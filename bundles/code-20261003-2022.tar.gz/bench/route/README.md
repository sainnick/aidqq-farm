# bench/route — route 生成器（MC-ROUTE-02，开发线 C）

按 `bench/route/SCHEMA.md` v1 生成 `route/<seed>.json`。**改规范只能由设计会话做**；
本目录只提供生成与核验工具。

## 两段式：probe（要机器时间） → emit（纯函数，零机器时间）

```
gen_route.mjs --seed <S>          # 开泳道 C 的服、跑服务器权威扫描 → probe/<S>.probe.json
emit_route.mjs --seed <S>         # 纯函数：probe → <S>.json（符合 SCHEMA v1 的草稿）
verify_determinism.mjs --seed <S> # 离线：两次 emit 逐字节比对 + 结构核验
```

**为什么拆两段**：验收要求「同一种子重复生成结果一致」。若探针与产出揉在一起，
证明它就得重开三次服重扫三遍；拆开后「重复生成」只需把纯函数跑两遍——**秒级、不占泳道**。
探针还能缓存复用（换站序/改字段不必重新探测）。

`gen_route.mjs --only <cat1,cat2>` 会**合并**进已有 probe（只覆盖重算的类），
所以补测某一类不用整轮重扫。

## 核验方法（赛前允许，口径见手册 §7 / DECISION-01 §2.1）

| 环节 | 手段 |
|---|---|
| 结构起点 | 服务器 `/locate <裸名>`（1.16.1 只认裸名，没有 `/locatebiome`） |
| 方块计数 | `forceload` + `fill <box> <marker> replace <block>` 的**服务器回执** |
| 精确坐标 | 对 `fill` 计数做**八叉递归细分**到 1×1×1（`descend()`） |
| 地形对照 | 每盒同时计 stone/dirt/water（主世界）或 netherrack（下界） |
| 自检 | 点状目标「下钻点数 == 粗扫计数」，不等即降级 `UNVERIFIED` |

坐标与核验数据只落在 `scout` 区；`station` 区由 emit **主动粗化到 16 格网格**
（比加载器兜底的 8 格更粗），radius 一律 ≥16，MISSION 形态固定为 `do station <id>`。

## 三个踩过的坑（都写进了代码注释，改代码前先读）

1. **`fill X replace X` 不计数**——替换成自己 = 无变化，服务器回 `No blocks were filled`。
   所以下钻必须**双标记逐层交替**（`barrier` ↔ `command_block`）才既能量又能递归。
2. **同盒多个 target 共用 marker 会污染下钻**——所有 target 都标成 `barrier` 时，
   下钻数到的是**全部 target 之和**（实测要塞一盒：spawner 真实 2，下钻报 130）。
   修法：地形对照先做，**每个 target 填完立刻下钻**，再去标下一个。
3. **回执迟滞会错位**——大 `fill`（尤其下界大量生成区块时）会让服务器 `Can't keep up!`，
   迟到回执与下一条命令配错位。修法三件：盒高 ≤16（单次 ≤16384 格，原版上限 32768）、
   发命令前先排空缓冲、**超时空错位硬失败不重试**（宁可报错也不产出"看着正常但坐标是错的"数据）。

## 泳道纪律

只用**泳道 C**（25568/25578），与开发线 E 排队共用。`console.mjs::waitForLaneC()`
同时检查**端口占用**与**心跳归属**（`experiments/mc1161-gate/.lane-owners`）——
端口空但心跳新鲜且归属别的活 runner 时一律让路。起停服复用 `_lib/runner_core.mjs`，
心跳由 `_lib/cleanup.mjs` 的 `registerChild` 统一维护，本工具不自己造心跳。

## 文件

| 文件 | 作用 |
|---|---|
| `console.mjs` | 泳道 C 装配 / 心跳排队 / 起停服 / stdin 控制台通道 |
| `scan.mjs` | fill-replace 计数、八叉下钻、地形对照、`/locate` 解析 |
| `gen_route.mjs` | probe 阶段：按 8 类配方探测 → `probe/<seed>.probe.json` |
| `emit_route.mjs` | emit 阶段：probe → SCHEMA v1 草稿（纯函数、确定性） |
| `verify_determinism.mjs` | 确定性 + 结构 + scout/station 分离的离线核验 |
| `smoke_probe.mjs` | 可行性冒烟（`/locate` 解析 + 末地门框几何自检） |
| `portal_frame.mjs` | **传送门框体**：生产 `frameCells` 的独立移植 + 候选框搜索 + 逐格服务端分类 + 与 B 线 r3 的离线对账闸门 |
| `cell_probe.mjs` | **逐格方块名**（非破坏性 2-fill 判据）。文件头有 1.16.1「没有 `/say`」的踩坑史 |
| `cmd_channel_smoke.mjs` | 实测 1.16.1 哪些命令通道能给控制台回读（回归护栏） |
| `frame_cell_truth.mjs` | 框体真值的最小诊断：逐格判据 / 整盒分类 / 慢速计数三方对照 |
| `portal_frame_batch.mjs` | **Top30 批量框体实测**（每种子两次开服）→ `probe/portal_frame_batch.json` |
| `seed_recommend.mjs` | 框体实测 × SEED-03 §9.4 五站硬上限合并排序 → `probe/seed_recommendation.md`（只推荐不冻结） |
| `nether_portal_frame.mjs` | 下界废弃门的框内黑曜石取证（一次性） |
| `cubiomes_struct.mjs` | cubiomes 结构放置数学的 JS 移植（带 9 项真值闸门） |
| `nether_portal_scan.mjs` | 下界废弃传送门是否存在（离线 cubiomes） |
| `inject_starts.mjs` | 把 SEED-03 的 cubiomes 起点注入 probe（带审计与备份） |
| `review_checklist.mjs` | 冻结审阅清单生成器（只读 route/probe） |
| `missions/` | （序列 JSON 在 fullrun stage，不在本目录） |

## 框体实测（Top30 批量）

```powershell
$N = '.\.runtime\node-v20.20.2-win-x64\node.exe'
& $N bench\route\tools\portal_frame.mjs                          # 离线对账闸门（10 项，不过就别开服）
& $N bench\route\tools\portal_frame_batch.mjs --limit 8 --resume # 分块跑，每块 ≤20 分钟（向 E 借泳道 C）
& $N bench\route\tools\seed_recommend.mjs                        # 合并五站硬上限 → 推荐
```

**两个必须知道的坑**（代码里都有详细注释）：

1. **1.16.1 没有 `/say`**，`tellraw` 在零玩家时也不落控制台 ⇒ **条件回读只能用 `/fill` 回执**。
2. **回执必须严格 FIFO 配对**（`con.sentFills/gotFills`）：发命令前"排空缓冲"对**还在路上的**回执无效，
   迟到的旧回执会被当成本条的答案。配不上时抛 `FILL_DESYNC` 硬失败，绝不在流不可信时继续产出坐标。

## 常用命令（Node 必须用 20：`.runtime/node-v20.20.2-win-x64/node.exe`）

```powershell
$N = '.\.runtime\node-v20.20.2-win-x64\node.exe'
& $N bench\route\tools\gen_route.mjs  --seed -8839485814800629942
& $N bench\route\tools\gen_route.mjs  --seed -6850455172235562789 --only fortress_spawner
& $N bench\route\tools\emit_route.mjs --seed -8839485814800629942
& $N bench\route\tools\verify_determinism.mjs --seed -8839485814800629942 --seed -6850455172235562789
& $N bench\route\tools\smoke_probe.mjs --seed -8839485814800629942
```

**冻结由设计会话做**（人工审阅 → 写 `frozenAt` → 生成 `<seed>.sha256`）。本工具产出的一律是
`frozenAt: null` 的草稿；编排器默认拒跑草稿，开发局需显式 `--allow-draft`。
