// bed_seal_check.mjs — ROUND7-C 复核：S0b_village_beds 的床到底连不连得上外面的空气
//
// 【为什么单独查】全站审计跑出 `S0b_village_beds: 同落脚分量 = 0`（床的空气分量 ≠ 露天分量），
//   而 route 里 `scout.reachability` 写的是"20 张床全部可达、不需挖墙"。
//   那条 reachability 的判据是**相邻性**（脚下实心 + 上方 2 格空 + ≥1 个可站邻格），
//   它自己在 caveat 里就写了"**这是代理判据，不是寻路**：没有计算门、没有计算从村外怎么走"。
//   ⇒ 两边不矛盾，是**粒度不同**。本文件把粒度补上：床所在的空气分量到底有多大、有没有门出去。
//
// 只读；不改 route。

import { openWorld } from './region_reader.mjs';

const AIR = new Set(['air', 'cave_air', 'void_air']);
const world = openWorld(process.argv[2] ?? 'D:/AI斗蛐蛐/bench/route/probe/_bedhunt');
const get = (x, y, z) => world.blockAt(x, y, z, 'overworld');

const CX = 120, CZ = 312, R = 56;
const box = { x1: CX - R, y1: 0, z1: CZ - R, x2: CX + R, y2: 255, z2: CZ + R };

function flood(seed) {
    const seen = new Set([seed.join(',')]);
    const st = [seed];
    const members = [];
    while (st.length) {
        const [x, y, z] = st.pop();
        members.push([x, y, z]);
        for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
            const nx = x + dx, ny = y + dy, nz = z + dz, k = `${nx},${ny},${nz}`;
            if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
            if (seen.has(k) || !AIR.has(get(nx, ny, nz))) continue;
            seen.add(k); st.push([nx, ny, nz]);
        }
    }
    return members;
}

const beds = [];
for (let y = 0; y <= 100; y++) for (let z = CZ - R; z <= CZ + R; z++) for (let x = CX - R; x <= CX + R; x++) {
    const b = get(x, y, z);
    if (b === 'yellow_bed' || b === 'white_bed') beds.push([x, y, z, b]);
}
console.log(`盘内(圆 r=${R}) 共读到床 ${beds.length} 张`);

const perBed = [];
const compOf = new Map();
for (const [x, y, z, b] of beds) {
    const seed = [x, y + 1, z];
    const key = seed.join(',');
    let m = compOf.get(key);
    if (!m) { m = flood(seed); compOf.set(key, m); }
    const ys = m.map((c) => c[1]);
    const openCol = m.some((c) => { for (let k = c[1] + 1; k <= 255; k++) if (!AIR.has(get(c[0], k, c[2]))) return false; return true; });
    const stand = m.filter((c) => AIR.has(get(c[0], c[1] - 1, c[2])) && get(c[0], c[1] - 1, c[2]) !== 'water' && !AIR.has(get(c[0], c[1] - 1, c[2])));
    perBed.push({ xyz: [x, y, z], b, compSize: m.length, yRange: [Math.min(...ys), Math.max(...ys)], openCol, feetSolid: stand.length });
}
const bySize = new Map();
for (const p of perBed) {
    const k = `${p.compSize}|${p.yRange[0]}-${p.yRange[1]}|openCol=${p.openCol}`;
    bySize.set(k, (bySize.get(k) ?? 0) + 1);
}
console.log('\n按空气分量归组（分量大小 | y 范围 | 有无整列通天 | 床数）：');
for (const [k, n] of [...bySize.entries()].sort((a, b) => b[1] - a[1])) console.log(`  ${n} 张床 ⇒ ${k}`);

// ---- 切面图：把最大那个分量画出来
const biggest = perBed.reduce((a, b) => (b.compSize > a.compSize ? b : a), perBed[0]);
const m = compOf.get([biggest.xyz[0], biggest.xyz[1] + 1, biggest.xyz[2]].join(','));
const inM = new Set(m.map((c) => c.join(',')));
const [bx, by, bz] = biggest.xyz;
const y0 = by - 1, y1 = by + 2;
// ---- 边界材料：分量内每格朝外一步，统计挡住它的方块名
// ⚠ 这是关键一步：光说"没连通"不够（空气泛洪不等于寻路，楼梯/台阶/栅栏会把玩家能走的
//   房间切成两团）。要看**挡在边界上的到底是什么**：若是 `oak_door` 就是"门关着"（可交互），
//   若是 cobblestone / oak_planks 就是"拿建材封死的墙"（要挖）。
const boundary = new Map();
for (const [x, y, z] of m) {
    for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
        const nx = x + dx, ny = y + dy, nz = z + dz;
        if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
        if (inM.has(`${nx},${ny},${nz}`)) continue;
        const b = get(nx, ny, nz);
        boundary.set(b, (boundary.get(b) ?? 0) + 1);
    }
}
const bSorted = [...boundary.entries()].sort((a, b) => b[1] - a[1]);
console.log(`\n该分量边界上挡路的方块（名称 × 面数）：`);
console.log('  ' + bSorted.map(([n, c]) => `${n}×${c}`).join('  '));
const doorish = bSorted.filter(([n]) => /door|trapdoor|fence_gate|ladder/.test(n));
console.log(`  ⇒ 门类方块：${doorish.length ? doorish.map(([n, c]) => `${n}×${c}`).join(' ') : '**一个都没有**'}`);

console.log(`\n最大分量（${m.length} 格，含床 @${bx},${by},${bz}）的切面，x ${bx - 9}..${bx + 9} / z ${bz - 9}..${bz + 9}`);
console.log('  符号：# 实体  . 露天空气  o 分量内空气(封闭)  B 床  ? 读不到  水 液体');
for (let z = bz - 9; z <= bz + 9; z++) {
    let rows = '';
    for (let y = y0; y <= y1; y++) {
        let r = '';
        for (let x = bx - 9; x <= bx + 9; x++) {
            const b = get(x, y, z);
            r += b === 'yellow_bed' || b === 'white_bed' ? 'B'
                : b === 'unknown' ? '?'
                    : AIR.has(b) ? (inM.has(`${x},${y},${z}`) ? 'o' : '.')
                        : b === 'water' || b === 'lava' ? '~' : '#';
        }
        rows += r + ' | ';
    }
    console.log(`  z=${z}  ${rows}`);
}
console.log(`  (每段依次是 y=${y0},y=${y0 + 1},y=${y0 + 2},y=${y0 + 3},y=${y0 + 4})`);
