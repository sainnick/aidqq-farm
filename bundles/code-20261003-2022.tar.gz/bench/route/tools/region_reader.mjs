// region_reader.mjs — R6-3：**1.16.1 Anvil 存档只读解析器**
//
// 【为什么做这个】控制台通道（FIFO 回执、未知方块名零回执、forceload 异步、实体计数无阳性对照、
//   `execute as @e[...,r=N]` 不支持距离参数）已经让 C/F 线返工多轮。
//   改成"让服务器把世界生成并保存一次 → 离线解析 .mca"，拿到**每一格方块和每一个实体**的真值，不再依赖回执。
//   仍属赛前预勘，公平口径允许（手册 §7「赛前允许：服务器权威通道核验」）。
//
// 【依赖选择：为什么不直接用 prismarine-nbt】`bench/` 仓库**没有 node_modules**（它是独立 git 仓库），
//   本机的 prismarine-nbt 只装在 `mindcraft/node_modules` 下 ⇒ 引用它得靠绝对路径或 junction，**跨目录很脆弱**
//   （别人一改 mindcraft 的依赖树，bench 的预勘工具就挂）。Anvil 容器层 + NBT 层一共约 200 行、格式稳定，
//   自己实现能被离线自检**逐字节**覆盖，判据可审计 ⇒ 选自研。
//   ⚠ prismarine-nbt 仍作为**交叉验证的第二实现**（`selftest` 里能 import 到就跑，对同一存档比对结果）。
//
// 【布局不是照 wiki 写的，是探测出来的】实测本机 1.16.1 存档：
//   - 定位表在 **0..4095**（**没有 4 KiB 头**！wiki 说的"前 4 KiB 为空"对这份存档不成立）
//   - 时间戳表 4096..8191 · 数据区 8192 起
//   - 每个 chunk：`4 字节压缩长度 + 1 字节 compression type + 数据`（type=2 ⇒ zlib）
//   ⇒ 所以本文件**自探测**两种布局（无头 / 有头），判据是"按该布局取第一个非零项能否解压并解析成 NBT"，
//   探测结果写进 `world.layout` 供审计。硬编码任何一种都可能在这台机器上读到垃圾。
//
// 【位打包：同样不靠记忆】1.16 的 Palette+BlockStates 有两种可能的位布局（跨 long / 不跨 long），
//   派单点名"1.16 起不跨 long"，但我**两个都实现**（`unpackBits` 的 `mode`），由**阳性对照**（C-2 的
//   gold_block 22 / gilded_blackstone 227 / chest 5 等已知真值）决定用哪个，并把实测记进存档元数据。

import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

// ================================================================== NBT 读取（自研，见文件头依赖说明）
const TAG_END = 0;
class NbtReader {
    constructor(buf) { this.b = buf; this.p = 0; }
    i8() { return this.b.readInt8(this.p++); }
    u8() { return this.b.readUInt8(this.p++); }
    i16() { const v = this.b.readInt16BE(this.p); this.p += 2; return v; }
    i32() { const v = this.b.readInt32BE(this.p); this.p += 4; return v; }
    i64() { const v = this.b.readBigInt64BE(this.p); this.p += 8; return v; }
    f32() { const v = this.b.readFloatBE(this.p); this.p += 4; return v; }
    f64() { const v = this.b.readDoubleBE(this.p); this.p += 8; return v; }
    str() { const n = this.i16(); const v = this.b.toString('utf8', this.p, this.p + n); this.p += n; return v; }
    payload(type) {
        switch (type) {
            case 1: return this.i8();
            case 2: return this.i16();
            case 3: return this.i32();
            case 4: return this.i64();
            case 5: return this.f32();
            case 6: return this.f64();
            case 7: { const n = this.i32(); const v = this.b.subarray(this.p, this.p + n); this.p += n; return v; }
            case 8: return this.str();
            case 9: { const et = this.i8(); const n = this.i32(); const a = new Array(n); for (let i = 0; i < n; i++) a[i] = this.payload(et); return a; }
            case 10: { const o = {}; for (;;) { const t = this.i8(); if (t === TAG_END) break; const name = this.str(); o[name] = this.payload(t); } return o; }
            case 11: { const n = this.i32(); const a = new Array(n); for (let i = 0; i < n; i++) a[i] = this.i32(); return a; }
            case 12: { const n = this.i32(); const a = new Array(n); for (let i = 0; i < n; i++) a[i] = this.i64(); return a; }
            default: throw new Error(`未知 NBT tag ${type} @${this.p - 1}`);
        }
    }
    readRoot() {
        const t = this.i8(); const name = this.str();
        return { type: t, name, value: this.payload(t), bytesRead: this.p };
    }
}

/** 便捷：把 `minecraft:stone` 归一成裸名 `stone`（比对时两边都归一） */
export const bare = (n) => String(n).replace(/^minecraft:/, '');

/**
 * palette 条目的 `Properties` → 规整对象（v1.1）。
 *
 * ⚠ **NBT 里 Properties 的值全是 tag 8（字符串）**：液体的 level 是 `"0"` / `"8"` 而不是数字。
 *   判"是不是源块"时 `props.level === 0` 会**永远为 false**（`"0" === 0` 是 false）——
 *   这正是本单最危险的一类静默失败，所以这里统一转型成数字/布尔。
 *   规则：能干净转成数字的转 number；`"true"/"false"` 转 boolean；其余保持原字符串。
 *   缺失或不是对象时返回 `null`（"这个方块没有状态"，与"状态是空对象"要能区分）。
 */
export function normalizeProps(props) {
    if (props == null || typeof props !== 'object' || Array.isArray(props)) return null;
    const out = {};
    for (const [k, v] of Object.entries(props)) {
        if (typeof v === 'boolean' || typeof v === 'number') { out[k] = v; continue; }
        const s = String(v);
        if (s === 'true' || s === 'false') { out[k] = (s === 'true'); continue; }
        // 只在"整个字符串就是数字"时转型，避免 "01" / "1.0.0" 之类被误当成数值
        if (s.trim() !== '' && /^-?\d+$/.test(s.trim())) { out[k] = Number(s); continue; }
        out[k] = s;
    }
    return out;
}

// ================================================================== 位解包（两种模式都实现，由阳性对照定夺）
/**
 * @param {bigint[]} longs   Section.BlockStates
 * @param {number} bits       max(4, ceilLog2(paletteSize))
 * @param {'packed'|'linear'} mode  'packed' = 1.16 的 PackedIntegerArray（**位段不跨 long**）
 *                                 'linear' = 1.15 及更早（位段连续跨 long）
 * @returns {Int16Array} 4096 个 palette 下标
 */
export function unpackBits(longs, bits, mode = 'packed') {
    const out = new Int16Array(4096);
    const mask = (1n << BigInt(bits)) - 1n;
    if (mode === 'linear') {
        for (let i = 0; i < 4096; i++) {
            const start = bits * i;
            const li = Math.floor(start / 64), off = start % 64;
            let v = (longs[li] ?? 0n) >> BigInt(off);
            if (off + bits > 64) v = v | ((longs[li + 1] ?? 0n) << BigInt(64 - off));   // 跨 long
            out[i] = Number(v & mask);
        }
        return out;
    }
    // packed：每个元素独占 long 内的 bits 位，不跨
    const perLong = Math.floor(64 / bits);
    for (let i = 0; i < 4096; i++) {
        const li = Math.floor(i / perLong), off = (i % perLong) * bits;
        out[i] = Number(((longs[li] ?? 0n) >> BigInt(off)) & mask);
    }
    return out;
}

/** ceil(log2(n))：让 2^bits >= n 所需的最小位数（n>=1）。⚠ 用纯 JS 写，JS 没有 `Math.numberOfLeadingZeros`。 */
export function ceilLog2(n) {
    let bits = 0, v = Math.max(1, n) - 1;
    while (v > 0) { bits++; v >>>= 1; }
    return bits;
}

/** bits 计算：1.16 的 PackedIntegerArray.getBits = max(4, ceilLog2(size)) */
export function bitsForPalette(n) { return Math.max(4, ceilLog2(n)); }

// ================================================================== Anvil 容器
/**
 * 读一个 chunk 的 NBT（返回 {ok, reason, root}）。
 *
 * 【1.16 的 chunk 数据布局 —— 实测钉死，不是照 wiki】
 *   `[4 字节 len][1 字节 compression type][数据]`，**且 `len` 字段含那个 type 字节**
 *   （实测真存档：len=7264、type=2、真正压缩数据 7263 字节；
 *     `subarray(+5, +4+len)` 与 `subarray(+5, +5+len)` 都能 inflate，而 `+4` 起会 "incorrect header check"）。
 *   type：2 = zlib、1 = gzip。
 *   ⇒ 两种 len 约定（"含 type" / "不含 type"）都试一遍，谁解得出 NBT 用谁。
 */
function readChunkNbt(buf, byteStart, sectorCount) {
    void sectorCount;
    if (byteStart + 5 > buf.length) return { ok: false, reason: 'offset 越界' };
    const len = buf.readInt32BE(byteStart);
    if (!(len > 0) || byteStart + 4 + len > buf.length) return { ok: false, reason: `压缩长度异常 ${len}` };
    const typeByte = buf[byteStart + 4];
    const withType = (n) => buf.subarray(byteStart + 5, Math.min(buf.length, byteStart + 5 + n));
    const attempts = [];
    if (typeByte === 2) { attempts.push(['zlib(len-1)', withType(len - 1), () => zlib.inflateSync(withType(len - 1))]); attempts.push(['zlib(len)', withType(len), () => zlib.inflateSync(withType(len))]); }
    if (typeByte === 1) { attempts.push(['gzip(len-1)', withType(len - 1), () => zlib.gunzipSync(withType(len - 1))]); attempts.push(['gzip(len)', withType(len), () => zlib.gunzipSync(withType(len))]); }
    // 旧格式（1.15 及更早）：没有 type 字节，len 就是压缩长度
    const legacy = buf.subarray(byteStart + 4, byteStart + 4 + len);
    attempts.push(['zlib(无type)', legacy, () => zlib.inflateSync(legacy)]);
    attempts.push(['gzip(无type)', legacy, () => zlib.gunzipSync(legacy)]);
    for (const [how, _d, fn] of attempts) {
        try {
            const raw = fn();
            const r = new NbtReader(raw).readRoot();
            if (r && typeof r.value === 'object' && r.value.Level) return { ok: true, how, bytes: raw.length, root: r.value };
        } catch { /* 试下一个 */ }
    }
    return { ok: false, reason: `所有解压路径都失败（type 字节=${typeByte}, len=${len}）` };
}

/** 布局自探测：{ headerBytes: 0 | 4096 } */
function detectLayout(file) {
    if (file.length < 8192 + 8) return null;                 // 定位表 + 时间戳表都放不下
    for (const headerBytes of [0, 4096]) {
        if (headerBytes + 4096 + 3 > file.length) continue;
        let probed = null;
        for (let i = 0; i < 1024 && !probed; i++) {
            const b0 = file.readUInt8(headerBytes + i * 4), b1 = file.readUInt8(headerBytes + i * 4 + 1);
            const b2 = file.readUInt8(headerBytes + i * 4 + 2), b3 = file.readUInt8(headerBytes + i * 4 + 3);
            const off = (b0 << 16) | (b1 << 8) | b2, sectors = b3;
            if (!off || !sectors) continue;
            const start = off * 4096;
            if (start + 8 > file.length) continue;
            const r = readChunkNbt(file, start, sectors);
            if (r.ok) probed = { index: i, offset: off, sectors, ok: true };
        }
        if (probed) return { headerBytes, probe: probed };
    }
    return null;
}

// ================================================================== World
/** 读不到时的统一返回（对象版）。冻结共享常量，避免每次 new 造成引用比较失败。 */
const UNKNOWN_STATE = Object.freeze({ name: 'unknown', props: null });

class World {
    /**
     * @param {string} worldDir  含 `region/` 的世界目录
     * @param {object} opt  { unpackMode: 'packed'|'linear'|'auto', dims: ['overworld'] }
     */
    constructor(worldDir, opt = {}) {
        this.dir = worldDir;
        this.regionDir = path.join(worldDir, 'region');
        this.unpackMode = opt.unpackMode ?? 'auto';
        this.dims = opt.dims ?? ['overworld'];
        this.chunkCache = new Map();          // "dim/cx/cz" → { palette:string[], idx:Int16Array, entities:[] }
        this.regionCache = new Map();         // region 路径 → {file, headerBytes}
        this.stats = { chunksRead: 0, chunkMiss: 0, entities: 0, layouts: {} };
        if (!fs.existsSync(this.regionDir)) {
            throw new Error(`REGION_DIR_MISSING：${this.regionDir} 不是世界目录（缺 region/）`);
        }
    }

    dimDir(dim) { return dim === 'overworld' ? this.regionDir : path.join(this.dir, dim === 'the_nether' ? 'DIM-1' : 'DIM1', 'region'); }

    _region(rx, rz) {
        const dim = this._dim ?? 'overworld';
        const p = path.join(this.dimDir(dim), `r.${rx}.${rz}.mca`);
        let rec = this.regionCache.get(p);
        if (rec !== undefined && this.regionCache.has(p)) return rec;
        if (!fs.existsSync(p)) { this.regionCache.set(p, null); return null; }
        const st = fs.statSync(p);
        if (st.size < 8192 + 8) { this.regionCache.set(p, null); return null; }   // 空/未初始化 region
        const file = fs.readFileSync(p);
        const det = detectLayout(file);
        if (!det) { this.regionCache.set(p, null); return null; }
        this.stats.layouts[p] = det.headerBytes;
        rec = { file, headerBytes: det.headerBytes, name: `r.${rx}.${rz}.mca` };
        this.regionCache.set(p, rec);
        return rec;
    }

    /** 读并缓存一个 chunk（返回 {palette, idx, entities, sections} 或 null） */
    chunk(cx, cz, dim = 'overworld') {
        this._dim = dim;
        const key = `${dim}/${cx}/${cz}`;
        if (this.chunkCache.has(key)) return this.chunkCache.get(key);
        const rx = cx >> 5, rz = cz >> 5;
        const reg = this._region(rx, rz);
        if (!reg) { this.chunkCache.set(key, null); this.stats.chunkMiss++; return null; }
        const idx = (cx - rx * 32) + (cz - rz * 32) * 32;
        if (reg.headerBytes + idx * 4 + 3 >= reg.file.length) { this.chunkCache.set(key, null); this.stats.chunkMiss++; return null; }
        const { file, headerBytes } = reg;
        const b0 = file.readUInt8(headerBytes + idx * 4), b1 = file.readUInt8(headerBytes + idx * 4 + 1);
        const b2 = file.readUInt8(headerBytes + idx * 4 + 2), b3 = file.readUInt8(headerBytes + idx * 4 + 3);
        const off = (b0 << 16) | (b1 << 8) | b2, sectors = b3;
        if (!off || !sectors) { this.chunkCache.set(key, null); this.stats.chunkMiss++; return null; }
        const r = readChunkNbt(file, off * 4096, sectors);
        if (!r.ok) { this.chunkCache.set(key, null); this.stats.chunkMiss++; return null; }
        this.stats.chunksRead++;
        const level = r.root.Level;
        // ⚠ 一个 chunk 跨 24 个 section（y 0..383）⇒ 索引空间是 **16×16×384 = 98304**，不是 4096。
        //   `idx` 存全局 palette 下标；`filled` 标记"这一格被某个 section 覆盖过"，
        //   用来区分**真 air**（被 section 覆盖且值是 air）与**该 y 段没有 section**（未加载 ⇒ unknown）。
        const SPAN = 16 * 16 * 384;
        const out = {
            palette: [], idx: new Int16Array(SPAN), filled: new Uint8Array(SPAN),
            entities: [], sections: 0, how: r.how, dataVersion: r.root.DataVersion ?? null,
        };
        const airId = out.palette.push({ name: 'air', props: null }) - 1;   // palette[0] 恒为 air，便于"空 section"直接引用
        let emptySections = 0;
        for (const sec of (level.Sections ?? [])) {
            const yBase = Number(sec.Y) * 16;
            if (yBase < 0 || yBase > 383) continue;
            if (!sec.BlockStates || !sec.Palette || !sec.Palette.length) {
                // ⚠⚠ **1.16 用「只有 Y、没有 BlockStates/Palette 的 section」表示"该段全 air"**
                //   （真存档实测：Y=-1 的 section 只有 `Y` 一个键）。
                //   这与「该 y 段根本没有 section 条目」（= 未生成/未加载，blockAt 应返 unknown）
                //   是**两件事** —— 手册 §5 的"没读到 ≠ 没有"，这里就是活例子。
                emptySections++;
                for (let y = 0; y < 16; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
                    const o = x + z * 16 + (yBase + y) * 256;
                    out.idx[o] = airId; out.filled[o] = 1;
                }
                continue;
            }
            // ⚠ v1.1（2026-10-02 R6-6）：palette 存 `{name, props}`。
            //   `Properties` 是 1.13+ BlockState 的状态（液体的 level、床的 part/facing、楼梯的 half…），
            //   **同一个 Name 可以有多个 Properties**（岩浆源 level=0 vs 流动岩浆 level≠0），
            //   所以只存名字会把这两种格子**混成一类**——而 B 线正在做的正是"舀源块 / 倒进缺格"的判定。
            //   ⚠ NBT 里 Properties 的值都是 **tag 8（字符串）**：`"0"` 不是数字 0，判等必须统一转型。
            const pal = sec.Palette.map((e) => ({ name: bare(e.Name ?? 'air'), props: normalizeProps(e.Properties) }));
            const bits = bitsForPalette(pal.length);
            const longs = sec.BlockStates.map((v) => BigInt(v));
            const mode = this.unpackMode === 'auto' ? 'packed' : this.unpackMode;
            const unpacked = unpackBits(longs, bits, mode);
            const map = new Map();
            for (let i = 0; i < pal.length; i++) map.set(i, out.palette.push(pal[i]) - 1);
            // ⚠⚠ **必须用 sec.Y 定位 y 偏移**（1.16 无 -4 偏移，sectionY = floor(y/16)）。
            //   漏掉它 ⇒ 所有 section 都写 y0..15 互相覆盖，最后一个 section 赢 ⇒ 整块 chunk 读成同一个方块。
            for (let y = 0; y < 16; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
                const o = x + z * 16 + (yBase + y) * 256;
                out.idx[o] = map.get(unpacked[x + z * 16 + y * 256]) ?? 0;
                out.filled[o] = 1;
            }
            out.sections++;
        }
        out.emptySections = emptySections;
        // ---- 实体（1.16 存 chunk **局部**坐标；下面用"Pos 是否在 0..16"自动判定并换算成绝对）
        for (const e of (level.Entities ?? [])) {
            if (!Array.isArray(e.Pos)) continue;
            const local = e.Pos[0] >= 0 && e.Pos[0] < 16 && e.Pos[2] >= 0 && e.Pos[2] < 16;
            const abs = local ? [cx * 16 + e.Pos[0], e.Pos[1], cz * 16 + e.Pos[2]] : [e.Pos[0], e.Pos[1], e.Pos[2]];
            out.entities.push({ id: bare(e.id ?? 'unknown'), pos: abs, local, dim: e.Dimension ?? dim, raw: e });
        }
        this.stats.entities += out.entities.length;
        this.chunkCache.set(key, out);
        return out;
    }

    /** 区块是否已保存（定位表里有数据） */
    hasChunk(cx, cz, dim = 'overworld') { return this.chunk(cx, cz, dim) !== null; }

    /**
     * 全局方块名（该 y 段没有 section / 区块未保存 ⇒ 'unknown'，**不**当 air）。
     *
     * ⚠ **v1.1 起这里仍然只返回名字字符串**（旧调用零影响，见 `blockState` 拿状态）。
     */
    blockAt(x, y, z, dim = 'overworld') {
        return this.blockState(x, y, z, dim).name;
    }

    /**
     * 全局方块**状态**：`{ name, props }`（v1.1 新增）。
     *
     * 需要区分同名不同状态的场合用这个 —— 典型是**液体**：
     *   岩浆源 `props.level === 0`、流动岩浆 `props.level !== 0`（1.16 流动岩浆 level 1..7，源块是 0）。
     *   只读名字的话这两种格子**完全一样**，B 线的"舀源块 / 浇方块"就会判错。
     * `props` 为 `null` = 这个方块没有 Properties（普通方块）；`name === 'unknown'` = 读不到。
     */
    blockState(x, y, z, dim = 'overworld') {
        const cx = x >> 4, cz = z >> 4;
        const c = this.chunk(cx, cz, dim);
        if (!c) return UNKNOWN_STATE;
        const lx = x - cx * 16, lz = z - cz * 16;
        if (y < 0 || y > 383) return UNKNOWN_STATE;
        const o = lx + lz * 16 + y * 256;
        if (!c.filled[o]) return UNKNOWN_STATE;
        return c.palette[c.idx[o]] ?? UNKNOWN_STATE;
    }

    /**
     * 盒内方块计数。**按 palette 直方图做**（不是逐格遍历）⇒ 大盒也快。
     * @param {{x1,y1,z1,x2,y2,z2}} box
     * @param {string[]|null} names 只数这些（裸名或带命名空间都行）；null = 全部
     * @returns {{counts:Object, unknownCells:number, cells:number}}
     */
    countInBox(box, names = null, dim = 'overworld') {
        const want = names ? new Set(names.map(bare)) : null;
        const counts = {};
        let unknownCells = 0, cells = 0;
        const cx1 = Math.floor(box.x1 / 16), cx2 = Math.floor(box.x2 / 16);
        const cz1 = Math.floor(box.z1 / 16), cz2 = Math.floor(box.z2 / 16);
        for (let cx = cx1; cx <= cx2; cx++) for (let cz = cz1; cz <= cz2; cz++) {
            const c = this.chunk(cx, cz, dim);
            // 该 chunk 与盒的交集范围
            const lx1 = Math.max(0, box.x1 - cx * 16), lx2 = Math.min(15, box.x2 - cx * 16);
            const lz1 = Math.max(0, box.z1 - cz * 16), lz2 = Math.min(15, box.z2 - cz * 16);
            const ly1 = Math.max(0, box.y1), ly2 = Math.min(383, box.y2);
            if (lx1 > lx2 || lz1 > lz2 || ly1 > ly2) continue;
            if (!c) { const n = (lx2 - lx1 + 1) * (lz2 - lz1 + 1) * (ly2 - ly1 + 1); unknownCells += n; cells += n; continue; }
            const hist = new Map();
            for (let y = ly1; y <= ly2; y++) for (let z = lz1; z <= lz2; z++) for (let x = lx1; x <= lx2; x++) {
                const o = x + z * 16 + y * 256;
                if (!c.filled[o]) { unknownCells++; cells++; continue; }      // 该 y 段没有 section ⇒ 不当 air
                const id = c.idx[o];
                hist.set(id, (hist.get(id) ?? 0) + 1);
            }
            for (const [id, n] of hist) {
                const name = c.palette[id]?.name ?? 'unknown';    // v1.1：palette 元素是 {name, props}
                cells += n;
                if (name === 'unknown') { unknownCells += n; continue; }
                if (want && !want.has(name)) continue;
                counts[name] = (counts[name] ?? 0) + n;
            }
        }
        return { counts, unknownCells, cells };
    }

    /**
     * 盒内实体。
     * @returns {Array<{id,pos,dim}>} 绝对坐标
     */
    entitiesInBox(box, types = null, dim = 'overworld') {
        const want = types ? new Set(types.map(bare)) : null;
        const out = [];
        const cx1 = Math.floor(box.x1 / 16), cx2 = Math.floor(box.x2 / 16);
        const cz1 = Math.floor(box.z1 / 16), cz2 = Math.floor(box.z2 / 16);
        for (let cx = cx1; cx <= cx2; cx++) for (let cz = cz1; cz <= cz2; cz++) {
            const c = this.chunk(cx, cz, dim);
            if (!c) continue;
            for (const e of c.entities) {
                if (want && !want.has(bare(e.id))) continue;
                if (e.pos[0] < box.x1 || e.pos[0] > box.x2) continue;
                if (e.pos[1] < box.y1 || e.pos[1] > box.y2) continue;
                if (e.pos[2] < box.z1 || e.pos[2] > box.z2) continue;
                out.push({ id: e.id, pos: e.pos.map(Math.floor), dim: e.dim });
            }
        }
        return out;
    }

    /** 便捷：某点附近的实体（**球形**，按 3D 距离；方盒用 entitiesInBox） */
    entitiesNear(x, y, z, radius, types = null, dim = 'overworld') {
        const all = this.entitiesInBox({ x1: x - radius, y1: y - radius, z1: z - radius, x2: x + radius, y2: y + radius, z2: z + radius }, types, dim);
        return all.filter((e) => Math.hypot(e.pos[0] - x, e.pos[1] - y, e.pos[2] - z) <= radius);
    }

    /** 调试：某 chunk 的解析摘要（只统计 section 覆盖到的格） */
    chunkInfo(cx, cz, dim = 'overworld') {
        const c = this.chunk(cx, cz, dim);
        if (!c) return null;
        const hist = {};
        let filled = 0;
        for (let i = 0; i < c.filled.length; i++) {
            if (!c.filled[i]) continue;
            filled++;
            const n = c.palette[c.idx[i]]?.name ?? 'unknown';       // v1.1：palette 元素是 {name, props}
            hist[n] = (hist[n] ?? 0) + 1;
        }
        return { cx, cz, sections: c.sections, paletteLen: c.palette.length, how: c.how, dataVersion: c.dataVersion, entities: c.entities.length, filled, hist };
    }
}

// ================================================================== NBT 写入（**只给离线自检构造合成存档用**）
/**
 * 最小 NBT writer：把 JS 值写成 1.16 的 NBT 字节。
 * ⚠ 它是自检的**另一半**：自检要造"已知内容的 .mca"来测位打包边界，
 *   如果用解析器的镜像逻辑来写，就等于自证（读写同源、同一个误解查不出来）。
 *   这里刻意用**独立的、直接的**写法（Buffer.concat 拼字节），与 reader 不共享任何代码。
 * 支持：byte/short/int/long/float/double/string/compound/list/intArray/longArray
 */
export function writeNbt(rootValue, { rootName = '', rootType = 10 } = {}) {
    const parts = [];
    const u8 = (v) => parts.push(Buffer.from([v & 0xff]));
    const i16 = (v) => { const b = Buffer.alloc(2); b.writeInt16BE(v); parts.push(b); };
    const i32 = (v) => { const b = Buffer.alloc(4); b.writeInt32BE(v); parts.push(b); };
    const i64 = (v) => { const b = Buffer.alloc(8); b.writeBigInt64BE(BigInt(v)); parts.push(b); };
    const f32 = (v) => { const b = Buffer.alloc(4); b.writeFloatBE(v); parts.push(b); };
    const f64 = (v) => { const b = Buffer.alloc(8); b.writeDoubleBE(v); parts.push(b); };
    const strBytes = (s) => { const bb = Buffer.from(s, 'utf8'); i16(bb.length); parts.push(bb); };
    const typeOf = (v) => {
        if (typeof v === 'boolean') return 1;
        if (typeof v === 'number') return Number.isInteger(v) && v >= -128 && v <= 127 ? 1 : (Number.isInteger(v) && v >= -32768 && v <= 32767 ? 2 : (Number.isInteger(v) ? 3 : 6));
        if (typeof v === 'bigint') return 4;
        if (typeof v === 'string') return 8;
        if (Array.isArray(v)) return 9;
        if (v && v.__type) return v.__type;
        return 10;
    };
    const payload = (type, v) => {
        switch (type) {
            case 1: u8(typeof v === 'boolean' ? (v ? 1 : 0) : v); break;
            case 2: i16(v); break;
            case 3: i32(v); break;
            case 4: i64(v); break;
            case 5: f32(v); break;
            case 6: f64(v); break;
            case 8: strBytes(v); break;
            case 9: { const et = v.__elemType ?? (v.length ? typeOf(v[0]) : 1); u8(et); i32(v.length); for (const x of v) payload(et, x); break; }
            case 10: { for (const [k, val] of Object.entries(v)) { const t = typeOf(val); u8(t); strBytes(k); payload(t, val); } u8(0); break; }
            case 11: { i32(v.length); for (const x of v) i32(x); break; }
            case 12: { i32(v.length); for (const x of v) i64(x); break; }
            default: throw new Error(`writeNbt 不支持 tag ${type}`);
        }
    };
    u8(rootType); strBytes(rootName); payload(rootType, rootValue);
    return Buffer.concat(parts);
}

/**
 * 把 4096 个 palette 下标按 `mode` 打包成 long[]（1.16 的 BlockStates 格式）。
 * @param {number[]} idx  4096 个下标（顺序 x + z*16 + y*256）
 * @param {number} bits
 * @param {'packed'|'linear'} mode
 */
export function packBits(idx, bits, mode = 'packed') {
    const out = [];
    const mask = (1n << BigInt(bits)) - 1n;
    if (mode === 'packed') {
        const perLong = Math.floor(64 / bits);
        const n = Math.ceil(4096 / perLong);
        for (let i = 0; i < n; i++) {
            let acc = 0n;
            for (let k = 0; k < perLong; k++) {
                const e = i * perLong + k;
                if (e >= 4096) break;
                acc |= (BigInt(idx[e]) & mask) << BigInt(k * bits);
            }
            out.push(acc);
        }
        return out;
    }
    let acc = 0n, nbits = 0;
    for (const v of idx) {
        acc |= (BigInt(v) & mask) << BigInt(nbits);
        nbits += bits;
        if (nbits >= 64) { out.push(acc); acc = 0n; nbits -= 64; }
    }
    if (nbits > 0) out.push(acc);
    return out;
}

export { NbtReader, readChunkNbt, detectLayout };
export function openWorld(worldDir, opt) { return new World(worldDir, opt); }
export default { openWorld, unpackBits, bitsForPalette, ceilLog2, bare, normalizeProps, NbtReader, readChunkNbt, detectLayout };
