﻿// v2_guard_selftest.mjs — route_guard 的 **SCHEMA §5 / aidqq-route/2** 判据离线用例
//
// 【为什么单独一个文件】v1 的既有用例（route_guard_fallback_selftest.mjs / route_hash_selftest.mjs）
//   不动、不改；本单只往 route_guard.mjs 里**追加** v2 分支，v1 行为必须逐字不变 ——
//   这一点由 C1/C9 两个用例 + 那两个既有用例一起兜住。
//
// 【要证明什么】验收线是**反向**的：每个 v2 判据都必须能被抓到（故意弄错 → 报 violation），
//   同时没弄错时必须 0 violations。**只测"对的通过"是不够的** —— 一个永远返回 0 的校验
//   同样能通过那种测试。所以每个变更用例都同时跑一遍"未变更的同一份 fixture"，
//   断言它此刻是空的（C2 基准），以此证明该 violation 是被这次变更**触发**的、不是恒真的。
//   用例 6/7/8 全部满足「非空 + 命中预期子串 + 基准为空」三段。
//
// 【fixture 从哪来】只在**内存**里造，写进 os.tmpdir() 的临时目录；**从不改** bench/route/*.json。
//   唯一读真实文件的是 C1（两个 v1 回归样本）和 C9（把 v1 文档过一遍 v2 路径）。
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\v2_guard_selftest.mjs

import fs from 'fs';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { readRouteFile, checkStandsAgainstSave } from '../../stages/fullrun/route_guard.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));   // bench/route/tools
const ROUTE_DIR = path.resolve(HERE, '..');                    // bench/route
const PROBE_OUT = path.join(ROUTE_DIR, 'probe', 'v2_guard_selftest.last.json');

let pass = 0, fail = 0;
const cases = [];
/** 每个用例一行 PASS/FAIL；用例内部的子断言折叠进 ok 里（任一子断言失败 ⇒ 整例失败） */
function runCase(id, name, fn) {
    const notes = [];
    const bad = (m) => { notes.push(m); };
    try { fn(bad); } catch (e) { bad(`用例抛异常：${String(e).slice(0, 200)}`); }
    const ok = notes.length === 0;
    if (ok) { pass++; console.log(`PASS  ${id}  ${name}`); } else { fail++; console.log(`FAIL  ${id}  ${name}`); for (const n of notes) console.log(`        ↳ ${n}`); }
    cases.push({ id, name, ok, notes });
}

// ------------------------------------------------------------------ fixture：基准 v2
// 3 个正常流程站 + 2 个 fallback-only 站；4 条腿（2 正常、1 正常→fallback、1 纯 fallback 内部走线）。
const EV = 'experiments/seed-scout/v2_parse.json';
function mkStation(id, seq, extra = {}) {
    return {
        id, seq, kind: 'x', dim: 'overworld',
        station: { center: [0, 0], yHint: 'surface', radius: 32, lookFor: ['stone'] },
        scout: { verify: { status: 'REAL' } },
        fallback: [],
        exact: {
            stand: [[0, 64, 0]],
            targets: [{ what: 'dig', xyz: [1, 64, 0], tool: 'iron_pickaxe' }],
            hazards: [],
            verify: { status: 'REAL', evidence: EV },
        },
        ...extra,
    };
}
function baseV2() {
    return {
        schema: 'aidqq-route/2', frozenAt: null, sha256File: null,
        stations: [
            mkStation('S0_iron', 1, { fallback: ['S0_sheep'] }),
            mkStation('S0_gravel', 2),
            mkStation('S1_portal', 3, { fallback: ['S1b_lava_pool'] }),
            mkStation('S0_sheep', 4, { routeRole: 'fallback-only' }),
            mkStation('S1b_lava_pool', 5, { routeRole: 'fallback-only' }),
        ],
        // 相邻腿的路点间距**全部正好 32**（§5 的合法上限），距离判据的边界就压在这个值上
        legs: [
            { from: 'S0_iron', to: 'S0_gravel', dim: 'overworld', waypoints: [[0, 64, 0], [32, 64, 0], [64, 64, 0]] },
            { from: 'S0_gravel', to: 'S1_portal', dim: 'overworld', waypoints: [[64, 64, 0], [96, 64, 0], [128, 64, 0]] },
            { from: 'S1_portal', to: 'S1b_lava_pool', dim: 'the_nether', waypoints: [[128, 64, 0], [160, 64, 0]] },
            { from: 'S0_sheep', to: 'S1b_lava_pool', dim: 'overworld', waypoints: [[300, 64, 0], [332, 64, 0]] },
        ],
        normalFlowStations: ['S0_iron', 'S0_gravel', 'S1_portal'],
        fallbackOnlyStations: [
            { id: 'S0_sheep', seq: 4, fallbackOf: ['S0_iron'] },
            { id: 'S1b_lava_pool', seq: 5, fallbackOf: ['S1_portal'] },
        ],
    };
}

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'v2guard-'));
const FILE = path.join(TMP, 'route.json');
/** 造一份 fixture（内存里 mutate 完再落临时盘）→ 过一遍真正的 readRouteFile */
function check(doc) {
    fs.writeFileSync(FILE, JSON.stringify(doc, null, 2) + '\n');
    const r = readRouteFile(FILE);
    return { v: r.violations, traffic: r.v2FallbackTraffic, schema: r.schema };
}
/** 基准/变更 一次跑完，返回两份结果；变更用例必须同时看到「基准空 + 变更非空」 */
function pair(mutate) {
    const clean = check(baseV2());
    const doc = baseV2();
    if (mutate) mutate(doc);
    const dirty = check(doc);
    return { clean, dirty };
}
const st = (doc, id) => doc.stations.find((s) => s.id === id);
/** 变更用例的统一断言：基准必须空、变更必须非空、且必须命中预期子串 */
function mustFire(bad, pairResult, re, what) {
    if (pairResult.clean.v.length) { bad(`【非空证明失败】未变更的同一份 fixture 竟然有 ${pairResult.clean.v.length} 条 violation：${pairResult.clean.v.join(' | ')}`); return; }
    if (!pairResult.dirty.v.length) { bad(`【变更没触发任何 violation】${what}`); return; }
    if (!pairResult.dirty.v.some((x) => re.test(x))) {
        bad(`没命中预期子串 ${re}：${what}\n        实际：${JSON.stringify(pairResult.dirty.v).slice(0, 400)}`);
    }
}

// ============================================================ C1 v1 回归：两个真实 v1 文件
runCase('C1', '两个真实 v1 route 文件（回归）仍然 0 violations', (bad) => {
    for (const f of ['-8839485814800629942.json', '-6850455172235562789.json']) {
        const p = path.join(ROUTE_DIR, f);
        if (!fs.existsSync(p)) { bad(`回归样本不存在：${p}`); continue; }
        const r = readRouteFile(p);
        if (r.schema !== 'aidqq-route/1') bad(`${f} 期望 schema=aidqq-route/1，实得 ${r.schema}`);
        if (r.violations.length) bad(`${f} 应 0 violations，实得 ${r.violations.length}：${r.violations.join(' | ')}`);
    }
});

// ============================================================ C2 最小合法 v2
runCase('C2', '最小合法 v2 文档 → 0 violations（所有变更用例的非空基准）', (bad) => {
    const r = check(baseV2());
    if (r.v.length) bad(`基准 v2 竟有 ${r.v.length} 条：${r.v.join(' | ')}`);
    if (r.schema !== 'aidqq-route/2') bad(`schema 未识别为 v2：${r.schema}`);
    // 非正常腿要被标成 fallback traffic 供观察（不报 violation）
    if (r.traffic.length !== 2) bad(`fallbackTraffic 应为 2 条（正常→fallback、纯 fallback 内部），实得 ${JSON.stringify(r.traffic)}`);
});

// ============================================================ C3 exact.verify.evidence 为空
runCase('C3', 'v2 的 exact.verify.evidence 为空 → violation', (bad) => {
    mustFire(bad, pair((d) => { st(d, 'S0_iron').exact.verify.evidence = '   '; }),
        /S0_iron exact\.verify\.evidence="   " 为空/, 'S0_iron 的证据被清空');
    // evidence 整个字段缺失也要抓到
    mustFire(bad, pair((d) => { delete st(d, 'S1_portal').exact.verify; }),
        /S1_portal exact\.verify\.evidence=null 为空/, 'S1_portal 的 exact.verify 整个缺失');
});

// ============================================================ C4 腿的端点站没有 exact.stand
runCase('C4', 'leg 的端点站没有非空 exact.stand → violation（首尾与站一致）', (bad) => {
    mustFire(bad, pair((d) => { delete st(d, 'S0_gravel').exact.stand; }),
        /legs\[0\]\(S0_iron->S0_gravel\) to 站 S0_gravel 没有非空 exact\.stand/, 'S0_gravel 被删掉站位，legs[0] 的 to 端点落空');
    // from 端点同样要被抓到（S0_gravel 是 legs[1] 的 from）
    mustFire(bad, pair((d) => { st(d, 'S0_gravel').exact.stand = []; }),
        /legs\[1\]\(S0_gravel->S1_portal\) from 站 S0_gravel 没有非空 exact\.stand/, 'S0_gravel 站位置空，legs[1] 的 from 端点落空');
});

// ============================================================ C5 相邻路点 ≤ 32（两个方向都断言）
runCase('C5', '相邻路点距离：33 → violation；正好 32 → 放行；32.0001 → violation', (bad) => {
    // (a) 33 格 → 必报
    mustFire(bad, pair((d) => { d.legs[0].waypoints[1] = [33, 64, 0]; }),
        /legs\[0\]\(S0_iron->S0_gravel\) 相邻路点 waypoints\[0\]->waypoints\[1\] 距离 33\.0000 > 32 格/, '把路点拉到 33 格');
    // (b) 正好 32 格 → 必须**不**报（基准本身就是全 32）
    const at = check(baseV2());
    if (at.v.length) bad(`正好 32 格反而报了 violation：${at.v.join(' | ')}`);
    // (c) 32.0001 → 必报（证明判据是严格 > 32，不是 ≥ 32 也不是整数判定）
    mustFire(bad, pair((d) => { d.legs[0].waypoints[1] = [32.0001, 64, 0]; }),
        /waypoints\[0\]->waypoints\[1\] 距离 32\.0001 > 32 格/, '32.0001 格应当判违规');
    // (d) 3D 欧氏，不是 XZ：XZ 相距 0、y 差 36 → 3D 36 > 32 → 必报
    mustFire(bad, pair((d) => { d.legs[1].waypoints = [[64, 64, 0], [64, 100, 0], [64, 100, 32]]; }),
        /legs\[1\].*waypoints\[0\]->waypoints\[1\] 距离 36\.0000 > 32 格/, 'XZ 距离 0 但 y 差 36（只量 XZ 就会漏）');
    // (e) 同上方向的合法侧：y 差正好 32（XZ 距离 0）→ 放行
    const y32 = baseV2();
    y32.legs[1].waypoints = [[64, 64, 0], [64, 96, 0], [64, 96, 32]];
    const r32 = check(y32);
    if (r32.v.length) bad(`y 差正好 32 反被报违规：${r32.v.join(' | ')}`);
});

// ============================================================ C6 非整数坐标
runCase('C6', 'exact 里的非整数坐标 → violation（stand / targets / hazards 三处）', (bad) => {
    mustFire(bad, pair((d) => { st(d, 'S0_iron').exact.stand = [[0.5, 64, 0]]; }),
        /S0_iron exact\.stand\[0\]=\[0\.5,64,0\] 不是整数三元组/, 'stand 里写了 0.5');
    mustFire(bad, pair((d) => { st(d, 'S0_iron').exact.targets[0].xyz = [1, 64, 2.25]; }),
        /S0_iron exact\.targets\[0\]\(dig\)\.xyz=\[1,64,2\.25\] 不是整数三元组/, 'targets[0].xyz 写了 2.25');
    mustFire(bad, pair((d) => { st(d, 'S0_iron').exact.hazards = [[3, 64, 4], [5, 64]]; }),
        /S0_iron exact\.hazards\[1\]=\[5,64\] 不是整数三元组/, 'hazards[1] 只有两维');
});

// ============================================================ C7 leg 指向不存在的站
runCase('C7', 'leg 引用不存在的站 → violation', (bad) => {
    mustFire(bad, pair((d) => { d.legs.push({ from: 'GHOST', to: 'S0_iron', dim: 'overworld', waypoints: [[0, 64, 0], [32, 64, 0]] }); }),
        /legs\[4\]\(GHOST->S0_iron\) from 指向不存在的站 "GHOST"/, '新增一条 from=GHOST 的腿');
});

// ============================================================ C8 正常流程之间缺腿
runCase('C8', '两条相邻 normalFlowStations 之间缺腿 → violation', (bad) => {
    mustFire(bad, pair((d) => { d.legs.splice(1, 1); }),
        /legs 缺 S0_gravel -> S1_portal 这条腿（normalFlowStations 第 2、3 个正常流程站之间必须有腿/, '删掉 S0_gravel→S1_portal');
    // 反向也判：把腿的 from/to 调个头（区间覆盖不算数）
    mustFire(bad, pair((d) => { const l = d.legs[1]; l.from = 'S1_portal'; l.to = 'S0_gravel'; }),
        /legs 缺 S0_gravel -> S1_portal 这条腿/, '把 S0_gravel→S1_portal 反向，正常流程仍然连不上');
});

// ============================================================ C9 v1 走 v2 路径不被误伤
runCase('C9', 'v1 文档过一遍（v2 路径只对 aidqq-route/2 生效）', (bad) => {
    // 造一份"典型 v1"：有 normalFlowStations / fallbackOnlyStations / routeRole，
    // 但**没有 legs、没有 exact** —— 正是 v1 正常形态。
    const v1 = {
        schema: 'aidqq-route/1', frozenAt: null, sha256File: null,
        stations: baseV2().stations,
        normalFlowStations: baseV2().normalFlowStations,
        fallbackOnlyStations: baseV2().fallbackOnlyStations,
    };
    for (const s of v1.stations) { delete s.exact; delete s.legs; }
    const r = check(v1);
    if (r.schema !== 'aidqq-route/1') bad(`schema 未识别为 v1：${r.schema}`);
    if (r.v.length) bad(`v1 文档被误判（v1 规则全过时不该有 violation）：${r.v.join(' | ')}`);
    // 关键反向断言：不得出现任何 v2 专属的抱怨
    const v2ish = r.v.filter((x) => /exact|legs|腿|证据|站位/.test(x));
    if (v2ish.length) bad(`v1 文档被判了 v2 专属的违规：${v2ish.join(' | ')}`);
    // 同一份文档改成 v2（只加 schema，legs/exact 还没补）必须**开始**报 v2 违规，
    // 证明 C9 的"0 violations"不是因为 v2 判据根本没跑。
    const v2stub = { ...v1, schema: 'aidqq-route/2' };
    const r2 = check(v2stub);
    if (!r2.v.some((x) => x.startsWith('顶层缺 legs'))) {
        bad(`v2 stub 竟没报"顶层缺 legs"（说明 C9 的 0 violations 是判据没跑）：${JSON.stringify(r2.v).slice(0, 300)}`);
    }
});

// ============================================================ C10 v2 不再查 center 8 格 / radius≥16 / lookFor（ROUND9-C）
//   背景：DECISION-02 §3 已把这三条作废，而 B 线的 `route_loader` 在 v2 下**已经不查**。
//   ⇒ guard 再查就成了"**比 loader 严**"，v2 文件会被自己的守卫判死。
//   本用例是**双向**的：v2 放行 + v1 仍然拦（证明不是把判据删了，是按 schema 分流）。
runCase('C10', 'v2 不查 center 8 格/radius/lookFor；v1 仍然查（逐字不变）', (bad) => {
    const mk = (schema) => {
        const d = baseV2();
        d.schema = schema;
        for (const s of d.stations) s.station = { center: [13, 27], yHint: 'surface', radius: 8, lookFor: [] };  // 三样都"违规"
        return d;
    };
    const v2 = check(mk('aidqq-route/2'));
    const hit = v2.v.filter((x) => /未对齐 8 格|radius=|lookFor 为空/.test(x));
    if (hit.length) bad(`v2 仍被判了已作废的三条：${hit.join(' | ')}`);
    const v1 = check(mk('aidqq-route/1'));
    for (const re of [/未对齐 8 格/, /radius=8 < 16/, /lookFor 为空/]) {
        if (!v1.v.some((x) => re.test(x))) bad(`v1 不再报 ${re}（v1 行为必须逐字不变）：${JSON.stringify(v1.v).slice(0, 300)}`);
    }
    const v1ok = check(baseV2());
    if (v1ok.v.length) bad(`基准 v1 竟有 violation：${v1ok.v.join(' | ')}`);
});

// ============================================================ C11 站位回读判据（ROUND9-C 新增，反例必须报错）
//   **反例就是本单那三个低 1 格的坐标**：S3 [331,62,238]、C3 [220,68,-87]、S5 [1332,35,1159]。
//   这三处在 ROUND8-C 的 v2 里通过了全部结构判据、也是 0 violations ——
//   只有拿存档逐格读"支撑方块实不实、身体两格空不空"才抓得到。
const C11 = async () => {
    const PROBE = path.join(ROUTE_DIR, 'probe');
    const OW = path.join(PROBE, '_bedhunt');
    const NETHER = path.join(PROBE, '_r9c_nether_corridor');
    const S5W = path.join(PROBE, '_s5_s5');
    for (const p of [OW, NETHER, S5W]) if (!fs.existsSync(p)) return [`读回用存档不存在：${p}`];
    const mkDoc = () => {
        const d = baseV2();
        const mk = (id, dim, stand) => { const s = d.stations.find((x) => x.id === id); s.dim = dim; s.exact = { ...s.exact, stand }; };
        mk('S0_iron', 'overworld', [[206, 45, 232]]);
        mk('S0_gravel', 'overworld', [[186, 42, 258]]);
        mk('S1_portal', 'overworld', [[187, 41, 307]]);
        mk('S0_sheep', 'overworld', [[216, 62, 224]]);
        mk('S1b_lava_pool', 'overworld', [[1332, 35, 1159]]);       // ❌ S5 低 1 格（_bedhunt 不覆盖要塞，靠 moreWorlds 读 _s5_s5）
        return d;
    };
    const bad = [];
    const v1 = [];
    const r1 = await checkStandsAgainstSave(mkDoc(), { overworldWorld: OW, moreWorlds: [S5W] }, v1);
    if (r1.checked < 5) bad.push(`回读只检查了 ${r1.checked} 个站位，通道可能没跑（应有 5 个）`);
    if (!v1.some((x) => /1332,35,1159/.test(x))) bad.push(`S5 低 1 格的反例没被抓到：${JSON.stringify(v1).slice(0, 400)}`);
    for (const good of ['206,45,232', '186,42,258', '187,41,307', '216,62,224'])
        if (v1.some((x) => x.includes(good))) bad.push(`正确的站位 ${good} 被误报：${v1.find((x) => x.includes(good))}`);

    const doc2 = baseV2();
    const mk2 = (id, dim, stand) => { const s = doc2.stations.find((x) => x.id === id); s.dim = dim; s.exact = { ...s.exact, stand }; };
    mk2('S0_iron', 'the_nether', [[331, 62, 238]]);               // ❌ S3 低 1 格
    mk2('S0_gravel', 'the_nether', [[220, 68, -87]]);              // ❌ C3 低 1 格
    mk2('S1_portal', 'overworld', [[1332, 35, 1159]]);             // ❌ S5 低 1 格
    mk2('S0_sheep', 'overworld', [[216, 62, 224]]);
    mk2('S1b_lava_pool', 'overworld', [[103, 72, 267]]);
    const v2v = [];
    await checkStandsAgainstSave(doc2, { overworldWorld: OW, netherWorld: NETHER, moreWorlds: [S5W] }, v2v);
    for (const b3 of ['331,62,238', '220,68,-87', '1332,35,1159'])
        if (!v2v.some((x) => x.includes(b3))) bad.push(`反例 ${b3} 没报违规：${JSON.stringify(v2v).slice(0, 500)}`);

    const doc3 = baseV2();
    const mk3 = (id, dim, stand) => { const s = doc3.stations.find((x) => x.id === id); s.dim = dim; s.exact = { ...s.exact, stand }; };
    mk3('S0_iron', 'the_nether', [[331, 56, 238]]);
    mk3('S0_gravel', 'the_nether', [[220, 69, -87]]);
    mk3('S1_portal', 'overworld', [[1332, 36, 1159]]);
    mk3('S0_sheep', 'overworld', [[216, 62, 224]]);
    mk3('S1b_lava_pool', 'overworld', [[103, 72, 267]]);
    const v3 = [];
    await checkStandsAgainstSave(doc3, { overworldWorld: OW, netherWorld: NETHER, moreWorlds: [S5W] }, v3);
    if (v3.length) bad.push(`订正后的站位仍被报违规：${v3.join(' | ')}`);
    return bad;
};
{
    const notes = [];
    try { notes.push(...(await C11())); } catch (e) { notes.push(`用例抛异常：${String(e).slice(0, 200)}`); }
    if (notes.length) { fail++; console.log('FAIL  C11  站位回读：低 1 格的三个坐标必须报违规，订正后必须干净'); for (const n of notes) console.log(`        ↳ ${n}`); }
    else { pass++; console.log('PASS  C11  站位回读：低 1 格的三个坐标必须报违规，订正后必须干净'); }
    cases.push({ id: 'C11', name: '站位回读：低 1 格的三个坐标必须报违规，订正后必须干净', ok: !notes.length, notes });
}

// ------------------------------------------------------------------ 收尾：汇总落盘
const total = pass + fail;
console.log(`\n${fail === 0 ? '✅' : '❌'} v2_guard 自检 ${pass}/${total} 用例通过${fail ? `，${fail} 失败` : ''}`);
try {
    fs.mkdirSync(path.dirname(PROBE_OUT), { recursive: true });
    fs.writeFileSync(PROBE_OUT, JSON.stringify({
        selftest: 'v2_guard_selftest', schemaUnderTest: 'aidqq-route/2',
        at: new Date().toISOString(), node: process.version,
        total, pass, fail, ok: fail === 0, cases,
    }, null, 2) + '\n', 'utf8');
    console.log(`汇总已写：${PROBE_OUT}`);
} catch (e) {
    console.log(`⚠ 汇总写盘失败：${String(e).slice(0, 160)}`);
    fail++;   // 写不出汇总 = 本次运行无法被验证，同样算失败
}
process.exit(fail === 0 ? 0 : 1);
