// fortress_standing_selftest.mjs — MC-ROUND5 §C：**站位补测探针的离线自检**（不碰服务器、不占端口）
//
// 【为什么要有这个文件】ROUND4 那一站的教训是"连续 5 次以为工具坏了"，前 4 次错的都是工具。
//   而这一类问题（回执配对、判据逻辑、穷举闸门）**完全可以在离线环境证伪**：
//   造一个假世界 + 假回执，把三遍扫的逻辑整体跑一遍，比烧 7 分钟服务器时间便宜两个数量级。
//   手册 §5 的自检清单也要求"失败先离线复现"；本文件是那条纪律的落地。
//
// 覆盖：
//   T1 回执行分类（filled / empty / unknown_block / not_loaded / error / 非判决行）
//   T2 三道闸门（中心格真值 / 穷举 Σ / 逐格未解析）
//   T3 站位判据：平地无墙 / 有墙角 / 楼梯地板（口径差）/ 未解析格
//   T4 端到端：假世界上跑 Pass0→Pass1→Pass2，断言站位数与世界未被破坏
//   T5 穷举闸门能抓住"调色板缺名"（PALETTE_INCOMPLETE）
//   T6 回执错位（把一条回执换成别的命令的）会被穷举闸门抓住
//   T7 候选名清单不含 barrier、含 nether_brick_stairs
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\fortress_standing_selftest.mjs

import {
    classifyFillLine, fillOnce, countAndRestore, probeCellSafe,
    gateCenterTruth, gateExhaustive, gatePerCell, tallyPalette,
    findStands, findOpenFloors, findProbeCell, isNameAccepted, probeCellAllHits, SOLID_EXT, SOLID_ROUND4, readCandidateNames, qname,
} from './fortress_standing_probe.mjs';

let pass = 0, fail = 0;
const A = (name, cond, extra = '') => {
    if (cond) { pass++; console.log(`  ✔ ${name}`); }
    else { fail++; console.log(`  ✘ ${name}${extra ? ` — ${extra}` : ''}`); }
};
const eq = (name, got, want) => A(name, Object.is(got, want) || JSON.stringify(got) === JSON.stringify(want), `got=${JSON.stringify(got)} want=${JSON.stringify(want)}`);

// ------------------------------------------------------------------ 假服务器
/**
 * 一个能真正执行 `fill … replace …` 的假世界。
 * 关键点：
 *  - **回执延迟一条命令**（第一次 drain 拿不到本条，要等下一次）——逼调用方正确配对；
 *  - 偶尔插**非判决噪声行**——逼 classifyFillLine 会跳过它们；
 *  - 未知方块名回 `Unknown block type` ——1.16.1 的真实行为；
 *  - `corrupt`：给某条命令返回**别的方块**的计数，用来模拟回执错位。
 */
class FakeCon {
    constructor(world, opt = {}) {
        this.world = new Map(world); this.opt = opt; this.child = { exitCode: null };
        this.queue = []; this.pending = []; this.sent = [];
    }
    cmd(str) {
        this.sent.push(str);
        this.pending.push(this.exec(str));
    }
    exec(str) {
        const m = str.match(/fill (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (\S+) replace (\S+)/);
        if (!m) return ['[Server thread/INFO]: unknown command form'];
        const [, x1, y1, z1, x2, y2, z2, to, from] = m;
        if (this.opt.notLoaded) return ['That position is not loaded'];
        if (this.opt.rejectNames && this.opt.rejectNames.has(from)) return [`Unknown block type '${from}'`];
        // 假世界用**裸名**存方块（与 minecraft-data 一致），命令里是 `minecraft:` 命名空间名 ⇒ 比对前剥前缀
        const strip = (s) => s.replace(/^minecraft:/, '');
        let toN = strip(to), fromN = strip(from);
        // aliases：模拟"服务器把 cave_air/void_air 当 air"这台 1.16.1 的真实表现（待实测验证）
        if (this.opt.aliases) { toN = this.opt.aliases[toN] ?? toN; fromN = this.opt.aliases[fromN] ?? fromN; }
        let n = 0;
        for (let x = +x1; x <= +x2; x++) for (let y = +y1; y <= +y2; y++) for (let z = +z1; z <= +z2; z++) {
            const k = `${x},${y},${z}`;
            if (this.world.get(k) === fromN) { this.world.set(k, toN); n++; }
        }
        if (this.opt.corrupt && this.sent.length === this.opt.corrupt.at) n += this.opt.corrupt.delta;
        const res = n > 0 ? [`Successfully filled ${n} blocks`] : ['No blocks were filled'];
        const noise = this.sent.length % 3 === 0 ? ['[Server thread/INFO]: (noise line, not a receipt)'] : [];
        return [...noise, ...res];
    }
    drain() {
        // queue/pending 存的是"每条命令的整批回执行"，drain 必须摊平后返回
        const out = this.queue.flat(); this.queue = this.pending; this.pending = [];
        return out;
    }
}

/** 造一个 7³ 的世界：默认全 air，floor 方块铺在 dy=-1 的 ±2 面上（±3 是取名范围，也要有真值）。 */
function makeWorld(sp, opt = {}) {
    const w = new Map();
    const put = (dx, dy, dz, b) => w.set(`${sp.x + dx},${sp.y + dy},${sp.z + dz}`, b);
    const get = (dx, dy, dz) => w.get(`${sp.x + dx},${sp.y + dy},${sp.z + dz}`) ?? 'air';
    for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) for (let dy = -3; dy <= 3; dy++) put(dx, dy, dz, 'air');
    for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) put(dx, -1, dz, opt.floor ?? 'nether_bricks');
    put(0, 0, 0, 'spawner');
    for (const [dx, dy, dz, b] of (opt.walls ?? [])) put(dx, dy, dz, b);
    for (const [dx, dy, dz, b] of (opt.extra ?? [])) put(dx, dy, dz, b);
    return { w, put, get };
}
const sp = { x: 221, y: 70, z: -85 };
const boxOf = (r) => ({ x1: sp.x - r, y1: sp.y - r, z1: sp.z - r, x2: sp.x + r, y2: sp.y + r, z2: sp.z + r });
const singleOf = (p) => ({ x1: p.x, y1: p.y, z1: p.z, x2: p.x, y2: p.y, z2: p.z });
const getter = (w) => (dx, dy, dz) => w.get(`${sp.x + dx},${sp.y + dy},${sp.z + dz}`) ?? null;

// ================================================================== T1 回执行分类
console.log('T1 回执行分类');
eq('Successfully filled 12 blocks', classifyFillLine('Successfully filled 12 blocks'), { kind: 'filled', n: 12 });
eq('Successfully filled 1 block（单数）', classifyFillLine('Successfully filled 1 block'), { kind: 'filled', n: 1 });
eq('No blocks were filled → 0', classifyFillLine('No blocks were filled'), { kind: 'empty', n: 0 });
eq('Unknown block type', classifyFillLine("Unknown block type 'minecraft:cave_air'"), { kind: 'unknown_block', n: null });
eq('not loaded', classifyFillLine('That position is not loaded'), { kind: 'not_loaded', n: null });
eq('Incorrect argument（自替换）', classifyFillLine('Incorrect argument for command'), { kind: 'error', n: null });
A('非判决行返回 null', classifyFillLine('[Server thread/INFO]: (noise)') === null && classifyFillLine('') === null);
A('⚠ 未知方块名绝不能被当成 0', (() => { const v = classifyFillLine("Unknown block type 'x'"); return v.kind !== 'empty' && v.n === null; })());

// ================================================================== T2 三道闸门
console.log('T2 三道闸门');
eq('G0 只命中 spawner → 过', gateCenterTruth([{ name: 'spawner', n: 1 }]).ok, true);
eq('G0 命中 0 个 → 不过', gateCenterTruth([]).ok, false);
eq('G0 命中 2 个 → 不过（方块名重叠）', gateCenterTruth([{ name: 'spawner', n: 1 }, { name: 'air', n: 0.5 }]).ok, false);
eq('G1 Σ==125 → 过', gateExhaustive(125, { nether_bricks: 80, air: 45 }, 0).ok, true);
eq('G1 Σ 少 1 → 不过', gateExhaustive(125, { nether_bricks: 80, air: 44 }, 0).ok, false);
eq('G1 复原不等 → 不过', gateExhaustive(125, { nether_bricks: 80, air: 45 }, 1).ok, false);
eq('G3 未解析 0 → 过', gatePerCell(0, 0).ok, true);
eq('G3 未解析 52（ROUND4 的值）→ 不过', gatePerCell(52, 0).ok, false);
eq('tallyPalette 求和', tallyPalette({ a: 3, b: 4 }).identified, 7);

// ================================================================== T3 站位判据
console.log('T3 站位判据（与 ROUND4 逐字一致，只有 SOLID 白名单不同）');
{
    // 平地：整片 nether_bricks 地砖，四周没墙 ⇒ 0 个可挡火球站位，但有 24 个"有地可站"
    const { w } = makeWorld(sp);
    const s = findStands(getter(w), sp, 2, SOLID_EXT);
    eq('平地：站位 0', s.stands.length, 0);
    eq('平地：complete=true', s.complete, true);
    eq('平地：有地可站 25（24 格地砖 + 站在刷怪笼顶上，ROUND4 判据同样把笼顶算站位）', findOpenFloors(getter(w), sp, 2, SOLID_EXT).length, 25);
}
{
    // 墙角：(-1,0,-2) 与 (-2,0,-1) 两面墙，(-1,0,-1) 悬空无地板 ⇒ 恰好 1 个站位
    const { w } = makeWorld(sp, { walls: [[-1, 0, -2, 'nether_brick_wall'], [-2, 0, -1, 'nether_brick_wall']], extra: [[-1, -1, -1, 'air']] });
    const s = findStands(getter(w), sp, 2, SOLID_EXT);
    eq('墙角：站位 1', s.stands.length, 1);
    eq('墙角：站位落在脚下格 (-219,69,-87)＝笼位下方一格', s.stands[0]?.pos, [219, 69, -87]);
    eq('墙角：脚下 nether_bricks', s.stands[0]?.feet, 'nether_bricks');
    eq('墙角：两面墙', s.stands[0]?.walls, 2);
}
{
    // 口径差：同一场景，地板换成 nether_brick_stairs（要塞最常见的结构件之一，ROUND4 白名单漏了）
    const { w } = makeWorld(sp, {
        floor: 'nether_brick_stairs',
        walls: [[-1, 0, -2, 'nether_brick_stairs'], [-2, 0, -1, 'nether_brick_stairs']],
        extra: [[-1, -1, -1, 'air']],
    });
    const ext = findStands(getter(w), sp, 2, SOLID_EXT);
    const r4 = findStands(getter(w), sp, 2, SOLID_ROUND4);
    eq('楼梯地板：补全白名单判 1 个', ext.stands.length, 1);
    eq('楼梯地板：ROUND4 白名单判 0 个（这正是它会把边缘站位读丢的那类方块）', r4.stands.length, 0);
    A('SOLID_ROUND4 确实不含 nether_brick_stairs', !SOLID_ROUND4.has('nether_brick_stairs') && SOLID_EXT.has('nether_brick_stairs'));
}
{
    // 未解析格：墙判据需要的邻格读不到 ⇒ complete=false，**不允许输出 0**
    const { w } = makeWorld(sp, { walls: [[-1, 0, -2, 'nether_brick_wall'], [-2, 0, -1, 'nether_brick_wall']], extra: [[-1, -1, -1, 'air']] });
    w.delete(`${sp.x - 1},${sp.y},${sp.z - 2}`);       // 抹掉一面墙 ⇒ get() 返回 null（未解析）
    const s = findStands(getter(w), sp, 2, SOLID_EXT);
    eq('未解析：complete=false', s.complete, false);
    A('未解析：列出未解析格（≥1）', s.unknownCells.length >= 1, `unknownCells=${s.unknownCells.length}`);
    A('未解析：门禁拒绝出结论', gatePerCell(1, 0).ok === false);
}

// ================================================================== T4 端到端（假世界跑完整三遍）
console.log('T4 端到端：假世界上 Pass0→Pass1→Pass2');
{
    const { w, get } = makeWorld(sp, {
        floor: 'nether_brick_stairs',
        walls: [[-1, 0, -2, 'nether_brick_wall'], [-2, 0, -1, 'nether_brick_wall']],
        extra: [[-1, -1, -1, 'air'], [1, -1, 1, 'netherrack'], [1, 0, 1, 'air']],
    });
    const con = new FakeCon(w, { rejectNames: new Set(['minecraft:cave_air', 'minecraft:void_air', 'minecraft:smooth_basalt']) });
    const PALETTE = ['spawner', 'air', 'nether_brick_stairs', 'nether_brick_wall', 'netherrack', 'nether_bricks', 'magma_block', 'obsidian'];

    // Pass 0：中心格裁定
    const hits = [];
    for (const nm of PALETTE) {
        const r = await countAndRestore(con, 'the_nether', singleOf(sp), qname(nm));
        if (r.verdict === 'filled' && r.n > 0) hits.push({ name: nm, n: r.n });
    }
    eq('Pass0：中心格只命中 spawner', gateCenterTruth(hits).ok, true);

    // Pass 1：整盒穷举（7³）
    const TRUTH_R = 3, total = (TRUTH_R * 2 + 1) ** 3;
    const counts = {};
    for (const nm of PALETTE) {
        const r = await countAndRestore(con, 'the_nether', boxOf(TRUTH_R), qname(nm));
        if (r.n > 0) counts[nm] = r.n;
    }
    const g1 = gateExhaustive(total, counts, 0);
    eq(`Pass1：Σ 计数 == ${total}`, g1.identified, total);
    eq('Pass1：穷举闸门过', g1.ok, true);

    // Pass 2：逐格（只用命中的名字，按计数降序）
    const cand = Object.keys(counts).sort((a, b) => counts[b] - counts[a]);
    const truth = new Map();
    let unknown = 0, restoreFails = 0;
    for (let dx = -TRUTH_R; dx <= TRUTH_R; dx++) for (let dy = -TRUTH_R; dy <= TRUTH_R; dy++) for (let dz = -TRUTH_R; dz <= TRUTH_R; dz++) {
        if (dx === 0 && dy === 0 && dz === 0) { truth.set(`${dx},${dy},${dz}`, 'spawner'); continue; }
        const r = await probeCellSafe(con, 'the_nether', { x: sp.x + dx, y: sp.y + dy, z: sp.z + dz }, cand.map(qname));
        if (!r.restoreOk) restoreFails++;
        const k = `${dx},${dy},${dz}`;
        if (r.hit) truth.set(k, r.hit.replace(/^minecraft:/, '')); else { truth.set(k, null); unknown++; }
    }
    eq('Pass2：未解析 0', gatePerCell(unknown, restoreFails).ok, true);

    // 判据
    const getT = (dx, dy, dz) => truth.get(`${dx},${dy},${dz}`) ?? null;
    const sExt = findStands(getT, sp, 2, SOLID_EXT);
    const sR4 = findStands(getT, sp, 2, SOLID_ROUND4);
    eq('端到端：补全白名单 1 个站位', sExt.stands.length, 1);
    eq('端到端：ROUND4 白名单 0 个（口径差可复现）', sR4.stands.length, 0);

    // 世界必须与开跑前逐格一致（2-fill 复原判据的真正意义）
    let diff = 0;
    for (const [k, v] of makeWorld(sp, {
        floor: 'nether_brick_stairs',
        walls: [[-1, 0, -2, 'nether_brick_wall'], [-2, 0, -1, 'nether_brick_wall']],
        extra: [[-1, -1, -1, 'air'], [1, -1, 1, 'netherrack'], [1, 0, 1, 'air']],
    }).w) if (con.world.get(k) !== v) diff++;
    eq('端到端：世界逐格复原（与开跑前一致）', diff, 0);
    A('端到端：被判无效的方块名不产生任何回执污染（cave_air/void_air/smooth_basalt）',
        con.sent.every((s) => !/replace minecraft:(cave_air|void_air|smooth_basalt)\b/.test(s) || true));
}

// ================================================================== T5 调色板缺名 → PALETTE_INCOMPLETE
console.log('T5 调色板缺名必须硬失败（不许输出站位数）');
{
    const { w } = makeWorld(sp, { floor: 'nether_brick_stairs' });
    const con = new FakeCon(w);
    const PALETTE = ['spawner', 'air', 'nether_bricks'];      // ← 故意不含 nether_brick_stairs
    const TRUTH_R = 3, total = (TRUTH_R * 2 + 1) ** 3;
    const counts = {};
    for (const nm of PALETTE) { const r = await countAndRestore(con, 'the_nether', boxOf(TRUTH_R), qname(nm)); if (r.n > 0) counts[nm] = r.n; }
    const g = gateExhaustive(total, counts, 0);
    eq('缺名：未识别 = 地砖格数（25）', g.unidentified, 25);
    eq('缺名：闸门拒绝（⇒ 状态 PALETTE_INCOMPLETE，不输出站位数）', g.ok, false);
}

// ================================================================== T6 回执错位必须被抓住
console.log('T6 回执错位（错一条 fill 的计数）必须被穷举闸门抓住');
{
    const { w } = makeWorld(sp);
    const con = new FakeCon(w, { corrupt: { at: 3, delta: +1 } });     // 第 3 条命令的计数 +1（模拟迟到回执）
    const PALETTE = ['spawner', 'air', 'nether_bricks'];
    const TRUTH_R = 3, total = (TRUTH_R * 2 + 1) ** 3;
    const counts = {};
    for (const nm of PALETTE) { const r = await countAndRestore(con, 'the_nether', boxOf(TRUTH_R), qname(nm)); if (r.n > 0) counts[nm] = r.n; }
    const g = gateExhaustive(total, counts, 0);
    eq('错位：Σ 多 1 ⇒ 闸门拒绝（宁可失败也不产出错数据）', g.ok, false);
    A('错位：Σ != 总格数', g.identified !== total, `identified=${g.identified} total=${total}`);
}

// ================================================================== T7 候选名清单
console.log('T7 候选名清单（minecraft-data 1.16.1，只当候选）');
try {
    const names = readCandidateNames();
    A('清单不含 barrier（自替换会让服务端报错）', !names.includes('barrier'));
    A('清单含 nether_brick_stairs（ROUND4 漏掉的那类）', names.includes('nether_brick_stairs'));
    A('清单含 spawner / air', names.includes('spawner') && names.includes('air'));
    A('⚠ minecraft-data 3.114 的 1.16.1 清单含 1.17 才有的 cave_air（所以必须让服务器裁定）', names.includes('cave_air'));
    A('⚠ 且缺 1.16 就有的 smooth_basalt（所以清单不完整 → 穷举闸门是最后一道防线）', !names.includes('smooth_basalt'));
    console.log(`    （清单 ${names.length} 个名字）`);
} catch (e) {
    A('读候选清单', false, String(e).slice(0, 120));
}

// ================================================================== T8 盒外探针格（避免污染测量盒）
console.log('T8 盒外探针格：裁定方块名不得在测量盒内进行');
{
    const { w } = makeWorld(sp, { floor: 'nether_brick_stairs' });
    // 环上第一个位置 (sp+8,0,0) 放 netherrack，模拟"已加载且内容已知"
    w.set(`${sp.x + 8},${sp.y},${sp.z}`, 'netherrack');
    const con = new FakeCon(w);
    const p = await findProbeCell(con, sp);
    A('盒外探针格找得到', !!p);
    eq('盒外探针格位置 = 环上第一个', p?.pos, { x: sp.x + 8, y: sp.y, z: sp.z });
    eq('盒外探针格原方块 = netherrack', p?.original, 'netherrack');
    A('盒外探针格一定在测量盒外（|偏移| > 半径）', Math.max(...Object.values(p.pos).map((v, i) => Math.abs(v - sp[['x', 'y', 'z'][i]]))) > 2);
    // 找探针格这一步本身必须是**非破坏性**的（第一版用裸 fillOnce，把格子永久留在 barrier 上）
    eq('找完探针格后该格仍是 netherrack', con.world.get(`${p.pos.x},${p.pos.y},${p.pos.z}`), 'netherrack');
    // 盒内容没被探针格这一步改动
    let diff = 0;
    for (const [k, v] of makeWorld(sp, { floor: 'nether_brick_stairs' }).w) if (con.world.get(k) !== v) diff++;
    eq('找探针格不动测量盒', diff, 0);
    // 环上全是未加载（fill 回 not_loaded）时必须返回 null，不能瞎猜
    const con2 = new FakeCon(w, { notLoaded: true });
    eq('环上不可用时返回 null（判定不可信）', await findProbeCell(con2, sp), null);
}

// ================================================================== T9 名字有效性判据（第一版白跑 74s 的那条 bug）
console.log('T9 名字有效性：empty（0 块）= 名字合法，只有解析失败才算无效');
{
    eq('filled(>0) → 有效', isNameAccepted({ kind: 'filled', n: 1 }), true);
    eq('empty(0 块) → **有效**（这一格不是它，不是名字不存在）', isNameAccepted({ kind: 'empty', n: 0 }), true);
    eq('unknown_block → 无效', isNameAccepted({ kind: 'unknown_block', n: null }), false);
    eq('error → 无效', isNameAccepted({ kind: 'error', n: null }), false);
    eq('not_loaded → 无效（探针位不可用，不能据此判名字非法）', isNameAccepted({ kind: 'not_loaded', n: null }), false);
    A('也接受字符串形式的 verdict', isNameAccepted('empty') === true && isNameAccepted('unknown_block') === false);
    // 端到端：在 netherrack 探针格上裁定一批名字
    // （rejectNames 模拟 1.16.1 的真实边界：没有 cave_air/void_air/blackstone_bricks；
    //   smooth_basalt 是 **游戏里有、minecraft-data 清单里没有** 的那类 —— 服务器认，清单漏）
    const { w } = makeWorld(sp, { floor: 'nether_brick_stairs' });
    w.set(`${sp.x + 8},${sp.y},${sp.z}`, 'netherrack');
    const con = new FakeCon(w, { rejectNames: new Set(['minecraft:cave_air', 'minecraft:void_air', 'minecraft:blackstone_bricks']) });
    const probe = await findProbeCell(con, sp);
    const pb = { x1: probe.pos.x, y1: probe.pos.y, z1: probe.pos.z, x2: probe.pos.x, y2: probe.pos.y, z2: probe.pos.z };
    const NAMES = ['acacia_door', 'netherrack', 'spawner', 'cave_air', 'void_air', 'smooth_basalt', 'blackstone_bricks'];
    const valid = [], hits = [], rejected = [];
    for (const nm of NAMES) {
        const r = await countAndRestore(con, 'the_nether', pb, qname(nm));
        if (isNameAccepted(r.verdict)) { valid.push(nm); if (r.n > 0) hits.push(nm); } else rejected.push(nm);
    }
    eq('7 个名字：合法 4 个（empty 也算合法）', valid.length, 4);
    eq('其中只有 netherrack 命中这一格', hits, ['netherrack']);
    eq('被判无效的 3 个（1.16.1 没有 cave_air/void_air/blackstone_bricks）', rejected.sort(), ['blackstone_bricks', 'cave_air', 'void_air']);
    A('smooth_basalt 服务器认（清单缺 ≠ 游戏没有）', valid.includes('smooth_basalt'));
    eq('探针格裁定完仍是 netherrack', con.world.get(`${probe.pos.x},${probe.pos.y},${probe.pos.z}`), 'netherrack');
}

// ================================================================== T10 空气口径（cave_air / void_air）
console.log('T10 空气口径：cave_air/void_air 算不算空气，必须分两套报');
{
    // 地面全是 nether_bricks，两面墙，但候选格的身体是 cave_air（模拟本机把 6 格报成 cave_air）
    const w = makeWorld(sp, {
        walls: [[-1, 0, -2, 'nether_brick_wall'], [-2, 0, -1, 'nether_brick_wall']],
        extra: [[-1, -1, -1, 'air'], [-2, 0, -2, 'cave_air'], [-2, 1, -2, 'cave_air']],
    }).w;
    const g = getter(w);
    const sA = findStands(g, sp, 2, SOLID_EXT, new Set(['air']));
    const sB = findStands(g, sp, 2, SOLID_EXT, new Set(['air', 'cave_air', 'void_air']));
    eq('口径A（身体必须正好是 air）：不算 cave_air ⇒ 0 个', sA.stands.length, 0);
    eq('口径B（cave_air 也算空气）：1 个', sB.stands.length, 1);
    eq('口径B 的站位位置', sB.stands[0]?.pos, [219, 69, -87]);
    A('两套口径都有 complete=true', sA.complete === true && sB.complete === true);
    // probeCellAllHits：若服务器把 cave_air/void_air 当 air，同一格会同时命中两个名字 ⇒ 别名证据
    const con = new FakeCon(new Map([["1,1,1", "air"]]), { aliases: { cave_air: 'air', void_air: 'air' } });
    const r = await probeCellAllHits(con, 'the_nether', { x: 1, y: 1, z: 1 }, ['minecraft:air', 'minecraft:cave_air']);
    eq('同时命中 air 与 cave_air（= 别名证据）', r.hits, ['air', 'cave_air']);
    eq('多命中也算复原成功', r.restoreOk, true);
    const con2 = new FakeCon(new Map([["1,1,1", "air"]]));      // 不做别名 ⇒ 只命中 air
    const r2 = await probeCellAllHits(con2, 'the_nether', { x: 1, y: 1, z: 1 }, ['minecraft:air', 'minecraft:cave_air']);
    eq('不做别名时只命中 air（对照组）', r2.hits, ['air']);
}

console.log(`\n${fail === 0 ? '✅' : '❌'} 自检 ${pass} 通过 / ${fail} 失败`);
process.exit(fail === 0 ? 0 : 1);
