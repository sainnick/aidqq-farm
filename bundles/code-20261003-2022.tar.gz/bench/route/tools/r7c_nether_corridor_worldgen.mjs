// r7c_nether_corridor_worldgen.mjs — ROUND7-C 续单（低优先项 5）：下界**路线走廊**存档
//
// 【为什么必须新生成】路线三段都在下界，而盘上**没有任何一份存档**覆盖到那条走廊：
//   `_world_A` 下界只到 x112..431 / z-192..367（cx7..26 / cz-12..22），
//   而 S1 门对应的下界落点 ≈ x23、S3 堡垒 x42、C3 要塞 x28 —— **全在 x<112，一格都没覆盖**。
//   ⇒ 直线距离可以纯算，**可走路径必须先有地形**，本文件只负责把这一小片生成出来。
//
// 【只发三类命令】`difficulty easy` / `forceload add` / `save-all flush`。
//   **不发 fill / summon / setblock** —— 除就绪探针那 1 格 barrier（落盘时如实标注）。
//
// 【窗口】cx 0..7 / cz -5..7 = 8×13 = **104 区块**（单批 ≤128，手册 §5）⇒ 块 x 0..127 / z -80..127。
//   路线三点的余量：S1(23,38) 最近边 23 格、S3(42,32) 42 格、C3(28,-11) 11 格。

import fs from 'fs';
import path from 'path';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR } from './console.mjs';

const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const DIFFICULTY = argOf(process.argv, 'difficulty', 'easy');
const CX0 = 0, CX1 = 7, CZ0 = -5, CZ1 = 7;
const RUN_DIR = path.join(ROUTE_DIR, 'probe', '_run_round7c_corridor');
const OUT = path.join(ROUTE_DIR, 'probe', 'worldgen_nether_corridor.json');
const DEST = path.join(ROUTE_DIR, 'probe', '_nether_corridor');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function cmdOnce(con, cmd, re, timeoutMs = 60000) {
    con.drain();
    con.cmd(cmd);
    const t0 = Date.now();
    const seen = [];
    for (;;) {
        for (const line of con.drain()) { seen.push(line); if (re.test(line)) return line; }
        if (Date.now() - t0 > timeoutMs) throw new Error(`CMD_NO_RECEIPT: ${cmd}（${seen.slice(-2).join(' | ').slice(0, 200)}）`);
        await sleep(50);
    }
}

const bx0 = CX0 * 16, bx1 = (CX1 + 1) * 16 - 1, bz0 = CZ0 * 16, bz1 = (CZ1 + 1) * 16 - 1;
const expected = (CX1 - CX0 + 1) * (CZ1 - CZ0 + 1);

const out = {
    schema: 'aidqq-round7c-nether-corridor/1', seed: SEED, mcVersion: '1.16.1', lane: 'C',
    startedAt: new Date().toISOString(), status: 'NOT_RUN',
    purpose: '低优先项 5：量 S1门→S3堡垒→C3要塞→回门 的**可走路径**长度（直线距离不需要存档）',
    window: { chunks: { cx: [CX0, CX1], cz: [CZ0, CZ1] }, blocks: { x: [bx0, bx1], z: [bz0, bz1] }, expectedChunks: expected },
    commandsIssued: [], difficultyReceipt: null, probeBarrierCells: [], savedAt: null,
};

let h = null;
try {
    out.status = 'RUNNING';
    log(`=== ROUND7-C 下界走廊世界生成（difficulty=${DIFFICULTY}，${expected} 区块）===`);
    h = await bootLaneC({ seed: SEED, runDir: RUN_DIR, logFn: log });
    const con = h.con;
    const sp = fs.readFileSync(path.join(h.lane.dir, 'server.properties'), 'utf8');
    const levelName = (/level-name=(.*)/.exec(sp)?.[1] ?? 'world').trim();
    out.worldDir = path.join(h.lane.dir, levelName);
    out.bootMs = h.server.bootMs;

    out.difficultyReceipt = await cmdOnce(con, `difficulty ${DIFFICULTY}`, /difficulty/i, 20000);
    out.commandsIssued.push(`difficulty ${DIFFICULTY}`);
    log(`  ${out.difficultyReceipt.trim()}`);

    const marked = await cmdOnce(con, `execute in minecraft:the_nether run forceload add ${bx0} ${bz0} ${bx1} ${bz1}`,
        /Marked \d+ chunks?|Too many chunks|force loaded/i, 60000);
    if (/Too many chunks/i.test(marked)) throw new Error(`FORCELOAD_OVER_256：${marked}`);
    if (/minecraft:overworld/i.test(marked)) throw new Error(`FORCELOAD_WRONG_DIM：${marked}`);
    out.commandsIssued.push(`forceload add ${bx0} ${bz0} ${bx1} ${bz1}`);
    out.forceloadReceipt = marked;
    log(`  ${marked}`);

    // 权威就绪闸门：轮询 fill 探针直到不再 "not loaded"（1 格 barrier，如实标注）
    let probe = '', attempt = 0;
    for (attempt = 1; attempt <= 30; attempt++) {
        probe = await cmdOnce(con,
            `execute in minecraft:the_nether run fill ${bx0} 70 ${bz0} ${bx0} 70 ${bz0} minecraft:barrier replace minecraft:netherrack`,
            /Successfully filled|No blocks were filled|not loaded/i, 60000);
        if (!/not loaded/i.test(probe)) break;
        log(`    第 ${attempt} 次探针仍 not loaded`);
        await sleep(3000);
    }
    if (/not loaded/i.test(probe)) throw new Error('CHUNK_GATE_NOT_LOADED');
    out.readyProbe = probe;
    out.probeAttempts = attempt;
    // ⚠ 只有探针**真的替换掉一块**才算污染。"No blocks were filled" = 目标格本来就不是 netherrack
    //   （多半是空气）⇒ **一格都没改**，存档是干净的。别把探针格无条件记成"我下的 barrier"。
    if (/Successfully filled/i.test(probe)) out.probeBarrierCells.push([bx0, 70, bz0]);
    else out.probeNoOp = `探针格 (${bx0},70,${bz0}) 本身不是 netherrack，回执 "No blocks were filled" ⇒ 未改动任何方块`;
    log(`  就绪（第 ${attempt} 次）：${probe}`);
    if (!out.probeBarrierCells.length) log(`  ⇒ 探针是空操作，存档未被本单污染`);

    const saveLine = await cmdOnce(con, 'save-all flush', /Saved the game|Flushing|Saved/i, 300000);
    out.commandsIssued.push('save-all flush');
    out.saveLine = saveLine;
    log(`  ${saveLine}`);
    await sleep(4000);
    await shutdownLaneC(h); h = null;
    out.status = 'SAVED';
    out.savedAt = new Date().toISOString();

    fs.rmSync(DEST, { recursive: true, force: true });
    fs.mkdirSync(DEST, { recursive: true });
    for (const item of ['DIM-1', 'DIM1', 'region', 'level.dat', 'level.dat_old']) {
        const src = path.join(out.worldDir, item);
        if (fs.existsSync(src)) fs.cpSync(src, path.join(DEST, item), { recursive: true });
    }
    out.copiedTo = DEST;

    let saved = 0;
    for (let cx = CX0; cx <= CX1; cx++) for (let cz = CZ0; cz <= CZ1; cz++) {
        const rx = cx >> 5, rz = cz >> 5, idx = (cx - rx * 32) + (cz - rz * 32) * 32;
        const f = path.join(DEST, 'DIM-1', 'region', `r.${rx}.${rz}.mca`);
        if (!fs.existsSync(f)) continue;
        const b = fs.readFileSync(f);
        if (b.length < 8192 + 4) continue;
        if (((b.readUInt8(idx * 4) << 16) | (b.readUInt8(idx * 4 + 1) << 8) | b.readUInt8(idx * 4 + 2)) > 0) saved++;
    }
    out.savedChunksInWindow = saved;
    out.coverageOK = saved === expected;
    if (!out.coverageOK) out.status = 'SAVED_INCOMPLETE';
    log(`  收尾硬闸：${saved}/${expected} ⇒ ${out.coverageOK ? 'OK' : '✗ 覆盖不全'}`);
} catch (e) {
    out.error = String(e && e.stack ? e.stack : e);
    if (out.status === 'RUNNING') out.status = 'FAILED';
    log(`✗ ${out.status}：${String(e).split('\n')[0]}`);
} finally {
    try { if (h) await shutdownLaneC(h); } catch { /* ignore */ }
    out.seconds = Math.round((Date.now() - Date.parse(out.startedAt)) / 1000);
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
    log(`落盘：${path.relative(process.cwd(), OUT)}（status=${out.status}，${out.seconds}s）`);
}
