// inject_starts.mjs — MC-ROUTE-02 收尾 **P2** 第 1 步：把 SEED-03 的 cubiomes 结构起点注入 probe
//
// 病因（ROUTE-02 §4.7）：备选种子 1 上 `/locate buried_treasure` / `/locate fortress` /
//   `/locate bastion_remnant` 把服务器拖过 60s 看门狗、自判崩溃 → probe 里这三个起点是
//   `{timeout:true}` / `{failed:true}` → 依赖它们的类目全被判 `start_not_found` →
//   `S3_bastion` / `S4_fortress_spawner` 两站 UNVERIFIED。
//
// 派单 P2 要求的替代路径：**离线 cubiomes 坐标 + 小范围 fill-replace 核验**替代 `/locate`。
// 本脚本只做"前半句"——把离线坐标写进 probe（并留审计痕迹 + 备份）；
// 后半句（服务器权威下钻）由 `gen_route.mjs --only <类目>` 正常跑，不用本脚本操心。
//
// 坐标来源：experiments/seed-scout/s3_results/s3_truth_table.csv 的 **A 通道（cubiomes）**，
//   该表的 REAL 判定是 SEED-03 R3 用 fill-replace 在服务器上核过的（例如
//   backup1 的 bastion_remnant evidence=`r48|bastion_bricks:9212`、fortress=`r48|nether_bricks:26390`）。
//   注入时再用 `cubiomes_struct.mjs`（本单移植，已过 9/9 真值闸门）**独立复算一次**做交叉核对，
//   两者不一致就拒绝注入。
//
// ⚠ 幂等：已注入过的 key 会跳过（除非 --force），避免重复运行把审计痕迹冲掉。
//
// 用法（Node 20）：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\inject_starts.mjs --seed -6850455172235562789 --structure bastion_remnant --structure fortress --structure buried_treasure

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { argOf } from '../../stages/_lib/runner_core.mjs';
import { CONFIGS, candidates, nearest, floordiv, U64 } from './cubiomes_struct.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE_DIR = path.join(HERE, '..');
const ROOT = path.join(ROUTE_DIR, '..', '..');
const CSV = path.join(ROOT, 'experiments', 'seed-scout', 's3_results', 's3_truth_table.csv');
const TOP_CSV = path.join(ROOT, 'experiments', 'seed-scout', 'top_ranked.csv');

const SEED = argOf(process.argv, 'seed', '-6850455172235562789');
const FORCE = process.argv.includes('--force');
/**
 * 免交叉核对开关（**必须显式给**，且会进审计痕迹）。
 * 只给"移植口径本来就没实现、但权威来源是 SEED-03 的服务器核验"的结构用——
 * 目前只有 buried_treasure（本移植没实现 cubiomes 的 Monument 邻域过滤，
 * 所以复算出的"最近宝藏"必然与 A 通道不同；坐标本身由 SEED-03 R3 用 fill-replace 核过 REAL）。
 */
const ALLOW_UNCROSSCHECKED = process.argv.includes('--allow-uncrosschecked');
const WANT = (() => {
    const out = [];
    const a = process.argv;
    for (let i = 0; i < a.length; i++) if (a[i] === '--structure') out.push(a[i + 1]);
    return out.length ? out : ['bastion_remnant', 'fortress'];
})();

/** probe 里的 key → cubiomes 结构类型（用于独立复算交叉核对）。null = 本移植不覆盖，跳过核对。 */
const PORT_TYPE = {
    ruined_portal: 'Ruined_Portal',
    fortress: 'Fortress',
    bastion_remnant: 'Bastion',
    buried_treasure: 'Treasure',   // 参考项（未移植 Monument 过滤），只记录不作为否决
};

/** 与 scan.c 相同的搜索口径：主世界结构以出生点为参考、半径 768；下界结构以 spawn÷8 为参考、半径 320 */
function portCrossCheck(structure, seed, sp) {
    const type = PORT_TYPE[structure];
    if (!type) return { ok: true, note: '本移植不覆盖该类型，跳过交叉核对' };
    const ref = (type === 'Fortress' || type === 'Bastion')
        ? { x: floordiv(sp.x, 8), z: floordiv(sp.z, 8) }
        : sp;
    const range = (type === 'Fortress' || type === 'Bastion') ? 320 : 768;

    if (type === 'Bastion') {
        // 群系门槛本移植没实现 → 只断言"SEED-03 的真值在最近 96 个候选里"
        const cands = candidates('Bastion', seed, ref.x, ref.z, range).sort((a, b) => a.d2 - b.d2).slice(0, 96);
        return { exact: false, cands, note: `参考点(${ref.x},${ref.z}) 最近 96 候选（群系门槛未移植，只作参考）` };
    }
    const n = nearest(type, seed, ref.x, ref.z, range, 96);
    return {
        exact: true, got: n ? { x: n.x, z: n.z } : null,
        note: `参考点(${ref.x},${ref.z}) 最近值=${n ? `${n.x},${n.z}` : 'NONE'}`,
    };
}

/** SEED-01 A 级表里的出生点（cubiomes getSpawn 口径） */
function readSpawn(seedStr) {
    const lines = fs.readFileSync(TOP_CSV, 'utf8').split(/\r?\n/).filter((l) => l.trim());
    const head = lines[0].split(',');
    for (const line of lines.slice(1)) {
        const f = line.split(',');
        if (f.length < head.length) continue;
        const row = Object.fromEntries(head.map((h, i) => [h, f[i]]));
        if (row.seed === String(seedStr)) return { x: +row.spawn_x, z: +row.spawn_z };
    }
    throw new Error(`SEED-01 表里没有种子 ${seedStr} 的出生点`);
}

let TABLE = null;
function readScoutTable() {
    if (TABLE) return TABLE;
    const lines = fs.readFileSync(CSV, 'utf8').split(/\r?\n/).filter((l) => l.trim());
    TABLE = lines.slice(1).map((line) => {
        const f = line.split(',');
        // ⚠ evidence 列含未转义逗号（`r48|crying_obsidian:1,obsidian:9`），只取前 9 列是安全的
        const [seed, structure, aX, aZ, bX, bZ, aReal, bReal, verdict] = f;
        return { seed: (seed ?? '').trim(), structure, aX, aZ, bX, bZ, aReal, bReal, verdict, evidence: f.slice(9).join(',') };
    });
    return TABLE;
}

const rows = readScoutTable().filter((r) => r.seed === String(SEED));
if (!rows.length) throw new Error(`SEED-03 表里没有种子 ${SEED}`);
const byStruct = new Map(rows.map((r) => [r.structure, r]));
const seed = BigInt(SEED) & U64;
const spawn = readSpawn(SEED);

const PROBE = path.join(ROUTE_DIR, 'probe', `${SEED}.probe.json`);
const probe = JSON.parse(fs.readFileSync(PROBE, 'utf8'));

// ---- 备份（只备份一次，不覆盖已有的 pre-inject 快照） ----
const BAK = path.join(ROUTE_DIR, 'probe', '_old', `${SEED}.probe.pre-inject.json`);
if (!fs.existsSync(BAK)) {
    fs.mkdirSync(path.dirname(BAK), { recursive: true });
    fs.writeFileSync(BAK, fs.readFileSync(PROBE, 'utf8'));
    console.log(`已备份原 probe → ${path.relative(ROOT, BAK)}`);
}

const audit = [];
probe.structuresInjected = probe.structuresInjected ?? {};

for (const key of WANT) {
    const r = byStruct.get(key);
    if (!r) { console.log(`✗ ${key}: SEED-03 表里没有这一项`); process.exitCode = 1; continue; }
    if (!['BOTH_REAL', 'A_ONLY', 'B_ONLY'].includes(r.verdict) || r.aReal !== 'REAL') {
        console.log(`✗ ${key}: verdict=${r.verdict} aReal=${r.aReal} —— 不是已核验的 cubiomes 真值，拒绝注入`);
        process.exitCode = 1;
        continue;
    }
    if (probe.structuresInjected[key] && !FORCE) {
        console.log(`· ${key}: 已注入过，跳过（--force 可重注）`);
        continue;
    }
    const x = +r.aX, z = +r.aZ;
    const cc = portCrossCheck(key, seed, spawn);
    let uncrosschecked = null;
    if (cc.exact) {
        // 精确型（Fortress / Ruined_Portal / Treasure）：移植复算的最近值必须逐坐标等于要注入的值
        const eq = cc.got && cc.got.x === x && cc.got.z === z;
        if (!eq) {
            if (!ALLOW_UNCROSSCHECKED) {
                console.log(`✗ ${key}: 移植复算得 ${cc.got ? `${cc.got.x},${cc.got.z}` : 'NONE'}，`
                    + `SEED-03 表是 (${x},${z}) —— 不一致，拒绝注入`
                    + `（确系移植口径缺失可加 --allow-uncrosschecked，但会在审计里留痕）`);
                process.exitCode = 1;
                continue;
            }
            uncrosschecked = `移植复算得 ${cc.got ? `${cc.got.x},${cc.got.z}` : 'NONE'}（口径差异，未交叉核对）`;
        }
    } else if (cc.cands) {
        // 成员型（Bastion：群系门槛没移植）：SEED-03 的真值必须在最近 96 个候选里
        const hit = cc.cands.some((c) => c.x === x && c.z === z);
        if (!hit) {
            console.log(`✗ ${key}: SEED-03 的 (${x},${z}) 不在移植的最近 96 候选里，拒绝注入`);
            process.exitCode = 1;
            continue;
        }
    }

    probe.structures[key] = {
        x, y: null, z,
        source: 'cubiomes(R3表)',
        fallbackFrom: 'locate_failed_1.16.1_tick_timeout',
        cubiomesConfig: { ...CONFIGS[PORT_TYPE[key]], salt: CONFIGS[PORT_TYPE[key]].salt.toString() },
        serverVerifiedBy: 'SEED-03 R3 (fill-replace)',
        evidence: `experiments/seed-scout/s3_results/s3_truth_table.csv#${key}｜${r.evidence}`,
        portCrossCheck: cc.note,
        ...(uncrosschecked ? { uncrosscheckedReason: uncrosschecked } : {}),
        injectedAt: new Date().toISOString(),
    };
    audit.push(`${key}=(${x},${z}) src=cubiomes(R3表) verdict=${r.verdict} portXcheck=${cc.note}${uncrosschecked ? ' ⚠UNCROSSCHECKED' : ''}`);
    console.log(`✓ ${key} → (${x}, ${z})  [${r.verdict}, ${r.evidence.slice(0, 60)}]  移植交叉核对：${cc.note}`);
}

if (audit.length) {
    probe.method.starts = probe.method.starts + ' ｜部分起点改由 SEED-03 cubiomes 表注入（1.16.1 的 /locate 下界/稀有地物会拖崩服务器）';
    probe.structuresInjected.at = new Date().toISOString();
    probe.structuresInjected.entries = audit;
    fs.writeFileSync(PROBE, JSON.stringify(probe, null, 2));
    console.log(`\n已写回 ${path.relative(ROOT, PROBE)}（注入 ${audit.length} 项）`);
    const usable = Object.values(probe.structures).filter((v) => Number.isFinite(v?.x)).length;
    console.log(`可用起点：${usable}/7 —— ${usable >= 7 ? 'gen_route 会跳过 /locate 阶段' : '仍不足 7，gen_route 会再跑 /locate'}`);
} else {
    console.log('\n没有注入任何起点（全部跳过或被拒）');
}
