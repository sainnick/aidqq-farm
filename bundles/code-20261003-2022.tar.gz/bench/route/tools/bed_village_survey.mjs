// bed_village_survey.mjs — R6-4：出生点 ±384 格内的**村庄床普查** + **扩大范围找羊**
//
// 【只读解析为主】控制台只负责 forceload 与 save-all（见 worldgen_for_region.mjs）；
//   本文件**不碰服务器**，只解析存档。
//
// 【为什么关心床】床是 E 线屠龙的前置（末影龙要 4 张床做末影之眼），S2 之前必须解决。
//   已知线索：出生点附近有 11 个村民 ⇒ 附近有村庄；村庄的 shepherd 屋与农舍里有床。
//
// 【"是否需要挖墙"怎么判 —— 先说清这是代理判据，不是寻路】
//   1.16.1 的羊**不会跳上方块**，所以"楼上的床"羊根本够不着 —— 这比"要不要挖墙"更致命。
//   本文件对每张床判三件事：
//     · `floorBelow`  床正下方一格是否实心（= 床在地板上，不是悬空）
//     · `headroom`   床上方 2 格是否空（= 站得下）
//     · `openSides`  床的 4 个水平邻格里，有几个同时满足"脚下实心 + 身体两格空"
//                    （= 羊能站上去的位置有多少；0 ⇒ 四周被墙堵死，羊进不去 ⇒ **需要挖墙**）
//   这不是完整路径规划（没算门、没算从村外怎么走），但足以把"完全够不着"和"够得着"分开。
//
// 【内存】±384 格 = 48×48 = 2304 区块，每 chunk 的方块索引 98304 项（196KB）⇒ 全缓存约 500MB。
//   Node 堆上限只有 2GB，所以**分块解析 + 及时清缓存**。

import fs from 'fs';
import path from 'path';
import { argOf, log } from '../../stages/_lib/runner_core.mjs';
import { openWorld, bare } from './region_reader.mjs';
import { ROUTE_DIR } from './console.mjs';

const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const WORLD = argOf(process.argv, 'world', path.join(PROBE_DIR, '_bedhunt'));
const OUT = path.join(PROBE_DIR, 'bed_village_survey.round6c.json');
const SPAWN = { x: 216, z: 224 };
const S1 = { x: 176, z: 304 };
const R = 384;                                   // 普查半径（格）
const CLUSTER = 64;                              // 村庄聚类阈值（格）
const BLOCK_PER_CHUNK = 4 * 16 * 16;              // 16×16×16

/** 1.16.1 的 16 种床 + 畜栏建材 + 箱子 */
const BED_NAMES = ['white_bed', 'orange_bed', 'magenta_bed', 'light_blue_bed', 'yellow_bed', 'lime_bed',
    'pink_bed', 'gray_bed', 'light_gray_bed', 'cyan_bed', 'purple_bed', 'blue_bed', 'brown_bed', 'green_bed', 'red_bed', 'black_bed'];
const SUPPLY = ['hay_block', 'chest', 'trapped_chest'];

const SOLID_HINT = new Set(['stone', 'cobblestone', 'oak_planks', 'spruce_planks', 'dark_oak_planks', 'oak_log',
    'hay_block', 'dirt', 'grass_block', 'stone_bricks', 'mossy_cobblestone', 'oak_stairs', 'cobblestone_stairs',
    'torch', 'ladder', 'fence', 'oak_fence', 'glass', 'glass_pane', 'iron_bars']);
const AIRISH = new Set(['air', 'cave_air', 'short_grass', 'tall_grass', 'grass', 'dead_bush', 'torch', 'flower', 'dandelion', 'poppy']);
const isSolid = (n) => !AIRISH.has(n) && n !== 'unknown';

const out = { schema: 'aidqq-round6c-bed-survey/1', at: new Date().toISOString(), world: WORLD, spawn: SPAWN, s1: S1, radius: R, clusterThreshold: CLUSTER };

// ---------------------------------------------------------------- 逐 chunk 扫（省内存）
const w = openWorld(WORLD, { unpackMode: 'packed' });
const beds = [];
const supply = { hay_block: 0, chest: 0, trapped_chest: 0 };
let chunksScanned = 0, yMin = 999, yMax = -999;
const c0x = Math.floor((SPAWN.x - R) / 16), c1x = Math.floor((SPAWN.x + R) / 16);
const c0z = Math.floor((SPAWN.z - R) / 16), c1z = Math.floor((SPAWN.z + R) / 16);
log(`扫描区块 x${c0x}..${c1x} z${c0z}..${c1z}（${(c1x - c0x + 1) * (c1z - c0z + 1)} 个）`);

for (let cx = c0x; cx <= c1x; cx++) {
    for (let cz = c0z; cz <= c1z; cz++) {
        const c = w.chunk(cx, cz);
        if (!c) continue;
        chunksScanned++;
        for (let i = 0; i < c.filled.length; i++) {
            if (!c.filled[i]) continue;
            const name = c.palette[c.idx[i]];
            const y = Math.floor(i / 256), z = Math.floor((i % 256) / 16), x = i % 16;
            if (name.endsWith('_bed') && BED_NAMES.includes(name)) {
                beds.push({ x: cx * 16 + x, y, z: cz * 16 + z, name });
                if (y < yMin) yMin = y;
                if (y > yMax) yMax = y;
            } else if (SUPPLY.includes(name)) {
                supply[name] = (supply[name] ?? 0) + 1;
            }
        }
    }
    // 逐行清缓存，控制峰值内存
    if ((cx - c0x) % 8 === 7) { w.chunkCache.clear(); w.regionCache.clear(); }
}
w.chunkCache.clear();
out.chunksScanned = chunksScanned;
out.beds = beds;
out.bedYRange = [yMin === 999 ? null : yMin, yMax === -999 ? null : yMax];
out.supply = supply;
log(`扫到床 ${beds.length} 张（y ${out.bedYRange[0]}..${out.bedYRange[1]}）｜干草 ${supply.hay_block} 箱 ${supply.chest}/${supply.trapped_chest}`);

// ---------------------------------------------------------------- 村庄聚类（贪心：到簇心 ≤ CLUSTER 算同一村）
const clusters = [];
const d2 = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);
for (const b of beds.sort((p, q) => p.x - q.x || p.z - q.z)) {
    let hit = null;
    for (const c of clusters) { if (d2(b.x, b.z, c.cx, c.cz) <= CLUSTER) { hit = c; break; } }
    if (!hit) { clusters.push({ cx: b.x, cz: b.z, beds: [b] }); hit = clusters[clusters.length - 1]; }
    else {
        hit.beds.push(b);
        // 簇心用中位数式更新，避免被单个离群点拉走
        const n = hit.beds.length;
        hit.cx = Math.round(hit.beds.reduce((s, x) => s + x.x, 0) / n);
        hit.cz = Math.round(hit.beds.reduce((s, x) => s + x.z, 0) / n);
    }
}

// ---------------------------------------------------------------- 每村的可达性判据（代理）
const w2 = openWorld(WORLD, { unpackMode: 'packed' });
function bedReach(b) {
    const below = w2.blockAt(b.x, b.y - 1, b.z);
    const above1 = w2.blockAt(b.x, b.y + 1, b.z);
    const above2 = w2.blockAt(b.x, b.y + 2, b.z);
    const sides = [[1, 0], [-1, 0], [0, 1], [0, -1]].map(([dx, dz]) => {
        const sx = b.x + dx, sz = b.z + dz;
        const foot = w2.blockAt(sx, b.y, sz);
        const body = w2.blockAt(sx, b.y + 1, sz);
        const head = w2.blockAt(sx, b.y + 2, sz);
        return { pos: [sx, b.y, sz], standable: isSolid(foot) && AIRISH.has(body) && AIRISH.has(head), block: foot };
    });
    return {
        floorBelow: isSolid(below), below,
        headroom: AIRISH.has(above1) && AIRISH.has(above2),
        openSides: sides.filter((s) => s.standable).length,
        sides: sides.map((s) => `${s.block}${s.standable ? '✓' : '✗'}`),
    };
}
out.villages = clusters.map((c) => {
    const reach = c.beds.map(bedReach);
    const ys = c.beds.map((b) => b.y);
    const reachable = reach.filter((r) => r.floorBelow && r.headroom && r.openSides > 0).length;
    return {
        center: [c.cx, c.cz],
        bedCount: c.beds.length,
        bedColors: Object.fromEntries(c.beds.reduce((m, b) => m.set(b.name, (m.get(b.name) ?? 0) + 1), new Map())),
        yRange: [Math.min(...ys), Math.max(...ys)],
        yLayers: Object.fromEntries([...new Set(ys.map((y) => Math.floor(y / 16)))].sort((a, b) => a - b).map((L) => [L, ys.filter((y) => Math.floor(y / 16) === L).length])),
        distToSpawn: Math.round(d2(c.cx, c.cz, SPAWN.x, SPAWN.z)),
        distToS1: Math.round(d2(c.cx, c.cz, S1.x, S1.z)),
        reachableBeds: reachable,
        needsDig: reachable === 0,
        bedsDetail: c.beds.map((b, i) => ({ pos: [b.x, b.y, b.z], name: b.name, ...reach[i] })),
    };
}).sort((a, b) => a.distToSpawn - b.distToSpawn);
w2.chunkCache.clear();

// ---------------------------------------------------------------- 羊（扩大范围）
const w3 = openWorld(WORLD, { unpackMode: 'packed' });
const allSheep = w3.entitiesInBox({ x1: SPAWN.x - R, y1: 0, z1: SPAWN.z - R, x2: SPAWN.x + R, y2: 255, z2: SPAWN.z + R }, ['sheep'], 'overworld');
w3.chunkCache.clear();
// 聚群（羊是成群的：同群距离通常 <16 格）
const flocks = [];
for (const s of allSheep) {
    let hit = null;
    for (const f of flocks) { if (d2(s.pos[0], s.pos[2], f.cx, f.cz) <= 24) { hit = f; break; } }
    if (!hit) { flocks.push({ cx: s.pos[0], cz: s.pos[2], members: [s] }); }
    else { hit.members.push(s); hit.cx = Math.round(hit.members.reduce((a, m) => a + m.pos[0], 0) / hit.members.length); hit.cz = Math.round(hit.members.reduce((a, m) => a + m.pos[2], 0) / hit.members.length); }
}
out.sheep = {
    total: allSheep.length,
    flocks: flocks.map((f) => ({
        center: [f.cx, f.cz], size: f.members.length,
        distToSpawn: Math.round(d2(f.cx, f.cz, SPAWN.x, SPAWN.z)),
        distToS1: Math.round(d2(f.cx, f.cz, S1.x, S1.z)),
        members: f.members.map((m) => m.pos),
    })).sort((a, b) => a.distToSpawn - b.distToSpawn),
    note: `±${R} 格（${(c1x - c0x + 1) * (c1z - c0z + 1)} 区块）内的全部羊`,
};

fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
log(`村庄簇：${out.villages.length} 个｜床 ${beds.length} 张｜羊 ${out.sheep.total} 只（${out.sheep.flocks.length} 群）`);
for (const v of out.villages.slice(0, 8)) {
    log(`  村 @(${v.center}) 床 ${v.bedCount}（可达 ${v.reachableBeds}，需挖墙 ${v.needsDig ? '是' : '否'}）y${v.yRange[0]}..${v.yRange[1]} 到出生点 ${v.distToSpawn} / 到 S1 ${v.distToS1}`);
}
for (const f of out.sheep.flocks.slice(0, 5)) log(`  羊群 @(${f.center}) ${f.size} 只，到出生点 ${f.distToSpawn} / 到 S1 ${f.distToS1}`);
log(`落盘：${path.relative(process.cwd(), OUT)}`);
