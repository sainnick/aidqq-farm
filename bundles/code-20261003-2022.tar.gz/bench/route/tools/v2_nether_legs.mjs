// v2_nether_legs.mjs — ROUND8-C：把 round7c 存下的**步数**补成**逐格路径**，供 route schema `aidqq-route/2` 的 `legs[]` 用
//
// 【为什么有这一单】`probe/nether_route_distance.round7c.json` 量出了下界三段的可走步数
//   （25 / 69 / 58，合计 152），但**只存了步数没存路径**。v2 的 `legs[].waypoints` 需要**真实坐标**，
//   而 SCHEMA §5 硬要求「相邻路点 ≤ 32 格」+ 「每个坐标都要有存档解析证据」⇒ 必须离线把路径重算出来。
//
// 【口径：逐字复用 round7c，不重新发明】
//   判据、移动集、站位解析（nearestStandable 的并列打破）全部照抄 `r7c_nether_route_distance.mjs`：
//     - AIRLIKE = {air, cave_air, void_air}；HAZARD = {lava, magma_block, fire, soul_fire}
//     - standable(y) = y≥1 ∧ y+1≤y2 ∧ solidGround(y-1) ∧ air(y) ∧ air(y+1)
//     - solidGround  = 非 unknown ∧ 非 AIRLIKE ∧ 非 HAZARD（**不站在液体上**）
//     - 邻接表 = 水平 4 向，每向 {Δy=0, Δy=+1, Δy=-1..-20}（MAX_DROP=20，**不含斜向**）
//     - 每步代价 1 ⇒ 步数是 BFS 最短距离，**与并列打破无关**（只有"同长路径里选哪条"依赖遍历序）
//   走廊盒沿用 `worldgen_nether_corridor.json` 的窗口，存档**只读**。
//
// 【阳性对照（手册 §4 第 11 条）】路径是"从存档真值里读出来的"，所以先证明"读得到真的"：
//   ① 地形控制计数（netherrack / lava / solid / air）+ `unknownCells === 0`（覆盖齐全，"没读到"≠"没有"）
//   ② `w.countInBox` 独立跑一遍同一块盒，和自己逐格扫描的 unknown / lava 对账
//   ③ **可走格数 == 0 就直接抛错停工**（图是空的 ⇒ 判据或读法坏了，不能输出路线）
//   ④ 路径每一对相邻格都断言是合法移动（抓 BFS 重建的 off-by-one）

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from './region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));   // ⚠ 不用 new URL(...).pathname（Windows 上是坏路径）
const ROUTE_DIR = path.resolve(HERE, '..');
const PROBE = path.join(ROUTE_DIR, 'probe');
const WORLD = path.join(PROBE, '_nether_corridor');
const WG = path.join(PROBE, 'worldgen_nether_corridor.json');
const R7C = path.join(PROBE, 'nether_route_distance.round7c.json');
const OUT = path.join(PROBE, 'v2_nether_legs.json');

const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };

const wg = readJson(WG);
if (!wg) throw new Error(`缺 ${WG} —— 先跑 r7c_nether_corridor_worldgen.mjs`);
if (!wg.coverageOK) throw new Error(`走廊存档覆盖不全（${wg.savedChunksInWindow}/${wg.window.expectedChunks}）—— 拒绝在残缺地形上量路径`);

const w = openWorld(WORLD, { dims: ['the_nether'] });
const DIM = 'the_nether';
const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);
const HAZARD = new Set(['lava', 'magma_block', 'fire', 'soul_fire']);
const MAX_DROP = 20;          // 与 round7c 一致：下界是洞穴，掉下去是免费移动
const MAX_WP_GAP = 32;        // SCHEMA §5「相邻路点 ≤ 32 格」
const HAZARD_CAP = 64;        // 危险格上限（超出会明写 hazardsCapped）

// ---- 走廊盒（与 round7c 逐字一致：x[0]..x[1] / z[0]..z[1] / y 0..127）
const BOX = {
    x1: wg.window.blocks.x[0], y1: 0, z1: wg.window.blocks.z[0],
    x2: wg.window.blocks.x[1], y2: 127, z2: wg.window.blocks.z[1],
};
const W = BOX.x2 - BOX.x1 + 1, D = BOX.z2 - BOX.z1 + 1, H = BOX.y2 - BOX.y1 + 1;
const N = W * D * H;
console.log(`走廊：x ${BOX.x1}..${BOX.x2} / z ${BOX.z1}..${BOX.z2} / y ${BOX.y1}..${BOX.y2}（${W}×${D}×${H} = ${N} 格）`);

const nameAt = (x, y, z) => w.blockAt(x, y, z, DIM);
const solidGround = (n) => n !== 'unknown' && !AIRLIKE.has(n) && !HAZARD.has(n);

/** 站得住：脚下实心非液体 + 身体 2 格空气（与 round7c `standable` 同式） */
const standable = (x, y, z, self) => {
    const selfName = self ?? nameAt(x, y, z);
    return y >= 1 && y + 1 <= BOX.y2
        && solidGround(nameAt(x, y - 1, z))
        && AIRLIKE.has(selfName) && AIRLIKE.has(nameAt(x, y + 1, z));
};

// ---- 立可走图（0=不可走，1=可走）+ 地形对照计数（阳性对照①）
const walk = new Uint8Array(N);
const idxOf = (x, y, z) => (x - BOX.x1) + (z - BOX.z1) * W + (y - BOX.y1) * W * D;
let unknownCells = 0, airCells = 0, netherrackCells = 0, lavaCells = 0, solidCells = 0, solidExclLava = 0;
for (let y = BOX.y1; y <= BOX.y2; y++) {
    for (let z = BOX.z1; z <= BOX.z2; z++) {
        for (let x = BOX.x1; x <= BOX.x2; x++) {
            const n = nameAt(x, y, z);
            if (n === 'unknown') { unknownCells++; continue; }        // 该 y 段没 section ⇒ 不当空气
            if (AIRLIKE.has(n)) airCells++;
            if (n === 'netherrack') netherrackCells++;
            if (n === 'lava') lavaCells++;
            if (!AIRLIKE.has(n)) { solidCells++; if (n !== 'lava') solidExclLava++; }
            if (standable(x, y, z, n)) walk[idxOf(x, y, z)] = 1;
        }
    }
}
let walkCells = 0; for (let i = 0; i < N; i++) if (walk[i]) walkCells++;
console.log(`读数：unknown ${unknownCells}｜可走格 **${walkCells}**｜netherrack ${netherrackCells}｜岩浆 ${lavaCells}｜实心(含岩浆) ${solidCells}｜空气 ${airCells}`);

// ---- 阳性对照②：countInBox 独立再数一遍，交叉对账
const xbox = w.countInBox(BOX, null, DIM);
const xLava = xbox.counts.lava ?? 0, xNetherrack = xbox.counts.netherrack ?? 0;
const xAir = (xbox.counts.air ?? 0) + (xbox.counts.cave_air ?? 0) + (xbox.counts.void_air ?? 0);
console.log(`对账 countInBox：unknown ${xbox.unknownCells}｜netherrack ${xNetherrack}｜岩浆 ${xLava}｜空气 ${xAir}`);

// ---- 阳性对照③：图是空的就停工，不输出路线
const problems = [];
if (unknownCells !== 0) problems.push(`unknownCells=${unknownCells} ≠ 0 —— 覆盖不全`);
if (xbox.unknownCells !== unknownCells) problems.push(`unknown 对账不一致：逐格 ${unknownCells} vs countInBox ${xbox.unknownCells}`);
if (xLava !== lavaCells) problems.push(`lava 对账不一致：逐格 ${lavaCells} vs countInBox ${xLava}`);
if (xNetherrack !== netherrackCells) problems.push(`netherrack 对账不一致：逐格 ${netherrackCells} vs countInBox ${xNetherrack}`);
if (walkCells === 0) problems.push('walkableCells === 0 —— 读法或判据坏了，停工不输出路线');
if (netherrackCells === 0) problems.push('netherrack === 0 —— 存档读不到正地形（阳性对照失败）');
if (problems.length) throw new Error(`阳性对照未过：\n  - ${problems.join('\n  - ')}`);
console.log('阳性对照通过：unknown=0、可走格>0、netherrack>0、countInBox 对账一致。');

// ---- 三个站点（先在主世界 ÷8；站位取"离目标 XZ 最近的可走格"）
const STATIONS = [
    { key: 'S1_netherLanding', label: 'S1 门对应的下界落点', nether: [187 / 8, 308 / 8] },
    { key: 'S3_bastion', label: 'S3 堡垒', nether: [336 / 8, 256 / 8] },
    { key: 'C3_fortress', label: 'C3 要塞刷怪笼', nether: [224 / 8, -88 / 8] },
];
const LEGS = [
    { from: 'S1_netherLanding', to: 'S3_bastion' },
    { from: 'S3_bastion', to: 'C3_fortress' },
    { from: 'C3_fortress', to: 'S1_netherLanding' },
];

/** 离 (tx,tz) 最近的站得住格；**原始** d 参与比较，并列时显式取 y 小、再 x 小、再 z 小（照抄 round7c） */
function nearestStandable(tx, tz) {
    let best = null;
    for (let y = BOX.y1; y <= BOX.y2; y++) {
        for (let z = BOX.z1; z <= BOX.z2; z++) {
            for (let x = BOX.x1; x <= BOX.x2; x++) {
                if (!walk[idxOf(x, y, z)]) continue;
                const d = Math.hypot(x + 0.5 - tx, z + 0.5 - tz);
                if (best === null || d < best.d - 1e-9
                    || (Math.abs(d - best.d) <= 1e-9 && (y < best.cell[1]
                        || (y === best.cell[1] && (x < best.cell[0] || (x === best.cell[0] && z < best.cell[2])))))) {
                    best = { cell: [x, y, z], d };
                }
            }
        }
    }
    return best;
}

// ---- 邻接表：水平 4 向，每向 {同层, 上 1, 下 1..20}
const NB = [];
for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    NB.push([dx, 0, dz], [dx, 1, dz]);
    for (let k = 1; k <= MAX_DROP; k++) NB.push([dx, -k, dz]);
}

/** 水平 4 向 + 上 1 / 下 ≤MAX_DROP 的 BFS：返回 {steps, path} 或 null */
function bfs(a, b) {
    const start = idxOf(...a), goal = idxOf(...b);
    if (!walk[start] || !walk[goal]) return null;
    const dist = new Int32Array(N).fill(-1);
    const prev = new Int32Array(N).fill(-1);
    const q = new Int32Array(N);
    let qh = 0, qt = 0;
    dist[start] = 0; q[qt++] = start;
    while (qh < qt) {
        const cur = q[qh++];
        if (cur === goal) break;
        const y = BOX.y1 + Math.floor(cur / (W * D));
        const rem = cur - (y - BOX.y1) * W * D;
        const z = BOX.z1 + Math.floor(rem / W);
        const x = BOX.x1 + (rem % W);
        for (const [dx, dy, dz] of NB) {
            const nx = x + dx, ny = y + dy, nz = z + dz;
            if (nx < BOX.x1 || nx > BOX.x2 || ny < BOX.y1 || ny > BOX.y2 || nz < BOX.z1 || nz > BOX.z2) continue;
            const ni = idxOf(nx, ny, nz);
            if (!walk[ni] || dist[ni] !== -1) continue;
            dist[ni] = dist[cur] + 1; prev[ni] = cur; q[qt++] = ni;
        }
    }
    if (dist[goal] === -1) return null;
    const path = [];
    for (let c = goal; c !== -1; c = prev[c]) {
        const y = BOX.y1 + Math.floor(c / (W * D));
        const rem = c - (y - BOX.y1) * W * D;
        path.push([BOX.x1 + (rem % W), y, BOX.z1 + Math.floor(rem / W)]);
        if (c === start) break;
    }
    path.reverse();
    return { steps: dist[goal], path };
}

// ---- 阳性对照④：路径每一对相邻格必须是合法移动（抓重建 off-by-one）
function assertLegalPath(path, label) {
    if (path.length < 2) throw new Error(`${label}: 路径长度 ${path.length} < 2`);
    for (let i = 0; i + 1 < path.length; i++) {
        const [x, y, z] = path[i], [nx, ny, nz] = path[i + 1];
        const dx = nx - x, dy = ny - y, dz = nz - z;
        const okXZ = Math.abs(dx) + Math.abs(dz) === 1;             // 4 向，无斜向
        const okY = dy === 0 || dy === 1 || (dy < 0 && dy >= -MAX_DROP);
        if (!okXZ || !okY) throw new Error(`${label}: 第 ${i}→${i + 1} 步不是合法移动 ${JSON.stringify([dx, dy, dz])}`);
        if (!walk[idxOf(nx, ny, nz)]) throw new Error(`${label}: 第 ${i + 1} 格 ${JSON.stringify(path[i + 1])} 不可走`);
    }
}

/**
 * 抽稀：贪心往前推，**只取原路径上的格**（绝不插值到路径外），
 * 相邻路点 3D 欧氏 ≤ MAX_WP_GAP，首尾严格保留。
 * 贪心每步至少能吃掉 1 个路径格（单步 ≤ MAX_DROP=20 < 32）⇒ 必然收敛且末点必被发出。
 */
function thin(path, maxGap = MAX_WP_GAP) {
    const d3 = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1], p[2] - q[2]);
    const wps = [path[0]];
    let i = 0;
    while (i < path.length - 1) {
        let j = i + 1;
        for (let k = path.length - 1; k > i; k--) {
            if (d3(path[i], path[k]) <= maxGap) { j = k; break; }
        }
        wps.push(path[j]); i = j;
    }
    return wps;
}

// ---- 危险格：与路径**切比雪夫距离 ≤1**（26 邻域）的 lava/magma_block/fire/soul_fire，按首次出现顺序去重
function hazardsNear(path, cap = HAZARD_CAP) {
    const seen = new Set(), out = [];
    for (const [x, y, z] of path) {
        for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
            if (!dx && !dy && !dz) continue;
            const nx = x + dx, ny = y + dy, nz = z + dz;
            if (ny < BOX.y1 || ny > BOX.y2 || nx < BOX.x1 || nx > BOX.x2 || nz < BOX.z1 || nz > BOX.z2) continue;
            const k = `${nx},${ny},${nz}`;
            if (seen.has(k)) continue;
            const n = nameAt(nx, ny, nz);
            if (!HAZARD.has(n)) continue;
            seen.add(k); out.push({ cell: [nx, ny, nz], block: n });
        }
    }
    return { all: out, kept: out.slice(0, cap), capped: out.length > cap, total: out.length };
}

// ---- 站位解析（并与 round7c 存档里的 stand 交叉对账）
const r7c = readJson(R7C);
const resolved = {};
for (const s of STATIONS) {
    const ns = nearestStandable(s.nether[0], s.nether[1]);
    resolved[s.key] = { ...s, stand: ns ? ns.cell : null, distXZ: ns ? Number(ns.d.toFixed(2)) : null };
    const expect = r7c?.stations?.[s.key]?.stand ?? null;
    const same = JSON.stringify(expect) === JSON.stringify(resolved[s.key].stand);
    console.log(`  ${s.key.padEnd(16)} 站位 ${JSON.stringify(resolved[s.key].stand)}（round7c 存档 ${JSON.stringify(expect)}${same ? ' ✓一致' : ' ✗不一致'}）`);
    if (!same) problems.push(`${s.key} 站位与 round7c 不一致：重算 ${JSON.stringify(resolved[s.key].stand)} vs 存档 ${JSON.stringify(expect)}`);
}
if (problems.length) throw new Error(`站位对账未过：\n  - ${problems.join('\n  - ')}`);

// ---- 三段
const legs = LEGS.map((L) => {
    const A = resolved[L.from], B = resolved[L.to];
    const straightXZ = Number(Math.hypot(A.nether[0] - B.nether[0], A.nether[1] - B.nether[1]).toFixed(1));
    const r = (A.stand && B.stand) ? bfs(A.stand, B.stand) : null;
    if (!r) return { ...L, dim: DIM, walkableSteps: null, straightXZ, reachable: false, path: null, waypoints: null };
    assertLegalPath(r.path, `${L.from}→${L.to}`);
    if (r.path.length !== r.steps + 1) throw new Error(`${L.from}→${L.to}: 路径长 ${r.path.length} ≠ 步数 ${r.steps}+1（BFS 重建 off-by-one）`);
    const wps = thin(r.path);
    // 抽稀后仍要逐段核：每段跨越的都是原路径上的一段，且首尾与原路径一致
    if (JSON.stringify(wps[0]) !== JSON.stringify(r.path[0]) || JSON.stringify(wps[wps.length - 1]) !== JSON.stringify(r.path[r.path.length - 1])) {
        throw new Error(`${L.from}→${L.to}: 抽稀丢了首尾`);
    }
    const onPath = new Set(r.path.map((p) => p.join(',')));
    for (const p of wps) if (!onPath.has(p.join(','))) throw new Error(`${L.from}→${L.to}: 路点 ${p} 不在原路径上`);
    let maxGap = 0, maxGapXZ = 0;
    for (let i = 0; i + 1 < wps.length; i++) {
        maxGap = Math.max(maxGap, Math.hypot(wps[i][0] - wps[i + 1][0], wps[i][1] - wps[i + 1][1], wps[i][2] - wps[i + 1][2]));
        maxGapXZ = Math.max(maxGapXZ, Math.hypot(wps[i][0] - wps[i + 1][0], wps[i][2] - wps[i + 1][2]));
    }
    if (maxGap > MAX_WP_GAP) throw new Error(`${L.from}→${L.to}: 相邻路点间距 ${maxGap.toFixed(2)} > ${MAX_WP_GAP}`);
    const hz = hazardsNear(r.path);
    const ys = r.path.map((p) => p[1]);
    return {
        from: L.from, to: L.to, dim: DIM,
        waypoints: wps,
        notes: `纯地形路径（round7c 同判据/同移动集：水平4向+上1+下≤${MAX_DROP}，无斜向）。`
            + `全程 ${r.steps} 步 / ${r.path.length} 格，y ${Math.min(...ys)}..${Math.max(...ys)}。`
            + (hz.total ? `沿途 1 格内有 ${hz.total} 个危险格（lava/magma_block/fire/soul_fire），编排器须绕行。` : '沿途 1 格内无危险格。'),
        walkableSteps: r.steps, straightXZ, detourFactor: Number((r.steps / straightXZ).toFixed(2)),
        reachable: true,
        pathMinMaxY: [Math.min(...ys), Math.max(...ys)],
        path: r.path,
        waypointCount: wps.length,
        maxWaypointSpacing: Number(maxGap.toFixed(2)),
        maxWaypointSpacingXZ: Number(maxGapXZ.toFixed(2)),
        hazardsCap: HAZARD_CAP,
        hazardsTotal: hz.total,
        hazardsCapped: hz.capped,
        hazards: hz.kept.map((h) => ({ cell: h.cell, block: h.block })),
    };
});

for (const l of legs) {
    console.log(`  ${l.from} → ${l.to}：直线 ${l.straightXZ}｜可走 ${l.walkableSteps ?? '不可达'} 步｜路径 ${l.path?.length ?? 0} 格｜`
        + `路点 ${l.waypointCount} 个（最大间距 ${l.maxWaypointSpacing}，3D 上限 ${MAX_WP_GAP}）｜危险格 ${l.hazardsTotal}${l.hazardsCapped ? `（截到 ${HAZARD_CAP}）` : ''}`);
}
const totalSteps = legs.every((l) => l.walkableSteps != null) ? legs.reduce((a, l) => a + l.walkableSteps, 0) : null;
console.log(`  合计可走：${totalSteps ?? '—'} 步`);

const EXPECT = { 'S1_netherLanding>S3_bastion': 25, 'S3_bastion>C3_fortress': 69, 'C3_fortress>S1_netherLanding': 58 };
const compare = legs.map((l) => {
    const exp = EXPECT[`${l.from}>${l.to}`] ?? null;
    return { leg: `${l.from}>${l.to}`, expected: exp, recomputed: l.walkableSteps, match: exp === l.walkableSteps };
});
console.log('  对账 round7c：' + compare.map((c) => `${c.leg} 期望 ${c.expected} 实得 ${c.recomputed} ${c.match ? '✓' : '✗'}`).join('｜'));

const out = {
    schema: 'aidqq-route-v2-nether-legs/1',
    routeSchemaTarget: 'aidqq-route/2',
    at: new Date().toISOString(),
    seed: '4926685115947721762', mcVersion: '1.16.1', lane: 'C',
    criteria: {
        reusedFrom: 'probe/nether_route_distance.round7c.json + tools/r7c_nether_route_distance.mjs',
        standable: '脚下 1 格非空气且非 {lava, magma_block, fire, soul_fire} + 身体 2 格空气集',
        walkableGraph: `水平 4 向 + 上 1 格 / 下 ≤${MAX_DROP} 格（不含斜向）`,
        stepCost: '每步代价 1（步数 = BFS 最短距离；并列路径的选法依赖遍历序，但步数不受影响）',
        standCellRule: '离 目标netherXZ(主世界÷8) 最近的站得住格；距离并列时取 y 小、再 x 小、再 z 小',
        waypointRule: `路径抽稀，只取原路径上的格，相邻路点 3D 欧氏 ≤ ${MAX_WP_GAP} 格，首尾严格保留`,
        hazardRule: '与路径切比雪夫距离 ≤1（26 邻域）且方块 ∈ {lava, magma_block, fire, soul_fire}',
        worldReadOnly: true,
    },
    world: {
        dir: WORLD, window: BOX, cells: N,
        unknownCells, walkableCells: walkCells,
        terrainControl: { netherrack: netherrackCells, lava: lavaCells, solidIncludingLava: solidCells, solidExcludingLava: solidExclLava, air: airCells },
        crossCheck: { source: 'region_reader.countInBox', unknownCells: xbox.unknownCells, netherrack: xNetherrack, lava: xLava, air: xAir, consistent: true },
        coverageOK: wg.coverageOK, savedChunksInWindow: wg.savedChunksInWindow, expectedChunks: wg.window.expectedChunks,
    },
    positiveControl: {
        pass: true,
        checks: [
            'unknownCells === 0（"没读到"未发生，覆盖齐全）',
            `netherrack ${netherrackCells} / lava ${lavaCells} / 实心 ${solidCells} / 空气 ${airCells}（读到了正地形）`,
            `可走格 ${walkCells} > 0（图非空）`,
            'countInBox 独立复算与逐格扫描对账一致',
            '每段路径逐对断言为合法移动（水平4向 + Δy∈{0,+1,-1..-20}）',
            'path.length === walkableSteps + 1（抓 BFS 重建 off-by-one）',
            '抽稀路点全部落在原路径上，且首尾与原路径一致',
            '站位与 round7c 存档逐格一致',
        ],
    },
    stations: resolved,
    legs,
    totals: {
        walkableSteps: totalSteps,
        expectedRound7c: 152,
        matchesRound7c: totalSteps === 152,
        waypoints: legs.reduce((a, l) => a + (l.waypointCount ?? 0), 0),
        hazards: legs.reduce((a, l) => a + (l.hazardsTotal ?? 0), 0),
    },
    comparisonToRound7c: compare,
    caveats: [
        '**纯地形距离**：不判遭遇战（猪灵/烈焰人/岩浆怪），也不判搭桥/岩浆船 ⇒ 实战步数只会更多。',
        '**不含斜向**：真人会斜着走，本数是上界估计。',
        '**下界落点未验**：门落点的实际 (x,y,z) 需真服开一次门看 Pos；本单用"离目标 XZ 最近的可走格"代替（与 round7c 同）。',
        '**三段各自独立最短路**，往返不一定走同一条路。',
        `**hazards 每腿截到 ${HAZARD_CAP} 个**（hazardsTotal 是未截断的总数，hazardsCapped 说明是否被截）。`,
    ],
    evidence: [
        'bench/route/probe/worldgen_nether_corridor.json',
        'bench/route/probe/nether_route_distance.round7c.json',
        'bench/route/probe/v2_nether_legs.json',
    ],
};
fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
console.log(`\n落盘：${OUT}`);
