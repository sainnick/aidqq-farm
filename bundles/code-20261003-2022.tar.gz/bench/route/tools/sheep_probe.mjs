// sheep_probe.mjs v2 — MC-ROUND5 §C 复核指令 3 第二轮：S0_sheep 的羊到底有没有、在哪儿
//
// 【v1 为什么不够（设计会话 2026-10-02 夜指出，两条都成立）】
//   ① **计数通道没做过阳性对照**。v1 全 0 之后我无法区分"没有羊"和"通道坏了"。
//      ⇒ v2 第一件事：在同一个世界里 `summon` 1 只羊，用**同一条通道**数；数不到 = 通道坏了，**直接停下**。
//   ② **采样区太小**。v1 用了 6 个 32×32 盒（各 4 个区块）且全在 ≥192 格外；每个区块只有约 10%
//      概率刷一群 ⇒ 24 个区块全 0 在统计上完全不意外。v1 还把"避开预生成区"当纪律，
//      但那恰恰**排除了最可能有羊的地方**（起服时预生成的区块与难度/玩家无关，羊就在里面）。
//   ⇒ v2：出生点周围、**预生成区以内**，用 4×4 区块（64×64）的大盒**铺满 ≥16×16 区块**。
//
// 【另外更正 v1 的一个推理（重要）】
//   v1 写"实跑是 peaceful ⇒ 1.16.1 的 NaturalSpawner 直接不刷 ⇒ 羊不会自然生成"。
//   **这个推理不成立**：F 线实测（docs/MC-S2-01.md §4.5）在 **peaceful 下堡垒站有 28 头猪灵**
//   （服务端 `kill @e[type=piglin]` 回执 + 客户端一致）⇒ 区块生成期的"初始 mobs"**不受 peaceful 抑制**。
//   （猪灵与羊的 MobCategory 不同，羊仍需实测 —— 这就是本文件要做的事。）
//
// 【通道（1.16.1 唯一可用的逐实体计数）】
//   `execute in minecraft:overworld at @e[type=armor_stand,tag=<盒>] as @e[type=minecraft:sheep,r=N] run time query gametime`
//   每个匹配实体执行一次 ⇒ 回执行数 == 实体数；0 匹配是零输出 ⇒ 靠静默窗收尾。
//   ⚠ 载体必须用 `tag` 点名（`limit=1` 是按执行源选的，命令源是控制台 0,0,0，会挑错人）。
//   ⚠ 坐标用 `data get entity @s Pos`；**先探一次回执形态再解析**（1.16/1.17 的措辞与格式都不同）。
//   ⚠ F 线 §8.4 记过 `data get entity` 在某些上下文 100% 解析失败 ⇒ 探不到就**如实标"坐标未取到"**，不猜。
//
// 【判据（设计会话给的）】
//   两个 fresh world：坐标集合一致且非空 ⇒ 由种子决定 ⇒ 标 REAL，center 取**离 S1 路线最近**的那群；
//   不一致或仍为 0 ⇒ 保持 UNVERIFIED、center 维持 [216,224]，停下报告。
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\sheep_probe.mjs [--budget-ms 1800000]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, waitForLaneC, ROUTE_DIR } from './console.mjs';
import { fillOnce, countAndRestore, qname } from './fortress_standing_probe.mjs';
import { forceload } from './scan.mjs';

const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const RUN_DIR = path.join(PROBE_DIR, '_run_round5c', 'sheep');
const OUT = path.resolve(argOf(process.argv, 'out', path.join(PROBE_DIR, 'sheep.round5c.json')));
const BUDGET_MS = parseInt(argOf(process.argv, 'budget-ms', '1800000'), 10);
const SEED = argOf(process.argv, 'seed', '4926685115947721762');

/** 出生点与 S1（SEED-01 top_ranked.csv + 既有 route） */
const SPAWN = { x: 216, z: 224, biome: 'plains' };
const S1 = { x: 176, z: 304 };
/** 采样区：4×4 区块 = 64×64 格的大盒，4×4 个盒 = 16×16 区块 = 256×256 格，覆盖出生点 ±128 格（≲ 8 区块，
 *  完全在起服预生成半径 12 区块内）。**不再避开 192 格** —— 预生成区才是羊在的地方。 */
const BOX = 64;
const GRID = 4;                                   // 4×4 个盒
const X0 = SPAWN.x - (GRID * BOX) / 2;            // 88
const Z0 = SPAWN.z - (GRID * BOX) / 2;            // 96
const Y_GROUND = { y1: 56, y2: 71 };               // 地形对照的 y 层（fill 盒高 ≤16）
const PASSIVES = ['sheep', 'cow', 'pig', 'chicken'];
const R_SCAN = Math.ceil((BOX * Math.SQRT2) / 2) + 2;   // 47：覆盖 64×64 盒的半对角线

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 发一条命令等第一条匹配行 */
async function cmdOnce(con, cmd, re, timeoutMs = 15000) {
    con.drain();
    con.cmd(cmd);
    const t0 = Date.now();
    const seen = [];
    for (;;) {
        for (const line of con.drain()) {
            seen.push(line);
            if (re.test(line)) return line;
        }
        if (Date.now() - t0 > timeoutMs) throw new Error(`CMD_NO_RECEIPT: ${cmd}（末几条：${seen.slice(-3).join(' | ').slice(0, 160)}）`);
        await sleep(40);
    }
}

/** 起服 + bind 竞态的正解（v1 踩过：waitForLaneC 返回"获得"后对面抢先起服，三次重试全撞 BindException） */
async function bootRobust(seed, runDir, label, { rounds = 4, coolMs = 75000 } = {}) {
    for (let round = 1; round <= rounds; round++) {
        try { return await bootLaneC({ seed, runDir, logFn: log }); }
        catch (e) {
            const logPath = path.join(runDir, 'server.log');
            let txt = '';
            try { txt = fs.readFileSync(logPath, 'utf8'); } catch { /* 没落盘 */ }
            const bind = /Address already in use/i.test(txt);
            log(`  [${label}] 起服失败：${String(e).slice(0, 80)}｜日志判据：${bind ? '**端口被别人占**' : '非端口原因'}`);
            if (!bind) throw e;
            if (round === rounds) throw new Error(`BOOT_BIND_ROUNDS_EXHAUSTED：连续 ${rounds} 轮被占`);
            log(`  [${label}] 冷却 ${Math.round(coolMs / 1000)}s 后重新排队`);
            await sleep(coolMs);
            await waitForLaneC({ timeoutMs: 15 * 60 * 1000, logFn: log });
        }
    }
    throw new Error('BOOT_ROUNDS_EXHAUSTED');
}

/** 实体计数：回执行数 == 实体数；0 匹配零输出（静默窗收尾） */
async function countEntities(con, carrierTag, type, timeRe, { quietMs = 1200, timeoutMs = 30000 } = {}) {
    con.drain();
    // ⚠⚠ **不能带 `r=`**（见 `probeCommandShapes` 的实测：本机 1.16.1 对 `execute as @e[...,r=N]`
    //    回 `Unknown option 'r'`，命令整条被拒 ⇒ 计数恒为 0）。1.16.1 的 `execute as` 不接受距离参数。
    //    所以这里搜**全部已加载区块**；分盒在**离线**做（用坐标），信息还更全。
    con.cmd(`execute in minecraft:overworld at @e[type=minecraft:armor_stand,tag=${carrierTag},limit=1] `
        + `as @e[type=minecraft:${type}] run time query gametime`);
    const t0 = Date.now();
    let n = 0, lastHit = 0;
    for (;;) {
        for (const line of con.drain()) if (timeRe.test(line)) { n++; lastHit = Date.now(); }
        const now = Date.now();
        if (lastHit && now - lastHit > quietMs) return n;
        if (!lastHit && now - t0 > quietMs) return 0;
        if (now - t0 > timeoutMs) return n;
        await sleep(50);
    }
}

/**
 * ★ 命令形态探测（v2 新增，先探后用）。
 * 本单在 1.16.1 上实测踩到：`execute as @e[type=sheep,r=48]` 回 **`Unknown option 'r'`**
 * ⇒ 整条命令被解析器拒绝（**不是**"0 匹配"，而是一条回执都没有）⇒ 上一版把采样区的羊全数成 0。
 * 教训与手册 §3 一脉相承（"`execute in … fill` 漏 `run`"、"`blackstone_bricks` 让整轮挂 25s"）：
 * **1.16.1 的 execute 链对选择器选项的限制，必须逐条实测，不能照搬新版的写法。**
 * 这里把候选写法全试一遍并落档，阳性对照随之用它认定的可用写法。
 */
async function probeCommandShapes(con, tag) {
    const CANDS = [
        { name: 'as @e[type]（不带任何选项）', sel: 'as @e[type=minecraft:sheep]', run: 'time query gametime', expect: 'count' },
        { name: 'as @e[type,r=N]', sel: 'as @e[type=minecraft:sheep,r=48]', run: 'time query gametime', expect: 'count' },
        { name: 'as @e[type,limit=N]', sel: 'as @e[type=minecraft:sheep,limit=8]', run: 'time query gametime', expect: 'count' },
        { name: 'as @e[type] run data get entity @s Pos', sel: 'as @e[type=minecraft:sheep]', run: 'data get entity @s Pos', expect: 'nbt' },
    ];
    const out = [];
    for (const c of CANDS) {
        con.drain();
        const cmd = `execute in minecraft:overworld at @e[type=minecraft:armor_stand,tag=${tag},limit=1] ${c.sel} run ${c.run}`;
        con.cmd(cmd);
        const t0 = Date.now();
        const lines = [];
        let lastHit = 0;
        for (;;) {
            for (const line of con.drain()) { lines.push(line); lastHit = Date.now(); }
            const now = Date.now();
            if (lastHit && now - lastHit > 900) break;
            if (!lastHit && now - t0 > 1500) break;
            if (now - t0 > 12000) break;
            await sleep(50);
        }
        const err = lines.find((l) => /Unknown option|Incorrect argument|Unknown or incomplete|Expected/i.test(l));
        const rec = {
            name: c.name, cmd, ok: !err, receipts: lines.filter((l) => !/INFO\]: \[/.test(l)).length,
            sampleLine: lines.find((l) => !/Unknown option/i.test(l) && l.trim()) ?? null,
            errorLine: err ?? null,
        };
        out.push(rec);
        log(`  形态探测：${c.name} → ${rec.ok ? `✅ 可用（${rec.receipts} 条回执）` : `❌ ${(err ?? '').slice(0, 60)}`}`);
    }
    return out;
}

/**
 * 取实体坐标：`as @e[type] run data get entity @s Pos`，每只一条回执。
 * ⚠ **先探形态再解析**（`probeCommandShapes` 已经探过）；探不到就返回 null，调用方如实标"坐标未取到"。
 */
async function entityPositions(con, carrierTag, type, { quietMs = 1500, timeoutMs = 30000 } = {}) {
    con.drain();
    con.cmd(`execute in minecraft:overworld at @e[type=minecraft:armor_stand,tag=${carrierTag},limit=1] `
        + `as @e[type=minecraft:${type}] run data get entity @s Pos`);
    const t0 = Date.now();
    const lines = [];
    let lastHit = 0;
    for (;;) {
        for (const line of con.drain()) { if (/data|here|Expected/i.test(line)) { lines.push(line); lastHit = Date.now(); } }
        const now = Date.now();
        if (lastHit && now - lastHit > quietMs) break;
        if (!lastHit && now - t0 > quietMs) break;
        if (now - t0 > timeoutMs) break;
        await sleep(50);
    }
    const pos = [];
    let parsed = null;
    for (const l of lines) {
        const m = l.match(/\[(-?[\d.]+)d?,\s*(-?[\d.]+)d?,\s*(-?[\d.]+)d?\]/);
        if (m) { parsed = parsed ?? m[0]; pos.push([+m[1], +m[2], +m[3]]); }
    }
    return { pos, sampleLine: lines[0] ?? null, parseRe: parsed, total: lines.length };
}

/** 区块就绪闸门（forceload 异步；实体只存在于已加载区块） */
async function ensureLoaded(con, x1, z1, x2, z2, { tries = 10, settleMs = 1000 } = {}) {
    const probes = [[x1, z1], [x2, z2], [Math.floor((x1 + x2) / 2), Math.floor((z1 + z2) / 2)]];
    for (let i = 0; i < tries; i++) {
        await forceload(con, 'overworld', x1, z1, x2, z2, settleMs);
        let pending = 0;
        for (const [x, z] of probes) {
            const v = await fillOnce(con, 'overworld', { x1: x, y1: 70, z1: z, x2: x, y2: 70, z2: z }, 'minecraft:stone', { timeoutMs: 12000 });
            if (v.kind === 'not_loaded') pending++;
        }
        if (pending === 0) return { ready: true, tries: i + 1 };
    }
    return { ready: false, tries };
}

const boxes = [];
for (let i = 0; i < GRID; i++) for (let j = 0; j < GRID; j++) {
    boxes.push({ name: `B${i}${j}`, x1: X0 + i * BOX, z1: Z0 + j * BOX, x2: X0 + i * BOX + BOX - 1, z2: Z0 + j * BOX + BOX - 1 });
}

/** 一个 fresh world 的整套测量。`positiveControl` 决定要不要做阳性对照（第一个 world 必须做）。 */
async function probeWorld(handle, { label, positiveControl }) {
    const con = handle.con;
    const rec = { label, timeRe: null, boxes: [], sheep: [], controls: {}, chunkGate: {}, positiveControl: null };

    // ---- 难度闸门（记下服务器实际回执，不靠记忆）
    rec.difficulty = await cmdOnce(con, 'difficulty', /difficulty/i, 15000);

    // ---- `time query` 的真实回执措辞（先探后用）
    const probe = await cmdOnce(con, 'time query gametime', /time/i, 10000);
    rec.timeQueryReceipt = probe;
    const m = probe.match(/The (?:game )?time is (\d+)/i);
    if (!m) throw new Error(`TIME_QUERY_RECEIPT_UNKNOWN：${probe}`);
    const timeRe = new RegExp(`^${m[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`);

    // ---- 区块就绪 + 载体（每盒一个 tag；分盒在离线做，载体只为 `at` 定位用）
    for (const b of boxes) {
        const g = await ensureLoaded(con, b.x1 - 2, b.z1 - 2, b.x2 + 2, b.z2 + 2);
        rec.chunkGate[b.name] = g;
        if (!g.ready) throw new Error(`CHUNK_GATE_NOT_READY：${b.name}`);
    }
    for (const b of boxes) {
        const cx = Math.floor((b.x1 + b.x2) / 2), cz = Math.floor((b.z1 + b.z2) / 2);
        await cmdOnce(con, `summon minecraft:armor_stand ${cx} 90 ${cz} {NoGravity:1b,Marker:1b,Invisible:1b,Silent:1b,Tags:["p2_${b.name.toLowerCase()}"]}`, /Armor Stand/i, 15000);
    }

    // ---- ★ 形态探测（先探后用：哪些选择器写法这台 1.16.1 真的认）
    rec.commandShapes = await probeCommandShapes(con, 'p2_b00');

    // ---- 逐盒地形对照（fill；只判"哪些盒是草地"）
    for (const b of boxes) {
        const ctrl = {};
        for (const half of [0, 1]) {
            const bx1 = half === 0 ? b.x1 : Math.floor((b.x1 + b.x2) / 2) + 1;
            const bx2 = half === 0 ? Math.floor((b.x1 + b.x2) / 2) : b.x2;
            const bb = { x1: bx1, y1: Y_GROUND.y1, z1: b.z1, x2: bx2, y2: Y_GROUND.y2, z2: b.z2 };
            for (const c of ['grass_block', 'stone', 'water']) {
                const r = await countAndRestore(con, 'overworld', bb, qname(c), { timeoutMs: 12000 });
                if (r.n) ctrl[c] = (ctrl[c] ?? 0) + r.n;
                if (r.restoreMismatch) throw new Error(`RESTORE_MISMATCH @ ${b.name} ${c}`);
            }
        }
        const cx = Math.floor((b.x1 + b.x2) / 2), cz = Math.floor((b.z1 + b.z2) / 2);
        rec.boxes.push({ ...b, center: [cx, cz], controls: ctrl });
        for (const [k, v] of Object.entries(ctrl)) rec.controls[k] = (rec.controls[k] ?? 0) + v;
    }
    log(`  [${label}] 地形对照完成：草 ${rec.controls.grass_block ?? 0} / 石 ${rec.controls.stone ?? 0} / 水 ${rec.controls.water ?? 0}`);

    // ---- ★ 阳性对照（v2 的第一件事）：summon 1 只羊，同一通道必须数到 +1
    if (positiveControl) {
        const before = await countEntities(con, 'p2_b00', 'sheep', timeRe);
        const sumLine = await cmdOnce(con, `summon minecraft:sheep ${X0 + BOX / 2} 70 ${Z0 + BOX / 2}`, /Summoned new Sheep|summon/i, 15000);
        const after = await countEntities(con, 'p2_b00', 'sheep', timeRe);
        rec.positiveControl = { countBefore: before, countAfter: after, delta: after - before, summonReceipt: sumLine, ok: after === before + 1 };
        log(`  [${label}] ★阳性对照：summon 1 只羊 → 计数 ${before} → **${after}**（Δ=${after - before}）${rec.positiveControl.ok ? '✅ 通道可用' : '❌ 通道坏了'}`);
        if (!rec.positiveControl.ok) {
            throw new Error(`POSITIVE_CONTROL_FAILED：summon 1 只羊后同通道数到 ${after}（应 ${before + 1}）⇒ 计数通道不可用，**不产出任何羊站结论**`);
        }
        // 复原：把对照羊清掉（避免污染采样）
        await cmdOnce(con, 'kill @e[type=minecraft:sheep]', /Killed|no entities/i, 10000).catch(() => { });
        rec.positiveControl.killedBack = true;
    }

    // ---- 实体计数（全部已加载区块）+ 坐标（离线再分盒）
    const ents = {};
    for (const p of PASSIVES) ents[p] = await countEntities(con, 'p2_b00', p, timeRe);
    rec.entities = ents;
    for (const [k, v] of Object.entries(ents)) rec[k] = v;
    log(`  [${label}] 全局实体计数（已加载区块）：${JSON.stringify(ents)}`);

    const posInfo = await entityPositions(con, 'p2_b00', 'sheep');
    rec.posSample = posInfo.sampleLine; rec.posParseRe = posInfo.parseRe; rec.posRawCount = posInfo.total;
    rec.sheep = posInfo.pos;                 // 全部已加载区块里的羊坐标（未分盒）
    rec.insideArea = posInfo.pos.filter((p) => p[0] >= X0 && p[0] < X0 + GRID * BOX && p[2] >= Z0 && p[2] < Z0 + GRID * BOX);
    rec.outsideArea = posInfo.pos.length - rec.insideArea.length;
    // 离线分盒（`execute as` 不支持 r=，所以分盒必须离线做）
    for (const b of boxes) {
        const row = rec.boxes.find((x) => x.name === b.name);
        row.entities = {};
        for (const p of rec.insideArea) {
            if (p[0] >= b.x1 && p[0] <= b.x2 && p[2] >= b.z1 && p[2] <= b.z2) row.entities.sheep = (row.entities.sheep ?? 0) + 1;
        }
        log(`  [${label}] ${b.name} 草${row.controls.grass_block ?? 0} | 羊${row.entities.sheep ?? 0}`);
    }
    log(`  [${label}] 坐标：解析 ${rec.sheep.length} 只（采样区内 ${rec.insideArea.length} / 区外 ${rec.outsideArea}）｜回执 ${rec.posRawCount} 条`);
    return rec;
}

// ---------------------------------------------------------------- 判读（纯函数，offline 自检直接覆盖）
const key3 = (p) => `${Math.round(p[0])},${Math.round(p[1])},${Math.round(p[2])}`;
/**
 * 两个 world 的读数 → 结论。
 * ⚠ 三条判据（设计会话）：**阳性对照必须过**（不过 = 通道坏，停）；**坐标集合一致且非空** ⇒ REAL，
 *   center 取**离 S1 最近**的那群；**不一致或仍 0** ⇒ UNVERIFIED、center 维持。
 */
export function judgeSheep(worlds, { spawn = SPAWN, s1 = S1 } = {}) {
    const A = worlds.find((w) => /模板默认$/.test(w.label)) ?? worlds[0];
    const B = worlds.find((w) => /第二次/.test(w.label));
    // ⚠ 只用**采样区内**的羊做"坐标一致"判据（`execute as` 不支持 r=，所以实体计数是全局的；
    //   预生成半径 12 区块 = 192 格 > 采样区 128 格，区外的羊单独记数）
    const setA = new Set((A?.insideArea ?? []).map(key3));
    const setB = new Set((B?.insideArea ?? []).map(key3));
    // 坐标可用 = **A 能解析**；B 存在时也必须能（B 跑不出来就是"坐标不可用"，不是"不一致"）
    const posOk = !!A?.posParseRe && (!B || !!B?.posParseRe);
    const channelOk = !!A?.positiveControl?.ok;
    const terrainOk = (A?.controls?.grass_block ?? 0) > 0;
    const dToS1 = (p) => Math.hypot(p[0] - s1.x, p[2] - s1.z);
    const rows = worlds.map((w) => ({
        label: w.label, difficulty: w.difficulty,
        sheepInside: w.insideArea?.length ?? 0, sheepOutside: w.outsideArea ?? 0,
        cow: w.cow ?? 0, pig: w.pig ?? 0, chicken: w.chicken ?? 0,
        controls: w.controls ?? {},
    }));
    const gates = {
        positiveControl: channelOk, coordinateParse: posOk, terrainControl: terrainOk,
        twoWorldsSameCoordinates: B ? (setA.size > 0 && setA.size === setB.size && [...setA].every((k) => setB.has(k))) : null,
        commandShapes: (A?.commandShapes ?? []).map((c) => ({ name: c.name, ok: c.ok, error: c.errorLine })),
    };
    let status = 'INCONCLUSIVE', conclusion = '', center = null, nearest = null;
    if (!channelOk) {
        status = 'CHANNEL_BROKEN';
        conclusion = '**阳性对照失败**（summon 1 只羊，同通道没数到 +1）⇒ 计数通道不可用，按设计会话指令停下，不产出任何羊站结论。';
    } else if (!posOk) {
        status = 'COORDINATES_UNAVAILABLE';
        conclusion = '计数通道可用，但 `data get entity @s Pos` 的回执形态没探明（F 线 §8.4 记过它会 100% 解析失败）'
            + '⇒ 拿不到坐标，无法满足"两个 world 坐标一致"这条判据。保持 UNVERIFIED、center 维持，停下报告。';
    } else if (setA.size === 0) {
        status = 'ZERO_WITH_WORKING_CHANNEL';
        conclusion = `通道已用阳性对照证明可用、坐标可解析，但**采样区 ${GRID * GRID} 个 ${BOX}×${BOX} 盒`
            + `（${GRID * GRID * 16} 个区块、约 ${GRID * BOX}×${GRID * BOX} 格）里一只羊都没有**`
            + `（区外另有 ${A?.outsideArea ?? 0} 只；牛/猪/鸡 ${A?.cow ?? 0}/${A?.pig ?? 0}/${A?.chicken ?? 0}；草地 ${A?.controls?.grass_block ?? 0} 格）`
            + '⇒ 保持 UNVERIFIED、center 维持 [216,224]，停下报告。';
    } else if (setA.size > 0 && !terrainOk) {
        status = 'INCONCLUSIVE';
        conclusion = `羊数 >0（${setA.size}）但**地形对照为 0** ⇒ 数据自相矛盾（区块没生成不可能有实体），`
            + '按手册 §5 先证伪工具/区域，不采信实体数、不标 REAL。';
    } else if (gates.twoWorldsSameCoordinates === true) {
        const best = [...A.insideArea].sort((p, q) => dToS1(p) - dToS1(q))[0];
        nearest = { pos: best.map(Math.round), distToS1: Math.round(dToS1(best)) };
        center = [Math.round(best[0] / 8) * 8, Math.round(best[2] / 8) * 8];
        status = 'REAL';
        conclusion = `两个 fresh world 的羊**坐标集合完全一致**（采样区内各 ${setA.size} 只；采样区外另有 ${A?.outsideArea ?? 0} / ${B?.outsideArea ?? 0} 只，不参与判据）`
            + `⇒ 由种子决定 ⇒ 标 REAL；`
            + `center 取离 S1 最近的那群 @(${nearest.pos.join(',')})（距 S1 门 ${nearest.distToS1} 格，8 格对齐后 [${center}]）`;
    } else if (gates.twoWorldsSameCoordinates === false) {
        status = 'INCONSISTENT';
        conclusion = `两个 world 的羊坐标**不一致**（A ${setA.size} 只 / B ${setB.size} 只）⇒ 不是纯种子决定 ⇒ 保持 UNVERIFIED、center 维持，停下报告。`;
    } else {
        status = 'INCONCLUSIVE';
        conclusion = '只跑了一个 world（或第二个 world 没跑完）⇒ 无法做"坐标一致"对比。';
    }
    return { rows, gates, status, conclusion, center, nearest, setA: [...setA], setB: [...setB] };
}

async function main() {
    const t0 = Date.now();
    const left = () => BUDGET_MS - (Date.now() - t0);
    const out = {
        schema: 'aidqq-round5c-sheep/2',
        label: 'MC-ROUND5 §C 复核指令 3 第二轮：阳性对照 + 预生成区内 16×16 区块铺开采样 + 记坐标',
        seed: SEED, mcVersion: '1.16.1', lane: 'C',
        spawn: SPAWN, s1: S1, spawnDistance: Math.round(Math.hypot(SPAWN.x - S1.x, SPAWN.z - S1.z)),
        sampling: { box: `${BOX}x${BOX} 格（= 4x4 区块）`, grid: `${GRID}x${GRID} 盒`, totalBlocks: GRID * GRID * 16, extent: `${X0}..${X0 + GRID * BOX - 1} × ${Z0}..${Z0 + GRID * BOX - 1}`, insidePregen: true },
        passives: PASSIVES, startedAt: new Date().toISOString(), status: 'NOT_RUN', worlds: [],
        note: '羊是**实体**不是方块 ⇒ fill 通道数不到；走 `as @e[type=…] run <每实体一次回执>`。'
            + 'v2 相比 v1：①加阳性对照（通道坏了就停）②采样区从 6 个 32×32 盒/24 区块扩大到 16 个 64×64 盒/256 区块，'
            + '且**不再避开预生成区**（羊就在预生成时刷出）。',
    };
    let h = null;
    try {
        out.status = 'RUNNING';
        log('=== C 线 · S0_sheep 实测 v2（阳性对照 + 大范围采样 + 坐标）===');
        log(`出生点 (${SPAWN.x},${SPAWN.z})=${SPAWN.biome} · 采样 ${GRID * GRID} 个 ${BOX}×${BOX} 盒（${GRID * GRID * 16} 区块）· ${out.sampling.extent}`);

        h = await bootRobust(SEED, path.join(RUN_DIR, 'A'), 'A');
        out.worlds.push(await probeWorld(h, { label: 'A:模板默认', positiveControl: true }));
        await shutdownLaneC(h); h = null;

        if (left() > 600000) {
            h = await bootRobust(SEED, path.join(RUN_DIR, 'B'), 'B');
            out.worlds.push(await probeWorld(h, { label: 'B:模板默认(第二次)', positiveControl: false }));
            await shutdownLaneC(h); h = null;
        } else log('  预算不足，跳过 world B');

        const j = judgeSheep(out.worlds, { spawn: SPAWN, s1: S1 });
        out.readout = j.rows; out.gates = j.gates; out.status = j.status; out.conclusion = j.conclusion;
        out.nearestSheep = j.nearest; out.suggestedCenter = j.center;
        out.sheepCoordsA = j.setA; out.sheepCoordsB = j.setB;
        log(`判读：${JSON.stringify(j.rows, null, 1)}`);
        log(`【结论】${j.status}：${j.conclusion}`);
    } catch (e) {
        out.error = String(e && e.stack ? e.stack : e);
        if (out.status === 'RUNNING') out.status = /POSITIVE_CONTROL_FAILED/.test(out.error) ? 'CHANNEL_BROKEN' : 'FAILED';
        log(`✗ ${out.status}：${String(e).split('\n')[0]}`);
    } finally {
        out.seconds = Math.round((Date.now() - t0) / 1000);
        out.finishedAt = new Date().toISOString();
        fs.mkdirSync(path.dirname(OUT), { recursive: true });
        fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
        log(`落盘：${path.relative(process.cwd(), OUT)}（status=${out.status}，${out.seconds}s）`);
    }
}

if (process.argv[1] && path.resolve(process.argv[1]).endsWith('sheep_probe.mjs')) {
    await main();
}
