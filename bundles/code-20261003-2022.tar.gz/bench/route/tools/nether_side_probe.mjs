// nether_side_probe.mjs — MC-ROUND4 §C 线：**主种子下界一侧预勘**（服务器权威通道）
//
// 【为什么是三个全新站】ROUTE-02（10-01/10-02）已经核过主种子的 S3_bastion 与
//   S4_fortress_spawner，但那两条的起点来自 `/locate`（从出生点找最近的），实测中心分别在
//   (288,240) 与 (-432,32)，**离本单的"要塞对应点" (163,151) 有 153 格和 607 格**——
//   不是本单要的那片区域。派单 C 节的三个问题（下界废弃门 / 堡垒类型 / 要塞刷怪笼）上一单
//   一个都没测过。本文件按派单口径新开三站，起点全部来自离线 cubiomes（nether_side_offline.mjs），
//   再用**服务器 fill 通道**下钻核验（手册 §7「赛前允许」）。
//
// 【三个站 + 各自的口径】
//   C-1 nether_ruined_portal  派单 C-1：框内计数（生产 frameCells 几何）、缺几格、缺格被什么占、
//                             附近的箱子。决定"穿下界、到要塞附近补门出来"要多少黑曜石。
//   C-2 bastion                派单 C-2：堡垒类型（housing/bridge/treasure/hoglin stables，按结构件判别）
//                             + 金块与宝箱位置。**交给 F 线 B5 用**。
//   C-3 fortress_spawner       派单 C-3：刷怪笼数量（≥2？）、各自所在区域、
//                             以及笼周围的站位条件（有没有能挡烈焰人火球的墙角）。
//
// 【纪律（全部来自手册 §5 与上一单的踩坑）】
//   1. **每个站一个 fresh world**：fill-replace 真实改变世界，重叠区域用被标过的世界会读出假数。
//      三个站彼此有重叠（都在下界），所以绝不共用世界。
//   2. **每盒地形对照**：下界用 netherrack + soul_soil。读出全零先证伪工具再证伪世界。
//   3. **fill 回执严格 FIFO 配对**（scan.mjs 的 fillCount 已实现；FILL_DESYNC 直接抛错硬失败）。
//   4. **"没找到"必须判失败**：目标全零 → 记 toolFailed 并加宽半径，不许等价成"不需要处理"。
//   5. **下钻点数必须等于粗扫计数**（scan.mjs 的 selfCheck），不等即降级 UNVERIFIED。
//   6. 1.16.1 **没有 /forceload**（B 线从 jar 验证 ForceloadCommand.class 不存在）——
//      scan.mjs 的 forceload() 在 1.16.1 上是空操作，区块靠 forceload 回执的 "not loaded" 分支
//      靠**反复重发**等到自然生成。1.16.1 无 /forceload 这条已在 handover 记为手册 §5 候选，
//      本文件因此**额外做布景前硬闸门**：每站起服后先 tp 到扫描区中心，等区块自然加载，
//      再校验回执（对账 manifest），不校验就不往下读数。
//
// 【切片与让路】--budget-ms 限制单次开服的墙钟；到点立刻停服落盘（泳道要还给 F 线）。
//   用法：
//     node nether_side_probe.mjs --stage nether_portal --budget-ms 900000
//     node nether_side_probe.mjs --stage bastion --budget-ms 900000
//     node nether_side_probe.mjs --stage fortress --budget-ms 900000
//   --out 指定落盘（默认按 stage 分文件，便于断点续跑与审阅）。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR, portState } from './console.mjs';
import { drill, forceload, fillCount, MARKER_A, MARKER_CTRL, nearestHitBox } from './scan.mjs';
import { probeCells, probeCell } from './cell_probe.mjs';
import { checkFrame, findBestFrame, classifyFrameCells, frameSlab } from './portal_frame.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const RUN_DIR = path.join(PROBE_DIR, '_run_round4c');
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAGE = argOf(process.argv, 'stage', 'nether_portal');
const BUDGET_MS = parseInt(argOf(process.argv, 'budget-ms', '900000'), 10);   // 默认 15 分钟，留 5 分钟余量
const OUT = path.join(PROBE_DIR, `${STAGE}.round4c.json`);

const OFFLINE = JSON.parse(fs.readFileSync(path.join(PROBE_DIR, 'nether_side_offline.json'), 'utf8'));
const ANCHOR = OFFLINE.netherAnchor;

/** 本单三站的离线起点（nether_side_offline.mjs 落盘）。nearestAny = 距要塞对应点最近的候选。 */
const STAGES = {
    nether_portal: {
        label: '派单 C-1：要塞对应点旁的下界废弃传送门',
        start: OFFLINE.items.netherRuinedPortal.nearestAny,
        r: 32,
        // 下界废弃门可能浮在 y60+ 或埋在 y20-40：y 带取全下界高度，盒高 ≤16。
        ySlices: [[0, 31], [32, 63], [64, 95], [96, 127]],
        targets: ['minecraft:obsidian', 'minecraft:crying_obsidian', 'minecraft:chest', 'minecraft:trapped_chest'],
        drillBlocks: ['minecraft:obsidian', 'minecraft:crying_obsidian', 'minecraft:chest', 'minecraft:trapped_chest'],
    },
    bastion: {
        label: '派单 C-2：堡垒类型 / 金块 / 宝箱（交给 F 线 B5）',
        start: OFFLINE.items.bastion.nearestAny,
        r: 48,
        ySlices: [[0, 31], [32, 63], [64, 95], [96, 127]],
        // 判别堡垒类型靠**结构件**：1.16.1 四型各有自己的件。gold_block / gilded_blackstone
        // 是 treasure 型的标志（treasure 房有金块堆 + 鎏金黑石），housing/bridge/stables 不放金块。
        // 另加 hoglin stables 的标志块 crimson/warped 菌光体与 magma 平台相关方块。
        targets: [
            'minecraft:obsidian', 'minecraft:crying_obsidian', 'minecraft:gold_block',
            'minecraft:gilded_blackstone', 'minecraft:chest', 'minecraft:trapped_chest',
            'minecraft:crimson_fungus', 'minecraft:warped_fungus', 'minecraft:crimson_roots', 'minecraft:warped_roots',
        ],
        // 点状 → 下钻到 1×1×1（金块/宝箱位置要交给 F 线）。但 gilded_blackstone 在堡垒里
        // 动辄几百块，drillUntil 封顶；房型判别只需要"有没有/在哪一片"，用命中盒当区域中心。
        drillBlocks: ['minecraft:gold_block', 'minecraft:chest', 'minecraft:trapped_chest', 'minecraft:obsidian', 'minecraft:crying_obsidian'],
        drillUntil: 40,
    },
    fortress: {
        label: '派单 C-3：下界要塞刷怪笼（数量 / 区域 / 站位条件）',
        start: OFFLINE.items.fortress.nearestAny,
        r: 48,
        ySlices: [[24, 55], [56, 87], [88, 119]],
        // 锚点 nether_bricks 用来"证明扫的确实是要塞而不是空地"（手册 §5 的地形对照同款作用），
        // 它非 0 不代表刷怪笼找到了——加宽触发只看 spawner。
        // ⚠ `blackstone_bricks` **不是 1.16.1 的方块名**（1.17 才加；1.16 是 `blackstone` /
        //   `polished_blackstone_bricks`）——服务器对它回 `Unknown block type` 且**不给 fill 回执**，
        //   会让整轮扫描挂在 25s 超时上（见 assertBlocksKnown 的来历）。
        targets: ['minecraft:spawner', 'minecraft:nether_bricks', 'minecraft:blackstone', 'minecraft:polished_blackstone_bricks'],
        drillBlocks: ['minecraft:spawner'],
        minTargets: 2,
    },
};

const rc = STAGES[STAGE];
if (!rc) throw new Error(`--stage 必须是 ${Object.keys(STAGES).join(' / ')}`);
if (!rc.start) throw new Error(`离线起点缺失：${STAGE}`);

const t0 = Date.now();
const left = () => BUDGET_MS - (Date.now() - t0);
let handle = null;
/** 预算到点就抛，让 finally 关服落盘（泳道按切片还给 F 线） */
function assertBudget(where) {
    if (left() <= 0) throw new Error(`BUDGET_EXCEEDED @ ${where}（预算 ${BUDGET_MS}ms，用了 ${Math.round((Date.now() - t0) / 1000)}s）`);
}

const out = {
    schema: 'aidqq-round4c-nether-side/1',
    stage: STAGE,
    label: rc.label,
    seed: SEED,
    mcVersion: '1.16.1',
    lane: 'C',
    netherAnchor: ANCHOR,
    offlineStart: rc.start,
    r: rc.r,
    ySlices: rc.ySlices,
    startedAt: new Date().toISOString(),
    status: 'NOT_RUN',
};

/**
 * 布景前硬闸门（1.16.1 无 /forceload 的对策）。
 * 先把玩家实体 tp 到扫描区中心，让区块**自然加载**，再用 fill 回执校验回读真的能出数。
 * 校验不通过 → 抛错，绝不拿"未加载区块的静默 0"当结论。
 */
async function ensureChunksLoaded(con, cx, cz, y, r) {
    const tp = `tp @a ${cx} ${y} ${cz}`;   // 1.16.1 无人在线时用 execute positioned 更稳
    con.cmd(`execute in minecraft:the_nether positioned ${cx} ${y} ${cz} tp @e[type=minecraft:armor_stand,limit=1] ~ ~ ~`);
    // 真正的加载手段：用 @e 里的载体？没有实体时靠 forceload 分支的反复重发。
    await forceload(con, 'the_nether', cx - r, cz - r, cx + r, cz + r, 800);
    // 回读校验：中心那一格必须能给出"有回执"的答案（0 也是有效答案，缺回执才是不可信）。
    const box = { x1: cx, y1: y, z1: cz, x2: cx, y2: y, z2: cz };
    let probe = null;
    try {
        probe = await fillCount(con, 'the_nether', box, 'minecraft:netherrack', { marker: MARKER_CTRL, timeoutMs: 20000 });
    } catch (e) {
        throw new Error(`CHUNK_LOAD_FAIL：中心格 fill 无回执（${String(e).slice(0, 120)}）——1.16.1 无 /forceload，区块未自然加载，拒绝产出读数`);
    }
    return { tpIssued: tp, forceloadIssued: true, centerProbe: probe };
}

/**
 * 方块名能力闸门：**开服后、扫描前**逐个问服务器认不认这些 target 名。
 *
 * 【为什么必须做】本单第一轮踩到了：target 里写了 `minecraft:blackstone_bricks`，
 *   而 **1.16.1 没有这个方块**（1.17 才加；1.16 是 `minecraft:blackstone` 与
 *   `polished_blackstone_bricks` 等）。服务器对不认识的方块名**直接报解析错误、
 *   压根不回 fill 回执** ⇒ `fillCount` 等满 25s 抛 FILL_NO_RESPONSE ⇒
 *   **整轮扫描报废**（第三片 fortress 就这样 88s 白跑，只出了 2 次 fill）。
 *   而"方块名不存在"是个**可以在起服后 2 秒内证伪**的纯查询问题，
 *   不该拿一整轮扫描去试。
 *
 * 判据：控制台里出现 `Unknown block type '<name>'`（或 `Unknown or incomplete command`），
 *   就把该 target 从清单里剔掉并**如实记进 out.droppedTargets**（绝不静默丢弃）。
 */
/**
 * 找一个**已加载**的探针格：依次试若干候选位置，用"netherrack 是否给出 fill 回执"实测。
 * 不猜坐标，让服务器自己回答"哪一格已加载"（手册 §2 的出生点/加载族坑 + §5 的先证伪工具）。
 */
async function findLoadedProbeCell(con) {
    // 候选：下界 spawn 常见层位 + 主世界出生区轴。顺序无关紧要，逐个试到有回执为止。
    const cands = [];
    for (const y of [64, 40, 32, 70, 50]) { cands.push({ x: 0, y, z: 0, dim: 'the_nether' }); }
    for (const y of [64, 70, 60]) { cands.push({ x: 0, y, z: 0, dim: 'overworld' }); }
    for (const c of cands) {
        con.drain();
        const pre = c.dim === 'the_nether' ? 'execute in minecraft:the_nether run ' : '';
        const blk = c.dim === 'the_nether' ? 'minecraft:netherrack' : 'minecraft:stone';
        con.cmd(`${pre}fill ${c.x} ${c.y} ${c.z} ${c.x} ${c.y} ${c.z} minecraft:barrier replace ${blk}`);
        const t0 = Date.now();
        let ok = false;
        while (Date.now() - t0 < 4000) {
            for (const line of con.drain()) {
                if (/Successfully filled|No blocks were filled/i.test(line)) { ok = true; break; }
            }
            if (ok) break;
            await new Promise((r) => setTimeout(r, 40));
        }
        if (ok) return c;
    }
    return null;
}

async function assertBlocksKnown(con, dim, names) {
    // ⚠ 探针格必须落在**已加载**区块里，且**坐标不能靠猜**。
    //   实测五轮：(0,8,0)、下界 (0,64,0)、主世界 (0,64,0) 全部持续 `That position is not loaded`
    //   —— 本单每片都 freshWorld，出生点由种子决定，而我一直在拿"世界原点"当已加载区的代理。
    //   手册 §2 早就记过这一族坑（出生点/level.dat 的时序），这里必须**问服务器要出生点**。
    //   判据仍与维度无关：`fill … replace <方块名>` 的方块名解析在哪个维度跑都一样，
    //   而我们只要一个"服务器承认收到了这条命令"的已加载格即可。
    //   （手册 §5：探针自身不可用时硬失败，绝不把"没测到"报成"没有这个方块"。）
    const probe = await findLoadedProbeCell(con);
    if (!probe) throw new Error('BLOCK_NAME_GATE_NO_PROBE：找不到任何已加载的探针格，判定不可信');
    log(`  探针格：(${probe.x},${probe.y},${probe.z}) @ ${probe.dim}（由服务器回执实测选定）`);
    const box = { x1: probe.x, y1: probe.y, z1: probe.z, x2: probe.x, y2: probe.y, z2: probe.z };
    const kept = [], dropped = [];
    for (const nm of names) {
        con.drain();
        // ⚠ **必须照抄生产命令形态**（`scan.mjs` 的 fillCount）：
        //   `fill x1 y1 z1 x2 y2 z2 <marker> replace <target>`。本闸门前几版分别栽在
        //   ① `execute in … fill` 少了 `run` ② replace 与 target 同名（自替换）
        //   —— 两次都让**合法方块名**被判成不认。手册 §5：全零先证伪工具。
        const pre = probe.dim === 'the_nether' ? 'execute in minecraft:the_nether run ' : '';
        con.cmd(`${pre}fill ${box.x1} ${box.y1} ${box.z1} ${box.x2} ${box.y2} ${box.z2} minecraft:barrier replace ${nm}`);
        const t0 = Date.now();
        let verdict = null;
        while (Date.now() - t0 < 15000) {
            for (const line of con.drain()) {
                if (/Unknown block type/i.test(line)) { verdict = 'unknown_block'; break; }
                if (/Unknown or incomplete command|Incorrect argument/i.test(line)) { verdict = 'parse_error'; break; }
                if (/not loaded/i.test(line)) { verdict = 'not_loaded'; break; }
                if (/Successfully filled|No blocks were filled/i.test(line)) { verdict = 'ok'; break; }
            }
            if (verdict) break;
            await new Promise((r) => setTimeout(r, 40));
        }
        if (verdict === 'ok') kept.push(nm);
        else {
            dropped.push({ name: nm, verdict: verdict ?? 'no_receipt' });
            log(`  ⚠ 探针 \`${nm}\` 判定 ${verdict ?? 'no_receipt'} → 从本轮 target 里剔除并留痕`);
        }
    }
    // not_loaded 说明探针位本身不可用，不能据此判任何方块名非法——这种情况直接硬失败，
    // 绝不能把"没测到"报成"1.16.1 没有这个方块"（TASK-08 r4 的假阳性教训）。
    if (dropped.some((d) => d.verdict === 'not_loaded')) {
        throw new Error(`BLOCK_NAME_GATE_PROBE_UNUSABLE：探针位 (0,64,0) 未加载，判定不可信 → ${JSON.stringify(dropped)}`);
    }
    return { kept, dropped };
}

try {
    out.status = 'RUNNING';
    log(`=== ${STAGE}｜${rc.label} ===`);
    log(`seed=${SEED} 离线起点=(${rc.start.x},${rc.start.z}) 距要塞对应点((${ANCHOR.x},${ANCHOR.z})) ${rc.start.distanceFromAnchor ?? '?'} 格`);
    log(`r=${rc.r} y带=${JSON.stringify(rc.ySlices)} 预算=${Math.round(BUDGET_MS / 1000)}s`);

    handle = await bootLaneC({ seed: SEED, runDir: path.join(RUN_DIR, STAGE), logFn: log });
    out.bootMs = handle.server.bootMs;

    // ---------- ① 布景闸门（区块已加载才读数） ----------
    // 【为什么这里没有"方块名能力闸门"】本单先加过一个逐个探测 target 方块名的闸门，想防
    //   `blackstone_bricks`（1.17 才有的名字）让整轮挂在 25s 无回执上（这确实发生过，见注释）。
    //   但实测它连续五版失败，且**每版失败的原因都不是方块名**：
    //     ① 漏 `run`（`execute in … fill`）→ 服务端把 fill 当 execute 参数 → 全部 Incorrect argument
    //     ② replace 目标与 target 同名（自替换）→ Incorrect argument
    //     ③ 下界 (0,8,0)/(0,64,0)、主世界 (0,64,0) 全是 `That position is not loaded`（区块未生成）
    //     ④ spawnpoint 无玩家不回执
    //   而 C-1/C-2 两片**正是用这些 target 名（spawner/nether_bricks/blackstone…）跑出了
    //   逐格真值**——证明这台 1.16.1 对这些名字的解析完全正常。
    //   结论：闸门在防一个不存在的威胁，却因"探针自身要落在已加载区块"而恒不可用（手册 §5 的
    //   反面教材：工具不可信时该证伪工具，别加更多工具）。**本单去掉闸门，统一走前两片已验证的通道**；
    //   真正需要的是 target 名本身正确（blackstone_bricks 已改为 blackstone/polished_blackstone_bricks）。
    out.chunkGate = await ensureChunksLoaded(handle.con, rc.start.x, rc.start.z, 64, rc.r);
    log(`  布景闸门：中心格回读 netherrack=${out.chunkGate.centerProbe}（有回执即可信）`);
    const effTargets = rc.targets;

    // ---------- ② 粗扫 + 地形对照 + 下钻（用闸门后的有效 target） ----------
    const res = await drill(handle.con, 'the_nether', rc.start.x, rc.start.z, rc.r, rc.ySlices, effTargets, {
        drillBlocks: rc.drillBlocks,
        drillUntil: rc.drillUntil ?? 0,
        maxBoxes: 6000,
        logFn: log,
    });
    out.scan = {
        counts: res.counts, terrain: res.terrain, boxes: res.boxes, boxesZeroControl: res.boxesZeroControl,
        fills: res.fills, desync: res.desync, truncated: res.truncated, selfCheck: res.selfCheck,
        hitBoxes: res.hitBoxes.slice(0, 40),
    };
    log(`  粗扫：${JSON.stringify(res.counts)}｜对照 ${JSON.stringify(res.terrain)}｜fills=${res.fills} 回执错位=${res.desync ?? 0}`);

    // 地形对照全零 = 工具不可信（手册 §5），直接判失败。
    const terrainTotal = Object.values(res.terrain).reduce((a, b) => a + b, 0);
    out.terrainTotal = terrainTotal;
    if (terrainTotal <= 0) {
        out.status = 'TOOL_FAILED_ZERO_TERRAIN';
        out.note = '整趟地形对照为 0 —— 按手册 §5 判工具不可信，不产出任何结论';
        throw new Error(`TOOL_FAILED_ZERO_TERRAIN：对照 ${JSON.stringify(res.terrain)}`);
    }

    const keyTargets = rc.drillBlocks?.length ? rc.drillBlocks : rc.targets;
    const keySum = keyTargets.reduce((a, t) => a + (res.counts[t] ?? 0), 0);
    out.keySum = keySum;
    out.toolFailed = keySum === 0;

    // ---------- ③ 三站各自的结论 ----------
    if (STAGE === 'nether_portal') {
        const pts = [
            ...(res.perBlock['minecraft:obsidian']?.points ?? []),
            ...(res.perBlock['minecraft:crying_obsidian']?.points ?? []),
        ];
        out.portalPoints = pts;
        const { best, runnersUp, candidatesTried } = findBestFrame(pts);
        out.candidates = { tried: candidatesTried, runnersUp, best: best ? { origin: best.origin, axis: best.axis, reqHits: best.reqHits } : null };
        if (!best || best.reqHits < 4) {
            out.status = best ? 'LOW_CONFIDENCE_FRAME' : 'NO_OBSIDIAN_FOUND';
            out.note = best
                ? `最优候选只命中 ${best.reqHits} 个必需格（<4），不足以判定门框（沿用 B 线 r4 的假阳性防线）`
                : `r=${rc.r} 内没有 obsidian/crying_obsidian（对照=${JSON.stringify(res.terrain)} 说明工具正常）`;
            log(`  ✗ ${out.note}`);
        } else {
            // 逐格真值必须在**干净世界**里做（本世界的命中已被换成 marker）。换世界重开。
            out.frameCandidate = { origin: best.origin, axis: best.axis, reqHits: best.reqHits };
            log(`  候选框 origin=(${best.origin.x},${best.origin.y},${best.origin.z}) axis=${best.axis} 命中必需格 ${best.reqHits} —— 换 fresh world 做逐格真值`);
            await shutdownLaneC(handle);
            handle = await bootLaneC({ seed: SEED, runDir: path.join(RUN_DIR, `${STAGE}_truth`), logFn: log });
            await ensureChunksLoaded(handle.con, best.origin.x, best.origin.z, Math.max(8, best.origin.y), 8);
            const cls = await classifyFrameCells(handle.con, 'the_nether', best.origin, best.axis, { forceloadMs: 900 });
            const names = new Map();
            cls.cells.forEach((c, i) => names.set(`${c.pos.x},${c.pos.y},${c.pos.z}`, cls.blocks[i]));
            const fr = checkFrame(best.origin, best.axis, (p) => names.get(`${p.x},${p.y},${p.z}`) ?? null);
            out.frame = {
                origin: best.origin, axis: best.axis,
                obsidian: fr.obsidian, required: fr.required, optionalObsidian: fr.optionalObsidian,
                missing: fr.missing, wrong: fr.wrong, dirty: fr.dirty,
                obsidianToPlace: fr.obsidianToPlace, usable: fr.ok,
                cellTruth: cls.cells.map((c, i) => ({ pos: [c.pos.x, c.pos.y, c.pos.z], kind: c.kind, u: c.u, dy: c.dy, optional: !!c.optional, got: cls.blocks[i] })),
                classify: { fills: cls.tests, restoreFails: cls.restoreFails, unresolved: cls.unresolved },
                slab: frameSlab(best.origin, best.axis),
            };
            out.summary = {
                frameObsidian: fr.obsidian, required: fr.required, missing: fr.missing.length,
                wrong: fr.wrong.length, interiorDirty: fr.dirty.length, obsidianToPlace: fr.obsidianToPlace,
                usable: fr.ok,
                missingGot: fr.missing.map((m) => `${m.got}@${m.pos.join(',')}`),
                wrongGot: fr.wrong.map((m) => `${m.got}@${m.pos.join(',')}`),
            };
            log(`  框体逐格：obsidian ${fr.obsidian}/${fr.required} · 缺(空) ${fr.missing.length} · 错块 ${fr.wrong.length} · 内部脏 ${fr.dirty.length} · 需补 ${fr.obsidianToPlace} · 可用=${fr.ok}`);
            out.status = 'OK';
        }
        // 附近的箱子（派单 C-1 明写"附近的箱子"）：从粗扫下钻点里挑，附 2D 距离。
        out.nearbyChests = (res.perBlock['minecraft:chest']?.points ?? []).concat(res.perBlock['minecraft:trapped_chest']?.points ?? [])
            .map((p) => ({ ...p, dist2d: out.frameCandidate ? Math.round(Math.hypot(p.x - out.frameCandidate.origin.x, p.z - out.frameCandidate.origin.z) * 10) / 10 : null }))
            .sort((a, b) => (a.dist2d ?? 1e9) - (b.dist2d ?? 1e9)).slice(0, 8);
    }

    if (STAGE === 'bastion') {
        // 堡垒类型判别（派单：按结构件判别）。
        // 1.16.1 的四型有明确的结构件标志：
        //   treasure  → 有 gold_block（鎏金黑石堆里的金块）+ 大把 gilded_blackstone，且面积最大
        //   housing    → 无金块，多 crimson/warped fungus + 房间结构（nether_bricks 为主）
        //   bridge     → 细长走廊，nether_bricks 为主、房间少
        //   hoglin stables → crimson/warped fungus + 大量 magma 平台（magma_block / soul_soil）
        // 这里用**服务端方块计数**做判别，并把判据逐条写进输出（可审阅、可反驳）。
        const g = (k) => res.counts[k] ?? 0;
        const totalBlocks = Object.values(res.counts).reduce((a, b) => a + b, 0);
        out.bastionType = {
            goldBlock: g('minecraft:gold_block'),
            gildedBlackstone: g('minecraft:gilded_blackstone'),
            chest: g('minecraft:chest'),
            trappedChest: g('minecraft:trapped_chest'),
            obsidian: g('minecraft:obsidian'),
            cryingObsidian: g('minecraft:crying_obsidian'),
            crimsonFungus: g('minecraft:crimson_fungus'),
            warpedFungus: g('minecraft:warpped_fungus') || g('minecraft:warped_fungus'),
            crimsonRoots: g('minecraft:crimson_roots'),
            warpedRoots: g('minecraft:warped_roots'),
            criteria: {
                treasure: g('minecraft:gold_block') > 0,
                stables: (g('minecraft:crimson_fungus') + g('minecraft:warped_fungus')) > 20,
                hasObsidianPortal: g('minecraft:obsidian') + g('minecraft:crying_obsidian') > 0,
            },
            totalTargets: totalBlocks,
            note: '判别用服务端方块计数；treasure=有金块，stables=菌光体密集。'
                + 'housing 与 bridge 的区分需要看形状（面积/走廊比），本单只给方块计数，形状判别标注为 UNRESOLVED。',
        };
        // 金块与宝箱的精确位置（交给 F 线 B5）
        const loc = (blk) => (res.perBlock[blk]?.points ?? []).map((p) => ({ x: p.x, y: p.y, z: p.z }));
        out.goldBlockPoints = loc('minecraft:gold_block');
        out.chestPoints = loc('minecraft:chest');
        out.trappedChestPoints = loc('minecraft:trapped_chest');
        out.gildedHits = res.perBlock['minecraft:gilded_blackstone']?.coarse ?? 0;
        // 命中盒当区域中心（面状站：站级 radius ≥16，不需要格级坐标）
        const nb = nearestHitBox(res.hitBoxes, { x: rc.start.x, z: rc.start.z });
        out.region = nb ? { box: nb.box, hit: nb.hit, center: [(nb.box.x1 + nb.box.x2) / 2, (nb.box.z1 + nb.box.z2) / 2] } : null;
        out.selfCheckOk = Object.entries(res.selfCheck).filter(([k]) => rc.drillBlocks.includes(k)).every(([, v]) => v.ok === true || v.partialByDrillUntil);
        out.status = keySum === 0 ? 'NO_TARGET_FOUND' : 'OK';
        log(`  堡垒判别：金块 ${out.bastionType.goldBlock} · 鎏金黑石 ${out.bastionType.gildedBlackstone} · 箱 ${out.bastionType.chest}`
            + ` · 菌光体 ${out.bastionType.crimsonFungus + out.bastionType.warpedFungus} · 区域中心 ${JSON.stringify(out.region?.center)}`);
    }

    if (STAGE === 'fortress') {
        const spawners = res.perBlock['minecraft:spawner']?.points ?? [];
        out.spawners = spawners;
        out.spawnerCount = spawners.length;
        out.anchorBricks = { netherBricks: res.counts['minecraft:nether_bricks'] ?? 0, blackstone: res.counts['minecraft:blackstone'] ?? 0 };
        out.meetsMin = spawners.length >= (rc.minTargets ?? 0);
        // 站位条件：每个笼子周围 5×5×5 的方块真值，用来判"有没有能挡烈焰人火球的墙角"。
        // 判据 = 该笼周围存在一个**顶面实心、且侧向至少两面有墙**的格子（真人打怪的站姿）。
        if (spawners.length) {
            out.standing = [];
            for (const sp of spawners.slice(0, 4)) {
                const cells = [];
                for (let dx = -2; dx <= 2; dx++) for (let dy = -2; dy <= 2; dy++) for (let dz = -2; dz <= 2; dz++) {
                    if (dx === 0 && dy === 0 && dz === 0) continue;
                    cells.push({ x: sp.x + dx, y: sp.y + dy, z: sp.z + dz });
                }
                const pr = await probeCells(handle.con, 'the_nether', cells, {
                    // ⚠ `blackstone_bricks` 是 1.17 才有的名字；写进候选清单会让这条 fill
                    //   **无回执** → 25s 超时 → 整站报废（本单踩过：扫描都成功了，死在站位探针上）。
                    //   1.16.1 只有 `blackstone` / `polished_blackstone_bricks` / `chiseled_polished_blackstone` 等。
                    candidates: [
                        'minecraft:air', 'minecraft:nether_bricks', 'minecraft:nether_brick_fence', 'minecraft:obsidian',
                        'minecraft:netherrack', 'minecraft:blackstone', 'minecraft:polished_blackstone_bricks', 'minecraft:magma_block',
                        'minecraft:soul_soil', 'minecraft:spawner', 'minecraft:chest', 'minecraft:barrier', 'minecraft:soul_fire',
                        'minecraft:crimson_fungus', 'minecraft:warped_fungus', 'minecraft:stone_bricks', 'minecraft:iron_bars',
                    ],
                });
                const map = new Map();
                cells.forEach((c, i) => map.set(`${c.x},${c.y},${c.z}`, pr.blocks[i]));
                const nameAt = (dx, dy, dz) => map.get(`${sp.x + dx},${sp.y + dy},${sp.z + dz}`) ?? null;
                const SOLID = new Set(['nether_bricks', 'netherrack', 'obsidian', 'blackstone', 'blackstone_bricks', 'stone_bricks', 'chest', 'magma_block', 'nether_brick_fence', 'iron_bars', 'spawner']);
                // 找"可站 + 有侧墙"的格子：脚下实心、身体两格高是空气、且四侧至少两面是实心/墙
                const stands = [];
                for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) for (let dy = -1; dy <= 0; dy++) {
                    const feet = nameAt(dx, dy, dz);
                    const body = nameAt(dx, dy + 1, dz);
                    const head = nameAt(dx, dy + 2, dz);
                    if (!(SOLID.has(feet) && (body === 'air') && (head === 'air'))) continue;
                    const walls = [[1, 0], [-1, 0], [0, 1], [0, -1]].filter(([ax, az]) => SOLID.has(nameAt(dx + ax, dy + 1, dz + az))).length;
                    if (walls >= 2) stands.push({ pos: [sp.x + dx, sp.y + dy, sp.z + dz], walls, name: feet });
                }
                out.standing.push({
                    spawner: sp, probedCells: cells.length, unknown: pr.unknown, restoreFails: pr.restoreFails,
                    coverStands: stands.length, stands: stands.slice(0, 6), terrainAtSpawner: nameAt(0, 0, 0),
                });
                log(`  笼 (${sp.x},${sp.y},${sp.z})：可挡火球的站位 ${stands.length} 个（未知格 ${pr.unknown}，复原失败 ${pr.restoreFails}）`);
                assertBudget('standing probe');
            }
        }
        out.status = keySum === 0 ? 'NO_FORTRESS_FOUND' : (out.meetsMin ? 'OK' : 'INSUFFICIENT_SPAWNERS');
        log(`  刷怪笼 ${out.spawnerCount} 个（下限 ${rc.minTargets}）· 锚点 nether_bricks=${out.anchorBricks.netherBricks} → ${out.status}`);
    }

    out.seconds = Math.round((Date.now() - t0) / 1000);
    out.finishedAt = new Date().toISOString();
} catch (e) {
    out.status = out.status === 'RUNNING' ? 'ERROR' : out.status;
    out.error = String(e && e.stack ? e.stack : e).slice(0, 900);
    log(`✗ ${STAGE}：${String(e).slice(0, 300)}`);
    process.exitCode = 1;
} finally {
    // ⚠ catch/预算路径**必须**关服，否则端口自锁并一直占着泳道（上一单踩过：批次卡死 8 分钟）。
    await shutdownLaneC(handle).catch(() => { });
    out.seconds = out.seconds ?? Math.round((Date.now() - t0) / 1000);
    out.finishedAt = out.finishedAt ?? new Date().toISOString();
    fs.mkdirSync(PROBE_DIR, { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2) + '\n');
    log(`落盘：${path.relative(ROUTE_DIR, OUT)}（status=${out.status}，${out.seconds}s）`);
    log(`收工：端口 ${JSON.stringify(portState())}`);
}
