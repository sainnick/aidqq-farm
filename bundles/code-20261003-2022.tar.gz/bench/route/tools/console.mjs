// console.mjs — MC-ROUTE-02：泳道 C 服务器生命周期 + stdin 控制台通道 + 心跳排队
//
// 三个约束同时成立（这是本文件存在的全部理由）：
//   1. **命令一律走服务器 stdin 控制台**（手册 §2：RCON 会毒化服务进程；SEED-03 R3 同样结论）。
//      计数用 `fill <box> <marker> replace <block>` 的返回行（"Successfully filled N blocks" /
//      "No blocks were filled"），即**服务器权威真值**，比客户端扫描强（无同步问题、原始返回可留档）。
//   2. **泳道按心跳排队共用**（手册 §9：泳道只认名字；归属看 `.lane-owners` 心跳，不能只看端口空闲）。
//      本单与开发线 E（END-01）共用泳道 C：起服前既查端口、也查心跳；端口空但心跳新鲜且归属**别的**
//      活 runner 时，一律排队等待，不抢。
//   3. **复用 _lib 的起停服**（只读引用）：bootServerWithRetry / stopServer / freshWorld 内部已经
//      调 registerChild/unregisterChild → 心跳由 _lib 统一维护，本文件不自己造心跳。
//
// 说明：本文件不修改 _lib 任何文件（手册 §9：_lib 只能新增文件，改已有文件要先报告）。

import { spawnSync } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { argOf, log, waitFreeMem, freshWorld, bootServerWithRetry, stopServer } from '../../stages/_lib/runner_core.mjs';
import { ownerTable, liveOwnerPids, procInfo, netstatListeners, MEM_PER_LANE_MB } from '../../stages/_lib/preflight.mjs';

export const ROUTE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const ROOT = path.resolve(ROUTE_DIR, '../..');

const TEMPLATE_DIR = path.resolve(process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161'));
export const LANE = {
    name: 'C', idx: 2,
    dir: `${TEMPLATE_DIR}_laneC`,
    serverPort: 25568, rconPort: 25578,
    username: 'RouteBotC',
};
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
export const JAVA = process.env.MC_BENCH_JAVA || (() => {
    const jdkRoot = path.join(ROOT, 'experiments', 'mc1161-gate', 'jdk');
    const hit = fs.readdirSync(jdkRoot).find((d) => fs.existsSync(path.join(jdkRoot, d, 'bin', 'java.exe')));
    if (!hit) throw new Error('找不到便携 JDK11（手册 §2）');
    return path.join(jdkRoot, hit, 'bin', 'java.exe');
})();
export const MC_VERSION = argOf(process.argv, 'mc-version', process.env.MC_BENCH_VERSION || '1.16.1');

/** 泳道 C 是否被"别的活会话"占着：端口占用 或 心跳新鲜且归属他人。 */
export function laneCBusy() {
    const listeners = netstatListeners();
    const portBusy = [LANE.serverPort, LANE.rconPort].some((pt) => (listeners[String(pt)] ?? []).length > 0);
    const owners = liveOwnerPids(new Set(procInfo().map((p) => p.pid)));
    const rec = ownerTable()['server-1161_lanec'];
    const fresh = rec && rec.ageMs != null && rec.ageMs <= 20000;
    const foreignRunner = fresh && owners.has(Number(rec.runnerPid)) && Number(rec.runnerPid) !== process.pid;
    const reason = portBusy ? 'ports-busy' : foreignRunner ? `heartbeat:runner=${rec.runnerPid}` : null;
    return { busy: portBusy || !!foreignRunner, portBusy, foreignRunner, reason, owner: rec ?? null };
}

/** 按心跳排队：直到端口空 + 无他人新鲜心跳 + 空闲内存过护栏。返回排队毫秒。 */
export async function waitForLaneC({ minFreeMb = 2560, timeoutMs = 30 * 60 * 1000, logFn = log } = {}) {
    const t0 = Date.now();
    let lastMsg = 0;
    for (;;) {
        const st = laneCBusy();
        const freeMB = Math.round(os.freemem() / 1048576);
        if (!st.busy && freeMB >= minFreeMb) {
            const waited = Date.now() - t0;
            if (waited > 1000) logFn(`lane C 获得：排队 ${(waited / 1000).toFixed(0)}s（free=${freeMB}MB）`);
            return waited;
        }
        if (Date.now() - t0 > timeoutMs) throw new Error(`lane C 排队超时 ${timeoutMs / 60000}min：${JSON.stringify(st)} free=${freeMB}MB`);
        if (Date.now() - lastMsg > 30000) {
            logFn(`lane C 排队中：${st.busy ? st.reason : `内存 ${freeMB}MB < ${minFreeMb}MB`}（不抢 E 线，按心跳让路）`);
            lastMsg = Date.now();
        }
        await new Promise((r) => setTimeout(r, 3000));
    }
}

/** 泳道 C 目录装配（只碰 _laneC）——与 fullrun/run_bench.mjs 同款，不调 buildLanes（那会改写 B 的配置）。 */
export function ensureLaneC() {
    const sp = path.join(LANE.dir, 'server.properties');
    if (!fs.existsSync(sp)) {
        log(`lane C: 从模板派生 ${LANE.dir}`);
        fs.mkdirSync(LANE.dir, { recursive: true });
        fs.copyFileSync(path.join(TEMPLATE_DIR, JAR_NAME), path.join(LANE.dir, JAR_NAME));
        const eula = path.join(TEMPLATE_DIR, 'eula.txt');
        if (fs.existsSync(eula)) fs.copyFileSync(eula, path.join(LANE.dir, 'eula.txt'));
        const lines = fs.readFileSync(path.join(TEMPLATE_DIR, 'server.properties'), 'utf8')
            .split(/\r?\n/)
            .map((l) => (l.startsWith('server-port=') ? `server-port=${LANE.serverPort}`
                : l.startsWith('rcon.port=') ? `rcon.port=${LANE.rconPort}` : l))
            .filter((l) => !l.startsWith('level-seed='));
        fs.writeFileSync(sp, lines.join('\n') + '\n');
    }
    if (!fs.existsSync(path.join(LANE.dir, JAR_NAME))) throw new Error(`lane C 缺 jar：${JAR_NAME}`);
    return { ...LANE, jarPath: path.join(LANE.dir, JAR_NAME), java: JAVA };
}

/**
 * stdin 控制台通道：从服务器日志增量对齐读回执。
 * （沿用 r3_fill.mjs 的 ConsoleChannel：Windows 上对 java 追加中的句柄 statSync().size 恒陈旧，
 *  必须整读日志 + 行数游标。）
 */
export class Console {
    constructor(child, logPath) {
        this.child = child;
        this.logPath = logPath;
        this.consumed = 0;
        this.child.stdin.on('error', () => { /* 服务器死亡时 EPIPE，吞掉，用 exitCode 判 */ });
    }
    cmd(str) {
        if (this.child.exitCode !== null) throw new Error(`server died rc=${this.child.exitCode}`);
        this.child.stdin.write(String(str) + '\n');
    }
    /** 抽掉还没读过的控制台回执行 */
    drain() {
        let txt = '';
        try { txt = fs.readFileSync(this.logPath, 'utf8'); } catch { return []; }
        const all = txt.split('\n');
        const full = all.slice(0, -1); // 最后一段可能是半行
        if (full.length <= this.consumed) return [];
        const fresh = full.slice(this.consumed);
        this.consumed = full.length;
        const out = [];
        for (const l of fresh) {
            const m = l.match(/^\[\d\d:\d\d:\d\d\] \[[^\]]+\]: (.*)\r?$/);
            out.push(m ? m[1] : (l.trim() || null));
        }
        return out.filter(Boolean);
    }
}

/** 起服 + 排空控制台，返回 {lane, server, console}。server 已在 _lib 登记心跳。 */
export async function bootLaneC({ seed, runDir, xmx = '1G', minFreeMb = 2560, logFn = log }) {
    await waitForLaneC({ minFreeMb, logFn });
    const lane = ensureLaneC();
    freshWorld(lane, seed);
    fs.mkdirSync(runDir, { recursive: true });
    logFn(`lane C: fresh world seed=${seed}，起服（xmx=${xmx} free=${(os.freemem() / 1048576).toFixed(0)}MB）`);
    const server = await bootServerWithRetry(lane, runDir, xmx, logFn, 3);
    const serverLog = path.join(runDir, 'server.log');
    // 起服期回执先排空，避免把 "Done (...)" 之类的行误当成命令回执
    await new Promise((r) => setTimeout(r, 1500));
    const con = new Console(server.child, serverLog);
    con.drain();
    logFn(`lane C: server up in ${(server.bootMs / 1000).toFixed(0)}s`);
    return { lane, server, con, runDir };
}

/** 停服（把 bootLaneC 的返回原样传进来）。⚠ stopServer(lane, server) 的第二个参数
 *  必须是 bootServerWithRetry 的产物（内部有 .child），不能是包装对象——
 *  传错会在 runner_core 里 `server.child` 得到 undefined 而崩，且崩在写 stop 之前 → 服务器泄漏。 */
export async function shutdownLaneC(handle) {
    if (!handle) return;
    await stopServer(handle.lane ?? LANE, handle.server);
}

/** 端口复核（收工用） */
export function portState() {
    const l = netstatListeners();
    return {
        server: l[String(LANE.serverPort)] ?? [],
        rcon: l[String(LANE.rconPort)] ?? [],
        free: !(l[String(LANE.serverPort)] ?? []).length && !(l[String(LANE.rconPort)] ?? []).length,
    };
}
