// frame_cell_truth.mjs — 框体逐格真值的**最小诊断**（把"世界到底是什么"和"读法对不对"分开）
//
// 为什么需要它：本单在 classifyFrameCells 上测到同一个 4×5×1 盒子里，
//   阶段 A（r=24 扫描 + 下钻）读到 obsidian 9 / crying 1 —— 与 B 线 r3 完全一致；
//   阶段 B（干净世界里的整盒分类）却读到 obsidian 0 / netherrack 9。
//   而**空气格两者完全一致**（几何、盒子都对）。所以问题要么在"读法"，要么在"回执配对"。
//
// 本文件把两者分开：
//   ① **慢速逐候选计数**：每个候选之间 sleep 500ms，排除"回执迟到被当成本条答案"的配对竞态
//      （ROUTE-02 §4.3 记过的那一类：自检成对通过不等于没串位）。
//   ② **逐格非破坏性判据**（2 次 fill 一次命中一次复原）：3 个抽样格，直接问"这一格是谁"。
//   ③ 最后再做一次整盒分类（与 classifyFrameCells 同款，但**慢速**），对比 ① 的结果。
//
// 用法：node frame_cell_truth.mjs [--seed <S>] [--origin 180,77,355] [--axis z]

import path from 'path';
import { argOf, log } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, portState, ROUTE_DIR } from './console.mjs';
import { fillCount } from './scan.mjs';
import { probeCell } from './cell_probe.mjs';
import { frameCells, interiorCells, frameSlab, checkFrame, classifyFrameCells, FRAME_SCAN_CANDIDATES } from './portal_frame.mjs';

const SEED = argOf(process.argv, 'seed', '-8839485814800629942');
const [OX, OY, OZ] = argOf(process.argv, 'origin', '180,77,355').split(',').map(Number);
const AXIS = argOf(process.argv, 'axis', 'z');
const origin = { x: OX, y: OY, z: OZ };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let handle = null;
try {
    log(`框体真值诊断 seed=${SEED} origin=(${OX},${OY},${OZ}) axis=${AXIS}`);
    handle = await bootLaneC({ seed: SEED, runDir: path.join(ROUTE_DIR, 'probe', '_run_frametruth'), logFn: log });
    const con = handle.con;
    const slab = frameSlab(origin, AXIS);
    log(`slab = ${JSON.stringify(slab)}（${(slab.x2 - slab.x1 + 1) * (slab.y2 - slab.y1 + 1) * (slab.z2 - slab.z1 + 1)} 格）`);

    // ① **先做非破坏性的逐格判据**（2 fill/候选，命中即复原）——这是"世界到底是什么"的地面真值。
    //    ⚠ 必须排在破坏性计数**前面**：下面 ② 的 fill 会把整片 slab 换成 marker。
    log('① 逐格非破坏性判据（2 fill/候选，命中即复原）');
    const allCells = [...frameCells(origin, AXIS), ...interiorCells(origin, AXIS)];
    const truth = new Map();
    for (const c of allCells) {
        const r = await probeCell(con, 'overworld', c.pos, [
            'minecraft:obsidian', 'minecraft:crying_obsidian', 'minecraft:netherrack',
            'minecraft:lava', 'minecraft:bedrock', 'minecraft:barrier', 'minecraft:command_block', 'minecraft:air',
        ]);
        truth.set(`${c.pos.x},${c.pos.y},${c.pos.z}`, r.hit ? r.hit.replace(/^minecraft:/, '') : null);
        log(`   (${c.pos.x},${c.pos.y},${c.pos.z}) ${c.kind.padEnd(8)} → ${r.hit ?? '（候选清单外）'}（${r.tests} fill，复原=${r.restoreOk}）`);
        await sleep(120);
    }
    const truthCounts = {};
    for (const v of truth.values()) truthCounts[v ?? 'unknown'] = (truthCounts[v ?? 'unknown'] ?? 0) + 1;
    log(`   逐格统计：${JSON.stringify(truthCounts)}`);
    const frTruth = checkFrame(origin, AXIS, (p) => truth.get(`${p.x},${p.y},${p.z}`) ?? null);
    log(`   逐格判据给出的框体读数：obsidian ${frTruth.obsidian}/${frTruth.required} · 缺(空) ${frTruth.missing.length} · 错块 ${frTruth.wrong.length} · 内部脏 ${frTruth.dirty.length} · 需补 ${frTruth.obsidianToPlace}`);

    // ② 整盒分类（生产路径）——与 ① 的逐格判据对照
    log('\n② 整盒分类 classifyFrameCells（生产路径，含候选间清场 + FIFO 回执配对）');
    const cls = await classifyFrameCells(con, 'overworld', origin, AXIS, { logFn: null });
    const nameOf = (p) => {
        const i = cls.cells.findIndex((c) => c.pos.x === p.x && c.pos.y === p.y && c.pos.z === p.z);
        return i < 0 ? null : cls.blocks[i];
    };
    const fr = checkFrame(origin, AXIS, nameOf);
    log(`   框内 obsidian ${fr.obsidian}/${fr.required} · 缺(空) ${fr.missing.length} · 错块 ${fr.wrong.length} · 内部脏 ${fr.dirty.length} · 需补 ${fr.obsidianToPlace}`);
    log(`   fills=${cls.tests} restoreFails=${cls.restoreFails} unresolved=${cls.unresolved}`);
    let mismatch = 0;
    cls.cells.forEach((c, i) => {
        const a = truth.get(`${c.pos.x},${c.pos.y},${c.pos.z}`) ?? 'unknown';
        const b = cls.blocks[i] ?? 'unknown';
        if (a !== b) { mismatch++; log(`   ❌ 不一致 (${c.pos.x},${c.pos.y},${c.pos.z}) ${c.kind}: 逐格=${a} vs 整盒=${b}`); }
    });
    log(`   逐格对账：${cls.cells.length} 格中不一致 ${mismatch} 处`);

    // ③ 慢速逐候选计数（**破坏性，放最后**；每条之间 sleep 500ms 排除回执竞态）
    log('\n③ 慢速逐候选计数（破坏性，只作独立旁证）');
    const slow = [];
    for (const c of ['minecraft:obsidian', 'minecraft:crying_obsidian', 'minecraft:netherrack', 'minecraft:lava', 'minecraft:bedrock', 'minecraft:structure_void', 'minecraft:barrier', 'minecraft:air']) {
        const n = await fillCount(con, 'overworld', slab, c, { marker: 'minecraft:structure_void' });
        slow.push({ block: c, n });
        log(`   ${c} → ${n}`);
        await sleep(500);
    }
    log(`\n与 ① 对照：${JSON.stringify(slow.map((s) => [s.block.replace('minecraft:', ''), s.n]))}`);
} catch (e) {
    log(`✗ 失败：${e && e.stack ? e.stack : e}`);
    process.exitCode = 1;
} finally {
    await shutdownLaneC(handle);
    log(`收工：端口 ${JSON.stringify(portState())}`);
}
