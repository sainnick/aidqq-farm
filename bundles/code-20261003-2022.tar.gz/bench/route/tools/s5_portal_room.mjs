// s5_portal_room.mjs — ROUND7-C：**S5_stronghold_room 末地门室预勘**（纯离线，存档解析器只读）
//
// 【三个要回答的问题】（派单原话）
//   ① 门室 12 个框里**已有末影之眼**的个数
//   ② 门室**是否有暴露面**，并连到**可走的洞穴/走廊**
//   ③ **从要塞外最近的可进入点**
//
// 【为什么眼睛能从存档读出来，而不是要开服查】
//   末影之眼是**世界生成时定死**的：`EndPortalFrameFeature` 对每个框用 1/23 的概率决定
//   `eye=true`，状态直接写进区块的 BlockStates.Properties。⇒ 离线读 `.mca` 就是真值，
//   **不需要也不应该**用 `data get entity` / `execute` 去查（本单因此完全不开服）。
//   ⚠ 判 `eye` 必须读 **props**（`blockState().props.eye`），不是方块名 —— 12 个框是同一个方块名。
//
// 【"可进入点"怎么定义才算数】手册 §7 的公平口径是"只能选看得见或有暴露面的"，
//   而"进得去"要回答的是**几何连通**：从门室那团空气出发，穿过最薄的**实体层**，
//   第一次碰到别的空气分量，那个出口在哪、要挖几格。
//   ⚠ **空气 6 连通 ≠ 能走**（楼梯/台阶/栅栏会把玩家走得通的房间切成两团），
//   所以本单**同时**给两件事：① 空气层面的连通结论 ② 最小实体层厚度（挖墙代价），
//   并把边界上挡路的方块名列出来（门 vs 建材），让"能不能进"有可审的物证。
//
// 只读。不改 route。

import fs from 'fs';
import path from 'path';
import { openWorld } from './region_reader.mjs';
import { AIRLIKE, BUILD_HEIGHT } from './visibility_audit.mjs';

/** 1.16.1 要塞建材（`StrongholdPieces` 的调色板）。用来分"要塞里的空气"和"外面的自然洞穴"。 */
const STRONGHOLD_MATERIALS = new Set([
    'stone_bricks', 'cracked_stone_bricks', 'mossy_stone_bricks', 'chiseled_stone_bricks',
    'infested_stone_bricks', 'stone_brick_slab', 'stone_brick_stairs', 'stone_brick_wall',
    'end_portal_frame', 'end_portal', 'spawner', 'mob_spawner', 'iron_bars', 'tnt', 'ladder',
]);
const argOf = (a, n, d) => { const i = a.indexOf(`--${n}`); return (i >= 0 && a[i + 1] && !a[i + 1].startsWith('--')) ? a[i + 1] : d; };
const argv = process.argv.slice(2);
const WORLD = argOf(argv, 'world', 'D:/AI斗蛐蛐/bench/route/probe/_s5_s5');
const OUT = argOf(argv, 'out', 'D:/AI斗蛐蛐/bench/route/probe/s5_portal_room.round7c.json');
const CX = parseInt(argOf(argv, 'cx', '1328'), 10);
const CZ = parseInt(argOf(argv, 'cz', '1152'), 10);
const RADIUS = parseInt(argOf(argv, 'radius', '24'), 10);
const MARGIN = parseInt(argOf(argv, 'margin', '24'), 10);

if (!fs.existsSync(path.join(WORLD, 'region'))) {
    console.error(`✗ 没有世界存档：${WORLD}（先跑 s5_worldgen.mjs）`);
    process.exit(2);
}
const world = openWorld(WORLD);
const DIM = 'overworld';
const YMAX = BUILD_HEIGHT.overworld - 1;
const box = { x1: CX - RADIUS - MARGIN, y1: 0, z1: CZ - RADIUS - MARGIN, x2: CX + RADIUS + MARGIN, y2: YMAX, z2: CZ + RADIUS + MARGIN };
const key = (x, y, z) => `${x},${y},${z}`;
const get = (x, y, z) => {
    if (x < box.x1 || x > box.x2 || y < box.y1 || y > box.y2 || z < box.z1 || z > box.z2) return 'unknown';
    return world.blockAt(x, y, z, DIM);
};
const getState = (x, y, z) => world.blockState(x, y, z, DIM);
const isAir = (x, y, z) => AIRLIKE.has(get(x, y, z));
const isSolid = (x, y, z) => { const b = get(x, y, z); return b !== 'unknown' && !AIRLIKE.has(b) && b !== 'water' && b !== 'lava'; };
const N6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

const out = { schema: 'aidqq-s5-portal-room/1', at: new Date().toISOString(), world: WORLD, center: [CX, CZ], radius: RADIUS, box };

// ---------------------------------------------------------------- 读数健康闸门（手册 §5）
// "框数 = 0"有两种完全不同的成因：① 这一片真的没有要塞 ② 存档里这一片根本没生成。
// 不把它们分开就会把"没读到"报成"不需要处理"（假阳性）。⇒ 先量**盘内有多少格读得到**。
let _read = 0, _unread = 0;
for (let y = 0; y <= YMAX; y += 4) for (let z = box.z1; z <= box.z2; z += 4) for (let x = box.x1; x <= box.x2; x += 4) {
    if (get(x, y, z) === 'unknown') _unread++; else _read++;
}
out.readHealth = {
    sampled: _read + _unread, readable: _read, unreadable: _unread,
    readableRatio: Math.round((_read / Math.max(1, _read + _unread)) * 1000) / 10,
    toolFailed: _read === 0,
    note: _read === 0 ? '盘内一格都读不到 ⇒ 存档里这一片从未生成，不能报"0 个框"' : '盘内可读 ⇒ 下面的 0 才是真 0',
};
if (_read === 0) {
    out.VERDICT = 'INCONCLUSIVE_TOOL_FAILED';
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
    console.error(`✗ INCONCLUSIVE_TOOL_FAILED：盘内抽样 ${_read + _unread} 格全部读不到（存档里这一片没生成）。已写 ${OUT}`);
    process.exit(3);
}

// ---------------------------------------------------------------- ① 12 个框 + 末影之眼
const frames = [];
for (let y = 0; y <= YMAX; y++) for (let z = CZ - RADIUS; z <= CZ + RADIUS; z++) for (let x = CX - RADIUS; x <= CX + RADIUS; x++) {
    if ((x - CX) ** 2 + (z - CZ) ** 2 > RADIUS * RADIUS) continue;
    const st = getState(x, y, z);
    if (st.name !== 'end_portal_frame') continue;
    frames.push({ xyz: [x, y, z], props: st.props, eye: st.props?.eye === true });
}
out.frames = {
    found: frames.length,
    withEye: frames.filter((f) => f.eye).length,
    withoutEye: frames.filter((f) => !f.eye).length,
    list: frames.map((f) => ({ xyz: f.xyz, eye: f.eye, props: f.props })),
};
if (frames.length) {
    const xs = frames.map((f) => f.xyz[0]), ys = frames.map((f) => f.xyz[1]), zs = frames.map((f) => f.xyz[2]);
    const bx = [Math.min(...xs), Math.max(...xs)], bz = [Math.min(...zs), Math.max(...zs)];
    const W = bx[1] - bx[0] + 1, D = bz[1] - bz[0] + 1;
    out.frames.boundingBox = { x: bx, y: [Math.min(...ys), Math.max(...ys)], z: bz, xSpan: W, zSpan: D };
    // ⚠⚠ **第一版把"环完整"写死成 4×4，是错的**，实数据是 **5×5 环、中心 3×3 空、缺四角**（12 格）。
    //   末影之门的环有两种都是 12 格的摆法（4×4 满边 / 5×5 缺角），所以**不能按形状判**，
    //   要按"外圈是否被 12 格填满"来判：
    //     候选外形 = 外圈 W×D 去掉 4 个角；把它和实测格集合逐一对比。
    const set = new Set(frames.map((f) => f.xyz.join(',')));
    const isCorner = (i, j) => (i === 0 || i === W - 1) && (j === 0 || j === D - 1);
    const expect = [];
    for (let i = 0; i < W; i++) for (let j = 0; j < D; j++) {
        const onRing = (i === 0 || i === W - 1) || (j === 0 || j === D - 1);
        if (onRing && !isCorner(i, j)) expect.push(`${bx[0] + i},${frames[0].xyz[1]},${bz[0] + j}`);
    }
    const missing = expect.filter((k) => !set.has(k));
    const extra = [...set].filter((k) => !expect.includes(k));
    out.frames.ring = {
        shape: `${W}×${D} 外圈缺四角（中心 ${W - 2}×${D - 2} 空）`,
        expectedCount: expect.length, foundCount: set.size, missing, extra,
        ringComplete: missing.length === 0 && extra.length === 0 && expect.length === 12 && set.size === 12,
    };
}

const endPortals = [];
for (let y = 0; y <= YMAX; y++) for (let z = CZ - RADIUS; z <= CZ + RADIUS; z++) for (let x = CX - RADIUS; x <= CX + RADIUS; x++) {
    if ((x - CX) ** 2 + (z - CZ) ** 2 > RADIUS * RADIUS) continue;
    if (get(x, y, z) === 'end_portal') endPortals.push([x, y, z]);
}
out.endPortalBlocks = endPortals;

// ---------------------------------------------------------------- 门室空气分量
// 门室内部 = 框环中心那 2×2 的正上方（y = 框顶 + 1）
let roomSeed = null;
if (frames.length) {
    const xs = frames.map((f) => f.xyz[0]), zs = frames.map((f) => f.xyz[2]), fy = frames[0].xyz[1];
    const cxr = (Math.min(...xs) + Math.max(...xs) + 1) / 2, czr = (Math.min(...zs) + Math.max(...zs) + 1) / 2;
    for (const [ax, az] of [[cxr - 0.5, czr - 0.5], [cxr - 0.5, czr + 0.5], [cxr + 0.5, czr - 0.5], [cxr + 0.5, czr + 0.5]]) {
        if (isAir(Math.floor(ax), fy + 1, Math.floor(az))) { roomSeed = [Math.floor(ax), fy + 1, Math.floor(az)]; break; }
    }
}
let room = { seed: roomSeed, size: 0, standSpots: 0, sky: false, cells: new Set() };
if (roomSeed) {
    const seen = new Set([key(...roomSeed)]); const st = [roomSeed];
    while (st.length) {
        const [x, y, z] = st.pop(); room.cells.add(key(x, y, z)); room.size++;
        for (const [dx, dy, dz] of N6) {
            const nx = x + dx, ny = y + dy, nz = z + dz, k = key(nx, ny, nz);
            if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
            if (seen.has(k) || !isAir(nx, ny, nz)) continue;
            seen.add(k); st.push([nx, ny, nz]);
        }
    }
    for (const k of room.cells) {
        const [x, y, z] = k.split(',').map(Number);
        if (isAir(x, y, z) && isSolid(x, y - 1, z) && isAir(x, y + 1, z) && isAir(x, y + 2, z)) room.standSpots++;
        for (let t = y + 1; t <= YMAX; t++) { if (!isAir(x, t, z)) { room.sky = false; break; } if (t === YMAX) room.sky = true; }
    }
    const ys = [...room.cells].map((k) => +k.split(',')[1]);
    out.room = { seed: roomSeed, size: room.size, standSpots: room.standSpots, sky: room.sky, yRange: [Math.min(...ys), Math.max(...ys)] };
} else out.room = { seed: null, note: '框环正上方不是空气 —— 门室内部被填实/读不到' };

// ---------------------------------------------------------------- 框的暴露面
out.frameExposure = frames.map((f) => {
    const [x, y, z] = f.xyz; let n = 0; const airNb = [];
    for (const [dx, dy, dz] of N6) { const nx = x + dx, ny = y + dy, nz = z + dz; if (isAir(nx, ny, nz)) { n++; airNb.push([nx, ny, nz]); } }
    return { xyz: f.xyz, eye: f.eye, airFaces: n, inRoomComponent: airNb.some((c) => room.cells.has(key(...c))) };
});

// ---------------------------------------------------------------- ② 连到"可走的洞穴/走廊"
// 判据：从门室空气出发，**只走空气**，能不能走到"贴着自然地形（要塞建材以外）"的空气格。
const natural = (x, y, z) => {           // 这一格旁边的实体是不是自然岩层（不是要塞建材）
    for (const [dx, dy, dz] of N6) { const b = get(x + dx, y + dy, z + dz); if (b === 'unknown' || AIRLIKE.has(b)) continue; if (!STRONGHOLD_MATERIALS.has(b)) return true; }
    return false;
};
let walkIn = null;
if (roomSeed) {
    for (const k of room.cells) {
        const [x, y, z] = k.split(',').map(Number);
        if (natural(x, y, z)) { walkIn = { cell: [x, y, z], dist: Math.round(Math.hypot(x - CX, y - 0, z - CZ) * 10) / 10 }; break; }
    }
}
out.reachability = {
    airConnectedToOpenTerrain: !!walkIn,
    firstOpenTerrainCell: walkIn?.cell ?? null,
    criterion: '门室空气分量里有任意一格，其 6 邻面存在"非要塞建材"的实体（自然岩层/泥土）⇒ 门室开在天然空洞/洞穴的边上，不用挖就能进。',
};

// ---------------------------------------------------------------- ③ 最近的可进入点：最小实体层厚度
// 从门室分量边界出发，**只穿实体**做 BFS，第一次碰到"不属于门室分量"的空气 = 出口。
const exit = (() => {
    if (!roomSeed) return null;
    // ⚠⚠ **第一版漏了 thickness=0 这档**：BFS 只从"边界上的实体格"起步，
    //   于是"门室空气**直接**挨着别的空气"（= 门开着 / 走廊通着 / 门室开在天然洞边上）
    //   这种最常见的情况**根本没有被考察**，一律被报成"至少要挖 1 格"。
    //   —— 实测就是踩到了：门室 airConnectedToOpenTerrain=true，却报 needsDig。
    //   先单独判 0 档：门室格与"非门室空气格"直接相邻。
    let zero = null;
    for (const k of room.cells) {
        const [x, y, z] = k.split(',').map(Number);
        for (const [dx, dy, dz] of N6) {
            const nx = x + dx, ny = y + dy, nz = z + dz;
            if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
            const kk = `${nx},${ny},${nz}`;
            if (room.cells.has(kk) || !isAir(nx, ny, nz)) continue;
            const c = { solidThickness: 0, exitCell: [nx, ny, nz], viaDoor: /door/.test(get(x, y, z)), touchingBlock: get(x, y, z), exitTouchesNatural: natural(nx, ny, nz) };
            if (!zero || Math.hypot(nx - CX, nz - CZ) < Math.hypot(zero.exitCell[0] - CX, zero.exitCell[2] - CZ)) zero = c;
        }
    }
    const bfs = new Map(); const q = [];
    for (const k of room.cells) for (const [dx, dy, dz] of N6) {
        const [x, y, z] = k.split(',').map(Number); const nx = x + dx, ny = y + dy, nz = z + dz;
        if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
        if (!isSolid(nx, ny, nz)) continue;
        const kk = key(nx, ny, nz); if (bfs.has(kk)) continue; bfs.set(kk, 1); q.push([nx, ny, nz, 1]);
    }
    let head = 0, best = null;
    while (head < q.length) {
        const [x, y, z, d] = q[head++];
        for (const [dx, dy, dz] of N6) {
            const nx = x + dx, ny = y + dy, nz = z + dz, kk = key(nx, ny, nz);
            if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
            if (isAir(nx, ny, nz) && !room.cells.has(kk)) {
                const cand = { solidThickness: d, exitCell: [nx, ny, nz], exitBlockIsStronghold: STRONGHOLD_MATERIALS.has(get(x, y, z)), exitTouchesNatural: natural(nx, ny, nz) };
                if (!best || cand.solidThickness < best.solidThickness) best = cand;
                continue;
            }
            if (isSolid(nx, ny, nz) && !bfs.has(kk)) { bfs.set(kk, d + 1); q.push([nx, ny, nz, d + 1]); }
        }
    }
    if (best) {
        const [x, y, z] = best.exitCell;
        best.distFromCenterXZ = Math.round(Math.hypot(x - CX, z - CZ) * 10) / 10;
        best.distFromRoomSeed = roomSeed ? Math.round(Math.hypot(x - roomSeed[0], y - roomSeed[1], z - roomSeed[2]) * 10) / 10 : null;
    }
    // 0 档优先：能直接走出去，就不存在"要挖"
    const pick = (zero && (!best || zero.solidThickness <= best.solidThickness)) ? zero : best;
    if (pick && zero && best) pick.alsoFoundDigOption = { solidThickness: best.solidThickness, exitCell: best.exitCell };
    return pick;
})();
out.nearestEnterable = exit;

// 边界上挡路的方块（门 vs 建材）：给"能不能进"一个物证
if (roomSeed) {
    const b = new Map();
    for (const k of room.cells) {
        const [x, y, z] = k.split(',').map(Number);
        for (const [dx, dy, dz] of N6) {
            const nx = x + dx, ny = y + dy, nz = z + dz;
            if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
            if (room.cells.has(key(nx, ny, nz))) continue;
            const nm = get(nx, ny, nz); b.set(nm, (b.get(nm) ?? 0) + 1);
        }
    }
    out.roomBoundary = Object.fromEntries([...b.entries()].sort((p, q) => q[1] - p[1]));
    out.roomBoundaryDoors = [...b.entries()].filter(([n]) => /door|trapdoor|fence_gate|ladder/.test(n));
}

// 地形对照（手册 §5：先证伪工具）
const ctrl = {};
for (let y = 0; y <= YMAX; y++) for (let z = box.z1; z <= box.z2; z += 2) for (let x = box.x1; x <= box.x2; x += 2) {
    const n = get(x, y, z); ctrl[n] = (ctrl[n] ?? 0) + 1;
}
out.terrainControl = Object.fromEntries(Object.entries(ctrl).sort((p, q) => q[1] - p[1]).slice(0, 18));

// ---------------------------------------------------------------- 三问汇总
// ⚠ 三个问题**互相独立**，不要合成一个"通过/不通过"：
//   ① 眼睛是**物资账**（能少投几个眼）；②③ 是**可达性账**（进不进得去）。
//   强要塞可能 12 框全没眼（① 满分、物资最省），也可能 12 框全有眼但门室封死（②③ 零分）。
out.summary = {
    q1_eyes: { frames: out.frames.found, withEye: out.frames.withEye, withoutEye: out.frames.withoutEye, ringComplete: out.frames.ring?.ringComplete, ringShape: out.frames.ring?.shape },
    q2_exposure: {
        framesWithAirFace: out.frameExposure.filter((f) => f.airFaces > 0).length,
        framesZeroFace: out.frameExposure.filter((f) => f.airFaces === 0).length,
        framesInRoomAir: out.frameExposure.filter((f) => f.inRoomComponent).length,
        roomSize: out.room?.size ?? null, roomStandSpots: out.room?.standSpots ?? null, roomSky: out.room?.sky ?? null,
        airConnectedToOpenTerrain: out.reachability.airConnectedToOpenTerrain,
    },
    // 🚨 **"进得去"有两条互斥的路，必须一起报，否则会得出"要挖墙"的错误结论**：
    //   ① 零挖掘：门室边界上有**关闭的门**（iron_door / oak_door）—— 右键就开，是正常交互，不是挖。
    //      ⚠ 6 连通空气泛洪**过不去关着的门**，所以 ① 在"空气连通"那一栏里必然显示为 false，
    //        **不能**据此判"要挖"。这正是 S0b 村庄床那一节的同一个坑。
    //   ② 挖掘：最薄**实体层**厚度（本单实测 ≥1 ⇒ 最薄也只挖 1 格）。
    q3_entry: {
        digBlocks: exit ? exit.solidThickness : null,
        digExitCell: exit?.exitCell ?? null,
        digDistFromCenterXZ: exit?.distFromCenterXZ ?? null,
        zeroDigViaDoors: (out.roomBoundaryDoors ?? []).map(([n, c]) => ({ block: n, cells: c, doors: c / 2 })),
        airPathOutExists: !!(exit && exit.solidThickness === 0),
    },
    needsDig: exit ? exit.solidThickness > 0 && !(out.roomBoundaryDoors ?? []).some(([n]) => /door/.test(n)) : null,
};
out.VERDICT = out.frames.found === 0 ? 'NO_STRONGHOLD_IN_SAVED_AREA'
    : (out.frames.ring?.ringComplete && !out.summary.needsDig) ? 'OK'
        : out.frames.ring?.ringComplete ? 'ENTRY_SEALED_NO_DOOR' : 'RING_INCOMPLETE';

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
console.log(JSON.stringify({
    frames: out.frames.found, withEye: out.frames.withEye, withoutEye: out.frames.withoutEye, ringComplete: out.frames.ringComplete,
    boundingBox: out.frames.boundingBox, endPortals: out.endPortalBlocks,
    room: out.room, airConnectedToOpenTerrain: out.reachability.airConnectedToOpenTerrain,
    nearestEnterable: out.nearestEnterable, roomBoundaryDoors: out.roomBoundaryDoors,
}, null, 2));
console.log(`\n落盘：${OUT}`);
console.log('地形对照：' + JSON.stringify(out.terrainControl));
