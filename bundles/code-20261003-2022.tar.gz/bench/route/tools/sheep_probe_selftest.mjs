// sheep_probe_selftest.mjs — 羊探针（v2）的**离线自检**（不碰服务器、不占端口）
//
// v2 相对 v1 的判据变化，所以自检也重写：
//   T1 ★阳性对照失败 ⇒ 判 `CHANNEL_BROKEN` 并**停**（不许产出任何羊站结论）
//   T2 ★两个 world 坐标一致且非空 ⇒ REAL，center 取**离 S1 最近**的那群
//   T3 坐标不一致 / 通道好但全 0 ⇒ 保持 UNVERIFIED、center 维持
//   T4 坐标解析失败 ⇒ 不许判 REAL（哪怕羊数>0）
//   T5 地形对照为 0 ⇒ 不许判 REAL（区块没生成不可能有实体）
//   T6 只跑一个 world ⇒ 无法做坐标对比
//   T7 命令形态探测：`execute as @e[...,r=N]` 在 1.16.1 上**不可用**（实测 Unknown option 'r'）⇒ 落档
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\sheep_probe_selftest.mjs

import { judgeSheep } from './sheep_probe.mjs';

let pass = 0, fail = 0;
const A = (name, cond, extra = '') => {
    if (cond) { pass++; console.log(`  ✔ ${name}`); }
    else { fail++; console.log(`  ✘ ${name}${extra ? ` — ${extra}` : ''}`); }
};
const eq = (name, got, want) => A(name, JSON.stringify(got) === JSON.stringify(want), `got=${JSON.stringify(got)} want=${JSON.stringify(want)}`);

const S1 = { x: 176, z: 304 };
const POS_RE = '[-123.5d, 70.0d, 88.0d]';

/** 造一个 world 读数（v2 字段） */
const W = (label, o = {}) => ({
    label,
    difficulty: 'The difficulty is Peaceful',
    sheep: [], insideArea: [], outsideArea: 0,
    cow: 0, pig: 0, chicken: 0,
    controls: { grass_block: 30000, stone: 20000, water: 5000 },
    boxes: [],
    positiveControl: { ok: true, countBefore: 8, countAfter: 9 },
    posParseRe: POS_RE,
    commandShapes: [
        { name: 'as @e[type]（不带任何选项）', ok: true, error: null },
        { name: 'as @e[type,r=N]', ok: false, errorLine: "Unknown option 'r'" },
    ],
    ...o,
});

console.log('T1 阳性对照失败 ⇒ 停下，不产出任何结论');
{
    const j = judgeSheep([W('A:模板默认', { positiveControl: { ok: false, countBefore: 8, countAfter: 8 }, insideArea: [[176, 70, 294]] })], { s1: S1 });
    eq('阳性对照失败 ⇒ CHANNEL_BROKEN', j.status, 'CHANNEL_BROKEN');
    A('结论里点明"通道不可用、按指令停下"', /通道不可用.*停下/s.test(j.conclusion));
    eq('不给 center（不许填）', j.center, null);
    eq('positiveControl 闸门=false', j.gates.positiveControl, false);
}

console.log('T2 两个 world 坐标一致且非空 ⇒ REAL，center 取离 S1 最近的那群');
{
    // 三群羊：离 S1 门 10 格、300 格、1000 格 —— center 必须取第一群
    const sheep = [[176, 70, 294], [200, 70, 100], [-400, 70, -400]];
    const j = judgeSheep([W('A:模板默认', { insideArea: sheep, outsideArea: 2 }), W('B:模板默认(第二次)', { insideArea: sheep.map((p) => [...p]), outsideArea: 2 })], { s1: S1 });
    eq('坐标一致 ⇒ REAL', j.status, 'REAL');
    eq('两 world 坐标闸门=true', j.gates.twoWorldsSameCoordinates, true);
    eq('取的是离 S1 最近的那群', j.nearest?.pos, [176, 70, 294]);
    eq('center 8 格对齐', j.center, [176, 296]);
    A('结论里写明"由种子决定"', /由种子决定/.test(j.conclusion));
    A('区外的羊不参与判据但被记录（两个 world 各多少只）', /采样区外另有 2 \/ 2 只/.test(j.conclusion));
}

console.log('T3 坐标不一致 / 通道好但全 0 ⇒ 保持 UNVERIFIED');
{
    const j = judgeSheep([
        W('A:模板默认', { insideArea: [[10, 70, 10]] }),
        W('B:模板默认(第二次)', { insideArea: [[11, 70, 10], [12, 70, 10]] }),
    ], { s1: S1 });
    eq('坐标不一致 ⇒ INCONSISTENT', j.status, 'INCONSISTENT');
    eq('不给 center', j.center, null);
    A('结论里点明"不是纯种子决定"', /不是纯种子决定/.test(j.conclusion));

    const j2 = judgeSheep([W('A:模板默认', { insideArea: [] }), W('B:模板默认(第二次)', { insideArea: [] })], { s1: S1 });
    eq('通道好但全 0 ⇒ ZERO_WITH_WORKING_CHANNEL', j2.status, 'ZERO_WITH_WORKING_CHANNEL');
    A('该状态明确区分于"通道坏了"', /通道已用阳性对照证明可用/.test(j2.conclusion));
    eq('不给 center', j2.center, null);
}

console.log('T4 坐标解析失败 ⇒ 不许判 REAL（即使羊数>0）');
{
    const j = judgeSheep([
        W('A:模板默认', { insideArea: [[176, 70, 294]], posParseRe: null }),
        W('B:模板默认(第二次)', { insideArea: [[176, 70, 294]], posParseRe: null }),
    ], { s1: S1 });
    eq('坐标不可用 ⇒ COORDINATES_UNAVAILABLE', j.status, 'COORDINATES_UNAVAILABLE');
    eq('不给 center', j.center, null);
    A('点明 F 线 §8.4 那条经验', /data get entity|§8\.4/.test(j.conclusion));
}

console.log('T5 地形对照为 0 时不许判 REAL（区块没生成不可能有实体）');
{
    const j = judgeSheep([
        W('A:模板默认', { insideArea: [[176, 70, 294]], controls: { grass_block: 0, stone: 0 } }),
        W('B:模板默认(第二次)', { insideArea: [[176, 70, 294]] }),
    ], { s1: S1 });
    eq('地形对照为 0 ⇒ 不判 REAL', j.status === 'REAL', false);
    eq('terrainControl 闸门=false', j.gates.terrainControl, false);
}

console.log('T6 只跑一个 world ⇒ 无法做坐标对比');
{
    const j = judgeSheep([W('A:模板默认', { insideArea: [[176, 70, 294]] })], { s1: S1 });
    eq('单 world ⇒ INCONCLUSIVE', j.status, 'INCONCLUSIVE');
    eq('twoWorldsSameCoordinates=null（不是 true 也不是 false）', j.gates.twoWorldsSameCoordinates, null);
}

console.log('T7 命令形态探测要落进闸门（r= 不可用这条是本单实测踩到的）');
{
    const j = judgeSheep([W('A:模板默认', { insideArea: [[176, 70, 294]] }), W('B:模板默认(第二次)', { insideArea: [[176, 70, 294]] })], { s1: S1 });
    eq('形态探测进 gates', j.gates.commandShapes.length, 2);
    eq('r= 那条记为不可用', j.gates.commandShapes[1].ok, false);
    A('错误行原样保留', /Unknown option 'r'/.test(JSON.stringify(j.gates.commandShapes)));
}

console.log(`\n${fail === 0 ? '✅' : '❌'} 自检 ${pass} 通过 / ${fail} 失败`);
process.exit(fail === 0 ? 0 : 1);
