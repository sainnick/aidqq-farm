// verify_determinism.mjs — MC-ROUTE-02 验收①：生成器对同一种子重复运行结果一致
//
// 口径（任务单 §4）：**除时间戳外 diff 为空**。
// 之所以能做到秒级、不占泳道：生成器拆成了 probe（要机器时间）与 emit（纯函数）两段，
// 「重复运行」只需要把纯函数那段跑两遍——探针结果不变时，route 必然逐字节一致。
//
// 同时顺带做三项结构核验（都在离线侧，不开服）：
//   · route 文件能通过编排器 route_guard 的全部结构校验（含 radius≥16 / center 8 格对齐）
//   · station 区**不含**精确坐标（scout 与 station 分离，SCHEMA §1 的结构性保证）
//   · MISSION 序列形态是 `do station <id>` 且不含坐标（手册 §7）
//
// 用法：node verify_determinism.mjs --seed <seed> [--seed <s2> ...]

import fs from 'fs';
import path from 'path';
import { argOf } from '../../stages/_lib/runner_core.mjs';
import { ROUTE_DIR } from './console.mjs';
import { emitRoute } from './emit_route.mjs';
import { checkRouteIntegrity, sha256Of, assertStationOnlyMissions } from '../../stages/fullrun/route_guard.mjs';

const SEEDS = process.argv.reduce((acc, a, i, arr) => (a === '--seed' ? [...acc, arr[i + 1]] : acc), []).filter(Boolean);
if (!SEEDS.length) SEEDS.push('-8839485814800629942');

const ISO = /\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?Z/;
// 归一化时间戳：只替换**时间戳本体**（引号保留），否则会产出 `""<TS>""` 这种非法 JSON
const norm = (o) => JSON.parse(JSON.stringify(o).replace(new RegExp(ISO.source, 'g'), '<TS>'));

let pass = 0, fail = 0;
const bad = [];
const check = (name, cond, extra = '') => { if (cond) { pass++; console.log(`  ✓ ${name}`); } else { fail++; bad.push(`${name}${extra ? ` — ${extra}` : ''}`); console.log(`  ✗ ${name}${extra ? ` — ${extra}` : ''}`); } };

for (const seed of SEEDS) {
    const probePath = path.join(ROUTE_DIR, 'probe', `${seed}.probe.json`);
    console.log(`\n=== seed ${seed} ===`);
    if (!fs.existsSync(probePath)) { check(`${seed} 有 probe`, false, probePath); continue; }
    const probe = JSON.parse(fs.readFileSync(probePath, 'utf8'));

    // ---- ① 确定性：同一 probe 连续 emit 两次 ----
    const r1 = emitRoute(probe);
    const r2 = emitRoute(probe);
    const j1 = JSON.stringify(r1, null, 2) + '\n';
    const j2 = JSON.stringify(r2, null, 2) + '\n';
    check('两次 emit 逐字节一致（含时间戳）', j1 === j2, j1 === j2 ? '' : `长度 ${j1.length} vs ${j2.length}`);

    // 归一化时间戳后再比（这是任务单那句"除时间戳外"的严格形式）
    const n1 = JSON.stringify(norm(r1), null, 2);
    const n2 = JSON.stringify(norm(r2), null, 2);
    check('归一化时间戳后 diff 为空', n1 === n2);

    // 另一路独立证据：sha256（归一化后的全文）
    check('归一化文本 sha256 一致', sha256Of(n1) === sha256Of(n2), `${sha256Of(n1).slice(0, 12)} vs ${sha256Of(n2).slice(0, 12)}`);

    // ---- ② 结构校验（编排器 route_guard 的判据） ----
    const out = path.join(ROUTE_DIR, `${seed}.json`);
    fs.writeFileSync(out, j1);
    const gate = checkRouteIntegrity(out, { allowDraft: true });
    check('通过编排器结构校验', gate.ok === true, gate.reason ?? gate.violations?.join(' | '));
    check('是草稿（frozenAt=null，冻结留给设计会话）', gate.frozen === false && gate.frozenAt === null);

    // ---- ③ scout / station 分离（SCHEMA §1 的结构性保证） ----
    const stationBlob = JSON.stringify(r1.stations.map((s) => s.station));
    const scoutHasCoords = r1.stations.some((s) => (s.scout?.points ?? []).length > 0);
    check('scout 里有精确坐标（证明下钻数据落对了地方）', scoutHasCoords);
    check('station 区不含任何 xyz 三元组', !/\[\s*-?\d+\s*,\s*-?\d+\s*,\s*-?\d+\s*\]/.test(stationBlob), stationBlob.slice(0, 120));
    check('每站 center 都是 16 的倍数（本单主动粗化，比加载器兜底的 8 格更粗）',
        r1.stations.every((s) => s.station.center.every((c) => c % 16 === 0)),
        JSON.stringify(r1.stations.map((s) => s.station.center)));
    check('每站 radius ≥ 16（SCHEMA 硬下限）', r1.stations.every((s) => s.station.radius >= 16));
    check('每站 lookFor 非空（运行时才能做到达确认）', r1.stations.every((s) => s.station.lookFor?.length > 0));
    check('seq 是 1..N 不重复', r1.stations.every((s, i) => s.seq === i + 1));

    // ---- ④ MISSION 形态（手册 §7：坐标不进 MISSION） ----
    const missions = r1.stations.map((s) => ({ raw: `do station ${s.id}` }));
    check('MISSION 形态自检通过（无坐标）', assertStationOnlyMissions(missions) === true);

    // ---- ⑤ 核验状态统计 ----
    const real = r1.stations.filter((s) => s.scout.verify.status === 'REAL');
    const unv = r1.stations.filter((s) => s.scout.verify.status === 'UNVERIFIED');
    console.log(`  · 站数 ${r1.stations.length}：REAL ${real.length} / UNVERIFIED ${unv.length}`);
    for (const s of r1.stations) {
        const v = s.scout.verify;
        const counts = v.counts && Object.keys(v.counts).length ? JSON.stringify(v.counts) : '{}';
        const terr = v.terrain && Object.keys(v.terrain).length ? `terrain=${JSON.stringify(v.terrain)}` : 'terrain={}';
        console.log(`    ${String(s.seq).padStart(2)} ${s.id.padEnd(20)} ${v.status.padEnd(10)} ${counts} ${terr}${v.reason ? ` reason=${v.reason}` : ''}`);
    }
    check('REAL 站全部带真值计数', real.every((s) => s.scout.verify.counts && Object.keys(s.scout.verify.counts).length > 0));
    check('REAL 站全部带地形对照', real.every((s) => s.scout.verify.terrain && Object.values(s.scout.verify.terrain).some((v) => v > 0)));
    check('UNVERIFIED 站全部写明原因', unv.every((s) => !!s.scout.verify.reason));
    console.log(`  → ${path.relative(process.cwd(), out)}`);
}

console.log(`\n[verify_determinism] ${pass} passed, ${fail} failed`);
if (bad.length) for (const b of bad) console.log(`  ✗ ${b}`);
process.exit(fail === 0 ? 0 : 1);
