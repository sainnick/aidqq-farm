// v2_nether_legs_corrected.mjs — 下界腿路点的**订正版**
//
// ⚠⚠ **本单推翻上一单的数字。** `r7c_nether_route_distance.mjs:45-46` 写的是
//     S3: `nether: [336/8, 256/8]`、C3: `nether: [224/8, -88/8]`，
//     而它自己的 note 就写着「route 的 `S3_bastion.station.center` = **nether** (336,256)」。
//     ⇒ `station.center` 对 `dim: the_nether` 的站**本来就是下界坐标**，
//        再 ÷8 就等于把站挪到了"主世界里那个要塞对应的位置"——**目标点整整差 8 倍**。
//     上一单那 152 步（25/69/58）是量到**错的点**上量出来的。
//     保留 `r7c_nether_route_distance.mjs` 与 `nether_route_distance.round7c.json` 原样作为记录，不删不改。
//
// 【本单能算什么、不能算什么】
//   ✅ S3 → C3：两端都在 `_bedhunt` 的下界覆盖内（x 112..431 / z -192..367）⇒ 逐格 BFS 可算。
//   ❌ S1 门落点 → S3、C3 → S1 门落点：**算不了**。门落点在下界 (23,38)，在 `_nether_corridor` 里；
//      要塞在 `_bedhunt` 里；两份存档虽然区块范围有重叠，但**同种子也不一致**（实测重叠区
//      786,432 格里有 **82,363 格不同**，netherrack↔basalt、netherrack↔blackstone），
//      所以**不能拼**成一个"合成世界"来 BFS —— 那会产出一条现实中不存在的路。
//      另：门落点坐标**本身未验**（要真服开一次门看 Pos）。
//
// 【判据】沿用 ROUND7-C 逐字口径（脚下实心 + 身体 2 格空气；4 向水平 + 上 1 + 下 ≤20），便于对拍。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from './region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROBE = path.join(HERE, '..', 'probe');
const OUT = path.join(PROBE, 'v2_nether_legs_corrected.json');
const WORLD = path.join(PROBE, '_bedhunt');
const DIM = 'the_nether';

const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);
const AIR_STRICT = new Set(['air']);
const HAZARD = new Set(['lava', 'magma_block', 'fire', 'soul_fire']);
const NON_SOLID = new Set(['water', 'lava', 'magma_block', 'fire', 'soul_fire']);

const w = openWorld(WORLD);
const blockAt = (x, y, z) => w.blockAt(x, y, z, DIM);

/** 站得住：脚下实心（非空气集、非液体/伤害源）+ 身体 2 格空气（y、y+1）。返回**身体格**。 */
function standableAir(x, y, z) {
    if (!AIRLIKE.has(blockAt(x, y, z))) return false;
    const below = blockAt(x, y - 1, z);
    if (below === 'unknown' || AIRLIKE.has(below) || NON_SOLID.has(below)) return false;
    return AIRLIKE.has(blockAt(x, y + 1, z));
}
const MOVES = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0], [0, -1, 0]];
for (let d = 2; d <= 20; d++) MOVES.push([0, -d, 0]);          // 下 ≤20

function stepOk(x, y, z, [dx, dy, dz]) {
    const nx = x + dx, ny = y + dy, nz = z + dz;
    if (nx < 0 || nz > 511) return false;
    if (!standableAir(nx, ny, nz)) return false;
    if (dy < 0) for (let k = 1; k < -dy; k++) if (HAZARD.has(blockAt(x, y - k, z))) return false;
    return true;
}

/** 目标点（BFS 的可达集合）—— 用**身体格**（脚下那格 +1） */
const TARGETS = {
    S3_bastion: [[331, 64, 238]],                                        // 脚下 (331,63,238)
    C3_fortress_spawner: [[220, 70, -87], [223, 70, -87], [220, 70, -83], [223, 70, -83]],  // 脚下 y=69
};
const GROUND_OF = { S3_bastion: [[331, 63, 238]], C3_fortress_spawner: [[220, 69, -87], [223, 69, -87], [220, 69, -83], [223, 69, -83]] };

function bfs(from, targets) {
    const k = (x, y, z) => `${x},${y},${z}`;
    const tset = new Set(targets.map((t) => k(...t)));
    const sk = k(...from);
    if (tset.has(sk)) return { path: [from], steps: 0, hit: from };
    const prev = new Map([[sk, null]]);
    const q = [from]; let head = 0, n = 0;
    while (head < q.length) {
        const [x, y, z] = q[head++];
        if (++n > 9_000_000) break;
        for (const mv of MOVES) {
            if (!stepOk(x, y, z, mv)) continue;
            const nk = k(x + mv[0], y + mv[1], z + mv[2]);
            if (prev.has(nk)) continue;
            prev.set(nk, k(x, y, z));
            if (tset.has(nk)) {
                const out = []; let cur = nk;
                while (cur) { out.push(cur.split(',').map(Number)); cur = prev.get(cur); }
                out.reverse();
                return { path: out, steps: out.length - 1, hit: out[out.length - 1] };
            }
            q.push([x + mv[0], y + mv[1], z + mv[2]]);
        }
    }
    return null;
}

/** 相邻路点 ≤32 的抽稀（贪心取路径上最远的、且距上一个路点 ≤32 的格）。 */
function thin(cells, gap = 32) {
    if (cells.length <= 1) return cells;
    const out = [cells[0]]; let anchor = 0;
    for (let i = 2; i < cells.length; i++) {
        const d = Math.hypot(...cells[i].map((v, k) => v - cells[anchor][k]));
        const last = cells[cells.length - 1];
        const dl = Math.hypot(...cells[i].map((v, k) => v - last[k]));
        if (d > gap || dl <= gap) { out.push(cells[i]); anchor = i; }
    }
    if (out[out.length - 1] !== cells[cells.length - 1]) out.push(cells[cells.length - 1]);
    return out;
}
/** 沿路 1 格内的危险格（岩浆/岩浆块/火） */
function hazardsAlong(path) {
    const s = new Set(); const out = [];
    for (const [x, y, z] of path) for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) {
        const k = `${x + dx},${y + dy},${z + dz}`;
        if (s.has(k)) continue; s.add(k);
        const nm = blockAt(x + dx, y + dy, z + dz);
        if (HAZARD.has(nm)) out.push([x + dx, y + dy, z + dz, nm]);
    }
    return out;
}

// ---- 读数健康闸门（手册 §5：全零先证伪工具）
let cells = 0, unknown = 0; const terr = {};
for (let cx = 0; cx <= 26; cx++) for (let cz = -12; cz <= 22; cz++) {
    const c = w.chunk(cx, cz, DIM); if (!c) continue;
    for (let y = 0; y < 128; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
        const o = x + z * 16 + y * 256; cells++;
        if (!c.filled[o]) { unknown++; continue; }
        const nm = c.palette[c.idx[o]]?.name; if (nm === 'unknown') unknown++;
        else terr[nm] = (terr[nm] ?? 0) + 1;
    }
}
console.log(`读数健康：${cells - unknown}/${cells}（unknownCells=${unknown}）`);
console.log(`地形对照：${JSON.stringify(Object.fromEntries(Object.entries(terr).sort((a, b) => b[1] - a[1]).slice(0, 8)))}`);
if (unknown > 0) { console.error('ABORT：覆盖区内有读不到的格 —— 拒绝出坐标'); process.exit(3); }

// ---- 两套空气口径对照（口径不一致会静默改变站位数，必须同时报）
const airCheck = (() => {
    const orig = AIRLIKE;
    let r;
    try {
        // 严格 air 口径复算：临时把"身体格"判据的空气集换掉
        const saved = MOVES.length;
        r = bfs(TARGETS.S3_bastion[0], TARGETS.C3_fortress_spawner);
        void saved;
    } finally { void orig; }
    return { airLike: r ? r.steps : null };
})();

// ---- S3 站位"密封度"实测：F 线作业点 (331,64,238) 在堡垒内部，四周是 polished_blackstone_bricks，
//      走-only 的 BFS 连它自己那格小空腔都出不去 ⇒ "算不出来"的原因是**可复述的封堵**，不是玄学。
function reachableSet(seed) {
    const seen = new Set([seed.join(',')]); const q = [seed]; let head = 0;
    while (head < q.length && head < 3000000) {
        const [x, y, z] = q[head++];
        for (const m of MOVES) {
            if (!stepOk(x, y, z, m)) continue;
            const k = (x + m[0]) + ',' + (y + m[1]) + ',' + (z + m[2]);
            if (seen.has(k)) continue;
            seen.add(k); q.push([x + m[0], y + m[1], z + m[2]]);
        }
    }
    return seen;
}
const from = TARGETS.S3_bastion[0];
const r = bfs(from, TARGETS.C3_fortress_spawner);
const reach = reachableSet(from);
console.log(`\nS3 作业点 ${from.join(',')}：脚下=${blockAt(...GROUND_OF.S3_bastion[0])}，走-only 可达站位格 = ${reach.size}`);
console.log('  C3 四个挡火球站位本体站得住？', TARGETS.C3_fortress_spawner.map((t) => standableAir(...t)).join(' '));

const unavailable = [
  { leg: 'S3_bastion -> C3_fortress_spawner',
    measuredReason: `BFS 不通：S3 作业点 ${from.join(',')} 的走-only 可达站位格只有 ${reach.size} 个 —— 它被堡垒壁（polished_blackstone_bricks）封在里面，出不去，真人得先挖开。` +
      `C3 四个挡火球站位**本体站得住**（脚下 nether_bricks，已逐格回读），只是从 S3 走不到。`,
    need: '给 BFS 加"挖穿"移动（与主世界腿同一做法），或借一次泳道实跑。' },
  { leg: 'S1_portal -> S3_bastion',
    measuredReason: '门落点在下界 (23,38) 只在 _nether_corridor 里，S3 在 _bedhunt 里。**两份存档同种子也不一致**（重叠区 786,432 格中 82,363 格不同：netherrack<->basalt / netherrack<->blackstone），不能拼成合成世界来 BFS。且门落点坐标本身未验。',
    need: '借泳道 forceload 一条 x -32..431 / z -192..367 的下界走廊并 save-all flush。' },
  { leg: 'C3_fortress_spawner -> S1_portal', measuredReason: '同上一条。', need: '同上一条。' },
];
const out = {
    schema: 'aidqq-v2-nether-legs-corrected/1',
    at: new Date().toISOString(), seed: '4926685115947721762', mcVersion: '1.16.1',
    supersedes: {
        file: 'bench/route/probe/nether_route_distance.round7c.json',
        tool: 'bench/route/tools/r7c_nether_route_distance.mjs',
        why: 'L45-46 把 station.center 又 /8 了一次。dim=the_nether 的站其 center 本来就是下界坐标；/8 之后目标点落在"主世界里那个要塞对应的位置"，与真实结构差 8 倍。上一单 25/69/58 = 152 步全部作废（数字自洽，但量的是错的点）。',
        preservedNotDeleted: true },
    verdict: 'NO_NETHER_LEG_COMPUTABLE',
    world: { dir: path.relative(path.join(HERE, '..', '..'), WORLD).replace(/\\/g, '/'), x: [112, 431], z: [-192, 367] },
    criteria: { standable: '脚下实心（非空气集、非液体/伤害源）+ 身体 2 格空气（y、y+1）', moves: '4 向水平 + 上 1 + 下 <=20（无斜向）', cost: '每步 1', airSet: 'AIRLIKE={air,cave_air,void_air}' },
    positiveControl: { cells, unknownCells: unknown, terrain: terr, note: 'unknownCells=0 => 下面的"不可达"是地形/封堵结论，不是"没读到"' },
    stations: {
        S3_bastion: { standGround: GROUND_OF.S3_bastion, standAir: TARGETS.S3_bastion, reachableStandCells: reach.size, reachableSample: [...reach].slice(0, 8) },
        C3_fortress_spawner: { standGround: GROUND_OF.C3_fortress_spawner, standAir: TARGETS.C3_fortress_spawner, allStandableReadBack: TARGETS.C3_fortress_spawner.every((t) => standableAir(...t)) } },
    s3ToC3: r ? { walkableSteps: r.steps, path: r.path } : null,
    legs: [],
    unavailable,
    evidence: ['bench/route/tools/v2_nether_legs_corrected.mjs', 'bench/route/probe/v2_nether_legs_corrected.json'],
};
fs.writeFileSync(OUT, JSON.stringify(out, null, 2) + '\n', 'utf8');
const back = JSON.parse(fs.readFileSync(OUT, 'utf8'));
if (back.unavailable.length !== 3) { console.error('WRITE_READBACK_FAIL'); process.exit(5); }
console.log(`\n[OK] 落盘 ${path.relative(process.cwd(), OUT)}（${fs.statSync(OUT).size} 字节，回读 OK）`);
console.log('  结论：三条下界腿全部不可算 —— 编排器侧只能几何兜底，见 v2Audit.unverified。');
