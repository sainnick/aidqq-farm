// nether_portal_frame.mjs — **下界**废弃传送门的框内黑曜石取证（ROUND3 §C-3）
//
// 用途：`4926685115947721762` 的下界有一处废弃传送门（离线 cubiomes 算得，距它要塞对应点 15.2 格，
// 见 bench/route/probe/nether_portal_scan.json）。要回答的问题是**同一个**：
// 「框内还剩几块 obsidian、缺几格、缺格被什么占」——而不是"这一片区域里有多少块 obsidian"
// （手册 §5 的「结构计数 ≠ 结构内计数」，B 线 r3 在主种子上就栽过这一下）。
//
// 方法：下界 r 盒粗扫 + 八叉下钻拿到 obsidian/crying 的精确坐标 → 用生产 frameCells 的移植
// （portal_frame.mjs）枚举候选框选最优 → **换一个未被 fill 标记污染的世界**逐格读方块真值
//（cell_probe.mjs 的 execute-if-block 通道，非破坏性）→ 输出缺格/错块/需补 obsidian 数。
//
// 为什么单独一个工具、不做成 gen_route 的一个类目：
//   这是**一次性的取证**，不是 route 的站（SCHEMA v1 的 kind 列表里没有"下界废墟门"，
//   设计会话也没要求新增 kind）。塞进 RECIPES 会让 probe 里多出一个没人消费的类目。
//
// 用法（Node 20）：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\nether_portal_frame.mjs --seed 4926685115947721762 --x 176 --z 144

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { argOf, log } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR, portState } from './console.mjs';
import { drill, forceload } from './scan.mjs';
import { frameCells, interiorCells, checkFrame, findBestFrame } from './portal_frame.mjs';
import { probeCells } from './cell_probe.mjs';

const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const CX = parseInt(argOf(process.argv, 'x', '176'), 10);
const CZ = parseInt(argOf(process.argv, 'z', '144'), 10);
const R = parseInt(argOf(process.argv, 'r', '48'), 10);
const DIM = argOf(process.argv, 'dim', 'the_nether');
const OUT = path.join(ROUTE_DIR, 'probe', 'nether_portal_frame_${SEED}.json');
const RUN_DIR = path.join(ROUTE_DIR, 'probe', `_run_netherframe_${SEED}`);

let handle = null;
const payload = {
    schema: 'aidqq-route-netherportalframe/1',
    generatedAt: new Date().toISOString(),
    tool: 'bench/route/tools/nether_portal_frame.mjs',
    seed: SEED, dim: DIM, center: [CX, CZ], r: R,
    method: {
        discovery: 'fill-replace 粗扫 + 八叉下钻（服务器回执），拿到 obsidian/crying_obsidian 精确坐标',
        frame: 'frameCells（生产 nether.js 独立移植，portal_frame.mjs），候选框打分取最优',
        truth: 'execute-if-block 逐格读方块名，在**未被标记污染**的 fresh world 里做（非破坏性）',
    },
    status: 'NOT_RUN',
};

try {
    log(`下界废弃门取证 seed=${SEED} dim=${DIM} center=(${CX},${CZ}) r=${R}`);
    // ---- ① 下钻：拿精确坐标（这个世界会被 fill 标记污染，用完即弃） ----
    handle = await bootLaneC({ seed: SEED, runDir: RUN_DIR, logFn: log });
    const res = await drill(handle.con, DIM, CX, CZ, R, [[0, 31], [32, 63], [64, 95], [96, 127]],
        ['minecraft:obsidian', 'minecraft:crying_obsidian'],
        { drillBlocks: ['minecraft:obsidian', 'minecraft:crying_obsidian'], drillUntil: 40, logFn: log });
    const pts = [
        ...(res.perBlock['minecraft:obsidian']?.points ?? []),
        ...(res.perBlock['minecraft:crying_obsidian']?.points ?? []),
    ];
    payload.discovery = {
        counts: res.counts, terrain: res.terrain, fills: res.fills, r: res.r,
        desync: res.desync ?? 0, points: pts.length, truncated: res.truncated,
        selfCheck: res.selfCheck,
        sample: pts.slice(0, 24),
    };
    log(`  下钻：obsidian=${res.counts['minecraft:obsidian']} crying=${res.counts['minecraft:crying_obsidian']} 点=${pts.length} 对照=${JSON.stringify(res.terrain)}`);
    await shutdownLaneC(handle); handle = null;

    // ---- ② 选框 ----
    const { best, runnersUp, candidatesTried } = findBestFrame(pts);
    payload.candidates = { tried: candidatesTried, best, runnersUp };
    if (!best) {
        payload.status = 'NO_CANDIDATE_FRAME';
        log('  没有候选框（这一带可能没有废弃门结构）');
    } else {
        log(`  候选框最优：origin=(${best.origin.x},${best.origin.y},${best.origin.z}) axis=${best.axis} reqHits=${best.reqHits}`);
        // ---- ③ 换 pristine world 逐格读真值 ----
        handle = await bootLaneC({ seed: SEED, runDir: `${RUN_DIR}_truth`, logFn: log });
        const cells = [...frameCells(best.origin, best.axis), ...interiorCells(best.origin, best.axis)];
        await forceload(handle.con, DIM,
            Math.min(...cells.map((c) => c.pos.x)) - 2, Math.min(...cells.map((c) => c.pos.z)) - 2,
            Math.max(...cells.map((c) => c.pos.x)) + 2, Math.max(...cells.map((c) => c.pos.z)) + 2);
        const pr = await probeCells(handle.con, DIM, cells);
        const names = new Map();
        cells.forEach((c, i) => names.set(`${c.pos.x},${c.pos.y},${c.pos.z}`, (pr.blocks[i] ?? '').replace(/^minecraft:/, '')));
        const fr = checkFrame(best.origin, best.axis, (p) => names.get(`${p.x},${p.y},${p.z}`) ?? null);
        payload.frame = {
            origin: [best.origin.x, best.origin.y, best.origin.z], axis: best.axis,
            obsidian: fr.obsidian, required: fr.required, optionalObsidian: fr.optionalObsidian,
            missing: fr.missing, wrong: fr.wrong, dirty: fr.dirty,
            obsidianToPlace: fr.obsidianToPlace, usable: fr.ok,
            cellTruth: cells.map((c, i) => ({
                pos: [c.pos.x, c.pos.y, c.pos.z], kind: c.kind, u: c.u, dy: c.dy, optional: !!c.optional,
                got: (pr.blocks[i] ?? '').replace(/^minecraft:/, '') || null,
            })),
            probe: { candidates: pr.candidates, commands: pr.commands, unresolved: pr.unknown, misses: pr.misses },
        };
        payload.status = 'OK';
        log(`  框体：obsidian ${fr.obsidian}/${fr.required} · 缺(空) ${fr.missing.length} · 错块 ${fr.wrong.length}`
            + ` · 内部脏 ${fr.dirty.length} · **需补 obsidian ${fr.obsidianToPlace}** · 清单外未识别 ${pr.unknown}`);
        await shutdownLaneC(handle); handle = null;
    }
} catch (e) {
    payload.status = 'ERROR';
    payload.error = String(e && e.stack ? e.stack : e).slice(0, 800);
    log(`✗ 失败：${payload.error.split('\n')[0]}`);
    process.exitCode = 1;
} finally {
    await shutdownLaneC(handle);
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(payload, null, 2) + '\n');
    log(`落盘：${OUT}`);
    log(`收工：端口 ${JSON.stringify(portState())}`);
}
