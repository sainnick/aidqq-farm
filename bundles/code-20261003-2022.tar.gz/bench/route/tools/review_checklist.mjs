// review_checklist.mjs — MC-ROUTE-02 收尾 **P3**：给每份 route 草稿生成一页"冻结审阅清单"
//
// 用途：设计会话人工审阅 → 写 frozenAt → 生成 <seed>.sha256（SCHEMA §4）。
//   本工具**只读 route / probe，绝不写 route 文件**，所以天然不会误写 frozenAt（派单 P3 原文）。
//
// 每站给五样东西（派单 P3 原文口径）：
//   kind / station 区域 / scout 核验状态 / 证据路径 / 冻结前的坑
//
// 用法（Node 20）：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\review_checklist.mjs [--seed <s>]...

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { argOf } from '../../stages/_lib/runner_core.mjs';
import { STATION_ORDER } from './emit_route.mjs';   // 站序是 emit 的唯一真源（不在本工具另写一份）

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE_DIR = path.join(HERE, '..');
const REVIEW_DIR = path.join(ROUTE_DIR, 'review');

const DEFAULT_SEEDS = ['-8839485814800629942', '-6850455172235562789', '4926685115947721762'];
const argSeeds = (process.argv.slice(2).reduce((acc, a, i, arr) => (a === '--seed' ? [...acc, arr[i + 1]] : acc), []));
const SEEDS = argSeeds.length ? argSeeds : DEFAULT_SEEDS;

/** 冻结前必须为真的 SCHEMA v1 硬条件（SCHEMA.md §2/§3）——清单里逐条列出，设计会话一眼能扫 */
function checkStation(st) {
    const v = st.scout?.verify ?? {};
    const counts = Object.entries(v.counts ?? {});
    const terrain = Object.entries(v.terrain ?? {});
    const terrainTotal = terrain.reduce((a, [, n]) => a + (Number(n) || 0), 0);
    const checks = [
        { ok: st.station.radius >= 16, label: `radius ${st.station.radius} ≥ 16`, why: 'SCHEMA §1：加载器硬下限' },
        { ok: st.station.center.every((c) => c % 8 === 0), label: `center ${JSON.stringify(st.station.center)} 对齐 8 格`, why: 'SCHEMA §1 粗化兜底' },
        {
            ok: JSON.stringify(Object.keys(st.station)).indexOf('scout') < 0,
            label: 'station 区不含 scout 字段', why: 'SCHEMA §1：L2 由结构保证',
        },
        {
            ok: v.status !== 'REAL' || (counts.length > 0 && terrainTotal > 0),
            label: v.status === 'REAL'
                ? `REAL 站有真值计数（${counts.length} 项）与地形对照（合计 ${terrainTotal}）`
                : `UNVERIFIED 站不要求计数`,
            why: '任务单 §4 验收线 2',
        },
    ];
    return { checks, counts: v.counts ?? {}, terrain: v.terrain ?? {}, terrainTotal, verify: v };
}

/** 路线级风险提示：UNVERIFIED 站、以及 kind 与 dim 的组合是否自洽 */
function stationRisks(route) {
    const risks = [];
    for (const st of route.stations) {
        if (st.scout?.verify?.status !== 'REAL') {
            risks.push(`**${st.id}** 是 ${st.scout?.verify?.status ?? 'UNKNOWN'}（${st.scout?.verify?.reason ?? '无 reason'}）——冻结前需要裁决：是补测、还是接受为"运行时靠闸门自己找"`);
        }
        if (st.station.center[0] === 0 && st.station.center[1] === 0) {
            risks.push(`**${st.id}** 的 center 是占位 [0,0]（探测未通过时的默认值）——它现在对 bot 没有任何指向性`);
        }
    }
    return risks;
}

function fmtCounts(counts) {
    const e = Object.entries(counts ?? {});
    return e.length ? e.map(([k, v]) => `${k}:${v}`).join(' · ') : '（空）';
}

function fmtTerrain(terrain, total) {
    const e = Object.entries(terrain ?? {});
    return e.length ? `${e.map(([k, v]) => `${k}:${v}`).join(' · ')}（合计 ${total}）` : '（空）';
}

/** 站 id → 探测类目名（route 文件本身不带 cat，从 emit 的站序反查，避免两处各写一份） */
const CAT_OF = Object.fromEntries(STATION_ORDER.map((s) => [s.id, s.cat]));

function buildRouteReview(seed) {
    const routePath = path.join(ROUTE_DIR, `${seed}.json`);
    if (!fs.existsSync(routePath)) throw new Error(`找不到 route 草稿：${routePath}`);
    const route = JSON.parse(fs.readFileSync(routePath, 'utf8'));
    const probePath = path.join(ROUTE_DIR, 'probe', `${seed}.probe.json`);
    const probe = fs.existsSync(probePath) ? JSON.parse(fs.readFileSync(probePath, 'utf8')) : null;

    const out = [];
    const real = route.stations.filter((s) => s.scout?.verify?.status === 'REAL').length;

    out.push(`# route 冻结审阅清单 —— ${seed}`);
    out.push('');
    out.push('> 由 `bench/route/tools/review_checklist.mjs` 生成（**只读 route/probe，不写任何 route 文件**）。');
    out.push('> 冻结（写 `frozenAt` + 生成 `<seed>.sha256`）由**设计会话**人工审阅后做，本工具不参与。');
    out.push('');
    out.push('| 项 | 值 |');
    out.push('|---|---|');
    out.push(`| 种子 | \`${route.seed}\` |`);
    out.push(`| 版本 | ${route.mcVersion} |`);
    out.push(`| \`frozenAt\` | \`${JSON.stringify(route.frozenAt)}\` —— ${route.frozenAt == null ? '**草稿，编排器默认拒跑**（SCHEMA §3）' : '已冻结'} |`);
    out.push(`| \`sha256File\` | \`${JSON.stringify(route.sha256File)}\` —— ${route.sha256File == null ? '冻结时才生成' : '已有'} |`);
    out.push(`| 站数 / REAL / UNVERIFIED | ${route.stations.length} / **${real}** / ${route.stations.length - real} |`);
    out.push(`| 探测来源 | \`${route.generatedFrom?.probe ?? '（无）'}\` |`);
    out.push(`| 生成时刻 | ${route.generatedAt} |`);
    out.push('');

    out.push('## 逐站清单');
    out.push('');
    for (const st of route.stations) {
        const { checks, counts, terrain, terrainTotal, verify } = checkStation(st);
        const cat = CAT_OF[st.id] ?? null;          // 类目名从 STATION_ORDER 反查（route 文件里不带 cat）
        const pts = st.scout?.points ?? [];
        out.push(`### ${String(st.seq).padStart(2, '0')} · \`${st.id}\` —— ${st.scout?.verify?.status}`);
        out.push('');
        out.push(`- **kind / dim**：\`${st.kind}\` / \`${st.dim}\``);
        out.push(`- **station 区域**：center \`${JSON.stringify(st.station.center)}\`（16 格粗化，运行时 bot 在 radius=${st.station.radius} 内自己找）· yHint \`${st.station.yHint}\` · lookFor \`${JSON.stringify(st.station.lookFor)}\``);
        out.push(`- **scout 核验**：status \`${verify.status}\` · method \`${verify.method ?? '-'}\`${verify.reason ? ` · reason \`${verify.reason}\`` : ''}`);
        out.push(`- **真值计数**：${fmtCounts(counts)}`);
        out.push(`- **地形对照**：${fmtTerrain(terrain, terrainTotal)}`);
        out.push(`- **scout 点位**：${pts.length} 个${st.scout?.pointsTruncated ? `（**已采样**，完整真值共 ${st.scout.pointsTotal} 个，在 verify.counts）` : ''}`);
        if (pts.length) {
            const brief = pts.slice(0, 4).map((p) => `${p.what ?? 'point'}(${p.x},${p.y},${p.z})`).join('、');
            out.push(`  - 样本：${brief}${pts.length > 4 ? ' …' : ''}`);
        }
        out.push(`- **fallback**：${(st.fallback ?? []).length ? `\`${st.fallback.join('`, `')}\`` : '（无）'}`);
        out.push(`- **证据路径**：\`.probe.json#categories.${cat ?? '(无类目)'}\` → \`bench/route/probe/${seed}.probe.json\`；服务器日志 \`bench/route/probe/_run_${seed}/\`${cat ? `/${cat}` : ''}/server.log\``);
        const probeCat = cat && probe?.categories?.[cat];
        if (probeCat) {
            out.push(`  - 本次探测：${probeCat.seconds ?? '?'}s · fills ${probeCat.fills ?? '?'} · r=${probeCat.r ?? '?'}${probeCat.widened ? '（加宽）' : ''} · 回执错位 ${probeCat.desyncStaleResponses ?? 0} · 自检 \`${JSON.stringify(probeCat.selfCheck ?? {})}\``);
        }
        out.push(`- **冻结前检查**：${checks.map((c) => `${c.ok ? '✅' : '❌'} ${c.label}`).join(' · ')}`);
        out.push('');
    }

    out.push('## 路线级风险（冻结前请逐条裁决）');
    out.push('');
    const risks = stationRisks(route);
    if (risks.length) risks.forEach((r) => out.push(`- ${r}`));
    else out.push('- 无');
    out.push('');

    out.push('## 冻结动作（本工具不做，人工做）');
    out.push('');
    out.push('1. 逐站核对上表，UNVERIFIED 站给出裁决；');
    out.push('2. 写 `frozenAt`（ISO 时间）；');
    out.push('3. 生成 `<seed>.sha256`（内容 = 除 `frozenAt` 外整个文件的规范化 sha256，SCHEMA §2）；');
    out.push(`4. 在 \`handover/minecraft.md\` 记一行：种子、sha256、审阅人。`);
    out.push('');
    out.push('> 冻结后再改必须升版本号（`<seed>.v2.json`），否则历史录像与 route 对不上号。');
    out.push('');

    return { text: out.join('\n'), route, real };
}

fs.mkdirSync(REVIEW_DIR, { recursive: true });
for (const seed of SEEDS) {
    const { text, real } = buildRouteReview(seed);
    const p = path.join(REVIEW_DIR, `${seed}.review.md`);
    fs.writeFileSync(p, text);
    console.log(`✓ ${path.relative(path.join(ROUTE_DIR, '..', '..'), p)}  ${real} REAL`);
}
console.log(`\n共 ${SEEDS.length} 份审阅清单 → ${path.relative(path.join(ROUTE_DIR, '..', '..'), REVIEW_DIR)}`);
