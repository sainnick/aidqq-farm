// s3_bastion_gold_piglins.mjs — ROUND7-C 续单：S3_bastion 的**金源地图 + 猪灵世界生成分布**
//
// 【为什么走存档解析器】手册 §5「只读预勘一律走 region_reader.mjs」。本单**不开服、不发任何 fill/summon**。
//   F 线 MC-S2-03 §B5 的"金源没着落"结论来自它的计数盒 x336..368 / z256..288 / y32..47 ——
//   那个盒**只擦到堡垒一角**（17424 格里只有 10 块黑曜石），而 C 线 scout 的金块/箱在 x322..361 / y33..80 / z217..265。
//   ⇒ 本单用**盘上已有存档**（ROUTE-06 时代生成、已 save-all flush 的 nether 区段）离线重算全范围。
//
// 【三条硬纪律，都是从踩过的坑来的】
//   ① **扫描范围要比目标大一圈，并检查边界上有没有命中**（手册 §5；S5 门室 9→12 就是被扫描窗下界切掉的）。
//      本工具**自动探测盘上真实覆盖范围**，并对每一类命中算"离覆盖边界多近"；
//      贴边就报 `coverageSufficient:false`，宁可说"没覆盖到"也不把截断读成真值。
//   ② **"没读到" ≠ "没有"**（手册 §5）。读数健康闸门（readableRatio）与地形对照分开记；
//      读不到就标 toolFailed，绝不折算成 0。
//   ③ **阳性对照**（手册 §4.10）：本单带三条 ——
//      (a) 地形对照 netherrack 计数非零；
//      (b) **年龄字段的阳性对照**：同一份存档里的 hoglin **带** `Age`/`ForcedAge` 顶层 tag，
//          证明解析器"能看见年龄 tag"；猪灵**没有** ⇒ 它们的年龄字段是默认 0（成年），不是"没读到"。
//          （1.16.1 `AgeableMob` 把年龄存成顶层 `Age`，不是 `IsBaby`；`Brain.Age` 不存在，别照 1.21 的直觉去读。）
//      (c) **与 ROUTE-02 控制台通道对账**：_world_A 上的 gold_block/gilded_blackstone/chest 计数
//          应与 `route/*.json` 里 fill-replace 的 22/227/5 逐个相等（两条独立通道）。
//
// 【输出】bench/route/probe/s3_bastion_gold_piglins.<tag>.json

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from './region_reader.mjs';

const argOf = (a, n, d) => { const i = a.indexOf('--' + n); return i >= 0 ? a[i + 1] : d; };

const WORLD = argOf(process.argv, 'world', 'D:/AI斗蛐蛐/bench/route/probe/_world_A');
const TAG = argOf(process.argv, 'tag', 'peaceful');
const ROUTE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUT = argOf(process.argv, 'out', path.join(ROUTE_DIR, 'probe', `s3_bastion_gold_piglins.${TAG}.json`));

const DIM = 'the_nether';
const Y1 = 0, Y2 = 127;
const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);
const FACES = [[1, 0, 0, '+x'], [-1, 0, 0, '-x'], [0, 1, 0, '+y'], [0, -1, 0, '-y'], [0, 0, 1, '+z'], [0, 0, -1, '-z']];

/** 作业点判据常量（全部写进产物，便于 F 线对拍） */
const CRIT = {
    standable: '脚下 1 格实心（非空气集）+ 身体 2 格空气集（bot 站得下）',
    piglinNear6: '站位中心 (x+0.5, y, z+0.5) 到猪灵 Pos 的 3D 欧氏距离 ≤ 6.0',
    piglinNear34: '同上，≤3.4（F 线 MC-S2-03 实测"并行伺候"用的窗口，留作同口径对照）',
    goldRadius: 8,
    goldExposed: '目标块 6 个面邻格里 ≥1 个属于空气集 {air,cave_air,void_air}（与 visibility_audit.mjs 同一判据）',
    minSeparation: 8,
    boundaryMargin: 4,
};

// ================================================================== 1. 覆盖范围自动探测
const w = openWorld(WORLD, { dims: ['overworld', DIM] });

// ⚠⚠ **必须把 C2 堡垒和 C3 要塞分开**：它们在同一份存档的**不同**区域（要塞在 z≈-149..-21、堡垒在 z≈192..320），
//   而两份存档的区域文件合并在同一个 `r.0.*.mca` 里。首次全盘扫描时 C3 的 **2 个箱子**
//   混进了堡垒的计数（chest 7 而不是 5）——**"同一张盘上"不等于"同一个结构"**。
//   ⇒ 显式限定 C2 堡垒的区块窗口（cx 14..26 / cz 10..22，即 blocks x224..431 / z160..367），
//      并且**边界检查按这个窗口算**（不是按整张盘）。
const CX0 = Number(argOf(process.argv, 'cx0', 14)), CX1 = Number(argOf(process.argv, 'cx1', 26));
const CZ0 = Number(argOf(process.argv, 'cz0', 10)), CZ1 = Number(argOf(process.argv, 'cz1', 22));

/** 在给定区块窗口内，列出真正有数据的区块（不是假设整个窗口都存了） */
function detectCoverage() {
    const regionDir = path.join(WORLD, 'DIM-1', 'region');
    const cxs = [], czs = [];
    const files = [];
    for (let cx = CX0; cx <= CX1; cx++) {
        for (let cz = CZ0; cz <= CZ1; cz++) {
            if (w.chunk(cx, cz, DIM)) { cxs.push(cx); czs.push(cz); }
        }
    }
    for (const f of fs.readdirSync(regionDir)) {
        if (!/^r\.-?\d+\.-?\d+\.mca$/.test(f)) continue;
        const st = fs.statSync(path.join(regionDir, f));
        if (st.size >= 8192 + 8) files.push(f);
    }
    if (!cxs.length) return null;
    return {
        requestedChunks: { cx: [CX0, CX1], cz: [CZ0, CZ1] },
        chunks: cxs.length,
        missingChunks: (CX1 - CX0 + 1) * (CZ1 - CZ0 + 1) - cxs.length,
        cx: [Math.min(...cxs), Math.max(...cxs)],
        cz: [Math.min(...czs), Math.max(...czs)],
        x: [Math.min(...cxs) * 16, (Math.max(...cxs) + 1) * 16 - 1],
        z: [Math.min(...czs) * 16, (Math.max(...czs) + 1) * 16 - 1],
        regionFiles: files,
    };
}

const cov = detectCoverage();
if (!cov) {
    console.error('NO_COVERAGE：盘上没有任何已保存的 nether 区块 —— 这是"没读到"，不是"没有"。');
    process.exit(2);
}
const BOX = { x1: cov.x[0], y1: Y1, z1: cov.z[0], x2: cov.x[1], y2: Y2, z2: cov.z[1] };
console.log(`覆盖范围：区块 cx ${cov.cx[0]}..${cov.cx[1]} / cz ${cov.cz[0]}..${cov.cz[1]}（${cov.chunks} 块）`);
console.log(`         方块 x ${BOX.x1}..${BOX.x2} / z ${BOX.z1}..${BOX.z2}（y ${Y1}..${Y2}）`);

// ================================================================== 2. 读数健康闸门 + 地形对照
const health = w.countInBox(BOX, null, DIM);
const readableRatio = 1 - health.unknownCells / health.cells;
const terrain = w.countInBox(BOX, ['netherrack', 'blackstone', 'nether_bricks', 'polished_blackstone_bricks'], DIM);
console.log(`读数健康：readable ${health.cells - health.unknownCells}/${health.cells}（${(readableRatio * 100).toFixed(2)}%）`);
console.log(`地形对照：${JSON.stringify(terrain.counts)}`);
if (readableRatio < 1) console.log(`  ⚠ unknownCells=${health.unknownCells} —— 下面每一类都另记 boundary，不把截断当真值`);

// ================================================================== 3. ① 金源普查（逐格，带暴露面）
const GOLD = new Set(['gold_block', 'gilded_blackstone', 'chest', 'trapped_chest']);
const goldHits = [];
const chunkHist = new Map();

for (let cx = cov.cx[0]; cx <= cov.cx[1]; cx++) {
    for (let cz = cov.cz[0]; cz <= cov.cz[1]; cz++) {
        const c = w.chunk(cx, cz, DIM);
        if (!c) continue;
        // 先看 palette 直方图：这块区块根本没有目标方块就跳过（绝大多数区块走这条路）
        const hist = new Map();
        for (let i = 0; i < c.filled.length; i++) {
            if (!c.filled[i]) continue;
            const n = c.palette[c.idx[i]]?.name ?? 'unknown';
            hist.set(n, (hist.get(n) ?? 0) + 1);
        }
        chunkHist.set(`${cx},${cz}`, Object.fromEntries(hist));
        let has = false;
        for (const n of hist.keys()) if (GOLD.has(n)) { has = true; break; }
        if (!has) continue;
        for (let y = Y1; y <= Y2; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
            const o = x + z * 16 + y * 256;
            if (!c.filled[o]) continue;
            const nm = c.palette[c.idx[o]]?.name;
            if (!GOLD.has(nm)) continue;
            const ax = cx * 16 + x, az = cz * 16 + z;
            const airFaces = [];
            for (const [dx, dy, dz, tag] of FACES) {
                if (AIRLIKE.has(w.blockAt(ax + dx, y + dy, az + dz, DIM))) airFaces.push(tag);
            }
            goldHits.push({ block: nm, xyz: [ax, y, az], exposed: airFaces.length > 0, airFaces });
        }
    }
}
const byBlock = {};
for (const g of goldHits) {
    const b = (byBlock[g.block] ??= { total: 0, exposed: 0, hidden: 0, airFaceHistogram: {} });
    b.total++; g.exposed ? b.exposed++ : b.hidden++;
    b.airFaceHistogram[g.airFaces.length] = (b.airFaceHistogram[g.airFaces.length] ?? 0) + 1;
}
console.log(`\n① 金源：${JSON.stringify(Object.fromEntries(Object.entries(byBlock).map(([k, v]) => [k, `${v.total}(暴露${v.exposed}/隐藏${v.hidden})`])))}`);

// ---- 边界检查（手册 §5：命中贴边 ⇒ 范围被截断）
function boundaryOf(list, getXYZ) {
    if (!list.length) return null;
    const xs = list.map(getXYZ), zs = list.map(getXYZ);
    const minX = Math.min(...xs.map((p) => p[0])), maxX = Math.max(...xs.map((p) => p[0]));
    const minZ = Math.min(...zs.map((p) => p[2])), maxZ = Math.max(...zs.map((p) => p[2]));
    const minY = Math.min(...xs.map((p) => p[1])), maxY = Math.max(...xs.map((p) => p[1]));
    return {
        bbox: { x: [minX, maxX], y: [minY, maxY], z: [minZ, maxZ] },
        distToEdge: {
            west: minX - BOX.x1, east: BOX.x2 - maxX,
            north: minZ - BOX.z1, south: BOX.z2 - maxZ,
        },
        minDistToEdge: Math.min(minX - BOX.x1, BOX.x2 - maxX, minZ - BOX.z1, BOX.z2 - maxZ),
    };
}
const goldBnd = boundaryOf(goldHits, (g) => g.xyz);

// ================================================================== 4. ② 猪灵（世界生成时）+ 8×8 网格密度
const pigs = [], hogs = [], others = {};
for (let cx = cov.cx[0]; cx <= cov.cx[1]; cx++) {
    for (let cz = cov.cz[0]; cz <= cov.cz[1]; cz++) {
        const c = w.chunk(cx, cz, DIM);
        if (!c) continue;
        for (const e of c.entities) {
            const rec = {
                pos: e.pos.map((v) => Math.round(v * 1000) / 1000),
                worldgen: e.raw.PersistenceRequired === 1,        // 堡垒生成时 setPersistenceRequired()
                ageTag: ('Age' in e.raw) ? Number(e.raw.Age) : null,
                forcedAgeTag: ('ForcedAge' in e.raw) ? Number(e.raw.ForcedAge) : null,
                isBabyTag: ('IsBaby' in e.raw) ? Number(e.raw.IsBaby) : null,
                health: e.raw.Health ?? null,
            };
            if (e.id === 'piglin') pigs.push(rec);
            else if (e.id === 'hoglin') hogs.push(rec);
            else others[e.id] = (others[e.id] ?? 0) + 1;
        }
    }
}
const isBaby = (r) => r.isBabyTag === 1 || (r.ageTag != null && r.ageTag > 0);
const wg = pigs.filter((p) => p.worldgen);
console.log(`\n② 猪灵：共 ${pigs.length}（世界生成 ${wg.length} / 非生成 ${pigs.length - wg.length}）｜幼年 ${pigs.filter(isBaby).length}`);
console.log(`   阳性对照(年龄字段)：hoglin ${hogs.length} 头，其中带 Age 顶层 tag 的 ${hogs.filter((h) => h.ageTag != null).length} 头`);
console.log(`   其他实体：${JSON.stringify(others)}`);

// ---- 8×8 网格密度
const grid = new Map();
const key = (gx, gz) => `${gx},${gz}`;
for (const p of wg) {
    const gx = Math.floor(p.pos[0] / 8) * 8, gz = Math.floor(p.pos[2] / 8) * 8;
    const k = key(gx, gz);
    const g = grid.get(k) ?? { gx, gz, piglins: 0, goldBlock: 0, gilded: 0, chest: 0, yRange: [1e9, -1e9] };
    g.piglins++;
    g.yRange[0] = Math.min(g.yRange[0], p.pos[1]); g.yRange[1] = Math.max(g.yRange[1], p.pos[1]);
    grid.set(k, g);
}
for (const hit of goldHits) {
    const gk = key(Math.floor(hit.xyz[0] / 8) * 8, Math.floor(hit.xyz[2] / 8) * 8);
    if (!grid.has(gk)) grid.set(gk, { gx: Math.floor(hit.xyz[0] / 8) * 8, gz: Math.floor(hit.xyz[2] / 8) * 8, piglins: 0, goldBlock: 0, gilded: 0, chest: 0, yRange: [null, null] });
    const cell = grid.get(gk);
    if (hit.block === 'gold_block') cell.goldBlock++;
    else if (hit.block === 'gilded_blackstone') cell.gilded++;
    else cell.chest++;
}
const gridArr = [...grid.values()].sort((a, b) => b.piglins - a.piglins || (b.goldBlock + b.gilded) - (a.goldBlock + a.gilded));
console.log(`\n   8×8 网格：非空格 ${gridArr.length}，猪灵密度前 6 ——`);
for (const g of gridArr.filter((x) => x.piglins > 0).slice(0, 6)) {
    console.log(`     格(${g.gx}..${g.gx + 7}, ${g.gz}..${g.gz + 7})：猪灵 ${g.piglins}  y ${g.yRange[0]}..${g.yRange[1]}  金块 ${g.goldBlock} 鎏金 ${g.gilded} 箱 ${g.chest}`);
}
const pigBnd = boundaryOf(wg.map((p) => ({ xyz: p.pos })), (p) => p.xyz);

// ================================================================== 5. ③ 作业点推荐
/** 站得下的空气格：脚下实心 + 身体 2 格空气集 */
function standable(x, y, z) {
    if (!AIRLIKE.has(w.blockAt(x, y, z, DIM))) return false;
    if (!AIRLIKE.has(w.blockAt(x, y + 1, z, DIM))) return false;
    if (!AIRLIKE.has(w.blockAt(x, y + 2, z, DIM))) return false;
    return !AIRLIKE.has(w.blockAt(x, y - 1, z, DIM));
}
const exposedGold = goldHits.filter((g) => g.exposed);
const cands = [];
// 候选只在"有世界生成猪灵的 8×8 格"所在的格子里枚举（其它地方猪灵密度必为 0）
for (const g of gridArr) {
    for (let z = g.gz; z < g.gz + 8; z++) for (let x = g.gx; x < g.gx + 8; x++) {
        for (let y = Y1; y <= Y2; y++) {
            if (!standable(x, y, z)) continue;
            const cxm = x + 0.5, czm = z + 0.5;
            let n6 = 0, n34 = 0, nearest = null, nd = Infinity;
            for (const p of wg) {
                const d = Math.hypot(p.pos[0] - cxm, p.pos[1] - y, p.pos[2] - czm);
                if (d <= 6) n6++;
                if (d <= 3.4) n34++;
                if (d < nd) { nd = d; nearest = p.pos; }
            }
            let gD = Infinity, gRec = null;
            for (const gg of exposedGold) {
                const d = Math.hypot(gg.xyz[0] - cxm, gg.xyz[1] - y, gg.xyz[2] - czm);
                if (d < gD) { gD = d; gRec = gg; }
            }
            if (gD > CRIT.goldRadius) continue;            // 必须"有暴露金源"在 8 格内
            cands.push({
                stand: [x, y, z], piglinWithin6: n6, piglinWithin34: n34,
                nearestPiglin: nearest, nearestPiglinDist: Number(nd.toFixed(2)),
                nearestGold: gRec.xyz, nearestGoldBlock: gRec.block, nearestGoldDist: Number(gD.toFixed(2)),
            });
        }
    }
}
cands.sort((a, b) => b.piglinWithin6 - a.piglinWithin6 || a.nearestGoldDist - b.nearestGoldDist
    || a.stand[0] - b.stand[0] || a.stand[2] - b.stand[2]);
const picks = [];
for (const c of cands) {
    if (picks.length >= 3) break;
    if (picks.some((p) => Math.hypot(p.stand[0] - c.stand[0], p.stand[1] - c.stand[1], p.stand[2] - c.stand[2]) < CRIT.minSeparation)) continue;
    picks.push(c);
}
console.log(`\n③ 作业点候选（站得下 + 8 格内有暴露金源）：${cands.length} 个；推荐 ${picks.length} 个`);
for (const p of picks) {
    console.log(`   站位 (${p.stand})  6格内猪灵 ${p.piglinWithin6}（3.4格内 ${p.piglinWithin34}）  最近猪灵 ${p.nearestPiglinDist} 格  暴露金源 ${p.nearestGoldBlock}@${p.nearestGold} ${p.nearestGoldDist} 格`);
}

// ================================================================== 6. 阳性对照（c）：与 ROUTE-02 控制台真值对账
const ROUTE_TRUTH = { gold_block: 22, gilded_blackstone: 227, chest: 5 };
const cross = {};
for (const [k, v] of Object.entries(ROUTE_TRUTH)) {
    const got = byBlock[k]?.total ?? 0;
    cross[k] = { routeFillReplace: v, archiveReader: got, agree: v === got };
}
console.log(`\n阳性对照（与 ROUTE-02 fill-replace 对账）：${JSON.stringify(cross)}`);

// ================================================================== 7. 落盘
const coverageSufficient = {
    gold: goldBnd ? goldBnd.minDistToEdge >= CRIT.boundaryMargin : null,
    piglin: pigBnd ? pigBnd.minDistToEdge >= CRIT.boundaryMargin : null,
};
const out = {
    schema: 'aidqq-round7c-s3-bastion-gold-piglins/1',
    at: new Date().toISOString(),
    tag: TAG, world: WORLD, dim: DIM, seed: '4926685115947721762', mcVersion: '1.16.1',
    box: BOX, criteria: CRIT,
    coverage: { ...cov, note: '盘上真实覆盖范围（自动探测，非人工假设）' },
    readHealth: { cells: health.cells, unknownCells: health.unknownCells, readableRatio: Number(readableRatio.toFixed(6)) },
    terrainControl: terrain.counts,
    gold: {
        byBlock, total: goldHits.length,
        boundary: goldBnd, coverageSufficient: coverageSufficient.gold,
        exposedTotal: exposedGold.length,
        list: goldHits.sort((a, b) => a.xyz[2] - b.xyz[2] || a.xyz[0] - b.xyz[0] || a.xyz[1] - b.xyz[1]),
    },
    piglins: {
        total: pigs.length, worldgen: wg.length, nonWorldgen: pigs.length - wg.length,
        babies: pigs.filter(isBaby).length,
        ageFieldPositiveControl: {
            note: '1.16.1 AgeableMob 把年龄存成**顶层** Age/ForcedAge（不是 IsBaby，也不是 Brain.Age）',
            hoglins: hogs.length, hoglinsWithAgeTag: hogs.filter((h) => h.ageTag != null).length,
            piglinsWithAgeTag: pigs.filter((p) => p.ageTag != null).length,
            verdict: hogs.filter((h) => h.ageTag != null).length > 0 && pigs.every((p) => p.ageTag == null)
                ? '解析器能看见年龄 tag（hoglin 为阳性对照）；猪灵没有该 tag ⇒ 年龄取默认 0 = 成年，不是"没读到"'
                : '阳性对照不成立，年龄结论降级为 INCONCLUSIVE',
        },
        boundary: pigBnd, coverageSufficient: coverageSufficient.piglin,
        list: wg.sort((a, b) => b.pos[1] - a.pos[1]),
        nonWorldgenList: pigs.filter((p) => !p.worldgen),
    },
    hoglins: hogs,
    otherEntities: others,
    grid8x8: { cells: gridArr.length, nonEmpty: gridArr.filter((g) => g.piglins > 0).length, list: gridArr },
    workPoints: { candidates: cands.length, picks, note: '只给数据，F 线去实测；未做寻路（BFS 到堡垒外的连通性未验）' },
    positiveControls: { terrain: terrain.counts, routeCrossCheck: cross },
};
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
console.log(`\n落盘：${OUT}`);
