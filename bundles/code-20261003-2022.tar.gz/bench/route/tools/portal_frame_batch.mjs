// portal_frame_batch.mjs — ROUND3 §补充二 C-线：**批量扫 SEED-03 Top30 的废弃传送门框体**
//
// 目标（派单原文）：对 Top30 每个种子输出五项——
//   ① 框内黑曜石数   ② 缺格数   ③ 缺格被什么占着   ④ 门框内有没有岩浆   ⑤ 16 格内是否同时有合格的水源和岩浆源
// 目的：和 SEED-03 §9.4 的**五站硬上限**合并排序，**推荐正式主种子**（只推荐，冻结由设计会话做）。
//
// 【每个种子两趟开服，共用一个 fresh world 生命周期内的两个阶段】
//   阶段 A（世界 1）：以 cubiomes 的废弃门坐标 (rp_x, rp_z) 为中心 r=24 粗扫 obsidian/crying_obsidian
//                     + 八叉下钻拿到精确坐标 → findBestFrame 枚举候选框打分取最优。
//   阶段 B（世界 2，**必须换 fresh world**）：classifyFrameCells 对那一片 4×5×1 做逐格真值分类；
//                     再以门为中心 r=16 扫 `water[level=0]` / `lava[level=0]`（1.16.1 的 fill 认方块状态，
//                     已实测）。
//   ⚠ 阶段 B 必须换世界：阶段 A 的 fill 把命中方块换成了 marker，在污染世界里"读"框体只会读出 barrier。
//      这条是 ROUTE-02 §4.3 铁律在"读"方向上的应用。
//
// 【踩过的坑，别再踩（详见 cell_probe.mjs 头）】
//   1. 1.16.1 **没有 /say**，tellraw 零玩家时也不落控制台 → 条件回读只能用 fill 回执。
//   2. `drillUntil` 是在**按坐标序遍历的盒子里**收手 → 点集偏向扫描区域边角，不是离门最近处。
//      所以岩浆/水源这类"要离门最近"的抽样必须用 `drillNearestBoxes` 锚定参考点。
//
// 【断点续跑】每跑完一个种子立刻写 JSON；`--resume` 跳过已完成的种子（泳道随时可能让路/到点）。
//
// 用法（Node 20）：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\portal_frame_batch.mjs --limit 4 --resume
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\portal_frame_batch.mjs --seed -8839485814800629942

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR, portState } from './console.mjs';
import { drill, boxesOf } from './scan.mjs';
import { checkFrame, findBestFrame, classifyFrameCells } from './portal_frame.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const TOP30 = path.join(HERE, '..', '..', '..', 'experiments', 'seed-scout', 'top30.csv');
const OUT = path.join(ROUTE_DIR, 'probe', 'portal_frame_batch.json');

const LIMIT = parseInt(argOf(process.argv, 'limit', '0'), 10);
const ONLY = (argOf(process.argv, 'seed', '') || '').trim();
const RESUME = process.argv.includes('--resume');
const R = parseInt(argOf(process.argv, 'r', '24'), 10);
const R16 = 16;                       // 「16 格内」的水源/岩浆源半径（派单原文）

/** 读 top30.csv（SEED-01 A 级 cubiomes 全量粗筛的 Top30；这 30 个种子的其余各站已核验过） */
function loadSeeds() {
    const lines = fs.readFileSync(TOP30, 'utf8').split(/\r?\n/).filter((l) => l.trim());
    const head = lines[0].split(',');
    return lines.slice(1).map((l, i) => {
        const f = l.split(',');
        const row = Object.fromEntries(head.map((h, k) => [h, f[k]]));
        return {
            rank: i + 1, seed: row.seed,
            rp: { x: +row.rp_x, z: +row.rp_z },
            sh: { x: +row.sh_x, z: +row.sh_z },
            dShOw: +row.d_sh_ow, dBast: +row.d_bast, dFort: +row.d_fort,
            spawnBiome: row.spawn_biome,
        };
    });
}

const store = fs.existsSync(OUT)
    ? JSON.parse(fs.readFileSync(OUT, 'utf8'))
    : { schema: 'aidqq-portal-frame-batch/1', startedAt: new Date().toISOString(), r: R, r16: R16, results: {} };

let handle = null;

/** 一个种子的完整取证 */
async function scanOne(meta) {
    const t0 = Date.now();
    const out = { seed: meta.seed, rank: meta.rank, rp: meta.rp, sh: meta.sh, status: 'NOT_RUN', startedAt: new Date().toISOString() };

    // ---------- 阶段 A：定位 + 下钻 ----------
    handle = await bootLaneC({ seed: meta.seed, runDir: path.join(ROUTE_DIR, 'probe', `_run_framebatch_${meta.seed}`), logFn: log });
    const ra = await drill(handle.con, 'overworld', meta.rp.x, meta.rp.z, R, [[40, 71], [72, 100]],
        ['minecraft:obsidian', 'minecraft:crying_obsidian'],
        { drillBlocks: ['minecraft:obsidian', 'minecraft:crying_obsidian'], drillUntil: 0, maxBoxes: 4000, logFn: null });
    const pts = [
        ...(ra.perBlock['minecraft:obsidian']?.points ?? []),
        ...(ra.perBlock['minecraft:crying_obsidian']?.points ?? []),
    ];
    out.discovery = {
        counts: ra.counts, terrain: ra.terrain, fills: ra.fills, r: ra.r, desync: ra.desync ?? 0,
        points: pts.length, truncated: ra.truncated, selfCheck: ra.selfCheck, boxes: ra.boxes,
    };
    log(`  [${meta.seed}] A 阶段：obsidian=${ra.counts['minecraft:obsidian']} crying=${ra.counts['minecraft:crying_obsidian']} 点=${pts.length} 对照=${JSON.stringify(ra.terrain)}`);

    const { best, runnersUp, candidatesTried } = findBestFrame(pts);
    out.candidates = { tried: candidatesTried, runnersUp };
    if (!best) {
        out.status = 'NO_OBSIDIAN_FOUND';
        out.note = `这一片 r=${R} 内没有 obsidian/crying_obsidian（对照=${JSON.stringify(ra.terrain)} 说明工具正常）`;
        await shutdownLaneC(handle); handle = null;
        out.seconds = Math.round((Date.now() - t0) / 1000);
        return out;
    }
    // 候选框的"命中格数"太低时不能当门框报（B 线 r4 修的假阳性：找不到框被当成"缺 0 格"→判合格）
    out.candidates.best = { origin: [best.origin.x, best.origin.y, best.origin.z], axis: best.axis, reqHits: best.reqHits };
    if (best.reqHits < 4) {
        out.status = 'LOW_CONFIDENCE_FRAME';
        out.note = `最优候选只命中 ${best.reqHits} 个必需格（<4），不足以判定这是一个门框；按 B 线 r4 的原则不报框内计数`;
        await shutdownLaneC(handle); handle = null;
        out.seconds = Math.round((Date.now() - t0) / 1000);
        return out;
    }
    await shutdownLaneC(handle); handle = null;

    // ---------- 阶段 B：干净世界里的逐格真值 + 16 格内水源/岩浆源 ----------
    handle = await bootLaneC({ seed: meta.seed, runDir: path.join(ROUTE_DIR, 'probe', `_run_framebatch_${meta.seed}_truth`), logFn: log });
    const cls = await classifyFrameCells(handle.con, 'overworld', best.origin, best.axis, { logFn: log });
    const names = new Map();
    cls.cells.forEach((c, i) => names.set(`${c.pos.x},${c.pos.y},${c.pos.z}`, cls.blocks[i]));
    const fr = checkFrame(best.origin, best.axis, (p) => names.get(`${p.x},${p.y},${p.z}`) ?? null);
    out.frame = {
        origin: [best.origin.x, best.origin.y, best.origin.z], axis: best.axis,
        obsidian: fr.obsidian, required: fr.required, optionalObsidian: fr.optionalObsidian,
        missing: fr.missing, wrong: fr.wrong, dirty: fr.dirty,
        obsidianToPlace: fr.obsidianToPlace, usable: fr.ok,
        cellTruth: cls.cells.map((c, i) => ({
            pos: [c.pos.x, c.pos.y, c.pos.z], kind: c.kind, u: c.u, dy: c.dy, optional: !!c.optional, got: cls.blocks[i],
        })),
        classify: { fills: cls.fills, airTests: cls.airTests, unresolved: cls.unresolved },
    };
    // ④ 门框内有没有岩浆（逐格真值里直接看）
    out.lavaInFrame = cls.cells
        .map((c, i) => ({ cell: [c.pos.x, c.pos.y, c.pos.z], kind: c.kind, got: cls.blocks[i] }))
        .filter((x) => x.got === 'lava');

    // ⑤ 16 格内的合格水源 / 岩浆源（level 0）
    const doorY = best.origin.y;
    const yLo = Math.max(1, doorY - 24), yHi = Math.min(120, doorY + 24);
    const bands = [[yLo, yLo + 15], [yLo + 16, yLo + 31], [yLo + 32, yHi]].filter(([a, b]) => a <= b);
    const rs = await drill(handle.con, 'overworld', meta.rp.x, meta.rp.z, R16, bands,
        ['minecraft:water[level=0]', 'minecraft:lava[level=0]'],
        { drillBlocks: ['minecraft:water[level=0]', 'minecraft:lava[level=0]'], drillNearestBoxes: 2, drillUntil: 40, maxBoxes: 2500, logFn: null });
    const near = (arr) => arr
        .map((p) => ({ ...p, dist2d: Math.round(Math.hypot(p.x - best.origin.x, p.z - best.origin.z) * 10) / 10, dy: Math.abs(p.y - doorY) }))
        .sort((a, b) => a.dist2d - b.dist2d || a.dy - b.dy);
    const waterPts = near(rs.perBlock['minecraft:water[level=0]']?.points ?? []);
    const lavaPts = near(rs.perBlock['minecraft:lava[level=0]']?.points ?? []);
    out.sources16 = {
        definition: `XZ ≤ ${R16} 格、y 带 ${yLo}..${yHi}（门在 y=${doorY}）；源块=level 0；抽样口径：离参考点最近的 ${2} 个盒`,
        water: { coarse: rs.counts['minecraft:water[level=0]'] ?? 0, points: waterPts.slice(0, 6), within16: waterPts.filter((p) => p.dist2d <= R16).length },
        lava: { coarse: rs.counts['minecraft:lava[level=0]'] ?? 0, points: lavaPts.slice(0, 6), within16: lavaPts.filter((p) => p.dist2d <= R16).length },
        terrain: rs.terrain,
    };
    out.hasWaterAndLava16 = out.sources16.water.within16 > 0 && out.sources16.lava.within16 > 0;

    out.status = 'OK';
    out.summary = {
        frameObsidian: fr.obsidian, required: fr.required,
        missing: fr.missing.length, wrong: fr.wrong.length, interiorDirty: fr.dirty.length,
        obsidianToPlace: fr.obsidianToPlace, usable: fr.ok,
        lavaInFrame: out.lavaInFrame.length,
        waterWithin16: out.sources16.water.within16, lavaWithin16: out.sources16.lava.within16,
        bothWithin16: out.hasWaterAndLava16,
    };
    log(`  [${meta.seed}] B 阶段：框内 obsidian ${fr.obsidian}/${fr.required} · 缺(空) ${fr.missing.length} · 错块 ${fr.wrong.length}`
        + ` · 需补 ${fr.obsidianToPlace} · 框内岩浆 ${out.lavaInFrame.length} · 16 格内 水 ${out.sources16.water.within16} / 岩浆 ${out.sources16.lava.within16}`);

    await shutdownLaneC(handle); handle = null;
    out.seconds = Math.round((Date.now() - t0) / 1000);
    return out;
}

let all = loadSeeds();
if (ONLY) all = all.filter((s) => s.seed === ONLY);
else if (LIMIT > 0) all = all.slice(0, LIMIT);
if (RESUME) all = all.filter((s) => !store.results[s.seed] || store.results[s.seed].status === 'NOT_RUN');

log(`批量框体扫描：${all.length} 个种子（r=${R}，16 格水源/岩浆口径 r=${R16}）${RESUME ? '，--resume 跳过已完成' : ''}`);
try {
    for (const meta of all) {
        log(`--- [${meta.rank}] ${meta.seed}  rp=(${meta.rp.x},${meta.rp.z}) ---`);
        try {
            store.results[meta.seed] = await scanOne(meta);
        } catch (e) {
            // ⚠ **catch 里必须关服**：不关的话 handle 还挂着上一个阶段的 java，
            //   下一个种子的 bootLaneC 会 freshWorld（删世界）+ 起服 → 端口被占 → 起服失败 →
            //   重试 3 次后抛错 —— 于是**后面每一个种子都被记成 ERROR**，而真因只是上一格没关服。
            //   本单实测踩过：整个批次卡死 8 分钟并一直占着泳道。
            await shutdownLaneC(handle).catch(() => { });
            handle = null;
            store.results[meta.seed] = { seed: meta.seed, rank: meta.rank, status: 'ERROR', error: String(e && e.stack ? e.stack : e).slice(0, 500), at: new Date().toISOString() };
            log(`  ✗ ${meta.seed} 失败：${String(e).slice(0, 120)}`);
        }
        store.updatedAt = new Date().toISOString();
        fs.writeFileSync(OUT, JSON.stringify(store, null, 2) + '\n');   // 增量落盘
    }
} finally {
    await shutdownLaneC(handle);
    const done = Object.values(store.results);
    log(`小结：${done.length} 个种子有结果 —— OK ${done.filter((r) => r.status === 'OK').length}`
        + ` / NO_OBSIDIAN_FOUND ${done.filter((r) => r.status === 'NO_OBSIDIAN_FOUND').length}`
        + ` / LOW_CONFIDENCE ${done.filter((r) => r.status === 'LOW_CONFIDENCE_FRAME').length}`
        + ` / ERROR ${done.filter((r) => r.status === 'ERROR').length}`);
    log(`落盘：${OUT}`);
    log(`收工：端口 ${JSON.stringify(portState())}`);
}
