// seed_recommend.mjs — ROUND3 §补充二 C-线：把**框体实测**与 **SEED-03 §9.4 五站硬上限**合并，**推荐正式主种子**
//
// 明确边界（本工具只"推荐"，不冻结）：
//   - 不写任何 `frozenAt`、不生成 `.sha256`、不动 route 文件（SCHEMA §3 冻结由设计会话做）。
//   - 输出两份：排序后的完整表 + 一句话推荐，供设计会话拍板。
//
// 排序口径（派单原文「优先：缺格 ≤1、或者缺格 ≤3 且 16 格内有水有岩浆；其次看要塞距离和下界废墟门」）：
//   tier 1  缺格 ≤1                                        —— 补 1 格，最省
//   tier 2  缺格 ≤3 且 16 格内**同时**有合格水源与岩浆源    —— 局部浇筑可行
//   tier 3  缺格 ≤3 但水源/岩浆不齐                        —— 要么多跑几趟，要么另找源
//   tier 4  缺格 >3                                        —— 结构代价大
// 同 tier 内依次比：① 五站硬上限是否全过（SEED-03 §9.4 strict.capsPass）
//                 ② 缺格数少  ③ 要塞主世界距离短（d_sh_ow）  ④ 要塞旁有无下界废弃传送门
//                 ⑤ 五站"最差归一化距离"（§9.4 worstNorm，小者好）
//
// 用法：node bench/route/tools/seed_recommend.mjs [--out <path>]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.join(HERE, '..', '..', '..');
const RERANK = path.join(REPO, 'experiments', 'seed-scout', 's3_results', 's3_rerank.json');
const BATCH = path.join(HERE, '..', 'probe', 'portal_frame_batch.json');
const NPORTAL = path.join(HERE, '..', 'probe', 'nether_portal_scan.json');
const OUT_JSON = path.join(HERE, '..', 'probe', 'seed_recommendation.json');
const OUT_MD = path.join(HERE, '..', 'probe', 'seed_recommendation.md');

const readJson = (p) => (fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : null);
const rerank = readJson(RERANK), batch = readJson(BATCH), nportal = readJson(NPORTAL);
if (!rerank) { console.error(`缺少 ${RERANK}`); process.exit(2); }
if (!batch) { console.error(`缺少 ${BATCH}（先跑 portal_frame_batch.mjs）`); process.exit(2); }

const capsBySeed = new Map((rerank.strict ?? []).map((r) => [String(r.seed), r]));
/** 要塞对应点下界 64 格内有废弃传送门的种子（P1 结果，"其次看下界废墟门"用） */
const netherPortalSeeds = new Set(
    (nportal?.results ?? []).filter((r) => (r.withinRadius?.length ?? 0) > 0).map((r) => String(r.seed)),
);

const rows = Object.values(batch.results ?? {}).map((r) => {
    const caps = capsBySeed.get(String(r.seed)) ?? null;
    const s = r.summary ?? {};
    // 「缺格」= 必需格里不是 obsidian 的格数（空气缺格 + 错块格都要补，放量也是一格）
    const missing = (s.missing ?? 0) + (s.wrong ?? 0);
    const hasBoth = !!s.bothWithin16;
    const tier = r.status !== 'OK' ? 9
        : missing <= 1 ? 1
            : missing <= 3 && hasBoth ? 2
                : missing <= 3 ? 3 : 4;
    return {
        seed: r.seed, rank_in_top30: r.rank, status: r.status, tier,
        frameObsidian: s.frameObsidian ?? null, required: s.required ?? null,
        missingAir: s.missing ?? null, wrongBlocks: s.wrong ?? null,
        missingTotal: r.status === 'OK' ? missing : null,
        obsidianToPlace: s.obsidianToPlace ?? null,
        lavaInFrame: s.lavaInFrame ?? null,
        water16: s.waterWithin16 ?? null, lava16: s.lavaWithin16 ?? null, bothWithin16: hasBoth,
        capsPass: caps?.capsPass ?? null, fails: caps?.fails || '',
        worstLeg: caps?.worstLeg ?? null, worstNorm: caps?.worstNorm ?? null,
        dShOw: caps?.legD?.stronghold ?? r.dShOw ?? null,
        netherPortalNearStronghold: netherPortalSeeds.has(String(r.seed)),
        note: r.note ?? '', error: r.error ? String(r.error).split('\n')[0] : '',
    };
});

rows.sort((a, b) => (a.tier - b.tier)
    || ((b.capsPass ? 1 : 0) - (a.capsPass ? 1 : 0))
    || ((a.missingTotal ?? 99) - (b.missingTotal ?? 99))
    || ((a.dShOw ?? 1e9) - (b.dShOw ?? 1e9))
    || ((b.netherPortalNearStronghold ? 1 : 0) - (a.netherPortalNearStronghold ? 1 : 0))
    || ((a.worstNorm ?? 9) - (b.worstNorm ?? 9)));

const tierName = { 1: '① 缺格≤1', 2: '② 缺格≤3 + 16格内有水有岩浆', 3: '③ 缺格≤3 但水/岩浆不齐', 4: '④ 缺格>3', 9: '— 未测出框体' };

const md = [];
md.push('# Top30 框体实测 × 五站硬上限 合并排序（推荐用）');
md.push('');
md.push('> 由 `bench/route/tools/seed_recommend.mjs` 生成。**只推荐，不冻结**——`frozenAt` 与 `<seed>.sha256` 由设计会话拍板后写。');
md.push('> 框体列来自 `bench/route/probe/portal_frame_batch.json`（服务端权威：fill 回执 + 八叉下钻 + 干净世界逐格分类）；');
md.push('> 五站列来自 `experiments/seed-scout/s3_results/s3_rerank.json`（SEED-03 §9.4，服务器真值重扫）。');
md.push('');
md.push('| # | 种子 | 档 | 框内 obsidian | 缺格(总) | 缺格明细 | 需补 obsidian | 框内岩浆 | 16格内水/岩浆 | 五站硬上限 | 要塞距离 | 要塞旁下界废墟门 |');
md.push('|---|---|---|---|---|---|---|---|---|---|---|---|');
rows.forEach((r, i) => {
    md.push(`| ${i + 1} | \`${r.seed}\` | ${tierName[r.tier]} | ${r.frameObsidian ?? '-'}/${r.required ?? '-'} | **${r.missingTotal ?? '-'}** `
        + `| 缺(空)${r.missingAir ?? '-'} + 错块${r.wrongBlocks ?? '-'} | ${r.obsidianToPlace ?? '-'} | ${r.lavaInFrame ?? '-'} `
        + `| ${r.water16 ?? '-'}/${r.lava16 ?? '-'}${r.bothWithin16 ? ' ✅' : ''} `
        + `| ${r.capsPass === null ? '-' : (r.capsPass ? '✅ 全过' : `❌ ${r.fails}`)} | ${r.dShOw != null ? Math.round(r.dShOw) : '-'} | ${r.netherPortalNearStronghold ? '✅ 有' : '无'} |`);
});
md.push('');

const best = rows.find((r) => r.tier === 1) ?? rows.find((r) => r.tier === 2) ?? rows.find((r) => r.tier <= 3);
md.push('## 推荐');
md.push('');
if (!best) {
    md.push('- **没有可推荐的种子**：要么没测出框体，要么全部缺格 >3。请看上面的表和 `portal_frame_batch.json` 的原始数据。');
} else {
    md.push(`> **推荐 \`${best.seed}\`**（档位 ${tierName[best.tier]}）。`);
    md.push('');
    md.push(`- 框内 obsidian **${best.frameObsidian}/${best.required}**，缺格合计 **${best.missingTotal}**（空气 ${best.missingAir} + 错块 ${best.wrongBlocks}），需补 obsidian **${best.obsidianToPlace}** 格`);
    md.push(`- 门框内岩浆：**${best.lavaInFrame}** 格${(best.lavaInFrame ?? 0) > 0 ? '（**要占位处理**——B 线 r4 的前置条件之一）' : '（无）'}`);
    md.push(`- 16 格内合格源：水 ${best.water16} / 岩浆 ${best.lava16}${best.bothWithin16 ? '（**两者都有 → 局部浇筑可行**）' : '（不齐）'}`);
    md.push(`- 五站硬上限：${best.capsPass ? '✅ 全过' : `❌ ${best.fails || '见 s3_rerank.json'}`}；最差站 \`${best.worstLeg}\` 归一化 ${best.worstNorm != null ? best.worstNorm.toFixed(3) : '-'}`);
    md.push(`- 要塞主世界距离 **${best.dShOw != null ? Math.round(best.dShOw) : '-'}** 格；要塞对应点下界 64 格内${best.netherPortalNearStronghold ? '**有**废弃传送门' : '没有废弃传送门'}`);
    if (best.note) md.push(`- 备注：${best.note}`);
}
md.push('');
md.push('## 口径与边界（别误读这张表）');
md.push('');
md.push('- **「缺格」= 必需格里不是 obsidian 的格数**（空气缺格 + 错块格）。错块也要补一格，且 `crying_obsidian` 必须先挖掉（1.16 要钻石/下界合金镐）。');
md.push('- 框体几何 = 生产 `nether.js` 的 `frameCells` 移植（4×5 框、内部 2×3、**1.16.1 顶行两角可省**）。');
md.push('- 找不到门框的种子记 `NO_OBSIDIAN_FOUND` / `LOW_CONFIDENCE_FRAME`，**不按"缺 0 格"算合格**（B 线 r4 修过的假阳性）。');
md.push('- 「16 格内」= **XZ ≤16 格**、y 带取门 y±24（bot 实际赶路看的是水平距离）；源块 = `level 0`。');
md.push('- 五站硬上限里 `d_fort` 缺失（值为 -1）的种子在 `s3_rerank.json` 中已按缺腿处理，排序以 `capsPass` 为准。');
md.push('');

fs.mkdirSync(path.dirname(OUT_JSON), { recursive: true });
fs.writeFileSync(OUT_JSON, JSON.stringify({ generatedAt: new Date().toISOString(), rows, recommended: best?.seed ?? null }, null, 2) + '\n');
fs.writeFileSync(OUT_MD, md.join('\n'));
console.log(md.join('\n'));
console.log(`\n落盘：${OUT_MD}`);
