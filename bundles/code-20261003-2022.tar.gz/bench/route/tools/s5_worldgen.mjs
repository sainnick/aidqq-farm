// s5_worldgen.mjs — ROUND7-C：只为 S5_stronghold_room **生成**世界（读数一律离线做）
//
// 【为什么单独一个文件、而不是改 worldgen_for_region.mjs】
//   `worldgen_for_region.mjs` 的 REGIONS 是**硬编码**的羊/门/堡垒/要塞对照组，没有要塞门室。
//   手册 §9「bench 脚本各开发线在自己的目录工作、改已有文件要先报告」⇒ 本单**不改**它，
//   新写一个只做 S5 的小工具，复用它的 `console.mjs` / `scan.mjs` 导出。
//
// 【控制台只做两件事】手册 §5：① forceload（生成区块）② `save-all flush`。
//   **不发任何 fill / summon / setblock** —— 一旦发了就污染世界（ROUTE-02 吃过三次亏）。
//   末影之眼是**世界生成时就定死**的（`EndPortalFrameFeature` 每框 1/23 概率带 eye，
//   状态直接写进存档）⇒ 离线读存档就能读到真值，不需要也不应该用命令去查。
//
// 【本单不做的事】不召唤任何实体（对照区在别处，避免游走混进统计）。

import fs from 'fs';
import path from 'path';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR } from './console.mjs';
import { forceload } from './scan.mjs';

const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const TAG = argOf(process.argv, 'tag', 's5');
const RUN_DIR = path.join(ROUTE_DIR, 'probe', `_run_round7c`, TAG);
const OUT = path.join(ROUTE_DIR, 'probe', `worldgen_${TAG}.json`);

/** 站级中心 S5_stronghold_room = [1328,1152] → 区块 (83,72)。要盖住 radius=24 + 泛洪外扩 24。 */
const CX = 83, CZ = 72, SIDE = 16;               // 16×16 = 256 区块，分 2 批（单批 ≤128，避开 256 上限）
const BATCH = 128;
const SPAWN = { x: 216, z: 224 };               // 就绪探测格（forceload 之外，用出生点，纯探测用）

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const argOfB = (a, n, d) => argOf(a, n, d);

async function cmdOnce(con, cmd, re, timeoutMs = 20000) {
    con.drain();
    con.cmd(cmd);
    const t0 = Date.now();
    const seen = [];
    for (;;) {
        for (const line of con.drain()) { seen.push(line); if (re.test(line)) return line; }
        if (Date.now() - t0 > timeoutMs) throw new Error(`CMD_NO_RECEIPT: ${cmd}（${seen.slice(-2).join(' | ').slice(0, 140)}）`);
        await sleep(50);
    }
}

const out = {
    schema: 'aidqq-round7c-worldgen/1', seed: SEED, tag: TAG, mcVersion: '1.16.1', lane: 'C',
    startedAt: new Date().toISOString(), status: 'NOT_RUN', batches: [], savedAt: null,
    purpose: 'S5_stronghold_room 门室预勘（只生成区块，读数全离线）',
};
let h = null;
try {
    out.status = 'RUNNING';
    log(`=== ROUND7-C S5 世界生成（tag=${TAG}）===`);
    h = await bootLaneC({ seed: SEED, runDir: RUN_DIR, logFn: log });
    const con = h.con;
    const sp = fs.readFileSync(path.join(h.lane.dir, 'server.properties'), 'utf8');
    const levelName = (/level-name=(.*)/.exec(sp)?.[1] ?? 'world').trim();
    out.levelName = levelName;
    out.worldDir = path.join(h.lane.dir, levelName);
    out.bootMs = h.server.bootMs;

    // ---- 分批 forceload（沿 x 切，每批 ≤BATCH）
    for (let x0 = CX - SIDE / 2; x0 < CX + SIDE / 2; x0 += Math.floor(BATCH / SIDE)) {
        const x1 = Math.min(CX + SIDE / 2, x0 + Math.floor(BATCH / SIDE));
        const bz1 = CZ + SIDE / 2, bz0 = CZ - SIDE / 2;
        await forceload(con, 'overworld', x0 * 16, bz0 * 16, x1 * 16 - 1, bz1 * 16 - 1, 1800);
        const b = { chunks: (x1 - x0) * SIDE, chunksXZ: `x${x0}..${x1 - 1} / z${bz0}..${bz1 - 1}`, blocks: `x${x0 * 16}..${x1 * 16 - 1} / z${bz0 * 16}..${bz1 * 16 - 1}` };
        out.batches.push(b);
        log(`  forceload ${b.chunksXZ}（${b.chunks} 区块）`);
    }

    // ---- 就绪闸门：中心一格 fill 必有回执（不是 "not loaded"）
    const ready = await cmdOnce(con, `fill ${SPAWN.x} 70 ${SPAWN.z} ${SPAWN.x} 70 ${SPAWN.z} minecraft:barrier replace minecraft:stone`,
        /Successfully filled|No blocks were filled|not loaded/i, 30000);
    out.readyProbe = ready;
    if (/not loaded/i.test(ready)) throw new Error('CHUNK_GATE_NOT_LOADED');
    log(`  就绪探测：${ready}`);

    const saveLine = await cmdOnce(con, 'save-all flush', /Saved the game|Flushing|Saved/i, 180000);
    out.saveLine = saveLine;
    log(`  ${saveLine}`);
    await sleep(3000);
    await shutdownLaneC(h); h = null;
    out.status = 'SAVED';
    out.savedAt = new Date().toISOString();

    // ---- 把世界**复制**出来给离线解析（原目录留给 cleanup 删）
    const dest = path.join(ROUTE_DIR, 'probe', `_s5_${TAG}`);
    fs.rmSync(dest, { recursive: true, force: true });
    fs.mkdirSync(dest, { recursive: true });
    for (const item of ['region', 'level.dat', 'level.dat_old', 'DIM-1', 'DIM1']) {
        const src = path.join(out.worldDir, item);
        if (fs.existsSync(src)) fs.cpSync(src, path.join(dest, item), { recursive: true });
    }
    out.copiedTo = dest;
    out.regionFiles = fs.readdirSync(path.join(dest, 'region')).filter((f) => f.endsWith('.mca'));
    log(`  已复制到 ${dest}：${JSON.stringify(out.regionFiles)}`);
} catch (e) {
    out.error = String(e && e.stack ? e.stack : e);
    if (out.status === 'RUNNING') out.status = 'FAILED';
    log(`✗ ${out.status}：${String(e).split('\n')[0]}`);
} finally {
    try { if (h) await shutdownLaneC(h); } catch { /* ignore */ }
    out.seconds = Math.round((Date.now() - Date.parse(out.startedAt)) / 1000);
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
    log(`落盘：${path.relative(process.cwd(), OUT)}（status=${out.status}，${out.seconds}s）`);
}
void argOfB;
