// r7c_nether_route_distance.mjs — ROUND7-C 续单（低优先项 5）：下界三段的**直线距离 + 可走路径长度**
//
// 【问题】下界几段的实际距离：S1 门对应的下界落点 → S3 堡垒 → C3 要塞 → 回门。
//   派单要**两个数**：直线与可走路径各一个。
//
// 【口径与它的三个不确定处（都写进产物，不藏）】
//   ① **下界落点不是查表能查到的**：1.16.1 建下界门时，落点 XZ = 主世界坐标 ÷8，
//      但实际落点会在该点附近**搜索/新建**一个安全位置，Y 由运行时地形决定。
//      ⇒ 本单**按"离目标 XZ 最近的站得住格"**起止，并把实际起止的 (x,y,z) 全部落盘。
//   ② **"可走"用 6 连通**（上下左右 + 上/下 1 格），**不含斜向**。真人会斜着走，
//      所以本单给的路径长度是**下界的一个上界估计**，不是最优解。
//   ③ **站得住**的判据：脚下 1 格**非空气且非岩浆/岩浆块**（不站在液体上）+ 身体 2 格空气。
//      沿途**不判"会不会被打"**（猪灵/烈焰人/岩浆怪），只判地形 ⇒ 这是**纯地形距离**。
//
// 【为什么要新存档】盘上已有的下界存档**一格都没覆盖到这条走廊**
//   （`_world_A` 下界从 x112 起，而三点的下界 X 是 23 / 42 / 28）⇒ 由
//   `r7c_nether_corridor_worldgen.mjs` 现生成 cx0..7 / cz-5..7。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from './region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE_DIR = path.resolve(HERE, '..');
const PROBE = path.join(ROUTE_DIR, 'probe');
const WORLD = path.join(PROBE, '_nether_corridor');
const OUT = path.join(PROBE, 'nether_route_distance.round7c.json');
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };

const wg = readJson(path.join(PROBE, 'worldgen_nether_corridor.json'));
if (!wg) throw new Error('缺 worldgen_nether_corridor.json —— 先跑走廊 worldgen');
if (!wg.coverageOK) throw new Error(`走廊存档覆盖不全（${wg.savedChunksInWindow}/${wg.window.expectedChunks}）—— 本单拒绝在残缺地形上量路径`);

const w = openWorld(WORLD, { dims: ['the_nether'] });
const DIM = 'the_nether';
const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);
const HAZARD = new Set(['lava', 'magma_block', 'fire', 'soul_fire']);
/** 允许的最大下落格数：下界是洞穴，掉下去是免费移动。实测 1 格会把整条路线判成"断的"。 */
const MAX_DROP = 20;

// ---- 三个站点（全部先在主世界 ÷8）
const STATIONS = [
    { key: 'S1_netherLanding', label: 'S1 门对应的下界落点', ow: [187, 41, 308], nether: [187 / 8, 308 / 8], note: '主世界 S1 废弃传送门框原点 (187,39,307) axis=z ⇒ 门心约 (187,41,308)' },
    { key: 'S3_bastion', label: 'S3 堡垒', ow: null, nether: [336 / 8, 256 / 8], note: 'route 的 `S3_bastion.station.center` = nether (336,256)' },
    { key: 'C3_fortress', label: 'C3 要塞刷怪笼', ow: null, nether: [224 / 8, -88 / 8], note: 'route 的 `C3_fortress_spawner.station.center` = nether (224,-88)' },
];
const LEGS = [
    { from: 'S1_netherLanding', to: 'S3_bastion' },
    { from: 'S3_bastion', to: 'C3_fortress' },
    { from: 'C3_fortress', to: 'S1_netherLanding' },
];

// ---- 走廊盒（与世界生成窗口一致）
const BOX = { x1: wg.window.blocks.x[0], y1: 0, z1: wg.window.blocks.z[0], x2: wg.window.blocks.x[1], y2: 127, z2: wg.window.blocks.z[1] };
const W = BOX.x2 - BOX.x1 + 1, D = BOX.z2 - BOX.z1 + 1, H = BOX.y2 - BOX.y1 + 1;
console.log(`走廊：x ${BOX.x1}..${BOX.x2} / z ${BOX.z1}..${BOX.z2} / y ${BOX.y1}..${BOX.y2}（${W}×${D}×${H}）`);

const nameAt = (x, y, z) => w.blockAt(x, y, z, DIM);
const solidGround = (x, y, z) => { const n = nameAt(x, y, z); return n !== 'unknown' && !AIRLIKE.has(n) && !HAZARD.has(n); };
/** 站得住：脚下实心非液体 + 身体 2 格空气 */
const standable = (x, y, z) => y >= 1 && y + 1 <= BOX.y2
    && solidGround(x, y - 1, z)
    && AIRLIKE.has(nameAt(x, y, z)) && AIRLIKE.has(nameAt(x, y + 1, z));

// ---- 立可走图（0=不可走，1=可走）
const N = W * D * H;
const walk = new Uint8Array(N);
let lavaCells = 0, solidCells = 0, unknownCells = 0;
const idxOf = (x, y, z) => (x - BOX.x1) + (z - BOX.z1) * W + (y - BOX.y1) * W * D;
for (let y = BOX.y1; y <= BOX.y2; y++) {
    for (let z = BOX.z1; z <= BOX.z2; z++) {
        for (let x = BOX.x1; x <= BOX.x2; x++) {
            const n = nameAt(x, y, z);
            if (n === 'unknown') { unknownCells++; continue; }
            if (n === 'lava') lavaCells++;
            if (!AIRLIKE.has(n)) solidCells++;
            if (standable(x, y, z)) walk[idxOf(x, y, z)] = 1;
        }
    }
}
let walkCells = 0; for (let i = 0; i < N; i++) if (walk[i]) walkCells++;
console.log(`读数：unknown ${unknownCells}｜可走格 **${walkCells}**｜岩浆格 ${lavaCells}｜实心格 ${solidCells}`);

/**
 * 离 (tx,tz) 最近的站得住格。
 * 🚨 **第一版把 `d.toFixed(2)` 存进 best、却拿未取整的 `d` 跟它比**：
 *    0.125 < 0.13 恒成立 ⇒ "距离相同"这个并列**永远判不出来** ⇒ 并列被退化成
 *    "遍历到的最后一个赢"（y=66），而不是我以为的"最低 y 赢"。
 *    这与手册 §5「排序有并列时必须显式打破，否则等于随机选」同族 ——
 *    **并列检测本身被取整破坏了**，比"忘了写并列"更隐蔽。
 *    ⇒ 现在存**原始** d 参与比较，取整只用于显示；并列时**显式**取 y 小的。
 */
function nearestStandable(tx, tz, { maxDrop = MAX_DROP } = {}) {
    let best = null;
    for (let y = BOX.y1; y <= BOX.y2; y++) {
        for (let z = BOX.z1; z <= BOX.z2; z++) {
            for (let x = BOX.x1; x <= BOX.x2; x++) {
                if (!walk[idxOf(x, y, z)]) continue;
                const d = Math.hypot(x + 0.5 - tx, z + 0.5 - tz);
                if (best === null || d < best.d - 1e-9
                    || (Math.abs(d - best.d) <= 1e-9 && (y < best.cell[1] || (y === best.cell[1] && (x < best.cell[0] || (x === best.cell[0] && z < best.cell[2])))))) {
                    best = { cell: [x, y, z], d };
                }
            }
        }
    }
    return best ? { cell: best.cell, distXZ: Number(best.d.toFixed(2)) } : null;
}

/** 目标 XZ 附近（≤2 格）所有站得住格的 y 分布 —— 用来显示"落点 y 选得不同，路径长度差多少" */
function landingCandidates(tx, tz, radius = 2) {
    const out = [];
    for (let y = BOX.y1; y <= BOX.y2; y++) for (let z = BOX.z1; z <= BOX.z2; z++) for (let x = BOX.x1; x <= BOX.x2; x++) {
        if (!walk[idxOf(x, y, z)]) continue;
        const d = Math.hypot(x + 0.5 - tx, z + 0.5 - tz);
        if (d <= radius) out.push({ cell: [x, y, z], d: Number(d.toFixed(2)) });
    }
    out.sort((a, b) => a.d - b.d || a.cell[1] - b.cell[1]);
    return out;
}

/** 水平 4 向 + 上 1 / 下 MAX_DROP 的 BFS：返回 {steps, path} 或 null */
function bfs(a, b) {
    const start = idxOf(...a), goal = idxOf(...b);
    if (!walk[start] || !walk[goal]) return null;
    const dist = new Int32Array(N).fill(-1);
    const prev = new Int32Array(N).fill(-1);
    const q = new Int32Array(N);
    let qh = 0, qt = 0;
    dist[start] = 0; q[qt++] = start;
    // 🚨 移动规则第一版是 `[[±1,0,0],[0,±1,0],[0,0,±1]]`（要求相邻格**自己**站得住）
    //   ⇒ "往上迈一格台阶"永远不成立：站位 (x,y,z) 的正上方要站得住，就要求 (x,y,z) 是实心
    //   —— **而你正站在那个空气格里**。后果：三段全部"不可达"，**看起来像下界走不通，其实是图画不出来**。
    // 正解：水平 4 向 + 上 1 / 下 MAX_DROP。**下界是洞穴，掉下去是免费的移动**，
    //   只允许下 1 格会把整条路线判成断的。
    const NB = [];
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        NB.push([dx, 0, dz], [dx, 1, dz]);
        for (let k = 1; k <= MAX_DROP; k++) NB.push([dx, -k, dz]);
    }
    while (qh < qt) {
        const cur = q[qh++];
        if (cur === goal) break;
        const y = BOX.y1 + Math.floor(cur / (W * D));
        const rem = cur - (y - BOX.y1) * W * D;
        const z = BOX.z1 + Math.floor(rem / W);
        const x = BOX.x1 + (rem % W);
        for (const [dx, dy, dz] of NB) {
            const nx = x + dx, ny = y + dy, nz = z + dz;
            if (nx < BOX.x1 || nx > BOX.x2 || ny < BOX.y1 || ny > BOX.y2 || nz < BOX.z1 || nz > BOX.z2) continue;
            const ni = idxOf(nx, ny, nz);
            if (!walk[ni] || dist[ni] !== -1) continue;
            dist[ni] = dist[cur] + 1; prev[ni] = cur; q[qt++] = ni;
        }
    }
    if (dist[goal] === -1) return null;
    const pathCells = [];
    for (let c = goal; c !== -1; c = prev[c]) {
        const y = BOX.y1 + Math.floor(c / (W * D));
        const rem = c - (y - BOX.y1) * W * D;
        pathCells.push([BOX.x1 + (rem % W), y, BOX.z1 + Math.floor(rem / W)]);
        if (c === start) break;
    }
    pathCells.reverse();
    return { steps: dist[goal], path: pathCells };
}

// ---- 落点解析 + 三段
const resolved = {};
for (const s of STATIONS) {
    const ns = nearestStandable(s.nether[0], s.nether[1]);
    const cands = landingCandidates(s.nether[0], s.nether[1], 2);
    resolved[s.key] = {
        ...s,
        stand: ns?.cell ?? null,
        offsetFromNetherXZ: ns?.distXZ ?? null,
        landingCandidatesXZ2: cands.slice(0, 8),
        candidateYs: [...new Set(cands.map((c) => c.cell[1]))].sort((a, b) => a - b),
    };
    console.log(`  ${s.label.padEnd(16)} 目标 nether(${s.nether.map((v) => Number(v.toFixed(1))).join(',')})  最近可走格 ${JSON.stringify(ns?.cell)}  XZ 偏移 ${ns?.distXZ} 格`);
    console.log(`  ${' '.repeat(16)}  附近(≤2格)可走格 ${cands.length} 个，y 取值 ${JSON.stringify(resolved[s.key].candidateYs)}`);
}

const legs = LEGS.map((L) => {
    const A = resolved[L.from], B = resolved[L.to];
    const straight = Number(Math.hypot(A.nether[0] - B.nether[0], A.nether[1] - B.nether[1]).toFixed(1));
    const r = (A.stand && B.stand) ? bfs(A.stand, B.stand) : null;
    return {
        ...L,
        fromXZ: A.nether.map((v) => Number(v.toFixed(1))), toXZ: B.nether.map((v) => Number(v.toFixed(1))),
        fromStand: A.stand, toStand: B.stand,
        straightXZ: straight,
        walkableSteps: r ? r.steps : null,
        detourFactor: r ? Number((r.steps / straight).toFixed(2)) : null,
        reachable: !!r,
        pathMinMaxY: r ? [Math.min(...r.path.map((p) => p[1])), Math.max(...r.path.map((p) => p[1]))] : null,
    };
});
for (const l of legs) {
    console.log(`  ${l.from} → ${l.to}：直线 ${l.straightXZ} 格｜可走 ${l.walkableSteps ?? '不可达'} 步｜绕行系数 ${l.detourFactor ?? '—'}`);
}
const totalStraight = Number(legs.reduce((a, l) => a + l.straightXZ, 0).toFixed(1));
const totalWalk = legs.every((l) => l.walkableSteps != null) ? legs.reduce((a, l) => a + l.walkableSteps, 0) : null;
console.log(`  合计：直线 ${totalStraight} 格｜可走 ${totalWalk ?? '—'} 步`);

// ---- 落点 y 的敏感性：同一个 XZ，落点 y 不同 ⇒ 路径长度差多少
const S1 = resolved.S1_netherLanding;
const ySensitivity = S1.landingCandidatesXZ2.map((c) => {
    const a = c.cell;
    return {
        landing: a,
        toS3: bfs(a, resolved.S3_bastion.stand)?.steps ?? null,
        toC3: bfs(a, resolved.C3_fortress.stand)?.steps ?? null,
    };
});
console.log('  落点 y 敏感性（同一 XZ，不同 y）：');
for (const r of ySensitivity) console.log(`     落点 (${r.landing}) → S3 ${r.toS3 ?? '不可达'} 步 / → C3 ${r.toC3 ?? '不可达'} 步`);

const out = {
    schema: 'aidqq-round7c-nether-route-distance/1', at: new Date().toISOString(),
    seed: '4926685115947721762', mcVersion: '1.16.1', lane: 'C',
    question: '下界三段的实际距离：S1门落点 → S3堡垒 → C3要塞 → 回门（直线 + 可走路径各一个数）',
    criteria: {
        netherScaling: '下界 XZ = 主世界 XZ ÷ 8（Y 由运行时地形决定，不按比例）',
        standable: '脚下 1 格非空气且非 {lava, magma_block, fire, soul_fire} + 身体 2 格空气集',
        walkableGraph: `水平 4 向 + 上 1 格 / 下 ≤${MAX_DROP} 格（不含斜向）`,
        straight: '两点 nether XZ 的欧氏距离',
        caveats: [
            '下界落点是**运行时**在 (主世界÷8) 附近搜索/新建出来的，本单用"离目标 XZ 最近的可走格"代替，**实际落点坐标未验**。',
            '**不含斜向** ⇒ 真人实际路径会比本单短（本单是**上界估计**）。',
            '只判地形，**不判遭遇战**（猪灵/烈焰人/岩浆怪）⇒ 这是**纯地形距离**。',
            '**落点 y 会明显改变数字**（见 `landingSensitivity`）—— 因为下界落点 y 是运行时定的，这一条比前三条更要紧。',
        ],
    },
    world: { dir: WORLD, window: BOX, unknownCells, walkableCells: walkCells, lavaCells, solidCells, coverageOK: wg.coverageOK },
    // ⚠ 探针格**只在真的替换掉一块时**才算污染。实测本走廊的探针回执是
    //   "No blocks were filled"（目标格本来就不是 netherrack）⇒ **一格都没改**，存档干净。
    //   别把"下过探针"当成"污染了存档"——那正是 §5「取证动作要紧贴它要证明的时刻」的同类误读。
    selfInflictedBlocks: /Successfully filled/i.test(wg.readyProbe ?? '')
        ? { note: '本单下的就绪探针', cells: [[BOX.x1, 70, BOX.z1]], block: 'barrier' }
        : { note: '**无污染** —— 探针回执 "No blocks were filled"，目标格本来不是 netherrack，一格都没改', cells: [], block: null, probeReceipt: wg.readyProbe },
    stations: resolved,
    legs,
    landingSensitivity: ySensitivity,
    totals: { straightXZ: totalStraight, walkableSteps: totalWalk, allLegsReachable: legs.every((l) => l.reachable) },
    notVerified: [
        '**下界门的实际落点坐标与 y**未验（需要真服开一次门看 `Pos`）—— 本单按"离目标 XZ 最近的可走格"代替，并给出 y 敏感性。',
        '**往返是否走同一条路**未验：本单三段各自独立最短路，**不是**一条连续巡回路线。',
        '**S3 堡垒内部**只走到"离站心最近的可走格"，**没有**走到金源作业点（那需要站内寻路，见 barterWorkPoints）。',
        '**不判遭遇战与岩浆**：这是纯地形距离；实战还要加打猪灵/烈焰人的时间和搭桥/岩浆船的时间。',
    ],
    evidence: ['bench/route/probe/worldgen_nether_corridor.json', 'bench/route/probe/nether_route_distance.round7c.json'],
};
fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
console.log(`\n落盘：${OUT}`);
