// nether_side_offline.mjs — MC-ROUND4 C 线**离线预研**（不开服、不占泳道）
//
// 【本单要解决的空白】ROUTE-02（10-01/10-02）对主种子 4926685115947721762 的下界侧
//   只测过两件事，而且都**不是本单要的**：
//     · S3_bastion   = `/locate bastion_remnant`（336,256）→ 该堡垒区域
//     · S4_fortress  = `/locate fortress`（-400,64）→ 该要塞区域
//   派单 §C 要的是**"要塞对应点旁 15.2 格那个下界废弃传送门"**，以及**它旁边**的堡垒/要塞。
//   主种子 ÷8 要塞对应点 = (162,150)；nether 废弃门离线值 (176,144) —— 两者相距 15.2 格。
//   上一单的 S3/S4 中心离这个 nether 门分别是 188.9 格和 605.6 格，**不是同一片区域**。
//   ⇒ 本单必须在 (162,150) 附近重新下钻，本脚本先离线把三个起点算出来。
//
// 【为什么先离线】/locate 在下界要先生成区块，实测能把服务器拖过 60s 看门狗
//   （gen_route.mjs 头注：备选 1 上 fortress / bastion_remnant 两条都被拖死）。
//   手册 §2 的口径允许"用种子数学/结构生成算法算坐标"，所以先用 cubiomes 算，
//   再用**服务器权威 fill 通道**下钻核验（和上一单同款做法）。
//
// 【口径纪律】cubiomes 给的是**结构起点**，不是"框在哪一格"。
//   框体几何、缺格、缺格被什么占 —— 全部必须等服务端逐格真值（portal_frame.mjs
//   的 classifyFrameCells），离线只给"去哪儿挖"。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { CONFIGS, candidates, nearest, floordiv, viableNote } from './cubiomes_struct.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE_DIR = path.join(HERE, '..');
const REPO = path.join(ROUTE_DIR, '..', '..');
const OUT = path.join(ROUTE_DIR, 'probe', 'nether_side_offline.json');

const SEED = BigInt(argOf(process.argv, 'seed', '4926685115947721762'));
/** 主世界要塞（离线算，上一单 probe.json#structures.stronghold 记的是 /locate 值 1304,1208） */
const OW_STRONGHOLD = { x: 1304, z: 1208 };
/** nether 目标 = 主世界 ÷ 8（离线锚点） */
const NETHER_ANCHOR = { x: floordiv(OW_STRONGHOLD.x, 8), z: floordiv(OW_STRONGHOLD.z, 8) };

function argOf(argv, name, dflt) {
    const i = argv.indexOf(`--${name}`);
    return i >= 0 && argv[i + 1] != null ? argv[i + 1] : dflt;
}

const d = (x, z, c) => Math.round(Math.hypot(x - c.x, z - c.z) * 10) / 10;
const fmt = (p) => p ? `(${p.x},${p.z})` : 'null';

console.log('=== MC-ROUND4 C 线：主种子下界一侧离线预研（cubiomes MC_1_16_1）===');
console.log(`seed                = ${SEED}`);
console.log(`主世界要塞(上一单/locate) = (${OW_STRONGHOLD.x},${OW_STRONGHOLD.z})`);
console.log(`nether 锚点(÷8)          = (${NETHER_ANCHOR.x},${NETHER_ANCHOR.z})   ← 本单的"要塞对应点"`);

// 半径口径：门按上一单 P1 的 64 格；堡垒/要塞因为结构本身 100+ 格宽，给 128 格。
const out = {
    schema: 'aidqq-nether-side-offline/1',
    generatedAt: new Date().toISOString(),
    tool: 'bench/route/tools/nether_side_offline.mjs + cubiomes_struct.mjs',
    seed: SEED.toString(),
    mcVersion: '1.16.1',
    overworldStronghold: OW_STRONGHOLD,
    netherAnchor: NETHER_ANCHOR,
    note: 'cubiomes 只给结构**起点**；框体/缺格/刷怪笼站位一律等服务端逐格真值。',
    items: {},
};

function find(type, radius, key, label) {
    const cands = candidates(type, SEED, NETHER_ANCHOR.x, NETHER_ANCHOR.z, radius)
        .map((c) => ({ ...c, d: Math.round(Math.hypot(c.d2) * 10) / 10 }))
        .sort((a, b) => a.d - b.d);
    const inR = cands.filter((c) => c.d <= radius);
    const near = nearest(type, SEED, NETHER_ANCHOR.x, NETHER_ANCHOR.z, radius, 96);
    console.log(`\n--- ${key}（${label}）---`);
    console.log(`  viable：${viableNote(type)}`);
    console.log(`  ${radius} 格内候选 ${inR.length} 个：${inR.slice(0, 5).map((c) => `${fmt(c)} d=${c.d}`).join('  ') || '无'}`);
    console.log(`  最近（不受半径限）：${fmt(near)}  d=${near ? d(near.x, near.z, NETHER_ANCHOR) : '-'}`);
    out.items[key] = {
        type, label, radius,
        viable: viableNote(type),
        withinRadius: inR.slice(0, 8).map((c) => ({ x: c.x, z: c.z, d: c.d, region: { rx: c.rx, rz: c.rz } })),
        nearestAny: near ? { x: near.x, z: near.z, d: d(near.x, near.z, NETHER_ANCHOR) } : null,
        distanceFromAnchor: near ? d(near.x, near.z, NETHER_ANCHOR) : null,
        candidateCount: cands.length,
    };
    return near;
}

// ① 下界废弃传送门（派单 C-1 的主角）
find('Ruined_Portal_N', 64, 'netherRuinedPortal', '派单 C-1：要塞对应点旁那个下界废弃门');
// ② 堡垒（派单 C-2，交给 F 线 B5）
find('Bastion', 128, 'bastion', '派单 C-2：堡垒类型 / 金块 / 宝箱');
// ③ 下界要塞（派单 C-3，刷怪笼）
find('Fortress', 128, 'fortress', '派单 C-3：下界要塞刷怪笼');

// 上一单已核区域与本单锚点的距离（说明为什么必须重测）
console.log('\n--- 上一单已核区域 vs 本单锚点 ---');
for (const [id, p] of Object.entries({ S3_bastion_route: { x: 288, z: 240 }, S4_fortress_route: { x: -432, z: 32 } })) {
    const dd = d(p.x, p.z, NETHER_ANCHOR);
    console.log(`  ${id} ${fmt(p)} 距锚点 ${dd} 格`);
    out.items.previousRunDistance = out.items.previousRunDistance ?? {};
    out.items.previousRunDistance[id] = { center: p, distance: dd };
}

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(out, null, 2) + '\n');
console.log(`\n落盘：${path.relative(REPO, OUT)}`);
console.log('提醒：以上全是**起点**。缺格/框内计数/刷怪笼站位必须等服务端逐格真值（下一阶段开泳道 C）。');
