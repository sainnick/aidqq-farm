// r9c_diag_nether.mjs — ROUND9-C 收尾诊断：S3→C3 这条腿"算不出来"的**可复述原因**
//
// 【为什么单独一个文件】A* 在 ±80 走廊带、2,500,000 节点、280s 的预算内没搜到 C3。
//   手册 §5：「报"不行 / 不可行"之前必须附阳性对照」—— 所以要分清三件完全不同的事：
//     ① 直线上有没有连续可站的地面（地形本身就不通）        —— 本文件第一段
//     ② S3 那个堡垒内部到底有多大（是不是被封死的盒子）    —— 本文件第二段
//     ③ 搜索预算够不够（连通但没搜到）                      —— 由 A* 的 nodesSeen/budget 给出
//   三者的处置完全不同：① 要改路线，② 要挖穿，③ 加预算就行。
//
// 用法：node tools/r9c_diag_nether.mjs [--reachable-cap 600000]

import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from './region_reader.mjs';
import { AIRLIKE, GROUND_HARD_FAIL } from '../lib/stand_criterion.mjs';

const argOf = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 ? process.argv[i + 1] : d; };
const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE = path.resolve(HERE, '..');
const CAP = Number(argOf('reachable-cap', '600000'));

const world = openWorld(path.join(ROUTE, argOf('world', 'probe/_r9c_nether_corridor')), { dims: ['the_nether'] });
const at = (x, y, z) => world.blockAt(x, y, z, 'the_nether');
const isAir = (x, y, z) => AIRLIKE.has(at(x, y, z));
const UNDIGGABLE = new Set(['unknown', 'out_of_range', 'bedrock', 'water', 'lava', 'fire', 'soul_fire', 'chest', 'spawner', 'end_portal_frame', 'iron_bars', 'end_portal', 'nether_portal', ...GROUND_HARD_FAIL]);
const diggable = (n) => !UNDIGGABLE.has(n) && !AIRLIKE.has(n);
const key = (x, y, z) => (x + 512) * 4194304 + (y + 8) * 1024 + (z + 512);

const A = [331, 57, 238];   // S3 身体格
const B = [220, 70, -87];   // C3 身体格

// ═══════════ ① 直线走廊普查
const n = Math.max(Math.abs(A[0] - B[0]), Math.abs(A[2] - B[2]));
let ok = 0, noStand = 0, viaLava = 0, unknown = 0;
const okCols = [];
for (let i = 0; i <= n; i++) {
    const x = Math.round(A[0] + (B[0] - A[0]) * i / n);
    const z = Math.round(A[2] + (B[2] - A[2]) * i / n);
    let found = null;
    for (let y = 8; y <= 100; y++) {
        if (!isAir(x, y, z) || !isAir(x, y + 1, z)) continue;
        const g = at(x, y - 1, z);
        if (AIRLIKE.has(g) || GROUND_HARD_FAIL.has(g)) continue;
        found = y; break;
    }
    if (found !== null) { ok++; okCols.push([x, found, z]); continue; }
    noStand++;
    const probe = [at(x, 50, z), at(x, 60, z), at(x, 70, z)];
    if (probe.includes('lava')) viaLava++; else if (probe.includes('unknown')) unknown++;
}
console.log('① 直线走廊普查（S3 身体格 → C3 身体格，横向 ' + n + ' 格）');
console.log(`   可站列 ${ok} / 不可站列 ${noStand}（其中列上见岩浆 ${viaLava}、读不到 ${unknown}）`);
console.log(`   ⇒ 沿直线至少要处理 ${noStand} 列（挖穿或搭桥），不是"一条直线走过去"就行`);
console.log(`   前 8 个可站列：${JSON.stringify(okCols.slice(0, 8))}`);

// ═══════════ ② S3 可达集（含挖隧道 ≤8）
const seen = new Set([key(...A)]);
const q = [A];
let head = 0;
while (head < q.length && seen.size < CAP) {
    const [x, y, z] = q[head++];
    const ps = (nx, ny, nz, cl) => {
        const g = at(nx, ny - 1, nz);
        if (AIRLIKE.has(g) || GROUND_HARD_FAIL.has(g)) return;
        const okC = (a, b, c) => (cl && cl.has(key(a, b, c))) ? true : AIRLIKE.has(at(a, b, c));
        if (!okC(nx, ny, nz)) return;
        if (!okC(nx, ny + 1, nz)) return;
        const k = key(nx, ny, nz);
        if (seen.has(k)) return;
        seen.add(k); q.push([nx, ny, nz]);
    };
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        for (const dy of [0, 1, -1]) ps(x + dx, y + dy, z + dz, null);
        for (let kk = 1; kk <= 8; kk++) {
            const cl = new Set();
            let good = true;
            for (let i = 1; i <= kk; i++) {
                const bx = x + dx * i, bz = z + dz * i;
                if (!diggable(at(bx, y, bz))) { good = false; break; }
                cl.add(key(bx, y, bz));
                const fn = at(bx, y - 1, bz);
                if (!AIRLIKE.has(fn)) { if (!diggable(fn)) { good = false; break; } cl.add(key(bx, y - 1, bz)); }
            }
            if (!good) continue;
            ps(x + dx * kk, y, z + dz * kk, cl);
            ps(x + dx * kk, y - 1, z + dz * kk, cl);
        }
        const nx = x + dx, nz = z + dz;
        if (isAir(nx, y, nz) && isAir(nx, y + 1, nz) && isAir(nx, y - 1, nz) && !AIRLIKE.has(at(nx, y - 2, nz))) ps(nx, y, nz, null);
    }
    for (let k2 = 1; k2 <= 4; k2++) {
        const ny = y - k2;
        if (isAir(x, y - 1, z) && !isAir(x, ny, z)) { const g = at(x, ny - 1, z); if (!AIRLIKE.has(g) && !GROUND_HARD_FAIL.has(g)) { ps(x, ny, z, null); break; } }
        if (diggable(at(x, y - k2, z))) {
            const cl = new Set();
            for (let j = 1; j < k2; j++) cl.add(key(x, y - j, z));
            const g = at(x, ny - 1, z);
            if (!AIRLIKE.has(g) && !GROUND_HARD_FAIL.has(g)) { ps(x, ny, z, cl); break; }
        }
    }
}
// ⚠ 400k 个 key 用 `Math.min(...arr)` 会**爆栈**（spread 的参数上限）—— 逐维单遍循环，别用 spread。
const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
for (const s of seen) {
    const zz = s % 1024 - 512, yy = Math.floor(s / 1024) % 4096 - 8, xx = Math.floor(s / 4194304) - 512;
    if (xx < lo[0]) lo[0] = xx; if (xx > hi[0]) hi[0] = xx;
    if (yy < lo[1]) lo[1] = yy; if (yy > hi[1]) hi[1] = yy;
    if (zz < lo[2]) lo[2] = zz; if (zz > hi[2]) hi[2] = zz;
}
console.log(`② S3 作业点可达集（含挖隧道 ≤8，节点上限 ${CAP}）：${seen.size} 格`
    + `（截断=${seen.size >= CAP}）x${JSON.stringify(lo[0])}..${hi[0]} y${JSON.stringify(lo[1])}..${hi[1]} z${JSON.stringify(lo[2])}..${hi[2]}`);
console.log(`   C3 身体格在可达集内：${seen.has(key(...B))}`);
console.log(`⇒ 若 x 上界远小于 ${B[0]}，说明 S3 侧被堡垒壁封住，**必须先挖穿外壁**；这是"路线问题"而不是"搜索预算问题"。`);
