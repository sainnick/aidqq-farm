// r9c_return_options.mjs — ROUND9-C 第 3 项：回程方案 A / B 的**数据**（不改站序）
//
// 【10-03 用户补充的前提】**下界里水会直接蒸发**（`BucketItem.java:107` 的 `ultraWarm`）
//   ⇒ 手册 §7 的标准打法"带两个桶、到门边舀岩浆倒进缺格再倒水浇成黑曜石"**在下界做不了**。
//   ⇒ 方案 B 改为**自带黑曜石**就地造门。本文件因此**不找岩浆源**，只给两样东西：
//     ① 下界 (167,145) 附近**能造门的平整站位**（自带黑曜石版）；
//     ② 出门后主世界落点 → 要塞门室入口铁门 (1311,36,1167) 的距离。
//
// 【⚠ 门落点"未验"这件事对方案 B 的影响，比对方案 A 大得多】
//   方案 A 回原门 ⇒ 落点就是当初进下界那个门，**同一个门必然回到同一个主世界格**，落点是确定的。
//   方案 B 在下界新造门 ⇒ 主世界落点是 1.16.1 `PortalShape.findEmptyOrNotNullPortalDestination`
//   **从 y = 下界门 y 往下搜**找出来的"该格是空气、其下是空气或黑曜石"的第一格，
//   且**必须只有一个候选**（多个候选直接失败）。要塞门室地板是 stone_bricks（不是 obsidian），
//   按 `isEmptyOrNotNull` 的判据**不满足**"下方可站" ⇒ 落点**不会**正好落在门室里。
//   ⇒ 本文件按同一判据**枚举候选**并给每个候选到铁门的距离，让 H 线知道最坏/最好情况。
//   **候选 ≠ 落点**；真实落点仍需真服开一次门看 bot `Pos`。
//
// 用法：node tools/r9c_return_options.mjs [--nether-world probe/_r9c_nether_corridor] [--json …]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld, bare } from './region_reader.mjs';
import { judgeStand, AIRLIKE, GROUND_HARD_FAIL, standBodyCells } from '../lib/stand_criterion.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE = path.resolve(HERE, '..');
const argOf = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 ? process.argv[i + 1] : d; };

const NETHER_WORLD_REL = argOf('nether-world', 'probe/_r9c_nether_corridor');
const OW_WORLD_REL = argOf('ow-world', 'probe/_s5_s5');
const OUT = path.resolve(ROUTE, argOf('json', 'probe/v2_return_options.json'));

/** 方案 B 的下界造门目标点（= 要塞在主世界的 (1334,1161) 对应下界坐标）。 */
const B_NETHER_SITE = [167, 145];
/** 要塞门室入口铁门（ROUTE-02 订正：入口走这扇，另三扇门外连通空气只有 34/61/61）。 */
const IRON_DOOR = [1311, 36, 1167];
/** 门室站位（ROUND9-C 站位回读的结论，脚下那格 = 支撑方块）。 */
const S5_STAND = [1332, 36, 1159];
const S1_PORTAL_OW = [187, 41, 308];     // 主世界进门点（身体格）

const dist3 = (a, b) => +Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]).toFixed(2);

function openIf(p, dims) {
    const d = path.resolve(ROUTE, p);
    if (!fs.existsSync(d)) return { __missing: d };
    try { return openWorld(d, { dims }); } catch (e) { return { __err: String(e) }; }
}

/** 造门体积判据：**4 宽 × 3 高**的框（最小的 10 格黑曜石门，内侧 2×1 空气）全部是空气，
 *  且框正下方是实心可站面。返回 {ok, floorCells, frameCells}。 */
const FRAME_W = 4, FRAME_H = 3;
function portalSpotOk(at, x, y, z) {
    for (let dx = 0; dx < FRAME_W; dx++) for (let dy = 0; dy < FRAME_H; dy++) {
        if (!AIRLIKE.has(at(x + dx, y + dy, z))) return { ok: false, why: `frame_cell_not_air:${x + dx},${y + dy},${z}=${at(x + dx, y + dy, z)}` };
    }
    for (let dx = 0; dx < FRAME_W; dx++) {
        const g = at(x + dx, y - 1, z);
        if (AIRLIKE.has(g) || GROUND_HARD_FAIL.has(g)) return { ok: false, why: `floor_not_solid:${x + dx},${y - 1},${z}=${g}` };
    }
    return { ok: true };
}

const out = {
    schema: 'aidqq-v2-return-options/1', at: new Date().toISOString(),
    premise: '下界水蒸发（BucketItem.java:107 ultraWarm）⇒ 两桶浇注在下界不可行 ⇒ 方案 B 改为**自带黑曜石**。本文件不找岩浆源。',
    site: { nether: B_NETHER_SITE, overworldGuess: [B_NETHER_SITE[0] * 8, null, B_NETHER_SITE[1] * 8], ironDoor: IRON_DOOR, s5Stand: S5_STAND },
    obsidianBudget: { note: '下界不产黑曜石，也没有水可用 ⇒ 黑曜石必须**从主世界带进去**。最小门 = 4 宽 × 3 高框 = 10 格（内侧 2×1，出入要爬）；完整 4×5 框 = 14 格（内侧 2×3，可直立通过）。', counts: null },
    netherBuildSpots: null, overworldLandingCandidates: null, options: [], warnings: [],
};

// ═══════════════ ① 下界 (167,145) 附近的平整造门站位
{
    const w = openIf(NETHER_WORLD_REL, ['the_nether']);
    if (w.__missing || w.__err) {
        out.netherBuildSpots = { skipped: w.__missing ? `走廊存档不存在：${w.__missing}` : w.__err };
        out.warnings.push('下界造门站位**未算**：走廊存档不在（先跑 r9c_nether_corridor_worldgen.mjs）');
    } else {
        const dim = 'the_nether';
        const at = (x, y, z) => w.blockAt(x, y, z, dim);
        const cx = B_NETHER_SITE[0], cz = B_NETHER_SITE[1], R = 24;
        const spots = [];
        for (let x = cx - R; x <= cx + R; x++) for (let z = cz - R; z <= cz + R; z++) for (let y = 5; y <= 100; y++) {
            if (!judgeStand(at(x, y, z), at(x, y + 1, z), at(x, y + 2, z)).ok) continue;
            // 框放在"站位正前方"或"站位正上方"：先试正上方 3 高，再试四邻方向
            const cands = [[0, 0, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [3, 0, 0], [-3, 0, 0], [0, 0, 3], [0, 0, -3]];
            for (const [dx, , dz] of cands) {
                const p = portalSpotOk(at, x + dx, y + 1, z + dz);
                if (!p.ok) continue;
                // 危险格统计（造门时人会站在框边上）
                let hazard = 0;
                for (let ax = x - 2; ax <= x + 5; ax++) for (let az = z - 2; az <= z + 2; az++) for (let ay = y - 1; ay <= y + 4; ay++) {
                    const n = at(ax, ay, az);
                    if (n === 'lava' || n === 'magma_block' || n === 'fire' || n === 'soul_fire') hazard++;
                }
                spots.push({ stand: [x, y, z], body: standBodyCells([x, y, z]), frameOrigin: [x + dx, y + 1, z + dz], frameSize: [FRAME_W, FRAME_H, 1], hazardCellsInPad: hazard, distToSite: dist3([x, y, z], [cx, 0, cz]) });
                break;
            }
        }
        spots.sort((a, b) => (a.hazardCellsInPad - b.hazardCellsInPad) || (a.distToSite - b.distToSite));
        out.netherBuildSpots = {
            searched: { center: [cx, null, cz], radius: R, yRange: [5, 100], frame: [FRAME_W, FRAME_H, 1] },
            count: spots.length, top: spots.slice(0, 12),
            nearestToSite: spots.length ? spots.reduce((a, b) => (a.distToSite <= b.distToSite ? a : b)) : null,
            cleanest: spots.length ? spots[0] : null,
            note: '`stand` = 脚下那格（支撑方块）；`frameOrigin` = 4×3 框左下角（10 格黑曜石）。**无岩浆源需求**（自带黑曜石）。',
        };
        out.netherBuildSpots.positiveControl = {
            note: '阳性对照：S3/C3 的支撑方块在**同一份存档**里必须读回实心 + 身体两格空气。',
            s3: { stand: [331, 56, 238], read: [at(331, 56, 238), at(331, 57, 238), at(331, 58, 238)], ok: judgeStand(at(331, 56, 238), at(331, 57, 238), at(331, 58, 238)).ok },
            c3: { stand: [220, 69, -87], read: [at(220, 69, -87), at(220, 70, -87), at(220, 71, -87)], ok: judgeStand(at(220, 69, -87), at(220, 70, -87), at(220, 71, -87)).ok },
        };
    }
}

// ═══════════════ ② 主世界落点候选 → 铁门距离
{
    const w = openIf(OW_WORLD_REL, ['overworld']);
    if (w.__missing || w.__err) {
        out.overworldLandingCandidates = { skipped: w.__missing ? `存档不存在：${w.__missing}` : w.__err };
    } else {
        const dim = 'overworld';
        const at = (x, y, z) => w.blockAt(x, y, z, dim);
        // 1.16.1 `findEmptyOrNotNullPortalDestination` 的判据：该格空气 + 其下"空气或黑曜石或门" + 某一侧上方 3 格也"空气或黑曜石或门"
        const isEmptyOrNotNull = (n) => AIRLIKE.has(n) || n === 'obsidian' || n === 'nether_portal';
        const cand = [];
        const x0 = B_NETHER_SITE[0] * 8, z0 = B_NETHER_SITE[1] * 8;
        for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) for (let y = 5; y <= 100; y++) {
            const x = x0 + dx, z = z0 + dz;
            if (!isEmptyOrNotNull(at(x, y, z))) continue;
            if (!isEmptyOrNotNull(at(x, y - 1, z))) continue;
            let sideOk = false;
            for (const [ax, az] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
                if (isEmptyOrNotNull(at(x + ax, y, z + az)) && isEmptyOrNotNull(at(x + ax, y + 1, z + az)) && isEmptyOrNotNull(at(x + ax, y + 2, z + az))) { sideOk = true; break; }
            }
            if (!sideOk) continue;
            const stand = judgeStand(at(x, y - 1, z), at(x, y, z), at(x, y + 1, z));
            cand.push({ landingCell: [x, y, z], feetAt: [x, y, z], standable: stand.ok, standReason: stand.reason, distToIronDoor: dist3([x, y, z], IRON_DOOR), distToS5Stand: dist3([x, y, z], S5_STAND) });
        }
        cand.sort((a, b) => a.distToIronDoor - b.distToIronDoor);
        out.overworldLandingCandidates = {
            searchArea: { x: [x0 - 1, x0 + 1], z: [z0 - 1, z0 + 1], y: [5, 100] },
            criterion: '1.16.1 findEmptyOrNotNullPortalDestination 判据：该格是空气/黑曜石/门 + 其下是空气/黑曜石/门 + 某一侧连续 3 格是空气/黑曜石/门',
            count: cand.length,
            standableCount: cand.filter((c) => c.standable).length,
            all: cand.slice(0, 24),
            nearestToIronDoor: cand[0] ?? null,
            nearestStandable: cand.find((c) => c.standable) ?? null,
            note: '**候选 ≠ 落点**。真实落点由真服开门那一刻从 y = 下界门 y 往下搜、且必须唯一。'
                + `⚠ 要塞门室地板是 stone_bricks/mossy_stone_bricks，**不满足**"其下是空气或黑曜石" ⇒ 落点不会正好在门室里。`
                + `命中 ${cand.length} 个（其中"站得住"${cand.filter((c) => c.standable).length} 个）⇒ 按 1.16.1 判据，命中 ≥2 个 y 就是**多点、服务端直接返回空**。`,
            strongest: cand.find((c) => c.standable) ?? cand[0] ?? null,
        };
        out.overworldLandingCandidates.positiveControl = {
            note: '阳性对照：S5 站位支撑方块在**同一份存档**里必须读回实心 + 身体两格空气；铁门那一列必须读回 iron_door。',
            s5Stand: { stand: S5_STAND, read: [at(...S5_STAND), at(S5_STAND[0], S5_STAND[1] + 1, S5_STAND[2]), at(S5_STAND[0], S5_STAND[1] + 2, S5_STAND[2])], ok: judgeStand(at(...S5_STAND), at(S5_STAND[0], S5_STAND[1] + 1, S5_STAND[2]), at(S5_STAND[0], S5_STAND[1] + 2, S5_STAND[2])).ok },
            ironDoor: { cell: IRON_DOOR, read: at(...IRON_DOOR) },
        };
    }
}

// ═══════════════ ③ 黑曜石库存（自带 12~14 块从哪来）
{
    const w = openIf('probe/_bedhunt', ['overworld', 'the_nether']);
    if (w.__missing || w.__err) out.obsidianBudget.counts = { skipped: w.__missing ? w.__missing : w.__err };
    else {
        const boxes = {
            'S1 门框 15 格盒 (x178..196,y36..46,z298..316)': { x1: 178, y1: 36, z1: 298, x2: 196, y2: 46, z2: 316 },
            'S1 门框 21 格盒 (x180..200,y34..50,z292..320)': { x1: 180, y1: 34, z1: 292, x2: 200, y2: 50, z2: 320 },
        };
        const res = {};
        for (const [k, b] of Object.entries(boxes)) {
            for (const dim of ['overworld', 'the_nether']) {
                const c = w.countInBox({ ...b, y1: b.y1, y2: b.y2 }, ['obsidian', 'crying_obsidian'], dim);
                res[`${k} [${dim}]`] = { obsidian: c.counts.obsidian ?? 0, crying_obsidian: c.counts.crying_obsidian ?? 0, unknownCells: c.unknownCells, cells: c.cells };
            }
        }
        out.obsidianBudget.counts = res;
        out.obsidianBudget.reading = '`countInBox` 走 palette 直方图（不是逐格遍历）；`unknownCells` 单独列出 —— **unknown 不当 0**。';
        out.obsidianBudget.toolGate = {
            finding: '**1.16.1 里黑曜石掉落有工具门槛，而本条链只有铁镐 ⇒ 方案 B 在铁镐链路上拿不到黑曜石。**',
            lootTable: '从 jar 逐字读 `data/minecraft/loot_tables/blocks/obsidian.json`：pools[0] 只有 `survives_explosion`，**没有 `match_tool` 条件**'
                + '⇒ 门槛不在战利品表里，而在方块属性（`requiresCorrectToolForDrops`）。',
            codeEvidence: '本线 10-03 已在混淆 jar 的 `ServerPlayerGameMode.destroyBlock` 里核过该判据**确实被读**（字节码层，见 handover 跨线通告与手册 §5）。',
            consequence: '铁镐挖 S1 门框的黑曜石 ⇒ **掉 0 块**；下界不产黑曜石；而"水+岩浆浇黑曜石"在下界因**水直接蒸发**（`BucketItem.java:107` ultraWarm）也做不了。'
                + '⇒ **自带黑曜石的方案 B 在拿到钻石镐之前不可行。**',
            notVerifiedThisRound: '本单**未实跑**这条（需一次真服对照：铁镐挖 1 格黑曜石看背包计数）。判据链：jar 战利品表 + 字节码判据 + 手册 §7 的铁镐口径。',
        };
        out.obsidianBudget.frameSizes = {
            min_4x4_inner2x2: 12, full_4x5_inner2x3: 14,
            note: '1.16.1 的 `PortalShape` 内侧最小 2×2（可直立通过），对应 4×4 框 = 12 格黑曜石；'
                + '内侧 2×3 的完整门 = 4×5 框 = 14 格。**所以"自带 10 块"不够**（那是内侧只有 2×1、成年人进不去的框）。',
        };
    }
}

// ═══════════════ ④ 两个方案的对照（只出数据与建议，不改站序）
{
    const a = {
        id: 'A', name: '回原门出主世界，主世界长距离走到门室',
        netherPath: '原路回门（下界三条腿反向）',
        landingCertainty: '**确定** —— 回同一个门必然回同一格（方案 A 唯一比 B 强的地方）',
        overworldWalk: null, viaIronDoor: IRON_DOOR,
        notes: '下界回程 = 三条腿反向；主世界那段要穿过 S1 门所在的山体到 (1311,36,1167)。'
            + '⚠ 主世界这段**没有存档支撑**（盘上存档不覆盖这条走廊），只能给几何路点。',
    };
    const best = out.overworldLandingCandidates?.strongest ?? out.overworldLandingCandidates?.all?.[0] ?? null;
    const b = {
        id: 'B', name: '下界 (167,145) 就地造门（自带 10 块黑曜石）出去',
        netherPath: 'C3 → (167,145) 造门点',
        landingCertainty: '**未验** —— 1.16.1 往下搜且必须唯一候选；候选清单见 overworldLandingCandidates',
        landingGuess: best,
        distLandingToIronDoor: best ? best.distToIronDoor : null,
        distLandingToS5Stand: best ? best.distToS5Stand : null,
        netherBuildSpots: out.netherBuildSpots?.cleanest?.stand ?? null,
        obsidianNeeded: 10,
        notes: '⚠ **下界没有水**（水直接蒸发）⇒ 门只能自带黑曜石：最小 4×3 框 = 10 格（内侧 2×1，要爬着过）；'
            + '完整 4×5 框 = 14 格（内侧 2×3，可直立）。下界不产黑曜石 ⇒ 这 10~14 块必须**从主世界带进去**，'
            + '而主世界能拿到的只有 S1 废墟门框那几块（见 obsidianBudget.counts）—— **这是方案 B 的真正瓶颈，不是距离**。',
    };
    out.options = [a, b];
    out.recommendation = {
        pick: '**A（回原门）** —— 除非链路能拿到钻石镐',
        why: ['① 距离上 B 更优：下界 233 格量级 vs 方案 A 的主世界 1430 格量级。',
            '② **但 B 的瓶颈不是距离，是黑曜石**：下界不产、水又蒸发（`BucketItem.java:107`）⇒ 只能自带；',
            '   而 1.16.1 黑曜石掉落有工具门槛（战利品表无 `match_tool`，门槛在方块属性），**铁镐挖门框掉 0 块**；',
            '   造门最少要 12 块（4×4 框，内侧 2×2），门框附近存档里一共只有 11 块 obsidian ⇒ **即便能挖也差 1 块**。',
            '③ A 的落点是**确定**的（回同一个门必然回同一格），B 的落点**未验**且按 1.16.1 判据门室地板不满足条件、命中还多解。',
            '④ 无论选哪个，**下界三条腿的地形路点都必须先有**（本单第 2 项的产出）—— 没有它两条都走不了。'],
        ifDiamondAvailable: '若链路能到钻石镐（S3 之后要不要为它绕路由设计会话定），B 立刻变成"挖 12 块门框黑曜石 + 下界 233 格"，'
            + '仍优于 A 的 1430 格。**这一条是"值不值得为钻石镐绕路"的唯一判据。**',
        notDecided: '站序未改（派单明确要求只出数据与建议）。',
    };
}

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
const back = JSON.parse(fs.readFileSync(OUT, 'utf8'));
if (back.schema !== out.schema) { console.error('✗ 写回读出不一致'); process.exit(1); }
console.log(`落盘并读回：${path.relative(process.cwd(), OUT)}`);
console.log('下界造门站位：', out.netherBuildSpots?.skipped ? `跳过（${out.netherBuildSpots.skipped}）` : `${out.netherBuildSpots.count} 个；最干净 ${JSON.stringify(out.netherBuildSpots.cleanest?.stand)}（附近危险格 ${out.netherBuildSpots.cleanest?.hazardCellsInPad}）`);
console.log('主世界落点候选：', out.overworldLandingCandidates?.skipped ? `跳过（${out.overworldLandingCandidates.skipped}）` : `${out.overworldLandingCandidates.count} 个；最近铁门 ${out.overworldLandingCandidates.strongest?.landingCell} → ${out.overworldLandingCandidates.strongest?.distToIronDoor} 格`);
console.log('黑曜石库存：', JSON.stringify(out.obsidianBudget.counts));
for (const w of out.warnings) console.log('⚠ ' + w);
