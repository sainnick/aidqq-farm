﻿// gen_route.mjs — MC-ROUTE-02 route 生成器 · **probe 阶段**（要开服、要机器时间）
//
// 职责：输入一个种子 → 用服务器权威通道把 SCHEMA v1 需要的每站数据探出来 →
//       落 `bench/route/probe/<seed>.probe.json`。**本阶段不产出 route 文件**，
//       route 文件由 emit_route.mjs（纯函数、零机器时间）从 probe 生成。
// 为什么要拆成两段：
//   1) 确定性可离线证明——"同种子重复生成 diff 为空"只需要重跑纯函数那一步（秒级），
//      不必重开三次服务器重扫三遍；
//   2) 探测结果可以缓存复用，换站序/换字段不用重新占泳道。
//
// 站序 = 通用 SSG 路线（route-01 §1.1 社区八段 + DECISION-01 §2.2 的 L2 站级切法），
// 不是针对某个种子的特化路线。
//
// 核验口径（手册 §5 / DECISION-01 §2.1）：
//   - 坐标来源 = 服务器 `/locate`（等价于"种子数学/结构生成算法"，赛前允许）；
//   - 下钻与计数 = `forceload` + `fill … replace` 的**服务器回执**；
//   - 每站都带地形对照（overworld: stone/dirt/water；nether: netherrack），
//     出现「全零对照盒」= 该次扫描不可信 → 站标 UNVERIFIED，不当 REAL；
//   - 点状目标额外自检：下钻点数 == 粗扫计数，不等则同样降级为 UNVERIFIED。
//
// 用法：node gen_route.mjs --seed <seed> [--only <cat1,cat2>]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR, portState, ROOT } from './console.mjs';
import { locate, drill, nearestHitBox, forceload } from './scan.mjs';
import { frameCells, interiorCells, checkFrame, findBestFrame, classifyFrameCells, FRAME_SCAN_CANDIDATES } from './portal_frame.mjs';
import { probeCells, probeBlockState, fillSupportsBlockState } from './cell_probe.mjs';

/**
 * SEED-03 结构起点回退表（cubiomes A 通道 + `/locate` B 通道，R3 已用服务器权威通道核验过 REAL）。
 *
 * 为什么需要回退：**下界结构的 `/locate` 必须先生成下界区块**，实测能把服务器拖过 60s 看门狗
 * （"A single server tick took 60.01 seconds … server will forcibly shutdown"），
 * 备选 1 上 `fortress` / `bastion_remnant` 两条都被拖死。任务单 §1 写的是
 * "坐标来源：cubiomes / `/locate` 给结构起点"——两者都在允许范围内，
 * 所以下界坐标改从 SEED-03 的 cubiomes 结果取（R3 已逐个用 fill-replace 核过 REAL），
 * 起点**本身仍要经本工具的服务器权威通道下钻核验**，只是"起点"来自 cubiomes 而不是当场 `/locate`。
 */
function loadSeedScoutTable() {
    const p = path.join(ROOT, 'experiments', 'seed-scout', 's3_results', 's3_truth_table.csv');
    if (!fs.existsSync(p)) return { table: new Map(), path: p, ok: false };
    // ⚠ 这份 CSV 的 evidence 列**含未转义逗号**（如 `r48|crying_obsidian:1,obsidian:9`），
    //   不能按逗号朴素切分；前 9 列（seed..verdict）是安全的，evidence 起全部忽略。
    const map = new Map();
    for (const line of fs.readFileSync(p, 'utf8').split(/\r?\n/).slice(1)) {
        if (!line.trim()) continue;
        const f = line.split(',');
        if (f.length < 9) continue;
        const [seed, structure, aX, aZ, bX, bZ, aReal, bReal, verdict] = f;
        if (!/^-?\d+$/.test((seed ?? '').trim())) continue;
        if (verdict !== 'BOTH_REAL' && verdict !== 'B_ONLY' && verdict !== 'A_ONLY') continue;
        // B_ONLY/A_ONLY 表示只有一路声称 REAL，但仍被 R3 核验过；取声称 REAL 的那一路
        const src = (bReal === 'REAL' && bX) ? { x: +bX, z: +bZ, src: 'locate(R3)' }
            : (aReal === 'REAL' && aX) ? { x: +aX, z: +aZ, src: 'cubiomes(R3)' }
                : null;
        if (!src) continue;
        if (!map.has(seed.trim())) map.set(seed.trim(), {});
        map.get(seed.trim())[structure] = src;
    }
    return { table: map, path: p, ok: true };
}

const SEED = argOf(process.argv, 'seed', '-8839485814800629942');
const ONLY = argOf(process.argv, 'only', '').split(',').map((s) => s.trim()).filter(Boolean);
const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const RUN_DIR = path.join(ROUTE_DIR, 'probe', `_run_${SEED}`);

// ---- 每站的探测配方（改这里 = 换探测口径；站序不在这里，在 emit 的 STATION_ORDER） ----
const RECIPES = {
    // ① 末地门室：12 个框的精确位置（点状 → 下钻到 1×1×1）
    stronghold_room: {
        dim: 'overworld', from: 'stronghold', r: 48, ySlices: [[0, 63], [64, 100]], // 提到贯穿高度：备选2 r=48/y10-60 只测到 9 个框（SEED-03 记 12），先排除 y 带漏扫
        minTargets: 12,   // 门室固定 12 框：不足即加宽（备选2 实测 r=48 只切到 9 个——门室贴在盒子边界上）
        targets: ['minecraft:end_portal_frame'], drillBlocks: ['minecraft:end_portal_frame'],
    },
    // ② 烈焰人刷怪笼：≥2 个（点状 → 精确坐标）。
    //    注意 `/locate fortress` 给的是"最近的堡垒生成点"，r48 常常只盖到堡垒一角
    //    （主种子首轮 r48：nether_bricks 有货但 spawner=0）→ 允许全零加宽到 r96，
    //    并把 nether_bricks 一并计进 targets，用来证明"扫的确实是要塞而不是空地"。
    fortress_spawner: {
        dim: 'the_nether', from: 'fortress', r: 48, ySlices: [[30, 61], [62, 93]],
        minTargets: 2,   // 任务单 §1.2「≥2 个冗余」：不足也加宽
        targets: ['minecraft:spawner', 'minecraft:nether_bricks'],
        drillBlocks: ['minecraft:spawner'],
        undrilledExempt: ['minecraft:nether_bricks'],   // 锚点：只用来证明"扫的确实是要塞"，不是本站交付物
        drillUntil: 6,   // 任务单只要「≥2 个冗余」；一个要塞能有几百个，挖 6 个够审阅与冗余
        widen: true,
    },
    // ③ 堡垒遗迹：**区域**级（任务单 §1.3 原文："下钻只记结构区域"）。
    //    主种子实测该堡垒有 gilded_blackstone:190 / gold_block:36 / chest:16，
    //    逐点下钻要 7462 次 fill 且被保险丝截断——而站级 radius 本来就 ≥16，不需要格级坐标。
    //    所以取「离参考点最近且对照通过的命中盒」当区域中心，精确计数留在 scout。
    bastion: {
        dim: 'the_nether', from: 'bastion_remnant', r: 48, ySlices: [[0, 31], [32, 63], [64, 95], [96, 127]],
        targets: ['minecraft:gilded_blackstone', 'minecraft:gold_block', 'minecraft:chest'],
        drillBlocks: [],
        widen: true,
    },
    // 传送门本体：点状（下钻补框要用到门框与黑曜石的实际位置）
    //    ROUND3 §C-1：**区域总数 ≠ 框内计数**。这里除下钻外还要输出**逐格框体判定**
    //    （缺几格、缺格被什么占），几何 = portal_frame.mjs（生产 frameCells 的移植）。
    //    ⚠ 必须排在 lava_pool **之前**：岩浆站的"离门距离/高度差"要拿门框原点当基准。
    ruined_portal: {
        dim: 'overworld', from: 'ruined_portal', r: 32, ySlices: [[40, 71], [72, 100]],
        targets: ['minecraft:crying_obsidian', 'minecraft:obsidian', 'minecraft:chest'],
        drillBlocks: ['minecraft:crying_obsidian', 'minecraft:obsidian', 'minecraft:chest'],
        frame: true,
    },
    // ④ 浇门用岩浆源：主世界、离废墟门最近的岩浆（**下钻到源块**，面状 → 只记命中盒，不逐点下钻）
    //    ROUND3 §C-1：岩浆站要输出「源块(level 0) + 离门距离 + 高度差 + 可达性」，
    //    而旧的 `selfCheck.minecraft:lava.ok = null`（粗扫命中、未下钻）不许再标 REAL。
    //    所以这里把 target 换成**带方块状态**的 `lava[level=0]`——能否直接用取决于 1.16.1 的
    //    `/fill … replace` 认不认方块状态，运行时用 fillSupportsBlockState() 实测（见下）。
    lava_pool: {
        dim: 'overworld', from: 'ruined_portal', r: 48, ySlices: [[0, 31]],
        targets: ['minecraft:lava[level=0]'], drillBlocks: ['minecraft:lava[level=0]'],
        sourceBlocks: true, drillNearestBoxes: 2, drillUntil: 60, widen: true,
    },
    // ⑤ 采集点：铁源（面状）
    iron_source: {
        dim: 'overworld', from: 'spawn', r: 64, ySlices: [[0, 31], [32, 63]],
        targets: ['minecraft:iron_ore'], drillBlocks: [],
        allowUndrilled: true,   // 面状站按设计只记区域（任务单 §1.3「下钻只记结构区域」）
    },
    // ⑤ 采集点：裸露沙砾区（面状）。y 带按"地表附近"取，避开 y<40 的洞穴砾。
    gravel: {
        dim: 'overworld', from: 'spawn', r: 64, ySlices: [[40, 71], [72, 100]],
        targets: ['minecraft:gravel'], drillBlocks: [],
        allowUndrilled: true,   // 同上：面状站
    },
    // 埋藏宝藏箱（铁源的精确补充：箱里有铁锭）
    buried_treasure: {
        dim: 'overworld', from: 'buried_treasure', r: 32, ySlices: [[20, 51], [52, 75]],
        targets: ['minecraft:chest', 'minecraft:trapped_chest'], drillBlocks: ['minecraft:chest', 'minecraft:trapped_chest'],
    },
};

const want = (k) => !ONLY.length || ONLY.includes(k);

let handle = null;
const PROBE_OUT = path.join(PROBE_DIR, `${SEED}.probe.json`);
// --only 复跑某一类时**合并**进已有 probe（而不是整份覆盖），否则补测一类会把其余七类的
// 数据清掉、逼着整轮重扫。合并时只覆盖本次真正重算的 categories。
const merge = ONLY.length > 0 && fs.existsSync(PROBE_OUT);
const base = merge ? JSON.parse(fs.readFileSync(PROBE_OUT, 'utf8')) : null;
if (merge) log(`--only 模式：合并进已有 probe（已存 ${Object.keys(base.categories ?? {}).length} 类），本次重算：${ONLY.join(',')}`);

const probe = {
    schema: 'aidqq-route-probe/1',
    seed: SEED,
    mcVersion: '1.16.1',
    generatedAt: new Date().toISOString(),
    generatedAtByCategory: merge ? (base.generatedAtByCategory ?? {}) : {},   // 每类各自的探测时刻
    method: {
        starts: 'server /locate (1.16.1 裸名，Y 返回 ~ 需按 XZ 取)',
        counts: 'forceload + fill <box> <marker> replace <block> 回执（服务器权威）；盒高 ≤16 避免回执迟滞错位',
        drill: '双标记逐层交替递归细分至 1x1x1（barrier ↔ command_block）；fill 自替换不计数，故必须交替；下钻前清场',
        controls: '每盒地形对照（overworld stone/dirt/water，nether netherrack）；整趟全零时用贯穿 y 带复扫以证伪工具',
        selfCheck: '点状目标「下钻点数 == 粗扫计数」；不等即降级 UNVERIFIED（防回执错位/标记污染产出错坐标）',
        worldPerCategory: '**每个类目一个 fresh world**。原因：fill-replace 会真实改变世界——'
            + '粗扫会把实测石块换成 bedrock、会把目标块换成 marker。多个类目在同一世界扫重叠区域会互相污染'
            + '（实测：lava_pool 把 206619 个石头换成 bedrock 后，随后扫同一片区域的 ruined_portal 地形对照读到 0；'
            + 'lava_pool 的 3502 个 marker 也让门户下钻多算了点）。世界生成对同种子是确定的，所以重开世界不改变地形，只清掉标记污染。',
    },
    structures: merge ? (base.structures ?? {}) : {},
    categories: merge ? (base.categories ?? {}) : {},
    unverified: [],
};

/** 增量落盘：写 probe 快照（每类完成后调用；中断后可 `--only <剩余类目>` 续跑） */
function writeProbe(out, pr) {
    try {
        fs.mkdirSync(path.dirname(out), { recursive: true });
        pr.unverified = Object.entries(pr.categories).filter(([, c]) => c.status !== 'OK').map(([k, c]) => ({ cat: k, reason: c.reason }));
        for (const [k, c] of Object.entries(pr.categories)) {
            pr.generatedAtByCategory[k] = c.probedAt ?? pr.generatedAt;
            c.probedAt = pr.generatedAtByCategory[k];
        }
        fs.writeFileSync(out, JSON.stringify(pr, null, 2));
    } catch (e) {
        log(`  ✗ 增量落盘失败：${String(e).slice(0, 100)}`);
    }
}

try {
    // ---- 0) 结构起点（服务器权威；与 SEED-03 cubiomes 结果交叉核对） ----
    // 这一段单独一个世界：用完就停，后面每个类目各自开一个 fresh world。
    // 只数**真正拿到坐标**的起点：失败的条目也占键（probe 里 stronghold…bastion_remnant 一共 7 个键，
    // 但其中 3 个可能是 {failed:true}）。按键数判断会误以为"起点已齐"从而跳过定位，
    // 连带把依赖它的类目错判成 start_not_found（实测踩过）。
    const usable = Object.values(probe.structures).filter((v) => Number.isFinite(v?.x)).length;
    if (usable >= 7) {
        log(`--- 0) /locate 结构起点：probe 里已有 ${usable}/7 个可用，跳过（省一次起服）---`);
    } else {
        const scout = loadSeedScoutTable();
        if (scout.ok) log(`SEED-03 起点回退表已载入：${path.relative(ROOT, scout.path)}（${scout.table.size} 个种子）`);
        const b = await bootLaneC({ seed: SEED, runDir: RUN_DIR, logFn: log });
        handle = b;
        log('--- 0) /locate 结构起点（失败则回退 SEED-03 cubiomes 表）---');
        for (const [key, st, dim] of [
            ['stronghold', 'stronghold', 'overworld'],
            ['ruined_portal', 'ruined_portal', 'overworld'],
            ['village', 'village', 'overworld'],
            ['shipwreck', 'shipwreck', 'overworld'],
            ['buried_treasure', 'buried_treasure', 'overworld'],
            ['fortress', 'fortress', 'the_nether'],
            ['bastion_remnant', 'bastion_remnant', 'the_nether'],
        ]) {
            // 逐个容错：单条 /locate 失败（含把服务器拖死）不能带倒整轮。
            // 实测：`/locate buried_treasure` / `locate fortress` 会触发 "A single server tick took
            // 60.01 seconds" → 服务器自判崩溃。失败后按 SEED-03 表回退（R3 已核验 REAL）。
            let got = null;
            if (handle && handle.server?.child?.exitCode === null) {
                try { const p = await locate(b.con, st, dim); if (p.x != null) got = { ...p, source: 'locate' }; }
                catch (e) { log(`  ${key} locate 异常：${String(e).slice(0, 80)}`); }
            }
            if (!got) {
                const fb = scout.table.get(String(SEED))?.[st];
                if (fb) { got = { x: fb.x, y: null, z: fb.z, source: fb.src, fallbackFrom: 'locate_failed' }; log(`  ${key} → 回退 ${fb.src} (${fb.x}, ${fb.z})`); }
            }
            probe.structures[key] = got ?? { failed: true, reason: 'locate_failed_and_no_scout_fallback' };
            if (got && got.source === 'locate') log(`  ${key} → (${got.x}, ${got.z})`);
            if (handle && handle.server?.child?.exitCode !== null) { log('  服务器已死：后续 /locate 全部走回退'); handle = null; }
        }
        if (handle) { await shutdownLaneC(handle); handle = null; }
    }
    const spawnRef = probe.structures.ruined_portal?.x != null
        ? { x: probe.structures.ruined_portal.x, z: probe.structures.ruined_portal.z }
        : { x: 0, z: 0 };
    probe.spawnRef = spawnRef;

    // ---- 1) 各类别下钻 ----
    for (const [cat, rc] of Object.entries(RECIPES)) {
        if (!want(cat)) continue;
        const start = rc.from === 'spawn' ? spawnRef : probe.structures[rc.from];
        if (!start || start.x == null) {
            log(`  [${cat}] 起点缺失（${rc.from}），标 UNVERIFIED`);
            probe.categories[cat] = { status: 'UNVERIFIED', reason: `start_not_found:${rc.from}` };
            probe.unverified.push({ cat, reason: `start_not_found:${rc.from}` });
            continue;
        }
        const t0 = Date.now();
        log(`--- ${cat} @ ${rc.from}(${start.x},${start.z}) dim=${rc.dim} r=${rc.r}（本类目开 fresh world）---`);
        // 每个类目一个 fresh world：fill-replace 会真实改变世界（实测石块被换成 bedrock、
        // 目标块被换成 marker），同世界扫重叠区域会互相污染。详见 probe.method.worldPerCategory。
        // 服务器中途死掉（实测 `/locate` 稀有地物时可能触发 tick 超时自判崩溃）→ 本类目重试一次。
        const runCategory = async (attemptNo) => {
            handle = await bootLaneC({ seed: SEED, runDir: path.join(RUN_DIR, cat), logFn: log });
            // 源块口径的能力探测：**1.16.1 的 `/fill … replace` 认不认方块状态**（如 `lava[level=0]`）。
            // 认 → 直接把带状态的方块当 target，drill 的粗扫计数 / 八叉下钻 / 双重自检全部白拿；
            // 不认 → 退回「粗扫所有 lava + 对下钻到的点逐个用 execute if block 判 level=0」，
            //        慢且是抽样，报告里会标明是 fallback 口径。
            let eff = rc;
            if (rc.sourceBlocks) {
                const cap = await fillSupportsBlockState(handle.con, rc.dim, { x: start.x, y: 40, z: start.z });
                probe.capabilities = { ...(probe.capabilities ?? {}), fillReplaceBlockState: cap };
                log(`  [${cat}] 能力探测 /fill replace <方块状态>：${cap.supported ? '支持' : '不支持'}（${cap.evidence}）`);
                if (!cap.supported) {
                    eff = { ...rc, targets: ['minecraft:lava'], drillBlocks: ['minecraft:lava'], sourceFallback: true, widen: false };
                    log(`  [${cat}] → 退回抽样口径：粗扫 minecraft:lava，再逐点判 level=0`);
                }
            }
            const doDrill = (r, ySlices) => drill(handle.con, eff.dim, start.x, start.z, r, ySlices, eff.targets,
                { drillBlocks: eff.drillBlocks, drillUntil: eff.drillUntil ?? 0, logFn: log });
            let res = await doDrill(rc.r, rc.ySlices);
            // R3 同款「全零加宽」：**只看本站真正需要的那个目标**是不是 0。
            // 触发量必须排除锚点方块——例如要塞的 nether_bricks 是"证明扫对地方"的锚点，
            // 它非 0 不代表刷怪笼找到了（主种子首轮：砖 91747 但 spawner=0）。
            const keyTargets = eff.drillBlocks?.length ? eff.drillBlocks : eff.targets;
            let widened = false;
            // 加宽触发：目标全 0（没盖到）**或** 少于 minTargets（不够用）。
            // 备选 2 实测 r=48 只有 1 个刷怪笼，而任务单要「≥2 个冗余」——不够也要加宽。
            const keySum = keyTargets.reduce((a, t) => a + (res.counts[t] ?? 0), 0);
            const need = rc.minTargets ?? 0;
            if ((keySum === 0 || (need > 0 && keySum < need)) && rc.widen !== false) {
                const r2 = rc.r * 2;
                log(`  [${cat}] r=${rc.r} 目标不足（${keyTargets.join('|')} 合计 ${keySum}${need ? ` < 最低要求 ${need}` : ' = 0'}；地形对照=${JSON.stringify(res.terrain)} 说明工具正常）→ 加宽到 r=${r2}`);
                // ⚠ 加宽前**必须换 fresh world**（ROUTE-02 §4.3 的铁律：fill-replace 会真实改变世界，
                //   而 r2 的盒子**包含** r 的盒子）。上一版在同一世界里加宽，等于拿被上一轮
                //   标过 marker/CTRL 的区域去重数——补 1 条：本单 P2 实测 backup1 的
                //   fortress_spawner 在 r=96 时数到的 nether_bricks(26194) 与 R3 在 r=48 的
                //   26390 几乎一样（r=96 的盒更大，砖却没变多）= 内圈被上一轮标掉了、没被数到。
                await shutdownLaneC(handle);
                handle = await bootLaneC({ seed: SEED, runDir: path.join(RUN_DIR, `${cat}_widen`), logFn: log });
                res = await doDrill(r2, rc.ySlices);
                widened = true;
            }
            // fallback 口径的收尾：把下钻到的**所有 lava 点**筛成真正的源块（level=0）。
            // 注意这是**抽样**结论（drillUntil 封顶），报告里会标明。
            if (eff.sourceFallback) {
                const pts = res.perBlock['minecraft:lava']?.points ?? [];
                let srcs = [];
                if (pts.length) {
                    await forceload(handle.con, eff.dim, Math.min(...pts.map((p) => p.x)) - 1, Math.min(...pts.map((p) => p.z)) - 1,
                        Math.max(...pts.map((p) => p.x)) + 1, Math.max(...pts.map((p) => p.z)) + 1);
                    srcs = (await probeBlockState(handle.con, eff.dim, pts, 'minecraft:lava[level=0]')).hits;
                }
                res.perBlock['minecraft:lava[level=0]'] = { block: 'minecraft:lava[level=0]', coarse: srcs.length, points: srcs };
                res.counts['minecraft:lava[level=0]'] = srcs.length;
                res.selfCheck['minecraft:lava[level=0]'] = {
                    coarse: srcs.length, drilled: srcs.length, partialByDrillUntil: false,
                    ok: srcs.length === pts.length ? null : true, sampledFrom: pts.length, method: 'execute-if-block-level0',
                };
                log(`  [${cat}] fallback：抽样 ${pts.length} 个 lava 点，判出源块 ${srcs.length} 个`);
            }
            return { res, widened };
        };
        let res, widened;
        try {
            ({ res, widened } = await runCategory(1));
        } catch (e) {
            if (!/server died|FILL_NO_RESPONSE|SERVER_DIED/i.test(String(e))) throw e;
            log(`  [${cat}] 服务器异常（${String(e).slice(0, 80)}）→ 冷却 20s 后重起一次`);
            await shutdownLaneC(handle).catch(() => { });
            handle = null;
            await new Promise((r) => setTimeout(r, 20000));
            ({ res, widened } = await runCategory(2));
        }
        const sec = Math.round((Date.now() - t0) / 1000);

        // 「整趟地形对照为零」的两种可能，必须分开（手册 §5：读出全零先证伪工具，再证伪世界）：
        //   (a) 工具坏了 → 不可信
        //   (b) 这一片本来就几乎全是空气（山丘上的门、海面上）——**数据其实是对的**
        // 区分办法：换一条贯穿地形的 y 带只扫对照块，能扫到东西 → 工具正常，数据采信。
        let terrainTotal = Object.values(res.terrain).reduce((a, b) => a + b, 0);
        let terrainProof = terrainTotal > 0 ? 'in-scan' : null;
        if (terrainTotal <= 0) {
            log(`  [${cat}] 原地形对照全零 → 用贯穿 y 带 [[0,63],[64,127]] 复扫对照块以证伪工具`);
            const ctl = await drill(con, rc.dim, start.x, start.z, Math.min(rc.r, 32), [[0, 63], [64, 127]], [], { logFn: null });
            terrainTotal = Object.values(ctl.terrain).reduce((a, b) => a + b, 0);
            terrainProof = terrainTotal > 0 ? 'reprobe-wide-y' : 'still-zero';
            res.terrain = ctl.terrain;
            log(`  [${cat}] 证伪结果：${terrainProof}（对照合计 ${terrainTotal}）`);
        }

        // badDrill 只收 ok === false；ok === 'partial' 是"主动按 drillUntil 少挖"，不是错
        const badDrill = Object.entries(res.selfCheck).filter(([, v]) => v.ok === false).map(([k]) => k);
        // ROUND3 §C-1：`selfCheck.<block>.ok = null`（粗扫命中、**没下钻核验**）不许再标 REAL。
        //   面状站（区域级，按任务单 §1.3 只记区域）必须显式 `allowUndrilled: true` 才放行；
        //   锚点方块（如要塞的 nether_bricks，只用来"证明扫对地方"、不是本站交付物）
        //   逐条列进 `undrilledExempt` 豁免——**要指名，不给"其余默认豁免"**。
        const exempt = new Set(rc.undrilledExempt ?? []);
        const undrilled = Object.entries(res.selfCheck)
            .filter(([k, v]) => v.ok === null && (v.coarse ?? 0) > 0 && !exempt.has(k))
            .map(([k]) => k);
        const undrilledBlocked = undrilled.length > 0 && rc.allowUndrilled !== true;
        const ok = terrainTotal > 0 && badDrill.length === 0 && !res.truncated && !undrilledBlocked;
        probe.categories[cat] = {
            status: ok ? 'OK' : 'UNVERIFIED',
            reason: ok ? null : [
                terrainTotal <= 0 ? 'terrainControlAllZero_evenAfterReprobe(tool suspect)' : null,
                badDrill.length ? `drillMismatch:${badDrill.join('|')}` : null,
                res.truncated ? 'drillTruncated(保险丝截断，点集不全)' : null,
                undrilledBlocked ? `coarseHitButNotDrilled:${undrilled.join('|')}（面状站需显式 allowUndrilled）` : null,
            ].filter(Boolean).join('; '),
            seconds: sec, fills: res.fills, widened, r: res.r,
            desyncStaleResponses: res.desync ?? 0,
            start: { from: rc.from, x: start.x, z: start.z },
            region: { cx: start.x, cz: start.z, r: res.r, ySlices: rc.ySlices, dim: rc.dim },
            counts: res.counts, terrain: res.terrain, terrainTotal, terrainProof,
            boxes: res.boxes, boxesZeroControl: res.boxesZeroControl,
            selfCheck: res.selfCheck,
            hitBoxes: res.hitBoxes.map((h) => ({ box: h.box, hit: h.hit, zeroCtrl: h.zeroCtrl })),
            points: Object.fromEntries(Object.entries(res.perBlock).map(([k, v]) => [k, v.points])),
            nearestBox: (() => { const nb = nearestHitBox(res.hitBoxes, spawnRef); return nb ? { box: nb.box, hit: nb.hit } : null; })(),
        };
        // ================= ① 框体逐格判定（ROUND3 §C-1） =================
        // 「区域总数 ≠ 框内计数」：obsidian:9 + crying:1 的总数不能回答"框里缺几格"。
        if (rc.frame) {
            const framePts = [
                ...(res.perBlock['minecraft:obsidian']?.points ?? []),
                ...(res.perBlock['minecraft:crying_obsidian']?.points ?? []),
            ];
            const { best, runnersUp, candidatesTried } = findBestFrame(framePts);
            const frameOut = { method: 'frameCells(production 移植, bench/route/tools/portal_frame.mjs)', evidencePoints: framePts.length, candidatesTried, best: null };
            if (!best) {
                frameOut.reason = 'no_candidate_frame（下钻没拿到任何 obsidian/crying 点）';
            } else {
                // ⚠ 逐格读方块**必须在未被 fill 标记污染的世界里**做——下钻已经把框内黑曜石
                //   换成了 barrier/command_block。所以这里换 fresh world 再读（与 ROUTE-02 §4.3
                //   同一条纪律，只是这次用于「读」而不是「扫」）。
                await shutdownLaneC(handle);
                handle = await bootLaneC({ seed: SEED, runDir: path.join(RUN_DIR, `${cat}_frame`), logFn: log });
                const pr = await classifyFrameCells(handle.con, rc.dim, best.origin, best.axis, { logFn: log });
                const names = new Map();
                pr.cells.forEach((c, i) => names.set(`${c.pos.x},${c.pos.y},${c.pos.z}`, pr.blocks[i]));
                const blockAt = (p) => names.get(`${p.x},${p.y},${p.z}`) ?? null;
                const fr = checkFrame(best.origin, best.axis, blockAt);
                frameOut.best = {
                    origin: [best.origin.x, best.origin.y, best.origin.z], axis: best.axis,
                    obsidian: fr.obsidian, required: fr.required, optionalObsidian: fr.optionalObsidian,
                    missing: fr.missing, wrong: fr.wrong, dirty: fr.dirty,
                    obsidianToPlace: fr.obsidianToPlace, usable: fr.ok,
                    runnerUps: runnersUp.map((r) => ({ origin: [r.origin.x, r.origin.y, r.origin.z], axis: r.axis, reqHits: r.reqHits })),
                    // 逐格真值留档（14 框格 + 6 内部格），审阅时可逐格核对
                    cellTruth: pr.cells.map((c, i) => ({
                        pos: [c.pos.x, c.pos.y, c.pos.z], kind: c.kind, u: c.u, dy: c.dy,
                        optional: !!c.optional, got: pr.blocks[i] ?? null,
                    })),
                    probe: { fills: pr.fills, airTests: pr.airTests, unresolved: pr.unresolved, candidates: FRAME_SCAN_CANDIDATES },
                };
                log(`  [${cat}] 框体判定 origin=(${best.origin.x},${best.origin.y},${best.origin.z}) axis=${best.axis}：`
                    + `obsidian ${fr.obsidian}/${fr.required} · 缺(空) ${fr.missing.length} · 错块 ${fr.wrong.length}`
                    + ` · 内部脏 ${fr.dirty.length} · **需补 obsidian ${fr.obsidianToPlace}** · 清单外未识别 ${pr.unresolved} · 复原失败 ${pr.restoreFails}`);
            }
            probe.categories[cat].frame = frameOut;
            probe.frame = frameOut.best ? { origin: frameOut.best.origin, axis: frameOut.best.axis, obsidianToPlace: frameOut.best.obsidianToPlace, usable: frameOut.best.usable, dim: rc.dim } : (probe.frame ?? null);
        }

        // ================= ② 岩浆源块字段（离门距离 / 高度差 / 可达性） =================
        if (rc.sourceBlocks) {
            const ref = probe.frame?.origin
                ? { x: probe.frame.origin[0], y: probe.frame.origin[1], z: probe.frame.origin[2], from: 'frameOrigin' }
                : { x: start.x, y: null, z: start.z, from: 'locateStart(门框原点缺失，高度差无法计算)' };
            const round1 = (v) => Math.round(v * 10) / 10;
            const srcPts = (probe.categories[cat].points?.['minecraft:lava[level=0]'] ?? []).map((p) => {
                const dx = p.x - ref.x, dz = p.z - ref.z;
                return {
                    ...p,
                    dist2d: round1(Math.hypot(dx, dz)),
                    dist3d: ref.y == null ? null : round1(Math.hypot(dx, p.y - ref.y, dz)),
                    dy: ref.y == null ? null : Math.abs(p.y - ref.y),
                };
            }).sort((a, b) => a.dist2d - b.dist2d);
            // 「走得到」的**可测代理**：源块正上方那一格是不是空气（站得下/舀得到）。
            // 真正的可达性要 bot 跑一遍寻路才算（那是任务层的活，预勘阶段给不出）——
            // 这里给的是「能不能站上去」这一半，报告里会写明它是代理指标。
            const near = srcPts.slice(0, 12);
            let standable = null;
            if (near.length && handle) {
                await forceload(handle.con, rc.dim, Math.min(...near.map((p) => p.x)) - 2, Math.min(...near.map((p) => p.z)) - 2,
                    Math.max(...near.map((p) => p.x)) + 2, Math.max(...near.map((p) => p.z)) + 2);
                const sp = await probeCells(handle.con, rc.dim, near.map((p) => ({ x: p.x, y: p.y + 1, z: p.z })), { candidates: ['minecraft:air'] });
                standable = sp.blocks.map((b, i) => ({ ...near[i], standable: b === 'minecraft:air' }));
            }
            const list = standable ?? near;
            const meets = (p) => p.dy == null ? false : (p.dist2d <= 48 && p.dy <= 8 && p.standable !== false);
            const bestSrc = list.find(meets) ?? null;
            probe.categories[cat].sources = {
                blockState: 'minecraft:lava[level=0]',
                fallbackSampling: (probe.capabilities?.fillReplaceBlockState?.supported === false) ? 'fill 不认方块状态 → 抽样口径' : 'exact(fill 直接按 level=0 计数+下钻)', count: srcPts.length, sampled: list.length,
                doorRef: ref,
                criteria: { source: 'level=0', maxDist2d: 48, maxDy: 8, standable: '源块正上方为空气（可达性代理，非寻路结论）' },
                best: bestSrc,
                verdict: bestSrc ? 'usable_source_found' : (srcPts.length ? 'sources_exist_but_none_meet_criteria' : 'no_source_block_in_region'),
                points: list,
            };
            log(`  [${cat}] 岩浆源块 ${srcPts.length} 个（取最近 ${list.length} 个测上方空气）；`
                + `门基准 ${JSON.stringify(ref)}；判定=${probe.categories[cat].sources.verdict}`
                + (bestSrc ? ` 最近合格源=(${bestSrc.x},${bestSrc.y},${bestSrc.z}) 距门 ${bestSrc.dist2d} 格 Δy=${bestSrc.dy}` : ''));
        }

        if (!ok) probe.unverified.push({ cat, reason: probe.categories[cat].reason });        const tot = Object.entries(res.counts).map(([k, v]) => `${k.replace('minecraft:', '')}:${v}`).join(' ');
        log(`  [${cat}] ${probe.categories[cat].status} ${sec}s fills=${res.fills} r=${res.r}${widened ? '(加宽)' : ''} desync=${res.desync ?? 0} 计数: ${tot} 对照合计: ${terrainTotal}(${terrainProof})`);
        // 本类目的世界用完即弃（fresh world 隔离，见 probe.method.worldPerCategory）
        await shutdownLaneC(handle);
        handle = null;
        // **每类增量落盘**：泳道与开发线 E 排队共用，进程随时可能因为让路/窗口到点被中断；
        //   只在最后写盘的话，中断就等于整轮白跑（实测被占泳道时确实如此）。写增量后
        //   中断也能用 `--only <剩余类目>` 接着跑。
        writeProbe(PROBE_OUT, probe);
        log(`  [${cat}] 增量落盘（${Object.keys(probe.categories).length} 类已存）`);
    }

    writeProbe(PROBE_OUT, probe);
    log(`probe 落盘：${PROBE_OUT}`);
    const bad = Object.entries(probe.categories).filter(([, c]) => c.status !== 'OK');
    log(`小结：${Object.keys(probe.categories).length} 类，OK ${Object.keys(probe.categories).length - bad.length}，UNVERIFIED ${bad.length}（${bad.map(([k]) => k).join(',') || '无'}）`);
} catch (e) {
    log(`✗ gen_route 失败: ${e && e.stack ? e.stack : e}`);
    process.exitCode = 1;
} finally {
    await shutdownLaneC(handle);
    log(`收工：端口 ${JSON.stringify(portState())}`);
}




