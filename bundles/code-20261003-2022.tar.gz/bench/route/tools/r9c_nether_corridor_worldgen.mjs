// r9c_nether_corridor_worldgen.mjs — ROUND9-C 重点：下界**三条腿的真实地形走廊**存档
//
// 【为什么必须新生成（和 ROUND7-C 那次的区别）】
//   ROUND7-C（`r7c_nether_corridor_worldgen.mjs`）生成的是**作废坐标**的走廊：
//   那次把 `station.center` 又 ÷8 了一次，于是窗口只覆盖 x 0..127 / z -80..127
//   （对应"门落点 ≈ x23、S3 ≈ x42、C3 ≈ x28"这三个 ÷8 后的假坐标）。
//   **真实**下界坐标是：门落点 ≈(23,38)、S3 作业点 [331,56,238]、C3 站位 [220,69,-87]
//   ⇒ 走廊必须覆盖 x -32..431 / z -192..367 = 29×35 = **1015 区块**。
//   盘上四份存档（`_bedhunt` x112..431 / `_nether_corridor` x-32..127 / `_s3_easy` / `_s5_s5`）
//   **没有一份覆盖这条走廊**，而 ROUND7-C 已实证 `_bedhunt` 与 `_nether_corridor`
//   同种子也不一致（重叠 786,432 格中 82,363 格不同）⇒ 不能拼合成世界跑 BFS。
//
// 【只发两类命令】`difficulty easy` / `forceload add|query` / `save-all flush`。
//   **不发 fill / setblock / summon** —— 连 ROUND7-C 那个"就绪探针"的 1 格 barrier 也不发了。
//   原因：手册 §5「`kit / 布景命令"没报错" ≠ 生效`」+ B 线 r19 的教训 ——
//   **就绪与否用离线覆盖闸门判**（每批 save-all 后直接数 .mca 的区块头），
//   那比"fill 不再报 not loaded"更强，而且**一格都不改世界**。
//
// 【分批】1.16.1 单次 `forceload add` 上限 256 区块（手册 §5 / F 线 S2-01），
//   本单 1015 区块切成 5 批（210/210/210/175/210），每批 ≤256 且**回执逐批留档**。
//   每批加完立刻 `forceload query` 读回强制集，再 `save-all flush`。
//   收尾硬闸：逐区块数 .mca 头，`savedChunks === expected`，不足则**如实报缺**并再补一轮。
//
// 【泳道纪律】借泳道 C（与 F/H 按心跳共用）。**单次占用 ≤20 分钟**：本文件自带
//   `--deadline-s`（默认 900s）软闸，到点就停止加批、save-all、如实报 `PARTIAL`。
//
// 用法：node tools/r9c_nether_corridor_worldgen.mjs [--deadline-s 900] [--passes 2]

import fs from 'fs';
import path from 'path';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR } from './console.mjs';

const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const DEADLINE_S = Number(argOf(process.argv, 'deadline-s', '900'));
const PASSES = Number(argOf(process.argv, 'passes', '2'));
const RUN_DIR = path.join(ROUTE_DIR, 'probe', '_run_r9c_corridor');
const OUT = path.join(ROUTE_DIR, 'probe', 'worldgen_nether_corridor_r9c.json');
const DEST = path.join(ROUTE_DIR, 'probe', '_r9c_nether_corridor');

// ---- 走廊窗口：三条腿的并集包围盒 + 余量
// 门落点 (23,38) / S3 [331,56,238] / C3 [220,69,-87]  ⇒  x -32..431 / z -192..367
const BX0 = -32, BX1 = 431, BZ0 = -192, BZ1 = 367;
const CX0 = Math.floor(BX0 / 16), CX1 = Math.floor(BX1 / 16);   // -2 .. 26  (29)
const CZ0 = Math.floor(BZ0 / 16), CZ1 = Math.floor(BZ1 / 16);   // -12 .. 22 (35)
const EXPECTED = (CX1 - CX0 + 1) * (CZ1 - CZ0 + 1);              // 1015

/** 切成每批 ≤256 区块的 cx 段。 */
function planBatches() {
    const cols = [];
    for (let cx = CX0; cx <= CX1; cx++) cols.push(cx);
    const perBatchCols = Math.floor(256 / (CZ1 - CZ0 + 1));      // 256/35 = 7
    const out = [];
    for (let i = 0; i < cols.length; i += perBatchCols) out.push(cols.slice(i, i + perBatchCols));
    return out.map((cs) => ({ cx: [cs[0], cs[cs.length - 1]], chunks: cs.length * (CZ1 - CZ0 + 1) }));
}
const BATCHES = planBatches();

/** 数一个窗口里**真正写进了 .mca** 的区块数（离线硬闸，不看任何回执）。 */
function countSavedChunks(dimDir) {
    let saved = 0;
    const missing = [];
    for (let cx = CX0; cx <= CX1; cx++) for (let cz = CZ0; cz <= CZ1; cz++) {
        const rx = cx >> 5, rz = cz >> 5, idx = (cx - rx * 32) + (cz - rz * 32) * 32;
        const f = path.join(dimDir, `r.${rx}.${rz}.mca`);
        let ok = false;
        try {
            const b = fs.readFileSync(f);
            if (b.length >= 8192 + 4 && ((b.readUInt8(idx * 4) << 16) | (b.readUInt8(idx * 4 + 1) << 8) | b.readUInt8(idx * 4 + 2)) > 0) ok = true;
        } catch { ok = false; }
        if (ok) saved++; else missing.push([cx, cz]);
    }
    return { saved, missing };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** 单发命令等回执。回执行走 drain()（先进先出，单条在途 ⇒ 不会互抢）。 */
async function cmdOnce(con, cmd, re, timeoutMs = 120000) {
    con.drain();
    con.cmd(cmd);
    const t0 = Date.now();
    const seen = [];
    for (;;) {
        for (const line of con.drain()) { seen.push(line); if (re.test(line)) return line; }
        if (Date.now() - t0 > timeoutMs) throw new Error(`CMD_NO_RECEIPT: ${cmd}（末尾：${seen.slice(-2).join(' | ').slice(0, 200)}）`);
        await sleep(50);
    }
}

const out = {
    schema: 'aidqq-round9c-nether-corridor/1', seed: SEED, mcVersion: '1.16.1', lane: 'C',
    startedAt: new Date().toISOString(), status: 'NOT_RUN',
    purpose: '下界三条腿（门落点→S3→C3→门落点）的**地形级**路点：避开岩浆/岩浆块、逐格列出要挖穿/搭桥的格子',
    supersedesWindowOf: 'bench/route/probe/worldgen_nether_corridor.json（ROUND7-C，窗口按 ÷8 作废坐标选的）',
    window: {
        blocks: { x: [BX0, BX1], z: [BZ0, BZ1] }, chunks: { cx: [CX0, CX1], cz: [CZ0, CZ1] },
        expectedChunks: EXPECTED, batches: BATCHES,
        why: '真实下界坐标：门落点 ≈(23,38)、S3 作业点 [331,56,238]、C3 站位 [220,69,-87] ⇒ 并集包围盒 x-32..431 / z-192..367',
    },
    deadlineS: DEADLINE_S, passes: [], commandsIssued: [], mutatedCells: [],
    mutationPolicy: '**零方块改动**：不发 fill/setblock/summon（连 ROUND7-C 的就绪探针 barrier 也不发）。就绪判定 = 离线 .mca 区块头计数。',
    savedAt: null, coverage: null,
};

let h = null;
try {
    out.status = 'RUNNING';
    log(`=== ROUND9-C 下界走廊世界生成（${EXPECTED} 区块 / ${BATCHES.length} 批 / 软闸 ${DEADLINE_S}s）===`);
    h = await bootLaneC({ seed: SEED, runDir: RUN_DIR, logFn: log });
    const con = h.con;
    const sp = fs.readFileSync(path.join(h.lane.dir, 'server.properties'), 'utf8');
    const levelName = (/level-name=(.*)/.exec(sp)?.[1] ?? 'world').trim();
    out.worldDir = path.join(h.lane.dir, levelName);
    out.bootMs = h.server.bootMs;
    out.netherRegionDir = path.join(out.worldDir, 'DIM-1', 'region');

    const diff = await cmdOnce(con, 'difficulty easy', /difficulty/i, 20000);
    out.commandsIssued.push('difficulty easy'); out.difficultyReceipt = diff;
    log(`  ${diff}`);

    const t0 = Date.now();
    for (let pass = 1; pass <= PASSES; pass++) {
        const pRec = { pass, batches: [], startedAt: new Date().toISOString() };
        out.passes.push(pRec);
        for (const [bi, b] of BATCHES.entries()) {
            const elapsed = (Date.now() - t0) / 1000;
            const cnt = countSavedChunks(out.netherRegionDir);
            if (elapsed > DEADLINE_S) { pRec.stoppedByDeadline = `软闸触发：已用 ${elapsed.toFixed(0)}s > ${DEADLINE_S}s`; log(`  ⏱ ${pRec.stoppedByDeadline}；停止加批`); break; }
            const need = b.chunks;
            if (cnt.saved >= EXPECTED) { pRec.alreadyComplete = true; break; }
            const x0 = b.cx[0] * 16, x1 = (b.cx[1] + 1) * 16 - 1, z0 = CZ0 * 16, z1 = (CZ1 + 1) * 16 - 1;
            const cmd = `execute in minecraft:the_nether run forceload add ${x0} ${z0} ${x1} ${z1}`;
            let receipt;
            try { receipt = await cmdOnce(con, cmd, /Marked|Too many chunks|already force loaded|force loaded/i, 180000); }
            catch (e) { pRec.batches.push({ batch: bi + 1, cx: b.cx, chunks: need, error: String(e).slice(0, 200) }); log(`  ✗ 第 ${bi + 1} 批：${String(e).slice(0, 120)}`); continue; }
            out.commandsIssued.push(cmd);
            if (/Too many chunks/i.test(receipt)) { pRec.batches.push({ batch: bi + 1, cx: b.cx, chunks: need, error: 'FORCELOAD_OVER_256', receipt }); log(`  ✗ 第 ${bi + 1} 批 Too many chunks`); continue; }
            if (/minecraft:overworld/i.test(receipt)) throw new Error(`FORCELOAD_WRONG_DIM：${receipt}`);

            // 逐批落盘（save-all flush 是异步收尾，回执到了再数区块头）
            const saveLine = await cmdOnce(con, 'save-all flush', /Saved the game|Flushing|Saved/i, 300000);
            out.commandsIssued.push('save-all flush');
            const after = countSavedChunks(out.netherRegionDir);
            // forceload query：只读、不改世界，用来留档强制集规模
            let q = null;
            try { q = await cmdOnce(con, `execute in minecraft:the_nether run forceload query ${x0} ${z0} ${x1} ${z1}`, /chunks? (are|is) force loaded|force loaded|no chunks/i, 60000); } catch { /* 只读诊断，拿不到不算失败 */ }
            if (q) out.commandsIssued.push(`forceload query ${x0} ${z0} ${x1} ${z1}`);
            const rec = {
                batch: bi + 1, cx: b.cx, cz: [CZ0, CZ1], chunks: need,
                forceload: receipt.trim(), save: saveLine.trim(), forceloadQuery: q ? q.trim() : null,
                savedAfter: after.saved, savedExpected: EXPECTED, secondsIntoRun: Math.round((Date.now() - t0) / 1000),
            };
            pRec.batches.push(rec);
            log(`  批 ${bi + 1}/${BATCHES.length} cx${b.cx[0]}..${b.cx[1]}（${need} 区块）：${receipt.trim().slice(0, 70)} ⇒ 落盘 ${after.saved}/${EXPECTED}（${rec.secondsIntoRun}s）`);
            if (after.saved >= EXPECTED) { pRec.complete = true; break; }
        }
        const cnt = countSavedChunks(out.netherRegionDir);
        if (cnt.saved >= EXPECTED) { out.status = 'SAVED'; break; }
        if (pRec.stoppedByDeadline) { out.status = 'PARTIAL_DEADLINE'; break; }
        if (pass === PASSES) { out.status = cnt.saved ? 'SAVED_INCOMPLETE' : 'FAILED'; out.coverage = { ...cnt, expected: EXPECTED }; }
        if (pass < PASSES) { out.status = 'RETRY_MISSING'; log(`  ⇒ 第 ${pass} 轮结束，落盘 ${cnt.saved}/${EXPECTED}，缺 ${cnt.missing.length}，再来一轮补`); }
    }

    const finalFlush = await cmdOnce(con, 'save-all flush', /Saved the game|Flushing|Saved/i, 300000);
    out.commandsIssued.push('save-all flush');
    out.finalSave = finalFlush.trim();
    await sleep(4000);
    const live = countSavedChunks(out.netherRegionDir);
    out.coverage = { saved: live.saved, expected: EXPECTED, missing: live.missing.length, missingSample: live.missing.slice(0, 40) };
    await shutdownLaneC(h); h = null;
    out.savedAt = new Date().toISOString();

    fs.rmSync(DEST, { recursive: true, force: true });
    fs.mkdirSync(DEST, { recursive: true });
    for (const item of ['DIM-1', 'DIM1', 'region', 'level.dat', 'level.dat_old']) {
        const src = path.join(out.worldDir, item);
        if (fs.existsSync(src)) fs.cpSync(src, path.join(DEST, item), { recursive: true });
    }
    out.copiedTo = DEST;
    const copied = countSavedChunks(path.join(DEST, 'DIM-1', 'region'));
    out.copiedChunks = copied.saved;
    out.copiedMatchesLive = copied.saved === live.saved;
    log(`  收尾硬闸：live 落盘 ${live.saved}/${EXPECTED}，拷贝后 ${copied.saved}/${EXPECTED}${out.copiedMatchesLive ? '（一致 ✅）' : '（⚠ 不一致）'}`);
} catch (e) {
    out.error = String(e && e.stack ? e.stack : e);
    if (out.status === 'RUNNING') out.status = 'FAILED';
    log(`✗ ${out.status}：${String(e).split('\n')[0]}`);
} finally {
    try { if (h) await shutdownLaneC(h); } catch { /* ignore */ }
    out.seconds = Math.round((Date.now() - Date.parse(out.startedAt)) / 1000);
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
    log(`落盘：${path.relative(process.cwd(), OUT)}（status=${out.status}，${out.seconds}s）`);
}
