// emit_round5c.mjs — MC-ROUND5 §C 线：把 ROUND4 C 线下界三站的**裁决结果**并进主种子 route 草稿
//
// 【按派单 C 节的三条裁决执行】
//   C-1 下界废弃传送门 → **不 emit**（底行 (178,46,149) 是 bedrock，清不掉；缺格里有 1 格
//     crying_obsidian 要钻石镐；下界不能用水浇黑曜石 ⇒ 4 块黑曜石是净物资成本）。
//     不 emit 的理由写进 route 的 `notEmitted` 区（审阅时能看到，不必翻报告）。
//   C-2 堡垒（treasure 型）→ **并入既有 S3_bastion 站的 scout**（不是新站：派单原话"并入 S3 站的 scout"），
//     并把"挖金块会激怒 16 格内猪灵"写进该站 notes（F 线 B5 直接看得到）。
//   C-3 下界要塞（刷怪笼 1 个，派单判为**接受**）→ **新增一站** C3_fortress_spawner，
//     站级数据按 SCHEMA §1 粗化（center 对齐 8 格网格、radius ≥16），精确坐标只进 scout。
//     站位数据取 ROUND5 补测（ROUND4 那份 52/124 未解析、站位数不可信）。
//
// 【硬约束（脚本自己守）】
//   1. **绝不写 `frozenAt` / `sha256File`**：输入里若已非 null 直接拒绝运行。
//   2. C-3 的站位补测没有 OK（`fortress_standing.round5c.json` 缺失或 status != OK）→ **拒绝 emit**，
//      因为 route 的 scout 一旦写了 UNRESOLVED 的站位数，编排器会当成"0 个站位"用。
//   3. 幂等：重复运行结果一致（按 station id 去重覆盖，不追加重复项）。
//   4. 只写 `<seed>.json` + 一份变更台账，**不碰**其它种子、不碰 probe 原始数据。
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\emit_round5c.mjs [--seed 4926685115947721762]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { argOf, log } from '../../stages/_lib/runner_core.mjs';
import { ROUTE_DIR } from './console.mjs';

const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const ROUTE_PATH = path.join(ROUTE_DIR, `${SEED}.json`);
const LEDGER_PATH = path.join(PROBE_DIR, 'route_emit.round5c.json');

const readJson = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const r4 = {
    nether_portal: readJson(path.join(PROBE_DIR, 'nether_portal.round4c.json')),
    bastion: readJson(path.join(PROBE_DIR, 'bastion.round4c.json')),
    fortress: readJson(path.join(PROBE_DIR, 'fortress.round4c.json')),
};
const standingPath = path.join(PROBE_DIR, 'fortress_standing.round5c.json');
const standing = fs.existsSync(standingPath) ? readJson(standingPath) : null;

// ---------------------------------------------------------------- 硬约束
const route = readJson(ROUTE_PATH);
if (route.seed !== SEED) throw new Error(`种子不符：route.seed=${route.seed} ≠ ${SEED}`);
if (route.frozenAt !== null) throw new Error(`REFUSE_FROZEN：${SEED}.json 的 frozenAt 已是 ${route.frozenAt} —— 冻结后的文件禁止改写（SCHEMA §4：再改要升版本号）`);
if (!standing || standing.status !== 'OK') {
    throw new Error(`STANDING_NOT_OK：C-3 站位补测没有通过（${standing ? standing.status : '文件缺失'}）——`
        + ' 站位数不可信时不允许 emit（否则编排器会把"没读到"当"0 个站位"用）');
}
if (standing.gates?.exhaustive?.ok !== true || standing.gates?.perCell?.ok !== true || standing.gates?.centerTruth?.ok !== true) {
    throw new Error(`STANDING_GATES_FAILED：站位补测的闸门没过（${JSON.stringify(standing.gates)}）`);
}

const changes = [];
const note = (kind, what, detail) => changes.push({ kind, what, detail });

const at = (p) => (p ? [p.x, p.y, p.z] : null);
/** 点对象的坐标（⚠ 不能用 `{...at(p)}`：数组展开会变成键 "0"/"1"/"2"，本单踩过）。 */
const pt = (p) => (p ? { x: p.x, y: p.y, z: p.z } : null);

// ================================================================== C-2：并入 S3_bastion 的 scout
const ba = r4.bastion;
const s3 = route.stations.find((s) => s.id === 'S3_bastion');
if (!s3) throw new Error('找不到 S3_bastion 站，派单要求"并入 S3 站的 scout"');
// 幂等：重跑时**重算覆盖**已有的 C-2 corroboration（而不是拒绝重入）——
// 因为裁决可能在本单中途变化（站级中心迁移、口径更正…），覆盖才能让 route 跟上裁决。
// ⚠ 同时要把 notes 里**上一轮追加的尾巴剥掉**，否则重跑会叠加（notes 是纯文本，没有结构可覆盖）。
const stripRound5 = (s) => (s.includes('｜ROUND5') ? s.split('｜ROUND5')[0] : s);
if (s3.scout.corroboration) { delete s3.scout.corroboration; note('C2', '重跑：清掉上一次的 S3_bastion.scout.corroboration，准备重算', null); }
s3.scout.notes = stripRound5(s3.scout.notes);
delete s3.scout.centerMigration;
const C2_WARN = '⚠ 挖金块/鎏金黑石/开箱会**激怒 16 格内的猪灵 30s**（研究线字节码：这三类方块都在 `guarded_by_piglins` 标签内；'
    + '金甲才是仇恨来源，30 格内）；进堡垒前先决定打法（远程取金 or 硬吃伤害）。';
s3.scout.corroboration = {
    source: 'bench/route/probe/bastion.round4c.json',
    at: ba.startedAt,
    method: 'fill-replace + 八叉下钻（服务器权威，每盒地形对照 + fill 回执严格 FIFO 配对）',
    seconds: ba.seconds,
    status: ba.status,
    region: { center: ba.region?.center ?? null, box: ba.region?.box ?? null },
    counts: {
        gold_block: ba.bastionType?.goldBlock ?? 0,
        gilded_blackstone: ba.bastionType?.gildedBlackstone ?? 0,
        chest: ba.bastionType?.chest ?? 0,
        trapped_chest: ba.bastionType?.trappedChest ?? 0,
        obsidian: ba.bastionType?.obsidian ?? 0,
        crying_obsidian: ba.bastionType?.cryingObsidian ?? 0,
    },
    typeJudgment: {
        treasure: '有金块 → 是',
        hoglinStables: `菌光体密集（crimson ${ba.bastionType?.crimsonFungus ?? 0} + warped ${ba.bastionType?.warpedFungus ?? 0}）`,
        unresolved: 'housing 与 bridge 靠形状（面积/走廊比）区分，本单只给方块计数 ⇒ 两型标 UNRESOLVED（不影响 B5：treasure 已定）',
    },
    goldBlockPoints: (ba.goldBlockPoints ?? []).map(at).filter(Boolean),
    chestPoints: (ba.chestPoints ?? []).map(at).filter(Boolean),
    terrainControl: ba.scan?.terrain ?? {},
    selfCheck: ba.scan?.selfCheck?.['minecraft:gold_block'] ?? null,
    hoglinAggression: C2_WARN,
    areaNote: `⚠ 本次复核的区域中心 ${JSON.stringify(ba.region?.center)} 与 S3_bastion 站级中心 ${JSON.stringify(s3.station.center)} `
        + '**不是同一片**（相距约 55 格）。站级数据（运行区）本单**不动** —— 路线到底去哪一片由设计会话在冻结前裁决；'
        + '精确坐标按 SCHEMA §1 只留在 scout 区。',
};
s3.scout.notes = `${s3.scout.notes}｜ROUND5 并入 C-2：同片区域经服务器权威复核 —— 金块 ${ba.bastionType?.goldBlock} / 鎏金黑石 ${ba.bastionType?.gildedBlackstone} / 箱 ${ba.bastionType?.chest}，treasure 型；精确坐标见 \`corroboration\`。${C2_WARN}`;
note('C2', 'S3_bastion.scout.corroboration', { region: ba.region?.center ?? null, counts: s3.scout.corroboration.counts });

// ================================================================== C-3：新增站（刷怪笼 + ROUND5 补测的站位）
const fo = r4.fortress;
const sp = fo.spawners[0];
if (!sp) throw new Error('ROUND4 的 fortress 取证里没有刷怪笼坐标，拒绝 emit');
const st = standing.stands;
const C3 = {
    id: 'C3_fortress_spawner',
    seq: 6,                                      // 初始占位：语义上在 S3_bastion 之后、S5 之前；下面统一重排
    kind: 'fortress_spawner',
    dim: 'the_nether',
    station: {
        // SCHEMA §1：center 加载器会对齐 8 格网格、半径不小于 16 —— 这里直接给 8 格对齐值
        center: [Math.round(sp.x / 8) * 8, Math.round(sp.z / 8) * 8],
        yHint: 'nether_mid',
        radius: 32,
        lookFor: ['spawner'],
    },
    scout: {
        points: [{ what: 'spawner', ...pt(sp) }],
        pointsTotal: fo.spawnerCount,
        pointsTruncated: false,
        verify: {
            status: 'REAL',
            method: 'fill-replace + 八叉下钻（服务器权威）+ 穷举逐格（ROUND5 补测）',
            counts: { ...fo.scan.counts },
            terrain: { ...fo.scan.terrain },
            at: standing.finishedAt ?? new Date().toISOString(),
            evidence: 'bench/route/probe/fortress.round4c.json（数量/区域） + bench/route/probe/fortress_standing.round5c.json（站位）',
            blazeSpawners: { found: fo.spawnerCount, required: 2, sufficient: false, acceptedBy: 'MC-ROUND5 §C（1 个笼刷 8 根烈焰棒是常规打法，冗余记为风险）' },
        },
        cover: {
            criterion: standing.criterion,
            criterionRadius: st.criterionRadius,
            truthRadius: st.truthRadius,
            probeCells: standing.cellTruth.cells,
            unknown: standing.cellTruth.unknown,
            restoreFails: standing.cellTruth.restoreFails,
            coverStands: st.coverStands,                                  // 主口径：身体/头 == air（与 ROUND4 判据逐字一致）
            airLike: {                                                    // 口径 B：这台 1.16.1 还认的空气名也算空气
                airNames: st.airNamesSeen ?? null,
                coverStands: st.coverStandsAirLike,
                diff: st['air口径差'] ?? null,
                multiHitCells: standing.cellTruth.multiHitCells,
            },
            coverStandsRound4Set: st.coverStandsRound4Set,              // 同判据、ROUND4 白名单（口径对照）
            openFloors: st.openFloors,                                  // 诊断：有地可站（无墙约束）
            stands: st.stands,                                          // 精确坐标（scout 区，允许）
            solidRation: st.solidRation,
            gates: {
                exhaustive: standing.gates.exhaustive,
                perCell: standing.gates.perCell,
                centerTruth: standing.gates.centerTruth?.ok ?? null,
                probeRestored: standing.gates.probeRestored ?? null,
                worldDrift: standing.worldRecheck?.drift ?? null,
            },
        },
        notes: '烈焰棒：距要塞对应点 (163,151) 最近的下界要塞，1 个刷怪笼（14379 块下界砖 + 55779 块黑石证明扫的是要塞）。'
            + '**编排器处理（设计会话裁决）**：1 笼按**尽力而为**——只有"找不到要塞/到达确认失败"才切 fallback 到 S4，'
            + '**掉落少不是重试理由**（勿重试到超时）。'
            + `｜站位（ROUND5 穷举补测，取名半径 ±${st.truthRadius}、判据半径 ±${st.criterionRadius}，`
            + '**已裁决只测 ±2、不扩大**）：'
            + `可挡火球站位 **${st.coverStands}** 个`
            + `（另有"把 ${JSON.stringify(st.airNamesSeen)} 也算空气"的口径：${st.coverStandsAirLike} 个）`
            + (st.coverStandsRound4Set !== st.coverStands
                ? `｜同判据但用 ROUND4 的 SOLID 白名单是 ${st.coverStandsRound4Set} 个 —— 白名单漏了 nether_brick_stairs/wall 等要塞最常见结构件`
                : '｜同判据换 ROUND4 的 SOLID 白名单结果相同（本片站位的脚下与墙都是 nether_bricks，两套白名单都认）')
            + `｜有地可站（无墙约束）${st.openFloors} 个｜逐格 ${standing.cellTruth.cells} 格全部解析（未解析 0）｜`
            + `同盒附带：1 格 \`nether_quartz_ore\` @ (224,72,-82)（下界石英，路线可用）｜`
            + `📌 **口径更正（设计会话 2026-10-02 夜）**：这 7³ 盒里有 6 格 \`cave_air\`（y=73 上方空腔）。`
            + 'cave_air/void_air 是 **1.13 起就有的方块**，1.16.1 本来就有它们；'
            + `minecraft-data 3.114 的 pc/1.16.1 清单是正确的（它同时含 cave_air/void_air、且不含 1.17 才有的 smooth_basalt，\`block_palette_1161.validated.json\` 754/754 全被服务器接受）。`
            + '我上一版报告把版本读反了、并据此怀疑"这台 jar 不是 1.16.1"——**该怀疑作废**。'
            + `本片两套空气口径（只认 air / 把 ${JSON.stringify(st.airNamesSeen)} 都算空气）结果相同：${st.coverStands} 个。`,
    },
    fallback: ['S4_fortress_spawner'],
};
// ================================================================== 插入 C-3 新站（先插入，后面才重排/分角色）
route.stations = route.stations.filter((s) => s.id !== C3.id);
route.stations.push(C3);
// ⚠ 坐标键形自检：数组展开会写成 {"0":x,"1":y,"2":z}（本单踩过：编排器读不到 x/y/z，且看不出是错）
for (const p of C3.scout.points) {
    if (p.x === undefined || p.y === undefined || p.z === undefined) {
        throw new Error(`POINT_SHAPE_BAD：${C3.id} 的 point 缺 x/y/z：${JSON.stringify(p)}`);
    }
}
note('C3', '新增站 C3_fortress_spawner', {
    center: C3.station.center, radius: C3.station.radius,
    spawner: at(sp), coverStands: st.coverStands, openFloors: st.openFloors,
});

// ================================================================== 裁决 2：S3 站级中心迁到 C-2 实测片（前置：cubiomes 证明两片是同一个堡垒）
// 设计会话原话：「S3 站级中心移到 C-2 实测片（loader 对齐后约 [336,256]），radius 保持 32；
//   /locate 的 [288,240] 留在 scout 作参照。**前提：先确认两者是同一个堡垒**……不是同一个就停下报告。」
// 前提已用**离线 cubiomes**核完（零开服）：这一带过了 RNG 门�� Bastion 起点共 5 个，
//   唯一能同时圈住两点的那个是 (336,256)（距离 50.6 / 0.7 格），其余 4 个都在 300+ 格外。
//   证据工具 `bench/route/tools/same_bastion_check.mjs`（零开服，可复跑）。
// ⚠ 336 % 8 = 0、256 % 8 = 0 —— 已满足 route_guard.mjs:49 的"center 必须 8 格对齐"硬闸门。
{
    const c2center = s3.scout.corroboration?.region?.center ?? [335.5, 255.5];
    const aligned = [Math.round(c2center[0] / 8) * 8, Math.round(c2center[1] / 8) * 8];
    const from = [...s3.station.center];
    s3.station.center = aligned;
    s3.station.radius = 32;
    s3.scout.centerMigration = {
        at: new Date().toISOString(),
        decidedBy: '设计会话 2026-10-02 夜复核指令 2',
        from: { center: from, source: '服务器 /locate bastion（ROUTE-02 站级数据）' },
        to: { center: aligned, source: 'C-2 逐格复核实测片中心（loader 8 格对齐）' },
        measuredAreaCenter: c2center,
        sameStructureEvidence: {
            method: '离线 cubiomes（本移植的 Bastion RNG 起点枚举，getRegPos）',
            tool: 'bench/route/tools/same_bastion_check.mjs',
            result: '这一带 5 个过了 RNG 门的 Bastion 起点，**唯一**能同时圈住 (288,240) 与 (335.5,255.5) 的是 (336,256)；其余 4 个均在 300+ 格外',
            distanceToFrom: 50.6, distanceToTo: 0.7, footprintThreshold: 96,
            caveat: 'cubiomes 给的是**起点坐标**不是足迹边界 ⇒ "圈内"是必要条件；配合两片计数一致（金块 22 / 鎏金黑石 227 / 箱 5），判为同一堡垒',
            notVerified: '未做"两片之间连续堡垒方块"的服务器侧确认（设计会话给的判据是"或"关系，cubiomes 那条已满足）',
        },
        locateKeptAsReference: `${from} —— 服务器 /locate bastion 的原始结果，保留在 scout 作参照，不再作为站级中心`,
    };
    s3.scout.notes = `${s3.scout.notes}｜ROUND5 复核：站级中心由 /locate 的 [${from}] 迁到 C-2 实测片（对齐后 [${aligned}]，radius 32）；`
        + `前置已用离线 cubiomes 证明两者是同一个堡垒（${aligned} 附近的唯一起点；见 scout.centerMigration）`;
    note('C3-裁决2', 'S3_bastion 站级中心迁到 C-2 实测片（cubiomes 已证同一堡垒）', { from, to: aligned, radius: 32 });
}

// ================================================================== 裁决 3：S0_sheep
// 设计会话原话：「冻结前不允许 center=[0,0]（编排器会把 bot 导到 340 格外）。
//   请用两个 fresh world 在出生点周边几个盒子里数羊……两次一致 → 填真实中心，标 REAL；
//   不一致 → 用离线 cubiomes 找出生点到 S1 路上最近的草原或平原片作中心，保持 UNVERIFIED。」
//
// **实测结果（bench/route/probe/sheep.round5c.json，status=ZERO_ALL_DIFFICULTIES）**：
//   两个 fresh world（模板默认 Peaceful / 显式 `difficulty easy`）里，羊/牛/猪/鸡**全部为 0**；
//   地形对照正常（stone 79478 / grass_block 3125 / water 48782）、六个盒区块全部就绪、实体计数回执已探明。
//   ⇒ **不标 REAL**（"两个 0"不能互相印证，也没有数到任何一只）。
//   ⇒ **也不下"实跑没有羊"的结论**：本次实验**全程无玩家在线**，forceload 区块属 onlyInBorder
//      （1.16.1 不对 onlyInBorder 区块跑生物刷怪），所以"peaceful 不刷"与"无玩家不刷"两个解释分不开。
//      要分开必须补"玩家在线"的对照 —— 那是另一个尺度的实验，本单不擅自扩大范围。
//
// **因此按派单 fallback 执行**：center 填**出生点**（不是数羊数出来的，是 SEED-01 `top_ranked.csv` 的
// `spawn_biome=plains` = 出生点本身就是平原；且距 S1 门 89 格、顺路），**保持 UNVERIFIED**。
// ⚠ R6-4 复核后本块整体改写（见下）：羊群实测存在 ⇒ status REAL、center 改指羊群、本站改 fallback-only。
{
    const shAB = readJson(path.join(PROBE_DIR, 'sheep_ab.round6c.json'), null);
    const survey = readJson(path.join(PROBE_DIR, 'bed_village_survey.round6c.json'), null);
    const align8 = (v) => Math.round(v / 8) * 8;
    const s0 = route.stations.find((s) => s.id === 'S0_sheep');
    if (!s0) throw new Error('找不到 S0_sheep 站');
    const from = [...s0.station.center];
    s0.scout.notes = stripRound5(s0.scout.notes);
    delete s0.scout.sheepAbsence;
    delete s0.scout.centerChoice;

    // ---- 裁决 2（10-02 夜）：S0_sheep 改 fallback-only（作 S0b 的 fallback）、center 改指最近的羊群
    const CTRL = { x: 516, z: 224 };                                  // R6-3 的 summon 对照区，排除
    const flocks = (survey?.sheep?.flocks ?? []).filter((f) => Math.hypot(f.center[0] - CTRL.x, f.center[1] - CTRL.z) >= 40);
    const nearest = flocks.slice().sort((a, b) => a.distToSpawn - b.distToSpawn)[0];
    // ⚠ 自然羊只数必须**排除 summon 对照群**：survey.sheep.total 是含那 3 只的（11），自然生成是 8。
    const naturalTotal = flocks.reduce((s, f) => s + f.size, 0);
    const sheepCenter = nearest ? [align8(nearest.center[0]), align8(nearest.center[1])] : [216, 224];

    s0.station.center = sheepCenter;
    s0.routeRole = 'fallback-only';
    s0.seqNote = '正常流程不去这一站（只作 S0b_village_beds 的 fallback）：最近的羊群在出生点 194 格外，比村庄远得多';
    s0.fallback = [];
    s0.scout.points = nearest ? nearest.members.map((p) => ({ what: 'sheep', x: p[0], y: p[1], z: p[2] })) : [];
    s0.scout.pointsTotal = nearest?.members.length ?? 0;
    s0.scout.pointsTruncated = false;
    s0.scout.verify.status = nearest ? 'REAL' : 'UNVERIFIED';
    s0.scout.verify.reason = nearest
        ? `羊群实测存在：出生点 ±384 格内**自然生成**羊 ${naturalTotal} 只 / ${flocks.length} 群（已排除 R6-3 的 summon 对照群 3 只；普查 raw total=${survey.sheep.total} 含那 3 只），最近一群 @(${nearest.center}) ${nearest.size} 只，`
          + `距出生点 ${nearest.distToSpawn} 格、距 S1 门 ${nearest.distToS1} 格。`
          + '⚠ **措辞限定：出生点 ±128 格（16×16 区块）内没有自然羊** —— 两个 fresh world 均为 0'
          + '（bench/route/probe/sheep_ab.round6c.json）。本种子**并非"没有羊"**，羊只是全落在该采样区之外。'
          + '⚠ 证据强度：存在性有直接证据（存档里读到的精确坐标）；**"由种子决定"的双 world 坐标比对未做**（R6-4 只生成过一个世界）。'
        : '未取得羊群坐标（普查数据缺失）⇒ 保持 UNVERIFIED';
    s0.scout.verify.evidence = 'bench/route/probe/bed_village_survey.round6c.json（±384 格普查）+ bench/route/probe/sheep_ab.round6c.json（±128 格双 fresh world）';
    s0.scout.sheepSurvey = {
        at: new Date().toISOString(), decidedBy: '设计会话 2026-10-02 夜复核指令 2',
        within128: 0, within384Raw: survey?.sheep?.total ?? null, within384Natural: naturalTotal,
        flocks: flocks.map((f) => ({ center: f.center, size: f.size, distToSpawn: f.distToSpawn, distToS1: f.distToS1 })),
        wording: '**措辞限定**：出生点 ±128 格内无自然羊（≠ 本种子无羊）',
        evidenceStrength: '存在性：直接证据（存档读到的精确坐标）。可复现性（由种子决定）：**缺第二个 world 的坐标比对**。',
    };
    s0.scout.centerChoice = {
        at: new Date().toISOString(), decidedBy: '设计会话 2026-10-02 夜复核指令 2',
        from, to: sheepCenter,
        basis: nearest ? `最近的自然羊群 @(${nearest.center})（${nearest.size} 只，距出生点 ${nearest.distToSpawn}、距 S1 门 ${nearest.distToS1}）` : '普查未找到羊群，退回出生点对齐值',
        caveat: '羊群中心与实际羊坐标有最多 24 格的散布（聚类阈值），到达确认仍靠 `lookFor:["sheep"]` 在 radius 内自己找',
    };
    s0.scout.notes += `｜R6-4 复核：状态 ${s0.scout.verify.status}（羊群实测存在，最近一群 @(${nearest?.center ?? '?'}）${nearest?.size ?? 0} 只），`
        + `center 由 [${from}] 改指羊群 [${sheepCenter}]；**本站改 fallback-only**，正常流程不去，只作 S0b_village_beds 的 fallback。`
        + '⚠ 措辞限定：**出生点 ±128 格内无自然羊**，不等于本种子无羊。';
    note('R6-4', 'S0_sheep：改 fallback-only（S0b 的 fallback）、center 改指最近羊群、措辞限定为"±128 格内无羊"', { from, to: sheepCenter });
}

// ================================================================== 裁决 1：yHint 逐站对照 scout 实测高度（SCHEMA v1.1）
// 设计会话原话：「`yHint` 必须和 scout 实测高度一致：结构在地下（例如洞穴里的废墟门）就写 `underground`，
//   不能因为"从地表走过去"写 `surface`。全 9 站逐站对照 scout 实测高度核一遍，列表放进审阅清单。」
//
// **口径要先说清**（本单第一版就混淆过）：scout 里两种"高度"不是一回事 ——
//   ① `points[].y`  = **逐格实测命中点**的 y（精确，最可信）
//   ② `points[].box.y1..y2` = **扫描盒**的 y 范围（是扫描窗口，不是命中物的高度）
// 下面每一站都标了用的是哪一种，避免"用扫描盒冒充实测高度"。
{
    // ⚠ 口径：`hit_box` 的点**同时带 `y`（盒的起始 y）和 `box`** —— 必须**优先读 box**，
    //   否则会把"扫描窗口"当成"实测高度"（本单第一版就把 S0_gravel 的 box 56..71 读成实测 56，错改成 underground）。
    const yOf = (s) => {
        const all = s.scout.points ?? [];
        const boxes = all.filter((p) => p.box).map((p) => p.box);
        if (boxes.length) return { kind: 'hit_box', lo: Math.min(...boxes.map((b) => b.y1)), hi: Math.max(...boxes.map((b) => b.y2)), n: boxes.length };
        const pts = all.filter((p) => Number.isInteger(p.y));
        if (pts.length) return { kind: 'point', lo: Math.min(...pts.map((p) => p.y)), hi: Math.max(...pts.map((p) => p.y)), n: pts.length };
        return null;
    };
    // 判据：主世界 —— 实测最高点在 y≥64 视为地表，y<64 视为地下；下界一律 nether_mid（该档无精确范围定义）
    const expect = (s, y) => {
        if (s.dim === 'the_nether') return 'nether_mid';
        if (!y) return null;
        return y.hi >= 64 ? 'surface' : 'underground';
    };
    // 基线 = ROUTE-02 首单提交（bench `bab33d3`）里的 yHint。
    // ⚠ 不用"改前"（= 上一轮 emit 的结果）当基线：emit 是幂等重算的，重跑会让"改前"变成上一次的结果，审阅会被误导。
    const YHINT_BASELINE = {
        S0_iron: 'underground', S0_gravel: 'surface', S0_sheep: 'surface',
        S1_portal: 'surface', S1b_lava_pool: 'underground',
        S3_bastion: 'nether_mid', S4_fortress_spawner: 'nether_mid',
        C3_fortress_spawner: 'nether_mid', S5_stronghold_room: 'underground',
    };
    const rows = [];
    let fixed = 0;
    for (const s of route.stations) {
        const y = yOf(s);
        const want = expect(s, y);
        const baseline = YHINT_BASELINE[s.id] ?? null;
        if (want) s.station.yHint = want;
        if (baseline && want && baseline !== want) fixed++;
        rows.push({
            id: s.id, dim: s.dim, yHintBaseline: baseline, yHint: s.station.yHint,
            changed: baseline ? (want !== baseline) : false,
            measuredY: y ? `${y.lo}..${y.hi}` : null,
            ySource: y ? (y.kind === 'point'
                ? `scout.points[].y（${y.n} 个精确命中点）`
                : `scout.points[].box.y1..y2（${y.n} 个扫描盒；是扫描窗口不是命中高度）`) : '无（UNVERIFIED 站）',
        });
    }
    route.yHintAudit = {
        at: new Date().toISOString(), decidedBy: '设计会话 2026-10-02 夜复核指令 1（SCHEMA v1.1）',
        rule: 'yHint 必须和 scout 实测高度一致：结构在地下就写 underground，不能因为"从地表走过去"写 surface',
        caveats: [
            '**扫描盒 ≠ 实测高度**：只有 `points[].y`（逐格下钻命中）才算实测；`box.y1..y2` 是扫描窗口，'
            + '本单对这类站（iron/gravel/bastion/lava_pool）标了口径，审阅时别当成"东西就在这个高度"。',
            '`nether_mid` 在 SCHEMA v1.1 里**没有给出精确 y 范围**，本单按"下界一律 nether_mid"处理，'
            + '并把实测 y 单列出来供审阅；若要改成更细的分档（例如上/中/下），需要设计会话先定义。',
            '`S0_sheep` 是 UNVERIFIED、没有任何实测高度，yHint 维持 surface（按"被动生物在地面"的常识保守填），不算"已核"。',
        ],
        rows, changedCount: fixed,
    };
    note('C3-yHint', `yHint 逐站对照 scout 实测高度（SCHEMA v1.1）：改了 ${fixed} 站（基线 = 首单提交 bab33d3）`, rows.filter((r) => r.changed).map((r) => `${r.id} ${r.yHintBaseline}→${r.yHint}`));
}

// ================================================================== 裁决 1：S3 scout 并入 F 线的猪灵实测（设计会话指令 4）
// 证据：docs/MC-S2-01.md §4.5「peaceful 下堡垒站有猪灵（28 头，服务端与客户端一致）」
// ⚠ 这条数据对本线的价值超出 S3：**它证明 1.16.1 的"区块生成期初始 mobs"不受 peaceful 抑制**
//   （猪灵不是敌对类别刷怪）。而我此前在 S0_sheep 上写"实跑是 peaceful ⇒ 羊不会自然生成"——
//   **那个推理不成立**（详见报告 §5.3 的更正）：羊数不到更可能是采样太小 + 计数通道未做阳性对照。
{
    const s3 = route.stations.find((s) => s.id === 'S3_bastion');
    s3.scout.piglinPopulation = {
        at: new Date().toISOString(),
        source: 'docs/MC-S2-01.md §4.5（开发线 F · MC-S2-01 实测）',
        method: '服务端权威：`kill @e[type=piglin]` 回执（`Killed N entities`）；客户端可见数与之比对',
        peaceful: 28, easy: '57–64（B1 局同位置的 kill 回执 Killed 16 / Killed 59）',
        agree: 'peaceful 局服务端 28 = 客户端 28（一致）',
        spread: '分散在结构内外：平台落位时最近的一头 10.7–20 格，落到自然地面后最近 0.5–4.4 格',
        implication: [
            '**1.16.1 猪灵不受 peaceful 抑制**（不是敌对类别刷怪）⇒ S2 易物段不需要为猪灵改难度。',
            '主种子堡垒站加载区里只有 28–60 头猪灵 ⇒ N=6 的槽位在"一个站位周围"未必凑得齐，换人/拉黑逻辑是必需的。',
            '⚠ **这条不能反推羊**：猪灵与羊的 MobCategory 不同（前者非被动），'
            + '"初始 mobs 不受 peaceful 抑制"对羊是否成立要单独实测 —— 见 S0_sheep 的实测与更正。',
        ],
    };
    s3.scout.notes = `${s3.scout.notes}｜F 线实测并入：本片加载区 peaceful 下 28 头猪灵（easy 57–64），`
        + '分散在结构内外 ⇒ 易物槽位需换人/拉黑逻辑（证据 docs/MC-S2-01.md §4.5）';
    note('C3-piglin', 'S3_bastion.scout 并入 F 线猪灵实测（peaceful 28 头）', { peaceful: 28 });
}

// ================================================================== R6-4 裁决：并入 S0b_village_beds
// 设计会话裁决（10-02 夜）：「S0b_village_beds 并入 route，正常流程中排在 S1_portal 之前，
//   center [120,312]、radius 32、lookFor 用草稿里的」+「村庄箱子暂不成站（存档里读不出箱子内容），
//   只在 S0b 的 scout notes 里记"箱 13、干草 45"」。
// 草稿来源 bench/route/probe/village_beds.station.draft.json；普查数据 bed_village_survey.round6c.json。
{
    const survey = readJson(path.join(PROBE_DIR, 'bed_village_survey.round6c.json'), null);
    const draft = readJson(path.join(PROBE_DIR, 'village_beds.station.draft.json'), null);
    if (!survey || !draft) throw new Error('S0b 并入需要 bed_village_survey.round6c.json 与 village_beds.station.draft.json');
    const picked = survey.villages.find((v) => v.center[0] === draft.station.station.center[0] + 1)
        ?? survey.villages.slice().sort((a, b) => a.distToS1 - b.distToS1)[0];
    route.stations = route.stations.filter((s) => s.id !== 'S0b_village_beds');
    route.stations.push({
        id: draft.station.id,
        seq: 3,                                      // 排在 S1_portal(原 seq 4) 之前；下面统一重排
        kind: 'village_beds',
        dim: 'overworld',
        station: { ...draft.station.station },                  // center [120,312]、radius 32、lookFor
        scout: {
            ...draft.scout,
            points: picked.bedsDetail.map((b) => ({ what: b.name, x: b.pos[0], y: b.pos[1], z: b.pos[2] })),
            supply: draft.scout.supply,
            notes: `床：末影龙要 4 张床做末影之眼。**该村 ${picked.bedCount} 张床全部可达、不需挖墙**（`
                + `地板 + 净空 + ≥1 可站邻格，三条全满足；全在 sectionY=4 地表同层，1.16.1 的羊不会跳上方块这一层很关键），`
                + `到 S1 门 ${picked.distToS1} 格、到出生点 ${picked.distToSpawn} 格（在去 S1 的顺路上）。`
                + `📌 **食物线索**：本区干草块 ${survey.supply.hay_block} · 箱子 ${survey.supply.chest}（陷阱箱 ${survey.supply.trapped_chest}）。`
                + '⚠ 箱子**暂不成站**（箱子内容只有开箱时才生成，存档里读不出），故只记数。'
                + '⚠ 精确坐标只在 scout 区，不得进 prompt / 模型记忆 / MISSION。',
            _draft: undefined,
        },
        fallback: ['S0_sheep'],                                  // 主站拿不到时，S0_sheep 仍是备选
    });
    note('R6-4', '并入 S0b_village_beds（正常流程排在 S1_portal 之前；fallback = S0_sheep）', {
        beds: picked.bedCount, reachable: picked.reachableBeds, distToS1: picked.distToS1,
        center: draft.station.station.center,
    });
}

// ================================================================== 裁决 1：C3 为主站；fallback 站不进正常站序
// 设计会话原话：「C3 为主站；S4 不进正常站序，只作 C3 的 fallback（同时确认编排器对
//   S1b_lava_pool 这类 fallback 站的处理一致：正常流程不去）。」
// ⚠ route_guard.mjs:57-58 要求 **seq 必须是 1 起不重复的连续整数**，
//   而 seq 连续 ⇒ 无法"用空隙"表达"不在正常流程"。所以用**显式字段**表达，并把 fallback 站排到数组末尾：
//     `routeRole: "fallback-only"` + 顶层 `normalFlowStations` / `fallbackOnlyStations`。
//   这两个字段是**新增契约**（建议设计会话写进 SCHEMA），编排器按 normalFlowStations 走。
{
    const FALLBACK_ONLY = new Set(['S1b_lava_pool', 'S4_fortress_spawner', 'S0_sheep']);
    for (const s of route.stations) {
        if (FALLBACK_ONLY.has(s.id)) {
            s.routeRole = 'fallback-only';
            s.seqNote = '正常流程不去这一站；只在前一站的 fallback 触发时使用';
        } else {
            delete s.routeRole;
        }
    }
    // 数组重排：正常站在前（按既有 seq），fallback 站在后
    // ⚠ 排序键必须容忍 `seq: null`（C3 刚构造出来还没编号）——`null - 1 === -1` 会把它甩到 seq 1。
    const seqKey = (s) => (Number.isInteger(s.seq) ? s.seq : 999);
    route.stations.sort((a, b) => {
        const fa = FALLBACK_ONLY.has(a.id) ? 1 : 0, fb = FALLBACK_ONLY.has(b.id) ? 1 : 0;
        return fa !== fb ? fa - fb : seqKey(a) - seqKey(b);
    });
    route.stations.forEach((s, i) => { s.seq = i + 1; });
    // 路线语义断言：正常流程的相对顺序必须是"铁 → 沙砾 → 羊 → 地狱门 → 堡垒 → 要塞 → 末地门室"。
    // （踩过的坑：seq 为 null 时排序把它甩到 seq 1，靠断言防复发。）
    {
        // ⚠ R6-4 后：S0b_village_beds 进正常流程且排在 S1_portal **之前**；S0_sheep 变 fallback-only。
    const EXPECT = ['S0_iron', 'S0_gravel', 'S0b_village_beds', 'S1_portal', 'S3_bastion', 'C3_fortress_spawner', 'S5_stronghold_room'];
        const got = route.stations.filter((s) => s.routeRole !== 'fallback-only').map((s) => s.id);
        if (JSON.stringify(got) !== JSON.stringify(EXPECT)) {
            throw new Error(`NORMAL_FLOW_ORDER_WRONG：正常流程站序应为 ${JSON.stringify(EXPECT)}，实得 ${JSON.stringify(got)}`);
        }
    }
    route.normalFlowStations = route.stations.filter((s) => s.routeRole !== 'fallback-only').map((s) => s.id);
    route.fallbackOnlyStations = route.stations.filter((s) => s.routeRole === 'fallback-only').map((s) => ({
        id: s.id, seq: s.seq, fallbackOf: route.stations.filter((t) => (t.fallback ?? []).includes(s.id)).map((t) => t.id),
    }));
    route.orchestratorContract = {
        decidedBy: '设计会话 2026-10-02 夜复核指令 1 / 4',
        normalFlow: '按 `normalFlowStations` 的 seq 顺序执行；**不要**遍历整个 `stations` 数组',
        fallback: '仅在主站失败时按该站 `fallback` 数组切换；`fallbackOnlyStations` 里的站正常流程不去',
        insufficientSpawners: 'C-3 只有 1 个刷怪笼：编排器**按尽力而为处理**——只有"找不到要塞/到达确认失败"才切 fallback，'
            + '**掉落少不是重试理由**（勿重试到超时）',
        newFields: '`routeRole` / `normalFlowStations` / `fallbackOnlyStations` / `orchestratorContract` 是本轮新增字段，'
            + '建议由设计会话写进 bench/route/SCHEMA.md（只有设计会话能改规范）',
    };
    note('C3-裁决1', 'C3 为主站；S4 与 S1b_lava_pool 标 fallback-only 并排到末尾', {
        normalFlow: route.normalFlowStations, fallbackOnly: route.fallbackOnlyStations,
    });
}

// ================================================================== C-1：明确不 emit
const np = r4.nether_portal;
const f = np.frame;
route.notEmitted = (route.notEmitted ?? []).filter((x) => x.id !== 'C1_nether_portal');   // 幂等：先删后建
{
    route.notEmitted.push({
        id: 'C1_nether_portal',
        kind: 'nether_portal',
        dim: 'the_nether',
        decision: 'NOT_EMITTED',
        decidedBy: 'MC-ROUND5 §C 派单 C-1（设计会话裁决）+ 复核更正',
        at: new Date().toISOString(),
        // ⚠ 更正（2026-10-02 夜，设计会话指出）：初版理由第 2 条写"缺格含 crying_obsidian，
        //   1.16 挖它要钻石镐" —— **错了**。crying_obsidian 非钻石镐也能挖掉（铁镐 41.7s，只是不掉落），
        //   且研究线已撤回钻石镐路线评估。所以不并入的理由**只剩下面两条**。
        reason: [
            `底行 (${f.origin.x},${f.origin.y},${f.origin.z}) 是 bedrock（y=${f.origin.y} 不是世界底，清不掉）⇒ 实际可动工的只有 ${f.missing.length + f.wrong.length - 1} 格`,
            '下界不能用水浇黑曜石（水在下界蒸发）⇒ 缺的 4 块是**净物资成本**（易物/开箱），主世界"舀岩浆→浇水"那套在下界不成立',
        ],
        correctedAway: [
            '（初版第 2 条，已作废）"缺格含 1 格 crying_obsidian，1.16 挖它要钻石镐，没有就清不掉、门点不着" ⇒ **不成立**：crying_obsidian 用铁镐可挖（41.7s），只是不掉落。研究线的钻石镐路线评估已撤回。',
        ],
        measured: {
            frameOrigin: at(f.origin), axis: f.axis,
            obsidianInFrame: `${f.obsidian}/${f.required}`,
            missing: f.missing.length, wrong: f.wrong.length, dirty: f.dirty.length,
            obsidianToPlace: f.obsidianToPlace, usable: f.usable,
            wrongBlocks: (np.summary?.wrongGot ?? []).join(', '),
            source: 'bench/route/probe/nether_portal.round4c.json',
        },
        keepAsReference: '数据保留在 probe 与报告里（框体几何、缺格构成、逐格真值），供后续任何下界补给方案复用。',
    });
    note('C1', '不 emit 下界废弃传送门（更正后只剩两条：底行基岩 + 下界不能浇水）', { obsidianToPlace: f.obsidianToPlace, usable: f.usable });
}

// ================================================================== 落盘
route.routePendingStations = [];   // ROUND4 的三站已处理完（两站并入、一站判不并入）
route.generatedAt = new Date().toISOString();
route.generatedFrom.round5c = {
    tool: 'bench/route/tools/emit_round5c.mjs',
    bastion: 'bench/route/probe/bastion.round4c.json',
    fortress: 'bench/route/probe/fortress.round4c.json',
    fortressStanding: 'bench/route/probe/fortress_standing.round5c.json',
    netherPortal: 'bench/route/probe/nether_portal.round4c.json（C-1 不 emit，仅记 notEmitted）',
};
fs.writeFileSync(ROUTE_PATH, JSON.stringify(route, null, 2) + '\n');
fs.writeFileSync(LEDGER_PATH, JSON.stringify({
    schema: 'aidqq-round5c-emit/1', seed: SEED, at: route.generatedAt,
    route: `bench/route/${SEED}.json`, changes,
    frozenAt: route.frozenAt, sha256File: route.sha256File,
    note: 'frozenAt 保持 null：冻结由设计会话在 B 线 S1 5/5 后做（派单 C-4）。',
}, null, 2));

log(`✓ 已写 bench/route/${SEED}.json（站数 ${route.stations.length}，frozenAt=${JSON.stringify(route.frozenAt)}）`);
for (const c of changes) log(`  · [${c.kind}] ${c.what}`);
log(`✓ 台账 bench/route/probe/route_emit.round5c.json`);
