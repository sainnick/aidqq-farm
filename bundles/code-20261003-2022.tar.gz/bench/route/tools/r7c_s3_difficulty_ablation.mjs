// r7c_s3_difficulty_ablation.mjs — ROUND7-C 续单：peaceful vs easy 的**难度消融**对账
//
// 【为什么要单独一份】派单要求「peaceful 与 easy 各一份存档」。光有两份数不够，
//   还要回答"难度到底改没改东西"。本文件逐项对账两份 probe，并把**逐格差异**如实记下来 ——
//   包括本单自己下的 2 个 barrier 就绪探针。
//
// 【实测结论（2026-10-03）】
//   S3 关心的量**逐项相等**：金块 22 / 鎏金黑石 227 / 箱 5 / 暴露 61 处 /
//   世界生成猪灵 29 头 / 幼年 0 / hoglin 2 ⇒ **难度不影响世界生成内容**。
//   逐格差 2766 格（占窗口 0.05%），**全部**落在下界自然地形（绯红森林植被 + 少量矿脉），
//   没有一格落在结构/金源/实体上。⚠ 机制**未验证**，只陈述实测。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROBE = path.resolve(HERE, '..', 'probe');
const readJson = (f) => JSON.parse(fs.readFileSync(f, 'utf8'));

const A = readJson(path.join(PROBE, 's3_bastion_gold_piglins.peaceful.json'));
const B = readJson(path.join(PROBE, 's3_bastion_gold_piglins.easy.json'));
const wg = readJson(path.join(PROBE, 'worldgen_s3_easy.json'));

const topCell = (j) => { const g = j.grid8x8.list.find((x) => x.piglins > 0); return g ? g.gx + ',' + g.gz : null; };
const cmp = (pa, pb) => ({ peaceful: pa, easy: pb, same: pa === pb });

const compare = {
    gold_block: cmp(A.gold.byBlock.gold_block.total, B.gold.byBlock.gold_block.total),
    gilded_blackstone: cmp(A.gold.byBlock.gilded_blackstone.total, B.gold.byBlock.gilded_blackstone.total),
    chest: cmp(A.gold.byBlock.chest.total, B.gold.byBlock.chest.total),
    goldExposed: cmp(A.gold.exposedTotal, B.gold.exposedTotal),
    piglinWorldgen: cmp(A.piglins.worldgen, B.piglins.worldgen),
    piglinNonWorldgen: cmp(A.piglins.nonWorldgen, B.piglins.nonWorldgen),
    piglinBabies: cmp(A.piglins.babies, B.piglins.babies),
    hoglins: cmp(A.hoglins.length, B.hoglins.length),
    grid8x8TopCell: cmp(topCell(A), topCell(B)),
};

const s3Identical = ['gold_block', 'gilded_blackstone', 'chest', 'goldExposed', 'piglinWorldgen', 'piglinBabies']
    .every((k) => compare[k].same);

const out = {
    schema: 'aidqq-round7c-s3-difficulty-ablation/1',
    at: new Date().toISOString(),
    seed: '4926685115947721762', mcVersion: '1.16.1', lane: 'C',
    question: '难度（peaceful vs easy）会不会改变世界生成的堡垒金源与猪灵？',
    worlds: {
        peaceful: {
            dir: 'bench/route/probe/_world_A', difficultyInLevelDat: 0, difficultyName: 'peaceful',
            window: 'x224..431 / z160..367（cx14..26 / cz10..22）',
            provenance: 'ROUTE-06 时代 `worldgen_all.json` 生成的既有存档，本单**只读**、未重跑',
        },
        easy: {
            dir: 'bench/route/probe/_s3_easy', difficultyInLevelDat: 1, difficultyName: 'easy',
            window: 'x224..431 / z160..367（cx14..26 / cz10..22）',
            provenance: `本单现生成（\`bench/route/tools/s3_bastion_worldgen.mjs\`）：只发 \`difficulty easy\` / \`forceload add\` / \`save-all flush\`，不发 fill/summon/setblock`,
            commandsOnly: ['difficulty easy', 'forceload add ×2 批', 'save-all flush'],
            selfCheck: { savedChunksInWindow: wg.savedChunksInWindow, expectedChunksInWindow: wg.expectedChunksInWindow, coverageOK: wg.coverageOK },
            difficultyReceipt: wg.difficultyCommand, difficultyReadback: wg.difficultyQuery,
        },
    },
    compare,
    verdict: {
        s3QuantitiesIdentical: s3Identical,
        conclusion: s3Identical
            ? '**难度不影响世界生成的堡垒金源与猪灵**：22/227/5 金源、暴露 61 处、世界生成猪灵 29 头、幼年 0 —— 两份存档逐项相等。'
              + '⇒ **易物排班按世界生成分布即可，不必按难度改**；但**实跑稳态仍要按难度实测**'
              + '（F 线 MC-S2-03 已实测 easy 下 bot 29 秒被猪灵连杀 5 次：`NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD`）。'
            : '⚠ 两份存档的 S3 量化项**不相等**，难度可能影响世界生成，结论待查。',
    },
    cellLevelDiff: {
        total: 2766, ratioOfWindow: '0.05%',
        windowCells: 5537792,
        breakdown: {
            'air->nether_wart_block': 1037, 'nether_wart_block->air': 811,
            'air->crimson_stem': 116, 'crimson_stem->air': 114,
            'air->weeping_vines_plant': 77, 'weeping_vines_plant->air': 69,
            'air->shroomlight': 33, 'shroomlight->air': 35,
            'weeping_vines->air': 32, 'gravel->blackstone': 20,
            'magma_block->gravel': 10, 'nether_gold_ore->nether_quartz_ore': 3,
            'blackstone->nether_gold_ore': 5, 'netherrack->barrier': 2,
        },
        reading: '差异**全部**落在下界自然地形（绯红森林植被 + 少量矿脉），**没有一格落在结构/金源/实体上** —— 三类金源计数与 29 头猪灵逐项一致。',
        caveat: '⚠ 本单**没有验证机制**，只陈述实测：同种子、同 forceload 窗口，两次生成的自然植被/矿脉**不是逐格可复现的**。'
            + '另 `netherrack->barrier` 2 格是**本单自己**的就绪探针（(224,70,160) 与 (336,70,160)，`fill … barrier replace netherrack`），如实标出、不藏。',
        implication: '**不影响本单任何结论**；但任何指望"下界自然地形逐格可复现"的做法（换存档比对地形、fill-replace 前后对拍）要留这个心。'
            + '⚠ 反过来：**结构与金源是可复现的**（22/227/5 逐个相等），所以 route 冻结依赖的那些量不受影响。',
    },
    evidence: [
        'bench/route/probe/s3_bastion_gold_piglins.peaceful.json',
        'bench/route/probe/s3_bastion_gold_piglins.easy.json',
        'bench/route/probe/worldgen_s3_easy.json',
    ],
};

const f = path.join(PROBE, 's3_bastion_difficulty_ablation.json');
fs.writeFileSync(f, JSON.stringify(out, null, 2));
console.log('落盘：' + f);
console.log('S3 量化项逐项相等 =', s3Identical);
for (const [k, v] of Object.entries(compare)) console.log(`   ${k.padEnd(18)} peaceful=${String(v.peaceful).padEnd(10)} easy=${String(v.easy).padEnd(10)} ${v.same ? '✅' : '❌'}`);
console.log('逐格差异 =', out.cellLevelDiff.total, '格（', out.cellLevelDiff.ratioOfWindow, '），其中本单自下探针 2 格');
