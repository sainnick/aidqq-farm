// s5_room_doors.mjs — ROUND7-C：门室空气分量边界上那 4 扇铁门**具体在哪**（= "最近的可进入点"）
//
// 【为什么单独查】`s5_portal_room.mjs` 给出的是**面数**（边界 iron_door×8 = 4 扇），
//   但"进得去"要回答的是**站在哪一格能开这扇门**。本文件把 4 扇门的坐标 + 朝向 + 门内外两侧
//   各自通到哪种空气打出来，让"最近可进入点"是**可执行坐标**而不是一个统计量。
// 只读。

import { openWorld } from './region_reader.mjs';
import { AIRLIKE } from './visibility_audit.mjs';

const world = openWorld(process.argv[2] ?? 'D:/AI斗蛐蛐/bench/route/probe/_s5_s5');
const CX = 1328, CZ = 1152;
const box = { x1: 1280, y1: 0, z1: 1104, x2: 1376, y2: 255, z2: 1200 };
const N6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const key = (x, y, z) => `${x},${y},${z}`;
const get = (x, y, z) => world.blockAt(x, y, z, 'overworld');
const isAir = (x, y, z) => AIRLIKE.has(get(x, y, z));

// 门室空气分量（种子 = 框环中心正上方）
const SEED = [1334, 39, 1161];
const room = new Set([key(...SEED)]);
{
    const st = [SEED];
    while (st.length) {
        const [x, y, z] = st.pop();
        for (const [dx, dy, dz] of N6) {
            const nx = x + dx, ny = y + dy, nz = z + dz, k = key(nx, ny, nz);
            if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
            if (room.has(k) || !isAir(nx, ny, nz)) continue;
            room.add(k); st.push([nx, ny, nz]);
        }
    }
}
console.log(`门室空气分量：${room.size} 格（种子 ${SEED}）`);

// 找所有"贴在门室空气上"的 iron_door
const doors = [];
for (const k of room) for (const [dx, dy, dz] of N6) {
    const [x, y, z] = k.split(',').map(Number);
    const nx = x + dx, ny = y + dy, nz = z + dz;
    const b = get(nx, ny, nz);
    if (b !== 'iron_door' && b !== 'oak_door') continue;
    const st = world.blockState(nx, ny, nz, 'overworld');
    if (st.props?.half !== 'lower') continue;                 // 每扇门只记下扇
    if (doors.some((d) => d.xyz.join() === [nx, ny, nz].join())) continue;
    // 门"外侧"= 继续沿同一方向再走一格（房间 R → 门 D=R+delta → 远侧 R+2*delta）
    // ⚠ 第一版写成 `nx - dx`，算出来又回到门室里了，等于把"外侧"打印成"内侧"。方向反了就白测。
    const away = [nx + dx, ny + dy, nz + dz];
    const outsideAir = isAir(away[0], away[1], away[2]);
    let outsideComp = 0;
    if (outsideAir) {
        const seen = new Set([key(...away)]); const s2 = [away];
        while (s2.length) {
            const [x2, y2, z2] = s2.pop(); outsideComp++;
            for (const [a, b2, c] of N6) {
                const ax = x2 + a, ay = y2 + b2, az = z2 + c, kk = key(ax, ay, az);
                if (ax < box.x1 || ax > box.x2 || ay < box.y1 || ay > box.y2 || az < box.z1 || az > box.z2) continue;
                if (seen.has(kk) || !isAir(ax, ay, az)) continue;
                seen.add(kk); s2.push([ax, ay, az]);
            }
        }
    }
    doors.push({ xyz: [nx, ny, nz], props: st.props, roomSideCell: [x, y, z], outsideCell: away, outsideIsAir: outsideAir, outsideAirComponentSize: outsideComp });
}
doors.sort((a, b) => Math.hypot(a.xyz[0] - CX, a.xyz[2] - CZ) - Math.hypot(b.xyz[0] - CX, b.xyz[2] - CZ));
console.log(`\n贴在门室空气上的门：${doors.length} 扇`);
for (const d of doors) {
    console.log(`  门 @${JSON.stringify(d.xyz)}  facing=${d.props.facing}  open=${d.props.open}`);
    console.log(`     内侧（门室空气）@${JSON.stringify(d.roomSideCell)}   外侧@${JSON.stringify(d.outsideCell)} 是空气=${d.outsideIsAir}` +
        (d.outsideIsAir ? ` 外侧空气分量=${d.outsideAirComponentSize} 格（与门室分量 ${d.outsideAirComponentSize === room.size ? '同一团' : '不同团'}）` : ''));
}
