﻿import { openWorld } from "./region_reader.mjs";
const W = "D:/AI斗蛐蛐/experiments/mc1161-gate/server-1161/world";
for (const mode of ["packed","linear"]) {
  const w = openWorld(W, { unpackMode: mode });
  // r.-1.-1.mca 的局部 (9,16) ⇒ 全局 chunk (-23,-16)
  const info = w.chunkInfo(-23, -16);
  console.log(`\n=== unpackMode=${mode} ===`);
  if(!info){ console.log("  chunk 读不到"); continue; }
  console.log("  sections:",info.sections,"| 压缩:",info.how,"| palette:",JSON.stringify(info.palette.slice(0,10)),"| 实体:",info.entities);
  const top = Object.entries(info.hist).sort((a,b)=>b[1]-a[1]).slice(0,8);
  console.log("  top8:", JSON.stringify(Object.fromEntries(top)));
}
