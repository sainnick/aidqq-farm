// v2_extract_s0.mjs — route v2（aidqq-route/2）：S0_iron / S0_gravel 的 L0 精确坐标
//
// 【为什么是"精确坐标 + 证据"】依据 docs/MC-DECISION-02（背作业 L0）与 SCHEMA §5：
//   v2 的 exact 里每一格都必须来自**存档解析或实跑真值**，并写明证据路径；没有证据不许进 v2。
//   本单全部读数来自 `region_reader.mjs`（1.16.1 Anvil 只读解析器，**离线**，不依赖 mineflayer），
//   存档是 `probe/_bedhunt`（主种子 fresh world，619 个区块，x 32..591 / z 48..431）。
//
// 【选点口径】（用户派单原文：按离路线近、有暴露面或浅层优先，数量够用）
//   1. **必须有暴露面**：6 个面邻格里 ≥1 个属于空气集 {air, cave_air, void_air}
//      —— 手册 §7「方块/矿石只能选看得见、或者有暴露面的」。
//   2. **离路线近**：到「出生点(216,224) → 村庄床(125,310) → S1 门(187,307)」折线的 XZ 垂距。
//      这条折线就是 S0/S0b/S1 三站真实的走法顺序。
//   3. **成堆**：按 8-连通把暴露块聚成"一镐能连着挖"的簇，优先取块多、浅、近的簇；
//      避免派 30 个散在半个地图上的单块（那等于让 bot 自己找，等于没背作业）。
//   4. **数量够用**：铁 10 锭 ⇒ 目标 ≥10 块铁矿（1 块矿 = 1 锭，保守不赌时运）；
//      沙砾出燧石掉率 10% ⇒ 目标 30 块（P(≥1 燧石)=1-0.9^30=95.8%，P(≥2)=89.5%）。
//
// 【"读不到"绝不折算成"没有"】region_reader 的 `blockAt` 在该 y 段没有 section 时返回 'unknown'。
//   本单在读数健康闸门里统计 unknownCells；非 0 就**拒绝出坐标**（手册 §5 / §4-11）。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from './region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROBE = path.join(HERE, '..', 'probe');
const WORLD_DIR = path.join(PROBE, '_bedhunt');
const OUT = path.join(PROBE, 'v2_s0_exact.json');
const DIM = 'overworld';

const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);
const FACES = [[1, 0, 0, '+x'], [-1, 0, 0, '-x'], [0, 1, 0, '+y'], [0, -1, 0, '-y'], [0, 0, 1, '+z'], [0, 0, -1, '-z']];
/** 1.16.1 没有"玩家会造成伤害/不可站立"的方块集合这里不需要；NON_SOLID 只用于站位判据。 */
const NON_SOLID = new Set(['water', 'lava']);

/** 主种子出生点（SEED-01 top_ranked.csv：spawn_x=216, spawn_z=224, plains） */
const SPAWN = [216, 224];
/** 村庄床簇质心（S0b_village_beds，route scout.points 20 条算得） */
const VILLAGE = [125, 310];
/** S1 废墟门门心（主世界） */
const S1 = [187, 307];
/** 正常流程的过路折线（XZ） */
const ROUTE_XZ = [SPAWN, VILLAGE, S1];

const Y0 = 1, Y1 = 100;

// ---------------------------------------------------------------- 1. 覆盖范围（自动探测，不假设）
const w = openWorld(WORLD_DIR);
let cx0 = 1e9, cx1 = -1e9, cz0 = 1e9, cz1 = -1e9, chunkCount = 0;
for (let cx = -32; cx <= 64; cx++) for (let cz = -32; cz <= 64; cz++) {
    if (!w.chunk(cx, cz, DIM)) continue;
    chunkCount++; cx0 = Math.min(cx0, cx); cx1 = Math.max(cx1, cx); cz0 = Math.min(cz0, cz); cz1 = Math.max(cz1, cz);
}
if (!chunkCount) { console.error('NO_COVERAGE：存档里没有已保存的主世界区块 —— 这是"没读到"，不是"没有"。'); process.exit(2); }
console.log(`覆盖：${chunkCount} 区块，cx ${cx0}..${cx1} / cz ${cz0}..${cz1} ⇒ x ${cx0 * 16}..${(cx1 + 1) * 16 - 1} / z ${cz0 * 16}..${(cz1 + 1) * 16 - 1}`);

// ---------------------------------------------------------------- 2. 读数健康闸门 + 地形对照（手册 §5：全零先证伪工具）
const box = { x1: cx0 * 16, y1: Y0, z1: cz0 * 16, x2: (cx1 + 1) * 16 - 1, y2: Y1, z2: (cz1 + 1) * 16 - 1 };
let cells = 0, unknown = 0;
const terrain = {};
for (let cx = cx0; cx <= cx1; cx++) for (let cz = cz0; cz <= cz1; cz++) {
    const c = w.chunk(cx, cz, DIM); if (!c) continue;
    for (let y = Y0; y <= Y1; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
        const o = x + z * 16 + y * 256;
        if (!c.filled[o]) { cells++; unknown++; continue; }
        cells++;
        const nm = c.palette[c.idx[o]]?.name ?? 'unknown';
        if (nm === 'unknown') unknown++;
        else if (['stone', 'dirt', 'grass_block', 'water', 'gravel', 'iron_ore', 'coal_ore', 'andesite', 'diorite', 'granite', 'cave_air', 'sand', 'bedrock'].includes(nm)) terrain[nm] = (terrain[nm] ?? 0) + 1;
    }
}
console.log(`读数健康：${cells - unknown}/${cells} 可读（unknownCells=${unknown}）`);
console.log(`地形对照：${JSON.stringify(terrain)}`);
if (unknown > 0) { console.error(`ABORT：扫描盒里有 ${unknown} 格读不到（该 y 段没有 section / 区块未落盘）—— 拒绝出坐标。`); process.exit(3); }

// ---------------------------------------------------------------- 3. 逐块普查（暴露面 + 离路线距离）
function distToRouteXZ(x, z) {
    let best = Infinity;
    for (let i = 0; i + 1 < ROUTE_XZ.length; i++) {
        const [ax, az] = ROUTE_XZ[i], [bx, bz] = ROUTE_XZ[i + 1];
        const dx = bx - ax, dz = bz - az, len2 = dx * dx + dz * dz;
        let t = len2 ? ((x - ax) * dx + (z - az) * dz) / len2 : 0;
        t = Math.max(0, Math.min(1, t));
        best = Math.min(best, Math.hypot(x - (ax + t * dx), z - (az + t * dz)));
    }
    return best;
}
const key = (x, y, z) => `${x},${y},${z}`;
const census = { iron_ore: new Map(), gravel: new Map() };
for (let cx = cx0; cx <= cx1; cx++) for (let cz = cz0; cz <= cz1; cz++) {
    const c = w.chunk(cx, cz, DIM); if (!c) continue;
    const hist = new Set();
    for (let i = 0; i < c.filled.length; i++) {
        if (!c.filled[i]) continue;
        const nm = c.palette[c.idx[i]]?.name;
        if (nm === 'iron_ore' || nm === 'gravel') hist.add(nm);
    }
    if (!hist.size) continue;                                   // 绝大多数区块走这条路
    for (let y = Y0; y <= Y1; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
        const o = x + z * 16 + y * 256;
        if (!c.filled[o]) continue;
        const nm = c.palette[c.idx[o]]?.name;
        if (nm !== 'iron_ore' && nm !== 'gravel') continue;
        const ax = cx * 16 + x, az = cz * 16 + z;
        const airFaces = [];
        for (const [dx, dy, dz, tag] of FACES) if (AIRLIKE.has(w.blockAt(ax + dx, y + dy, az + dz, DIM))) airFaces.push(tag);
        if (!airFaces.length) continue;                          // 没暴露面 ⇒ 不可选（手册 §7）
        census[nm].set(key(ax, y, az), { xyz: [ax, y, az], airFaces });
    }
}
for (const nm of ['iron_ore', 'gravel']) {
    const L = [...census[nm].values()];
    console.log(`\n${nm}：暴露块 ${L.length}  离路线最近 ${Math.min(...L.map((h) => distToRouteXZ(h.xyz[0], h.xyz[2]))).toFixed(1)} 格`);
}

// ---------------------------------------------------------------- 4. 8-连通聚簇 + 排序
function clusters(map) {
    const seen = new Set(); const out = [];
    for (const start of map.keys()) {
        if (seen.has(start)) continue;
        const comp = []; const stack = [start]; seen.add(start);
        while (stack.length) {
            const k = stack.pop(); comp.push(map.get(k));
            const [x, y, z] = k.split(',').map(Number);
            for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
                if (!dx && !dy && !dz) continue;
                const nk = key(x + dx, y + dy, z + dz);
                if (map.has(nk) && !seen.has(nk)) { seen.add(nk); stack.push(nk); }
            }
        }
        out.push(comp);
    }
    return out;
}
/**
 * 站得住吗（**挖掘站位**口径，与"走路"口径故意不同）。
 *
 * ⚠⚠ **踩过的坑（值得进手册）**：本项目其它工具（`visibility_audit.mjs` 的
 *   `standable(footIsAir, belowSolid, plus1Air, plus2Air)`、下界 legs 的"身体 2 格空气集"）
 *   都要求 **y 与 y+1、y+2 三格都是空气**。那是**走路**判据（留头顶余量），**不是站位判据**。
 *   照抄它来做挖掘站位，会把**"站在矿正下方向上挖"这种最正常不过的站位全部误杀** ——
 *   实测：主种子 S0 沿线最近的铁矿 (206,49,233) 脚下 (206,47,233)/(206,48,233) 都是 cave_air、
 *   y=49 是铁矿，25 个近路铁矿簇因这条被 100% 拒绝。
 *
 *   玩家的碰撞箱高 1.8 格 = 身体占 **y、y+1 两格**；y+2 实心只意味着"头顶贴着方块"，
 *   **不妨碍站立、也不妨碍挖它**。所以挖掘站位只要求：脚下实心 + y、y+1 两格空气。
 *   `headClear`（y+2 是否空气）只作记录，不作拒绝条件。
 */
function standableAt(x, y, z) {
    const feet = w.blockAt(x, y, z, DIM);
    if (!AIRLIKE.has(feet)) return null;
    const below = w.blockAt(x, y - 1, z, DIM);
    if (AIRLIKE.has(below) || below === 'unknown' || NON_SOLID.has(below)) return null;
    if (!AIRLIKE.has(w.blockAt(x, y + 1, z, DIM))) return null;      // 身体第 2 格（头）
    return { headClear: AIRLIKE.has(w.blockAt(x, y + 2, z, DIM)) };  // 只是记录
}
/**
 * 给一簇矿找站位。
 *
 * 只看 6 个面邻格是不够的：实测沿线大量矿脉在**没有地板的竖井/斜壁**上
 * （脚下 3~6 格一路 cave_air 通到底），面邻格里根本没有实心地面。
 * 真人这时会**搭方块（pillar）或踩着斜壁上下**——所以这里改成
 * **在簇的包围盒外扩 R 格内找站得住的格子**，并把距离如实记下来：
 *   - `dist ≤ 1.5`：站在矿旁边直接挖
 *   - `1.5 < dist ≤ 6`：需要挪位置/搭一小段
 * 找不到就标 `needsPillar`（不是"这一簇不存在"）。
 */
const STAND_R = 6;
function standFor(comp) {
    const set = new Set(comp.map((h) => key(...h.xyz)));
    const xs = comp.map((h) => h.xyz[0]), ys = comp.map((h) => h.xyz[1]), zs = comp.map((h) => h.xyz[2]);
    const lo = [Math.min(...xs) - STAND_R, Math.min(...ys) - STAND_R, Math.min(...zs) - STAND_R];
    const hi = [Math.max(...xs) + STAND_R, Math.max(...ys) + STAND_R, Math.max(...zs) + STAND_R];
    const cands = [];
    for (let y = lo[1]; y <= hi[1]; y++) for (let z = lo[2]; z <= hi[2]; z++) for (let x = lo[0]; x <= hi[0]; x++) {
        if (set.has(key(x, y, z))) continue;                       // 矿块本身不能站
        const st = standableAt(x, y, z);
        if (!st) continue;
        let dmin = Infinity;
        for (const h of comp) dmin = Math.min(dmin, Math.hypot(x - h.xyz[0], y - h.xyz[1], z - h.xyz[2]));
        cands.push({ stand: [x, y, z], d: dmin, headClear: st.headClear });
    }
    cands.sort((a, b) => (a.d - b.d) || (a.stand[1] - b.stand[1]) || (a.stand[0] - b.stand[0]) || (a.stand[2] - b.stand[2]));
    return cands.length ? cands[0] : null;
}
function rank(comp) {
    const ys = comp.map((h) => h.xyz[1]);
    const dmin = Math.min(...comp.map((h) => distToRouteXZ(h.xyz[0], h.xyz[2])));
    return { n: comp.length, yMin: Math.min(...ys), yMax: Math.max(...ys), dMin: +dmin.toFixed(1) };
}
/** 派单的优先级原文是「**离路线近**、有暴露面或浅层优先」⇒ 排序必须以 dMin 为主键。 */
const MAX_DETOUR = 80;      // 允许的最大绕路（格）。超过就不如现挖。
function pick(need, map, label) {
    const all = clusters(map).map((c) => ({ comp: c, ...rank(c) })).filter((c) => c.n >= 2);
    const inRange = all.filter((c) => c.dMin <= MAX_DETOUR);
    // **主键是离路线距离**，其次块数（一次挖得多），再次浅。
    // ⚠ 反面教材：先按块数排会把 bot 派到 200+ 格外的大矿坑去 —— 那不是"背作业"，那是让它自己找路。
    const cmp = (a, b) => (a.dMin - b.dMin) || (b.n - a.n) || (a.yMax - b.yMax);
    inRange.sort(cmp);
    console.log(`\n${label} 暴露簇：共 ${all.length}（n≥2），其中离路线 ≤${MAX_DETOUR} 的 ${inRange.length}，前 12：`);
    for (const c of inRange.slice(0, 12)) console.log(`   n=${String(c.n).padStart(3)}  y${c.yMin}..${c.yMax}  d=${c.dMin}`);
    const chosen = []; let total = 0;
    for (const c of inRange) {
        if (total >= need) break;
        const st = standFor(c.comp);
        if (!st) { console.log(`  ✗ 簇 n=${c.n} @y${c.yMin}..${c.yMax} d=${c.dMin}：外扩 ${STAND_R} 格内也没有站得住的地面 —— 跳过（需要先自己开路）`); continue; }
        chosen.push({ stand: st.stand, standDist: +st.d.toFixed(2), blocks: c.comp.map((h) => h.xyz), n: c.n, yMin: c.yMin, yMax: c.yMax, dMin: c.dMin });
        total += c.n;
    }
    console.log(`  选中 ${chosen.length} 簇，共 ${total} 块（需要 ${need}）`);
    if (total < need) console.log(`  ⚠ 只凑到 ${total} < ${need}`);
    return { chosen, total, inRange: inRange.length, allClusters: all.length };
}
const iron = pick(14, census.iron_ore, 'iron_ore');      // 10 锭硬需求 + 4 块余量
const grav = pick(30, census.gravel, 'gravel');          // 10% 掉率 ⇒ 30 块保 1 根燧石 95.8%

// ---------------------------------------------------------------- 5. 逐块回读自证（阳性对照：不回读到目标块就丢弃并记账）
function verifyBlock(xyz, want) {
    const got = w.blockAt(xyz[0], xyz[1], xyz[2], DIM);
    if (got !== want) return { ok: false, got };
    const faces = [];
    for (const [dx, dy, dz, tag] of FACES) if (AIRLIKE.has(w.blockAt(xyz[0] + dx, xyz[1] + dy, xyz[2] + dz, DIM))) faces.push(tag);
    return { ok: faces.length > 0, got, airFaces: faces };
}
function emit(pickRes, want) {
    const stand = [], targets = [], rejected = [];
    let order = 1;
    for (const c of pickRes.chosen) {
        stand.push(c.stand);
        for (const b of c.blocks) {
            const v = verifyBlock(b, want);
            if (v.ok) targets.push({ what: 'dig', xyz: b, order: order++, airFaces: v.airFaces, standFor: c.stand, standDist: c.standDist, tool: want === 'iron_ore' ? 'stone_pickaxe' : 'any' });
            else rejected.push({ xyz: b, want, got: v.got, reason: v.got === 'unknown' ? 'readback unknown' : (v.got !== want ? `readback=${v.got}` : 'no exposed face on readback') });
        }
    }
    return { stand, targets, rejected };
}
const ironOut = emit(iron, 'iron_ore');
const gravOut = emit(grav, 'gravel');

// 站位格也要回读（站得住这一条）
for (const [arr, tag] of [[ironOut.stand, 'iron'], [gravOut.stand, 'gravel']]) {
    for (const s of arr) if (!standableAt(...s)) console.log(`  ⚠ ${tag} 站位 ${JSON.stringify(s)} 回读发现站不住（剔除）`);
}

// ---------------------------------------------------------------- 6. 落盘
const out = {
    schema: 'aidqq-v2-s0-exact/1',
    at: new Date().toISOString(),
    seed: '4926685115947721762',
    mcVersion: '1.16.1',
    world: path.relative(path.join(HERE, '..', '..'), WORLD_DIR).replace(/\\/g, '/'),
    reader: 'bench/route/tools/region_reader.mjs（离线 .mca 解析，**不依赖 mineflayer**）',
    evidence: 'bench/route/probe/v2_s0_exact.json（本文件）+ bench/route/tools/v2_extract_s0.mjs',
    coverage: { chunks: chunkCount, cx: [cx0, cx1], cz: [cz0, cz1], x: [box.x1, box.x2], z: [box.z1, box.z2], y: [Y0, Y1], unknownCells: unknown },
    positiveControls: {
        note: '手册 §4-11 / §5：全零先证伪工具。这里 terrain 是同一存档同一次扫描的对照读数。',
        terrain,
    },
    criteria: {
        exposed: '6 面邻格 ≥1 属于 {air,cave_air,void_air}',
        routeDist: '到折线 spawn(216,224)→village(125,310)→S1(187,307) 的 XZ 垂距',
        clustering: '8-连通；只取 n≥2 的簇（要"一镐连着挖"，不是撒芝麻）',
        standable: '脚下非空气集且非 water/lava + 本格与 +1 两格空气集',
    },
    stations: {
        S0_iron: {
            need: '10 锭（1 块铁矿 = 1 锭，保守不赌时运）',
            exposedTotal: census.iron_ore.size,
            selected: ironOut.targets.length,
            stand: ironOut.stand,
            targets: ironOut.targets,
            rejected: ironOut.rejected,
        },
        S0_gravel: {
            need: '30 块（燧石掉率 10%：P(≥1)=1-0.9^30=95.8%，P(≥2)=89.5%）',
            exposedTotal: census.gravel.size,
            selected: gravOut.targets.length,
            stand: gravOut.stand,
            targets: gravOut.targets,
            rejected: gravOut.rejected,
        },
    },
};
fs.writeFileSync(OUT, JSON.stringify(out, null, 2) + '\n', 'utf8');
// 写完读回断言（手册 §3：`new URL(import.meta.url).pathname` 那条坑的同族——"我写了文件"必须核）
const back = JSON.parse(fs.readFileSync(OUT, 'utf8'));
if (back.stations.S0_iron.targets.length !== ironOut.targets.length) { console.error('WRITE_READBACK_FAIL'); process.exit(4); }
console.log(`\n✔ 落盘 ${OUT}`);
console.log(`  S0_iron   暴露 ${out.stations.S0_iron.exposedTotal} → 选中 ${out.stations.S0_iron.selected} 块，站位 ${ironOut.stand.length} 个，丢弃 ${ironOut.rejected.length}`);
console.log(`  S0_gravel 暴露 ${out.stations.S0_gravel.exposedTotal} → 选中 ${out.stations.S0_gravel.selected} 块，站位 ${gravOut.stand.length} 个，丢弃 ${gravOut.rejected.length}`);
