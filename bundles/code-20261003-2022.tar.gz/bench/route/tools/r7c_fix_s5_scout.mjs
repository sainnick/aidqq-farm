// r7c_fix_s5_scout.mjs — ROUND7-C 续单：**只改 S5 的 scout 区**（不动 station、不写 frozenAt）
//
// 【改什么、依据什么】
//   ① `verify.counts.end_portal_frame` 9 → 12：ROUTE-02 的扫描窗 z 下界是 1160，把 z=1159 上的 3 框切掉了（9+3=12）。
//      依据：bench/route/probe/s5_portal_room.round7c.json + 本单在 `_s5_s5` 存档上逐格复核（12 框、y 全是 38）。
//   ② 补 `withEye: 2`：末影之眼的 eye 状态是**世界生成时定死**的（`EndPortalFrameFeature` 每框 1/23），
//      存档里读得到 ⇒ 要投 10 颗而不是 12 颗。
//   ③ 补入口：门室边界有 4 扇**关闭的铁门**，最近 (1332,30,1174) 距站心 20.0 格 ⇒ **不用挖**。
//   ④ 补刷怪笼：**本单把上一版"2 个"订正为 1 个**（见 correctionSpawner）。
//
// 【为什么 ③ 的门是 4 扇而不是 8 扇】`iron_door` 每扇占 2 格（lower/upper），
//   盘上盒内共 16 个 iron_door 格 = 8 扇门，但**贴在门室空气上的只有 8 格 = 4 扇**。

import fs from 'fs';
import path from 'path';

const P = 'D:/AI斗蛐蛐/bench/route/4926685115947721762.json';
const raw = fs.readFileSync(P, 'utf8');
const route = JSON.parse(raw);
const before = JSON.stringify(route, null, 2) + '\n';
if (raw !== before) throw new Error('文件不是规范化形式，先确认再改（SCHEMA §4）');

const S5 = route.stations.find((s) => s.id === 'S5_stronghold_room');
if (!S5) throw new Error('找不到 S5_stronghold_room');
const stationBefore = JSON.stringify(S5.station);
const frozenBefore = JSON.stringify([route.frozenAt, route.sha256File]);

// ---- ① 框数 9 → 12，并把 points 补齐到 12（原来是 8/9 且 truncated）
const FRAMES = [
    [1333, 38, 1159], [1334, 38, 1159], [1335, 38, 1159],
    [1332, 38, 1160], [1336, 38, 1160],
    [1332, 38, 1161], [1336, 38, 1161],
    [1332, 38, 1162], [1336, 38, 1162],
    [1333, 38, 1163], [1334, 38, 1163], [1335, 38, 1163],
];
const EYES = [[1332, 38, 1161], [1335, 38, 1163]];
const isEye = (p) => EYES.some((e) => e[0] === p[0] && e[1] === p[1] && e[2] === p[2]);

S5.scout.points = FRAMES.map((p) => ({ x: p[0], y: p[1], z: p[2], what: 'end_portal_frame', eye: isEye(p) }));
S5.scout.pointsTotal = FRAMES.length;
S5.scout.pointsTruncated = false;

S5.scout.verify.counts = { ...S5.scout.verify.counts, end_portal_frame: 12 };
S5.scout.verify.method = 'fill-replace（ROUTE-02 粗扫）+ 存档解析逐格复核（region_reader.mjs，本单订正）';
S5.scout.verify.correction = {
    at: '2026-10-03T10:40:00.000Z',
    by: '开发线 C · ROUND7-C 续单',
    field: 'verify.counts.end_portal_frame',
    from: 9, to: 12,
    cause: 'ROUTE-02 的扫描窗 z 下界是 **1160**，把 **z=1159 上的 3 个框**（1333/1334/1335,38,1159）切掉了。9+3=12，与本站 notes 原话"12 个框"对上。',
    whyMissed: '下钻自检（coarse 9 == drilled 9）只能证明"**在扫到的范围内**粗扫与下钻一致"；terrainProof=in-scan 只能证明地形对照在扫描区内。两者都证明不了扫描范围没被截断。',
    lesson: '手册 §5「扫描范围要比目标大一圈，并检查边界上有没有命中」—— 命中贴着扫描边界时必须扩大范围重扫。',
    statusUnchanged: 'verify.status 仍是 REAL（方法没错，错的是那个数，已订正）。',
    evidence: 'bench/route/probe/s5_portal_room.round7c.json；本单在 bench/route/probe/_s5_s5 上逐格复核',
};

// ---- ② 已有末影之眼
S5.scout.frames = {
    total: 12,
    withEye: 2,
    withoutEye: 10,
    eyePositions: EYES,
    allY: 38,
    ringShape: '5×5 外圈缺四角、中心 3×3 空',
    ringComplete: true,
    missing: [], extra: [],
    implication: '**要投 10 颗末影之眼**（12 − 已有 2）。`eye` 状态在世界生成时就定死（EndPortalFrameFeature 每框 1/23 概率），存档已带 ⇒ 投眼前**先看框上有没有眼**，别按 12 个盲投。',
    evidence: '存档逐格复核：blockState(...).props.eye',
};

// ---- ③ 入口（4 扇关闭的铁门，不用挖）
S5.scout.entrance = {
    needsDig: false,
    method: '**右键开铁门**（正常玩家交互，不是挖墙、不是透视）',
    nearest: { xyz: [1332, 30, 1174], facing: 'north', open: false, distFromStationCenterXZ: 20.0 },
    doors: [
        { xyz: [1332, 30, 1174], facing: 'north', open: false, distFromStationCenterXZ: 20.0, note: '最近' },
        { xyz: [1311, 36, 1167], facing: 'west', open: false, distFromStationCenterXZ: 22.7, note: '外侧空气分量 414 格（最大，最像主走廊）' },
        { xyz: [1320, 36, 1181], facing: 'north', open: false, distFromStationCenterXZ: 30.1 },
        { xyz: [1323, 36, 1185], facing: 'east', open: false, distFromStationCenterXZ: 33.4 },
    ],
    doorCount: 4,
    doorCellCount: 8,
    caveat: '⚠ 空气 6 连通在这里**必然显示"不通"**，因为泛洪过不去**关着的门**。判"能不能进"必须把门单独数，不能只看空气连通（与 S0b 村庄床同一个坑）。',
    fallback: '若 4 扇门都不可用，最薄实体层只 1 格。',
    evidence: 'bench/route/probe/s5_portal_room.round7c.json + s5_room_doors.mjs',
};

// ---- ④ 刷怪笼 / 门室里的箱子（**订正上一版的"2 个"**）
S5.scout.roomContents = {
    roomAirCells: 1218, standSpots: 284, yRange: [30, 41], sky: false,
    spawners: [
        {
            xyz: [1330, 38, 1161], mobType: 'minecraft:silverfish', spawnCount: 4, delay: 20,
            facesTouchingRoomAir: 2,
            note: '**银鱼（silverfish）不会攻击玩家** ⇒ 门室里的威胁等级比"刷怪笼"三个字听起来低得多。',
        },
    ],
    chests: [
        { xyz: [1327, 37, 1179], lootTable: 'minecraft:chests/stronghold_corridor', facesTouchingRoomAir: 2 },
    ],
    correctionSpawner: {
        at: '2026-10-03T10:40:00.000Z',
        field: '上一版报告 §3「门室里有什么：spawner×2（边界）、chest×2」',
        from: '2 个刷怪笼 + 2 个箱子', to: '**1 个刷怪笼 + 1 个箱子**',
        cause: '那两个数来自 `s5_portal_room.mjs` 的 `roomBoundary`，它统计的是"**非门室格被多少个门室空气格贴到**"的**邻接次数**，不是方块个数。实测：(1330,38,1161) 这**一个**刷怪笼有 **2 个面**贴门室空气 ⇒ 被计成 2；箱子 (1327,37,1179) 同理。',
        evidence: '全盒复核：x1280..1376 / y0..255 / z1104..1200 内 spawner **恰好 1 个**（1330,38,1161）；`TileEntities` 里 `minecraft:mob_spawner` 该区域共 4 个，其余 3 个在 (166,39,214) / (1411,16,1235) / (1250,22,1269) / (1276,25,1296) 一带，**都不在门室上**。',
        rule: '手册 §5「**区域总数 ≠ 框内计数**」——结构附近某种方块的总数不能当成结构里关键位置上的计数。',
    },
    nbtNote: '1.16.1 的区块 NBT 里方块实体键是 **`TileEntities`**（1.17+ 才改名 block_entities），刷怪笼的怪物类型在 **`SpawnData.id`**、坐标在 **`x`/`y`/`z`**（不是 `Spawner.EntityId`、不是 `Pos`）。',
    lootNote: '门室旁那个箱子是 `stronghold_corridor` 战利品表；门室这一片另有 stronghold_library / stronghold_crossing 战利品表，但**都不贴在门室上**。',
};

// ---- notes 补两句（原 notes 里"bot 自己 findBlocks 找齐 12 框"此前与 counts=9 自相矛盾，现已成立）
S5.scout.notes += '｜【ROUND7-C 续单订正】counts 9→12（扫描窗 z 下界切掉 z=1159 的 3 框）；已有末影之眼 2 ⇒ **要投 10 颗**；入口 = 4 扇关闭铁门、最近 (1332,30,1174) 20.0 格、**不用挖**；门室边只有 **1 个**刷怪笼（银鱼，不攻击）不是 2 个';

// ---- 硬闸：station / frozenAt / sha256File 一个字节都不能动
if (JSON.stringify(S5.station) !== stationBefore) throw new Error('station 被改了 —— 违反派单');
if (JSON.stringify([route.frozenAt, route.sha256File]) !== frozenBefore) throw new Error('frozenAt/sha256File 被改了 —— 违反派单');

fs.writeFileSync(P, JSON.stringify(route, null, 2) + '\n');
console.log('S5 scout 已更新：');
console.log('  points 8/9(truncated) →', S5.scout.points.length, '(truncated=' + S5.scout.pointsTruncated + ')');
console.log('  verify.counts.end_portal_frame 9 →', S5.scout.verify.counts.end_portal_frame);
console.log('  withEye =', S5.scout.frames.withEye, '  entrance.needsDig =', S5.scout.entrance.needsDig, '  doors =', S5.scout.entrance.doorCount);
console.log('  spawners =', S5.scout.roomContents.spawners.length, '(上一版误记 2)');
console.log('  station 逐字节不变 ✓  frozenAt/sha256File 不变 ✓');
