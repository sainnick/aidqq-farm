// portal_frame.mjs — **废弃/下界传送门框体**的逐格判定（几何为生产代码的独立移植）
//
// 【来源与移植声明】（ROUND3 §C-1 原文：「几何和生产代码 frameCells 保持一致，
//   在 bench/route/tools/ 里**移植**，文件头注明来源；不许直接 import worktree 里的代码」）
//   移植自：`mindcraft-wt/s1-portal/src/agent/tasks/exec/nether.js`
//            · PORTAL_W / PORTAL_H / CORNERS_OPTIONAL（该文件 36–38 行）
//            · frameCells / interiorCells / checkFrame（该文件 47–89 行）
//   **刻意不 import**：worktree 是开发线 B 的工作区，任务层代码随时在改；预勘工具要在
//   bench 侧自包含。两边的等价性由下面的 `parityWithTask08r3()` 离线对账守住——
//   它拿 B 线 r3 的服务端逐格真值表当 fixture，**对不上就抛错**。
//
// 【为什么要逐格】（手册 §5 + ROUTE-02 报告 §4 已有的教训族）：
//   `fill … replace <block>` 给的是**区域内该方块类型的总数**，不是"某个结构体内有几格"。
//   主种子废弃门因此被算成"obsidian 9 + crying 1 = 差 1 格"，逐格判定后框内只有 7 格 obsidian。
//   门框是**有固定拓扑的结构**（4×5 边框、内部 2×3 空、1.16.1 顶行两角可省），
//   必须逐格才能回答"缺几格、缺格被什么占着"。
//
// 【1.16.1 的三条语义】（错了整份数据就错，务必照抄）
//   1. 框宽 4、框高 5；`origin` = **底行、展开轴上最小的那一格**。
//   2. **顶行两角可省**（CORNERS_OPTIONAL）：它们不计入 required，判"补齐"时也不算缺。
//   3. 判"可用"只认 `obsidian`。`crying_obsidian` 在框里算**错块**（要挖掉重放，
//      而 1.16 挖它必须钻石/下界合金镐）——它不是"已有"。

export const PORTAL_W = 4;
export const PORTAL_H = 5;
export const CORNERS_OPTIONAL = true;

/** 1.16 里能当作"门框已被占据"的方块（只 obsidian 算可用；crying 算错块） */
export const USABLE_FRAME_BLOCK = 'obsidian';
export const WRONG_BLOCK_KINDS = new Set(['crying_obsidian', 'netherrack']);

/** 内部空气格（点火瞄准区，也是"框内无杂物"的判据）——同 nether.js 的 interiorCells */
export function interiorCells(origin, axis = 'x') {
    const o = { x: Math.round(origin.x), y: Math.round(origin.y), z: Math.round(origin.z) };
    const at = (u, dy) => (axis === 'x' ? { x: o.x + u, y: o.y + dy, z: o.z } : { x: o.x, y: o.y + dy, z: o.z + u });
    const out = [];
    for (let dy = 1; dy <= PORTAL_H - 2; dy++) {
        for (let u = 1; u <= PORTAL_W - 2; u++) out.push({ pos: at(u, dy), kind: 'interior', u, dy });
    }
    return out;
}

/** 门框全部格子——同 nether.js 的 frameCells */
export function frameCells(origin, axis = 'x') {
    const o = { x: Math.round(origin.x), y: Math.round(origin.y), z: Math.round(origin.z) };
    const at = (u, dy) => (axis === 'x' ? { x: o.x + u, y: o.y + dy, z: o.z } : { x: o.x, y: o.y + dy, z: o.z + u });
    const cells = [];
    for (let u = 0; u < PORTAL_W; u++) cells.push({ pos: at(u, 0), kind: 'bottom', u, dy: 0, optional: false });
    for (let dy = 1; dy <= PORTAL_H - 2; dy++) {
        cells.push({ pos: at(0, dy), kind: 'side', u: 0, dy, optional: false });
        cells.push({ pos: at(PORTAL_W - 1, dy), kind: 'side', u: PORTAL_W - 1, dy, optional: false });
    }
    for (let u = 0; u < PORTAL_W; u++) {
        cells.push({
            pos: at(u, PORTAL_H - 1), kind: 'top', u, dy: PORTAL_H - 1,
            optional: CORNERS_OPTIONAL && (u === 0 || u === PORTAL_W - 1),
        });
    }
    return cells;
}

const key = (p) => `${p.x},${p.y},${p.z}`;

/**
 * 逐格判定。
 * @param {{x,y,z}} origin 底行最小格
 * @param {'x'|'z'} axis   门宽展开方向
 * @param {(p:{x,y,z}) => string|null} blockAt 取该格的方块名（服务端真值）；null = 未知
 * @returns {{ok, obsidian, required, optionalObsidian, missing:[], wrong:[], dirty:[], obsidianToPlace, cells}}
 *
 * 口径与 nether.js 的 checkFrame 一致，**只是把"逐格读方块"换成了"由服务端真值表喂进去"**：
 *   - required 格不是 obsidian → missing（按占位分成 air / wrong 两类）
 *   - optional 角不苛求，但单独统计（人审阅要看）
 *   - interior 非 air → dirty
 * `obsidianToPlace` = 要让门可用**必须新放的 obsidian 数**
 *   = 空气缺格数 + 错块格数（错块要先挖掉）。注意：**错块格也要算一格**，
 *   挖掉旧块再放新的，不是"补 0 格"。
 */
export function checkFrame(origin, axis, blockAt) {
    const cells = frameCells(origin, axis);
    const required = cells.filter((c) => !c.optional);
    const missing = [], wrong = [], dirty = [];
    let obsidian = 0, optionalObsidian = 0;
    for (const c of required) {
        const got = blockAt(c.pos) ?? null;
        if (got === USABLE_FRAME_BLOCK) { obsidian++; continue; }
        const rec = { pos: [c.pos.x, c.pos.y, c.pos.z], kind: c.kind, u: c.u, dy: c.dy, got };
        if (got === null) { rec.unknown = true; missing.push(rec); continue; }
        if (got === 'air' || got === 'cave_air' || got === 'void_air') missing.push(rec);
        else wrong.push(rec);
    }
    for (const c of cells.filter((x) => x.optional)) {
        if ((blockAt(c.pos) ?? null) === USABLE_FRAME_BLOCK) optionalObsidian++;
    }
    for (const c of interiorCells(origin, axis)) {
        const got = blockAt(c.pos) ?? null;
        if (got !== 'air' && got !== 'cave_air' && got !== 'void_air') {
            dirty.push({ pos: [c.pos.x, c.pos.y, c.pos.z], got, unknown: got === null });
        }
    }
    return {
        ok: missing.length === 0 && wrong.length === 0 && dirty.length === 0,
        obsidian, required: required.length, optionalObsidian,
        missing, wrong, dirty,
        obsidianToPlace: missing.length + wrong.length,
        cells,
    };
}

/**
 * 枚举候选框并选最优。
 *
 * 候选 = 每个"框体证据点"（obsidian 或 crying_obsidian）× 两个展开方向 × 20 个 origin 偏移。
 * 打分：命中证据点的 required 格子越多越好（crying 也算证据——它在框内占着，
 * 说明这确实是个门框）；同分时取 required 命中更多的，再同分取离证据质心更近的。
 *
 * @param {Array<{x,y,z}>} points   下钻得到的 obsidian / crying_obsidian 精确坐标
 * @returns {{best, runnersUp:Array, candidatesTried:number}} best=null 表示一个候选都没有
 */
export function findBestFrame(points) {
    const pts = (points ?? []).filter((p) => p && Number.isFinite(p.x));
    if (!pts.length) return { best: null, runnersUp: [], candidatesTried: 0 };
    const evidence = new Set(pts.map(key));
    const centroid = pts.reduce((a, p) => ({ x: a.x + p.x / pts.length, y: a.y + p.y / pts.length, z: a.z + p.z / pts.length }), { x: 0, y: 0, z: 0 });
    const scored = [];
    let tried = 0;
    for (const axis of ['x', 'z']) {
        for (const p of pts) {
            for (let u = 0; u < PORTAL_W; u++) {
                for (let dy = 0; dy < PORTAL_H; dy++) {
                    const origin = axis === 'x'
                        ? { x: p.x - u, y: p.y - dy, z: p.z }
                        : { x: p.x, y: p.y - dy, z: p.z - u };
                    tried++;
                    const cells = frameCells(origin, axis);
                    const reqHits = cells.filter((c) => !c.optional && evidence.has(key(c.pos))).length;
                    const optHits = cells.filter((c) => c.optional && evidence.has(key(c.pos))).length;
                    const d = Math.hypot(origin.x - centroid.x, origin.y - centroid.y, origin.z - centroid.z);
                    scored.push({ origin, axis, reqHits, optHits, d, total: reqHits + optHits });
                }
            }
        }
    }
    scored.sort((a, b) => b.reqHits - a.reqHits || b.total - a.total || a.d - b.d);
    const best = scored[0] ?? null;
    return { best, runnersUp: scored.slice(1, 4), candidatesTried: tried };
}

// ------------------------------------------------- 服务端逐格分类（fill 通道）

/**
 * 框体所在的那一片是一个 **4×5×1（或 1×5×4）的单盒**（14 框格 + 6 内部格全在盒内）。
 *
 * 【为什么用逐格判据而不是"整盒 fill 计数 + 八叉下钻"】
 *   后者是先前的做法，实测**更慢也更不可靠**：457 次 fill 才能读完一个 20 格的盒子，
 *   而且一旦某一轮的 marker 没清干净，下一轮的下钻会把上一轮标上去的方块一起挖出来
 *   （实测主种子 20 格里 8 格被两种方块同时命中，最后整片读成 netherrack、obsidian 读成 0）。
 *   逐格判据（cell_probe.probeCell，2 次 fill 定性并复原）读完同一片只要 ~9 秒、
 *   而且**每格的读数自带复原回执**，错了当场能看出来。
 *   实测：逐格判据给出的框体读数 = obsidian 7/12 · 缺3 · 错2 · 脏0，与 B 线 r3 的服务端真值一致。
 *
 * ⚠ 本函数会修改世界（命中时短暂换成 marker）→ 必须在**未被污染的 fresh world** 里跑，
 *   并检查 `restoreFails === 0`（非零说明复原失败，后面的读数一律不可信）。
 *
 * @returns {Promise<{cells, blocks, unresolved, tests, restoreFails, candidates}>}
 */
export async function classifyFrameCells(con, dim, origin, axis, opts = {}) {
    const { probeCell } = await import('./cell_probe.mjs');
    const { forceload } = await import('./scan.mjs');
    const all = [...frameCells(origin, axis), ...interiorCells(origin, axis)];
    const candidates = opts.candidates ?? FRAME_SCAN_CANDIDATES;
    const blocks = new Array(all.length).fill(null);
    let tests = 0, restoreFails = 0;
    // ⚠ 必须先 forceload：单格 fill 落在**未加载区块**上时服务器不给回执，
    //   fillCount 等满 25s 会抛 FILL_NO_RESPONSE（本单实测踩到，种子 4775301964146737582）。
    //   框体常常在山坡/悬崖上，周围区块不一定被生成器带出来。
    const xs = all.map((c) => c.pos.x), zs = all.map((c) => c.pos.z);
    await forceload(con, dim, Math.min(...xs) - 2, Math.min(...zs) - 2, Math.max(...xs) + 2, Math.max(...zs) + 2, opts.forceloadMs ?? 600);
    for (let i = 0; i < all.length; i++) {
        const r = await probeCell(con, dim, all[i].pos, candidates);
        tests += r.tests;
        if (!r.restoreOk) restoreFails++;
        blocks[i] = r.hit ? r.hit.replace(/^minecraft:/, '') : null;
    }
    return { cells: all, blocks, unresolved: blocks.filter((b) => b === null).length, tests, restoreFails, candidates };
}
/**
 * 候选顺序按**命中概率**排（不是按语义分类）：框里绝大多数格要么是 obsidian、要么是空气，
 * 把这两个放前面能把 20 格的判据从 ~200 次 fill 压到 ~60 次。air 排第二**不会**误判——
 * 一个格子不可能既是 obsidian 又是 air。
 */
export const FRAME_SCAN_CANDIDATES = [
    'minecraft:obsidian',
    'minecraft:air',
    'minecraft:crying_obsidian',
    'minecraft:netherrack',
    'minecraft:lava',
    'minecraft:water',
    'minecraft:chest',
    'minecraft:trapped_chest',
    'minecraft:bedrock',
    'minecraft:cobblestone',
    'minecraft:magma_block',
    'minecraft:soul_soil',
    'minecraft:basalt',
    'minecraft:blackstone',
    'minecraft:sand',
    'minecraft:gravel',
    'minecraft:glass',
    'minecraft:glowstone',
    'minecraft:stone',
    'minecraft:dirt',
];

/** origin+axis 对应的"整片"包围盒（4×5×1） */
export function frameSlab(origin, axis) {
    const all = [...frameCells(origin, axis), ...interiorCells(origin, axis)].map((c) => c.pos);
    const xs = all.map((p) => p.x), ys = all.map((p) => p.y), zs = all.map((p) => p.z);
    return {
        x1: Math.min(...xs), y1: Math.min(...ys), z1: Math.min(...zs),
        x2: Math.max(...xs), y2: Math.max(...ys), z2: Math.max(...zs),
    };
}
// ---------------------------------------------------------------- 离线对账闸门
/**
 * B 线 r3 的服务端逐格真值表（`docs/MC-M1-TASK-08-r3.md` §2.1，证据
 * `bench/stages/portal/runs/P8R3_GEOM2/geom2_result.json`）。**服务端真值，不是推的。**
 *
 *   z=355      z=356          z=357        z=358
 * y=81  air    air            air          air
 * y=80  air    air            air          obsidian
 * y=79  obsid  air            air          obsidian
 * y=78  obsid  air            air          obsidian
 * y=77  obsid  crying_obsidian netherrack  obsidian
 *
 * 最佳候选：origin=(180,77,355) axis=z。B 线的判据读数：obsidian 7 / 缺 3 / 错块 2 / 内部脏 0。
 */
const R3_MAIN_GRID = {
    origin: { x: 180, y: 77, z: 355 },
    axis: 'z',
    grid: {
        81: { 355: 'air', 356: 'air', 357: 'air', 358: 'air' },
        80: { 355: 'air', 356: 'air', 357: 'air', 358: 'obsidian' },
        79: { 355: 'obsidian', 356: 'air', 357: 'air', 358: 'obsidian' },
        78: { 355: 'obsidian', 356: 'air', 357: 'air', 358: 'obsidian' },
        77: { 355: 'obsidian', 356: 'crying_obsidian', 357: 'netherrack', 358: 'obsidian' },
    },
    // B 线报告里的判据读数（用来对账"几何等价"，不是用来对账"补几格"——见下方注释）
    expect: { obsidian: 7, missingAir: 3, wrong: 2, dirty: 0, origin: { x: 180, y: 77, z: 355 }, axis: 'z' },
};

/** 把 r3 的表格还原成 blockAt 查表函数 */
export function r3MainBlockAt() {
    const { origin, axis, grid } = R3_MAIN_GRID;
    return (p) => {
        const u = axis === 'x' ? p.x - origin.x : p.z - origin.z;
        const dy = p.y - origin.y;
        if (p.x !== origin.x && p.z !== origin.z) return 'netherrack';   // 框外一律当别的方块
        const row = grid[p.y];
        return row ? (row[axis === 'x' ? p.x : p.z] ?? null) : null;
    };
}

/**
 * 与 B 线 r3 的离线对账。**返回逐条断言**，由调用方（`--parity` / 测试入口）决定是否抛错。
 *
 * ⚠ 顺带记录一处**口径出入**（不是我方移植错，是 B 报告 §2.1 的收尾那句少算了 1 格）：
 *   r3 判据读数 missing=3（三个必需格是空气：(180,80,355) 侧柱 + 顶行中间 2 格）、
 *   wrong=2 ⇒ 要让门可用，必须新放 **5** 块 obsidian；
 *   而 B 报告写的是「真正必须补齐的 = 2（错块）+ 2（顶行中间）= **4** 格 obsidian」，
 *   **漏掉了侧柱那一格空气 (180,80,355)**（required、non-optional）。
 *   下面的断言按**几何本身**（= 生产 frameCells）核对，期望 obsidianToPlace=5。
 */
export function parityWithTask08r3() {
    const { origin, axis, expect } = R3_MAIN_GRID;
    const r = checkFrame(origin, axis, r3MainBlockAt());
    const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
    const checks = [
        { name: 'obsidian(required 格) = 7', ok: r.obsidian === expect.obsidian, got: r.obsidian },
        { name: '缺格(空气) = 3', ok: r.missing.length === expect.missingAir, got: r.missing.length },
        { name: '错块 = 2', ok: r.wrong.length === expect.wrong, got: r.wrong.length },
        { name: '内部脏 = 0', ok: r.dirty.length === expect.dirty, got: r.dirty.length },
        { name: 'required 格数 = 12（14 减顶行两角）', ok: r.required === 12, got: r.required },
        { name: '补齐需新放 obsidian = 5（缺 3 + 错块 2）', ok: r.obsidianToPlace === 5, got: r.obsidianToPlace, note: 'B 报告写 4，少算侧柱空气 (180,80,355)' },
        { name: '最差的那个候选框必须被判"不可用"', ok: r.ok === false, got: r.ok },
        {
            name: '两处错块的 got 与 B 线一致',
            ok: eq(r.wrong.map((w) => w.got).sort(), ['crying_obsidian', 'netherrack']),
            got: r.wrong.map((w) => `${w.got}@${w.pos.join(',')}`),
        },
        {
            name: '缺格坐标与 B 线一致（侧柱 + 顶行中间）',
            ok: eq(r.missing.map((m) => m.pos.join(',')).sort(), ['180,80,355', '180,81,356', '180,81,357']),
            got: r.missing.map((m) => m.pos.join(',')),
        },
        {
            name: '内部 6 格全是空气 → 不触发 dirty',
            ok: interiorCells(origin, axis).length === 6 && r.dirty.length === 0,
            got: { interior: interiorCells(origin, axis).length, dirty: r.dirty.length },
        },
    ];
    return { checks, frame: r, r3: R3_MAIN_GRID, origin, axis };
}

if (process.argv[1] && /portal_frame\.mjs$/.test(process.argv[1])) {
    const p = parityWithTask08r3();
    console.log('=== portal_frame 与 B 线 r3 取证的离线对账 ===');
    for (const c of p.checks) {
        console.log(`  ${c.ok ? '✅' : '❌'} ${c.name}${c.note ? `  （注：${c.note}）` : ''}`);
    }
    const bad = p.checks.filter((c) => !c.ok);
    console.log(`判定：${p.checks.length - bad.length}/${p.checks.length}`);
    if (bad.length) process.exit(1);
}
