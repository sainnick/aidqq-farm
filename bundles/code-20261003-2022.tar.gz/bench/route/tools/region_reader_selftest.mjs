// region_reader_selftest.mjs — R6-3 解析器的**离线自检**（造合成 .mca，不碰服务器、不占端口）
//
// 【为什么必须自己造存档】本单所有"格式"问题都是**静默**的：布局头有无、位打包跨不跨 long、
//   y 偏移、空 section、实体坐标是局部还是绝对 —— 任何一条错，解析器都**不报错**，
//   只是安静地给出"看起来挺合理"的错数据（第一版就因为漏了 sec.Y 偏移，整块 chunk 读成同一个方块）。
//   而真存档只有一个种子、几个坐标，**没法穷举位宽**。合成存档能。
//
// 覆盖：
//   T1 NBT 写入→读取往返
//   T2 位打包边界：多档 palette 长度（bits 4/5/6/7/8/9/12）× {packed, linear} 逐格校验
//   T3 chunk 结构：多 section 的 y 偏移、空 section（无 BlockStates）当 air、未加载段当 unknown
//   T4 实体：Pos 是 chunk 局部坐标 ⇒ 必须换算成绝对；entitiesInBox / entitiesNear
//   T5 countInBox：只数指定方块名；未加载格计入 unknownCells 而不是当 air
//   T6 布局自探测：带 4 KiB 头 / 不带头、zlib / gzip
//   T7 交叉验证：能 import 到 prismarine-nbt 时，用它解同一份合成存档并比对键集合
//   T8 palette Properties（v1.1）：**同名不同状态必须分得开** —— 岩浆源 level=0 vs 流动 level≠0、
//      床的 part/facing；NBT 里 Properties 是字符串（`"0"` 不是 `0`）必须转型，否则判据静默失效；
//      blockAt 仍返回字符串（旧调用零影响）
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\region_reader_selftest.mjs

import fs from 'fs';
import os from 'os';
import path from 'path';
import zlib from 'zlib';
import { createRequire } from 'module';
import { openWorld, unpackBits, packBits, bitsForPalette, ceilLog2, writeNbt, NbtReader } from './region_reader.mjs';

let pass = 0, fail = 0;
const A = (n, c, x = '') => { if (c) { pass++; console.log(`  ✔ ${n}`); } else { fail++; console.log(`  ✘ ${n}${x ? ` — ${x}` : ''}`); } };
/** BigInt 安全的 JSON（1.16 的 Long tag 读出来是 bigint，JSON.stringify 会直接抛） */
const j = (v) => JSON.stringify(v, (k, x) => (typeof x === 'bigint' ? `${x}n` : x));
const eq = (n, got, want) => A(n, j(got) === j(want), `got=${j(got)} want=${j(want)}`);

/** 造一个单 chunk 的世界目录；`headerBytes` 决定有没有 4 KiB 头 */
function makeWorld(tmp, chunkNbt, { headerBytes = 0, cx = 0, cz = 0, compressionType = 2 } = {}) {
    const regionDir = path.join(tmp, 'region');
    fs.mkdirSync(regionDir, { recursive: true });
    const raw = writeNbt(chunkNbt, { rootName: '', rootType: 10 });
    const comp = compressionType === 1 ? zlib.gzipSync(raw) : zlib.deflateSync(raw);
    const dataStart = 8192;
    const payload = Buffer.alloc(4 + 1 + comp.length);
    // ⚠ 1.16 的 len 字段**含那个 type 字节**（实测：len=7264 / type=2 / 压缩数据 7263 字节）
    payload.writeInt32BE(comp.length + 1, 0);
    payload.writeUInt8(compressionType, 4);
    comp.copy(payload, 5);
    const file = Buffer.alloc(dataStart + 4096 + payload.length);
    const off = 2;                                            // sector 2 ⇒ 字节 8192
    const tb = headerBytes + (cx + cz * 32) * 4;
    file[tb] = (off >> 16) & 0xff; file[tb + 1] = (off >> 8) & 0xff; file[tb + 2] = off & 0xff;
    file[tb + 3] = Math.max(1, Math.ceil(payload.length / 4096));
    payload.copy(file, dataStart);
    fs.writeFileSync(path.join(regionDir, `r.${Math.floor(cx / 32)}.${Math.floor(cz / 32)}.mca`), file);
    return tmp;
}

console.log('T1 NBT 写入→读取往返');
{
    const v = { s: 'hello 世界', i: 42, l: 1234567890123n, d: 3.5, b: 7, list: [1, 2, 3], nested: { inner: 'x', arr: [1.25, 2.5] } };
    const buf = writeNbt(v, { rootName: 'R', rootType: 10 });
    const r = new NbtReader(buf).readRoot();
    eq('字符串往返', r.value.s, 'hello 世界');
    eq('int 往返', r.value.i, 42);
    eq('long 往返', r.value.l, 1234567890123n);
    eq('double 往返', r.value.d, 3.5);
    eq('byte 往返', r.value.b, 7);
    eq('list 往返', r.value.list, [1, 2, 3]);
    eq('嵌套 list 往返', r.value.nested.arr, [1.25, 2.5]);
    eq('完全消费（无错位）', r.bytesRead, buf.length);
    eq('根名', r.name, 'R');
}

console.log('\nT2 位打包边界（多档 palette 长度 × 两种模式，4096 格逐格校验）');
{
    for (const palLen of [2, 3, 5, 9, 17, 40, 300]) {
        const bits = bitsForPalette(palLen);
        const idx = Array.from({ length: 4096 }, (_, i) => (i * 7 + 3) % palLen);
        const back = unpackBits(packBits(idx, bits, 'packed'), bits, 'packed');
        const ok = idx.every((v, i) => back[i] === v);
        A(`paletteLen=${palLen} bits=${bits} packed 往返 4096/4096`, ok,
            ok ? '' : `首个不符 i=${idx.findIndex((v, i) => back[i] !== v)}`);
        const back2 = unpackBits(packBits(idx, bits, 'linear'), bits, 'linear');
        A(`paletteLen=${palLen} bits=${bits} linear 往返 4096/4096`, idx.every((v, i) => back2[i] === v));
    }
    // ⚠ 要证明"两种模式真的不同"，得**用错模式解**：两个模式各自 pack+unpack 都是对的
    //   （所以拿两个"各自往返"的结果比，永远相等 —— 我第一版就是这么写错的）。
    const bits6 = 6, palLen = 40;
    const idx = Array.from({ length: 4096 }, (_, i) => (i * 7 + 3) % palLen);
    const packedData = packBits(idx, bits6, 'packed');
    const linearData = packBits(idx, bits6, 'linear');
    A('两种模式的 long 数不同（packed 每 long 10 个、linear 连续位流）', packedData.length !== linearData.length,
        `packed=${packedData.length} linear=${linearData.length}`);
    const rightP = unpackBits(packedData, bits6, 'packed');
    const wrongL = unpackBits(packedData, bits6, 'linear');
    eq('packed 数据 + packed 解 ⇒ 正确', rightP[0], idx[0]);
    A('packed 数据 + linear 解 ⇒ **解错**（证明真存档必须判明是哪种布局）', wrongL.some((v, i) => v !== idx[i]));
    eq('ceilLog2(1)=0', ceilLog2(1), 0);
    eq('ceilLog2(40)=6', ceilLog2(40), 6);
    eq('bits 下限是 4（1.16 的 PackedIntegerArray）', bitsForPalette(2), 4);
    eq('bits 上限段：palette 300 ⇒ bits 9', bitsForPalette(300), 9);
}

console.log('\nT3-T6 合成世界端到端');
{
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rr-'));
    const idx0 = Array.from({ length: 4096 }, (_, i) => (i % 7 === 0 ? 1 : 0));
    const sec0 = { Y: 0, Palette: [{ Name: 'minecraft:stone' }, { Name: 'minecraft:air' }], BlockStates: packBits(idx0, 4, 'packed') };
    // y 段：i%11==0 → iron_ore(1)，否则 i%13==0 → air(2)，其余 andesite(0)
    const idx3 = Array.from({ length: 4096 }, (_, i) => {
        if (i % 11 === 0) return 1;
        if (i % 13 === 0) return 2;
        return 0;
    });
    const sec3 = { Y: 3, Palette: [{ Name: 'minecraft:andesite' }, { Name: 'minecraft:iron_ore' }, { Name: 'minecraft:air' }], BlockStates: packBits(idx3, 4, 'packed') };
    const secEmpty = { Y: 7 };                                   // 无 BlockStates / Palette ⇒ 1.16 的空 section 优化
    const entities = [
        { id: 'minecraft:sheep', Pos: [1.5, 65.0, 2.5] },        // **chunk 局部**坐标
        { id: 'minecraft:cow', Pos: [8.0, 66.0, 9.0] },
    ];
    const chunkNbt = { DataVersion: 2586, Level: { Sections: [secEmpty, sec0, sec3], Entities: entities, xPos: 0, zPos: 0, Status: 'full' } };
    makeWorld(tmp, chunkNbt, { headerBytes: 0, cx: 0, cz: 0 });
    const w = openWorld(tmp, { unpackMode: 'packed' });
    const info = w.chunkInfo(0, 0);
    A('合成 chunk 读到了', !!info);
    eq('DataVersion 透传', info.dataVersion, 2586);
    eq('只统计到 2 个有 BlockStates 的 section', info.sections, 2);
    eq('Y=0：y0 命中 i%7==0 ⇒ air', w.blockAt(0, 0, 0), 'air');
    eq('Y=0：y2 未命中 i%7 ⇒ stone', w.blockAt(0, 2, 0), 'stone');
    eq('Y=3：y48,x=0 命中 i%11 ⇒ iron_ore', w.blockAt(0, 48, 0), 'iron_ore');
    eq('Y=3：y48,x=1 两条件都未命中 ⇒ andesite', w.blockAt(1, 48, 0), 'andesite');
    eq('只有 Y 的空 section（Y=7 ⇒ y112）当 **air**（1.16 语义）', w.blockAt(0, 112, 0), 'air');
    eq('没有任何 section 覆盖的段（Y=4 ⇒ y64）当 **unknown** 而不是 air', w.blockAt(0, 64, 0), 'unknown');
    eq('区块外读不到 ⇒ unknown', w.blockAt(1000, 60, 1000), 'unknown');

    const ents = w.entitiesInBox({ x1: 0, y1: 0, z1: 0, x2: 15, y2: 127, z2: 15 }, ['sheep', 'cow']);
    eq('读到 2 个实体', ents.length, 2);
    eq('sheep 局部坐标已换算成绝对', ents.find((e) => e.id === 'sheep')?.pos, [1, 65, 2]);
    eq('entitiesNear(0,65,0,4,sheep) ⇒ 1（球形，sheep 在 (1,65,2)）', w.entitiesNear(0, 65, 0, 4, ['sheep']).length, 1);
    eq('entitiesNear(0,65,0,4,cow) ⇒ 0（cow 在 (8,66,9)，距离 12.4 > 4）', w.entitiesNear(0, 65, 0, 4, ['cow']).length, 0);
    eq('盒外找不到', w.entitiesInBox({ x1: 100, y1: 0, z1: 100, x2: 110, y2: 127, z2: 110 }, ['sheep']).length, 0);

    const cnt = w.countInBox({ x1: 0, y1: 0, z1: 0, x2: 15, y2: 15, z2: 15 }, ['stone', 'air']);
    eq('countInBox stone 计数（4096 格里 i%7!=0）', cnt.counts.stone, 4096 - Math.ceil(4096 / 7));
    eq('countInBox 把未加载段计入 unknownCells（不当 air）', cnt.unknownCells, 0);   // 本盒只取 y0..15，全被 Y=0 覆盖
    const cnt2 = w.countInBox({ x1: 0, y1: 60, z1: 0, x2: 15, y2: 70, z2: 15 }, ['stone']);
    eq('y60..70 里只有 y60..63 被 Y=3 覆盖，其余 7 层计入 unknownCells', cnt2.unknownCells, 16 * 16 * 7);

    const tmp2 = fs.mkdtempSync(path.join(os.tmpdir(), 'rr2-'));
    makeWorld(tmp2, chunkNbt, { headerBytes: 4096, cx: 0, cz: 0 });
    eq('带 4 KiB 头的存档也能读（布局自探测）', openWorld(tmp2, { unpackMode: 'packed' }).blockAt(0, 0, 0), 'air');

    const tmp3 = fs.mkdtempSync(path.join(os.tmpdir(), 'rr3-'));
    makeWorld(tmp3, chunkNbt, { headerBytes: 0, cx: 0, cz: 0, compressionType: 1 });
    eq('compression type=1（gzip）也能读', openWorld(tmp3, { unpackMode: 'packed' }).blockAt(0, 0, 0), 'air');

    const tmp4 = fs.mkdtempSync(path.join(os.tmpdir(), 'rr4-'));
    fs.mkdirSync(path.join(tmp4, 'region'), { recursive: true });
    fs.writeFileSync(path.join(tmp4, 'region', 'r.0.0.mca'), Buffer.alloc(0));
    eq('0 字节 region ⇒ unknown 而不是崩', openWorld(tmp4, {}).blockAt(0, 60, 0), 'unknown');
}

console.log('\nT7 交叉验证：prismarine-nbt 解同一份合成存档，比对键集合');
{
    let ok = false, note = '';
    try {
        const require = createRequire('file:///D:/AI斗蛐蛐/mindcraft/');
        const nbt = require('prismarine-nbt');
        const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rrx-'));
        const sec = { Y: 0, Palette: [{ Name: 'minecraft:stone' }], BlockStates: packBits(new Array(4096).fill(0), 4, 'packed') };
        makeWorld(tmp, { DataVersion: 2586, Level: { Sections: [sec], Entities: [], xPos: 0, zPos: 0 } }, { headerBytes: 0, cx: 0, cz: 0 });
        const region = fs.readFileSync(path.join(tmp, 'region', 'r.0.0.mca'));
        const off = (region.readUInt8(0) << 16) | (region.readUInt8(1) << 8) | region.readUInt8(2);
        const len = region.readInt32BE(off * 4096);
        const raw = zlib.inflateSync(region.subarray(off * 4096 + 5, off * 4096 + 4 + len));
        const mine = new NbtReader(raw).readRoot();
        // prismarine-nbt 2.8：`parseUncompressed(raw, proto.big)` 返回 `{type,name,value}` 包装结构，
        // 过 `simplify()` 才变成普通 JS 对象；它的 type 是字符串（'compound'），我的是 NBT 编号（10）⇒ 只比键。
        const theirs = nbt.simplify(nbt.parseUncompressed(raw, nbt.proto.big));
        const mk = JSON.stringify(Object.keys(mine.value).sort());
        const tk = JSON.stringify(Object.keys(theirs).sort());
        const lvlSame = JSON.stringify(Object.keys(mine.value.Level).sort()) === JSON.stringify(Object.keys(theirs.Level).sort());
        A('两个独立 NBT 实现：顶层键集合一致', mk === tk, `我的=${mk} 它的=${tk}`);
        A('两个独立 NBT 实现：Level 内部键集合也一致', lvlSame,
            `我的=${JSON.stringify(Object.keys(mine.value.Level).sort())} 它的=${JSON.stringify(Object.keys(theirs.Level).sort())}`);
        ok = true; note = '一致';
    } catch (e) { ok = false; note = `交叉验证未跑通：${String(e).slice(0, 100)}`; }
    A('两个独立 NBT 实现对同一份存档给出一致的键集合', ok, note);
}

console.log('\nT8 palette Properties：同名不同状态必须分得开（v1.1）');
{
    // 派单的阳性对照形态：**同名 lava** 的两种状态并存于同一个 section。
    // 1.16 语义：level=0 是**源块**、level≠0 是流动。真实存档里 Properties 全是字符串，
    // 这里刻意按真实写法喂字符串（writeNbt 的 typeOf 也会把 "0" 判成 string）。
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rrp-'));
    const idx = Array.from({ length: 4096 }, () => 0);
    // x=0 ⇒ 源块(level=0)；x=1 ⇒ 流动(level=8)；x=2 ⇒ 流动(level=1)；x=3 ⇒ 水源
    idx[0 + 0 * 16 + 0 * 256] = 0;
    idx[1 + 0 * 16 + 0 * 256] = 1;
    idx[2 + 0 * 16 + 0 * 256] = 2;
    idx[3 + 0 * 16 + 0 * 256] = 3;
    const pal = [
        { Name: 'minecraft:lava', Properties: { level: '0' } },
        { Name: 'minecraft:lava', Properties: { level: '8' } },
        { Name: 'minecraft:lava', Properties: { level: '1' } },
        { Name: 'minecraft:water', Properties: { level: '0' } },
    ];
    const sec = { Y: 0, Palette: pal, BlockStates: packBits(idx, 4, 'packed') };
    // 第二段放床：验证**非液体**状态（part/facing）也读得到
    const bedIdx = Array.from({ length: 4096 }, () => 0);
    bedIdx[0 + 0 * 16 + 0 * 256] = 0;   // foot
    bedIdx[1 + 0 * 16 + 0 * 256] = 1;   // head
    bedIdx[2 + 0 * 16 + 0 * 256] = 2;   // 空床：只有 occupied，无 part
    const secBed = {
        Y: 1,
        Palette: [
            { Name: 'minecraft:red_bed', Properties: { part: 'foot', facing: 'north', occupied: 'false' } },
            { Name: 'minecraft:red_bed', Properties: { part: 'head', facing: 'north', occupied: 'false' } },
            { Name: 'minecraft:red_bed', Properties: { facing: 'north', occupied: 'true' } },
        ],
        BlockStates: packBits(bedIdx, 4, 'packed'),
    };
    makeWorld(tmp, { DataVersion: 2586, Level: { Sections: [sec, secBed], Entities: [], xPos: 0, zPos: 0 } }, { headerBytes: 0, cx: 0, cz: 0 });
    const w = openWorld(tmp, { unpackMode: 'packed' });

    // ---- 关键判据：源块与流动**必须分得开**（派单点名） ----
    const src = w.blockState(0, 0, 0);
    const flow8 = w.blockState(1, 0, 0);
    const flow1 = w.blockState(2, 0, 0);
    eq('源块 name', src.name, 'lava');
    eq('源块 level（字符串 "0" 已转成数字）', src.props.level, 0);
    eq('流动 level=8', flow8.props.level, 8);
    eq('流动 level=1', flow1.props.level, 1);
    A('**源块与流动是不同状态**（level 0 vs 非 0）', src.props.level === 0 && flow8.props.level !== 0);
    A('两种流动的 level 也不相同（1 vs 8）', flow1.props.level !== flow8.props.level);
    A('**判"是不是源块"的两条判据都成立**',
        [flow8, flow1].every((s) => !(s.props.level === 0)) && src.props.level === 0);

    // ---- 反向对照：光看名字分不开（否则这条用例是空转的） ----
    A('光看名字确实分不开（三格都叫 lava）',
        src.name === flow8.name && flow8.name === flow1.name && 'lava' === 'lava');

    // ---- 字符串陷阱：`"0" === 0` 是 false，必须转成数字才能判源块 ----
    A('props.level 是 **number** 不是 string（否则 `=== 0` 永远 false）',
        typeof src.props.level === 'number' && typeof flow8.props.level === 'number');
    A('若不转型则判据会静默失效（演示 `"0" === 0` 为 false）', ('0' === 0) === false);

    // ---- 床：非液体状态 ----
    const foot = w.blockState(0, 16, 0);
    const head = w.blockState(1, 16, 0);
    const empty = w.blockState(2, 16, 0);
    eq('床脚 part', foot.props.part, 'foot');
    eq('床头 part', head.props.part, 'head');
    A('床头能分出 part（床占 2 格，只看名字会当成 2 张独立床）', head.props.part === 'head' && foot.props.part === 'foot');
    eq('床 facing 透传', foot.props.facing, 'north');
    eq('occupied 转成 boolean', empty.props.occupied, true);
    A('occupied 是 boolean 不是字符串 "true"', typeof empty.props.occupied === 'boolean');
    A('**床头没有 part 字段时是 undefined 而不是字符串**', !('part' in empty.props));

    // ---- 向后兼容：blockAt 仍返回名字字符串（旧调用零影响） ----
    eq('blockAt 仍返回字符串（旧调用不受影响）', w.blockAt(0, 0, 0), 'lava');
    A('blockAt 返回的是 string 类型', typeof w.blockAt(0, 0, 0) === 'string');
    A('blockAt 对床也仍是裸名', w.blockAt(0, 16, 0) === 'red_bed');
    eq('blockAt 读不到时仍是 "unknown" 字符串', w.blockAt(0, 64, 0), 'unknown');
    eq('blockState 读不到时 name 仍是 unknown', w.blockState(0, 64, 0).name, 'unknown');
    A('blockState 读不到时 props 为 null', w.blockState(0, 64, 0).props === null);

    // ---- 无 Properties 的普通方块：props 为 null，不能是 {} ----
    const tmpPlain = fs.mkdtempSync(path.join(os.tmpdir(), 'rrq-'));
    const secPlain = { Y: 0, Palette: [{ Name: 'minecraft:stone' }], BlockStates: packBits(new Array(4096).fill(0), 4, 'packed') };
    makeWorld(tmpPlain, { DataVersion: 2586, Level: { Sections: [secPlain], Entities: [], xPos: 0, zPos: 0 } }, { headerBytes: 0, cx: 0, cz: 0 });
    const wp = openWorld(tmpPlain, { unpackMode: 'packed' });
    eq('无 Properties 的方块 props 为 null（区分得开"没有状态"）', wp.blockState(0, 0, 0).props, null);
    eq('名字照常', wp.blockState(0, 0, 0).name, 'stone');

    // ---- countInBox / chunkInfo 不因 palette 结构变化而坏 ----
    const cnt = w.countInBox({ x1: 0, y1: 0, z1: 0, x2: 3, y2: 0, z2: 0 }, ['lava']);
    eq('countInBox 按名字仍数得对 3 格 lava', cnt.counts.lava, 3);
    const info = w.chunkInfo(0, 0);
    // ⚠ chunkInfo 数的是**整个 chunk**（y0..15 全 16 层 + y16..31）。默认下标 0 = 源块 lava，
    //   所以 lava 是 4095 格（每层 4096 格里换掉 1 格）× 16 层 − 4；这里只断言"直方图仍然出得来、
    //   且值是 number"，具体总数不作为判据（那是造数据的事，不是解析的事）。
    A('chunkInfo 仍能出直方图（palette 元素改成对象后没坏）',
        typeof info.hist.lava === 'number' && info.hist.lava > 0
        && typeof info.hist.red_bed === 'number' && info.hist.red_bed > 0
        && info.hist.water === 1,
        JSON.stringify(info.hist));
}

console.log(`\n${fail === 0 ? '✅' : '❌'} 自检 ${pass} 通过 / ${fail} 失败`);
process.exit(fail === 0 ? 0 : 1);
