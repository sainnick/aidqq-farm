// r7c_route_guard_run.mjs — ROUND7-C 续单：**route_guard 的命令行外壳**
//
// 【为什么需要这个文件】`bench/stages/fullrun/route_guard.mjs` 是**库**（只有 export，没有顶层 CLI 调用），
//   直接 `node route_guard.mjs` 会**静默空跑、退出码 0、一行输出都没有** ——
//   看起来像"通过"，其实是"什么都没做"（与本线 ROUND7-C 上一版记的
//   「中文路径下 import.meta.url === argv[1] 恒不相等 ⇒ 静默空跑」同一类）。
//   ⇒ 本文件显式 import 它、显式打印 violations 条数，并**在非 0 条时以非 0 退出码失败**，
//      让"通过"和"没跑"在 CI/人工核对时无法混淆。
//
// 用法：node r7c_route_guard_run.mjs [routeFile]
//   默认 bench/route/4926685115947721762.json；该文件是**草稿**（frozenAt=null）⇒ 默认 --allow-draft。

import path from 'path';
import { fileURLToPath } from 'url';
import { checkRouteIntegrity, readRouteFile, routeSha256 } from '../../stages/fullrun/route_guard.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE_DIR = path.resolve(HERE, '..');
const argOf = (a, n, d) => { const i = a.indexOf('--' + n); return i >= 0 ? a[i + 1] : d; };

const FILE = path.resolve(argOf(process.argv, 'file', path.join(ROUTE_DIR, '4926685115947721762.json')));
const allowDraft = !process.argv.includes('--require-frozen');

const r = checkRouteIntegrity(FILE, { allowDraft, requireFrozen: !allowDraft });

console.log(`文件        ：${r.file}`);
console.log(`规范 sha256 ：${r.sha256}`);
console.log(`原始 sha256 ：${r.rawSha256}`);
console.log(`frozenAt    ：${r.frozenAt}（frozen=${r.frozen}）${allowDraft ? '  [按草稿放行]' : ''}`);
console.log(`sha256File  ：${r.sha256File}`);
console.log(`ok          ：${r.ok}${r.reason ? '  reason=' + r.reason : ''}`);
console.log(`violations  ：**${r.violations.length}** 条`);
for (const v of r.violations) console.log('   - ' + (typeof v === 'string' ? v : JSON.stringify(v)));

// 顺带把站级区（运行区）列出来，方便核对"station 一个字没动"
const doc = readRouteFile(FILE).doc;
console.log(`\n站级区摘要（运行区，只读不改）：`);
for (const s of doc.stations) {
    console.log(`   ${String(s.seq).padStart(2)} ${s.id.padEnd(24)} ${s.dim.padEnd(11)} center=${JSON.stringify(s.station.center)} r=${s.station.radius} yHint=${s.station.yHint}`);
}
console.log(`\nnormalFlowStations : ${JSON.stringify(doc.normalFlowStations ?? null)}`);
console.log(`fallbackOnlyStations: ${JSON.stringify(doc.fallbackOnlyStations ?? null)}`);

if (r.violations.length) {
    console.error(`\n✗ ${r.violations.length} 条 violation —— 不算通过`);
    process.exit(1);
}
console.log(`\n✅ 0 violations（口径：checkRouteIntegrity，allowDraft=${allowDraft}）`);
console.log(`   复核用哈希：sha256(route) = ${routeSha256(doc)}`);
