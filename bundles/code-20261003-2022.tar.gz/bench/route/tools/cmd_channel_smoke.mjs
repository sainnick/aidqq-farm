// cmd_channel_smoke.mjs — **1.16.1 服务器到底能用哪些"条件真值"回读通道**（一次性冒烟，兼做回归护栏）
//
// 为什么要有这个文件（本单踩出来的）：我原先用
//     execute if block x y z <block> run say CELLPROBE ...
// 做逐格读方块。实测 1.16.1 **根本没有 `/say` 命令**（它是 1.17 才加的）——于是每条命令都解析失败，
// 服务器把**带 `<--[HERE]` 错误标记的命令回显**打进控制台；而我的解析器按 token/格号去匹配那行回显，
// 于是**把失败当成了命中**，读出"每格都是 air"。整份框体判定（obsidian 0/12）就是这么来的。
//
// 本文件把结论钉死，并**在离线自测里断言它**（`SMOKE_FINDINGS`）：
//   ① `run say`            → 1.16.1 不可用（未知子命令）
//   ② `run tellraw @a`     → 1.16.1 可用（1.13 起有 tellraw），输出带 `[CHAT]` 前缀
//   ③ `if block …[state]`  → 可用（方块状态判据）
//   ④ `fill … replace <block>[state]` → 可用（已由岩浆站实测： lava[level=0] 粗扫 3499）
//
// 用法：node cmd_channel_smoke.mjs        （会开泳道 C 的服，约 1 分钟）

import { bootLaneC, shutdownLaneC, portState } from './console.mjs';

/** 结论表：cell_probe / gen_route 都按这张表选通道，改动前先跑这个冒烟。 */
export const SMOKE_FINDINGS = {
    say: false,          // 1.16.1 无 /say
    tellraw: true,       // 1.16.1 用 tellraw @a {"text":"…"}
    ifBlockState: true,  // if block 认方块状态
    fillReplaceState: true,
};

let handle = null;
try {
    handle = await bootLaneC({ seed: '-8839485814800629942', runDir: 'bench/route/probe/_run_cmdsmoke', logFn: console.log });
    const con = handle.con;
    const p = { x: 180, y: 77, z: 355 };     // 主种子废弃门框底角那格（air）
    const token = 'SMOKE';
    const probes = [
        { id: 'say-stone', cmd: `execute if block ${p.x} ${p.y} ${p.z} minecraft:stone run say ${token} say-stone` },
        { id: 'say-air', cmd: `execute if block ${p.x} ${p.y} ${p.z} minecraft:air run say ${token} say-air` },
        { id: 'tellraw-stone', cmd: `execute if block ${p.x} ${p.y} ${p.z} minecraft:stone run tellraw @a {"text":"${token} tellraw-stone"}` },
        { id: 'tellraw-air', cmd: `execute if block ${p.x} ${p.y} ${p.z} minecraft:air run tellraw @a {"text":"${token} tellraw-air"}` },
        { id: 'tellraw-state', cmd: `execute if block ${p.x} ${p.y} ${p.z} minecraft:lava[level=0] run tellraw @a {"text":"${token} tellraw-state"}` },
        { id: 'tellraw-plane', cmd: `execute if block ${p.x} ${p.y} ${p.z} ${p.x + 1} ${p.y} ${p.z} minecraft:air run tellraw @a {"text":"${token} tellraw-plane"}` },
    ];
    for (const q of probes) con.cmd(q.cmd);
    await new Promise((r) => setTimeout(r, 2500));
    const lines = con.drain();
    console.log('--- 控制台原始输出 ---');
    for (const l of lines) console.log('   ', l);
    const sayLines = lines.filter((l) => new RegExp(`${token} say-`).test(l));
    const trLines = lines.filter((l) => new RegExp(`${token} tellraw-`).test(l));
    const withHere = lines.filter((l) => /<--\[HERE\]/.test(l));
    console.log('\n--- 判定 ---');
    console.log(`run say 命中行 = ${sayLines.length}（预期 0）`);
    console.log(`run tellraw 命中行 = ${trLines.map((l) => l.match(/tellraw-\w+/)?.[0]).filter(Boolean).join(', ') || '(无)'}`);
    console.log(`解析失败回显(带 <--[HERE]>) = ${withHere.length} 条：`);
    for (const l of withHere.slice(0, 4)) console.log('    ', l.slice(0, 150));
    console.log(`\n结论：say=${sayLines.length === 0 ? '不可用（应改用 tellraw）' : '可用'}；tellraw=${trLines.length > 0 ? '可用' : '不可用'}`);
} catch (e) {
    console.error('✗ 冒烟失败：', e && e.stack ? e.stack : e);
    process.exitCode = 1;
} finally {
    await shutdownLaneC(handle);
    console.log(`收工：端口 ${JSON.stringify(portState())}`);
}
