// split_test.mjs — MC-ROUTE-02：八叉细分 splitBox 的纯函数单测（离线、毫秒级）
//
// 为什么必须有这个测试：`descend()` 的正确性完全建立在「细分后的子盒互不重叠、
// 且恰好覆盖母盒」之上。这两条一旦不成立，下钻就会漏格或重复计数——
// 而重复计数的症状是**下钻点数 > 粗扫计数**，看起来像"数据更好"，实际是错的坐标。
// 实测就中过招（要塞：粗扫 spawner=2、下钻报 130），所以把它钉成单测而不是靠肉眼审。
//
// 用法：node bench/route/tools/split_test.mjs

import { splitBox } from './scan.mjs';

let pass = 0, fail = 0;
const failures = [];
const check = (name, cond, extra = '') => { if (cond) pass++; else { fail++; failures.push(`${name}${extra ? ` — ${extra}` : ''}`); } };

/** 递归细分到体积 1，返回全部叶子 */
function leaves(b, depth = 0) {
    const vol = (b.x2 - b.x1 + 1) * (b.y2 - b.y1 + 1) * (b.z2 - b.z1 + 1);
    if (vol === 1) return [{ x: b.x1, y: b.y1, z: b.z1, depth }];
    return splitBox(b).flatMap((s) => leaves(s, depth + 1));
}

const CASES = [
    { name: '实测那个门室盒 32×16×32', box: { x1: 176, y1: 72, z1: 352, x2: 207, y2: 87, z2: 383 } },
    { name: '1×1×1', box: { x1: 0, y1: 0, z1: 0, x2: 0, y2: 0, z2: 0 } },
    { name: '2×3×1（X/Y 非 2 次幂、Z 退化）', box: { x1: 0, y1: 0, z1: 0, x2: 1, y2: 2, z2: 0 } },
    { name: '5×1×1（X 奇数）', box: { x1: -3, y1: 7, z1: 11, x2: 1, y2: 7, z2: 11 } },
    { name: '4×4×4', box: { x1: 0, y1: 0, z1: 0, x2: 3, y2: 3, z2: 3 } },
    { name: '负坐标 32×16×32', box: { x1: -55, y1: 52, z1: 825, x2: -24, y2: 67, z2: 856 } },
    { name: '3×3×3（奇数×3）', box: { x1: 10, y1: 20, z1: 30, x2: 12, y2: 22, z2: 32 } },
];

for (const { name, box } of CASES) {
    const vol = (box.x2 - box.x1 + 1) * (box.y2 - box.y1 + 1) * (box.z2 - box.z1 + 1);
    const ls = leaves(box);
    const keys = ls.map((p) => `${p.x},${p.y},${p.z}`);
    const uniq = new Set(keys);
    const inRange = ls.every((p) => p.x >= box.x1 && p.x <= box.x2 && p.y >= box.y1 && p.y <= box.y2 && p.z >= box.z1 && p.z <= box.z2);
    const depthOk = Math.max(...ls.map((l) => l.depth)) <= Math.ceil(Math.log2(Math.max(
        box.x2 - box.x1 + 1, box.y2 - box.y1 + 1, box.z2 - box.z1 + 1)));
    check(`${name}：叶子数 == 体积`, ls.length === vol, `${ls.length} vs ${vol}`);
    check(`${name}：叶子互不重叠`, uniq.size === ls.length, `${uniq.size} vs ${ls.length}`);
    check(`${name}：叶子都在母盒内`, inRange);
    check(`${name}：细分深度不超 log2(最长边)`, depthOk, `maxDepth=${Math.max(...ls.map((l) => l.depth))}`);
}

// 单层切分也要验（递归正确不代表单层切分不重叠）
for (const { name, box } of CASES) {
    const subs = splitBox(box);
    const vol = (box.x2 - box.x1 + 1) * (box.y2 - box.y1 + 1) * (box.z2 - box.z1 + 1);
    const sumVol = subs.reduce((a, s) => a + (s.x2 - s.x1 + 1) * (s.y2 - s.y1 + 1) * (s.z2 - s.z1 + 1), 0);
    const keys = new Set(subs.map((s) => `${s.x1}-${s.x2},${s.y1}-${s.y2},${s.z1}-${s.z2}`));
    check(`${name}：单层子盒体积之和 == 母盒体积`, sumVol === vol, `${sumVol} vs ${vol}`);
    check(`${name}：单层子盒无重复`, keys.size === subs.length, `${keys.size} vs ${subs.length}`);
    check(`${name}：单层子盒都在母盒内`, subs.every((s) => s.x1 >= box.x1 && s.x2 <= box.x2 && s.y1 >= box.y1 && s.y2 <= box.y2 && s.z1 >= box.z1 && s.z2 <= box.z2));
    check(`${name}：单层子盒体积 > 0（无退化盒）`, subs.every((s) => (s.x2 - s.x1 + 1) * (s.y2 - s.y1 + 1) * (s.z2 - s.z1 + 1) > 0));
}

for (const f of failures) console.log(`  ✗ ${f}`);
console.log(`[split_test] ${pass} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
