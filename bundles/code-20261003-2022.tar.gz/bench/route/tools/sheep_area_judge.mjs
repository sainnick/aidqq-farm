// sheep_area_judge.mjs — R6-3 第二轮：**S0_sheep 的干净判读**（两个 fresh world，羊区不 summon）
//
// 【为什么重做】ROUND6 第一轮把召唤的 3 只羊放在**统计区里**做实体阳性对照，而**羊会游走**，
//   于是两个 world 的"羊坐标"必然不一致、统计的是"召唤羊 + 自然羊"的混合体 ⇒ 判读作废。
//   本版：召唤点挪到**羊区外 300 格的对照区**（两区互不重叠），实体阳性对照照做，统计区只放自然羊。
//
// 【判据（设计会话）】一致且非空 ⇒ REAL（center 取离 S1 最近的那群）；
//   两边都是 0 ⇒ 记「自然羊 = 0」，S0_sheep 改标 NOT_PRESENT 并停下报告；不一致 ⇒ 保持 UNVERIFIED。
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\sheep_area_judge.mjs \
//         --world-a <存档A> --world-b <存档B>

import fs from 'fs';
import path from 'path';
import { argOf, log } from '../../stages/_lib/runner_core.mjs';
import { openWorld } from './region_reader.mjs';
import { ROUTE_DIR } from './console.mjs';

const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const A = argOf(process.argv, 'world-a', path.join(PROBE_DIR, '_sheepA'));
const B = argOf(process.argv, 'world-b', path.join(PROBE_DIR, '_sheepB'));
const OUT = path.join(PROBE_DIR, 'sheep_ab.round6c.json');

const SPAWN = { x: 216, z: 224 };
const S1 = { x: 176, z: 304 };
/** 统计区：出生点周边 16×16 区块（派单要求 ≥16×16） */
const AREA = { x1: SPAWN.x - 128, y1: 0, z1: SPAWN.z - 128, x2: SPAWN.x + 128, y2: 255, z2: SPAWN.z + 128 };
/** 放大框：向外扩 32 格，用来确认"羊 0"不是取样框太小造成的 */
const AREA_BIG = { x1: AREA.x1 - 32, y1: 0, z1: AREA.z1 - 32, x2: AREA.x2 + 32, y2: 255, z2: AREA.z2 + 32 };
/** 对照区：羊区外 300 格，实体阳性对照（summon 的 3 只羊）在这里 */
const CTRL = { x1: SPAWN.x + 300 - 32, y1: 0, z1: SPAWN.z - 32, x2: SPAWN.x + 300 + 32, y2: 255, z2: SPAWN.z + 32 };

const PASSIVES = ['sheep', 'cow', 'pig', 'chicken', 'horse', 'wolf', 'turtle', 'cat'];

function survey(dir) {
    const w = openWorld(dir, { unpackMode: 'packed' });
    const inArea = w.entitiesInBox(AREA, null);
    const inBig = w.entitiesInBox(AREA_BIG, null);
    const ctrl = w.entitiesInBox(CTRL, ['sheep']);
    const cnt = (list, t) => list.filter((e) => e.id === t).length;
    const kinds = {};
    for (const e of inArea) kinds[e.id] = (kinds[e.id] ?? 0) + 1;
    return {
        dir,
        sheep: inArea.filter((e) => e.id === 'sheep').map((e) => e.pos).sort(compare),
        sheepInBig: cnt(inBig, 'sheep'),
        area: Object.fromEntries(PASSIVES.map((t) => [t, cnt(inArea, t)])),
        big: Object.fromEntries(PASSIVES.map((t) => [t, cnt(inBig, t)])),
        areaTotal: inArea.length,
        kinds,
        // 实体阳性对照：对照区里 summon 的羊（x/z 应与 summon 点一致，y 可能掉下去）
        controlSheep: ctrl.map((e) => e.pos).sort(compare),
    };
}
const compare = (a, b) => a[0] - b[0] || a[2] - b[2];
const key = (p) => p.join(',');

const out = { schema: 'aidqq-round6c-sheep-ab/1', at: new Date().toISOString(), area: AREA, areaBig: AREA_BIG, control: CTRL, s1: S1 };

const a = survey(A);
const b = survey(B);
out.worldA = a; out.worldB = b;

const setA = new Set(a.sheep.map(key));
const setB = new Set(b.sheep.map(key));
const coordsSame = setA.size === setB.size && [...setA].every((k) => setB.has(k));
out.gates = {
    entityPositiveControl: a.controlSheep.length > 0 && b.controlSheep.length > 0,
    coordsSame,
    sheepCountA: setA.size, sheepCountB: setB.size,
    sheepInBigA: a.sheepInBig, sheepInBigB: b.sheepInBig,
};

if (!out.gates.entityPositiveControl) {
    out.status = 'CHANNEL_BROKEN';
    out.conclusion = '实体阳性对照失败（对照区读不到 summon 的羊）⇒ 解析器读不出实体，不产出任何结论。';
} else if (setA.size === 0 && setB.size === 0) {
    out.status = 'NOT_PRESENT';
    out.conclusion = '两个 fresh world 的羊区**都没有自然生成的羊**（放大框里也各为 '
        + `${a.sheepInBig} / ${b.sheepInBig}）⇒ 记「自然羊 = 0」，S0_sheep 改标 NOT_PRESENT，停下报告。`;
    out.evidence = {
        areaCountsA: a.area, areaCountsB: b.area,
        note: '同一采样区里 cow/pig/chicken/horse/wolf/turtle/cat 都稳定存在 ⇒ 生成机制正常、通道正常，'
            + '唯独羊为 0 ⇒ 这是**这个种子的这块地**的实情，不是工具或通道的问题。',
    };
} else if (setA.size > 0 && coordsSame) {
    const d = (p) => Math.hypot(p[0] - S1.x, p[2] - S1.z);
    const best = [...a.sheep].sort((p, q) => d(p) - d(q))[0];
    out.status = 'REAL';
    out.center = [Math.round(best[0] / 8) * 8, Math.round(best[2] / 8) * 8];
    out.nearest = { pos: best, distToS1: Math.round(d(best)) };
    out.conclusion = `两个 fresh world 的羊坐标完全一致（各 ${setA.size} 只）⇒ 由种子决定 ⇒ 标 REAL；`
        + `center 取离 S1 最近的那群 @(${best.join(',')})（距 S1 ${Math.round(d(best))} 格，8 格对齐后 [${out.center}]）`;
} else {
    out.status = 'INCONCLUSIVE';
    out.conclusion = `羊坐标不一致（A ${setA.size} / B ${setB.size}）⇒ 保持 UNVERIFIED，停下报告。`;
}

fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
log(`实体阳性对照 ${out.gates.entityPositiveControl ? '✅' : '❌'}｜羊 A=${setA.size} B=${setB.size}（放大框 ${a.sheepInBig}/${b.sheepInBig}）`);
log(`其它被动（A 区）: ${JSON.stringify(a.area)}`);
log(`其它被动（B 区）: ${JSON.stringify(b.area)}`);
log(`【结论】${out.status}：${out.conclusion}`);
log(`落盘：${path.relative(process.cwd(), OUT)}`);
