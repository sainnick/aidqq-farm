// v2_extract_s5_c3_s3.mjs — ROUND8-C：为 aidqq-route/2 的 `exact` 块抽取 **S5 / C3 / S3** 三站的
// L0 精确坐标。**纯离线，只读存档**（region_reader.mjs）；不开服、不发任何 fill/summon、不碰端口。
//
// 【为什么是这��单】SCHEMA §5 硬规矩：「`exact` 里每个坐标必须来自存档解析器或实跑真值（手册 §5），
//   并写明证据路径；**没有证据的坐标不许进 v2**。」本文件是"证据生成器"：每个要吐出来的坐标
//   **在 emit 的那一刻重新读一遍存档**，读不回它声称的方块就**丢掉并进 rejected**（不硬塞进 v2）。
//
// 【复用了谁，几何逻辑一行没重写】
//   - S5 框环 / 门室空气分量 / 4 扇门 → `s5_portal_room.mjs` + `s5_room_doors.mjs` 的判据与坐标推导
//     （框环中心上方 fy+1 取种子、6 连通泛洪、`props.half==='lower'` 只记下扇、门"外侧"= R+2*delta）
//   - C3 站位判据 → `fortress_standing.round5c.json` 的 `criterion` 字段逐字实现
//   - S3 金源普查 / 暴露面 → `s3_bastion_gold_piglins.mjs`（含"先看 palette 直方图再逐格"的加速法）
//   - 空气集 / 建筑高度 → `visibility_audit.mjs` 的 `AIRLIKE` / `AIR_STRICT` / `BUILD_HEIGHT`
//
// 【手册 §4.11 + §5 阳性对照（先证伪工具，再信 0）】
//   每个扫描体都打印 terrain control（该体里最常见的几个方块）+ `unknownCells`。
//   **`unknownCells` 必须为 0** —— `blockAt` 返回 `'unknown'` = 那一段没 section / 区块没存盘，
//   那是"没读到"，绝不能当 air（区域_reader 的硬规矩）。非 0 就不发坐标，只报"存档没覆盖这一片"。
//
// 用法：node v2_extract_s5_c3_s3.mjs [--out <path>]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from './region_reader.mjs';
import { AIRLIKE, AIR_STRICT, BUILD_HEIGHT } from './visibility_audit.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));   // ⚠ 绝不用 new URL(...).pathname（Windows 上静默坏掉）
const ROUTE_DIR = path.resolve(HERE, '..');
const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const argOf = (a, n, d) => { const i = a.indexOf('--' + n); return (i >= 0 && a[i + 1] && !a[i + 1].startsWith('--')) ? a[i + 1] : d; };
const OUT = path.resolve(argOf(process.argv, 'out', path.join(PROBE_DIR, 'v2_s5_c3_s3_exact.json')));

const SEED = '4926685115947721762';
const MCV = '1.16.1';
const OVERWORLD_S5 = path.join(PROBE_DIR, '_s5_s5');
const NETHER_C3 = path.join(PROBE_DIR, '_nether_corridor');
const NETHER_S3 = path.join(PROBE_DIR, '_s3_easy');

const N6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const N4 = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];       // 四侧（水平）
const FACES = [[1, 0, 0, '+x'], [-1, 0, 0, '-x'], [0, 1, 0, '+y'], [0, -1, 0, '-y'], [0, 0, 1, '+z'], [0, 0, -1, '-z']];
const HAZARD = new Set(['lava', 'magma_block', 'fire', 'soul_fire', 'nether_portal']);
const keyOf = (x, y, z) => `${x},${y},${z}`;
const r1 = (n) => Math.round(n * 10) / 10;
const d3 = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

/** 读不回就是读不回：`unknown` 一律不当 air（手册 §5 / 区域_reader 硬规矩） */
function mkGet(w, dim, box) {
    return (x, y, z) => {
        if (x < box.x1 || x > box.x2 || y < box.y1 || y > box.y2 || z < box.z1 || z > box.z2) return 'unknown';
        return w.blockAt(x, y, z, dim);
    };
}
const isSolid = (get, x, y, z) => { const b = get(x, y, z); return b !== 'unknown' && !AIRLIKE.has(b) && b !== 'water' && b !== 'lava' && b !== 'fire'; };

/** terrain control + unknownCells（手册 §4.11 / §5：先证伪工具再信 0） */
function volumeControl(w, dim, box, label) {
    const h = w.countInBox(box, null, dim);
    const unknown = h.counts.unknown ?? 0;
    delete h.counts.unknown;
    const top = Object.entries(h.counts).sort((a, b) => b[1] - a[1]).slice(0, 10);
    return {
        label, box, cells: h.cells, unknownCells: h.unknownCells + unknown,
        readableRatio: Number((1 - (h.unknownCells + unknown) / Math.max(1, h.cells)).toFixed(6)),
        terrainControl: Object.fromEntries(top),
        toolFailed: (h.cells - h.unknownCells - unknown) === 0,
        ok: (h.unknownCells + unknown) === 0,
    };
}

const rejected = [];
/** emit 前的最后一道闸：声称的坐标必须当场读回它声称的方块，否则丢掉并记账 */
function confirm(w, dim, xyz, expectName, expectProp, wantValue, station, why) {
    const st = w.blockState(xyz[0], xyz[1], xyz[2], dim);
    if (st.name === 'unknown') { rejected.push({ station, xyz, claimed: expectName, reason: `UNREADABLE（存档里没有这一格/这一段 section）—— 手册 §5「没读到 ≠ 没有」`, wanted: why }); return null; }
    if (st.name !== expectName) { rejected.push({ station, xyz, claimed: expectName, readBack: st.name, reason: `读回方块名与声称不符（${st.name} ≠ ${expectName}）—— 不进 v2`, wanted: why }); return null; }
    if (expectProp) {
        const got = st.props ? st.props[expectProp] : undefined;
        if (got !== wantValue) { rejected.push({ station, xyz, claimed: `${expectName}.${expectProp}=${wantValue}`, readBack: `${expectName}.${expectProp}=${got}`, reason: '方块状态读回与声称不符 —— 不进 v2', wanted: why }); return null; }
    }
    return { name: st.name, props: st.props };
}

const out = {
    schema: 'aidqq-route-v2-exact-extract/1',
    at: new Date().toISOString(),
    seed: SEED, mcVersion: MCV, dimAliases: { overworld: 'overworld', the_nether: 'DIM-1' },
    standSemantics: '`exact.stand[i]` = **脚下那格坐标（玩家踩着的那一格的方块坐标）**，即身体格的 y-1。'
        + 'SCHEMA §5 原文就是"作业站位（按优先级），**脚下那格坐标**"，且与 bench/route/probe/fortress_standing.round5c.json 的 '
        + '`cover.stands[].pos` 口径一致（它记的 [220,69,-87] 是地面块，玩家实际站在 y=70）。'
        + '⚠ **各历史探针口径不一致，本单统一成"脚下那格"并把身体格另存**：'
        + 'ROUND5C 的 `stands[].pos` = 脚下那格；s3_bastion_gold_piglins.mjs 的 `workPoints.picks[].stand` = 身体格（空气格）。'
        + '两套差一个 y。⇒ 每站的 `verify.notes.standAirCells` 一律给出身体格，消费方按需要自己 +1/-1，不要混用。'
        + '不要把 C3 那 4 个数当身体格读，否则会读成 y=70 的悬空空气格。',
    airSet: { AIRLIKE: [...AIRLIKE], AIR_STRICT: [...AIR_STRICT], note: 'cave_air/void_air 是 1.13+ 就有的方块，1.16.1 真实存在（设计会话 2026-10-02 夜已裁决）' },
    stations: [],
};

// ══════════════════════════════════════════════════════ A. S5_stronghold_room（overworld）
// 几何判据 1:1 复刻 s5_portal_room.mjs / s5_room_doors.mjs，只换"要什么"（要 exact 坐标）。
{
    const SID = 'S5_stronghold_room', DIM = 'overworld';
    const w = openWorld(OVERWORLD_S5, { dims: ['overworld'] });
    // ⚠ 扫描窗要比目标大一圈（S5 门室 9→12 就是被 z 下界切掉的）。这里用比两把工具更大的窗。
    const box = { x1: 1272, y1: 0, z1: 1096, x2: 1384, y2: 255, z2: 1208 };
    const get = mkGet(w, DIM, box);
    const ctrl = volumeControl(w, DIM, box, 'S5 末地门室扫描窗（比 s5_portal_room.mjs 的 1280..1376/1104..1200 每边再大 8）');
    console.log(`\n[S5] 扫描窗 ${JSON.stringify(box)}  cells=${ctrl.cells} unknownCells=${ctrl.unknownCells} ok=${ctrl.ok}`);
    console.log(`[S5] 地形对照 ${JSON.stringify(ctrl.terrainControl)}`);

    // ---- ① 12 个 end_portal_frame + eye（判 eye 必须读 props，不是方块名）
    const YMAX = BUILD_HEIGHT.overworld - 1;
    const frames = [];
    for (let y = 0; y <= YMAX; y++) for (let z = box.z1; z <= box.z2; z++) for (let x = box.x1; x <= box.x2; x++) {
        if (get(x, y, z) !== 'end_portal_frame') continue;
        const st = w.blockState(x, y, z, DIM);
        frames.push({ xyz: [x, y, z], eye: st.props?.eye === true });
    }
    frames.sort((a, b) => a.xyz[2] - b.xyz[2] || a.xyz[0] - b.xyz[0]);
    // 边界截断检查（手册 §5）：命中离扫描窗边界多近
    const edge = (p) => Math.min(p[0] - box.x1, box.x2 - p[0], p[2] - box.z1, box.z2 - p[2]);
    const frameEdge = frames.length ? Math.min(...frames.map((f) => edge(f.xyz))) : null;
    const withEye = frames.filter((f) => f.eye).map((f) => f.xyz);
    console.log(`[S5] 框 ${frames.length}（已知真值 12）｜有眼 ${withEye.length}（已知真值 2）｜命中离扫描窗边界最近 ${frameEdge} 格`);
    const frameOk = ctrl.ok && frames.length === 12 && withEye.length === 2 && frameEdge >= 8;

    // 环完整性（5×5 外圈缺四角）——沿用 s5_portal_room.mjs 的判法，不能按"看起来是 4×4"判
    const xs = frames.map((f) => f.xyz[0]), zs = frames.map((f) => f.xyz[2]), fy = frames[0]?.xyz[1];
    let ring = null;
    if (frames.length) {
        const bx = [Math.min(...xs), Math.max(...xs)], bz = [Math.min(...zs), Math.max(...zs)];
        const W = bx[1] - bx[0] + 1, D = bz[1] - bz[0] + 1;
        const isCorner = (i, j) => (i === 0 || i === W - 1) && (j === 0 || j === D - 1);
        const set = new Set(frames.map((f) => keyOf(...f.xyz)));
        const expect = [];
        for (let i = 0; i < W; i++) for (let j = 0; j < D; j++) {
            if (((i === 0 || i === W - 1) || (j === 0 || j === D - 1)) && !isCorner(i, j)) expect.push(keyOf(bx[0] + i, fy, bz[0] + j));
        }
        ring = {
            shape: `${W}×${D} 外圈缺四角`, expectedCount: expect.length, foundCount: set.size,
            missing: expect.filter((k) => !set.has(k)), extra: [...set].filter((k) => !expect.includes(k)),
            ringComplete: expect.length === 12 && set.size === 12 && expect.every((k) => set.has(k)),
        };
    }

    // ---- ② 门室空气分量（种子 = 框环中心正上方 fy+1，1:1 沿用 s5_portal_room.mjs）
    let roomSeed = null;
    if (frames.length) {
        const cxr = (Math.min(...xs) + Math.max(...xs) + 1) / 2, czr = (Math.min(...zs) + Math.max(...zs) + 1) / 2;
        for (const [ax, az] of [[cxr - 0.5, czr - 0.5], [cxr - 0.5, czr + 0.5], [cxr + 0.5, czr - 0.5], [cxr + 0.5, czr + 0.5]]) {
            if (AIRLIKE.has(get(Math.floor(ax), fy + 1, Math.floor(az)))) { roomSeed = [Math.floor(ax), fy + 1, Math.floor(az)]; break; }
        }
    }
    const room = new Set();
    if (roomSeed) {
        room.add(keyOf(...roomSeed));
        const st = [roomSeed];
        while (st.length) {
            const [x, y, z] = st.pop();
            for (const [dx, dy, dz] of N6) {
                const nx = x + dx, ny = y + dy, nz = z + dz, k = keyOf(nx, ny, nz);
                if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
                if (room.has(k) || !AIRLIKE.has(get(nx, ny, nz))) continue;
                room.add(k); st.push([nx, ny, nz]);
            }
        }
    }
    const roomYs = [...room].map((k) => +k.split(',')[1]);
    console.log(`[S5] 门室空气分量 ${room.size} 格（种子 ${JSON.stringify(roomSeed)}）y ${room.size ? Math.min(...roomYs) : '-'}..${room.size ? Math.max(...roomYs) : '-'}`);

    // ---- ③ 贴在门室空气上的门（1:1 沿用 s5_room_doors.mjs：half==='lower' 只记下扇；外侧=R+2*delta）
    const rawDoors = [];
    for (const k of room) {
        const [x, y, z] = k.split(',').map(Number);
        for (const [dx, dy, dz] of N6) {
            const nx = x + dx, ny = y + dy, nz = z + dz;
            if (room.has(keyOf(nx, ny, nz))) continue;
            const b = get(nx, ny, nz);
            if (b !== 'iron_door' && b !== 'oak_door') continue;
            const st = w.blockState(nx, ny, nz, DIM);
            if (st.props?.half !== 'lower') continue;                 // 每扇门只记下扇
            if (rawDoors.some((d) => keyOf(...d.xyz) === keyOf(nx, ny, nz))) continue;
            const away = [nx + dx, ny + dy, nz + dz];                 // ⚠ 外侧 = 沿同方向再走一格（第一版写反过）
            const outsideAir = AIRLIKE.has(get(away[0], away[1], away[2]));
            let outsideComp = 0;
            if (outsideAir) {
                const seen = new Set([keyOf(...away)]), s2 = [away];
                while (s2.length) {
                    const [x2, y2, z2] = s2.pop(); outsideComp++;
                    for (const [a, b2, c] of N6) {
                        const ax = x2 + a, ay = y2 + b2, az = z2 + c, kk = keyOf(ax, ay, az);
                        if (ax < box.x1 || ax > box.x2 || ay < box.y1 || ay > box.y2 || az < box.z1 || az > box.z2) continue;
                        if (seen.has(kk) || !AIRLIKE.has(get(ax, ay, az))) continue;
                        seen.add(kk); s2.push([ax, ay, az]);
                    }
                }
            }
            rawDoors.push({ xyz: [nx, ny, nz], facing: st.props?.facing, open: st.props?.open === true, roomSideCell: [x, y, z], outsideCell: away, outsideIsAir: outsideAir, outsideAirComponentSize: outsideComp, distFromStationCenterXZ: r1(Math.hypot(nx - 1328, nz - 1152)) });
        }
    }
    rawDoors.sort((a, b) => a.distFromStationCenterXZ - b.distFromStationCenterXZ || a.xyz[1] - b.xyz[1]);
    console.log(`[S5] 门室边界上的门 ${rawDoors.length} 扇（route 记 4）`);
    for (const d of rawDoors) console.log(`     ${JSON.stringify(d.xyz)} facing=${d.facing} open=${d.open} 距站心XZ=${d.distFromStationCenterXZ} 外侧空气=${d.outsideIsAir}(${d.outsideAirComponentSize}格)`);

    // ---- ④ 站位：门室分量里"脚下实心 + 身体/头 2 格空气"的格，按"能覆盖多少个要投眼的框"排序
    const needEye = frames.filter((f) => !f.eye).map((f) => f.xyz);
    const standCands = [];
    for (const k of room) {
        const [x, y, z] = k.split(',').map(Number);
        if (!isSolid(get, x, y - 1, z)) continue;
        if (!AIRLIKE.has(get(x, y + 1, z)) || !AIRLIKE.has(get(x, y + 2, z))) continue;
        const inReach = needEye.filter((f) => Math.hypot(f[0] - x, f[1] - (y + 1), f[2] - z) <= 5).length;
        const nearestNeed = needEye.length ? Math.min(...needEye.map((f) => d3(f, [x, y + 1, z]))) : Infinity;
        standCands.push({ xyz: [x, y, z], needEyeWithin5: inReach, nearestNeedEyeDist: r1(nearestNeed), ground: get(x, y - 1, z) });
    }
    standCands.sort((a, b) => b.needEyeWithin5 - a.needEyeWithin5 || a.nearestNeedEyeDist - b.nearestNeedEyeDist || a.xyz[1] - b.xyz[1] || a.xyz[0] - b.xyz[0] || a.xyz[2] - b.xyz[2]);
    console.log(`[S5] 门室内可站位 ${standCands.length} 个（route 记 standSpots 284），取前 ${Math.min(4, standCands.length)}`);
    for (const s of standCands.slice(0, 4)) console.log(`     ${JSON.stringify(s.xyz)} 脚下=${s.ground} 5格内待投眼框=${s.needEyeWithin5} 最近待投眼=${s.nearestNeedEyeDist}`);

    // ---- ⑤ emit 前逐个复核
    const stands = [];          // 脚下那格（= 身体格 y-1，SCHEMA §5 口径）
    const standAir = [];        // 身体格（空气格），另存以消歧义
    for (const s of standCands.slice(0, 4)) {
        if (!AIRLIKE.has(get(...s.xyz))) { rejected.push({ station: SID, xyz: s.xyz, claimed: 'standAir(空气格)', reason: 'emit 时读回不是空气' }); continue; }
        if (!isSolid(get, s.xyz[0], s.xyz[1] - 1, s.xyz[2])) { rejected.push({ station: SID, xyz: s.xyz, claimed: 'stand(脚下实心)', reason: 'emit 时读回脚下不是实心' }); continue; }
        stands.push([s.xyz[0], s.xyz[1] - 1, s.xyz[2]]);
        standAir.push(s.xyz);
    }
    const targets = [];
    let order = 1;
    for (const d of rawDoors) {
        const c = confirm(w, DIM, d.xyz, d.xyz.length && (get(...d.xyz) === 'iron_door' ? 'iron_door' : 'oak_door'), 'half', 'lower', SID, 'S5 入口门（右键开，正常交互不是挖墙）');
        if (!c) continue;
        targets.push({ what: 'door', xyz: d.xyz, order: order++, how: 'open', tool: null, notes: `facing=${c.props.facing} open=${c.props.open} 距站心XZ=${d.distFromStationCenterXZ} 外侧空气分量=${d.outsideAirComponentSize}格` });
    }
    const doorBase = order;
    const frameOut = [];
    for (const f of frames) {
        const c = confirm(w, DIM, f.xyz, 'end_portal_frame', 'eye', f.eye, SID, 'S5 末地门框');
        if (!c) continue;
        frameOut.push(f.xyz);
        targets.push({
            what: 'end_portal_frame', xyz: f.xyz, order: doorBase + frameOut.length,
            how: f.eye ? 'none_eye_already_present' : 'place_eye', tool: f.eye ? null : 'ender_eye',
            notes: `eye=${c.props.eye}`,
        });
    }
    console.log(`[S5] emit：stand ${stands.length} 个 / targets ${targets.length} 条（门 ${targets.length - frameOut.length} + 框 ${frameOut.length}）`);

    out.stations.push({
        id: SID, dim: DIM,
        exact: {
            stand: stands,
            targets,
            hazards: [],
            verify: {
                status: frameOk ? 'REAL' : 'INCONCLUSIVE',
                evidence: `bench/route/probe/_s5_s5（overworld region/，要塞实际在 r.2.2，非 r.0.0）｜`
                    + `工具 bench/route/tools/v2_extract_s5_c3_s3.mjs｜几何判据复刻 bench/route/tools/s5_portal_room.mjs + s5_room_doors.mjs｜`
                    + `产物 bench/route/probe/v2_s5_c3_s3_exact.json`,
                notes: {
                    scanWindow: box, scanWindowNote: '比 s5_portal_room.mjs 的窗每边再大 8 格，并查命中离边界距离',
                    framesFound: frames.length, framesKnownTruth: 12, framesAgree: frames.length === 12,
                    framesWithEye: withEye, framesWithEyeKnownTruth: 2, framesWithEyeAgree: withEye.length === 2,
                    eyesToPlace: frameOut.length - withEye.length,
                    frameMinDistToScanEdge: frameEdge, ring,
                    roomAirCells: room.size, roomSeed, standAirCells: standAir,
                    doorsFound: rawDoors.length, doorsKnownTruth: 4,
                    nearestDoor: rawDoors[0] ? { xyz: rawDoors[0].xyz, distFromStationCenterXZ: rawDoors[0].distFromStationCenterXZ } : null,
                    routeNoteCorrection: rawDoors.length ? (() => {
                        const d = rawDoors.find((q) => keyOf(...q.xyz) === '1332,30,1174');
                        const best = rawDoors[0];
                        return `route 的 entrance.nearest 坐标 (1332,30,1174) **复核成立**（4 扇里按站心 XZ 最近的一扇仍是它），`
                            + `但 distFromStationCenterXZ 写的是 **20.0**，实测站心 (1328,1152) 到它是 **${d?.distFromStationCenterXZ ?? '?'}** `
                            + `⇒ **距离值 20.0 不成立（坐标与"最近"的排序都成立）**。按实测重排：`
                            + rawDoors.map((q, i) => `#${i + 1} ${JSON.stringify(q.xyz)}=${q.distFromStationCenterXZ}`).join(' / ') + '。';
                    })() : null,
                    approachDoorAdvice: rawDoors.length ? (() => {
                        const best = [...rawDoors].sort((a, b) => b.outsideAirComponentSize - a.outsideAirComponentSize)[0];
                        return `**推荐走 ${JSON.stringify(best.xyz)}** —— 它的门外空气分量 **${best.outsideAirComponentSize} 格**（4 扇里最大，最像主走廊 ⇒ 从走廊推门进来最稳）；`
                            + `其余 3 扇门外只有 ${rawDoors.filter((q) => q !== best).map((q) => q.outsideAirComponentSize).join('/')} 格。4 扇全部 open=false，**都要右键开**。`;
                    })() : null,
                    volumeControl: ctrl,
                },
            },
        },
    });
}

// ══════════════════════════════════════════════════════ B. C3_fortress_spawner（the_nether）
// 判据逐字取自 fortress_standing.round5c.json 的 `criterion` 字段。
{
    const SID = 'C3_fortress_spawner', DIM = 'the_nether';
    const SPAWNER = [221, 70, -85];
    const QZ = [224, 72, -82];

    // ---- ⚠⚠ 覆盖范围闸门（手册 §5：「没读到 ≠ 没有」）
    // 派单指定的 `_nether_corridor` **整片读不到**：那个存档的 nether 区段没有要塞这一块。
    // 不先证伪工具就发坐标 = 把"没读到"报成"没有"。⇒ 先把 probe 盘下**所有**带 DIM-1 的存档
    // 都试读刷怪笼那一格，用"读回 spawner"当阳性对照，挑出真正覆盖这一片的那份。
    const netherWorlds = fs.readdirSync(PROBE_DIR, { withFileTypes: true })
        .filter((e) => e.isDirectory())
        .map((e) => path.join(PROBE_DIR, e.name))
        .filter((d) => { const r = path.join(d, 'DIM-1', 'region'); return fs.existsSync(r) && fs.readdirSync(r).some((f) => /^r\.-?\d+\.-?\d+\.mca$/.test(f) && fs.statSync(path.join(r, f)).size >= 8200); });
    const coverage = [];
    for (const d of netherWorlds) {
        try {
            const t = openWorld(d, { dims: ['the_nether'] });
            coverage.push({ world: path.basename(d), spawnerCellReadBack: t.blockAt(...SPAWNER, DIM), usable: t.blockAt(...SPAWNER, DIM) === 'spawner' });
        } catch (e) { coverage.push({ world: path.basename(d), spawnerCellReadBack: `OPEN_FAILED: ${e.message}`, usable: false }); }
    }
    const picked = coverage.find((c) => c.usable);
    console.log(`\n[C3] 覆盖范围闸门 —— 盘上带 DIM-1 的存档共 ${coverage.length} 份，逐个试读刷怪笼格 ${JSON.stringify(SPAWNER)}：`);
    for (const c of coverage) console.log(`     ${c.world.padEnd(22)} 读回=${c.spawnerCellReadBack.padEnd(20)} ${c.usable ? '✔ 覆盖' : '✘ 不覆盖'}`);
    const NETHER_C3_FOUND = picked ? path.join(PROBE_DIR, picked.world) : null;
    console.log(`[C3] 选定存档：${NETHER_C3_FOUND ?? '无（没有任何一份存档覆盖要塞这一片 ⇒ 不发坐标）'}`);

    if (!NETHER_C3_FOUND) {
        rejected.push({ station: SID, xyz: SPAWNER, claimed: 'spawner', reason: '盘上没有任何带 DIM-1 的存档能读回该格 —— 存档没覆盖要塞这一片（手册 §5「没读到 ≠ 没有」），不产坐标' });
        out.stations.push({
            id: SID, dim: DIM,
            exact: { stand: [], targets: [], hazards: [], verify: { status: 'INCONCLUSIVE', evidence: `覆盖范围闸门失败：${JSON.stringify(coverage)}`, notes: { coverageProbe: coverage, reason: '存档未覆盖，不发坐标' } } },
        });
    } else {
    const w = openWorld(NETHER_C3_FOUND, { dims: ['the_nether'] });
    // ⚠ 同一个盒，阳性对照才有着落：ROUND5C 的 paletteCounts 逐块可对账
    const box = { x1: 218, y1: 67, z1: -88, x2: 224, y2: 73, z2: -82 };
    const get = mkGet(w, DIM, box);
    const ctrl = volumeControl(w, DIM, box, 'C3 站位判据盒（与 ROUND5C 同盒：343 格）');
    console.log(`[C3] 盒 ${JSON.stringify(box)}  cells=${ctrl.cells} unknownCells=${ctrl.unknownCells} ok=${ctrl.ok}`);
    console.log(`[C3] 地形对照 ${JSON.stringify(ctrl.terrainControl)}`);
    if (!ctrl.ok) console.error(`✗ C3 盒 unknownCells=${ctrl.unknownCells} ≠ 0 —— 存档没覆盖，不发坐标`);

    // ---- 阳性对照：逐块全量普查，与 ROUND5C 的 paletteCounts 逐类对账
    const census = {};
    for (let y = box.y1; y <= box.y2; y++) for (let z = box.z1; z <= box.z2; z++) for (let x = box.x1; x <= box.x2; x++) {
        const n = get(x, y, z); census[n] = (census[n] ?? 0) + 1;
    }
    const TRUTH = { air: 138, cave_air: 6, nether_brick_fence: 27, nether_bricks: 108, nether_quartz_ore: 1, netherrack: 62, spawner: 1 };
    const cross = {};
    for (const [k, v] of Object.entries(TRUTH)) cross[k] = { round5cPaletteCounts: v, archiveReader: census[k] ?? 0, agree: v === (census[k] ?? 0) };
    const allAgree = Object.values(cross).every((c) => c.agree) && Object.keys(census).length === Object.keys(TRUTH).length;
    console.log(`[C3] 阳性对照 vs ROUND5C paletteCounts：${JSON.stringify(cross)}  全部一致=${allAgree}`);

    // ---- 站位判据：脚下实心 + 身体/头两格 air + 四侧 ≥2 面 SOLID
    //
    // ⚠⚠ **两处必须钉死，否则必然与 ROUND5C 对不上（本单第一版就栽在这）**：
    //  (1) **站位格 = 身体所在的那个空气格；脚下那格 = 站位格 y-1。**
    //      地面真值（cellTruth.table）里 (220,·,-87) 在 y=67/68/69 **全是 nether_bricks**，
    //      y=70 才是 air ⇒ 玩家站在 **y=70**、脚踩 **y=69**。
    //      而 ROUND5C 记的 `pos=[220,69,-87]` 是**脚下那格（地面块）**。
    //      ⇒ SCHEMA §5 的 `stand` 注释"**脚下那格坐标**"说的就是 ROUND5C 这个口径，
    //         本单 `exact.stand` 与之一致（`standAirCells` 里另给身体格，避免口径歧义）。
    //  (2) **四面墙必须在"身体格那一层"量，而且四面必须全部读得到。**
    //      用 ROUND5C 自己的 `cellTruth.table` 重放：墙在 y（身体层）⇒ 6 个；墙在 y-1（地面层）⇒ 25 个。
    //      ROUND5C 记录的 `wallNames`（如 (220,69,-87) = air/nether_bricks/air/nether_bricks）
    //      只有按**身体层 y=70** 才逐字对上 ⇒ 墙就是身体层。
    //      剩下多出来的 2 个在 x=218：它们的西墙落在**盒外**（盒 x1=218，x=217 读回 'unknown'），
    //      'unknown' 不算 SOLID ⇒ 被我算成"只有 2 面墙"而误过。
    //      手册 §5「没读到 ≠ 没有」：判"≥2 面 SOLID"必须四面都读到，否则这格判据不成立。
    //      加上"四面全部可读"这一条 ⇒ 恰好 4 个，与 ROUND5C 逐个相等。
    const SOLID_SIMPLE = (n) => n !== 'unknown' && !AIRLIKE.has(n);      // 非空气集且读得到
    const SOLID_WL = new Set(['nether_bricks', 'nether_brick_fence', 'nether_brick_stairs', 'nether_brick_wall',
        'nether_brick_slab', 'blackstone', 'polished_blackstone_bricks', 'chiseled_nether_bricks', 'netherrack',
        'crimson_nylium', 'warped_nylium', 'soul_soil', 'magma_block', 'iron_bars', 'chain', 'nether_quartz_ore']);
    const standable = (x, y, z, airSet, solidFn) => {
        if (!airSet.has(get(x, y, z)) || !airSet.has(get(x, y + 1, z))) return null;   // 身体格 + 头格
        if (!airSet.has(get(x, y + 2, z))) return null;                               // 头顶余量（更严，两种口径结果相同）
        const ground = get(x, y - 1, z);
        if (!solidFn(ground)) return null;                                            // 脚下实心
        // ⚠ N4 是 **3 元素** [dx,dy,dz]。按 [dx,dz] 解构会让 [0,0,1] 和 [0,0,-1] 都变成 (0,0)
        //   ⇒ 四面墙塌成三面、且其中两面指向自己（空气）⇒ "≥2 面 SOLID" 永远判不过。
        const walls = N4.map(([dx, , dz]) => ({ d: [dx, dz], n: get(x + dx, y, z + dz) }));   // ← 身体层 y
        if (walls.some((w2) => w2.n === 'unknown')) return null;                       // ⚠ 四面必须全部读得到
        const solidWalls = walls.filter((w2) => solidFn(w2.n));
        if (solidWalls.length < 2) return null;
        return { stand: [x, y - 1, z], airCell: [x, y, z], feet: ground, walls: solidWalls.length, wallNames: walls.map((w2) => w2.n) };
    };
    const derive = (airSet, solidFn) => {
        const r = [];
        for (let y = box.y1; y <= box.y2; y++) for (let z = box.z1; z <= box.z2; z++) for (let x = box.x1; x <= box.x2; x++) {
            const s = standable(x, y, z, airSet, solidFn); if (s) r.push(s);
        }
        return r;
    };
    const setKey = (arr) => arr.map((s) => keyOf(...s.stand)).sort().join(' ');
    const sAirLike = derive(AIRLIKE, SOLID_SIMPLE);
    const sAirOnly = derive(AIR_STRICT, SOLID_SIMPLE);
    const sAirLikeWL = derive(AIRLIKE, (n) => SOLID_WL.has(n));
    const KNOWN = [[220, 69, -87], [220, 69, -83], [223, 69, -87], [223, 69, -83]];   // ROUND5C 的 pos = 脚下那格
    const knownKey = setKey(KNOWN.map((p) => ({ stand: p })));
    const agree = { vsKnown: setKey(sAirLike) === knownKey, airOnlyVsAirLike: setKey(sAirOnly) === setKey(sAirLike), whitelistVsSimple: setKey(sAirLikeWL) === setKey(sAirLike) };
    console.log(`[C3] 站位（stand=脚下那格 / airCell=身体格）：airLike ${sAirLike.length} / airOnly ${sAirOnly.length} / 白名单 ${sAirLikeWL.length}（ROUND5C 记 4）`);
    console.log(`[C3] 一致性 ${JSON.stringify(agree)}`);
    for (const s of sAirLike) console.log(`     stand=${JSON.stringify(s.stand)} 身体格=${JSON.stringify(s.airCell)} 脚下=${s.feet} 墙=${s.walls} 侧=${s.wallNames.join('/')}`);

    // ---- emit 前复核：4 个站位 + 刷怪笼
    const stands = [];
    for (const s of sAirLike) {
        const [ax, ay, az] = s.airCell;
        const ok = AIRLIKE.has(get(ax, ay, az)) && AIRLIKE.has(get(ax, ay + 1, az))
            && SOLID_SIMPLE(get(ax, ay - 1, az)) && N4.every(([dx, dz]) => get(ax + dx, ay, az + dz) !== 'unknown');
        if (!ok) { rejected.push({ station: SID, xyz: s.stand, claimed: 'stand(脚下实心+身体2格空气+四面可读)', reason: 'emit 时复核不通过' }); continue; }
        stands.push({ stand: s.stand, airCell: s.airCell, feet: s.feet, walls: s.walls, wallNames: s.wallNames });
    }
    const SPAWNER = [221, 70, -85];
    const sp = confirm(w, DIM, SPAWNER, 'spawner', null, undefined, SID, 'C3 烈焰棒刷怪笼');
    const targets = sp ? [{ what: 'spawner', xyz: SPAWNER, order: 1, how: 'break_drop_blaze_rods', tool: 'iron_pickaxe', notes: 'ROUND5 穷举：本片恰好 1 个笼；编排器按"尽力而为"处理，掉落少不重试' }] : [];
    const QZ = [224, 72, -82];
    const qz = confirm(w, DIM, QZ, 'nether_quartz_ore', null, undefined, SID, 'C3 路线可用下界石英（非目标，附注）');

    // ---- hazards：盒内 lava/magma/fire（导航护栏直接用）
    const haz = [];
    for (let y = box.y1; y <= box.y2; y++) for (let z = box.z1; z <= box.z2; z++) for (let x = box.x1; x <= box.x2; x++) {
        if (HAZARD.has(get(x, y, z))) haz.push([x, y, z]);
    }
    const nearStand = (p) => {
        if (!stands.length) return null;
        return Math.min(...stands.map((s) => Math.max(Math.abs(p[0] - s.airCell[0]), Math.abs(p[1] - s.airCell[1]), Math.abs(p[2] - s.airCell[2]))));
    };
    const hazDetail = haz.map((p) => ({ xyz: p, block: get(...p), chebyshevToNearestStand: nearStand(p) }));
    console.log(`[C3] hazards（盒内 lava/magma/fire）：${haz.length} → ${JSON.stringify(hazDetail)}`);
    console.log(`[C3] nether_quartz_ore @${JSON.stringify(QZ)} 复核=${qz ? 'OK' : 'DROPPED'}；刷怪笼复核=${sp ? 'OK' : 'DROPPED'}`);

    out.stations.push({
        id: SID, dim: DIM,
        exact: {
            stand: stands.map((s) => s.stand),
            targets,
            hazards: haz,
            verify: {
                status: ctrl.ok && allAgree && agree.vsKnown && sp ? 'REAL' : 'INCONCLUSIVE',
                evidence: `${NETHER_C3_FOUND.replace(/\\/g, '/')}（DIM-1/region/）｜`
                    + `工具 bench/route/tools/v2_extract_s5_c3_s3.mjs｜判据逐字取自 bench/route/probe/fortress_standing.round5c.json#criterion｜`
                    + `产物 bench/route/probe/v2_s5_c3_s3_exact.json`,
                notes: {
                    archiveCoverageGate: {
                        note: '⚠ **派单指定的 `bench/route/probe/_nether_corridor` 整片读不到（343/343 格 unknown）—— 那份存档的 nether 区段没有要塞这一块。**'
                            + '按手册 §5「没读到 ≠ 没有」，不先证伪工具就发坐标会把覆盖缺失误报成"没找到"。本单因此先遍历盘上所有带 DIM-1 的存档试读刷怪笼格，再选真正覆盖的那份。',
                        netherWorldsProbed: coverage.length, probeTable: coverage, chosen: picked?.world ?? null,
                    },
                    criterionUsed: '脚下实心 + 身体/头两格空气 + 四侧 ≥2 面 SOLID（与 ROUND4/ROUND5C 逐字一致）｜'
                        + '**墙在身体层（站位身体格那一层 y）量，不是地面层**：用 ROUND5C 自己的 cellTruth.table 重放，'
                        + '身体层 ⇒ 6 个候选、地面层 ⇒ 25 个，而 ROUND5C 记的 wallNames 只在身体层逐字对上。',
                    wallReadabilityRule: '⚠ **四面墙必须全部读得到才判"≥2 面 SOLID"**。少了这条，x=218 的 (218,·,-86)/(218,·,-84) 会混进来：'
                        + '它们的西墙落在盒外（盒 x1=218，x=217 读回 unknown），unknown 不算 SOLID 于是只剩"2 面墙"而误过 —— '
                        + '这正是手册 §5「没读到 ≠ 没有」。加上该条后**恰好 4 个，与 ROUND5C 逐个相等**。',
                    standCellConvention: 'exact.stand = 脚下那格（身体格 y-1，与 ROUND5C stands[].pos 同口径）；standAirCells = 身体格。',
                    airConventionUsed: 'AIRLIKE = {air, cave_air, void_air}（本单采用；同时用 AIR_STRICT={air} 复算，两套结果相同，见 airConventionCheck）',
                    solidDefinitionUsed: 'SOLID = 读得到 且 不属于 AIRLIKE。同时用 ROUND5C 的 SOLID 白名单复算，结果相同（whitelistVsSimple）',
                    airConventionCheck: { airLike: sAirLike.length, airOnly: sAirOnly.length, agree: agree.airOnlyVsAirLike },
                    whitelistCheck: { simple: sAirLike.length, whitelist: sAirLikeWL.length, agree: agree.whitelistVsSimple },
                    knownStandsFromRound5c: KNOWN, derivedStands: sAirLike.map((s) => s.stand), derivedStandAirCells: stands.map((s) => s.airCell), standAirCells: stands.map((s) => s.airCell), agreeWithRound5c: agree.vsKnown,
                    standDetail: stands,
                    spawner: SPAWNER, spawnerReadsBack: !!sp,
                    quartzOre: qz ? { xyz: QZ, note: '路线可用（ROUND5C 原话），非本站目标' } : { xyz: QZ, dropped: true },
                    hazardsDetail: hazDetail,
                    positiveControl: { round5cCrossCheck: cross, allAgree, volumeControl: ctrl },
                },
            },
        },
    });
    }
}

// ══════════════════════════════════════════════════════ C. S3_bastion（the_nether，gold for barter）
{
    const SID = 'S3_bastion', DIM = 'the_nether';
    const w = openWorld(NETHER_S3, { dims: ['the_nether'] });
    const box = { x1: 224, y1: 0, z1: 160, x2: 431, y2: 127, z2: 367 };      // = easy 探针的窗（cx14..26 / cz10..22）
    const ctrl = volumeControl(w, DIM, box, 'S3 堡垒金源普查窗（= s3_bastion_gold_piglins.easy.json 的 box）');
    console.log(`\n[S3] 普查窗 ${JSON.stringify(box)}  cells=${ctrl.cells} unknownCells=${ctrl.unknownCells} ok=${ctrl.ok}`);
    console.log(`[S3] 地形对照 ${JSON.stringify(ctrl.terrainControl)}`);

    // ---- 金源普查（加速法沿用 s3_bastion_gold_piglins.mjs：先看 palette 直方图，含目标才逐格）
    const GOLD = new Set(['gold_block', 'gilded_blackstone', 'chest', 'trapped_chest']);
    const hits = [];
    const cx1 = Math.floor(box.x1 / 16), cx2 = Math.floor(box.x2 / 16), cz1 = Math.floor(box.z1 / 16), cz2 = Math.floor(box.z2 / 16);
    for (let cx = cx1; cx <= cx2; cx++) for (let cz = cz1; cz <= cz2; cz++) {
        const c = w.chunk(cx, cz, DIM);
        if (!c) continue;
        const hist = new Map();
        for (let i = 0; i < c.filled.length; i++) { if (!c.filled[i]) continue; const n = c.palette[c.idx[i]]?.name ?? 'unknown'; hist.set(n, (hist.get(n) ?? 0) + 1); }
        let has = false; for (const n of hist.keys()) if (GOLD.has(n)) { has = true; break; }
        if (!has) continue;
        for (let y = box.y1; y <= box.y2; y++) for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
            const o = lx + lz * 16 + y * 256;
            if (!c.filled[o]) continue;
            const nm = c.palette[c.idx[o]]?.name; if (!GOLD.has(nm)) continue;
            const ax = cx * 16 + lx, az = cz * 16 + lz;
            if (ax < box.x1 || ax > box.x2 || az < box.z1 || az > box.z2) continue;
            const airFaces = FACES.filter(([dx, dy, dz]) => AIRLIKE.has(w.blockAt(ax + dx, y + dy, az + dz, DIM))).map(([, , , t]) => t);
            hits.push({ block: nm, xyz: [ax, y, az], exposed: airFaces.length > 0, airFaces });
        }
    }
    const byBlock = {};
    for (const h of hits) { const b = (byBlock[h.block] ??= { total: 0, exposed: 0 }); b.total++; h.exposed ? b.exposed++ : b.hidden = (b.hidden ?? 0) + 1; }
    const TRUTH3 = { gold_block: 22, gilded_blackstone: 227, chest: 5 };
    const cross3 = {};
    for (const [k, v] of Object.entries(TRUTH3)) cross3[k] = { routeFillReplace: v, archiveReader: byBlock[k]?.total ?? 0, agree: v === (byBlock[k]?.total ?? 0) };
    const all3 = Object.values(cross3).every((c) => c.agree);
    const goldEdge = hits.length ? Math.min(...hits.map((h) => Math.min(h.xyz[0] - box.x1, box.x2 - h.xyz[0], h.xyz[2] - box.z1, box.z2 - h.xyz[2]))) : null;
    console.log(`[S3] 金源 ${JSON.stringify(Object.fromEntries(Object.entries(byBlock).map(([k, v]) => [k, `${v.total}(暴露${v.exposed})`])))} 合计=${hits.length}`);
    console.log(`[S3] 阳性对照 vs routeFillReplace：${JSON.stringify(cross3)}  全部一致=${all3}｜命中离普查窗边界最近 ${goldEdge} 格`);

    // ---- 作业点裁决：brief 的 F 线数 [331,57,238] vs easy 探针的 [331,64,238]
    const PICKS = [[326, 73, 265], [331, 64, 238], [325, 58, 239]];
    const F_LINE = [331, 57, 238];
    const exposedGoldBlock = hits.filter((h) => h.block === 'gold_block' && h.exposed);
    const exposedGilded = hits.filter((h) => h.block === 'gilded_blackstone' && h.exposed);
    const chests = hits.filter((h) => h.block === 'chest' || h.block === 'trapped_chest');
    const standable = (x, y, z) => AIRLIKE.has(w.blockAt(x, y, z, DIM)) && AIRLIKE.has(w.blockAt(x, y + 1, z, DIM))
        && AIRLIKE.has(w.blockAt(x, y + 2, z, DIM)) && !AIRLIKE.has(w.blockAt(x, y - 1, z, DIM));
    const hazardNear = (p, r) => {
        const out2 = [];
        for (let y = p[1] - r; y <= p[1] + r; y++) for (let z = p[2] - r; z <= p[2] + r; z++) for (let x = p[0] - r; x <= p[0] + r; x++) {
            if (HAZARD.has(w.blockAt(x, y, z, DIM))) out2.push([x, y, z]);
        }
        return out2;
    };
    const describe = (p) => {
        const feet = w.blockAt(p[0], p[1] - 1, p[2], DIM);
        const body = w.blockAt(...p, DIM), head = w.blockAt(p[0], p[1] + 1, p[2], DIM);
        // ⚠⚠ 第一版把"最近距离"和"最近坐标"塞进**同一个变量**（`ngb = d; ngb = g.xyz;`）——
        //   循环结束后 ngb 里存的是**最后命中那个**坐标，距离全丢，报告里就出现 dist:null（假坐标）。
        //   而且用"头层 y+1"还是"站位格 y"当中心会直接改变排序，必须钉死：这里用**站位格本身 p**，
        //   与 s3_bastion_gold_piglins.mjs 的 hypot(g-(x+0.5, y, z+0.5)) 同口径。
        const nearest = (list) => {
            let bd = Infinity, bc = null, bb = null;
            for (const g of list) { const d = d3(g.xyz, p); if (d < bd) { bd = d; bc = g.xyz; bb = g.block; } }
            return bc === null ? null : { xyz: bc, block: bb, dist: r1(bd) };
        };
        return {
            xyz: p, standable: standable(...p), body, head, ground: feet, groundIsSolid: feet !== 'unknown' && !AIRLIKE.has(feet),
            nearestExposedGoldBlock: nearest(exposedGoldBlock),
            nearestExposedGildedBlackstone: nearest(exposedGilded),
            nearestChest: nearest(chests),
            exposedGoldBlockWithin8: exposedGoldBlock.filter((g) => d3(g.xyz, p) <= 8).length,
            hazardsWithin5: hazardNear(p, 5),
        };
    };
    const dF = describe(F_LINE), dP = PICKS.map(describe);
    console.log(`[S3] F 线数 ${JSON.stringify(F_LINE)} → standable=${dF.standable} 脚下=${dF.ground} 身体=${dF.body} 头=${dF.head} 8格内暴露金块=${dF.exposedGoldBlockWithin8} 最近暴露金块=${JSON.stringify(dF.nearestExposedGoldBlock)}`);
    console.log(`[S3] easy 探针三个 pick：`);
    for (const d of dP) console.log(`     ${JSON.stringify(d.xyz)} standable=${d.standable} 脚下=${d.ground} 最近暴露金块=${JSON.stringify(d.nearestExposedGoldBlock)} 8格内=${d.exposedGoldBlockWithin8} 最近箱=${JSON.stringify(d.nearestChest)}`);

    // ---- 作业点选谁：站得住 + 最近暴露金块最近 + 无岩浆。**F 线的 [331,57,238] 也参与竞选**
    //   （brief 只让我"判它站不站得住"，但既然它站得住，就该让它按同一把尺子和别人比一遍，而不是先验排除）
    const allDesc = [F_LINE, ...PICKS].map(describe);
    const eligible = allDesc.filter((d) => d.standable).sort((a, b) => (a.nearestExposedGoldBlock?.dist ?? 1e9) - (b.nearestExposedGoldBlock?.dist ?? 1e9) || a.hazardsWithin5.length - b.hazardsWithin5.length);
    const WP = eligible[0];
    if (!WP) { rejected.push({ station: SID, xyz: null, claimed: 'workPoint', reason: '四个候选（F 线 + easy 三个 pick）复核后全部站不住 —— 无作业点可发' });
    }
    console.log(`[S3] 作业点排名（最近暴露金块升序）：${JSON.stringify(eligible.map((e) => ({ xyz: e.xyz, goldDist: e.nearestExposedGoldBlock?.dist ?? null, goldWithin8: e.exposedGoldBlockWithin8, haz: e.hazardsWithin5.length })))}`);
    const fLineVerdict = dF.standable
        ? `F 线数 ${JSON.stringify(F_LINE)} **站得住**（脚下=${dF.ground}，身体格=${dF.body}，头格=${dF.head}）——`
          + `brief 里"if it is not standable, say so"的担心**不成立**：它是 4 个候选里唯一非 easy-探针来源的数，复核通过。`
          + `但它离最近的暴露金块 ${dF.nearestExposedGoldBlock?.dist ?? '?'} 格、8 格内暴露金块只有 ${dF.exposedGoldBlockWithin8} 块 ⇒ `
          + `**能不能当作业点取决于"挖金够不够近"，不是"站不站得住"**（见 notes.workPointRanking）。`
        : `F 线数 ${JSON.stringify(F_LINE)} **站不住**：脚下=${dF.ground}（${AIRLIKE.has(dF.ground) ? '脚下是空气 ⇒ 没有支撑' : dF.ground === 'unknown' ? '读不到' : '脚下有方块但不是实心'}），`
          + `身体格=${dF.body}，头格=${dF.head} ⇒ 它不是作业站位（很可能是 F 线把"作业点 y"记成了地面层或走廊层）`;

    // ---- 目标：从作业点出发，最近优先，只取 exposed（手册 §7 公平口径：看得见/够得着）
    const targets = [];
    let order = 1;
    const from = WP ? [WP.xyz[0], WP.xyz[1] + 1, WP.xyz[2]] : null;
    const sortedGold = WP ? [...exposedGoldBlock].sort((a, b) => d3(a.xyz, from) - d3(b.xyz, from) || a.xyz[2] - b.xyz[2] || a.xyz[0] - b.xyz[0]) : [];
    for (const g of sortedGold) {
        const c = confirm(w, DIM, g.xyz, 'gold_block', null, undefined, SID, 'S3 暴露金块（挖 = 金锭来源）');
        if (!c) continue;
        targets.push({ what: 'dig', xyz: g.xyz, order: order++, how: 'dig', tool: 'iron_pickaxe', notes: `exposed 空气面=${g.airFaces.join('|') || '-'} 距作业点中心=${r1(d3(g.xyz, from))}` });
    }
    for (const g of chests.sort((a, b) => d3(a.xyz, from) - d3(b.xyz, from) || a.xyz[2] - b.xyz[2] || a.xyz[0] - b.xyz[0])) {
        const c = confirm(w, DIM, g.xyz, g.block, null, undefined, SID, 'S3 箱子（可开箱 = 零挖掘金锭来源）');
        if (!c) continue;
        targets.push({ what: 'chest', xyz: g.xyz, order: order++, how: 'open', tool: null, notes: `${g.block} exposed 空气面=${g.airFaces.join('|') || '-'} 距作业点中心=${r1(d3(g.xyz, from))}｜战利品只有开箱时才生成，存档读不出` });
    }
    const hazS3 = WP ? hazardNear(WP.xyz, 8) : [];
    const hazS3ByBlock = {};
    for (const p of hazS3) { const n = w.blockAt(...p, DIM); hazS3ByBlock[n] = (hazS3ByBlock[n] ?? 0) + 1; }
    // exact.stand = 脚下那格（SCHEMA §5 / ROUND5C 口径）；easy 探针给的 picks[].stand 是身体格，差一个 y
    const standGround = WP ? [WP.xyz.map((v, i) => (i === 1 ? v - 1 : v)), ...eligible.slice(1).map((e) => e.xyz.map((v, i) => (i === 1 ? v - 1 : v)))] : [];
    const standAirS3 = WP ? [WP.xyz, ...eligible.slice(1).map((e) => e.xyz)] : [];
    console.log(`[S3] 选定作业点 身体格=${JSON.stringify(WP?.xyz)} 脚下格=${JSON.stringify(standGround[0])}（脚下=${WP?.ground}）｜选中暴露金块 ${sortedGold.length} / 暴露金块总数 ${exposedGoldBlock.length}（金块总数 ${byBlock.gold_block?.total}）｜箱 ${targets.filter((t) => t.what === 'chest').length}｜作业点 ±8 内 hazard ${hazS3.length} ${JSON.stringify(hazS3ByBlock)}`);
    console.log(`[S3] F 线裁决：${fLineVerdict}`);

    // 猪灵：只作文字注记（战斗问题，不是地形危险格）—— 从 easy 探针读，不进 hazards
    const easyProbe = JSON.parse(fs.readFileSync(path.join(PROBE_DIR, 's3_bastion_gold_piglins.easy.json'), 'utf8'));
    out.stations.push({
        id: SID, dim: DIM,
        exact: {
            stand: standGround,
            targets,
            hazards: hazS3,
            verify: {
                status: ctrl.ok && all3 && WP && targets.some((t) => t.what === 'dig') ? 'REAL' : 'INCONCLUSIVE',
                evidence: `bench/route/probe/_s3_easy（DIM-1/region/r.0.0.mca，cx14..26 / cz10..22）｜`
                    + `工具 bench/route/tools/v2_extract_s5_c3_s3.mjs（普查/暴露面判据复刻 s3_bastion_gold_piglins.mjs）｜`
                    + `作业点与金源表来源 bench/route/probe/s3_bastion_gold_piglins.easy.json#workPoints.picks / #gold.list｜`
                    + `产物 bench/route/probe/v2_s5_c3_s3_exact.json`,
                notes: {
                    selectionRule: '只取 exposed=true（6 面邻格 ≥1 个在 {air,cave_air,void_air} 内）—— 手册 §7 公平口径：bot 要看得见/够得着；按到作业点的 3D 距离最近优先',
                    exposedGoldBlockSelected: sortedGold.length, exposedGoldBlockTotal: exposedGoldBlock.length,
                    goldBlockTotal: byBlock.gold_block?.total ?? 0, goldBlockExposed: byBlock.gold_block?.exposed ?? 0,
                    gildedExposedTotal: exposedGilded.length, gildedWarning: 'gilded_blackstone 不掉金锭（挖了没收益），故不进 targets，只作注记',
                    standCellConvention: 'exact.stand = 脚下那格（身体格 y-1，SCHEMA §5 口径）；standAirCells = 身体格。'
                        + '⚠ 注意：easy 探针 `workPoints.picks[].stand` 记的是**身体格**，与 exact.stand 差一个 y。',
                    standAirCells: standAirS3,
                    workPointChosenAirCell: WP ? WP.xyz : null,
                    workPointChosenGroundCell: WP ? standGround[0] : null,
                    workPointRanking: eligible.map((e, i) => ({
                        rank: i + 1, airCell: e.xyz, groundCell: e.xyz.map((v, k) => (k === 1 ? v - 1 : v)),
                        source: keyOf(...e.xyz) === keyOf(...F_LINE) ? 'F线MC-S2-03' : 'easy探针workPoints.picks',
                        nearestExposedGoldBlock: e.nearestExposedGoldBlock, exposedGoldBlockWithin8: e.exposedGoldBlockWithin8,
                        nearestChest: e.nearestChest, hazardsWithin5: e.hazardsWithin5.length,
                    })),
                    hazardsByBlockWithin8: hazS3ByBlock,
                    hazardsScope: 'exact.hazards = 选定作业点 ±8（17×17×17）内的 lava/magma_block/fire/soul_fire/nether_portal。'
                        + `实测这 ${hazS3.length} 格**全部是 lava**（magma_block 0）⇒ 是能掉下去淹死的真岩浆，不是"走得慢"的岩浆块，`
                        + '导航护栏应当当真岩浆处理。⚠ 但**作业点格子本身站在 polished_blackstone_bricks 上、身体/头两格是空气**，不在岩浆里；'
                        + '岩浆是它周围的地面。站位备选 [326,73,265] 附近 0 格 hazard（见 workPointRanking），若要更安全可用它。',
                    workPointChosen: WP ? { airCell: WP.xyz, ground: WP.ground, ...WP } : null,
                    workPointAlternates: eligible.slice(1).map((e) => ({ airCell: e.xyz, nearestExposedGoldBlock: e.nearestExposedGoldBlock })),
                    fLine331_57_238: { verdict: fLineVerdict, detail: dF, inArchive: dF.standable },
                    easyProbePicks: dP,
                    piglinCombatNote: `猪灵是**战斗问题，不是地形危险格** ⇒ 按派单要求只记在这里、不进 hazards：`
                        + `easy 探针存档里世界生成猪灵 ${easyProbe.piglins.total} 头（worldgen ${easyProbe.piglins.worldgen} / 幼年 ${easyProbe.piglins.babies}）；`
                        + `F 线 MC-S2-01 实测同位置 28 头（差 1 见 route 的 piglinPopulation.discrepancyWithF）。`
                        + `另外：挖金块/鎏金黑石/开箱会激怒 16 格内猪灵 30s（route#scout.notes hoglinAggression）。`,
                    positiveControl: { routeCrossCheck: cross3, allAgree: all3, goldMinDistToScanEdge: goldEdge, volumeControl: ctrl },
                },
            },
        },
    });
}

out.rejected = rejected;
out.rejectedTotal = rejected.length;

// ══════════════════════════════════════════════════════ 落盘 + 读回断言
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(out, null, 2) + '\n', 'utf8');
const back = JSON.parse(fs.readFileSync(OUT, 'utf8'));            // ⚠ 写完必须读回并 assert 能解析
if (back.stations.length !== 3) { console.error(`✗ 读回 stations=${back.stations.length}，期望 3`); process.exit(3); }
for (const s of back.stations) {
    if (!s.exact || !Array.isArray(s.exact.stand) || !Array.isArray(s.exact.targets) || !Array.isArray(s.exact.hazards) || !s.exact.verify) {
        console.error(`✗ ${s.id} 的 exact 块形状不对`); process.exit(3);
    }
    console.log(`\n=== ${s.id} ===\n  stand(${s.exact.stand.length}) ${JSON.stringify(s.exact.stand)}\n  targets(${s.exact.targets.length}) hazards(${s.exact.hazards.length}) verify.status=${s.exact.verify.status}`);
}
console.log(`\nrejected=${rejected.length} ${JSON.stringify(rejected)}`);
console.log(`落盘并读回断言通过：${OUT}（${fs.statSync(OUT).size} bytes）`);
