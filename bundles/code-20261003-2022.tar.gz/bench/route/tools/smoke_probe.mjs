﻿// smoke_probe.mjs — MC-ROUTE-02 可行性冒烟（诊断工具，不产出 route）
//
// 只验三件最容易翻车的事，各花一分钟内：
//   1. 泳道 C 能按心跳排队拿到（不抢 E 线）
//   2. `/locate` 裸名回执能解析（手册 §2：1.16.1 只认裸名、没有 /locatebiome）
//   3. **递归下钻能把目标方块定位到 1×1×1 精确坐标**（本单核心能力）
//      主种子的 stronghold 在 SEED-03 已验「r48 盒内 end_portal_frame:12」，
//      这里要证明能把这 12 个框各自的 xyz 挖出来。
//
// 用法：node smoke_probe.mjs [--seed <seed>]

import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR, portState } from './console.mjs';
import { locate, drill } from './scan.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SEED = argOf(process.argv, 'seed', '-8839485814800629942');
const RUN = path.join(ROUTE_DIR, 'probe', `smoke_${SEED}`);

let server = null;
try {
    const b = await bootLaneC({ seed: SEED, runDir: RUN, logFn: log });
    server = b;
    const con = b.con;

    // --- 1) /locate 裸名 ---
    log('--- 1) /locate 裸名回执 ---');
    for (const st of ['stronghold', 'ruined_portal', 'village', 'buried_treasure', 'shipwreck']) {
        const p = await locate(con, st, 'overworld');
        log(`  locate ${st} → ${JSON.stringify(p)}`);
    }

    // --- 2) 下界结构 ---
    log('--- 2) 下界 /locate ---');
    for (const st of ['fortress', 'bastion_remnant']) {
        const p = await locate(con, st, 'the_nether');
        log(`  locate(the_nether) ${st} → ${JSON.stringify(p)}`);
    }

    // --- 3) 递归下钻：stronghold → 12 个末地门框 ---
    log('--- 3) 下钻 end_portal_frame（先用 cubiomes 已知坐标 1556,356 定位区域）---');
    const sh = await locate(con, 'stronghold', 'overworld');
    const cx = sh?.x ?? 1556, cz = sh?.z ?? 356;
    log(`  stronghold 起点 → (${cx}, ${cz})`);

    const ySlices = [[10, 35], [36, 60]];
    const res = await drill(con, 'overworld', cx, cz, 48, ySlices, ['minecraft:end_portal_frame'], { logFn: log });
    log(`  r48 下钻：end_portal_frame=${res.counts['minecraft:end_portal_frame']} 地形=${JSON.stringify(res.terrain)} 盒=${res.boxes} 全零对照盒=${res.boxesZeroControl} fills=${res.fills}${res.truncated ? ' (截断!)' : ''}`);
    const frames = res.perBlock['minecraft:end_portal_frame'].points;
    log(`  ★ 精确定位到 end_portal_frame 共 ${frames.length} 个：`);
    for (const p of frames) log(`      (${p.x}, ${p.y}, ${p.z})`);
    // 自检：12 个框应当构成 3×4 矩形（在 XZ 平面上）
    if (frames.length === 12) {
        const xs = [...new Set(frames.map((p) => p.x))].sort((a, b) => a - b);
        const zs = [...new Set(frames.map((p) => p.z))].sort((a, b) => a - b);
        const ys = [...new Set(frames.map((p) => p.y))];
        log(`  几何自检：X 跨度 ${xs[0]}..${xs.at(-1)}（${xs.length} 个值）/ Z ${zs[0]}..${zs.at(-1)}（${zs.length} 个值）/ Y ${ys.join(',')}`);
    }
    fs.writeFileSync(path.join(RUN, 'frames.json'), JSON.stringify({ seed: SEED, strongholdStart: [cx, cz], frames }, null, 2));
} catch (e) {
    log(`✗ smoke 失败: ${e && e.stack ? e.stack : e}`);
    process.exitCode = 1;
} finally {
    await shutdownLaneC(server);
    log(`收工：端口 ${JSON.stringify(portState())}`);
}

