// r7c_chest_locus.mjs — ROUND7-C 续单3：地牢箱的**站位几何**（纯离线，不开服）
//
// 【为什么先做这个】续单3 要让 bot 真的走到箱子前把箱打开。站位不能靠线上试错：
//   ① 箱子在 y=39 的地牢里，`/tp` 到一个"看起来空"的位置可能把人塞进岩石；
//   ② `openContainer` 走 `activateBlock`，**服务端按 bot 看到的朝向做射线**（手册 §3），
//      站位不对就是"对着空气点"——**静默失败，不报错**。
//   ⇒ 先用只读存档解析器把三个箱子周边的真实方块读出来，**离线**算出站得住 + 看得见的格。
//
// 【复用生产解析器】只 import `region_reader.mjs`（只读），自己不发任何命令、不开服。
//
// 【自带阳性对照】（手册 §5）
//   - 地形对照：读数里必须出现 `stone` / `dirt` / `air`，全零先证伪工具。
//   - 视线判据的阳性对照：`selftestLocus()` 造"一堵墙挡路"与"空走廊"两个已知场景，
//     断言 DDA 分别判 `blocked` / `clear`。**没有这一步，"看得见"本身不可信。**
//
// 【口径】
//   - 站住：脚下 1 格**非空气且非液体**（站得住 = 不会掉下去），身体 2 格空气。
//   - 眼位：`feet + 1.62`（1.16.1 玩家眼高）。
//   - 够得着：眼位到箱体中心的**欧氏距离 ≤ REACH_SAFE(4.0)**（服务端上限 5.0，留 1 格余量）。
//   - 看得见：眼位→箱体中心的体素 DDA，**中间格**全部 see-through。
//     端点格（眼位所在格、箱体格）不计。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld, bare } from './region_reader.mjs';

const ROUTE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const argOf = (argv, k, d) => {
    const hit = argv.find((a) => a.startsWith(`--${k}=`));
    return hit ? hit.slice(k.length + 3) : d;
};

export const SEED = '4926685115947721762';
export const WORLD = argOf(process.argv, 'world', path.join(ROUTE_DIR, 'probe', '_bedhunt'));
export const REACH_SAFE = 4.0;
const SEE_THROUGH = new Set(['air', 'cave_air', 'void_air', 'grass', 'torch', 'redstone_torch', 'rail', 'vine', 'snow', 'dead_bush', 'tallgrass', 'seagrass', 'ladder', 'wall_torch', 'lever', 'stone_button', 'sugar_cane']);
const LIQUID = new Set(['water', 'lava']);

// ---- 三个目标箱（来源：bench/route/probe/leg1_shortcut.round7c.json，本单不改 route） ----
export const TARGETS = [
    { id: 'dungeon_A', xyz: [167, 39, 212], kind: 'simple_dungeon', lootTable: 'minecraft:chests/simple_dungeon', lootTableSeed: '-5724797073669668449' },
    { id: 'dungeon_B', xyz: [165, 39, 212], kind: 'simple_dungeon', lootTable: 'minecraft:chests/simple_dungeon', lootTableSeed: '-3182977001765690829' },
    { id: 'S1_ruined_portal', xyz: [184, 40, 310], kind: 'ruined_portal', lootTable: 'minecraft:chests/ruined_portal', lootTableSeed: '-4614222673420210636' },
];

/**
 * 3D 体素 DDA：从 `from` 走到 `to`，返回沿途**中间格**（不含起点格与终点格）。
 * ⚠⚠ 逐轴用自己的方向（跨线公告第 ② 条：三轴共用一个闭包会让 y/z 的 tMax 算大，
 *    遍历留在错误的高度层里，**永远踩不到终点格**，于是"看得见"被读成"看不见"）。
 * ⚠⚠ 零位移轴**显式置 Infinity**（`Infinity * 0 = NaN`，NaN 让所有比较为 false）。
 * ⚠ 终止条件有两条：踩到终点格，或 t > 1（防止终点坐标在格内时死循环）。
 */
export function ddaCells(from, to, maxSteps = 128) {
    const out = [];
    let x = Math.floor(from[0]), y = Math.floor(from[1]), z = Math.floor(from[2]);
    const ex = Math.floor(to[0]), ey = Math.floor(to[1]), ez = Math.floor(to[2]);
    const dx = to[0] - from[0], dy = to[1] - from[1], dz = to[2] - from[2];
    const stepX = dx > 0 ? 1 : dx < 0 ? -1 : 0;
    const stepY = dy > 0 ? 1 : dy < 0 ? -1 : 0;
    const stepZ = dz > 0 ? 1 : dz < 0 ? -1 : 0;
    const tDeltaX = stepX === 0 ? Infinity : Math.abs(1 / dx);
    const tDeltaY = stepY === 0 ? Infinity : Math.abs(1 / dy);
    const tDeltaZ = stepZ === 0 ? Infinity : Math.abs(1 / dz);
    // ⚠ 三根轴**各自**算 tMax（方向用自己的 step），共用闭包就是上面那个 bug
    const tMaxX = stepX === 0 ? Infinity : (stepX > 0 ? (x + 1 - from[0]) : (from[0] - x)) / Math.abs(dx);
    const tMaxY = stepY === 0 ? Infinity : (stepY > 0 ? (y + 1 - from[1]) : (from[1] - y)) / Math.abs(dy);
    const tMaxZ = stepZ === 0 ? Infinity : (stepZ > 0 ? (z + 1 - from[2]) : (from[2] - z)) / Math.abs(dz);
    let tX = tMaxX, tY = tMaxY, tZ = tMaxZ, t = 0;
    out.push([x, y, z]);
    for (let i = 0; i < maxSteps; i++) {
        if (x === ex && y === ey && z === ez) return out;
        if (tX <= tY && tX <= tZ) { x += stepX; t = tX; tX += tDeltaX; }
        else if (tY <= tZ) { y += stepY; t = tY; tY += tDeltaY; }
        else { z += stepZ; t = tZ; tZ += tDeltaZ; }
        if (t > 1) break;                  // 终点坐标在格内 ⇒ 已越过终点面
        // ⚠⚠ **先 push 再判终点**：反过来写会把终点格漏在 out 之外
        //    （本单自检 T2/T5 抓到的就是这个——判据"看起来能跑"，实际少看一格）
        out.push([x, y, z]);
        if (x === ex && y === ey && z === ez) return out;
    }
    return out;
}

const dist3 = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

/**
 * 单条视线的判定：返回 {clear, blockedBy}。
 * ⚠ **"没读到"与"被挡住"必须分字段**（手册 §5：`blockAt` 返 `unknown` 时不能当成"空气 ⇒ 通"）。
 *   `unknown` 一律算 `readFailed` 交回调用方，本函数只回答"已读到的格子里有没有挡路的"。
 */
export function losVerdict(world, eye, box) {
    const path = ddaCells(eye, box);
    for (let i = 1; i < path.length - 1; i++) {          // 不含起点格与终点箱格
        const n = world.blockAt(path[i][0], path[i][1], path[i][2]);
        if (n === 'unknown') return { clear: false, readFailed: true, blockedBy: { cell: path[i], block: 'unknown' } };
        if (!SEE_THROUGH.has(n)) return { clear: false, readFailed: false, blockedBy: { cell: path[i], block: n } };
    }
    return { clear: true, readFailed: false, blockedBy: null };
}

/** 站得住 + 看得见某箱子的候选格，按"离箱体中心距离"升序。 */
export function standSpotsFor(world, chest, opts = {}) {
    const reach = opts.reach ?? REACH_SAFE;
    const R = opts.scan ?? 6;
    const [cx, cy, cz] = chest;
    const box = [cx + 0.5, cy + 0.5, cz + 0.5];
    const spots = [];
    // 站位扫描（目标格本身必须是 chest，否则整段结论无意义 —— 由调用方单独断言）
    for (let y = cy - R; y <= cy + R; y++) {
        for (let z = cz - R; z <= cz + R; z++) {
            for (let x = cx - R; x <= cx + R; x++) {
                const feet = world.blockAt(x, y, z);
                const below = world.blockAt(x, y - 1, z);
                const head = world.blockAt(x, y + 1, z);
                const feetPass = SEE_THROUGH.has(feet);
                const headPass = SEE_THROUGH.has(head);
                const groundOk = below !== 'air' && below !== 'unknown' && !LIQUID.has(below)
                    && !SEE_THROUGH.has(below) && below !== 'cave_air' && below !== 'void_air';
                if (!feetPass || !headPass || !groundOk) continue;
                const eye = [x + 0.5, y + 1.62, z + 0.5];
                const d = dist3(eye, box);
                if (d > reach) continue;
                const los = losVerdict(world, eye, box);
                if (!los.clear) continue;
                spots.push({ stand: [x, y, z], eye, dist: +d.toFixed(3), pathCells: ddaCells(eye, box).length });
            }
        }
    }
    spots.sort((a, b) => a.dist - b.dist);
    return spots;
}

/** 一个站位能不能同时够到多个箱子（本次要找"一个点开两箱"的最优站位）。 */
function scoreForSet(world, chests, p) {
    const res = [];
    for (const ch of chests) {
        const box = [ch.xyz[0] + 0.5, ch.xyz[1] + 0.5, ch.xyz[2] + 0.5];
        const eye = [p[0] + 0.5, p[1] + 1.62, p[2] + 0.5];
        const d = dist3(eye, box);
        if (d > REACH_SAFE) { res.push(null); continue; }
        const path = ddaCells(eye, box);
        let ok = losVerdict(world, eye, box).clear;
        res.push(ok ? +d.toFixed(3) : null);
    }
    return res;
}

export function selftestLocus() {
    // 假世界：只给 blockAt。`def` 是没列出的格子的读数（用来造"岩浆里"或"没读到"的场景）
    const fake = (grid, def = 'unknown') => ({ blockAt: (x, y, z) => (grid.has(`${x},${y},${z}`) ? grid.get(`${x},${y},${z}`) : def) });
    const results = [];
    // T1 墙体阻断：x=0 的洞被 x=5 处一堵 stone 墙拦住
    {
        const g = new Map();
        for (let x = 0; x <= 12; x++) for (let y = 0; y <= 4; y++) for (let z = 0; z <= 4; z++) g.set(`${x},${y},${z}`, 'air');
        for (let y = 0; y <= 4; y++) for (let z = 0; z <= 4; z++) g.set(`5,${y},${z}`, 'stone');
        const w = fake(g);
        const path = ddaCells([1.5, 2.62, 2.5], [9.5, 2.5, 2.5]);
        const crossedWall = path.some((c) => c[0] === 5);
        const hitsEnd = path[path.length - 1][0] === 9;
        results.push({ id: 'T1 墙在路径上 ⇒ DDA 必须踩到墙那一格，且能踩到终点格', pass: crossedWall && hitsEnd, detail: { crossedWall, hitsEnd, last: path[path.length - 1] } });
    }
    // T2 纯 x 射线：零位移轴不得变 NaN（NaN 会让遍历永远挑同一根轴）
    {
        const g = new Map();
        for (let x = 0; x <= 12; x++) for (let y = 0; y <= 4; y++) for (let z = 0; z <= 4; z++) g.set(`${x},${y},${z}`, 'air');
        const w = fake(g);
        const path = ddaCells([0.5, 2.62, 2.5], [9.5, 2.62, 2.5]);
        const ys = new Set(path.map((c) => c[1]));
        const zs = new Set(path.map((c) => c[2]));
        results.push({ id: 'T2 纯 x 射线：y/z 恒定、无 NaN、踩到终点格', pass: ys.size === 1 && zs.size === 1 && path[path.length - 1][0] === 9, detail: { last: path[path.length - 1] } });
    }
    // T3 **异号 y 的斜射线**（跨线公告那条 bug 的活例子：dy 与 dx 异号）
    {
        const g = new Map();
        for (let x = -10; x <= 10; x++) for (let y = -10; y <= 10; y++) for (let z = -10; z <= 10; z++) g.set(`${x},${y},${z}`, 'air');
        const w = fake(g);
        const path = ddaCells([0.5, 9.5, 0.5], [9.5, 0.5, 0.5]);   // dx>0, dy<0, dz=0
        const last = path[path.length - 1];
        results.push({ id: 'T3 dx>0 且 dy<0：必须踩到终点格（否则说明三轴方向写错了）', pass: last[0] === 9 && last[1] === 0 && last[2] === 0, detail: { last } });
    }
    // T4 视线判据本身（阳性+阴性成对）：1 格宽走廊，箱在 z=2 通道里；
    //    同一个眼位，加墙前判 clear、加墙后判 blocked。**判据不翻转 = 判据没在工作。**
    {
        const g = new Map();
        for (let x = 0; x <= 12; x++) for (let y = 0; y <= 4; y++) g.set(`${x},${y},2`, 'air');   // 只有 z=2 是洞，其余默认 stone
        g.set('9,2,2', 'chest');
        const eye = [2.5, 3.62, 2.5], box = [9.5, 2.5, 2.5];
        const w1 = fake(g, 'stone');
        const clearVerdict = losVerdict(w1, eye, box);
        for (let y = 0; y <= 4; y++) g.set(`5,${y},2`, 'stone');                                    // 加一堵墙
        const w2 = fake(g, 'stone');
        const blockedVerdict = losVerdict(w2, eye, box);
        results.push({
            id: 'T4 视线判据：同一眼位，加墙前 clear、加墙后 blocked（成对对照）',
            pass: clearVerdict.clear === true && blockedVerdict.clear === false && blockedVerdict.blockedBy?.cell?.[0] === 5,
            detail: { clear: clearVerdict.clear, blocked: blockedVerdict.clear, by: blockedVerdict.blockedBy },
        });
    }
    // T5 **"没读到"不许当成"看得见"**：把中间格读成 unknown ⇒ 必须判 readFailed 而不是 clear
    {
        const g = new Map();
        for (let x = 0; x <= 12; x++) for (let y = 0; y <= 4; y++) for (let z = 0; z <= 4; z++) g.set(`${x},${y},${z}`, 'air');
        g.set('9,2,2', 'chest');
        for (let x = 0; x <= 12; x++) for (let z = 0; z <= 4; z++) g.set(`${x},-1,${z}`, 'stone');
        for (let x = 0; x <= 12; x++) for (let z = 0; z <= 4; z++) if (x !== 6) g.set(`${x},3,${z}`, 'unknown');
        const w = fake(g, 'air');
        const v = losVerdict(w, [2.5, 3.62, 2.5], [9.5, 2.5, 2.5]);
        results.push({ id: 'T5 中间格 unknown ⇒ 必须 readFailed（不得读成 clear）', pass: v.clear === false && v.readFailed === true, detail: v });
    }
    // T6 地面判据：脚下是空气的格子一个都不许出现在候选里；铺上地板后候选才出现
    {
        const g = new Map();
        for (let x = 0; x <= 12; x++) for (let y = 0; y <= 4; y++) for (let z = 0; z <= 4; z++) g.set(`${x},${y},${z}`, 'air');
        g.set('9,2,2', 'chest');
        const noFloor = standSpotsFor(fake(g, 'air'), [9, 2, 2], { scan: 4 })
            .filter((s) => { const b = g.get(`${s.stand[0]},${s.stand[1] - 1},${s.stand[2]}`); return b === 'air' || b === 'unknown'; });
        for (let x = 0; x <= 12; x++) for (let z = 0; z <= 4; z++) g.set(`${x},-1,${z}`, 'stone');
        const withFloor = standSpotsFor(fake(g, 'air'), [9, 2, 2], { scan: 4 });
        const allGrounded = withFloor.every((s) => {
            const b = g.get(`${s.stand[0]},${s.stand[1] - 1},${s.stand[2]}`) ?? 'air';
            return b !== 'air' && b !== 'unknown' && !SEE_THROUGH.has(b);   // 脚下必须是实心（可以是箱子顶）
        });
        const onChest = withFloor.filter((s) => s.stand[1] === 3 && s.stand[0] === 9 && s.stand[2] === 2).length;
        results.push({ id: 'T6 地面判据：无地板 ⇒ 无任何"脚下悬空"的候选；铺地板 ⇒ 候选全部脚下实心', pass: noFloor.length === 0 && withFloor.length > 0 && allGrounded, detail: { floating: noFloor.length, withFloor: withFloor.length, onChest } });
    }
    return results;
}

// ---- CLI ----
if (process.argv[1] && fs.realpathSync(process.argv[1]) === fileURLToPath(import.meta.url)) {
    const st = selftestLocus();
    console.log('=== 判据自检 ===');
    for (const r of st) console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${r.id}${r.detail ? '  ' + JSON.stringify(r.detail) : ''}`);
    const stOK = st.every((r) => r.pass);
    console.log(`自检 ${st.filter((r) => r.pass).length}/${st.length} ⇒ ${stOK ? 'OK' : 'SELFTEST_FAILED'}\n`);
    if (!stOK) process.exit(2);

    const world = openWorld(WORLD, { dims: ['overworld'] });
    const out = { schema: 'aidqq-round7c-chest-locus/1', at: new Date().toISOString(), seed: SEED, world: WORLD, reachSafe: REACH_SAFE, selftest: st, targets: [] };

    for (const t of TARGETS) {
        const [cx, cy, cz] = t.xyz;
        // 地形对照：读数全零 ⇒ 先证伪工具
        const palette = {};
        const R = 5;
        for (let y = cy - R; y <= cy + R; y++) for (let z = cz - R; z <= cz + R; z++) for (let x = cx - R; x <= cx + R; x++) {
            const b = world.blockAt(x, y, z);
            palette[b] = (palette[b] ?? 0) + 1;
        }
        const chk = world.blockAt(cx, cy, cz) === 'chest';
        const spots = standSpotsFor(world, t.xyz, { scan: R });
        out.targets.push({
            ...t,
            blockCheck: { isChest: chk, got: world.blockAt(cx, cy, cz) },
            paletteTop: Object.entries(palette).sort((a, b) => b[1] - a[1]).slice(0, 8),
            spotCount: spots.length,
            bestSpots: spots.slice(0, 6),
        });
        console.log(`\n=== ${t.id} (${cx},${cy},${cz}) 目标格=${world.blockAt(cx, cy, cz)} ===`);
        console.log('  地形对照:', JSON.stringify(out.targets[out.targets.length - 1].paletteTop));
        console.log(`  合格站位 ${spots.length} 个，前 5：`);
        for (const s of spots.slice(0, 5)) console.log(`    stand=(${s.stand.join(',')})  眼距箱心 ${s.dist} 格  视线路径 ${s.pathCells} 格`);
    }

    // 一个站位同时够到两个地牢箱？
    const dungeon = TARGETS.filter((t) => t.kind === 'simple_dungeon');
    const common = [];
    {
        const R = 6;
        const [ax, ay, az] = dungeon[0].xyz;
        for (let y = ay - R; y <= ay + R; y++) for (let z = az - R; z <= az + R; z++) for (let x = ax - R; x <= ax + R; x++) {
            const feet = world.blockAt(x, y, z), below = world.blockAt(x, y - 1, z), head = world.blockAt(x, y + 1, z);
            if (!SEE_THROUGH.has(feet) || !SEE_THROUGH.has(head)) continue;
            if (below === 'air' || below === 'unknown' || LIQUID.has(below) || SEE_THROUGH.has(below)) continue;
            const sc = scoreForSet(world, dungeon, [x, y, z]);
            if (sc.every((v) => v !== null)) common.push({ stand: [x, y, z], dists: sc, sum: +sc.reduce((a, b) => a + b, 0).toFixed(3) });
        }
        common.sort((a, b) => a.sum - b.sum);
    }
    out.commonSpotForBothDungeonChests = { count: common.length, best: common.slice(0, 5) };
    console.log(`\n=== 一个站位同时够到两个地牢箱：${common.length} 个 ===`);
    for (const c of common.slice(0, 5)) console.log(`    stand=(${c.stand.join(',')})  眼距 ${JSON.stringify(c.dists)}  合计 ${c.sum}`);

    const outPath = path.join(ROUTE_DIR, 'probe', 'chest_locus.round7c.json');
    fs.writeFileSync(outPath, JSON.stringify(out, null, 2));
    console.log(`\n落盘：${path.relative(process.cwd(), outPath)}`);
    console.log(`(bare 导出自检: ${bare('minecraft:chest')})`);
}
