// worldgen_for_region.mjs — R6-3：借泳道**生成并保存**世界，供离线解析器读取
//
// 【为什么不直接用控制台数】控制台通道在 C/F 线反复返工（FIFO 回执、未知方块名零回执、
//   forceload 异步、实体计数没有阳性对照、`execute as @e[...,r=N]` 不支持距离参数）。
//   本文件**只用控制台做两件事**：① 布景（forceload / summon）② `save-all flush`；
//   读数一律交给 region_reader 离线做。
//
// 【流程】
//   fresh world（种子）→ 分批 forceload（单次 ≤256 区块）→ 轮询就绪 → 召唤羊（阳性对照实体）
//   → `save-all flush` → 停服 → 离线解析。
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\worldgen_for_region.mjs \
//         --seed 4926685115947721762 --tag main --budget-ms 900000 [--summon-sheep 3]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, waitForLaneC, ROUTE_DIR } from './console.mjs';
import { forceload } from './scan.mjs';

const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const TAG = argOf(process.argv, 'tag', 'main');
const BUDGET_MS = parseInt(argOf(process.argv, 'budget-ms', '900000'), 10);
const SUMMON_SHEEP = parseInt(argOf(process.argv, 'summon-sheep', '3'), 10);
const RUN_DIR = path.join(PROBE_DIR, '_run_round6c', TAG);
const OUT = path.join(PROBE_DIR, `worldgen_${TAG}.json`);

/** 出生点（SEED-01 top_ranked.csv：`spawn_x=216, spawn_z=224, spawn_biome=plains`） */
const SPAWN = { x: 216, z: 224 };
const BATCH = 256;                                     // 单次 forceload 的区块上限（派单要求 ≤256）

/**
 * forceload 的目标区清单。**一次 fresh world 里主世界与下界是同一个存档的两个维度**
 *  （主世界 `world/region/`，下界 `world/DIM-1/region/`）⇒ 一次借道就能覆盖全部阳性对照。
 *
 * ⚠⚠ **对照区（sheep-control）必须与统计区（sheep-area）完全不重叠**：
 *   ROUND6 第一轮把 summon 的 3 只羊放在**羊区里面**做实体阳性对照，而**羊会游走**，
 *   于是两个 fresh world 的"羊坐标"必然不一致、统计的是"召唤羊 + 自然羊"的混合体 ⇒ 判读作废。
 *   现在把召唤点挪到羊区外 300 格开外的对照区；对照区同样要 forceload（否则实体不落盘、对照白做）。
 */
const SHEEP_AREA = { name: 'sheep-area', dim: 'overworld', cx: SPAWN.x, cz: SPAWN.z, chunks: 16, for: '羊站统计区（出生点周边 16×16 区块）' };
const SHEEP_CTRL = { name: 'sheep-control', dim: 'overworld', cx: SPAWN.x + 300, cz: SPAWN.z, chunks: 4, for: '实体阳性对照区（羊区外 300 格，互不重叠）' };
/** ★下一单：找村庄的床 + 扩大范围找羊。±384 格 = 48×48 = 2304 区块（9 批，每批 ≤256）。 */
const BED_HUNT = { name: 'bed-hunt', dim: 'overworld', cx: SPAWN.x, cz: SPAWN.z, chunks: 48, for: '★床/羊普查：出生点 ±384 格（48×48 区块，分 9 批 forceload）' };
const REGIONS = [
    BED_HUNT,
    SHEEP_CTRL,
    { name: 's1-portal', dim: 'overworld', cx: 180, cz: 355, chunks: 4, for: '阳性对照 1：S1 门框 20 格（origin 180,77,355 axis=z）' },
    { name: 'c2-bastion', dim: 'the_nether', cx: 335, cz: 256, chunks: 8, for: '阳性对照 3：C-2 堡垒 gold_block 22 / gilded_blackstone 227 / chest 5' },
    { name: 'c3-fortress', dim: 'the_nether', cx: 221, cz: -85, chunks: 8, for: '阳性对照 2：C-3 刷怪笼 7³ 盒逐格' },
];

/** 召唤羊（实体阳性对照）——落在**对照区**中心，绝不与统计区重叠。 */
const SHEEP_AT = [
    { x: SHEEP_CTRL.cx, y: 70, z: SHEEP_CTRL.cz },
    { x: SHEEP_CTRL.cx - 6, y: 70, z: SHEEP_CTRL.cz + 5 },
    { x: SHEEP_CTRL.cx + 7, y: 70, z: SHEEP_CTRL.cz - 6 },
];

/** 羊区统计范围（16×16 区块的方框）——判读只用这个范围。 */
export const SHEEP_AREA_BOX = {
    x1: SPAWN.x - 128, y1: 0, z1: SPAWN.z - 128, x2: SPAWN.x + 128, y2: 255, z2: SPAWN.z + 128,
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 区域 → forceload 批（每批 ≤BATCH 区块；沿 z 方向切） */
function planBatches(region) {
    const n = region.chunks;
    const per = Math.max(1, Math.floor(BATCH / n));
    const out = [];
    for (let zc = 0; zc < n; zc += per) {
        const zc1 = Math.min(n, zc + per);
        const x0 = region.cx - (n * 16) / 2, z0 = region.cz - (n * 16) / 2;
        out.push({
            x0, z0, x1: region.cx + (n * 16) / 2, z1: z0 + zc1 * 16 - (n * 16) / 2 + (n * 16) / 2,
            chunks: n * (zc1 - zc),
        });
    }
    return out;
}

async function cmdOnce(con, cmd, re, timeoutMs = 20000) {
    con.drain();
    con.cmd(cmd);
    const t0 = Date.now();
    const seen = [];
    for (;;) {
        for (const line of con.drain()) { seen.push(line); if (re.test(line)) return line; }
        if (Date.now() - t0 > timeoutMs) throw new Error(`CMD_NO_RECEIPT: ${cmd}（${seen.slice(-2).join(' | ').slice(0, 120)}）`);
        await sleep(50);
    }
}

async function bootRobust(seed, runDir, label, { rounds = 4, coolMs = 75000 } = {}) {
    for (let round = 1; round <= rounds; round++) {
        try { return await bootLaneC({ seed, runDir, logFn: log }); }
        catch (e) {
            const logPath = path.join(runDir, 'server.log');
            let txt = '';
            try { txt = fs.readFileSync(logPath, 'utf8'); } catch { /* no file */ }
            const bind = /Address already in use/i.test(txt);
            if (!bind) throw e;
            if (round === rounds) throw new Error(`BOOT_BIND_ROUNDS_EXHAUSTED`);
            log(`  [${label}] 端口被别人占（BindException），冷却 ${Math.round(coolMs / 1000)}s 后重新排队`);
            await sleep(coolMs);
            await waitForLaneC({ timeoutMs: 15 * 60 * 1000, logFn: log });
        }
    }
    throw new Error('BOOT_ROUNDS_EXHAUSTED');
}

const out = { schema: 'aidqq-round6c-worldgen/1', seed: SEED, tag: TAG, mcVersion: '1.16.1', lane: 'C', startedAt: new Date().toISOString(), status: 'NOT_RUN', batches: [], savedAt: null };
let h = null;
try {
    out.status = 'RUNNING';
    log(`=== R6-3 世界生成（tag=${TAG}）===`);
    h = await bootRobust(SEED, RUN_DIR, TAG);
    const con = h.con;
    out.bootMs = h.server.bootMs;
    // ⚠ 世界目录名来自 server.properties 的 level-name（本机三个 lane 都是 spike_world，不是 world）
    const sp = fs.readFileSync(path.join(h.lane.dir, 'server.properties'), 'utf8');
    const levelName = (/level-name=(.*)/.exec(sp)?.[1] ?? 'world').trim();
    out.levelName = levelName;
    out.worldDir = path.join(h.lane.dir, levelName);
    out.regions = REGIONS;

    // ---- 分批 forceload（每批 ≤256 区块；主世界与下界是同一个存档的两个维度）
    for (const R of REGIONS) {
        for (const bt of planBatches(R)) {
            await forceload(con, R.dim, bt.x0, bt.z0, bt.x1, bt.z1, 1200);
            out.batches.push({ region: R.name, dim: R.dim, chunks: bt.chunks, bytes: `${bt.x0},${bt.z0}..${bt.x1},${bt.z1}` });
            log(`  forceload [${R.name}/${R.dim}] ${bt.chunks} 区块（${R.for}）`);
        }
    }
    // ---- 就绪校验：中心一格 fill 必须给出回执（不是 not loaded）
    const ready = await cmdOnce(con, `fill ${SPAWN.x} 70 ${SPAWN.z} ${SPAWN.x} 70 ${SPAWN.z} minecraft:barrier replace minecraft:stone`, /Successfully filled|No blocks were filled|not loaded/i, 30000);
    out.readyProbe = ready;
    log(`  就绪探测：${ready}`);
    if (/not loaded/i.test(ready)) throw new Error('CHUNK_GATE_NOT_LOADED');

    // ---- 召唤羊（实体阳性对照 + 羊站数据）
    for (const p of SHEEP_AT.slice(0, SUMMON_SHEEP)) {
        const line = await cmdOnce(con, `summon minecraft:sheep ${p.x} ${p.y} ${p.z}`, /Summoned new Sheep/i, 15000);
        log(`  summon 羊 @(${p.x},${p.y},${p.z})：${line}`);
    }
    out.summonedSheep = SHEEP_AT.slice(0, SUMMON_SHEEP);

    // ---- save-all flush（没有 flush，数据可能还在内存里）→ 停服
    const saveLine = await cmdOnce(con, 'save-all flush', /Saved the game|Flushing|Saved/i, 120000);
    out.saveLine = saveLine;
    log(`  ${saveLine}`);
    await sleep(2500);
    await shutdownLaneC(h); h = null;
    out.status = 'SAVED';
    out.savedAt = new Date().toISOString();
    log(`  世界已保存并停服：${out.worldDir}`);
} catch (e) {
    out.error = String(e && e.stack ? e.stack : e);
    if (out.status === 'RUNNING') out.status = 'FAILED';
    log(`✗ ${out.status}：${String(e).split('\n')[0]}`);
} finally {
    try { if (h) await shutdownLaneC(h); } catch { /* ignore */ }
    out.seconds = Math.round((Date.now() - Date.parse(out.startedAt)) / 1000);
    fs.mkdirSync(PROBE_DIR, { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
    log(`落盘：${path.relative(process.cwd(), OUT)}（status=${out.status}，${out.seconds}s）`);
}
