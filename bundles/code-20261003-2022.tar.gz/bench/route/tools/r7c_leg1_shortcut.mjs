// r7c_leg1_shortcut.mjs — ROUND7-C 续单（低优先项 4）：第 1 段的"现成铁源与桶"预勘
//
// 【问什么】出生点 ±384 格内，有哪些**现成的铁/桶/打火石**（结构箱 + 暴露铁矿），
//   每个候选离出生点与 S1 门多远、能拿多少。**只出数据，不改 route。**
//
// 【三处口径说明】
//   ① **箱内物品按 1.16.1 原版战利品表解析，而��是从记忆里断言**：直接读服务端 jar 里的
//      `data/minecraft/loot_tables/chests/*.json`（权威、离线、可复现），递归展开
//      `loot_table` 引用后列出**可能出现的物品与数量区间**。
//      ⚠ 这给的是"**该表可能出什么**"（表级），**不是"这一个箱子实际出了什么"**（实例级）——
//      实例级由 `LootTableSeed` 决定，本单**没有**实现原版战利品算法，**不编造实例结果**。
//      派单允许"在另一份 fresh world 里用控制台开箱读出内容"，本单**没做**那一趟（见 report 的未验项）。
//   ② **暴露面判据**与本线其它工具一致：6 个面邻格里 ≥1 个属于 {air,cave_air,void_air}。
//   ③ "地表或浅层"判据：`y <= 地表高度 + 4`。地表高度取该格所在列的**最高非空气格**。
//
// 【只读】不写 route、不改任何既有产物。

import fs from 'fs';
import path from 'path';
import zlib from 'zlib';
import { fileURLToPath } from 'url';
import { readChunkNbt, openWorld, NbtReader } from './region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE_DIR = path.resolve(HERE, '..');
const PROBE = path.join(ROUTE_DIR, 'probe');
const WORLD = path.join(PROBE, '_bedhunt');
const JAR = process.env.MC_BENCH_JAR
    || 'D:/AI斗蛐蛐/experiments/mc1161-gate/server-1161/server-1.16.1.jar';
const OUT = path.join(PROBE, 'leg1_shortcut.round7c.json');
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };

const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);
const WANT = { iron: /^(minecraft:)?(iron_ingot|iron_nugget|iron_ore|iron_shovel|iron_pickaxe|iron_axe|iron_helmet|iron_chestplate|iron_leggings|iron_boots)$/, bucket: /^(minecraft:)?bucket$/, flint: /^(minecraft:)?(flint|flint_and_steel)$/ };

// ================================================================== 1. 从 jar 读战利品表
function readJarEntry(entryName) {
    const buf = fs.readFileSync(JAR);
    // 找中央目录
    let eocd = buf.length - 22;
    while (eocd >= 0 && buf.readUInt32LE(eocd) !== 0x06054b50) eocd--;
    if (eocd < 0) throw new Error('ZIP 中央目录没找到');
    const n = buf.readUInt16LE(eocd + 10);
    let off = buf.readUInt32LE(eocd + 16);
    for (let i = 0; i < n; i++) {
        if (buf.readUInt32LE(off) !== 0x02014b50) break;
        const nameLen = buf.readUInt16LE(off + 28), extraLen = buf.readUInt16LE(off + 30), cmtLen = buf.readUInt16LE(off + 32);
        const lho = buf.readUInt32LE(off + 42);
        const name = buf.toString('utf8', off + 46, off + 46 + nameLen);
        if (name === entryName) {
            const method = buf.readUInt16LE(off + 10), csize = buf.readUInt32LE(off + 20);
            const lNameLen = buf.readUInt16LE(lho + 26), lExtraLen = buf.readUInt16LE(lho + 28);
            const dstart = lho + 30 + lNameLen + lExtraLen;
            const raw = buf.subarray(dstart, dstart + csize);
            return method === 0 ? raw : zlib.inflateRawSync(raw);
        }
        off += 46 + nameLen + extraLen + cmtLen;
    }
    return null;
}
const lootCache = new Map();
function lootTable(id) {
    const key = String(id);
    if (lootCache.has(key)) return lootCache.get(key);
    const rel = 'data/minecraft/loot_tables/' + key.replace('minecraft:', '').replace('chests/', 'chests/') + '.json';
    let t = null;
    for (const cand of [rel, 'data/minecraft/loot_tables/chests/' + key.replace('minecraft:chests/', '') + '.json']) {
        const b = readJarEntry(cand);
        if (b) { t = JSON.parse(b.toString('utf8')); break; }
    }
    lootCache.set(key, t);
    return t;
}
/** 递归展开一个战利品表，收集"物品 → 数量区间"（只处理本工具关心的三类） */
function summarizeLoot(id, depth = 0, seen = new Set()) {
    const out = {};
    if (depth > 6 || seen.has(id)) return out;
    seen.add(id);
    const t = lootTable(id);
    if (!t) return out;
    const walk = (node) => {
        if (!node || typeof node !== 'object') return;
        if (Array.isArray(node)) { node.forEach(walk); return; }
        if (node.type === 'minecraft:table' && node.name) { Object.assign(out, summarizeLoot(node.name, depth + 1, new Set(seen))); return; }
        if (node.type === 'minecraft:item' && node.name) {
            const cat = Object.keys(WANT).find((k) => WANT[k].test(node.name));
            if (!cat) return;
            // 数量：SetNbt 里的 min/max；没有就是 1
            let min = 1, max = 1;
            const f = (node.functions ?? []).find((x) => /set_count/i.test(x.function ?? ''));
            if (f?.count) {
                if (typeof f.count.value === 'number') { min = max = f.count.value; }
                else if (f.count.min != null) { min = f.count.min; max = f.count.max; }
            }
            const e = out[cat] ?? (out[cat] = { items: new Set(), minTotal: 0, maxTotal: 0 });
            e.items.add(node.name.replace('minecraft:', ''));
            e.minTotal += min; e.maxTotal += max;
        }
        for (const v of Object.values(node)) walk(v);
    };
    walk(t);
    for (const k of Object.keys(out)) { out[k].items = [...out[k].items].sort(); out[k].rolls = t.rolls?.min ?? t.rolls ?? null; }
    return out;
}

// ================================================================== 2. 出生点 & S1
function levelSpawn(worldDir) {
    // ⚠ 第一版用**字符串查找 + 手算字节偏移**去读 level.dat，读出 SpawnX=14091008 这种离谱值
    //   **而且不报错**；改成 `i + key.length + 3` 仍错（"SpawnX" 第一次出现是**别的字符串里的假匹配**）。
    //   正解：**用真正的 NBT 解析器**。1.16.1 的 level.dat 根 compound 名为 ""，出生点在**嵌套的 `Data`** 里。
    const b = (() => { try { return zlib.gunzipSync(fs.readFileSync(path.join(worldDir, 'level.dat'))); } catch { return fs.readFileSync(path.join(worldDir, 'level.dat')); } })();
    const root = new NbtReader(b).readRoot().value;
    const D = root?.Data ?? root;                     // 1.16.1：根里套一层 "Data"
    const sp = { x: D?.SpawnX ?? null, y: D?.SpawnY ?? null, z: D?.SpawnZ ?? null, difficulty: D?.Difficulty ?? null, levelName: D?.LevelName ?? null };
    for (const [k, v] of [['x', sp.x], ['y', sp.y], ['z', sp.z]]) {
        if (!Number.isInteger(v) || Math.abs(v) > 30000000) throw new Error(`SPAWN_READ_SUSPECT：${k}=${v}（level.dat 解析有问题，拒绝继续 —— 宁可失败也不产出错坐标）`);
    }
    return sp;
}
const SPAWN = levelSpawn(WORLD);
const S1 = { x: 187, y: 41, z: 308 };
console.log(`出生点 = (${SPAWN.x}, ${SPAWN.y}, ${SPAWN.z})｜S1 门 ≈ (${S1.x}, ${S1.y}, ${S1.z})`);

// ================================================================== 3. 扫全部区块：箱子（TileEntities）+ 暴露铁矿
const w = openWorld(WORLD, { dims: ['overworld'] });
const chests = [];
{
    const dir = path.join(WORLD, 'region');
    for (const rf of fs.readdirSync(dir).filter((x) => x.endsWith('.mca'))) {
        const f = fs.readFileSync(path.join(dir, rf));
        if (f.length < 8192 + 4) continue;
        for (let i = 0; i < 1024; i++) {
            if (i * 4 + 3 >= f.length) break;
            const off = (f.readUInt8(i * 4) << 16) | (f.readUInt8(i * 4 + 1) << 8) | f.readUInt8(i * 4 + 2);
            const sec = f.readUInt8(i * 4 + 3);
            if (!off || !sec || off * 4096 + 8 > f.length) continue;
            const r = readChunkNbt(f, off * 4096, sec);
            if (!r.ok) continue;
            const be = r.root.Level?.TileEntities;
            if (!Array.isArray(be)) continue;
            for (const e of be) {
                if (e.id !== 'minecraft:chest' && e.id !== 'minecraft:trapped_chest') continue;
                const lt = e.LootTable ?? null;
                chests.push({
                    xyz: [e.x, e.y, e.z],
                    kind: e.id === 'minecraft:chest' ? 'chest' : 'trapped_chest',
                    lootTable: lt,
                    // ⚠ `LootTableSeed` 是 NBT **long**（tag 4）⇒ 解析器给的是 **BigInt**，
                    //   直接进 JSON.stringify 会抛 "Do not know how to serialize a BigInt"。
                    //   战利品种子是 64 位，**超出 Number 安全整数**，所以存字符串（无损）。
                    lootTableSeed: e.LootTableSeed != null ? (typeof e.LootTableSeed === 'bigint' ? e.LootTableSeed.toString() : String(e.LootTableSeed)) : null,
                    distToSpawnXZ: Math.hypot(e.x - SPAWN.x, e.z - SPAWN.z),
                    distToS1XZ: Math.hypot(e.x - S1.x, e.z - S1.z),
                    possibleLoot: lt ? summarizeLoot(lt) : null,
                });
            }
        }
    }
}
chests.sort((a, b) => a.distToSpawnXZ - b.distToSpawnXZ);
console.log(`\n箱子 ${chests.length} 个（overworld，_bedhunt 覆盖区）`);
for (const c of chests) {
    const can = c.possibleLoot ? Object.keys(c.possibleLoot).join('/') || '无(这三类都没有)' : '?';
    console.log(`  (${c.xyz.join(',')}) ${String(c.lootTable).replace('minecraft:chests/', '')} seed=${c.lootTableSeed} → 距出生点 ${c.distToSpawnXZ.toFixed(0)} / 距 S1 ${c.distToS1XZ.toFixed(0)} ｜可能给 ${can}`);
}

// ---- 暴露铁矿（地表或浅层）
const box = { x1: SPAWN.x - 384, y1: 0, z1: SPAWN.z - 384, x2: SPAWN.x + 384, y2: 127, z2: SPAWN.z + 384 };
const surf = new Map();
function surfaceY(x, z) {
    const k = x + ',' + z;
    if (surf.has(k)) return surf.get(k);
    let top = -1;
    for (let y = 127; y >= 0; y--) { if (!AIRLIKE.has(w.blockAt(x, y, z, 'overworld'))) { top = y; break; } }
    surf.set(k, top); return top;
}
const iron = [];
for (let x = box.x1; x <= box.x2; x += 1) {
    for (let z = box.z1; z <= box.z2; z += 1) {
        const sy = surfaceY(x, z);
        if (sy < 0) continue;
        for (let y = Math.max(0, sy - 24); y <= Math.min(127, sy + 4); y++) {
            const n = w.blockAt(x, y, z, 'overworld');
            if (n !== 'iron_ore' && n !== 'iron_ore_block') continue;
            const airFaces = [];
            for (const [dx, dy, dz, tag] of [[1, 0, 0, '+x'], [-1, 0, 0, '-x'], [0, 1, 0, '+y'], [0, -1, 0, '-y'], [0, 0, 1, '+z'], [0, 0, -1, '-z']]) {
                if (AIRLIKE.has(w.blockAt(x + dx, y + dy, z + dz, 'overworld'))) airFaces.push(tag);
            }
            if (!airFaces.length) continue;
            iron.push({
                xyz: [x, y, z], block: n, airFaces,
                depthBelowSurface: sy - y,
                distToSpawnXZ: Math.hypot(x - SPAWN.x, z - SPAWN.z),
                distToS1XZ: Math.hypot(x - S1.x, z - S1.z),
            });
        }
    }
}
iron.sort((a, b) => a.distToSpawnXZ - b.distToSpawnXZ);
const shallow = iron.filter((i) => i.depthBelowSurface <= 4);
console.log(`\n暴露铁矿：共 ${iron.length} 块（扫描窗 x${box.x1}..${box.x2} / z${box.z1}..${box.z2}，深度 ≤24）｜其中**浅层（≤4 格）** ${shallow.length} 块`);
for (const i of iron.slice(0, 10)) {
    console.log(`  (${i.xyz.join(',')}) ${i.block} 暴露面 ${i.airFaces.length} 面｜地表下 ${i.depthBelowSurface} 格｜距出生点 ${i.distToSpawnXZ.toFixed(0)} / 距 S1 ${i.distToS1XZ.toFixed(0)}`);
}

// ================================================================== 4. 落盘
const out = {
    schema: 'aidqq-round7c-leg1-shortcut/1', at: new Date().toISOString(),
    seed: '4926685115947721762', mcVersion: '1.16.1',
    question: '第 1 段捷径预勘：出生点 ±384 格内的现成铁源与桶（结构箱 + 暴露铁矿）',
    scope: { world: WORLD, note: '**只出数据，不改 route**（派单要求）', coverage: '`_bedhunt` 存档实际覆盖区，见各坐标；不是整个 ±384 正方形都存了区块' },
    anchors: { spawn: SPAWN, S1_door: S1, note: 'S1 取传送门框原点 (187,39,307) axis=z ⇒ 门心约 (187,41,308)' },
    criteria: {
        exposure: '6 个面邻格里 ≥1 个属于 {air,cave_air,void_air}（与本线其它工具同一判据）',
        shallow: 'y ≤ 该列地表高度 + 4（"地表或浅层"）',
        ironScanDepth: '地表以下 24 格',
        loot: '战利品表**从服务端 jar 的 data/minecraft/loot_tables/ 读出**（权威、离线），递归展开 loot_table 引用',
    },
    chests: { count: chests.length, list: chests },
    ironOre: {
        exposedTotal: iron.length, shallowTotal: shallow.length,
        nearest10: iron.slice(0, 10), shallowNearest10: shallow.slice(0, 10),
    },
    notVerified: [
        '🚨 **箱内实际物品未读**：本单只给"该战利品表**可能**出什么"（表级），'
        + '**实例级结果由 `LootTableSeed` 决定，本单没有实现原版战利品算法，不编造**。',
        '   派单允许的做法是"在另一份 fresh world 里用控制台开箱读出内容"—— **本单没做那一趟**（预算已用在主三项 + 低优先项 5）。',
        '⚠ **`_bedhunt` 的区块覆盖不是完整的 ±384 正方形**：未存区块一律跳过，'
        + '所以"没找到沉船/铁匠房"**可能是那一带没生成、也可能是存档没覆盖**——两者本单分不开。',
        '   已确认**这个覆盖区里没有** shipwreck（需海域）与 village_toolsmith/weaponsmith/armorer（需相应村庄角色）。',
        '**桶的唯一来源是战利品表**（矿洞里不产桶）。本单把哪些表**可能**给桶列出来了，但没给实际数量。',
        '**打火石只能靠挖沙砾**（`gravel` 10% 掉燧石），不存在"打火石战利品表"——已在报告里说明。',
    ],
    evidence: ['bench/route/probe/leg1_shortcut.round7c.json', 'bench/route/probe/_bedhunt/（只读存档）', JAR],
};
fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
console.log(`\n落盘：${OUT}`);
