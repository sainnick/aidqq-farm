// visibility_audit_selftest.mjs — ROUND7-C 判据离线自检
//
// 【为什么先写自检再去烧世界】手册 §5：「扫描或核验工具读出"全零"时，先证伪工具」。
//   本单最容易出的两个**静默假数**是：
//     ① 邻格 `unknown` 被当成空气 ⇒ 凭空多报"有暴露面"（假阳性，把不该过的站判成 OK）；
//     ② 空气分量小但被当成"连通 ⇒ 走得到" ⇒ 把墙缝里的方块判成可见（正是 B 线那个透视 bug 的翻版）。
//   两者都不会报错，只会安静地给出好看的数字。所以先在**合成世界**上把反例钉死。
//
// 验收线是**反向**的：故意造出每一种该判失败的场景，工具**必须**报出对应的失败结论
// （手册 §4.10：报"不行"必须附阳性对照；这里对称地——报"行"也必须能证伪）。
//
// 用法：node bench/route/tools/visibility_audit_selftest.mjs

import { auditStation, AIRLIKE, MIN_EXPOSED } from './visibility_audit.mjs';

let pass = 0, fail = 0;
const results = [];
function check(name, cond, detail = '') {
    if (cond) { pass++; results.push(`  ✓ ${name}`); }
    else { fail++; results.push(`  ✗ ${name}${detail ? '  ← ' + detail : ''}`); }
}
function eq(name, got, want) { check(name, JSON.stringify(got) === JSON.stringify(want), `got=${JSON.stringify(got)} want=${JSON.stringify(want)}`); }

// ---------------------------------------------------------------- 合成世界：稀疏 dict
/**
 * `world = { 'x,y,z': name }`，未列出的格读成 `fill`（默认 stone），`null` = unknown。
 * ⚠ `skyFrom`：y ≥ skyFrom 且未列出的格读成 **air**（模拟真正的"露天"）。
 *   第一版这三个地表用例**忘了挖天空**，结果工具正确地报"分量 1 格、站位 0、不通天" ⇒ 只能隔墙看到。
 *   这正是判据在起作用（一个"看起来在地表"的方块如果头顶是石头，就不是露天），所以保留成注释。
 */
function mkGet(world, { fill = 'stone', skyFrom = null } = {}) {
    return (x, y, z) => {
        const v = world[`${x},${y},${z}`];
        if (v === undefined) return (skyFrom !== null && y >= skyFrom) ? 'air' : fill;
        if (v === null) return 'unknown';
        return v;
    };
}
/** 挖一个空气立方空腔（中心 (cx,cy,cz)，边长 s） */
function carve(world, cx, cy, cz, s, air = 'air') {
    const h = Math.floor(s / 2);
    for (let y = cy - h; y <= cy + h; y++)
        for (let z = cz - h; z <= cz + h; z++)
            for (let x = cx - h; x <= cx + h; x++) world[`${x},${y},${z}`] = air;
}

const A = { center: [0, 0], radius: 16, dim: 'overworld', margin: 8 };

// ================================================================ 1. 地表矿脉：3 块以上暴露 + 通天 ⇒ OK
{
    const w = {};
    // 地表：y<=63 实心，y>=64 露天（skyFrom=64）
    for (let z = -20; z <= 20; z++) for (let x = -20; x <= 20; x++) w[`${x},63,${z}`] = 'stone';
    for (const [x, z] of [[2, 0], [4, 1], [6, -1], [8, 2]]) { w[`${x},62,${z}`] = 'iron_ore'; w[`${x},63,${z}`] = 'air'; }
    const r = auditStation({ ...A, id: 'T1', lookFor: ['iron_ore'], get: mkGet(w, { skyFrom: 64 }) });
    const t = r.types[0];
    eq('1a 地表 4 块铁矿全部 total', t.total, 4);
    eq('1b 地表 4 块铁矿全部 exposed', t.exposed, 4);
    eq('1c 地表站 verdict=OK', r.verdict, 'OK');
    check('1d 天列连通 sky=true', t.bestComponent?.sky === true, JSON.stringify(t.bestComponent));
    check('1e 空气分量里有站位', t.bestComponent?.standSpots >= MIN_EXPOSED, JSON.stringify(t.bestComponent));
}

// ================================================================ 1f. 头顶是石头就不算露天（判据的反面，必须仍然判失败）
{
    const w = {};
    for (let z = -20; z <= 20; z++) for (let x = -20; x <= 20; x++) w[`${x},63,${z}`] = 'stone';
    for (const [x, z] of [[2, 0], [4, 1], [6, -1], [8, 2]]) { w[`${x},62,${z}`] = 'iron_ore'; w[`${x},63,${z}`] = 'air'; }
    const r = auditStation({ ...A, id: 'T1f', lookFor: ['iron_ore'], get: mkGet(w) });   // **没有** skyFrom ⇒ y64 是石头
    eq('1f 头顶封死的 4 块矿 exposed 仍=4（面是贴空气的）', r.types[0].exposed, 4);
    eq('1f2 但走不到 ⇒ verdict=只能隔墙看到', r.verdict, '只能隔墙看到');
    check('1f3 分量 1 格、站位 0', r.types[0].bestComponent?.size === 1 && r.types[0].bestComponent?.standSpots === 0,
        JSON.stringify(r.types[0].bestComponent));
}

// ================================================================ 2. 全封闭：0 暴露面 ⇒ 只能隔墙看到（= B 线那个透视 bug）
{
    const w = {};
    for (let z = -8; z <= 8; z++) for (let x = -8; x <= 8; x++) {
        for (let y = 8; y <= 20; y++) if (!(y === 14 && x === 0 && z === 0)) w[`${x},${y},${z}`] = 'stone';
    }
    w['0,14,0'] = 'iron_ore';
    const r = auditStation({ ...A, id: 'T2', lookFor: ['iron_ore'], get: mkGet(w) });
    const t = r.types[0];
    eq('2a 全封闭矿 total=1', t.total, 1);
    eq('2b 全封闭矿 exposed=0', t.exposed, 0);
    eq('2c 全封闭矿 nameOnly=1', t.nameOnly, 1);
    eq('2d 全封闭站 verdict=只能隔墙看到', r.verdict, '只能隔墙看到');
    check('2e 结论点明"全部 6 面贴实体"', /6 面/.test(r.why), r.why);
}

// ================================================================ 3. 小气穴：暴露但 bot 站不到 ⇒ 只能隔墙看到
{
    const w = {};
    for (let z = -8; z <= 8; z++) for (let x = -8; x <= 8; x++)
        for (let y = 8; y <= 20; y++) w[`${x},${y},${z}`] = 'stone';
    // 2 格高、1×1 的墙缝：目标块贴的空气只有 2 格，且脚下没有可站的地方
    w['0,14,0'] = 'air'; w['0,15,0'] = 'air';
    w['0,13,0'] = 'gold_block';
    const r = auditStation({ ...A, id: 'T3', lookFor: ['gold_block'], get: mkGet(w) });
    const t = r.types[0];
    eq('3a 墙缝金块 total=1', t.total, 1);
    eq('3b 墙缝金块 exposed=1', t.exposed, 1);
    eq('3c 分量大小=2', t.bestComponent?.size, 2);
    eq('3d 分量里站位=0', t.bestComponent?.standSpots, 0);
    eq('3e 墙缝站 verdict=只能隔墙看到', r.verdict, '只能隔墙看到');
    check('3f 分量不通天', t.bestComponent?.sky === false, JSON.stringify(t.bestComponent));
}

// ================================================================ 4. `unknown` 邻格**不算空气**（反例：不能假报暴露面）
{
    const w = {};
    for (let z = -8; z <= 8; z++) for (let x = -8; x <= 8; x++)
        for (let y = 8; y <= 20; y++) w[`${x},${y},${z}`] = 'stone';
    w['0,14,0'] = 'iron_ore';
    w['0,15,0'] = null;                                   // 上邻 = unknown
    const r = auditStation({ ...A, id: 'T4', lookFor: ['iron_ore'], get: mkGet(w) });
    eq('4a unknown 邻格 ⇒ exposed=0', r.types[0].exposed, 0);
    eq('4b unknown 邻格 ⇒ nameOnly=1', r.types[0].nameOnly, 1);
    check('4c toolFailed 被标出', r.toolFailed === true, `toolFailed=${r.toolFailed}`);
    // 对照：同样的地形，上邻换成真 air ⇒ 必须 exposed=1
    w['0,15,0'] = 'air';
    const r2 = auditStation({ ...A, id: 'T4b', lookFor: ['iron_ore'], get: mkGet(w) });
    eq('4d 对照组：真 air 邻格 ⇒ exposed=1', r2.types[0].exposed, 1);
}

// ================================================================ 5. 整卷读不到 ⇒ INCONCLUSIVE_TOOL_FAILED（不是"这里没有"）
{
    const r = auditStation({ ...A, id: 'T5', lookFor: ['end_portal_frame'], get: () => null });
    eq('5a 全读不到 ⇒ verdict=INCONCLUSIVE_TOOL_FAILED', r.verdict, 'INCONCLUSIVE_TOOL_FAILED');
    check('5b toolFailed=true', r.toolFailed === true);
    check('5c unknownInDisc = discCells', r.counts.unknownInDisc === r.counts.discCells,
        `${r.counts.unknownInDisc}/${r.counts.discCells}`);
    check('5d 结论写明"没读到 ≠ 没有"', /没读到/.test(r.why), r.why);
    check('5e totalFound 必须为 0（不能把读不到算成有）', r.counts.totalFound === 0);
}

// ================================================================ 6. 暴露块 < 3 ⇒ 暴露块太少
{
    const w = {};
    for (let z = -20; z <= 20; z++) for (let x = -20; x <= 20; x++) w[`${x},63,${z}`] = 'stone';
    for (const [x, z] of [[1, 0], [3, 0]]) w[`${x},63,${z}`] = 'gravel';   // 地面裸露的沙砾，只有 2 块
    const r = auditStation({ ...A, id: 'T6', lookFor: ['gravel'], get: mkGet(w, { skyFrom: 64 }) });
    eq('6a 只有 2 块暴露沙砾', r.types[0].exposed, 2);
    eq('6b 不足 3 ⇒ verdict=暴露块太少', r.verdict, '暴露块太少');
}

// ================================================================ 7. cave_air 算空气（两套口径对照：strict 口径应更少）
{
    const w = {};
    for (let z = -20; z <= 20; z++) for (let x = -20; x <= 20; x++) w[`${x},63,${z}`] = 'stone';
    carve(w, 0, 64, 0, 3, 'cave_air');                    // 27 格 cave_air 空腔
    for (const [x, z] of [[0, 0], [2, 0], [0, 2]]) w[`${x},63,${z}`] = 'obsidian';
    const r = auditStation({ ...A, id: 'T7', lookFor: ['obsidian'], get: mkGet(w) });
    const t = r.types[0];
    eq('7a cave_air 计入空气 ⇒ 3 块 exposed', t.exposed, 3);
    eq('7b 只认严格 air 的口径 ⇒ 0 块（对照）', t.exposedStrictAirOnly, 0);
    eq('7c cave_air 场景 verdict=OK', r.verdict, 'OK');
    check('7d AIRLIKE 三件套齐全', AIRLIKE.has('cave_air') && AIRLIKE.has('void_air') && AIRLIKE.has('air'));
}

// ================================================================ 8. 床：脚下实心 + 上方空 ⇒ 判为暴露（真人站在旁边能看见）
{
    const w = {};
    for (let z = -20; z <= 20; z++) for (let x = -20; x <= 20; x++) w[`${x},63,${z}`] = 'stone';
    for (const [x, z] of [[1, 1], [3, 1], [5, 1], [7, 1], [1, 4], [3, 4]]) w[`${x},63,${z}`] = 'yellow_bed';
    const r = auditStation({ ...A, id: 'T8', lookFor: ['yellow_bed'], get: mkGet(w, { skyFrom: 64 }) });
    eq('8a 6 张床全部读到', r.types[0].total, 6);
    eq('8b 6 张床全部暴露', r.types[0].exposed, 6);
    eq('8c 床站 verdict=OK', r.verdict, 'OK');
}

// ================================================================ 9. 大气穴（可走但不通天）⇒ 仍算 OK（下探即可，不是透视）
{
    const w = {};
    for (let z = -30; z <= 30; z++) for (let x = -30; x <= 30; x++)
        for (let y = 8; y <= 40; y++) w[`${x},${y},${z}`] = 'stone';
    carve(w, 0, 20, 0, 11, 'air');                       // 11³ = 1331 格空气
    for (const [x, z] of [[0, 0], [2, 0], [4, 0], [0, 2]]) w[`${x},19,${z}`] = 'spawner';
    const r = auditStation({ ...A, id: 'T9', lookFor: ['spawner'], get: mkGet(w) });
    const t = r.types[0];
    eq('9a 4 个笼全部 exposed', t.exposed, 4);
    check('9b 分量 ≥ MIN_COMPONENT', t.bestComponent?.size >= 8, JSON.stringify(t.bestComponent));
    check('9c 分量里站位充足', t.bestComponent?.standSpots >= 1, JSON.stringify(t.bestComponent));
    eq('9d 大气穴 verdict=OK', r.verdict, 'OK');
}

// ================================================================ 10. 一句话判据自检：MIN_EXPOSED 就是派单给的 3
{
    eq('10a MIN_EXPOSED === 3', MIN_EXPOSED, 3);
}

console.log('=== visibility_audit_selftest ===');
for (const r of results) console.log(r);
console.log(`\n合计 ${pass + fail}：通过 ${pass} / 失败 ${fail}`);
process.exit(fail ? 1 : 0);
