// route_hash_selftest.mjs — R6-5：SCHEMA §4 v1.1 统一哈希口径的离线用例（不开服、不占端口）
//
// 【为什么单独一个文件】`stages/fullrun/route_selftest.mjs` 是 MC-ROUTE-02 的旧用例，
//   `route_guard_fallback_selftest.mjs` 是 fallback 三处一致性的用例。哈希口径统一是**另一个**主题
//   （而且旧用例本身也在用它生成 sidecar，见下面 T4），另开文件不碰别人的用例。
//
// 【要证明什么】设计会话 2026-10-02 夜定案（bench 74b1b5d / 73f7456）：
//   口径 = `sha256( JSON.stringify(JSON.parse(原文), null, 2) + "\n" )`，对**整个文件**
//   （含 frozenAt 和 sha256File）计算。**用规范化而不是原始字节**，是因为本地 Windows 的 git 会把
//   LF 转成 CRLF、云端 X / 农场 Y 是 LF —— 原始字节哈希跨机器必然对不上，**而且本地自检全绿也不报错**。
//
// 【验收线是反向的】只测"哈希稳定"是不够的 —— 一个恒返回常量的函数也稳定。
//   所以每个性质都配一个**必须失败**的对照：换行风格变了哈希**不能**变；内容变了哈希**必须**变。
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\route_hash_selftest.mjs
// 退出码 0 = 全过

import fs from 'fs';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import { routeSha256, canonicalRouteText, sha256Of, readRouteFile, checkRouteIntegrity, RouteGuard } from '../../stages/fullrun/route_guard.mjs';

let pass = 0, fail = 0;
const failures = [];
const A = (name, cond, extra = '') => {
    if (cond) { pass++; console.log(`  ✔ ${name}`); }
    else { fail++; failures.push(`${name}${extra ? ` — ${extra}` : ''}`); console.log(`  ✘ ${name}${extra ? ` — ${extra}` : ''}`); }
};

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'routehash-'));

// ---- 基准 route：复制真实主种子的形状（10 站、7 正常 + 3 fallback-only），但字段内容是自造的
//      ⚠ 不直接用真实主种子文件做写入类用例：验收线要求"不碰真实 route"。
function baseDoc() {
    const mk = (id, seq, extra = {}) => ({
        id, seq, kind: 'x', dim: 'overworld',
        station: { center: [0, 0], yHint: 'surface', radius: 32, lookFor: ['stone'] },
        scout: { verify: { status: 'REAL' } },
        fallback: [], ...extra,
    });
    return {
        schema: 'aidqq-route/1', seed: 'selftest-seed', mcVersion: '1.16.1',
        frozenAt: null, sha256File: null,
        stations: [
            mk('S0_iron', 1),
            mk('S0_gravel', 2),
            mk('S0b_village_beds', 3, { fallback: ['S0_sheep'] }),
            mk('S1_portal', 4, { fallback: ['S1b_lava_pool'] }),
            mk('S3_bastion', 5),
            mk('C3_fortress_spawner', 6, { fallback: ['S4_fortress_spawner'] }),
            mk('S5_stronghold_room', 7),
            mk('S0_sheep', 8, { routeRole: 'fallback-only' }),
            mk('S1b_lava_pool', 9, { routeRole: 'fallback-only' }),
            mk('S4_fortress_spawner', 10, { routeRole: 'fallback-only' }),
        ],
        normalFlowStations: ['S0_iron', 'S0_gravel', 'S0b_village_beds', 'S1_portal', 'S3_bastion', 'C3_fortress_spawner', 'S5_stronghold_room'],
        fallbackOnlyStations: [
            { id: 'S0_sheep', seq: 8, fallbackOf: ['S0b_village_beds'] },
            { id: 'S1b_lava_pool', seq: 9, fallbackOf: ['S1_portal'] },
            { id: 'S4_fortress_spawner', seq: 10, fallbackOf: ['C3_fortress_spawner'] },
        ],
    };
}

console.log('T1 换行风格无关：LF 与 CRLF 两版哈希必须相同（这是本次改动的全部理由）');
{
    const doc = baseDoc();
    const lf = canonicalRouteText(doc);                                  // LF + 末尾换行
    const crlf = lf.replace(/\n/g, '\r\n');                               // 模拟 git 在 Windows 上把 LF 转成 CRLF
    A('两版内容确实不同（否则这条用例是空转的）', lf !== crlf && crlf.includes('\r\n'));
    A('原始字节哈希：LF ≠ CRLF（所以不能用原始字节当口径）', sha256Of(lf) !== sha256Of(crlf),
        `${sha256Of(lf).slice(0, 12)} vs ${sha256Of(crlf).slice(0, 12)}`);
    A('规范哈希：LF == CRLF', routeSha256(lf) === routeSha256(crlf),
        `${routeSha256(lf).slice(0, 12)} vs ${routeSha256(crlf).slice(0, 12)}`);
    // 还要盖住"CRLF 版连末尾换行都被吃掉"（某些编辑器会做）
    A('规范哈希：CRLF 版去掉末尾换行后仍相同', routeSha256(crlf.trimEnd()) === routeSha256(lf));

    const p1 = path.join(TMP, 'lf.json'), p2 = path.join(TMP, 'crlf.json');
    fs.writeFileSync(p1, lf, 'utf8');
    fs.writeFileSync(p2, crlf, 'utf8');
    A('readRouteFile 读两版得到相同规范哈希', readRouteFile(p1).sha256 === readRouteFile(p2).sha256);
    A('readRouteFile 的 rawSha256 仍能看出换行差异（诊断用）', readRouteFile(p1).rawSha256 !== readRouteFile(p2).rawSha256);
}

console.log('\nT2 内容变了哈希必须变（反向对照：防止"哈希恒定"这种假通过）');
{
    const base = baseDoc();
    const h0 = routeSha256(base);
    const mutations = [
        ['frozenAt（SCHEMA §4 明写含它）', (d) => { d.frozenAt = '2026-10-02T15:00:00.000Z'; }],
        ['sha256File（旁挂文件名）', (d) => { d.sha256File = 'selftest-seed.sha256'; }],
        ['某个站的 radius', (d) => { d.stations[0].station.radius = 33; }],
        ['某个站的 center', (d) => { d.stations[0].station.center = [8, 0]; }],
        ['某个站的 lookFor', (d) => { d.stations[0].station.lookFor = ['dirt']; }],
        ['scout 里的精确坐标（运行区看不见，但**文件**变了）', (d) => { d.stations[0].scout.points = [{ what: 'x', xyz: [1, 2, 3] }]; }],
        ['顶层 normalFlowStations 顺序', (d) => { d.normalFlowStations = [...d.normalFlowStations].reverse(); }],
        ['顶层 fallbackOnlyStations 的 fallbackOf', (d) => { d.fallbackOnlyStations[0].fallbackOf = ['S1_portal']; }],
        ['顶层新增一个字段', (d) => { d.orchestratorContract = 'x'; }],
    ];
    for (const [name, mut] of mutations) {
        const d = baseDoc();
        mut(d);
        A(`改 ${name} → 哈希不同`, routeSha256(d) !== h0, `仍为 ${routeSha256(d).slice(0, 12)}`);
    }
    // 字段顺序不该影响（规范化会重排）——但 JSON.parse 保序，所以这条是"文档承诺"的行为：
    A('未改动的基准哈希稳定（连算三次一致）',
        routeSha256(base) === routeSha256(base) && routeSha256(base) === h0);
}

console.log('\nT3 完整冻结链：--write 冻结 → requireFrozen 放行 → 改一字节 → ROUTE_HASH_MISMATCH');
{
    // 复制主种子 route 到临时目录，**只对副本**做 --write（验收线：不碰真实 route）
    const REAL = 'D:/AI斗蛐蛐/bench/route/4926685115947721762.json';
    const work = path.join(TMP, 'route');
    fs.mkdirSync(work, { recursive: true });
    const SEED = 'selftest-seed';
    const FILE = path.join(work, `${SEED}.json`);
    const SIDECAR = path.join(work, `${SEED}.sha256`);

    // 用真实主种子的 route 内容当冻结对象（更贴近真冻结），但写到临时目录
    const realDoc = JSON.parse(fs.readFileSync(REAL, 'utf8'));
    const FROZEN_AT = '2026-10-02T14:15:29.469Z';
    // 模拟 freeze_route.mjs --write 的**完全相同**步骤（同一个共享函数）：
    const next = { ...realDoc, frozenAt: FROZEN_AT, sha256File: `${SEED}.sha256` };
    const text = canonicalRouteText(next);
    const hash = routeSha256(next);
    fs.writeFileSync(FILE, text, 'utf8');
    fs.writeFileSync(SIDECAR, `${hash}  ${SEED}.json\n`, 'utf8');

    A('冻结副本 0 violations', readRouteFile(FILE).violations.length === 0,
        readRouteFile(FILE).violations.join(' | '));
    A('站数 10（正常 7 + fallback 3）', next.stations.length === 10
        && next.normalFlowStations.length === 7 && next.fallbackOnlyStations.length === 3);

    const r0 = checkRouteIntegrity(FILE, { requireFrozen: true });
    A('冻结 + requireFrozen → 放行', r0.ok === true, r0.reason ?? '');
    A('frozen=true 且 frozenAt 正确', r0.frozen === true && r0.frozenAt === FROZEN_AT);
    A('sidecar 值与共享函数算的一致', fs.readFileSync(SIDECAR, 'utf8').trim().split(/\s+/)[0] === hash);

    // 关键回归：冻结产物被 git 换成 CRLF 之后，**仍然**放行（这就是规范化口径的价值）
    fs.writeFileSync(FILE, text.replace(/\n/g, '\r\n'), 'utf8');
    const rCrlf = checkRouteIntegrity(FILE, { requireFrozen: true });
    A('冻结产物被换成 CRLF 后仍放行（跨机器可复现）', rCrlf.ok === true, rCrlf.reason ?? '');
    fs.writeFileSync(FILE, text, 'utf8');   // 换回 LF 继续

    // RouteGuard 开跑 + 段间复验也必须认这个哈希
    const g = new RouteGuard(FILE, { requireFrozen: true });
    A('RouteGuard 开局通过（requireFrozen）', g.started.ok === true, g.started.reason ?? '');
    A('RouteGuard 记的 sha 与共享函数一致', g.sha256 === hash, `${String(g.sha256).slice(0, 12)} vs ${hash.slice(0, 12)}`);
    A('未改动时段间复验 OK', g.verify('before:S0_iron').ok === true);

    // 改一个字节（radius 32→33，仍是合法 JSON）→ 冻结校验必须拒
    const doc = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    doc.stations[0].station.radius = 33;
    fs.writeFileSync(FILE, canonicalRouteText(doc), 'utf8');
    const r1 = checkRouteIntegrity(FILE, { requireFrozen: true });
    A('改一字节 → ROUTE_HASH_MISMATCH', r1.ok === false && /ROUTE_HASH_MISMATCH/.test(r1.reason ?? ''), r1.reason);
    const v1 = g.verify('before:S1_portal');
    A('RouteGuard 段间复验也判作废', v1.ok === false && v1.changed === true, JSON.stringify(v1));
}

console.log('\nT4 三处同源：freeze 写的、guard 读的、复验的必须是同一个值');
{
    // 直接对着真实主种子 route 跑一遍**只读**的口径检查（不写任何文件）
    const REAL = 'D:/AI斗蛐蛐/bench/route/4926685115947721762.json';
    const raw = fs.readFileSync(REAL, 'utf8');
    const r = readRouteFile(REAL);
    A('readRouteFile 的 sha256 == routeSha256(原文)', r.sha256 === routeSha256(raw));
    A('readRouteFile 的 sha256 == routeSha256(doc)', r.sha256 === routeSha256(r.doc));
    A('checkRouteIntegrity 透传的 sha 与之一致', checkRouteIntegrity(REAL, { allowDraft: true }).sha256 === r.sha256);
    A('主种子仍是草稿（frozenAt=null，未被我 --write）', r.doc.frozenAt === null, String(r.doc.frozenAt));
    A('主种子仍 0 violations', r.violations.length === 0, r.violations.join(' | '));
    A('真实 route 目录没有生成 .sha256（我没碰它）', !fs.existsSync('D:/AI斗蛐蛐/bench/route/4926685115947721762.sha256'));
}

console.log('\nT5 哈希实现本身的性质（sanity：口径函数不是恒定的）');
{
    A('不同内容 → 不同 sha256Of', sha256Of('a') !== sha256Of('b'));
    A('canonicalRouteText 末尾有换行', canonicalRouteText(baseDoc()).endsWith('\n'));
    A('canonicalRouteText 用 2 空格缩进', canonicalRouteText(baseDoc()).includes('\n  "schema"'));
    A('canonicalRouteText 是幂等的（parse 回去再规范化不变）',
        canonicalRouteText(JSON.parse(canonicalRouteText(baseDoc()))) === canonicalRouteText(baseDoc()));
    A('canonicalRouteText 接受对象和接受原文结果一致',
        canonicalRouteText(baseDoc()) === canonicalRouteText(JSON.stringify(baseDoc())));
    // 防呆：canonicalRouteText 传坏 JSON 应抛，而不是静默返回什么
    let threw = false;
    try { canonicalRouteText('{not json'); } catch { threw = true; }
    A('坏 JSON 会抛异常（不静默产出假哈希）', threw);
}

for (const f of failures) console.log(`\n  ✗ ${f}`);
console.log(`\n${fail === 0 ? '✅' : '❌'} route_hash 自检 ${pass} 通过 / ${fail} 失败`);
try { fs.rmSync(TMP, { recursive: true, force: true }); } catch { /* 临时目录，忽略 */ }
process.exit(fail === 0 ? 0 : 1);
