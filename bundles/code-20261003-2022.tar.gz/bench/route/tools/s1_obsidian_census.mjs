// s1_obsidian_census.mjs — ROUND7-C：S1_portal 半径内 obsidian / crying_obsidian 的逐块位置 + 暴露面
//
// 【为什么要单独数】route 的 `scout.verify.counts` 写 `obsidian: 8`（那是 fill-replace 在**某个扫描盒**里的数），
//   而本单的可见面审计在**站级圆盘 r=24** 里读到 49 块 obsidian。
//   两个数不冲突但很容易被下一个人当成打架 —— 手册 §5：「区域总数 ≠ 框内计数」。
//   本文件把**每块**列出来（坐标 / 暴露面数 / 所属空气分量），让 S1 到底有多少"能看见的黑曜石"一目了然。
//
// 只读。

import { openWorld } from './region_reader.mjs';
import { AIRLIKE } from './visibility_audit.mjs';

const argOf = (a, n, d) => { const i = a.indexOf(`--${n}`); return (i >= 0 && a[i + 1] && !a[i + 1].startsWith('--')) ? a[i + 1] : d; };
const argv = process.argv.slice(2);
const world = openWorld(argOf(argv, 'world', 'D:/AI斗蛐蛐/bench/route/probe/_bedhunt'));
const CX = parseInt(argOf(argv, 'cx', '176'), 10), CZ = parseInt(argOf(argv, 'cz', '304'), 10);
const R = parseInt(argOf(argv, 'radius', '24'), 10);
const N6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const get = (x, y, z) => world.blockAt(x, y, z, 'overworld');
const isAir = (x, y, z) => AIRLIKE.has(get(x, y, z));

const rows = [];
for (let y = 0; y <= 100; y++) for (let z = CZ - R; z <= CZ + R; z++) for (let x = CX - R; x <= CX + R; x++) {
    if ((x - CX) ** 2 + (z - CZ) ** 2 > R * R) continue;
    const b = get(x, y, z);
    if (b !== 'obsidian' && b !== 'crying_obsidian') continue;
    let n = 0; const nbs = [];
    for (const [dx, dy, dz] of N6) { if (isAir(x + dx, y + dy, z + dz)) { n++; nbs.push([x + dx, y + dy, z + dz]); } }
    rows.push({ xyz: [x, y, z], b, airFaces: n, dist: Math.round(Math.hypot(x - CX, z - CZ) * 10) / 10, airNb: nbs });
}
const exp = rows.filter((r) => r.airFaces > 0);
console.log(`S1_portal 圆盘 r=${R}：obsidian/crying_obsidian 共 ${rows.length} 块，其中**有暴露面** ${exp.length} 块，完全没暴露面 ${rows.length - exp.length} 块`);
const byB = {};
for (const r of rows) { byB[r.b] = byB[r.b] ?? { total: 0, exposed: 0 }; byB[r.b].total++; if (r.airFaces > 0) byB[r.b].exposed++; }
console.log('按种类：' + JSON.stringify(byB));
console.log('\n有暴露面的块（距离站中心的水平距离 / 贴空气的面数 / 空气邻格）：');
for (const r of exp.sort((a, b) => a.dist - b.dist)) console.log(`  ${JSON.stringify(r.xyz)} ${r.b.padEnd(16)} d=${r.dist}  airFaces=${r.airFaces}  ${JSON.stringify(r.airNb)}`);

// 门框几何：把所有黑曜石按 y 分层，看看框在哪
const layers = {};
for (const r of rows) { const y = r.xyz[1]; layers[y] = (layers[y] ?? 0) + 1; }
console.log('\n按 y 分层计数：' + JSON.stringify(layers));
const near = rows.filter((r) => r.dist <= 16);
console.log(`\nd≤16（真正的门那一坨）：${near.length} 块，其中暴露 ${near.filter((r) => r.airFaces > 0).length} 块`);
for (const r of near.sort((a, b) => a.xyz[1] - b.xyz[1] || a.xyz[2] - b.xyz[2])) {
    console.log(`  ${JSON.stringify(r.xyz)} ${r.b.padEnd(16)} d=${String(r.dist).padStart(5)} airFaces=${r.airFaces}`);
}

// ---- 诱饵簇：y 很低的那批 obsidian 会不会把"找门"带偏？
// 判据是**朴素选择器**会不会选中它：站级中心 (CX,CZ) 水平最近、还是相对门框 3D 最近。
const deep = rows.filter((r) => r.xyz[1] <= 20);
console.log(`\n=== 诱饵簇检查 ===`);
if (deep.length) {
    const xs = deep.map((r) => r.xyz[0]), ys = deep.map((r) => r.xyz[1]), zs = deep.map((r) => r.xyz[2]);
    console.log(`y≤20 的 obsidian 共 ${deep.length} 块，范围 x ${Math.min(...xs)}..${Math.max(...xs)} / y ${Math.min(...ys)}..${Math.max(...ys)} / z ${Math.min(...zs)}..${Math.max(...zs)}`);
    console.log(`  全部零暴露面？ ${deep.every((r) => r.airFaces === 0)}（最大面数 ${Math.max(...deep.map((r) => r.airFaces))}）`);
    console.log(`  距站中心水平距离 ${Math.min(...deep.map((r) => r.dist))}..${Math.max(...deep.map((r) => r.dist))}`);
}
const byXZ = [...rows].sort((a, b) => a.dist - b.dist)[0];
const DOOR_Y = framesY(rows);
const by3 = [...rows].map((r) => ({ ...r, d3: Math.round(Math.hypot(r.xyz[0] - CX, r.xyz[1] - DOOR_Y, r.xyz[2] - CZ)) })).sort((a, b) => a.d3 - b.d3)[0];
console.log(`  朴素"水平最近的一块" ⇒ ${JSON.stringify(byXZ.xyz)} ${byXZ.b} y=${byXZ.xyz[1]} ⇒ ${byXZ.xyz[1] <= 20 ? '⚠ 选中的是 y10 诱饵' : 'OK（选中真门）'}`);
console.log(`  以门框高度 y=${DOOR_Y} 为基准的 3D 最近 ⇒ ${JSON.stringify(by3.xyz)} ${by3.b} y=${by3.xyz[1]} ⇒ ${by3.xyz[1] <= 20 ? '⚠ 诱饵' : 'OK'}`);

/** 门那一坨的参考高度：取 y≥35 的 obsidian 的众数 y（门框所在层） */
function framesY(rs) {
    const tall = rs.filter((r) => r.xyz[1] >= 35);
    if (!tall.length) return 40;
    const h = {}; for (const r of tall) h[r.xyz[1]] = (h[r.xyz[1]] ?? 0) + 1;
    return +Object.entries(h).sort((a, b) => b[1] - a[1])[0][0];
}

