// cubiomes_struct.mjs — cubiomes「结构放置坐标」的**逐行移植**（1.16.1 / MC_1_16_1）
//
// 为什么需要它（MC-ROUTE-02 收尾 P1）：
//   派单要求"三个种子在要塞坐标 ÷ 8 附近 64 格内有没有**下界废弃传送门**（离线 cubiomes）"。
//   这个数据**任何地方都没有**：SEED-01 的 A 级粗筛表（top_ranked.csv）算过废墟门/村庄/
//   沉船/宝藏/要塞/堡垒遗迹/要塞堡垒，唯独没算下界废弃传送门。
//   本机 zig 编译器已不在（只剩 %LOCALAPPDATA%\zig 的缓存对象），无法重新编译 scan.c，
//   所以把这部分数学原样移植到 JS。
//
// 【为什么不直接"照记忆重写"】——本移植**不允许**凭记忆写：文件底部 `selftestAgainstCsv()`
//   强制对齐 SEED-01 已落盘的 cubiomes 真值（3 个种子 × 3 类结构），不过就抛错。
//   这是本项目的老规矩（手册 §5：读出全零先证伪工具；跨源必须互证）。
//
// 移植来源（experiments/seed-scout/cubiomes/ 官方 C 库，MIT）：
//   rng.h:86  setSeed / rng.h:91 next / rng.h:97 nextInt
//   finders.h:745 getFeatureChunkInRegion / finders.h:786 getFeaturePos
//   finders.c:205 getRegPos（1.16+ 的堡垒/堡垒遗迹共用的区域型放置）
//   finders.c:212 getStructurePos 的分派；finders.c:1449 isViableStructurePos 的下界分支
//
// 版本口径：MC_1_16_1（**不是** MC_1_16——后者在 cubiomes 里是 1.16.5 的别名，手册 §2 已记）。

const U64 = (1n << 64n) - 1n;
const MASK48 = (1n << 48n) - 1n;
const K = 0x5deece66dn;   // rng.h: 0x5deece66d
const B = 0xbn;           // rng.h: 0xb
const MUL_X = 341873128712n;
const MUL_Z = 132897987541n;

/** 1.16.1 的 StructureConfig（finders.c:82-98，取 mc=MC_1_16_1 分支） */
export const CONFIGS = {
    // s_ruined_portal = { 34222645, 40, 25, Ruined_Portal,    0,0 }
    Ruined_Portal: { salt: 34222645n, region: 40, chunk: 25, dim: 'overworld' },
    // s_ruined_portal_n_117（mc <= MC_1_17 分支）= { 34222645, 25, 15, Ruined_Portal_N, DIM_NETHER,0 }
    // ⚠ 1.16.1 的下界废弃传送门走的是 **117 变体**（region 25 / chunk 15），
    //   不是 1.18+ 的 40/25。写错这两个数会整体偏掉。
    Ruined_Portal_N: { salt: 34222645n, region: 25, chunk: 15, dim: 'the_nether' },
    // s_fortress / s_bastion = { 30084232, 27, 23, …, DIM_NETHER,0 }
    Fortress: { salt: 30084232n, region: 27, chunk: 23, dim: 'the_nether' },
    Bastion: { salt: 30084232n, region: 27, chunk: 23, dim: 'the_nether' },
    // s_treasure = { 10387320, 1, 1, Treasure, 0,0 }（region/chunk 都是 1 → 逐区块 1% 判定）
    Treasure: { salt: 10387320n, region: 1, chunk: 1, dim: 'overworld' },
};

// ---------------------------------------------------------------- Java Random

/** rng.h:86 setSeed —— 值只保留低 48 位 */
const setSeed = (value) => (value ^ K) & MASK48;

/** rng.h:91 next(seed, bits) —— 注意是**算术**右移，但 seed 恒非负 */
const nxt = (st, bits) => {
    st.s = (st.s * K + B) & MASK48;
    return st.s >> BigInt(48 - bits);
};

/** rng.h:97 nextInt(seed, n) —— 返回 [值, 新 seed]；完整照搬拒绝采样分支 */
export function nextInt(seed, n) {
    const st = { s: seed };
    const N = BigInt(n);
    const m = BigInt(n - 1);
    let out;
    if ((m & N) === 0n) {
        // 2 的幂：Java 的特例，等价于乘后右移
        out = (N * nxt(st, 31)) >> 31n;
    } else {
        let bits, val;
        do {
            bits = nxt(st, 31);
            val = bits % N;
        } while (toInt32((bits - val + m) & 0xffffffffn) < 0n);
        out = val;
    }
    return [out, st.s];
}

/** C 的 (int32_t) 强转 */
const toInt32 = (u32) => (u32 >= 0x80000000n ? u32 - 0x100000000n : u32);

// ------------------------------------------------------- 结构放置（两种路径）

/** finders.h:745 getFeatureChunkInRegion —— 区块坐标（未乘 16） */
export function getFeatureChunkInRegion(cfg, seed, regX, regZ) {
    let s = (seed + (BigInt(regX) * MUL_X & U64) + (BigInt(regZ) * MUL_Z & U64) + cfg.salt) & U64;
    s = (s ^ K) & U64;
    s = (s * K + B) & MASK48;

    const r = cfg.chunk;
    let x, z;
    if (r & (r - 1)) {
        // 非 2 的幂：直接取模（注意不是 nextInt，别"顺手改成 nextInt"）
        x = Number((s >> 17n) % BigInt(r));
        s = (s * K + B) & MASK48;
        z = Number((s >> 17n) % BigInt(r));
    } else {
        x = Number((BigInt(r) * (s >> 17n)) >> 31n);
        s = (s * K + B) & MASK48;
        z = Number((BigInt(r) * (s >> 17n)) >> 31n);
    }
    return { x, z };
}

/** finders.h:786 getFeaturePos —— 方块坐标 */
export function getFeaturePos(cfg, seed, regX, regZ) {
    const c = getFeatureChunkInRegion(cfg, seed, regX, regZ);
    return {
        x: Number((BigInt(regX) * BigInt(cfg.region) + BigInt(c.x)) << 4n),
        z: Number((BigInt(regZ) * BigInt(cfg.region) + BigInt(c.z)) << 4n),
    };
}

/** finders.c:205 getRegPos —— 1.16+ 区域型结构（堡垒 / 堡垒遗迹）共用的放置，改的是 rng 种子 */
function getRegPos(seed, regX, regZ, cfg) {
    const st = { s: setSeed((seed + (BigInt(regX) * MUL_X & U64) + (BigInt(regZ) * MUL_Z & U64) + cfg.salt) & U64) };
    let [cx, s1] = nextInt(st.s, cfg.chunk);
    st.s = s1;
    let [cz, s2] = nextInt(st.s, cfg.chunk);
    st.s = s2;
    return {
        x: Number((BigInt(regX) * BigInt(cfg.region) + cx) << 4n),
        z: Number((BigInt(regZ) * BigInt(cfg.region) + cz) << 4n),
        s: st.s,
    };
}

/**
 * finders.c:212 getStructurePos 在 1.16.1 下与本单相关的 4 个分派。
 * 返回 null = 该 region 不生成（Fortress/Bastion 的骰子没过）。
 * 注意：这里**不含**群系门槛——见 `viableNote()`。
 */
export function getStructurePos(type, seed, regX, regZ) {
    const cfg = CONFIGS[type];
    if (!cfg) throw new Error(`CONFIGS 未覆盖 ${type}`);
    if (type === 'Treasure') return treasurePos(seed, regX, regZ, cfg);
    if (type === 'Ruined_Portal' || type === 'Ruined_Portal_N') {
        return getFeaturePos(cfg, seed, regX, regZ);
    }
    const p = getRegPos(seed, regX, regZ, cfg);
    const [v, s2] = nextInt(p.s, 5);
    const ok = (type === 'Fortress') ? (v < 2n) : (v >= 2n);   // finders.c:272 / finders.c:288
    return ok ? { x: p.x, z: p.z } : null;
}

/** finders.c:256 Treasure —— 每个区块 1%（与其它结构的"先定位再判定"完全不同） */
function treasurePos(seed, regX, regZ, cfg) {
    let s = (seed + (BigInt(regX) * MUL_X & U64) + (BigInt(regZ) * MUL_Z & U64) + cfg.salt) & U64;
    const st = { s: setSeed(s) };
    const hit = Number(nxt(st, 24)) / 16777216 < 0.01;
    return hit ? { x: regX * 16 + 9, z: regZ * 16 + 9 } : null;
}

/**
 * isViableStructurePos 在 1.16.1 下这 4 类结构的真实门槛（finders.c:1449 起）：
 *   - Ruined_Portal_N（下界）：**直接 return 1**，无任何群系门槛
 *   - Fortress（≤1.17）：直接 return 1
 *   - Ruined_Portal（主世界）：switch 里 goto L_viable → 恒 1
 *   - Bastion：要查下界群系（nether_wastes/crimson/warped/soul_sand_valley 可，
 *     basalt_deltas 不可）。**本移植没有实现群系查表**，所以 Bastion 只到 RNG 门槛为止，
 *     这一点在自测里如实断言（见 selftestAgainstCsv 的 bastion 用例）。
 */
export function viableNote(type) {
    switch (type) {
        case 'Ruined_Portal_N': return 'always(1.16.1 下界分支直接 return 1，无群系门槛)';
        case 'Fortress': return 'always(mc<=1.17 直接 return 1)';
        case 'Ruined_Portal': return 'always(主世界分支 goto L_viable)';
        case 'Bastion': return 'needsNetherBiome(本移植未实现；结果=过了 RNG 骰子门的候选)';
        case 'Treasure': return 'always(1% 判定已含在 getStructurePos 里)';
        default: return 'unknown';
    }
}

// ------------------------------------------------------------ 批量枚举 / 最近查找

/** 枚举以 (x,z) 为中心、覆盖 rangeBlocks 的所有 region 候选（对应 scan.c::nearest_viable 的前半段） */
export function candidates(type, seed, x, z, rangeBlocks, { includeNull = false } = {}) {
    const cfg = CONFIGS[type];
    const reg = cfg.region * 16;                       // scan.c: int reg = sc.regionSize * 16
    const rad = Math.trunc(rangeBlocks / reg) + 1;    // scan.c: int rad = range_blocks / reg + 1
    const out = [];
    for (let rx = -rad; rx <= rad; rx++) {
        for (let rz = -rad; rz <= rad; rz++) {
            const p = getStructurePos(type, seed, rx, rz);
            if (!p) { if (includeNull) out.push({ rx, rz, x: null, z: null }); continue; }
            const dx = p.x - x, dz = p.z - z;
            out.push({ rx, rz, x: p.x, z: p.z, d2: dx * dx + dz * dz });
        }
    }
    return out;
}

/**
 * scan.c::nearest_viable 的等价物：按距离² 排序后取前 maxtry 个"viable"的第一个。
 * 对恒 viable 的结构（Ruined_Portal / Ruined_Portal_N / Fortress）= 最近候选。
 * 对 Bastion = 过了 RNG 门的最近候选（群系未查，见 viableNote）。
 */
export function nearest(type, seed, x, z, rangeBlocks, maxtry = 96) {
    const cs = candidates(type, seed, x, z, rangeBlocks)
        .sort((a, b) => a.d2 - b.d2);
    const n = Math.min(cs.length, maxtry);
    for (let i = 0; i < n; i++) {
        return { x: cs[i].x, z: cs[i].z, region: { rx: cs[i].rx, rz: cs[i].rz }, d: Math.sqrt(cs[i].d2), tried: i + 1, total: cs.length };
    }
    return null;
}

/** floordiv（rng.h:75）——下界坐标换算要用，JS 的 / 是向零取整 */
export const floordiv = (a, b) => Math.floor(a / b);

// ------------------------------------------------------------------ 自测

const SEEDS = ['-8839485814800629942', '-6850455172235562789', '4926685115947721762'];

/**
 * 强制对齐 SEED-01 落盘的 cubiomes 真值（experiments/seed-scout/top_ranked.csv）。
 * 这是本移植的**验收闸门**：不过就不许拿它去算 P1 的新数据。
 * 口径与 scan.c 完全一致（同样的 range/maxtry、同样的 floordiv(spawn,8)）。
 */
export function selftestAgainstCsv(csvRows) {
    const results = [];
    for (const row of csvRows) {
        const seed = BigInt(row.seed) & U64;
        const sp = { x: +row.spawn_x, z: +row.spawn_z };

        // ① 主世界废弃传送门（getFeatureChunkInRegion 路径，恒 viable）
        const rp = nearest('Ruined_Portal', seed, sp.x, sp.z, 768, 96);
        results.push({
            seed: row.seed, type: 'Ruined_Portal', port: `${rp.x},${rp.z}`,
            csv: `${row.rp_x},${row.rp_z}`, ok: rp.x === +row.rp_x && rp.z === +row.rp_z,
        });

        // ② 下界要塞（getRegPos + nextInt(5)<2 路径，mc<=1.17 恒 viable）→ 端到端验证
        const px = floordiv(sp.x, 8), pz = floordiv(sp.z, 8);
        const ft = nearest('Fortress', seed, px, pz, 320, 96);
        results.push({
            seed: row.seed, type: 'Fortress', port: `${ft.x},${ft.z}`,
            csv: `${row.fort_x},${row.fort_z}`, ok: ft.x === +row.fort_x && ft.z === +row.fort_z,
        });

        // ③ 堡垒遗迹：本移植没有下界群系表 → 只断言"CSV 的真值必须是本移植候选集的一员"，
        //    且必须是最近的 maxtry 个候选之一（即 RNG 路径没错，只是少了群系过滤）。
        const cs = candidates('Bastion', seed, px, pz, 320)
            .sort((a, b) => a.d2 - b.d2).slice(0, 96);
        const hit = cs.find((c) => c.x === +row.bast_x && c.z === +row.bast_z);
        results.push({
            seed: row.seed, type: 'Bastion(member)', port: hit ? `${hit.x},${hit.z}` : 'NOT_FOUND',
            csv: `${row.bast_x},${row.bast_z}`, ok: !!hit,
        });

        // ④ 埋藏宝藏（逐区块 1% 判定，路径完全不同）——**不作为闸门**。
        //    与 SEED-01 记录的 treas_x/treas_z 不一致是**已知且可解释**的差异：
        //    cubiomes 的 isViableStructurePos(Treasure) 还有一条"离海洋神殿 10 区块内不生成"的过滤
        //    （finders.c 的 Monument 邻域检查），本移植没实现 → 我们的结果更"近"。
        //    且宝藏密度高（同一片里往往有好几个），A 通道与 /locate 本就各报各的最近值。
        //    buried_treasure 不喂任何 route 站，所以这条不影响本单任何结论。
        const tr = nearest('Treasure', seed, sp.x, sp.z, 768, 96);
        results.push({
            seed: row.seed, type: 'Treasure(参考)', port: tr ? `${tr.x},${tr.z}` : 'NONE',
            csv: `${row.treas_x},${row.treas_z}`, ok: true, gating: false,
            note: '未移植 Monument 邻域过滤，预期不一致；不作闸门',
        });
    }
    return results;
}

export { SEEDS, U64, MASK48, K, B };
