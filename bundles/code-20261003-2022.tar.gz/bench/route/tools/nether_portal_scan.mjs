// nether_portal_scan.mjs — MC-ROUTE-02 收尾 **P1**：三个种子的「要塞 ÷ 8 附近 64 格内有没有下界废弃传送门」
//
// 口径：离线 cubiomes（MC_1_16_1），**不开服**。结果只写报告，不改站序（任务单 §7 原文）。
//
// 两步，顺序是硬要求：
//   1. `--selftest`：用 SEED-01 已落盘的 cubiomes 真值（top_ranked.csv）**先证伪移植**；
//      不过就 exit 1，不产出任何数字（手册 §5：工具不可信时读出的数一律不算数）。
//   2. 主流程：算下界废弃传送门。
//
// 用法（Node 20）：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\nether_portal_scan.mjs
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\nether_portal_scan.mjs --selftest

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
    CONFIGS, candidates, nearest, floordiv, viableNote, selftestAgainstCsv,
} from './cubiomes_struct.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE_DIR = path.join(HERE, '..');
const REPO = path.join(ROUTE_DIR, '..', '..');
const CSV = path.join(REPO, 'experiments', 'seed-scout', 'top_ranked.csv');
const OUT_JSON = path.join(ROUTE_DIR, 'probe', 'nether_portal_scan.json');

/** 本轮要查的三个种子（主 + SEED-03 Top3 #2/#3，与 ROUTE-02 任务单 §2 一致） */
const SEEDS = [
    { seed: '-8839485814800629942', tag: '主种子' },
    { seed: '-6850455172235562789', tag: '备选1' },
    { seed: '4926685115947721762', tag: '备选2' },
];

/** P1 的搜索半径：下界 64 格（任务单 §7 原文「下界 64 格内」） */
const RADIUS = 64;

function readCsvRows() {
    if (!fs.existsSync(CSV)) throw new Error(`找不到 SEED-01 的 cubiomes 真值表：${CSV}`);
    const lines = fs.readFileSync(CSV, 'utf8').split(/\r?\n/).filter((l) => l.trim());
    const head = lines[0].split(',');
    const map = new Map();
    for (const line of lines.slice(1)) {
        const f = line.split(',');
        if (f.length < head.length) continue;
        const row = Object.fromEntries(head.map((h, i) => [h, f[i]]));
        map.set(row.seed, row);
    }
    return map;
}

const argSelftestOnly = process.argv.includes('--selftest');

// ---------------------------------------------------------------- 1) 证伪移植

const csv = readCsvRows();
const missing = SEEDS.filter((s) => !csv.has(s.seed));
if (missing.length) throw new Error(`SEED-01 表里没有这些种子：${missing.map((m) => m.seed).join(',')}`);

const rows = SEEDS.map((s) => csv.get(s.seed));
const sel = selftestAgainstCsv(rows);

const selOk = sel.every((r) => r.gating === false || r.ok);
console.log('=== 步骤 1：移植自测（对齐 SEED-01 cubiomes 真值）===');
console.log('seed'.padEnd(22), 'type'.padEnd(16), '移植结果'.padEnd(16), 'CSV 真值'.padEnd(16), '一致');
for (const r of sel) {
    console.log(
        r.seed.padEnd(22), r.type.padEnd(16), String(r.port).padEnd(16), String(r.csv).padEnd(16),
        r.gating === false ? '—' : (r.ok ? '✅' : '❌'),
    );
}
const gate = sel.filter((r) => r.gating !== false);
console.log(`判定：${gate.filter((r) => r.ok).length}/${gate.length} 项闸门逐坐标吻合`
    + (sel.length > gate.length ? `（另有 ${sel.length - gate.length} 项参考项，不作闸门）` : ''));
for (const r of sel.filter((x) => x.note)) console.log(`  注：${r.type} —— ${r.note}`);
if (!selOk) {
    console.error('❌ 移植与 cubiomes 真值不一致 —— 拒绝产出 P1 数字（工具不可信时读出的数一律不算数）');
    process.exit(1);
}
if (argSelftestOnly) { console.log('--selftest 模式：只跑自测'); process.exit(0); }

// ------------------------------------------------ 2) 下界废弃传送门（真正的 P1）

console.log('\n=== 步骤 2：要塞 ÷ 8 附近 64 格内的下界废弃传送门（cubiomes MC_1_16_1）===');

const results = [];
for (const s of SEEDS) {
    const row = csv.get(s.seed);
    const seed = BigInt(s.seed);
    const sh = { x: +row.sh_x, z: +row.sh_z };                 // SEED-01 记的要塞坐标（离线算）
    const target = { x: floordiv(sh.x, 8), z: floordiv(sh.z, 8) };

    // 半径 64 格 → 覆盖它的 region 窗口（region = 25 区块 = 400 格）
    const cands = candidates('Ruined_Portal_N', seed, target.x, target.z, RADIUS);
    const hits = cands
        .map((c) => ({ ...c, d: Math.sqrt(c.d2) }))
        .filter((c) => c.d <= RADIUS)
        .sort((a, b) => a.d - b.d);

    // 顺带把「离要塞 ÷ 8 最近的下界废弃传送门」也给出来（不限 64 格），
    // 这样即使 64 格内没有，设计会话也能看到真实量级。
    const all = cands.map((c) => ({ ...c, d: Math.sqrt(c.d2) })).sort((a, b) => a.d - b.d);
    const closest = all[0] ?? null;

    results.push({
        seed: s.seed, tag: s.tag,
        stronghold: sh,
        netherTarget: target,
        radius: RADIUS,
        withinRadius: hits.map((h) => ({ x: h.x, z: h.z, d: Math.round(h.d * 10) / 10, region: { rx: h.rx, rz: h.rz } })),
        closestAny: closest ? { x: closest.x, z: closest.z, d: Math.round(closest.d * 10) / 10 } : null,
        candidateCount: cands.length,
        spawn: { x: +row.spawn_x, z: +row.spawn_z },
        netherPortalLanding: { x: floordiv(+row.spawn_x, 8), z: floordiv(+row.spawn_z, 8) },
        netherPortalsNearLanding: candidates('Ruined_Portal_N', seed, floordiv(+row.spawn_x, 8), floordiv(+row.spawn_z, 8), 320)
            .map((c) => ({ ...c, d: Math.round(Math.sqrt(c.d2) * 10) / 10 }))
            .sort((a, b) => a.d - b.d).slice(0, 3),
    });

    const r = results[results.length - 1];
    console.log(`\n[${s.tag}] ${s.seed}`);
    console.log(`  要塞(主世界) (${sh.x}, ${sh.z}) → 下界 ÷8 = (${target.x}, ${target.z})`);
    console.log(`  ${RADIUS} 格内：${r.withinRadius.length ? JSON.stringify(r.withinRadius) : '无'}`);
    console.log(`  最近的（不限半径）：(${r.closestAny?.x}, ${r.closestAny?.z}) 距离 ${r.closestAny?.d} 格`);
}

const payload = {
    schema: 'aidqq-route-netherportal/1',
    generatedAt: new Date().toISOString(),
    tool: 'bench/route/tools/nether_portal_scan.mjs + cubiomes_struct.mjs（cubiomes MC_1_16_1 逐行移植）',
    selftest: { passed: sel.filter((r) => r.ok).length, total: sel.length, rows: sel, source: 'experiments/seed-scout/top_ranked.csv' },
    config: { ...CONFIGS.Ruined_Portal_N, salt: CONFIGS.Ruined_Portal_N.salt.toString() },
    viability: viableNote('Ruined_Portal_N'),
    radius: RADIUS,
    results,
};
fs.mkdirSync(path.dirname(OUT_JSON), { recursive: true });
fs.writeFileSync(OUT_JSON, JSON.stringify(payload, null, 2) + '\n');
console.log(`\n落盘：${path.relative(REPO, OUT_JSON)}`);

const anyHit = results.filter((r) => r.withinRadius.length > 0).length;
console.log(`\n小结：${results.length} 个种子里，${anyHit} 个在要塞 ÷8 的 ${RADIUS} 格内**有**下界废弃传送门。`);
