// _anvil_probe.mjs — 一次性探针（**临时**，不是交付物）：用现成存档把 1.16.1 Anvil 的真实结构探出来。
// 目的：在写 region_reader 之前，把"压缩算法 / NBT 根键 / Section.Y 偏移 / 位打包是否跨 long /
//       实体坐标是局部还是绝对"这几件**不能靠记忆**的事一次探明。
// NBT 解析就地实现（bench 没有 node_modules，跨目录引用 mindcraft 的 prismarine-nbt 很脆弱）。
import fs from 'fs';
import zlib from 'zlib';

// ------------------------------------------------------------------ 最小 NBT 读取器
const TAG = { 0: 'End', 1: 'Byte', 2: 'Short', 3: 'Int', 4: 'Long', 5: 'Float', 6: 'Double', 7: 'ByteArray', 8: 'String', 9: 'List', 10: 'Compound', 11: 'IntArray', 12: 'LongArray' };
function readNbt(buf) {
    let p = 0;
    const i8 = () => buf.readInt8(p++);
    const i16 = () => { const v = buf.readInt16BE(p); p += 2; return v; };
    const i32 = () => { const v = buf.readInt32BE(p); p += 4; return v; };
    const i64 = () => { const v = buf.readBigInt64BE(p); p += 8; return v; };
    const f32 = () => { const v = buf.readFloatBE(p); p += 4; return v; };
    const f64 = () => { const v = buf.readDoubleBE(p); p += 8; return v; };
    const str = () => { const n = i16(); const v = buf.toString('utf8', p, p + n); p += n; return v; };
    function payload(type) {
        switch (type) {
            case 1: return i8();
            case 2: return i16();
            case 3: return i32();
            case 4: return i64();
            case 5: return f32();
            case 6: return f64();
            case 7: { const n = i32(); const v = buf.subarray(p, p + n); p += n; return Array.from(v); }
            case 8: return str();
            case 9: { const et = i8(); const n = i32(); const a = []; for (let i = 0; i < n; i++) a.push(payload(et)); return a; }
            case 10: { const o = {}; for (;;) { const t = i8(); if (t === 0) break; const name = str(); o[name] = payload(t); } return o; }
            case 11: { const n = i32(); const a = []; for (let i = 0; i < n; i++) a.push(i32()); return a; }
            case 12: { const n = i32(); const a = []; for (let i = 0; i < n; i++) a.push(i64()); return a; }
            default: throw new Error(`未知 tag ${type} @${p - 1}`);
        }
    }
    const rootType = i8();
    const rootName = str();
    const root = payload(rootType);
    return { rootType, rootName, root, bytesRead: p };
}

// ------------------------------------------------------------------ 探存档
const REGION = process.argv[2] || 'D:/AI斗蛐蛐/experiments/mc1161-gate/server-1161/world/region/r.-1.-1.mca';
const buf = fs.readFileSync(REGION);
console.log(`region：${REGION}`);
console.log(`  ${buf.length} 字节 = ${(buf.length / 4096).toFixed(2)} 个 sector`);

const used = [];
for (let i = 0; i < 1024; i++) {
    const off = (buf.readUInt8(4096 + i * 4) << 16) | (buf.readUInt8(4097 + i * 4) << 8) | buf.readUInt8(4098 + i * 4);
    const sectors = buf.readUInt8(4099 + i * 4);
    if (off || sectors) used.push({ cx: i % 32, cz: Math.floor(i / 32), off, sectors });
}
console.log(`  定位表：${used.length}/1024 个 chunk 有数据`);
for (const u of used.slice(0, 4)) console.log(`    (${u.cx},${u.cz}) offset=${u.off} sectors=${u.sectors}  字节 ${u.off * 4096}..${(u.off + u.sectors) * 4096}`);

const u0 = used[0];
const start = u0.off * 4096;
const compLen = buf.readInt32BE(start);
console.log(`\n  chunk(${u0.cx},${u0.cz}) 压缩长度字段 = ${compLen}`);
const comp = buf.subarray(start + 4, start + 4 + compLen);
let raw = null, how = null;
for (const [name, fn] of [['zlib.inflate', () => zlib.inflateSync(comp)], ['gunzip', () => zlib.gunzipSync(comp)], ['inflateRaw', () => zlib.inflateRawSync(comp)]]) {
    try { raw = fn(); how = name; break; } catch { /* 试下一个 */ }
}
if (!raw) { console.log('  ❌ 解压全部失败'); process.exit(1); }
console.log(`  解压 ${how} ✅ → ${raw.length} 字节`);

const { rootType, rootName, root, bytesRead } = readNbt(raw);
console.log(`  NBT 根：type=${TAG[rootType]} name="${rootName}" 解析到 ${bytesRead}/${raw.length} 字节 ${bytesRead === raw.length ? '✅' : '⚠ 有余量'}`);
console.log(`  顶层键：${JSON.stringify(Object.keys(root))}`);
const lvl = root.Level ?? root;
console.log(`  Level 键（${Object.keys(lvl).length}）：${JSON.stringify(Object.keys(lvl))}`);
console.log(`  DataVersion=${lvl.DataVersion}`);

const secs = lvl.Sections ?? [];
console.log(`\n  Sections=${secs.length}，Y 值 = ${JSON.stringify(secs.map((s) => s.Y))}`);
const secsWith = secs.filter((s) => s.BlockStates);
console.log(`  带 BlockStates 的 = ${secsWith.length}；带 Palette 的 = ${secs.filter((s) => s.Palette).length}`);
for (const sec of secsWith.slice(0, 5)) {
    const pal = sec.Palette ?? [];
    const bits = Math.max(4, 32 - Math.numberOfLeadingZeros(Math.max(1, pal.length - 1)));
    const perLong = Math.floor(64 / bits);
    console.log(`    Y=${sec.Y}: palette=${pal.length} [${pal.map((x) => x.Name).slice(0, 5).join(',')}${pal.length > 5 ? '…' : ''}]`);
    console.log(`        BlockStates=${sec.BlockStates.length} long`
        + ` | bits=max(4,ceilLog2(n))=${bits}`
        + ` | 连续位流 long 数 ceil(4096*${bits}/64)=${Math.ceil(4096 * bits / 64)}`
        + ` | 不跨long long 数 ceil(4096/${perLong})=${Math.ceil(4096 / perLong)}`);
}

const ent = lvl.Entities ?? [];
console.log(`\n  Entities=${ent.length}`);
if (ent.length) {
    const e0 = ent[0];
    console.log(`    首实体键：${JSON.stringify(Object.keys(e0).slice(0, 18))}`);
    console.log(`    id=${e0.id} Pos=${JSON.stringify(e0.Pos)} Dimension=${JSON.stringify(e0.Dimension)}`);
    const inside = ent.filter((e) => Array.isArray(e.Pos) && e.Pos[0] >= 0 && e.Pos[0] < 16 && e.Pos[2] >= 0 && e.Pos[2] < 16).length;
    console.log(`    Pos 落在 0..16 的：${inside}/${ent.length} ⇒ ${inside === ent.length ? '**chunk 局部坐标**' : '有越界（含绝对坐标）'}`);
    const kinds = {};
    for (const e of ent) kinds[e.id] = (kinds[e.id] ?? 0) + 1;
    console.log(`    实体种类：${JSON.stringify(kinds)}`);
}
console.log(`\n  顶层其它键：${JSON.stringify(Object.keys(lvl).filter((k) => !['Sections', 'Entities', 'DataVersion'].includes(k)))}`);
