// fortress_standing_probe.mjs — MC-ROUND5 §C 线：**C-3「可挡火球站位」补测**（只补这一项）
//
// 【为什么必须补测】ROUND4 的 C-3 在刷怪笼 (221,70,-85) 周围 5×5×5 探了 124 格，
//   **52 格未解析**，而站位判据是"脚下实心 + 身体两格空气 + 四侧≥两面实心"。
//   未解析的格子被 `nameAt()` 返回 null → 站位数读成 **0**。
//   **"0 个站位"是"没读到"，不是"没有"**（手册 §5「没找到目标必须判失败，不能等价成不需要处理」）。
//   ROUND4 的候选清单只有 16 个名字，而下界要塞最常见的结构件
//   `nether_brick_stairs` / `nether_brick_wall` / `chiseled_polished_blackstone` **全不在里面** ——
//   52 格未解析极可能就是这三类（依据：ROUND4 的 SOLID 白名单同样漏了它们，
//   也就是说即便那 52 格读到了，判据也会把楼梯/墙判成"不是实心"）。
//
// 【本文件的做法：把"穷举"和"自证"都做成结构性的】
//   ① **穷举**：候选名不再手挑 16 个，而是取 minecraft-data 的 1.16.1 全量方块名（763 个）
//      当**候选集**，**由服务器逐个裁定**认不认（1.16.1 对未知方块名回
//      `Unknown block type '<name>'`）。**实测已证 minecraft-data 3.114 的 pc/1.16.1
//      不是可信清单**（含 1.17 才有的 `cave_air`/`void_air`，却缺 1.16 就有的 `smooth_basalt`）
//      ⇒ 清单只能当候选，真值必须问服务器（这也是手册 §3「方块名先对照清单」那条的加强版：
//      **对照清单之后还要让服务器裁定，并把裁定结果落档**）。
//   ② **自证**（ROUND4 交了 5 版"能力闸门"都没自证成功，这版把闸门放在**有地面真值的格子**上）：
//      - G0 通道：Pass 0 在**刷怪笼那一格**上逐名试。刷怪笼的位置是 ROUND4 独立测出的地面真值
//        （下钻 `spawner` 粗扫计数 1 == 下钻点数 1，selfCheck.ok=true），
//        **所以"这一格必须是 spawner、且恰好只有一个名字命中"就是整条通道的端到端证明**。
//        探针格不再靠猜坐标（ROUND4 五版全栽在"猜一个已加载格"上）。
//      - G1 穷举：整盒 5×5×5=125 格，`Σ 各方块计数 + 未识别 == 125`。不等就硬失败，绝不"差不多"。
//      - G2 复原：每个被标记的盒都要用**反向 fill 换回**且回执计数必须与标记时一致
//        （`restoreMismatch` 必须为 0）——世界复原失败会让后续读数全废。
//      - G3 逐格：124 格必须**全部**解析；出现任何未解析 → 状态判 `UNRESOLVED`，
//        **不允许输出 0**（这正是 ROUND4 的 bug）。
//
// 【三遍扫，非破坏性】
//   Pass 0（中心格，763 名）：`fill <中心> barrier replace <名>` → 命中就立刻 `fill <中心> <名> replace barrier` 复原。
//   Pass 1（整盒，763 名）：`fill <盒> barrier replace <名>` 拿整盒计数 → 命中就整盒换回。
//   Pass 2（逐格，仅 Pass 1 命中的名，按计数升序试探）：cell_probe 的 2-fill 非破坏性判据。
//
// 【口径】站位判据与 ROUND4 **逐字一致**（脚下实心 + 身体/头两格空气 + 四侧≥两面实心，半径 ±2），
//   只把"实心"白名单**补全**（stairs/wall/chiseled/…）并**同时输出两套白名单的结果**，
//   审阅时能看出口径差在哪几格。半径、口径都不在本单改动范围内。
//
// 用法：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\fortress_standing_probe.mjs \
//       [--seed 4926685115947721762] [--budget-ms 900000] [--out bench\route\probe\fortress_standing.round5c.json]
//   离线自检（不碰服务器）：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\fortress_standing_selftest.mjs

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR } from './console.mjs';
import { forceload, MARKER_A } from './scan.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const RUN_DIR = path.join(PROBE_DIR, '_run_round5c');
const NODE_VER = '1.16.1';
const MINECRAFT_DATA = path.join(ROUTE_DIR, '..', '..', 'mindcraft', 'node_modules', 'minecraft-data', 'minecraft-data', 'data', 'pc', NODE_VER, 'blocks.json');

// ============================================================================================
// 纯函数区（导出给 fortress_standing_selftest.mjs 离线跑；本文件被 import 时不碰服务器）
// ============================================================================================

/** 1.16.1 的方块名要带命名空间；minecraft-data 的清单是裸名。 */
export function qname(n) {
    return n.includes(':') ? n : `minecraft:${n}`;
}

/** 标记方块：1.16.1 生存世界不自然生成 barrier（scan.mjs 的同款不变量）。 */
export const MARKER = MARKER_A;

/**
 * 把**一条**控制台行分类成 fill 回执判决。
 * 返回 null = 这行不是判决（命令回显 / `<--[HERE]` 上下文行 / 时间戳噪声），调用方应当**跳过**它。
 * ⚠ 必须允许"跳过非判决行"：未知方块名的报错会连带打出多行上下文，
 *   逐行判决会把上下文行当成下一条命令的回执 ⇒ 错位。
 */
export function classifyFillLine(line) {
    if (typeof line !== 'string') return null;
    const l = line.trim();
    if (!l) return null;
    let m;
    if ((m = l.match(/Successfully filled (\d+) blocks?/i))) return { kind: 'filled', n: parseInt(m[1], 10) };
    if (/No blocks were filled/i.test(l)) return { kind: 'empty', n: 0 };
    if (/Unknown block type/i.test(l)) return { kind: 'unknown_block', n: null };
    if (/not loaded/i.test(l)) return { kind: 'not_loaded', n: null };
    if (/Unknown or incomplete command|Incorrect argument|Cannot parse|Too many|Out of world/i.test(l)) return { kind: 'error', n: null };
    return null;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function dimPre(dim) {
    if (dim === 'the_nether') return 'execute in minecraft:the_nether run ';
    if (dim === 'the_end') return 'execute in minecraft:the_end run ';
    return '';
}

/**
 * 发一条 fill，等到**本条的第一条判决**。
 * 纪律（继承 scan.mjs 的 FIFO 教训）：
 *   - 跳过非判决行（见 classifyFillLine）；
 *   - **只认本条之后到达的第一条判决**，绝不跨命令配对；
 *   - 超时**直接抛错**，不重试 —— 丢一条回执意味着流已不可信，
 *     继续下去产出的是"看起来正常但坐标/计数是错的"数据。
 */
export async function fillOnce(con, dim, box, block, { asReplace = false, timeoutMs = 15000 } = {}) {
    const cmd = `${dimPre(dim)}fill ${box.x1} ${box.y1} ${box.z1} ${box.x2} ${box.y2} ${box.z2} `
        + `${asReplace ? block : MARKER} replace ${asReplace ? MARKER : block}`;
    con.cmd(cmd);
    const t0 = Date.now();
    for (;;) {
        if (con.child && con.child.exitCode !== null) throw new Error(`FILL_SERVER_DIED: server rc=${con.child.exitCode}`);
        for (const line of con.drain()) {
            const v = classifyFillLine(line);
            if (!v) continue;
            if (v.kind === 'filled' || v.kind === 'empty') return v;
            return v;                      // unknown_block / not_loaded / error：交调用方判断，绝不当成 0
        }
        if (Date.now() - t0 > timeoutMs) throw new Error(`FILL_NO_RECEIPT: ${cmd}（${timeoutMs}ms 无判决 —— 流不可信，拒绝继续）`);
        await sleep(25);
    }
}

/**
 * "服务器认不认这个名字"的判据。
 * ⚠ **`empty`（No blocks were filled）= 名字合法、只是这一格不是它** —— 它**必须**算"有效"。
 *   本单第一版把 `verdict !== 'filled'` 一律当成"名字无效"，结果 754 个名字全被判无效、
 *   Pass 1 无色可用，74 秒白跑（幸好被"探针格没复原"的闸门抓住，没有产出错数）。
 *   只有 `unknown_block` / `error` 才说明**解析层**不认。
 */
export function isNameAccepted(verdict) {
    const k = typeof verdict === 'string' ? verdict : verdict?.kind;
    return k === 'filled' || k === 'empty';
}

/** 非破坏性计数：标记 → 计数 → 换回；换回的回执计数必须与标记时一致。 */
export async function countAndRestore(con, dim, box, block, { timeoutMs = 15000 } = {}) {
    const v1 = await fillOnce(con, dim, box, block, { timeoutMs });
    if (v1.kind !== 'filled') return { n: null, verdict: v1.kind, restoreMismatch: false };
    if (v1.n === 0) return { n: 0, verdict: 'empty', restoreMismatch: false };
    const v2 = await fillOnce(con, dim, box, block, { asReplace: true, timeoutMs });
    // v2 必须是"filled n"（把 marker 换回原方块）。不等 = 世界没复原干净，后面读数全废。
    const ok = v2.kind === 'filled' && v2.n === v1.n;
    return { n: v1.n, verdict: 'filled', restoreMismatch: !ok, restoreGot: v2.kind === 'filled' ? v2.n : null };
}

/** 单格非破坏性判据（cell_probe 同款 2-fill，参数顺序别写反）。 */
export async function probeCellSafe(con, dim, p, candidates, { timeoutMs = 15000 } = {}) {
    const box = { x1: p.x, y1: p.y, z1: p.z, x2: p.x, y2: p.y, z2: p.z };
    let tests = 0;
    for (const c of candidates) {
        tests++;
        const hit = await fillOnce(con, dim, box, c, { timeoutMs });
        if (hit.kind !== 'filled' || hit.n === 0) continue;
        const back = await fillOnce(con, dim, box, c, { asReplace: true, timeoutMs });
        return { hit: c, tests, restoreOk: back.kind === 'filled' && back.n === 1 };
    }
    return { hit: null, tests, restoreOk: true };
}

/**
 * 逐格判据（**记录全部命中**，用于"air / cave_air / void_air 是不是同一个方块"这类问题）。
 * 本台 1.16.1 实测：754 个候选名全部被接受，且整盒真值里有 6 格报成 `cave_air`
 * —— 而 1.16.1 原版**没有** cave_air（1.17 才加）。若它其实是 `air` 的别名，
 * 判据里写死的 `body === 'air'` 就会把这几格当成"不是空气" ⇒ 少判站位。
 * 所以三个空气名**都要试、不提前退出**，命中几个记几个。
 * @returns {{hits:string[], tests:number, restoreOk:boolean}} hits = 命中的方块名（裸名）
 */
export async function probeCellAllHits(con, dim, p, candidates, { timeoutMs = 15000 } = {}) {
    const box = { x1: p.x, y1: p.y, z1: p.z, x2: p.x, y2: p.y, z2: p.z };
    const hits = [];
    let tests = 0, restoreOk = true;
    for (const c of candidates) {
        tests++;
        const hit = await fillOnce(con, dim, box, c, { timeoutMs });
        if (hit.kind !== 'filled' || hit.n === 0) continue;
        hits.push(c.replace(/^minecraft:/, ''));
        const back = await fillOnce(con, dim, box, c, { asReplace: true, timeoutMs });
        if (!(back.kind === 'filled' && back.n === 1)) restoreOk = false;
    }
    return { hits, tests, restoreOk };
}

/** 穷举自检：Σ 各方块计数 + 未识别 == 总格数 */
export function tallyPalette(counts) {
    let identified = 0;
    for (const v of Object.values(counts)) identified += v;
    return { identified, ...counts };
}

// ------------------------------------------------------------------ 三道闸门（纯函数，offline 自检直接覆盖）

/** G0：中心格（刷怪笼）必须**恰好**命中一个名字且是 spawner —— 整条通道的端到端证明。 */
export function gateCenterTruth(hits) {
    const names = hits.map((h) => h.name);
    return { hits, ok: names.length === 1 && names[0] === 'spawner' };
}

/** G1：穷举。Σ 计数 + 未识别 == 总格数，且复原不等为 0。 */
export function gateExhaustive(totalCells, counts, restoreMismatch = 0) {
    const t = tallyPalette(counts);
    const unidentified = totalCells - t.identified;
    return { totalCells, identified: t.identified, unidentified, restoreMismatch, ok: unidentified === 0 && restoreMismatch === 0 };
}

/**
 * G3：逐格。未解析必须为 0、复原失败必须为 0。
 * 未解析 > 0 ⇒ 状态 `UNRESOLVED`，**调用方不许输出站位数**（ROUND4 把"没读到"报成 0 的那条 bug）。
 */
export function gatePerCell(unknown, restoreFails) {
    return { unknown, restoreFails, ok: unknown === 0 && restoreFails === 0 };
}

/**
 * 站位判据（与 ROUND4 逐字一致：脚下实心 + 身体/头两格 `air` + 四侧 ≥2 面 SOLID，半径 ±r，dy∈{-1,0}）。
 * @param {(dx:number,dy:number,dz:number)=>string|null} get 相对笼子的偏移取名（null = 未解析）
 * @returns 站位列表 + 未解析格清单。**未解析格非空 ⇒ complete=false，调用方不许报 0。**
 */
const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
export function findStands(get, sp, r, SOLID, AIR = new Set(['air'])) {
    const stands = [];
    const unknown = new Map();
    const noteUnknown = (dx, dy, dz) => unknown.set(`${dx},${dy},${dz}`, [sp.x + dx, sp.y + dy, sp.z + dz]);
    for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) for (let dy = -1; dy <= 0; dy++) {
        const feet = get(dx, dy, dz), body = get(dx, dy + 1, dz), head = get(dx, dy + 2, dz);
        if (feet == null || body == null || head == null) { noteUnknown(dx, dy, dz); continue; }
        if (!(SOLID.has(feet) && AIR.has(body) && AIR.has(head))) continue;
        const wallNames = DIRS.map(([ax, az]) => get(dx + ax, dy + 1, dz + az));
        if (wallNames.some((n) => n == null)) { wallNames.forEach((n, i) => { if (n == null) noteUnknown(dx + DIRS[i][0], dy + 1, dz + DIRS[i][1]); }); continue; }
        const walls = wallNames.filter((n) => SOLID.has(n)).length;
        if (walls >= 2) stands.push({ pos: [sp.x + dx, sp.y + dy, sp.z + dz], feet, walls, wallNames });
    }
    return { stands, unknownCells: [...unknown.values()], complete: unknown.size === 0 };
}

/**
 * 「脚下实心 + 身体/头空气」的**诊断**计数（不加墙约束）。
 * 零额外服务器开销（同一份逐格真值算出来的），用途：审阅时能区分
 * "这附近连站的地方都没有" 与 "有站的地方但没有墙"。
 */
export function findOpenFloors(get, sp, r, SOLID, AIR = new Set(['air'])) {
    const out = [];
    for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) for (let dy = -1; dy <= 0; dy++) {
        const feet = get(dx, dy, dz), body = get(dx, dy + 1, dz), head = get(dx, dy + 2, dz);
        if (feet == null || body == null || head == null) continue;
        if (SOLID.has(feet) && AIR.has(body) && AIR.has(head)) out.push({ pos: [sp.x + dx, sp.y + dy, sp.z + dz], feet });
    }
    return out;
}

// ---------------------------------------------------------------- 站位判据的"实心"白名单（两套都要落档）
/** ROUND4 原样：漏了 stairs / wall / chiseled 等要塞最常见的结构件（保留用于口径对照）。 */
export const SOLID_ROUND4 = new Set([
    'nether_bricks', 'netherrack', 'obsidian', 'blackstone', 'blackstone_bricks', 'stone_bricks',
    'chest', 'magma_block', 'nether_brick_fence', 'iron_bars', 'spawner',
]);
/** 本单口径：ROUND4 + 1.16.1 要塞/下界**真实可站或可挡火球**的结构件。
 *  依据逐条列在 SOLID_RATIONALE，审阅时按它复核。 */
export const SOLID_EXT = new Set([
    ...SOLID_ROUND4,
    // 1.16.1 要塞建材（原样漏掉的，正是这三条让 52 格"读不到"、也最可能被判成"不是实心"）
    'nether_brick_stairs', 'nether_brick_wall', 'chiseled_polished_blackstone',
    'chiseled_nether_bricks', 'cracked_nether_bricks', 'nether_brick_slab',
    // 1.16.1 黑石系
    'polished_blackstone_bricks', 'cracked_polished_blackstone_bricks', 'gilded_blackstone',
    // 下界地形/建材
    'basalt', 'polished_basalt', 'smooth_basalt', 'magma_block', 'netherrack',
    'crimson_nylium', 'warped_nylium', 'shroomlight', 'nether_wart_block',
    'soul_soil', 'soul_sand', 'glowstone', 'quartz_block', 'lodestone', 'chain',
    // 功能件（挡火球有效）
    'obsidian', 'crying_obsidian', 'spawner', 'chest', 'trapped_chest', 'iron_bars',
    'nether_brick_fence', 'netherite_block', 'ancient_debris', 'bedrock', 'end_rod',
]);
export const SOLID_RATIONALE = [
    '脚下要"能站"：nether_brick_stairs / nether_brick_wall / *_slab 的上表面是实心的（玩家能站上去）',
    'nether_brick_fence / iron_bars / chain：人过不去但**火球过得去**（烈焰人的火球只被"完整方块"挡），',
    '  ⇒ 它们算"墙"不算"地"：因此白名单里 fence/iron_bars 保留给墙判定，脚判定时 fence 顶面也能站（1.16.1 事实如此）',
    'blackstone / polished_blackstone_bricks / chiseled_* 是要塞地基；crimson_nylium / warped_nylium / soul_soil / magma_block 是下界地面',
    '**不把 cave_air / void_air 当空气**：1.16.1 没有这两种方块（minecraft-data 3.114 的 1.16.1 清单里居然有，见报告），',
    '  本单判据的"空气"只认 `air`，若服务器真出现别的名字会记成未解析而不是误判成空',
];

// ============================================================================================
// 离线：候选名清单
// ============================================================================================

/** 读 minecraft-data 1.16.1 的全量方块名（**只当候选**，真值由服务器裁定）。 */
export function readCandidateNames(dataPath = MINECRAFT_DATA) {
    const arr = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    const names = arr.map((b) => b.name).filter(Boolean);
    // 标记方块本身不能出现在候选里（`fill … barrier replace barrier` 是自替换，服务端直接报错）
    return [...new Set(names)].filter((n) => !EXCLUDE_NAMES.has(n)).sort();
}

/**
 * 不参与裁定的名字。
 *  - `barrier`：本文件的标记方块，`fill … barrier replace barrier` 是自替换，服务端直接报错；
 *  - 其余是"塞进去会有副作用/噪音"的方块：末地门框与门会让服务端去建传送门、
 *    命令方块/结构方块会刷控制台。盒外探针格上放这些东西没有测量价值，只会给日志添乱。
 */
export const EXCLUDE_NAMES = new Set([
    'barrier', 'end_portal', 'end_portal_frame', 'command_block', 'chain_command_block',
    'repeating_command_block', 'structure_block', 'jigsaw', 'structure_void', 'light',
]);

/** 盒外探针格的可选环（相对笼位）。必须在 forceload 覆盖范围内，且不在测量盒内。 */
export const PROBE_RING = [[8, 0, 0], [-8, 0, 0], [0, 0, 8], [0, 0, -8], [8, 0, 8], [-8, 0, 8], [8, 0, -8], [-8, 0, -8]];

/**
 * 找一个**盒外**探针格：逐个候选位用"这里是不是 netherrack"实测（不猜坐标，服务器自己回答）。
 * 判据要一个**已知原方块**：Pass 0 会在这一格上把候选名挨个放上去再换回，
 * 只有先知道这里原本是什么，才能保证收尾能**逐格复原**。
 * @returns {{pos:{x,y,z}, original:string}|null}
 */
export async function findProbeCell(con, sp, { timeoutMs = 12000, logFn = null } = {}) {
    for (const [dx, dy, dz] of PROBE_RING) {
        const p = { x: sp.x + dx, y: sp.y + dy, z: sp.z + dz };
        const box = { x1: p.x, y1: p.y, z1: p.z, x2: p.x, y2: p.y, z2: p.z };
        let r;
        // ⚠ 必须用**非破坏性**的 countAndRestore：裸 fillOnce 会把这一格换成 barrier 且不换回，
        //   于是 Pass 0 在一个装着 marker 的格子上裁定名字 → 全部"没命中"（第一版就是这么白跑的 74s）。
        try { r = await countAndRestore(con, 'the_nether', box, 'minecraft:netherrack', { timeoutMs }); }
        catch { continue; }                      // 无回执 ⇒ 这一位不可用，换下一个
        if (r.verdict === 'filled' && r.n === 1 && !r.restoreMismatch) {
            logFn?.(`  盒外探针格：(${p.x},${p.y},${p.z}) = netherrack（由回执实测选定，已复原）`);
            return { pos: p, original: 'netherrack' };
        }
    }
    return null;
}

// ============================================================================================
// 实跑
// ============================================================================================

const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const BUDGET_MS = parseInt(argOf(process.argv, 'budget-ms', '900000'), 10);
const RADIUS = parseInt(argOf(process.argv, 'radius', '2'), 10);
const OUT = path.resolve(argOf(process.argv, 'out', path.join(PROBE_DIR, 'fortress_standing.round5c.json')));
const PALETTE_OUT = path.join(PROBE_DIR, 'block_palette_1161.validated.json');

/** 刷怪笼位置来自 ROUND4 的独立取证（不是本单重新找的）——本单只补"站位"这一项。 */
function loadRound4Spawners() {
    const p = path.join(PROBE_DIR, 'fortress.round4c.json');
    const d = JSON.parse(fs.readFileSync(p, 'utf8'));
    return {
        src: 'bench/route/probe/fortress.round4c.json',
        seed: d.seed, mcVersion: d.mcVersion, status: d.status,
        scanSpawnerCount: d.spawnerCount,
        scanSpawnerSelfCheck: d.scan?.selfCheck?.['minecraft:spawner'] ?? null,
        scanCounts: d.scan?.counts ?? {},
        spawners: d.spawners ?? [],
        standingRound4: (d.standing ?? []).map((s) => ({
            spawner: s.spawner, probedCells: s.probedCells, unknown: s.unknown,
            restoreFails: s.restoreFails, coverStands: s.coverStands,
        })),
    };
}

async function main() {
    const t0 = Date.now();
    // ⚠ 预算只算**起服之后**的泳道占用，不算 `waitForLaneC` 的排队时间。
    //   派单给的纪律是"每次 ≤20 分钟、在 F 线两局之间借"，排多久不算我的占用；
    //   而且把排队算进预算会导致"排了 10 分钟 → 起服后第一个 assertBudget 立刻超支"，白占一次泳道。
    let tLane = null;
    const left = () => (tLane === null ? BUDGET_MS : BUDGET_MS - (Date.now() - tLane));
    const assertBudget = (where) => {
        if (left() <= 0) throw new Error(`BUDGET_EXCEEDED @ ${where}（泳道占用 ${Math.round((Date.now() - (tLane ?? t0)) / 1000)}s / 预算 ${Math.round(BUDGET_MS / 1000)}s）`);
    };

    const r4 = loadRound4Spawners();
    const sp = { x: r4.spawners[0].x, y: r4.spawners[0].y, z: r4.spawners[0].z };
    const names = readCandidateNames();

    const out = {
        schema: 'aidqq-round5c-fortress-standing/1',
        label: 'MC-ROUND5 §C：C-3「可挡火球站位」补测（ROUND4 该项 124 格探测中 52 格未解析 → 0 不可信）',
        seed: SEED, mcVersion: NODE_VER, lane: 'C', dim: 'the_nether',
        spawner: sp, radius: RADIUS,
        criterion: '脚下实心 + 身体/头两格 air + 四侧 ≥2 面 SOLID（与 ROUND4 逐字一致；只补全 SOLID 白名单）',
        startedAt: new Date().toISOString(),
        status: 'NOT_RUN',
        round4: r4,
        palette: { source: 'minecraft-data pc/1.16.1/blocks.json（仅候选）', candidateCount: names.length },
        gates: {},
    };
    let handle = null;
    const dim = 'the_nether';

    try {
        out.status = 'RUNNING';
        log(`=== C 线 · C-3 站位补测 === seed=${SEED} 笼=(${sp.x},${sp.y},${sp.z}) 半径=${RADIUS} 预算=${Math.round(BUDGET_MS / 1000)}s`);
        log(`候选名 ${names.length} 个（minecraft-data 1.16.1；真值由服务器逐个裁定）`);

        fs.mkdirSync(RUN_DIR, { recursive: true });
        handle = await bootLaneC({ seed: SEED, runDir: path.join(RUN_DIR, 'standing'), logFn: log });
        tLane = Date.now();                       // ← 泳道占用从这一刻起算
        out.bootMs = handle.server.bootMs;
        out.queueWaitMs = tLane - t0;

        // ---------- G0a：区块闸门（读数前必须确认这块已经加载） ----------
        // forceload 覆盖 ±16 格（1.16.1 的 forceload add 是**四参数**形式，scan.mjs 已按此发），
        // 测量盒 7³ 与盒外探针环（±8 格）都在这个范围内。
        await forceload(handle.con, dim, sp.x - 16, sp.z - 16, sp.x + 16, sp.z + 16, 1500);
        const gateCell = { x: sp.x, y: sp.y, z: sp.z };
        const gateBox = { ...gateCell, x1: sp.x, y1: sp.y, z1: sp.z, x2: sp.x, y2: sp.y, z2: sp.z };
        const gateProbe = await fillOnce(handle.con, dim, gateBox, 'netherrack', { timeoutMs: 20000 });
        out.gates.chunkGate = { probe: gateProbe.kind, count: gateProbe.n };
        log(`  区块闸门：笼格 (${sp.x},${sp.y},${sp.z}) fill 判决=${gateProbe.kind}${gateProbe.n != null ? ` (n=${gateProbe.n})` : ''}`);
        if (gateProbe.kind === 'not_loaded') throw new Error(`CHUNK_GATE_NOT_LOADED：笼格所在区块未加载，拒绝产出读数`);

        // ---------- 盒外探针格（Pass 0 的落点：不在测量盒内） ----------
        // ⚠ 为什么必须放到盒外：候选名里有 water / lava / sand / gravel —— 在测量盒里临时放这些方块，
        //   200ms 的窗口足够液体流动/沙子掉落，**流出去的方块不会随复原回来** ⇒ 污染读数且不报错。
        //   盒外探针格只用来裁定"服务器认不认这个名字"，放坏了也只坏一个格子（收尾会复原）。
        const probe = await findProbeCell(handle.con, sp, { logFn: log });
        if (!probe) throw new Error('PROBE_CELL_NOT_FOUND：forceload 范围内找不到一个已加载的 netherrack 格子当盒外探针 → 判定不可信');
        const probeBox = { x1: probe.pos.x, y1: probe.pos.y, z1: probe.pos.z, x2: probe.pos.x, y2: probe.pos.y, z2: probe.pos.z };
        out.probeCell = probe.pos;

        // ---------- Pass 0：候选名逐个裁定（在盒外探针格上） ----------
        log(`  Pass 0：${names.length} 个候选名在盒外探针格 (${probe.pos.x},${probe.pos.y},${probe.pos.z}) 上逐个裁定…`);
        const valid = [], rejected = [];
        for (let i = 0; i < names.length; i++) {
            assertBudget('Pass0');
            const nm = names[i];
            const r = await countAndRestore(handle.con, dim, probeBox, qname(nm), { timeoutMs: 12000 });
            if (isNameAccepted(r.verdict)) valid.push(nm);
            else rejected.push({ name: nm, verdict: r.verdict });
            if (r.restoreMismatch) throw new Error(`RESTORE_MISMATCH @ Pass0 ${nm}：标记计数与复原计数不等，探针格状态不可信`);
            if ((i + 1) % 150 === 0) log(`    …${i + 1}/${names.length}（有效 ${valid.length}，被判无效 ${rejected.length}）剩余 ${Math.round(left() / 1000)}s`);
        }
        // 探针格必须已复原成 netherrack
        const probeBack = await countAndRestore(handle.con, dim, probeBox, 'minecraft:netherrack', { timeoutMs: 12000 });
        out.gates.probeRestored = probeBack.verdict === 'filled' && probeBack.n === 1;
        if (!out.gates.probeRestored) throw new Error(`PROBE_NOT_RESTORED：盒外探针格没能复原成 netherrack（${JSON.stringify(probeBack)}）`);
        out.palette.validatedValid = valid.length;
        out.palette.rejected = rejected;
        out.palette.rejectedByVerdict = rejected.reduce((a, r) => { a[r.verdict] = (a[r.verdict] || 0) + 1; return a; }, {});
        fs.writeFileSync(PALETTE_OUT, JSON.stringify({
            schema: 'aidqq-validated-block-palette/1', mcVersion: NODE_VER, at: new Date().toISOString(),
            source: out.palette.source, candidateCount: names.length, excluded: [...EXCLUDE_NAMES], valid, rejected,
            note: 'valid = 服务器逐个裁定认得的方块名（1.16.1）；rejected = 1.16.1 不认的名字。'
                + 'minecraft-data 的清单只当候选：3.114 的 pc/1.16.1 含 1.17 才有的 cave_air/void_air，又缺 1.16 就有的 smooth_basalt。',
        }, null, 2));
        log(`  Pass 0 完成：有效 ${valid.length} / 无效 ${rejected.length}（${JSON.stringify(out.palette.rejectedByVerdict)}）→ ${path.relative(process.cwd(), PALETTE_OUT)}`);

        // ---------- G0b：端到端自证（笼格必须是 spawner） ----------
        // 刷怪笼位置是 ROUND4 独立测出的地面真值（粗扫 spawner 计数 1 == 下钻点数 1）。
        // 这里用**已被 Pass 0 裁定过的名字**去读笼格：读出 spawner ⇒ 名字解析、fill 通道、
        // 回执配对、区块加载四件事同时被证明是对的。
        if (!valid.includes('spawner')) throw new Error('SPAWNER_NAME_NOT_VALIDATED：`spawner` 连服务器都不认，C-3 的判据本身不成立');
        const centerTruth = await countAndRestore(handle.con, dim, gateBox, 'minecraft:spawner', { timeoutMs: 12000 });
        out.gates.centerTruth = gateCenterTruth(
            centerTruth.verdict === 'filled' && centerTruth.n === 1 ? [{ name: 'spawner', n: centerTruth.n }] : []
        );
        out.gates.centerTruth.raw = centerTruth;
        if (!out.gates.centerTruth.ok || centerTruth.restoreMismatch) {
            out.status = 'TOOL_SELF_CHECK_FAILED';
            throw new Error(`CENTER_TRUTH_MISMATCH：笼格应恰好是 spawner（ROUND4 独立测得的地面真值），实得 ${JSON.stringify(centerTruth)} —— 通道不可信`);
        }
        log(`  ✅ G0 端到端自证通过：笼格 = spawner（ROUND4 独立测得的地面真值）且已复原`);

        // ---------- Pass 1：整盒穷举计数（非破坏性：计数后整盒换回） ----------
        // ⚠ 取名范围比判据半径大 1：墙判定要读候选格**四侧的邻格**，候选格在 ±R 边缘时邻格落在盒外。
        //   ROUND4 的做法是把 5×5×5 盒外的邻格当"不是实心" ⇒ **系统性少判边缘站位**（假阴性）。
        //   这里取名扩到 ±(R+1)=7³，判据区仍严格是 ±2（口径不变，只是把"不知道"消掉了）。
        const TRUTH_R = RADIUS + 1;
        const size = TRUTH_R * 2 + 1;
        const box = { x1: sp.x - TRUTH_R, y1: sp.y - TRUTH_R, z1: sp.z - TRUTH_R, x2: sp.x + TRUTH_R, y2: sp.y + TRUTH_R, z2: sp.z + TRUTH_R };
        const totalCells = size * size * size;
        log(`  Pass 1：整盒 ${size}×${size}×${size}=${totalCells} 格，${valid.length} 个名字逐个整盒计数…`);
        const counts = {};
        let fills = 0, restoreMismatch = 0;
        for (const nm of valid) {
            assertBudget('Pass1');
            const r = await countAndRestore(handle.con, dim, box, qname(nm), { timeoutMs: 12000 });
            fills += 2;
            if (r.restoreMismatch) { restoreMismatch++; throw new Error(`RESTORE_MISMATCH @ Pass1 ${nm}：世界复原不等，后续读数全废`); }
            if (r.n > 0) counts[nm] = r.n;
        }
        out.paletteCounts = counts;
        out.box = { ...box, cells: totalCells, fills };
        out.gates.exhaustive = gateExhaustive(totalCells, counts, restoreMismatch);
        log(`  Pass 1 完成：识别 ${out.gates.exhaustive.identified}/${totalCells}，未识别 ${out.gates.exhaustive.unidentified}，复原不等 ${restoreMismatch}｜${JSON.stringify(counts)}`);
        if (!out.gates.exhaustive.ok) {
            out.status = 'PALETTE_INCOMPLETE';
            throw new Error(`PALETTE_INCOMPLETE：整盒 ${totalCells} 格只识别出 ${out.gates.exhaustive.identified}（未识别 ${out.gates.exhaustive.unidentified}）—— 按纪律不许输出站位数（这正是 ROUND4 的 bug）`);
        }

        // ---------- Pass 2：逐格真值 ----------
        // 三个空气名（air / cave_air / void_air）**全部试、不提前退出**：
        //   本台 1.16.1 把 1.17 才有的 cave_air 也认了，且整盒真值里有 6 格报成 cave_air。
        //   若那是 air 的别名，判据里写死 `body === 'air'` 就会少判站位 ⇒ 必须把两套口径都算出来。
        // 其余候选按 Pass 1 的计数**降序**试探（命中概率最高的先试，每格平均试探次数最少）。
        const AIR_NAMES = ['air', 'cave_air', 'void_air'].filter((n) => valid.includes(n));
        const rest = Object.keys(counts).sort((a, b) => counts[b] - counts[a]).filter((n) => !AIR_NAMES.includes(n));
        const order = [...AIR_NAMES, ...rest];
        const cells = [];
        for (let dx = -TRUTH_R; dx <= TRUTH_R; dx++) for (let dy = -TRUTH_R; dy <= TRUTH_R; dy++) for (let dz = -TRUTH_R; dz <= TRUTH_R; dz++) {
            if (dx === 0 && dy === 0 && dz === 0) continue;
            cells.push({ x: sp.x + dx, y: sp.y + dy, z: sp.z + dz, d: [dx, dy, dz] });
        }
        log(`  Pass 2：${cells.length} 格逐格真值（空气名 ${AIR_NAMES.length} 个全试 + 其余 ${rest.length} 个按计数降序）…`);
        const truth = new Map();
        const truthTable = [];                       // 整份逐格真值（审阅要能自己复算）
        let restoreFails = 0, unknownCells = 0, fills2 = 0, aliasCells = 0;
        cells.forEach((c) => truth.set(`${c.d[0]},${c.d[1]},${c.d[2]}`, null));          // 先置 null
        truth.set('0,0,0', 'spawner');                                                   // Pass 0 已用地面真值证明
        truthTable.push({ d: [0, 0, 0], pos: [sp.x, sp.y, sp.z], hits: ['spawner'], src: 'G0 端到端自证（地面真值）' });
        for (let i = 0; i < cells.length; i++) {
            assertBudget('Pass2');
            const c = cells[i];
            const r = await probeCellAllHits(handle.con, dim, c, order.map(qname), { timeoutMs: 12000 });
            fills2 += r.tests;
            if (!r.restoreOk) restoreFails++;
            const k = `${c.d[0]},${c.d[1]},${c.d[2]}`;
            if (r.hits.length > 1) aliasCells++;
            // 命名：若同时命中多个空气名，取第一个（air 优先）；否则取唯一的方块名
            const airHit = r.hits.find((h) => AIR_NAMES.includes(h));
            const name = airHit ?? r.hits[0] ?? null;
            truth.set(k, name);
            if (!name) unknownCells++;
            truthTable.push({ d: c.d, pos: [c.x, c.y, c.z], hits: r.hits, name });
            if ((i + 1) % 100 === 0) log(`    …${i + 1}/${cells.length}（未解析 ${unknownCells}，多命中 ${aliasCells}）剩余 ${Math.round(left() / 1000)}s`);
        }
        out.cellTruth = {
            cells: cells.length, unknown: unknownCells, restoreFails, fills: fills2, truthRadius: TRUTH_R,
            airNames: AIR_NAMES, multiHitCells: aliasCells, table: truthTable,
        };
        log(`  Pass 2 完成：未解析 ${unknownCells}，复原失败 ${restoreFails}，**同时命中多个名字的格子 ${aliasCells}**`);
        // ---------- Pass 3：世界复核（"这一趟没把盒子改掉"必须可证，否则前面的读数不作数） ----------
        // fill-replace 真的会把盒子改掉（手册 §5）。Pass 1/2 靠 2-fill 复原，但**液体/沙砾会流走**，
        // 复原不了的那部分不会报错、只会悄悄改变读数。这里把 Pass 1 命中过的名字 + 高危名重数一遍，
        // 要求与 Pass 1 **逐项相等**。
        const HIGH_RISK = ['lava', 'water', 'flowing_lava', 'flowing_water', 'sand', 'red_sand', 'gravel',
            'fire', 'soul_fire', 'snow', 'powder_snow', 'dirt', 'grass_block', 'soul_sand'];
        const recheckNames = [...new Set([...Object.keys(counts), ...HIGH_RISK.filter((n) => valid.includes(n))])];
        const drift = [];
        for (const nm of recheckNames) {
            assertBudget('Pass3');
            const r = await countAndRestore(handle.con, dim, box, qname(nm), { timeoutMs: 12000 });
            if (r.restoreMismatch) drift.push({ name: nm, before: counts[nm] ?? 0, after: r.n, why: 'restore_mismatch' });
            else if ((r.n ?? 0) !== (counts[nm] ?? 0)) drift.push({ name: nm, before: counts[nm] ?? 0, after: r.n, why: 'count_changed' });
        }
        out.worldRecheck = { names: recheckNames.length, drift };
        log(`  Pass 3 世界复核：重数 ${recheckNames.length} 个名字，漂移 ${drift.length} 处`);
        if (drift.length) {
            out.status = 'WORLD_DRIFTED';
            throw new Error(`WORLD_DRIFTED：测量过程中盒子被改动（${JSON.stringify(drift).slice(0, 300)}）—— 读数不作数，拒绝输出站位数`);
        }

        const get = (dx, dy, dz) => truth.get(`${dx},${dy},${dz}`) ?? null;

        // ---------- 站位判据（两套空气口径 + 两套 SOLID 白名单） ----------
        const AIR_ONLY = new Set(['air']);                       // 口径 A：与 ROUND4 逐字一致
        const AIR_LIKE = new Set(AIR_NAMES.length ? AIR_NAMES : ['air']);   // 口径 B：把本机认的空气名都算空气
        const standsA = findStands(get, sp, RADIUS, SOLID_EXT, AIR_ONLY);
        const standsB = findStands(get, sp, RADIUS, SOLID_EXT, AIR_LIKE);
        const standsR4 = findStands(get, sp, RADIUS, SOLID_ROUND4, AIR_LIKE);
        const openFloors = findOpenFloors(get, sp, RADIUS, SOLID_EXT, AIR_LIKE);
        const keyOf = (s) => s.pos.join(',');
        const onlyB = standsB.stands.map(keyOf).filter((k) => !standsA.stands.map(keyOf).includes(k));
        const onlyA = standsA.stands.map(keyOf).filter((k) => !standsB.stands.map(keyOf).includes(k));
        out.solidRation = SOLID_RATIONALE;
        out.stands = {
            criterionRadius: RADIUS,
            truthRadius: TRUTH_R,
            complete: standsA.complete && standsB.complete,
            unresolvedCells: standsA.unresolvedCells,
            // 口径 A（主口径，与 ROUND4 逐字一致）：身体/头必须正好是 `air`
            coverStands: standsA.stands.length,
            stands: standsA.stands,
            // 口径 B（本机还认 cave_air/void_air，把它们也算空气）
            airNamesSeen: AIR_NAMES,
            coverStandsAirLike: standsB.stands.length,
            standsAirLike: standsB.stands,
            air口径差: { onlyAirLike: onlyB, onlyAirOnly: onlyA },
            // 口径对照：同判据但用 ROUND4 的 SOLID 白名单
            coverStandsRound4Set: standsR4.stands.length,
            standsRound4Set: standsR4.stands,
            // 诊断：脚下实心 + 身体空（无墙约束）
            openFloors: openFloors.length,
            openFloorCells: openFloors,
        };
        log(`  站位（半径 ${RADIUS}）：空气名 ${JSON.stringify(AIR_NAMES)}`);
        log(`    口径A（身体==air）：${standsA.stands.length} 个｜口径B（空气名全算空气）：${standsB.stands.length} 个｜ROUND4 白名单：${standsR4.stands.length} 个｜有地可站：${openFloors.length}｜未解析 ${standsA.unknownCells.length}`);

        out.gates.perCell = gatePerCell(unknownCells, restoreFails);
        if (!out.gates.perCell.ok) {
            out.status = 'UNRESOLVED';
            throw new Error(`PER_CELL_UNRESOLVED：${unknownCells} 格仍未解析 → 状态 UNRESOLVED（**不输出站位数**）`);
        }
        out.status = 'OK';
    } catch (e) {
        out.error = String(e && e.stack ? e.stack : e);
        if (out.status === 'RUNNING') out.status = 'FAILED';
        log(`  ✗ ${out.status}：${String(e).split('\n')[0]}`);
    } finally {
        out.laneOccupiedSeconds = tLane === null ? 0 : Math.round((Date.now() - tLane) / 1000);
        out.seconds = Math.round((Date.now() - t0) / 1000);
        out.finishedAt = new Date().toISOString();
        try { if (handle) await shutdownLaneC(handle); } catch (e) { out.shutdownError = String(e); }
        fs.mkdirSync(path.dirname(OUT), { recursive: true });
        fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
        log(`落盘：${path.relative(process.cwd(), OUT)}（status=${out.status}，泳道占用 ${out.laneOccupiedSeconds}s，总墙钟 ${out.seconds}s）`);
    }
    return out;
}

if (process.argv[1] && path.resolve(process.argv[1]).endsWith('fortress_standing_probe.mjs')) {
    await main();
}
