// r9c_stand_readback.mjs — ROUND9-C：站位回读（**存档解析器**通道，零起服）
//
// 【为什么需要这个文件】ROUND8-C 的 v2 把 S3 / C3 的 stand 整体低 1 格，
//   而"低 1 格"这件事在**三个地方各有一套差 +1 的口径**（HANDOVER 跨线通告 ㊷ ④）：
//     ① SCHEMA §5 / ROUND5C `stands[].pos`        = **脚下那格**（支撑方块那一格）
//     ② `s3_bastion_gold_piglins.mjs` workPoints   = **身体格**（空气格）
//     ③ `v2_nether_legs_corrected.json` 的 standGround = 名字叫 ground，但**存的是身体格**
//   ⇒ 任何"改坐标"的修复都可能再错 1 格。本文件**只做一件事**：把某一列逐格读出来，
//   然后按**唯一一条**判据（SCHEMA §5 口径：`stand` = 脚下那格 = 脚踩的那一格坐标）
//   给出 standable / 不可 standable 的结论与**读到的方块名**。
//
// 判据（= route_guard 的站位判据的唯一真源，两边共用同一份）：
//   **本项目的口径（SCHEMA §5 + ROUND5C `stands[].pos` + 现状速览 ㊷ ①）**：
//     `stand` = **脚下那格 = 玩家脚底下那一格（支撑方块）**；玩家身体占 y+1 与 y+2。
//     ⇒ 物理等价写法：**玩家 Pos.y = stand.y + 1**（实体位置就是脚）。
//   合法 ⟺ blockAt(x,y,z) 实心非危险 ∧ blockAt(x,y+1,z) ∈ AIR ∧ blockAt(x,y+2,z) ∈ AIR
//   ⚠ **与另外两套口径差 +1，移植时别混**（现状速览 ㊷ ④）：
//     ② `s3_bastion_gold_piglins.mjs` / `exact/s3_bastion.exact.json` 的 workPoints.picks[].stand
//        = **身体格**（空气格）= 本口径 +1 ⇒ 转过来要 **减 1**。
//        实测：F 线交来的 `[[331,57,238]]` 在存档里 57/58 是空气、56 是砖 ⇒ 57 是身体格，
//        本口径的 stand = **56**（与设计会话 10-03 的指定值一致）。
//     ③ 探针 `v2_nether_legs_corrected.json` 的 `standGround` = **支撑方块**（与本口径同）
//        —— ROUND8-C 的组装器对它再减了 1，**那才是低 1 格的病根**。
//
// 用法：
//   node r9c_stand_readback.mjs --world probe/_bedhunt --dim the_nether \
//        --col 331,238 --y0 50 --y1 75
//   node r9c_stand_readback.mjs --worlds probe/_bedhunt,probe/_nether_corridor --col 0,0 --y0 30 --y1 80
// 退出码：0 = 至少读到一个非 unknown 的格子；2 = 全部 unknown（通道坏了，不是"没有"）。

import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { openWorld, bare } from './region_reader.mjs';
import { judgeStand, AIRLIKE, GROUND_HARD_FAIL, GROUND_WARN, standBodyCells } from '../lib/stand_criterion.mjs';

// 判据本体在 `bench/route/lib/stand_criterion.mjs`（**唯一真源**，route_guard v2 与
// `v2_build_route.mjs` 也 import 同一份）。本文件只做"把一列逐格读出来 + 打印"。
export { judgeStand, AIRLIKE, GROUND_HARD_FAIL, GROUND_WARN };
export { standBodyCells };

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE = path.resolve(HERE, '..');

const argOf = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 ? process.argv[i + 1] : d; };
const has = (n) => process.argv.includes('--' + n);

export const AIRLIKE_UNUSED_MARKER = null; // （AIRLIKE/判据已移到 lib/stand_criterion.mjs）

/**
 * 站位判据 —— 已移到 `bench/route/lib/stand_criterion.mjs`，本文件只 re-export。
 * 保留这段注释是因为"判据在哪"这件事本身就是本单踩过的坑（见文件头）。
 */

const worlds = (argOf('worlds', argOf('world', `probe/_bedhunt`))).split(',').map((s) => s.trim()).filter(Boolean);
const dim = argOf('dim', 'the_nether');
const cols = argOf('col', '331,238').split(';').map((s) => s.trim()).filter(Boolean).map((s) => s.split(',').map(Number));
const y0 = Number(argOf('y0', '50'));
const y1 = Number(argOf('y1', '75'));
const label = argOf('label', '');

const out = { schema: 'aidqq-stand-readback/1', at: new Date().toISOString(), dim, cols: cols.map(([x, z]) => [x, z]), yRange: [y0, y1], label, worlds: [] };
let anyRead = false;

for (const w of worlds) {
    const dir = path.resolve(ROUTE, w);
    if (!fs.existsSync(dir)) { out.worlds.push({ world: w, missing: true }); continue; }
    let world;
    try { world = openWorld(dir, { dims: ['overworld', 'the_nether', 'the_end'] }); }
    catch (e) { out.worlds.push({ world: w, openError: String(e) }); continue; }

    const wOut = { world: w, dir, columns: [] };
    for (const [x, z] of cols) {
        const col = { x, z, cells: [], stands: [] };
        for (let y = y0; y <= y1; y++) {
            const st = world.blockState(x, y, z, dim);
            if (st.name !== 'unknown') anyRead = true;
            col.cells.push({ y, name: st.name, level: st.props?.level ?? null });
        }
        for (const c of col.cells) {
            const at = (y) => (y < y0 || y > y1 ? 'out_of_range' : (col.cells.find((k) => k.y === y)?.name ?? 'unknown'));
            const j = judgeStand(at(c.y), at(c.y + 1), at(c.y + 2));
            if (j.ok || j.reason.startsWith('body_low_not_air') || j.reason.startsWith('body_high_not_air') || j.reason.startsWith('no_ground') || j.reason.startsWith('ground_hazardous'))
                col.stands.push({ stand: [x, c.y, z], bodyCells: [[x, c.y + 1, z], [x, c.y + 2, z]], ...j });
        }
        col.standsOk = col.stands.filter((s) => s.ok).map((s) => s.stand);
        wOut.columns.push(col);
    }

    // ---- 水体普查（`--water`）：某片区域里 water / lava / magma_block 的逐格计数。
    //      用途：把"出生点是海面"这类**说法**变成**读数**。**没有阳性对照的水体普查等于没跑**，
    //      所以同时输出各 y 的方块直方图（地形对照，见手册 §5）。
    if (has('water')) {
        const [ax0, az0, ax1, az1] = argOf('area', '208,216,224,232').split(',').map(Number);
        const census = { area: [ax0, az0, ax1, az1], yRange: [y0, y1], byName: {}, byY: {}, unknownCells: 0, cells: 0 };
        for (let y = y0; y <= y1; y++) {
            census.byY[y] = {};
            for (let x = ax0; x <= ax1; x++) for (let z = az0; z <= az1; z++) {
                const n = world.blockAt(x, y, z, dim);
                census.cells++;
                if (n === 'unknown') { census.unknownCells++; continue; }
                census.byName[n] = (census.byName[n] ?? 0) + 1;
                census.byY[y][n] = (census.byY[y][n] ?? 0) + 1;
            }
        }
        wOut.waterCensus = census;
    }
    wOut.stats = world.stats;
    out.worlds.push(wOut);
}

if (has('json')) {
    const dst = path.resolve(ROUTE, argOf('json', 'probe/r9c_stand_readback.json'));
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.writeFileSync(dst, JSON.stringify(out, null, 2));
    // 手册 §5：写完必须读回断言一次（Windows 上路径/编码问题会静默失败）
    const back = JSON.parse(fs.readFileSync(dst, 'utf8'));
    if (back.cols?.length !== cols.length) { console.error(`✗ 写回读出不一致：${dst}`); process.exit(1); }
    console.log(`已写并读回：${dst}`);
}

for (const w of out.worlds) {
    if (w.missing) { console.log(`\n【${w.world}】目录不存在`); continue; }
    if (w.openError) { console.log(`\n【${w.world}】打开失败：${w.openError}`); continue; }
    console.log(`\n【${w.world}】dim=${dim}`);
    for (const col of w.columns) {
        console.log(`  列 (${col.x},*,${col.z})  y=${y0}..${y1}`);
        console.log('   ' + col.cells.map((c) => `${c.y}:${bare(c.name)}${c.level != null ? `(L${c.level})` : ''}`).join(' '));
        for (const s of col.stands) console.log(`    ${s.ok ? '✅' : '❌'} stand=${JSON.stringify(s.stand)} ground=${bare(String(s.ground))} ${s.reason}${s.warn.length ? ' warn=' + s.warn.join(',') : ''}`);
    }
    console.log(`  站得住的 stand（脚下那格口径）：${JSON.stringify(w.columns.map((c) => c.standsOk))}`);
    if (w.waterCensus) {
        const c = w.waterCensus;
        console.log(`  水体普查 area=${JSON.stringify(c.area)} y=${c.yRange} cells=${c.cells} unknown=${c.unknownCells}`);
        console.log(`    byName: ${JSON.stringify(c.byName)}`);
        for (const [y, m] of Object.entries(c.byY)) console.log(`    y=${y}: ${JSON.stringify(m)}`);
    }
    console.log(`  stats: ${JSON.stringify(w.stats)}`);
}
console.log(`\n通道自检：读到非 unknown 的格子 = ${anyRead ? '有 ✅' : '全部 unknown ❌（这是"没读到"，不是"没有"）'}`);
process.exit(anyRead ? 0 : 2);
