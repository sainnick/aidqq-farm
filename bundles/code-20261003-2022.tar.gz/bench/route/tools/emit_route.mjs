﻿// emit_route.mjs — MC-ROUTE-02 route 生成器 · **emit 阶段**（纯函数、零机器时间）
//
// 输入：bench/route/probe/<seed>.probe.json（gen_route.mjs 产出）
// 输出：bench/route/<seed>.json（符合 bench/route/SCHEMA.md v1 的**草稿**）
//
// 必须是纯函数：同一个 probe 重复 emit，输出除时间戳外逐字节一致
// ——验收"生成器对同一种子重复运行结果一致"就是靠 `emit` 跑两遍做 diff（秒级，不占泳道）。
//
// 两条设计红线（SCHEMA §1 的 L2 结构性保证）：
//   1. **精确坐标只进 scout.points**，station 区只放"区域"（center + radius + yHint + lookFor）。
//   2. station.center 由本文件**主动粗化到 16 格网格**——比加载器兜底的 8 格更粗，
//      所以即使有人绕过 route_loader 直接读本文件，拿到的也只是"这一片"，
//      不是"这一格"。（加载器仍会再对齐到 8 格并强制 radius ≥16，两层独立。）
//
// 站序 = 通用 SSG 路线（route-01 §1.1 社区八段 → DECISION-01 §2.2 的 L2 切法），
// **不含任何针对单个种子的特化**。
//
// 用法：node emit_route.mjs --seed <seed> [--out <path>]

import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';
import { argOf } from '../../stages/_lib/runner_core.mjs';
import { ROUTE_DIR } from './console.mjs';

const SEED = argOf(process.argv, 'seed', '-8839485814800629942');
const OUT = argOf(process.argv, 'out', path.join(ROUTE_DIR, `${SEED}.json`));
const PROBE = path.join(ROUTE_DIR, 'probe', `${SEED}.probe.json`);

// ---- 站序（通用 SSG 路线；radius 一律 ≥16，SCHEMA 的硬下限） ----
export const STATION_ORDER = [
    {
        id: 'S0_iron', kind: 'iron_source', dim: 'overworld', cat: 'iron_source', mode: 'area',
        yHint: 'underground', radius: 32, lookFor: ['iron_ore'],
        intent: '开局的铁：6 锭够（桶3+打火石1+剑1+镐1）。指一片有铁矿的区域，具体挑哪块由 bot 按暴露面判据自己选',
    },
    {
        id: 'S0_gravel', kind: 'gravel', dim: 'overworld', cat: 'gravel', mode: 'area',
        yHint: 'surface', radius: 32, lookFor: ['gravel'],
        intent: '打火石的燧石：挖沙砾，掉率 10%',
    },
    {
        id: 'S0_sheep', kind: 'sheep', dim: 'overworld', cat: null, mode: 'unverifiable',
        yHint: 'surface', radius: 32, lookFor: ['sheep'],
        intent: '食物（羊排/羊毛）。1.16.1 无 /locatebiome、无 execute if biome，且羊是实体随机生成，赛前无法确定性核验 → 本站恒为 UNVERIFIED，运行时靠到达确认闸门自己找',
    },
    {
        id: 'S1_portal', kind: 'ruined_portal', dim: 'overworld', cat: 'ruined_portal', mode: 'point',
        yHint: 'surface', radius: 24, lookFor: ['crying_obsidian', 'obsidian'],
        fallback: ['S1b_lava_pool'],
        intent: '地狱门：废弃传送门通常自带大部分框，补齐缺的即可点燃（不挖黑曜石，所以不需要钻石镐）',
    },
    {
        id: 'S1b_lava_pool', kind: 'lava_pool', dim: 'overworld', cat: 'lava_pool', mode: 'area',
        yHint: 'underground', radius: 24, lookFor: ['lava'],
        intent: '浇门/点燃的岩浆源：离废墟门最近的岩浆。S1_portal 的 fallback',
    },
    {
        id: 'S3_bastion', kind: 'bastion', dim: 'the_nether', cat: 'bastion', mode: 'point',
        yHint: 'nether_mid', radius: 32, lookFor: ['gilded_blackstone', 'gold_block', 'chest'],
        intent: '易物换珍珠：堡垒遗迹里的金块/金箱。1.16.1 无猪灵蛮兵（piglin brute 是 1.16.2+），珍珠率反而是 2.2 倍版本红利',
    },
    {
        id: 'S4_fortress_spawner', kind: 'fortress_spawner', dim: 'the_nether', cat: 'fortress_spawner', mode: 'point',
        yHint: 'nether_mid', radius: 32, lookFor: ['spawner'],
        intent: '烈焰棒：下界要塞刷怪笼。1 棒=2 粉、1 眼=1 粉 → 6 棒=12 眼（硬下限），推荐 8 根',
    },
    {
        id: 'S5_stronghold_room', kind: 'stronghold_portal_room', dim: 'overworld', cat: 'stronghold_room', mode: 'point',
        yHint: 'underground', radius: 24, lookFor: ['end_portal_frame'],
        intent: '末地门室：12 个框。站给"要塞这一片"，bot 自己 findBlocks 找齐 12 框再逐个投眼',
    },
];

/** scout 点位采样上限：一个要塞能有几百个刷怪笼，全塞进 route 文件没有意义
 *  （站级 radius ≥16，任务层要的是"这一片"）。完整真值保留在 verify.counts 里，
 *  scout 只留少量可审阅的样本 + 截断标记。 */
export const SCOUT_POINT_CAP = 8;

/** 任务单 §1.2：烈焰人刷怪笼「≥2 个冗余」。低于它 → 站标 `insufficient_spawners`（接受降级）。
 *  放成模块常量而不是写死在判断里，是为了让"降级"这件事在 route 里**可重现、可审阅**。 */
export const MIN_BLAZE_SPAWNERS = 2;
const capPoints = (pts) => {
    if (pts.length <= SCOUT_POINT_CAP) return { points: pts, truncated: false, total: pts.length };
    return { points: pts.slice(0, SCOUT_POINT_CAP), truncated: true, total: pts.length };
};

/** 主动粗化到 16 格网格（比加载器兜底的 8 格更粗，见文件头红线 2） */
export const coarsen16 = (v) => Math.floor(v / 16) * 16;
const centroid = (pts) => {
    if (!pts.length) return null;
    const s = pts.reduce((a, p) => ({ x: a.x + p.x, y: a.y + p.y, z: a.z + p.z }), { x: 0, y: 0, z: 0 });
    return { x: s.x / pts.length, y: s.y / pts.length, z: s.z / pts.length };
};
const stripNs = (o) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k.replace(/^minecraft:/, ''), v]));

/** 从 probe 的一段结果算出站：精确点 → scout；区域中心 → station（粗化） */
function buildStation(spec, probe) {
    const cat = spec.cat ? probe.categories?.[spec.cat] : null;
    const base = { id: spec.id, seq: 0, kind: spec.kind, dim: spec.dim };

    // ---- 无探测能力（羊）：直接 UNVERIFIED ----
    if (!spec.cat) {
        return {
            ...base,
            station: { center: [0, 0], yHint: spec.yHint, radius: spec.radius, lookFor: spec.lookFor },
            scout: {
                points: [],
                verify: {
                    status: 'UNVERIFIED', method: 'none',
                    reason: '1.16.1 无 /locatebiome（手册 §2）也无 execute if biome（1.19+ 才有）；羊是实体随机生成，赛前无法用 fill-replace 核验',
                    counts: {}, terrain: {}, at: probe.generatedAt,
                    evidence: 'bench/route/probe/' + probe.seed + '.probe.json#categories（无 sheep 条目）',
                },
                notes: spec.intent,
            },
            fallback: spec.fallback ?? [],
        };
    }

    if (!cat || cat.status !== 'OK') {
        return {
            ...base,
            station: { center: [0, 0], yHint: spec.yHint, radius: spec.radius, lookFor: spec.lookFor },
            scout: {
                points: [],
                verify: {
                    status: 'UNVERIFIED', method: 'fill-replace',
                    reason: cat?.reason ?? 'probe_missing', counts: {}, terrain: {},
                    at: probe.generatedAt, evidence: 'bench/route/probe/' + probe.seed + '.probe.json#categories.' + spec.cat,
                },
                notes: `${spec.intent}｜探测未通过：${cat?.reason ?? 'probe 缺失'}`,
            },
            fallback: spec.fallback ?? [],
        };
    }

    // ---- 取精确点（点状）或命中盒（面状） ----
    let points = [];
    let pointsTruncated = false, pointsTotal = 0;
    for (const [blk, pts] of Object.entries(cat.points ?? {})) {
        const capped = capPoints(pts.map((p) => ({ ...p, what: blk.replace(/^minecraft:/, '') })));
        points = points.concat(capped.points);
        pointsTruncated = pointsTruncated || capped.truncated;
        pointsTotal += capped.total;
    }
    let centerRaw;
    if (spec.mode === 'point' && points.length) {
        const c = centroid(points);
        centerRaw = { x: c.x, z: c.z };
    } else {
        const nb = cat.nearestBox;
        centerRaw = nb ? { x: (nb.box.x1 + nb.box.x2) / 2, z: (nb.box.z1 + nb.box.z2) / 2 } : { x: cat.start.x, z: cat.start.z };
        if (!nb) {
            return {
                ...base,
                station: { center: [coarsen16(centerRaw.x), coarsen16(centerRaw.z)], yHint: spec.yHint, radius: spec.radius, lookFor: spec.lookFor },
                scout: {
                    points: [],
                    verify: {
                        status: 'UNVERIFIED', method: 'fill-replace', reason: 'no_hit_box',
                        counts: stripNs(cat.counts), terrain: stripNs(cat.terrain), at: probe.generatedAt,
                        evidence: 'bench/route/probe/' + probe.seed + '.probe.json#categories.' + spec.cat,
                    },
                    notes: `${spec.intent}｜区域扫描没有任何命中盒`,
                },
                fallback: spec.fallback ?? [],
            };
        }
        // 面状站也把命中盒记进 scout（人审阅用：这一片有多少货）
        points = [{ what: 'hit_box', x: nb.box.x1, y: nb.box.y1, z: nb.box.z1, box: nb.box, hit: nb.hit }];
    }

    const station = {
        center: [coarsen16(centerRaw.x), coarsen16(centerRaw.z)], // ← 粗化到 16 格网格
        yHint: spec.yHint,
        radius: spec.radius,                                  // ≥16（SCHEMA 硬下限）
        lookFor: spec.lookFor,
    };
    if (station.radius < 16) throw new Error(`SCHEMA_VIOLATION: ${spec.id} radius=${station.radius} < 16`);
    if (station.center[0] % 8 !== 0 || station.center[1] % 8 !== 0) throw new Error(`SCHEMA_VIOLATION: ${spec.id} center 未对齐 8 格`);

    // ---- 站级附加判据（ROUND3 §C-1 / §C-4）----
    // **必须放在 center 算完之后**：下面的 frame/missing 点位是给人审阅的，
    // 混进 center 的质心会把站心带偏（它们是"缺格"，不是"结构在哪"）。
    const extra = { verify: {}, flags: [], notes: [] };

    // ① 传送门框体：逐格判定落到 scout（缺几格、缺格被什么占、要补几块 obsidian）
    const frame = spec.cat === 'ruined_portal' ? cat.frame?.best : null;
    if (frame) {
        extra.verify.frame = {
            origin: frame.origin, axis: frame.axis,
            obsidian: frame.obsidian, required: frame.required, optionalObsidian: frame.optionalObsidian,
            missingCells: frame.missing.map((m) => ({ pos: m.pos, got: m.got })),
            wrongCells: frame.wrong.map((m) => ({ pos: m.pos, got: m.got })),
            interiorDirty: frame.dirty,
            obsidianToPlace: frame.obsidianToPlace,
            usable: frame.usable,
            geometry: 'frameCells（生产 nether.js 的独立移植，bench/route/tools/portal_frame.mjs；4×5、顶行两角可省）',
        };
        points = points.concat(
            frame.missing.map((m) => ({ what: 'frame_missing', x: m.pos[0], y: m.pos[1], z: m.pos[2], got: m.got })),
            frame.wrong.map((m) => ({ what: 'frame_wrong_block', x: m.pos[0], y: m.pos[1], z: m.pos[2], got: m.got })),
        );
        extra.notes.push(`框体逐格：obsidian ${frame.obsidian}/${frame.required} · 缺(空) ${frame.missing.length} · 错块 ${frame.wrong.length}`
            + ` · 内部脏 ${frame.dirty.length} · **需补 obsidian ${frame.obsidianToPlace}**`);
        if (!frame.usable) extra.flags.push('frame_incomplete');
    }

    // ② 岩浆站：源块 + 离门距离 / 高度差 / 可达性代理；有合格源就把站心指到它
    if (spec.cat === 'lava_pool' && cat.sources) {
        const s = cat.sources;
        extra.verify.lavaSources = {
            blockState: s.blockState, count: s.count, sampling: s.fallbackSampling,
            doorRef: s.doorRef, criteria: s.criteria, verdict: s.verdict,
            best: s.best, nearest: (s.points ?? []).slice(0, 8),
        };
        if (s.best) {
            station.center = [coarsen16(s.best.x), coarsen16(s.best.z)];
            extra.notes.push(`岩浆源：(${s.best.x},${s.best.y},${s.best.z}) 距门 ${s.best.dist2d} 格 / Δy=${s.best.dy}`
                + ` / 源块上方${s.best.standable ? '是空气（站得下）' : '非空气'}`);
        } else {
            extra.flags.push('no_usable_lava_source');
            extra.notes.push(`岩浆站：区域内源块 ${s.count} 个，但**没有**满足「离门 ≤48 格 + Δy ≤8 + 上方可站」的（${s.verdict}）`);
        }
    }

    // ③ 刷怪笼降级标记（ROUND3 §C-4：接受降级、不加宽、不再追）
    if (spec.cat === 'fortress_spawner') {
        const n = cat.counts?.['minecraft:spawner'] ?? 0;
        extra.verify.blazeSpawners = { found: n, required: MIN_BLAZE_SPAWNERS, sufficient: n >= MIN_BLAZE_SPAWNERS };
        if (n < MIN_BLAZE_SPAWNERS) {
            extra.flags.push('insufficient_spawners');
            extra.notes.push(`**降级**：区域内刷怪笼只有 ${n} 个 < 要求的 ${MIN_BLAZE_SPAWNERS}（1 个笼≈2 根烈焰棒，S3 目标 8 根）。`
                + `按 ROUND3 §C-4 接受现状、不加宽；编排器见到本标记应把这一站当"尽力而为"，不要重试到超时`);
        }
    }

    return {
        ...base,
        station,
        scout: {
            points,
            pointsTotal,
            pointsTruncated,
            ...(extra.flags.length ? { flags: extra.flags } : {}),
            verify: {
                status: 'REAL', method: 'fill-replace',
                counts: stripNs(cat.counts), terrain: stripNs(cat.terrain),
                at: probe.generatedAt,
                evidence: `bench/route/probe/${probe.seed}.probe.json#categories.${spec.cat}`,
                ...extra.verify,
            },
            notes: [
                `${spec.intent}｜下钻自检 ${JSON.stringify(cat.selfCheck)}；命中盒 ${cat.hitBoxes.length}`,
                `；对照 ${cat.terrainProof ?? 'in-scan'}=${cat.terrainTotal}`,
                (pointsTruncated ? `；scout 点位已采样（${points.length}/${pointsTotal}，完整真值见 verify.counts）` : ''),
                ...(extra.notes.length ? [`｜${extra.notes.join('｜')}`] : []),
            ].join(''),
        },
        fallback: spec.fallback ?? [],
    };
}

export function emitRoute(probe) {
    const stations = STATION_ORDER.map((spec, i) => {
        const s = buildStation(spec, probe);
        s.seq = i + 1;
        return s;
    });
    return {
        schema: 'aidqq-route/1',
        seed: String(probe.seed),
        mcVersion: probe.mcVersion ?? '1.16.1',
        frozenAt: null,            // 草稿：冻结由设计会话做（本单不写）
        sha256File: null,          // 冻结时才生成 <seed>.sha256
        generatedFrom: {
            probe: `bench/route/probe/${probe.seed}.probe.json`,
            tool: 'bench/route/tools/gen_route.mjs (probe) + emit_route.mjs (emit)',
            method: probe.method,
        },
        generatedAt: probe.generatedAt, // 唯一的顶层时间戳（diff 验收时归一化这一个字段）
        stations,
    };
}

// 主入口判断：必须用 pathToFileURL 比。字符串拼 `file://${argv[1]}` 在 Windows 上
// 少一个斜杠（import.meta.url 是 file:///D:/…），条件永远不成立、脚本静默什么都不干。
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
    if (!fs.existsSync(PROBE)) { console.error(`找不到 probe：${PROBE}（先跑 gen_route.mjs --seed ${SEED}）`); process.exit(2); }
    const probe = JSON.parse(fs.readFileSync(PROBE, 'utf8'));
    const route = emitRoute(probe);
    fs.writeFileSync(OUT, JSON.stringify(route, null, 2) + '\n');
    const real = route.stations.filter((s) => s.scout.verify.status === 'REAL').length;
    console.log(`emit → ${OUT}`);
    console.log(`  ${route.stations.length} 站：REAL ${real} / UNVERIFIED ${route.stations.length - real}`);
    for (const s of route.stations) {
        console.log(`  ${String(s.seq).padStart(2)} ${s.id.padEnd(20)} ${s.kind.padEnd(24)} ${s.scout.verify.status.padEnd(10)} center=${JSON.stringify(s.station.center)} r=${s.station.radius} dim=${s.dim}`);
    }
}

