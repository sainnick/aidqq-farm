// r7c_chest_open.mjs — ROUND7-C 续单3：地牢箱**实例级**战利品（fresh world 真开箱）
//
// 【为什么必须真开箱】1.16.1 的箱子战利品是**第一次被打开那一刻**按 `LootTableSeed` 生成的，
//   生成完就写进方块实体 NBT。战利品表只能给"可能出什么"（表级），
//   **"这一箱实际出了什么"（实例级）只能开一次箱才知道**。上一单明确没做这一趟。
//
// 【口径：赛前预勘，允许】手册 §7「赛前允许：用服务器权威通道核验」。本单**只读世界**，
//   不改 route、不写 station、不写 frozenAt。唯一的"写"是**打开箱子**——
//   这正是被测对象本身，且用的是**另一份 fresh world**，不污染任何既有存档（手册 §5
//   「fill/交互会真实改变世界 ⇒ 重叠区域要换 fresh world」）。
//
// 【两条独立读数通道】（互相证伪，防"读数通道坏了"被读成"箱子是空的"）
//   A. **mineflayer 4.38 客户端**：`openContainer` → `window.containerItems()`（bot 真实看到的东西）
//   B. **服务器控制台**：`data get block <x> <y> <z>`（方块实体 NBT 原文，服务端权威）
//   两条不一致 ⇒ 如实报 INCONSISTENT，不挑一个信。
//
// 【站位来自离线几何】站位由 `r7c_chest_locus.mjs` 从只读存档算出（站得住 + 看得见 + 够得着），
//   **不在这里试错**。注意 (166,39,212) 一个点同时够到两个地牢箱（各 1.501 格）。
//
// 【只发命令】`difficulty` / `forceload add` / `gamemode` / `clear` / `tp` / `data get block` /
//   `save-all`。**不发 fill / setblock / summon** —— 一个方块都不改（除箱子自己被打开）。

import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, LANE, ROUTE_DIR, ROOT } from './console.mjs';

const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const mineflayer = require('mineflayer');
// ⚠ `bot.blockAt` 内部调 `pos.floored()` ⇒ **必须传 Vec3 实例**，传普通 `{x,y,z}` 会 TypeError（本单踩过）
const { Vec3 } = require('vec3');

const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const RUN_DIR = path.join(ROUTE_DIR, 'probe', '_run_round7c_chest');
const OUT = path.join(ROUTE_DIR, 'probe', 'chest_open.round7c.json');
const DEST = path.join(ROUTE_DIR, 'probe', '_chestopen');
// 站位表 = r7c_chest_locus.mjs 的输出（chest_locus.round7c.json），**离线算的，不是这里试出来的**
const LOCUS = path.join(ROUTE_DIR, 'probe', 'chest_locus.round7c.json');

// 一次传送开一组箱：dungeon 组用一个点开两个
const GROUPS = [
    { id: 'dungeon_pair', stand: [166, 39, 212], targets: ['dungeon_A', 'dungeon_B'] },
    { id: 'S1_ruined_portal', stand: [184, 40, 309], targets: ['S1_ruined_portal'] },
];

// forceload 窗口：目标 cx 10..11 / cz 13..19，各留 1 区块余量 ⇒ cx 9..12 / cz 12..20
const CX0 = 9, CX1 = 12, CZ0 = 12, CZ1 = 20;
const bx0 = CX0 * 16, bx1 = (CX1 + 1) * 16 - 1, bz0 = CZ0 * 16, bz1 = (CZ1 + 1) * 16 - 1;
const expectedChunks = (CX1 - CX0 + 1) * (CZ1 - CZ0 + 1);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** vec3 → 普通对象。⚠ 这条线上的 vec3 **没有 `toJSON()`**（1.16.1 实测 TypeError，白烧一轮起服）。 */
const v3 = (p) => ({ x: +p.x.toFixed(2), y: +p.y.toFixed(2), z: +p.z.toFixed(2) });

// ⚠⚠ 判据自检必须**在起服之前**跑完。守卫写在本文件靠后位置时，
//   `node r7c_chest_open.mjs --selftest` 会**先起服再自检**（本单真的踩了一次，白烧一轮起服）。
if (process.argv.includes('--selftest')) {
    const rr = selftestParse();          // 函数声明已提升，可以先调
    for (const x of rr) console.log(`${x.pass ? 'PASS' : 'FAIL'}  ${x.id}${x.detail !== undefined ? '  ' + JSON.stringify(x.detail) : ''}`);
    const ok = rr.every((x) => x.pass);
    console.log(`解析判据自检 ${rr.filter((x) => x.pass).length}/${rr.length} ⇒ ${ok ? 'OK' : 'SELFTEST_FAILED'}`);
    process.exit(ok ? 0 : 2);
}

async function cmdOnce(con, cmd, re, timeoutMs = 60000) {
    con.drain();
    con.cmd(cmd);
    const t0 = Date.now();
    const seen = [];
    for (;;) {
        for (const line of con.drain()) { seen.push(line); if (re.test(line)) return line; }
        if (Date.now() - t0 > timeoutMs) throw new Error(`CMD_NO_RECEIPT: ${cmd}（${seen.slice(-2).join(' | ').slice(0, 300)}）`);
        await sleep(50);
    }
}

const out = {
    schema: 'aidqq-round7c-chest-open/1',
    at: new Date().toISOString(), seed: SEED, mcVersion: '1.16.1', lane: 'C',
    bot: LANE.username, difficulty: 'peaceful',
    purpose: '地牢箱 + S1 废墟门箱的**实例级**战利品（真开箱），两条独立读数通道',
    startedAt: new Date().toISOString(), status: 'NOT_RUN',
    window: { chunks: { cx: [CX0, CX1], cz: [CZ0, CZ1] }, blocks: { x: [bx0, bx1], z: [bz0, bz1] }, expectedChunks },
    commandsIssued: [], groups: [], locusFile: LOCUS, note: '只出数据，不改 route',
};

let h = null, bot = null;
const cleanupBot = async () => { try { if (bot) { bot.quit(); await sleep(800); bot = null; } } catch { /* ignore */ } };

async function main() {
try {
    out.status = 'RUNNING';
    const locus = JSON.parse(fs.readFileSync(LOCUS, 'utf8'));
    out.locusTargets = locus.targets.map((t) => ({ id: t.id, xyz: t.xyz, isChest: t.blockCheck.isChest, spotCount: t.spotCount }));
    out.commonSpot = locus.commonSpotForBothDungeonChests?.best?.[0] ?? null;
    for (const g of GROUPS) if (locus.commonSpotForBothDungeonChests && g.id === 'dungeon_pair') {
        out.locusCrossCheck = `离线几何推荐共同站位 ${JSON.stringify(out.commonSpot?.stand)}，本单用 ${JSON.stringify(g.stand)}`;
    }
    if (out.locusCrossCheck && JSON.stringify(out.commonSpot?.stand) !== JSON.stringify(GROUPS[0].stand)) {
        throw new Error(`LOCUS_MISMATCH：离线共同站位 ${JSON.stringify(out.commonSpot?.stand)} ≠ 脚本用的 ${JSON.stringify(GROUPS[0].stand)}`);
    }
    for (const t of locus.targets) if (!t.blockCheck.isChest) throw new Error(`TARGET_NOT_CHEST：${t.id} @ ${t.xyz.join(',')} 读到 ${t.blockCheck.got}`);

    log(`=== ROUND7-C 续单3 地牢箱实例战利品（seed=${SEED}，peaceful，${expectedChunks} 区块）===`);
    h = await bootLaneC({ seed: SEED, runDir: RUN_DIR, logFn: log });
    const con = h.con;
    const sp = fs.readFileSync(path.join(h.lane.dir, 'server.properties'), 'utf8');
    const levelName = (/level-name=(.*)/.exec(sp)?.[1] ?? 'world').trim();
    out.worldDir = path.join(h.lane.dir, levelName);
    out.bootMs = h.server.bootMs;

    out.difficultyReceipt = await cmdOnce(con, 'difficulty peaceful', /difficulty/i, 20000);
    out.commandsIssued.push('difficulty peaceful');
    log(`  ${out.difficultyReceipt.trim()}`);

    const marked = await cmdOnce(con, `forceload add ${bx0} ${bz0} ${bx1} ${bz1}`, /Marked \d+ chunks?|Too many chunks|already force/i, 60000);
    if (/Too many chunks/i.test(marked)) throw new Error(`FORCELOAD_OVER_256：${marked}`);
    // ⚠ 本单**就要主世界**（下界那份脚本的 `FORCELOAD_WRONG_DIM` 闸门是反的，别照抄）
    if (!/minecraft:overworld/i.test(marked)) throw new Error(`FORCELOAD_WRONG_DIM：本单必须加载主世界，回执却是 ${marked}`);
    out.forceloadReceipt = marked;
    out.commandsIssued.push(`forceload add ${bx0} ${bz0} ${bx1} ${bz1}`);
    log(`  ${marked}`);

    // 就绪闸门：**用 bot 侧 `blockAt` 轮询，不用 `/forceload query`**。
    // ⚠ 本单在 1.16.1 的 `forceload query` 上连踩两次（四角写法 → Incorrect argument；
    //   改列坐标后回的是 `Chunk at [0, 0] …`，与我们标的窗口对不上），两次都白烧一轮起服。
    //   真正要紧的条件只有一个：**bot 自己能不能读到那格方块** —— 直接轮询它。
    out.forceloadSettleMs = 6000;
    await sleep(out.forceloadSettleMs);
    log(`  forceload 回执已收到（${marked.trim()}），静置 ${out.forceloadSettleMs / 1000}s 后交给 bot 侧闸门`);

    // ---- bot 进服 ----
    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE.serverPort, username: LANE.username, version: '1.16.1' });
    const botErrors = [];
    bot.on('error', (e) => botErrors.push(String(e?.message ?? e)));
    bot.on('kicked', (r) => botErrors.push(`kicked: ${JSON.stringify(r)}`));
    await new Promise((res, rej) => { bot.once('spawn', res); bot.once('end', () => rej(new Error(`BOT_ENDED_EARLY：${botErrors.join(' | ')}`))); });
    out.botSpawn = { pos: v3(bot.entity.position), gamemode: bot.game.gameMode, errors: botErrors };
    log(`  bot 进服：${JSON.stringify(out.botSpawn.pos)}`);

    // ⚠ 回执**不匹配不致命**，真正的判据一律取 bot 侧读数（`bot.game` / `bot.inventory` / 实际坐标）。
    //   本单因为回执文案对不上白烧了两次起服（`clear` 在背包本来就空时回的是
    //   `No items were found on player …`）。回执照记进 out，便于事后复核。
    const soft = async (cmd, re) => {
        out.commandsIssued.push(cmd);
        try { return await cmdOnce(con, cmd, re, 20000); }
        catch (e) { return `NO_MATCHED_RECEIPT: ${String(e?.message ?? e).slice(0, 200)}`; }
    };
    out.gamemodeReceipt = await soft(`gamemode creative ${LANE.username}`, /game mode|Set|Unknown/i);
    out.clearReceipt = await soft(`clear ${LANE.username}`, /Removed|No items were found|cleared|has no|Unknown/i);
    await sleep(1200);
    out.botAfterPrep = { gameMode: bot.game.gameMode, heldItem: bot.heldItem ? bot.heldItem.name : null, inventory: bot.inventory.items().map((i) => `${i.name}x${i.count}`) };
    log(`  准备完毕：gameMode=${out.botAfterPrep.gameMode} 手持=${out.botAfterPrep.heldItem} 背包=${JSON.stringify(out.botAfterPrep.inventory)}`);
    // 判据：创造模式（否则后面站在箱子边会被判成生存掉血）+ 空手（否则 activateBlock 变成"放置"）
    // ⚠ `bot.game.gameMode` 回的是**字符串** `'creative'`，不是数字 1（本单先按数字写、白烧一轮起服）
    const gm = out.botAfterPrep.gameMode;
    const isCreative = gm === 1 || String(gm).toLowerCase() === 'creative';
    if (!isCreative) throw new Error(`GAMEMODE_NOT_CREATIVE：bot 侧读到 ${JSON.stringify(gm)}（回执：${out.gamemodeReceipt}）`);
    if (out.botAfterPrep.heldItem !== null) out.warnHeldItem = '⚠ 手上有东西：activateBlock 可能变成"放置"而不是"开箱"';

    for (const g of GROUPS) {
        const [sx, sy, sz] = g.stand;
        const tpLine = await soft(`tp ${LANE.username} ${sx + 0.5} ${sy} ${sz + 0.5}`, /Teleported|moved|Unknown/i);
        // 等 bot 真的收到位置包（**不能只信回执**：回执说 teleported ≠ 客户端已经站过去了）
        let arrived = false, p = null;
        for (let a = 1; a <= 40; a++) {
            p = bot.entity.position;
            if (Math.abs(p.x - (sx + 0.5)) < 0.7 && Math.abs(p.y - sy) < 1.6 && Math.abs(p.z - (sz + 0.5)) < 0.7) { arrived = true; break; }
            await sleep(150);
        }
        if (!arrived) throw new Error(`TP_NOT_ARRIVED：目标 (${sx},${sy},${sz})，bot 实际 ${JSON.stringify(v3(p))}（回执：${tpLine}）`);
        await sleep(900);   // 等区块下发 + 落地
        const grp = { id: g.id, stand: g.stand, tpReceipt: tpLine, botAt: v3(p), chests: [] };
        log(`  ${g.id}：bot 站到 ${JSON.stringify(v3(p))}`);

        for (const id of g.targets) {
            const t = locus.targets.find((x) => x.id === id);
            const [cx, cy, cz] = t.xyz;
            // 客户端就绪闸门：轮询到真的读到 `chest` 为止。
            // ⚠ `blockAt` 在区块未下发时返回 **null**（不抛异常）——手册 §5：
            //   「没读到」必须与「读到非箱子」分开记，否则会把"还没加载"读成"箱子被拆了"。
            let blk = null, waited = 0;
            for (let a = 1; a <= 20; a++) {
                blk = bot.blockAt(new Vec3(cx, cy, cz));
                if (blk) break;
                await sleep(1500); waited += 1500;
            }
            const rec = { id, xyz: t.xyz, lootTable: t.lootTable, lootTableSeed: t.lootTableSeed, blockSeenByBot: blk ? blk.name : null, blockReadWaitMs: waited };
            if (!blk || blk.name !== 'chest') {
                rec.clientResult = 'BLOCK_NOT_CHEST';
                rec.readFailed = !blk;
                rec.error = `bot 读到 ${blk ? blk.name : 'null（区块未加载）'}，期望 chest`;
                grp.chests.push(rec);
                log(`    ✗ ${id}：${rec.error}`);
                continue;
            }
            const t0 = Date.now();
            let win = null;
            try {
                win = await Promise.race([
                    bot.openContainer(blk),
                    sleep(20000).then(() => { throw new Error('OPEN_TIMEOUT_20s（activateBlock 没换回窗口）'); }),
                ]);
            } catch (e) {
                rec.clientResult = 'OPEN_FAILED';
                rec.error = String(e?.message ?? e);
                grp.chests.push(rec);
                log(`    ✗ ${id} 开箱失败：${rec.error}`);
                continue;
            }
            await sleep(400);
            const items = win.containerItems().map((i) => ({ name: i.name, count: i.count }));
            rec.window = { id: win.id, type: win.type, slotCount: win.slots.length, title: win.title };
            rec.items = items;
            rec.itemTotal = items.reduce((a, b) => a + b.count, 0);
            rec.openMs = Date.now() - t0;
            rec.clientResult = 'OK';
            rec.bucket = items.filter((i) => i.name === 'bucket').reduce((a, b) => a + b.count, 0);
            rec.ironIngot = items.filter((i) => i.name === 'iron_ingot').reduce((a, b) => a + b.count, 0);
            rec.ironNugget = items.filter((i) => i.name === 'iron_nugget').reduce((a, b) => a + b.count, 0);
            rec.flint = items.filter((i) => i.name === 'flint').reduce((a, b) => a + b.count, 0);
            rec.flintAndSteel = items.filter((i) => i.name === 'flint_and_steel').reduce((a, b) => a + b.count, 0);
            log(`    ✓ ${id} @(${cx},${cy},${cz})：${rec.itemTotal} 件 ${JSON.stringify(items)}`);
            // 关窗（不发 closeWindow 也行，但留着占着窗口会影响下一个 openContainer）
            try { win.close(); } catch { /* ignore */ }
            await sleep(700);

            // ---- 通道 B：服务器权威 `data get block`（**独立于客户端**） ----
            try {
                out.commandsIssued.push(`data get block ${cx} ${cy} ${cz}`);
                const dline = await cmdOnce(con, `data get block ${cx} ${cy} ${cz}`, /block entity|NBT|Items:|No block/i, 30000);
                rec.serverNbt = dline;
                const parsed = parseServerItems(dline);
                rec.serverItems = parsed ? parsed.items : null;
                rec.serverParseClamped = parsed ? parsed.clamped : null;
                rec.serverBuckets = (rec.serverItems ?? []).filter((i) => i.name === 'bucket').reduce((a, b) => a + b.count, 0);
                rec.serverIronIngot = (rec.serverItems ?? []).filter((i) => i.name === 'iron_ingot').reduce((a, b) => a + b.count, 0);
                rec.crossCheck = crossCheck(rec);
                log(`      通道B data get block：${rec.serverItems ? `${rec.serverItems.length} 种` : '解析失败'} · ${rec.crossCheck?.verdict ?? 'N/A'}`);
            } catch (e) {
                rec.serverNbtError = String(e?.message ?? e);
                rec.crossCheck = { verdict: 'INCONCLUSIVE', why: `data get block 无回执：${rec.serverNbtError}` };
            }
            grp.chests.push(rec);
        }
        out.groups.push(grp);
    }

    out.botErrorsAtEnd = botErrors;
    const saveLine = await cmdOnce(con, 'save-all flush', /Saved the game|Flushing|Saved/i, 300000);
    out.commandsIssued.push('save-all flush');
    out.saveLine = saveLine;
    log(`  ${saveLine}`);
    await sleep(4000);
    await cleanupBot();
    await shutdownLaneC(h); h = null;
    out.status = 'DONE';
    out.savedAt = new Date().toISOString();

    fs.rmSync(DEST, { recursive: true, force: true });
    fs.mkdirSync(DEST, { recursive: true });
    for (const item of ['region', 'level.dat', 'level.dat_old']) {
        const src = path.join(out.worldDir, item);
        if (fs.existsSync(src)) fs.cpSync(src, path.join(DEST, item), { recursive: true });
    }
    out.copiedTo = DEST;
    let saved = 0;
    for (let cx = CX0; cx <= CX1; cx++) for (let cz = CZ0; cz <= CZ1; cz++) {
        const rx = cx >> 5, rz = cz >> 5, idx = (cx - rx * 32) + (cz - rz * 32) * 32;
        const f = path.join(DEST, 'region', `r.${rx}.${rz}.mca`);
        if (!fs.existsSync(f)) continue;
        const b = fs.readFileSync(f);
        if (b.length < 8196) continue;
        if (((b.readUInt8(idx * 4) << 16) | (b.readUInt8(idx * 4 + 1) << 8) | b.readUInt8(idx * 4 + 2)) > 0) saved++;
    }
    out.savedChunksInWindow = saved;
    out.coverageOK = saved === expectedChunks;
    if (!out.coverageOK) out.status = 'DONE_INCOMPLETE_WINDOW';
    log(`  收尾硬闸：窗口内已存区块 ${saved}/${expectedChunks}`);
} catch (e) {
    out.error = String(e?.stack ?? e);
    if (out.status === 'RUNNING') out.status = 'FAILED';
    log(`✗ ${out.status}：${String(e).split('\n')[0]}`);
} finally {
    try { await cleanupBot(); } catch { /* ignore */ }
    try { if (h) await shutdownLaneC(h); } catch { /* ignore */ }
    out.seconds = Math.round((Date.now() - Date.parse(out.startedAt)) / 1000);
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
    log(`落盘：${path.relative(process.cwd(), OUT)}（status=${out.status}，${out.seconds}s）`);
}
}

// ⚠⚠ 主流程**只在直接调用本文件时**跑。少了这一层，别人为了复用判据而 `import` 本模块，
//   就会**顺手起一个服**——本单真的踩了（为了打印一次解析结果 import 一次，白起一服 36s）。
//   与手册 §6①「判定类脚本必须能区分'通过'和'没跑'」同源：**模块的副作用必须由调用方显式触发**。
//   ⚠ 比较用 `fs.realpathSync`，不是 `import.meta.url === argv[1]`（中文路径下恒不相等）。
//   ⚠ `--selftest` / `--reparse` 是**离线模式**，此时绝不能起服（本单踩过一次：
//   `--reparse` 守卫写在主守卫之后 ⇒ 离线重解析顺带又起了一轮服）。
const OFFLINE = process.argv.includes('--selftest') || process.argv.includes('--reparse');
if (!OFFLINE && process.argv[1] && fs.realpathSync(process.argv[1]) === fileURLToPath(import.meta.url)) {
    await main();
}

/**
 * 从 `data get block` 的 SNBT 原文里抠出 Items 列表。⚠ 抠不出来就返回 **null**，**不返回 []**——
 *  "解析失败"和"箱子是空的"必须能分开（手册 §5「没读到 ≠ 没有」）。
 *
 * 1.16.1 **真服 `data get block` 原文**（本单实测，字面照抄）：
 *   `167, 39, 212 has the following block data: {x: 167, y: 39, z: 212, Items: [{Slot: 0b, id: "minecraft:rotten_flesh", Count: 1b}, {Slot: 7b, id: "minecraft:bucket", Count: 1b}], id: "minecraft:chest"}`
 * ⚠⚠ 三个形状事实，本单先错后对：
 *   ① **`Items` 不在字符串末尾**（后面还跟 `, id: "minecraft:chest"}`）
 *      ⇒ 不能用 `Items:\[(.*)\]\}?$` 这种"拉到行尾"的办法；
 *   ② **`id` 在物品的顶层**，不在 `tag` 里（这是 "block data" 表示法，不是原始 NBT）；
 *   ③ 物品之间是 `}, {Slot:`（**逗号后有空格**）。
 */
export function parseServerItems(line) {
    if (!line || typeof line !== 'string') return null;
    // ⚠⚠ 真服原文写的是 **`Items: [`（冒号后有空格）**，不是 `Items:[`。
    //   用 `indexOf('Items:[')` 会返回 -1 ⇒ 一律 null（本单踩过：三个箱子全判 INCONCLUSIVE）。
    const m2 = /Items:\s*\[/.exec(line);
    if (!m2) return null;                              // 这条回执里根本没有 Items
    const open = m2.index + m2[0].length;               // 指向 '[' 的下一位
    // 按**方括号深度**取 Items 数组本身，与它在不在行尾无关
    let depth = 0, end = -1;
    for (let i = open - 1; i < line.length; i++) {
        const c = line[i];
        if (c === '[') depth++;
        else if (c === ']') { depth--; if (depth === 0) { end = i; break; } }
    }
    if (end < 0) return null;                              // 数组没闭合 ⇒ 截断了，不认
    const body = line.slice(open, end);
    if (!body.trim()) return { items: [], clamped: 0 };    // Items:[] = 真的空
    // ⚠ 逐物品用**顶层形状**正则匹配：`{Slot:Nb, id:"…", Count:Mb[, tag:{…}]}`。
    //   嵌套在 `tag` 里的物品（潜影盒的 tag 自带 Items）**不会**命中这条正则 ——
    //   因为它们自己的 `id` 在更深一层的 `tag` 里，`Slot` 后面紧跟的是 `Count`。
    //   （本单先试过"按花括号深度切顶层"，被 tag 里的 `{}` 带偏：深度变负 ⇒ 切分点整体错位。）
    const items = [];
    const re = /\{Slot:\s*(\d+)b,\s*id:\s*"([^"]+)",\s*Count:\s*(\d+)b/g;
    let mm;
    while ((mm = re.exec(body)) !== null) {
        items.push({ slot: +mm[1], count: +mm[3], name: mm[2].replace('minecraft:', '') });
    }
    if (!items.length) {
        // 有 `{` 却一件都没匹配上 ⇒ 形状不认识，**如实 null**（绝不返回空数组冒充"箱子是空的"）
        if (body.includes('{')) return null;
        return null;
    }
    // 一致性闸：数出来的顶层 `{` 必须等于匹配到的件数（差一个就说明正则漏了形状）
    const opens = (body.match(/\{/g) ?? []).length;
    if (opens !== items.length) return { items, clamped: opens - items.length, partial: true };
    return { items, clamped: 0 };
}

/** 两条通道对账：客户端窗口 vs 服务端方块实体 NBT。 */
export function crossCheck(rec) {
    if (!rec.serverItems) return { verdict: 'INCONCLUSIVE', why: 'data get block 的 Items 解析失败（不当作空箱）' };
    const norm = (arr) => arr.map((i) => `${i.name}x${i.count}`).sort();
    const a = norm(rec.items ?? []), b = norm(rec.serverItems);
    const same = a.length === b.length && a.every((v, i) => v === b[i]);
    return { verdict: same ? 'MATCH' : 'MISMATCH', client: a, server: b };
}

/** 判据自检：输入用**真服 1.16.1 原文**做阳性对照（手册 §5「判据的输入格式必须用真服原文对拍」）。 */
export function selftestParse() {
    // ↓↓ S1..S6 的形状全部来自**本单真服回执原文**（`data get block`），不是凭印象编的
    const S1 = '184, 40, 310 has the following block data: {x: 184, y: 40, z: 310, Items: [{Slot: 1b, id: "minecraft:light_weighted_pressure_plate", Count: 1b}, {Slot: 3b, id: "minecraft:flint", Count: 1b}, {Slot: 26b, id: "minecraft:gold_nugget", Count: 2b}], id: "minecraft:chest"}';
    const S2 = '165, 39, 212 has the following block data: {x: 165, y: 39, z: 212, Items: [], id: "minecraft:chest"}';
    const S3 = 'There is no block entity at 1, 2, 3';      // 无 Items ⇒ 必须 null
    const r = [];
    const a = parseServerItems(S1);
    r.push({ id: 'P1 真服原文：Items 不在行尾 + 顶层 id + 槽位/数量逐个读出', pass: a && a.items.length === 3 && a.items[0].name === 'light_weighted_pressure_plate' && a.items[1].name === 'flint' && a.items[1].count === 1 && a.items[2].slot === 26 && a.items[2].count === 2, detail: a });
    const b = parseServerItems(S2);
    r.push({ id: 'P2 Items:[] ⇒ 返回空数组（真空箱），不得返回 null', pass: b && b.items.length === 0, detail: b });
    const c = parseServerItems(S3);
    r.push({ id: 'P3 无方块实体/无 Items ⇒ 返回 null（不得读成空箱）', pass: c === null, detail: c });
    r.push({ id: 'P4 undefined 输入 ⇒ null', pass: parseServerItems(undefined) === null });
    r.push({ id: 'P5 交叉对账：相同 ⇒ MATCH', pass: crossCheck({ items: [{ name: 'flint', count: 3 }], serverItems: [{ name: 'flint', count: 3 }] }).verdict === 'MATCH' });
    r.push({ id: 'P6 交叉对账：数量不同 ⇒ MISMATCH', pass: crossCheck({ items: [{ name: 'flint', count: 3 }], serverItems: [{ name: 'flint', count: 2 }] }).verdict === 'MISMATCH' });
    r.push({ id: 'P7 交叉对账：服务端解析失败 ⇒ INCONCLUSIVE（不判 MISMATCH）', pass: crossCheck({ items: [], serverItems: null }).verdict === 'INCONCLUSIVE' });
    // P8 嵌套花括号（真服 S1 样本原样：带附魔 tag 的金护腿）
    const S4 = '184, 40, 310 has the following block data: {x: 184, y: 40, z: 310, Items: [{Slot: 24b, id: "minecraft:golden_leggings", Count: 1b, tag: {Damage: 0, Enchantments: [{lvl: 2s, id: "minecraft:unbreaking"}]}}, {Slot: 26b, id: "minecraft:gold_nugget", Count: 2b}], id: "minecraft:chest"}';
    const d = parseServerItems(S4);
    r.push({ id: 'P8 嵌套 tag（附魔金护腿）⇒ 切出 2 件，id 不被 tag 串味', pass: d && d.items.length === 2 && d.items[0].name === 'golden_leggings' && d.items[1].name === 'gold_nugget', detail: d });
    // P9 截断的 Items（数组没闭合）⇒ null
    const S5 = '1, 2, 3 has the following block data: {x: 1, y: 2, z: 3, Items: [{Slot: 0b, id: "minecraft:flint", Count: 1b}, {Slot: 1b, id: "minecraft:bucket", Count: 1b';
    r.push({ id: 'P9 Items 数组被截断（没闭合）⇒ null', pass: parseServerItems(S5) === null });
    // P10 同名多槽：逐槽读出，聚合后 flint=3（真服 S1 的 flint 正是 3 个独立槽）
    const S6 = '184, 40, 310 has the following block data: {x: 184, y: 40, z: 310, Items: [{Slot: 3b, id: "minecraft:flint", Count: 1b}, {Slot: 10b, id: "minecraft:flint", Count: 1b}, {Slot: 19b, id: "minecraft:flint", Count: 1b}], id: "minecraft:chest"}';
    const e = parseServerItems(S6);
    r.push({ id: 'P10 同名 3 槽 ⇒ 逐槽读出，聚合 flint=3', pass: e && e.items.length === 3 && e.items.filter((i) => i.name === 'flint').reduce((a, x) => a + x.count, 0) === 3, detail: e });
    return r;
}

/** 离线重解析：用**已存盘的真服 NBT 原文**重跑通道 B 对账（不开服）。
 *  ⚠ 存在的理由：本单第一版解析器把 `Items` 当"行尾字段"，而真服原文里它后面还跟
 *    `, id: "minecraft:chest"}` ⇒ 三个箱子全判 INCONCLUSIVE。**原文已落盘**，
 *    所以修完解析器可以零成本重算，不必再烧一轮起服。 */
function reparse() {
    const j = JSON.parse(fs.readFileSync(OUT, 'utf8'));
    let ok = 0, bad = 0;
    for (const g of j.groups) for (const c of g.chests) {
        const parsed = parseServerItems(c.serverNbt);
        c.serverItems = parsed ? parsed.items : null;
        c.serverParseClamped = parsed ? parsed.clamped : null;
        c.crossCheck = crossCheck(c);
        const v = c.crossCheck.verdict;
        if (v === 'MATCH') ok++; else bad++;
        console.log(`  ${c.id} @(${c.xyz.join(',')})  客户端 ${c.itemTotal} 件 / 通道B ${c.serverItems ? c.serverItems.length : 'null'} 槽 ⇒ ${v}`);
        if (v !== 'MATCH') console.log(`    ${JSON.stringify(c.crossCheck)}`);
    }
    j.reparse = { at: new Date().toISOString(), match: ok, notMatch: bad, note: '用真服 NBT 原文离线重跑通道 B 对账；未重开服' };
    fs.writeFileSync(OUT, JSON.stringify(j, null, 2));
    console.log(`\n重解析：MATCH ${ok} / 非 MATCH ${bad}；已写回 ${path.relative(process.cwd(), OUT)}`);
    process.exit(bad === 0 && ok > 0 ? 0 : 2);
}
if (process.argv.includes('--reparse')) reparse();
