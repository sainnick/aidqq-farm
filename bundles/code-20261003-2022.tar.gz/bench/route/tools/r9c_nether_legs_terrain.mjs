﻿// r9c_nether_legs_terrain.mjs — ROUND9-C 重点：下界三条腿的**地形级**路点
//
// 【与上一单（`v2_nether_legs_corrected.mjs`）的区别】
//   上一单结论是 `NO_NETHER_LEG_COMPUTABLE`，三条原因都可复述：
//     ① S3 作业点被堡垒壁封住，走-only 可达站位格只有 2 个（**当时 BFS 不许挖**）；
//     ② 门落点只在 `_nether_corridor`、S3/C3 在 `_bedhunt`，**两份存档同种子也不一致**（重叠 82,363 格不同）；
//     ③ `probe/_nether_corridor` 窗口按 ÷8 作废坐标选的，根本不覆盖真实走廊。
//   本单三件事各对应一个解法：
//     ① **BFS 加"挖穿"与"搭桥"两种动作**（本文件 `MOVES` + `digThrough` / `bridgeCell`），
//        并把每一处要挖/要搭的格子**逐个列出来** —— 背作业要的就是这个清单。
//     ② **只读一份存档**：`probe/_r9c_nether_corridor`（ROUND9-C 在泳道 C 上 fresh world
//        + 分批 forceload + save-all flush 生成的，1015 区块，零方块改动）。
//     ③ 见 `r9c_nether_corridor_worldgen.mjs` 的窗口说明。
//
// 【口径：站位 = 脚下那格（支撑方块），玩家 Pos.y = stand.y + 1】
//   判据与 `bench/route/lib/stand_criterion.mjs` 共用同一份，**不重抄**。
//   腿的搜索节点用**身体格**（寻路节点就是身体格），与 `exact.stand` 差 +1，这是有意的。
//
// 【门落点】**未验**。1.16.1 的下界门落点由真服开门那一刻决定（`Entity.findPortalDestination`
//   的搜索结果），离线只能**枚举候选**：本文件按"2 宽 × 3 高的黑曜石框 + 框下 2 格黑曜石
//   + 框上 1 格空气"的形状在落点邻域枚举，并把候选逐个写进产物。
//   ⚠ 候选 ≠ 落点。真实落点需真服开一次门看 bot `Pos`（H 线一条命令的事）。
//
// 用法：node tools/r9c_nether_legs_terrain.mjs [--world probe/_r9c_nether_corridor] [--json probe/…]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld, bare } from './region_reader.mjs';
import { judgeStand, AIRLIKE, GROUND_HARD_FAIL, GROUND_WARN, standBodyCells } from '../lib/stand_criterion.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE = path.resolve(HERE, '..');
const argOf = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 ? process.argv[i + 1] : d; };

const WORLD_REL = argOf('world', 'probe/_r9c_nether_corridor');
const WORLD = path.resolve(ROUTE, WORLD_REL);
const OUT = path.resolve(ROUTE, argOf('json', 'probe/v2_nether_legs_terrain.json'));
const DIM = 'the_nether';

/** 端点（**身体格** = 脚所在格）。stand 来自 ROUND9-C 站位回读的结论。 */
const S3_STAND = [331, 56, 238];      // 支撑方块；身体格 = 57
const C3_STAND = [220, 69, -87];      // 支撑方块；身体格 = 70
const S3_BODY = [S3_STAND[0], S3_STAND[1] + 1, S3_STAND[2]];
const C3_BODY = [C3_STAND[0], C3_STAND[1] + 1, C3_STAND[2]];
/** 门落点的搜索中心：主世界门心 (187,41,308) ÷8 ⇒ x≈23 z≈38。y 待枚举。 */
const LANDING_CENTER_X = 23, LANDING_CENTER_Z = 38;
/** 主世界进门点（身体格）—— 只作 notes 里的溯源信息，不参与计算。 */
const S1_PORTAL_OW = [187, 41, 308];

// ---- 地形访问：走 chunk 的 palette，避免逐格 blockAt（33M 次调用会慢到分钟级）
const world = openWorld(WORLD, { dims: ['overworld', 'the_nether', 'the_end'] });
const chunkCache = new Map();
function chunkOf(cx, cz) {
    const k = `${cx}/${cz}`;
    if (chunkCache.has(k)) return chunkCache.get(k);
    const c = world.chunk(cx, cz, DIM);
    chunkCache.set(k, c);
    return c;
}
let unknownHits = 0;
/** 裸名；`unknown` = 读不到（**绝不**当空气）。 */
function at(x, y, z) {
    if (y < 0 || y > 383) return 'out_of_range';
    const cx = x >> 4, cz = z >> 4;
    const c = chunkOf(cx, cz);
    if (!c) { unknownHits++; return 'unknown'; }
    const o = (x - cx * 16) + (z - cz * 16) * 16 + y * 256;
    if (!c.filled[o]) { unknownHits++; return 'unknown'; }
    return c.palette[c.idx[o]]?.name ?? 'unknown';
}
/** 判据：身体格 y 可站？（支撑方块在 y-1） */
function standableBody(x, y, z) {
    return judgeStand(at(x, y - 1, z), at(x, y, z), at(x, y + 1, z)).ok;
}
const isAir = (x, y, z) => AIRLIKE.has(at(x, y, z));
/** 挖不动 / 不能挖穿当通路的东西。 */
const UNDIGGABLE = new Set(['unknown', 'out_of_range', 'bedrock', 'water', 'lava', 'fire', 'soul_fire', 'chest', 'spawner', 'end_portal_frame', 'iron_bars', 'end_portal', 'nether_portal', 'minecraft:air', ...GROUND_HARD_FAIL]);
const diggable = (n) => !UNDIGGABLE.has(n) && !AIRLIKE.has(n);

// ═══════════════════════════════════════════════ 门落点候选枚举
/**
 * ⚠ **v1 的枚举判据是错的，已改**（ROUND9-C 自查时发现）：v1 去找"已经存在的黑曜石门框"，
 *   于是必然枚举到 0 个 —— 下界的门是**服务端现搭的**，落点判据根本不是"那里有 obsidian"。
 *
 * 正确判据 = 1.16.1 `PortalShape.findEmptyOrNotNullPortalDestination`：
 *   · 搜索点 x/z **固定**在 `floorDiv(门心.x, 8)` / `floorDiv(门心.z, 8)`（**不横向搜**）
 *   · y 从 `门心.y` **往下**扫到 `40 - 门心.y`（越往下界越宽，`i > 40 - pos.getY()`）
 *   · `isValidEmptyPortalBlock`：该格是**空气** ∧ 其下是"空气或黑曜石或门"
 *     ∧ 某一侧方向连续 3 格（y、y+1、y+2）都是"空气或黑曜石或门"
 *   · **命中 ≥2 个 y ⇒ 直接返回空**（`if (optional.isPresent()) return absent`）⇒ 不出门。
 * ⚠ 以上是照 1.16.1 逻辑写下来的判据，**尚未在真服上验过落点**（要真服开一次门看 bot `Pos`）。
 */
const isEmptyOrNotNull = (n) => AIRLIKE.has(n) || n === 'obsidian' || n === 'nether_portal';
function landingCandidates(x, z, yStart, dirHint = [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
    const hits = [];
    for (let y = yStart; y > 0 && y > 40 - yStart; y--) {
        if (!isEmptyOrNotNull(at(x, y, z))) continue;
        if (!isEmptyOrNotNull(at(x, y - 1, z))) continue;
        let sideOk = null;
        for (const [ax, az] of dirHint) {
            if (isEmptyOrNotNull(at(x + ax, y, z + az)) && isEmptyOrNotNull(at(x + ax, y + 1, z + az)) && isEmptyOrNotNull(at(x + ax, y + 2, z + az))) { sideOk = [ax, az]; break; }
        }
        if (!sideOk) continue;
        hits.push({ cell: [x, y, z], sideDir: sideOk, standableBody: standableBody(x, y, z), distToS3Body: +Math.hypot(x - S3_BODY[0], z - S3_BODY[2]).toFixed(1) });
    }
    return hits;
}

// ═══════════════════════════════════════════════ 地形 BFS（含挖穿与搭桥）
/**
 * 节点 = **身体格**。动作：
 *   · 4 向水平，dy ∈ {0, +1, -1}（+1 = 迈上一个方块，-1 = 走下一个方块）
 *   · 原地竖直下落 1..4 格（沿途要挖的格数计入 dig）
 *   · **挖穿水平**：目标身体格是实心可挖 ⇒ 挖 1 格后进（记 dig）
 *   · **搭桥水平**：目标身体格与上格是空气、但**脚下是空气**（悬空缺口）且缺口只有 1 格深
 *     ⇒ 在目标脚下放 1 格（记 bridge）
 * 危险格（lava/fire/magma…）永不作为支撑；岩浆格永不作为落点。
 */
const MAX_FALL = 4;
const MAX_TUNNEL = 8;   // 单次挖隧道的最大格数（1 格宽 × 2 格高）
/** 数字键：`key < 2^48`，坐标范围 x/z ±512、y 0..383 内无碰撞。字符串键在 10^5 节点以上会慢到分钟级。 */
const key = (x, y, z) => ((x + 512) * 4194304) + (y + 8) * 1024 + (z + 512);
const unkey = (k) => [Math.floor(k / 4194304) - 512, Math.floor(k / 1024) % 4096 - 8, k % 1024 - 512];

/**
 * A*（不是 BFS）。**为什么必须换**：下界是开放洞穴系统，从 S3 出发的可达区 > 90 万格，
 * BFS 穷举到节点上限（实测 900,000 格 / 58s）都还没碰到 343 格外的 C3，
 * 症状是"算不出来"—— 但那是**预算不够**，不是没路。
 * 启发式 `h = 到目标的欧氏距离`；每步代价 = **推进的格数**（挖隧道 k 格记 k，不是记 1）
 * ⇒ h 可采纳（admissible），A* 找到的仍是最短路。
 */
function bfs(from, to, { maxNodes = 900_000, budgetMs = 150_000, box = null } = {}) {
    const t0 = Date.now();
    const kFrom = key(...from), kTo = key(...to);
    if (kFrom === kTo) return { path: [from], dug: [], bridged: [], nodesSeen: 0 };
    /** 走廊盒限幅。下界是开放洞穴系统，全域可达区 > 900 万格 ⇒ 任何无界搜索都会在预算内"算不出来"，
     *  而**那不是"没路"**。所以按直线两侧 ±BAND 的盒限幅，并把 BAND 写进产物的 `limitations`。 */
    const inBox = box ? (x, y, z) => x >= box.x0 && x <= box.x1 && z >= box.z0 && z <= box.z1 && y >= 0 && y <= 127 : () => true;
    const gScore = new Map([[kFrom, 0]]);
    const prev = new Map();                       // 子 → 父
    const step = new Map();                       // 子 → {kind,dx,dz,k,y}
    // 二叉堆（f, k）
    const hf = [], hk = [];
    const hpush = (f, k) => {
        hf.push(f); hk.push(k);
        let i = hf.length - 1;
        while (i > 0) { const p = (i - 1) >> 1; if (hf[p] <= hf[i]) break; [hf[p], hf[i]] = [hf[i], hf[p]]; [hk[p], hk[i]] = [hk[i], hk[p]]; i = p; }
    };
    const hpop = () => {
        const f = hf[0], k = hk[0];
        const lf = hf.pop(), lk = hk.pop();
        if (hf.length) { hf[0] = lf; hk[0] = lk; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < hf.length && hf[l] < hf[m]) m = l; if (r < hf.length && hf[r] < hf[m]) m = r; if (m === i) break; [hf[m], hf[i]] = [hf[i], hf[m]]; [hk[m], hk[i]] = [hk[i], hk[m]]; i = m; } }
        return [f, k];
    };
    const hx = (x, z) => Math.hypot(x - to[0], z - to[2]);     // 逐维欧氏（y 差算进去更准）
    const heur = (x, y, z) => Math.hypot(x - to[0], y - to[1], z - to[2]);
    let seen = 0, timedOut = false;
    hpush(heur(...from), kFrom);
    const DIRS = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];
    const closed = new Set();
    const relax = (nk, pk, cost, st) => {
        if (closed.has(nk)) return;
        const ng = gScore.get(pk) + cost;
        const old = gScore.get(nk);
        if (old !== undefined && old <= ng) return;
        gScore.set(nk, ng);
        prev.set(nk, pk);
        if (st) step.set(nk, st); else step.delete(nk);
        hpush(ng + heur(...unkey(nk)), nk);
    };
    while (hf.length) {
        const [, k] = hpop();
        if (closed.has(k)) continue;
        closed.add(k); seen++;
        if (seen >= maxNodes) break;
        if ((seen & 1023) === 0 && Date.now() - t0 > budgetMs) { timedOut = true; break; }
        if (k === kTo) break;
        const [x, y, z] = unkey(k);
        const g0 = gScore.get(k);
        /** 判"站得住"并入队。`cleared` = 这些格**已被本步动作清空**，不再要求它们是空气。 */
        const pushStand = (nx, ny, nz, cost, st, cleared) => {
            if (!inBox(nx, ny, nz)) return;
            const okCell = (xx, yy, zz) => (cleared && cleared.has(key(xx, yy, zz))) ? true : AIRLIKE.has(at(xx, yy, zz));
            const g = at(nx, ny - 1, nz);
            if (!okCell(nx, ny, nz)) return;
            if (!okCell(nx, ny + 1, nz)) return;
            if (AIRLIKE.has(g) || GROUND_HARD_FAIL.has(g)) return;
            relax(key(nx, ny, nz), k, cost, st);
        };
        void g0;
        for (const [dx, , dz] of DIRS) {
            // ① 平走 / 上 1 / 下 1
            for (const dy of [0, 1, -1]) pushStand(x + dx, y + dy, z + dz, 1, null, null);
            // ② 挖隧道（1 格宽 × 2 格高，k=1..8）。代价记 k（推进格数），不是 1。
            for (let kk = 1; kk <= MAX_TUNNEL; kk++) {
                const cleared = new Set();
                let footDug = false, ok = true;
                for (let i = 1; i <= kk; i++) {
                    const bx = x + dx * i, bz = z + dz * i;
                    if (!diggable(at(bx, y, bz))) { ok = false; break; }
                    cleared.add(key(bx, y, bz));
                    const fn = at(bx, y - 1, bz);
                    if (!AIRLIKE.has(fn)) {
                        if (!diggable(fn)) { ok = false; break; }
                        cleared.add(key(bx, y - 1, bz));
                        if (i === kk) footDug = true;
                    }
                }
                if (!ok) continue;
                const ex = x + dx * kk, ez = z + dz * kk;
                if (at(ex, y, ez) === 'unknown') continue;
                const st = { kind: 'dig', dx, dz, k: kk, y };
                if (!footDug && AIRLIKE.has(at(ex, y + 1, ez))) pushStand(ex, y, ez, kk, st, cleared);
                if (footDug) {
                    const g2 = at(ex, y - 2, ez);
                    if (!AIRLIKE.has(g2) && !GROUND_HARD_FAIL.has(g2)) pushStand(ex, y - 1, ez, kk, st, cleared);
                }
            }
            // ③ 搭桥：脚下悬空 1 格、缺口底实心
            const nx = x + dx, nz = z + dz;
            if (isAir(nx, y, nz) && isAir(nx, y + 1, nz) && isAir(nx, y - 1, nz) && !AIRLIKE.has(at(nx, y - 2, nz)))
                pushStand(nx, y, nz, 1, { kind: 'bridge', dx, dz, k: 1, y }, null);
        }
        // ④ 竖直下落（含挖穿）
        for (let k2 = 1; k2 <= MAX_FALL; k2++) {
            const ny = y - k2;
            if (isAir(x, y - 1, z) && !isAir(x, ny, z)) {
                const g = at(x, ny - 1, z);
                if (!AIRLIKE.has(g) && !GROUND_HARD_FAIL.has(g)) { pushStand(x, ny, z, k2, null, null); break; }
            }
            if (diggable(at(x, y - k2, z))) {
                const cleared = new Set();
                for (let j = 1; j < k2; j++) cleared.add(key(x, y - j, z));
                const g = at(x, ny - 1, z);
                if (!AIRLIKE.has(g) && !GROUND_HARD_FAIL.has(g)) { pushStand(x, ny, z, k2, { kind: 'digdown', k: k2, y }, cleared); break; }
            }
        }
    }
    if (!closed.has(kTo)) return { fail: true, nodesSeen: seen, timedOut, maxNodes, budgetMs, expanded: closed.size, frontier: hf.length };
    // 回溯，并**重算**每一步的挖/搭清单
    const chain = [];
    for (let k = kTo; ; k = prev.get(k)) { chain.push(k); if (k === kFrom) break; }
    chain.reverse();
    const path_ = chain.map(unkey);
    const dugList = [], bridgeList = [];
    for (let i = 1; i < chain.length; i++) {
        const st = step.get(chain[i]);
        if (!st) continue;
        const [px, py, pz] = unkey(chain[i - 1]);
        if (st.kind === 'dig') {
            for (let j = 1; j <= st.k; j++) {
                dugList.push([px + st.dx * j, py, pz + st.dz * j]);
                const fn = at(px + st.dx * j, py - 1, pz + st.dz * j);
                if (!AIRLIKE.has(fn)) dugList.push([px + st.dx * j, py - 1, pz + st.dz * j]);
            }
        } else if (st.kind === 'digdown') {
            for (let j = 1; j < st.k; j++) dugList.push([px, py - j, pz]);
        } else if (st.kind === 'bridge') {
            bridgeList.push([px + st.dx, py - 1, pz + st.dz]);
        }
    }
    const uniq = (a) => [...new Map(a.map((c) => [key(...c), c])).values()];
    return { path: path_, dug: uniq(dugList), bridged: uniq(bridgeList), nodesSeen: seen, timedOut, expanded: closed.size };
}
/** 抽稀：只保留转角与拐点，并保证相邻 ≤32 格（SCHEMA §5）。 */
function thin(path_, gap = 32) {
    const out = [path_[0]];
    for (let i = 1; i < path_.length - 1; i++) {
        const a = path_[i - 1], b = path_[i], c = path_[i + 1];
        const straight = (p, q, r) => (p[0] - q[0]) * (r[0] - q[0]) + (p[2] - q[2]) * (r[2] - q[2]) === 0 && (p[1] - q[1]) * (r[1] - q[1]) >= 0
            && (p[0] - q[0]) * (r[0] - q[0]) > 0 === ((p[2] - q[2]) * (r[2] - q[2]) > 0);
        if (!straight(a, b, c)) out.push(b);
    }
    if (path_.length > 1) out.push(path_[path_.length - 1]);
    // 再补点保证间隔
    for (let pass = 0; pass < 6; pass++) {
        let over = false;
        for (let i = 1; i < out.length; i++) {
            const a = out[i - 1], b = out[i];
            if (Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]) <= gap) continue;
            over = true;
            const idx = path_.findIndex((p) => key(...p) === key(...b));
            if (idx > 0) out.splice(i, 0, path_[Math.max(1, idx - Math.floor(idx / 2))]);
            else out.splice(i, 0, [Math.round((a[0] + b[0]) / 2), Math.round((a[1] + b[1]) / 2), Math.round((a[2] + b[2]) / 2)]);
            i++;
        }
        if (!over) break;
    }
    return out;
}
/** 路径沿途 3×3 邻域内的危险格（岩浆/岩浆块/火），导航护栏直接用。 */
function hazardsAlong(path_) {
    const set = new Map();
    for (const [x, y, z] of path_) for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) {
        const n = at(x + dx, y + dy, z + dz);
        if (n === 'lava' || n === 'magma_block' || n === 'fire' || n === 'soul_fire') set.set(`${x + dx},${y + dy},${z + dz}`, { xyz: [x + dx, y + dy, z + dz], what: n });
    }
    return [...set.values()];
}

const out = {
    schema: 'aidqq-v2-nether-legs-terrain/1', at: new Date().toISOString(), world: WORLD_REL, dim: DIM,
    endpoints: { S3: { stand: S3_STAND, body: S3_BODY }, C3: { stand: C3_STAND, body: C3_BODY } },
    criteria: {
        stand: '脚下那格（支撑方块）实心非危险 + 身体两格空气；玩家 Pos.y = stand.y+1（与 lib/stand_criterion.mjs 同一份判据）',
        moves: '4 向水平 dy∈{0,+1,-1} + 竖直下落 ≤4 + 挖穿水平 1 格 + 搭桥 1 格（悬空缺口且缺口底实心）',
        cost: '每步 1（挖/搭不额外计权，单独列清单）',
        note: '挖穿/搭桥是"背作业"要的动作清单，不是可选项：真人走到那里必须先挖或先搭。',
    },
    landing: null, legs: [], unavailable: [], evidence: ['bench/route/tools/r9c_nether_legs_terrain.mjs', 'bench/route/tools/r9c_nether_corridor_worldgen.mjs'],
};

if (!fs.existsSync(path.join(WORLD, 'DIM-1', 'region'))) {
    out.verdict = 'NO_CORRIDOR_SAVE';
    out.reason = `走廊存档不存在：${WORLD}（先跑 r9c_nether_corridor_worldgen.mjs 借泳道 C 生成）`;
    console.error(`✗ ${out.reason}`);
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
    process.exit(3);
}

// ---- 阳性对照：地形对照块必须能读出来（手册 §5「扫出全零先证伪工具」）
const control = {};
for (const [x, y, z, label] of [[23, 38, 0, '落点邻域'], [S3_STAND[0], S3_STAND[1], S3_STAND[2], 'S3 支撑方块'], [C3_STAND[0], C3_STAND[1], C3_STAND[2], 'C3 支撑方块']]) {
    control[label] = { xyz: [x, y, z], column: Array.from({ length: 6 }, (_, i) => `${y - 2 + i}:${bare(at(x, y - 2 + i, z))}`).join(' ') };
}
out.positiveControl = {
    ...control,
    s3StandOk: standableBody(S3_BODY[0], S3_BODY[1], S3_BODY[2]),
    c3StandOk: standableBody(C3_BODY[0], C3_BODY[1], C3_BODY[2]),
    unknownHitsDuringControl: unknownHits,
    note: 'S3/C3 的支撑方块必须读回实心 + 身体两格空气；读不到就是通道坏了，不是"没有"。',
};

// ---- 门落点候选
const LANDING_HITS = landingCandidates(LANDING_CENTER_X, LANDING_CENTER_Z, 40);
out.landing = {
    searchPoint: [LANDING_CENTER_X, 'y=40..40-40', LANDING_CENTER_Z],
    yStart: 40, yStopRule: 'i > 40 - yStart ⇒ yStart=40 时扫到 y=1',
    hitCount: LANDING_HITS.length,
    unique: LANDING_HITS.length === 1,
    hits: LANDING_HITS.slice(0, 12),
    verdict: LANDING_HITS.length === 1
        ? '**唯一候选** —— 按 1.16.1 判据服务端会在这里出门（仍需真服开一次门确认）'
        : LANDING_HITS.length === 0
            ? '**零候选** —— 按 1.16.1 判据这个点**不出门**（`findEmptyOrNotNullPortalDestination` 返回空）⇒ **进下界的门点得换/得先清出空间**'
            : `**${LANDING_HITS.length} 个候选 ⇒ 服务端判"多点"直接返回空 ⇒ 不出门**（这正是"进门后掉进岩浆/卡住"的成因）`,
    verified: false,
    why: '判据照 1.16.1 `PortalShape.findEmptyOrNotNullPortalDestination` 写：空气 ∧ 其下空气/黑曜石/门 ∧ 一侧连续 3 格同；命中 ≥2 个 y 直接失败。'
        + '⚠ 判据是照逻辑写的，**落点本身未在真服验过**（需真服开一次门看 bot `Pos`）。',
};
out.landing.positiveControl = { note: '同一份存档里 S3/C3 支撑方块必须读回实心 + 身体两格空气（否则是通道坏了）。', ...out.positiveControl };

function runLeg(id, from, to, extra = {}) {
    const t0 = Date.now();
    const BAND = Number(argOf('band', '64'));
    const box = { x0: Math.min(from[0], to[0]) - BAND, x1: Math.max(from[0], to[0]) + BAND, z0: Math.min(from[2], to[2]) - BAND, z1: Math.max(from[2], to[2]) + BAND };
    const r = bfs(from, to, { box, maxNodes: Number(argOf('max-nodes', '2500000')), budgetMs: Number(argOf('budget-ms', '600000')) });
    if (r.fail) {
        out.unavailable.push({
            leg: id, measuredReason: r.timedOut
                ? `BFS 在预算内没搜到（已搜 ${r.nodesSeen} 格、${(r.ms ?? 0)}；节点上限 ${r.maxNodes}、时间上限 ${r.budgetMs}ms）—— **这是"预算不够"，不是"没路"**`
                : `BFS 走遍可达区仍不连通（已搜 ${r.nodesSeen} 格）—— 地形封堵，**不是"没存档"**`,
            nodesSeen: r.nodesSeen, timedOut: r.timedOut, ...extra,
        });
        console.log(`  ✗ ${id}：${r.timedOut ? '预算内没搜到' : '算不出来'}（${r.nodesSeen} 格，${Date.now() - t0}ms）`);
        return;
    }
    const wp = thin(r.path);
    const hz = hazardsAlong(r.path);
    let maxGap = 0;
    for (let i = 1; i < wp.length; i++) maxGap = Math.max(maxGap, Math.hypot(wp[i][0] - wp[i - 1][0], wp[i][1] - wp[i - 1][1], wp[i][2] - wp[i - 1][2]));
    out.legs.push({
        id, from, to, dim: DIM, evidenceLevel: 'terrain',
        waypoints: wp, maxGap: +maxGap.toFixed(2),
        walkableCells: r.path.length,
        digCells: r.dug, digCount: r.dug.length,
        bridgeCells: r.bridged, bridgeCount: r.bridged.length,
        hazards: hz, hazardCount: hz.length,
        searchBox: box, band: BAND,
        bfsNodesSeen: r.nodesSeen, expanded: r.expanded ?? null, ms: Date.now() - t0, ...extra,
    });
    console.log(`  ✓ ${id}：可走 ${r.path.length} 格 / 路点 ${wp.length} / 挖 ${r.dug.length} 格 / 搭桥 ${r.bridged.length} 格 / 沿途危险格 ${hz.length}（最大间隔 ${maxGap.toFixed(1)}，${Date.now() - t0}ms）`);
}

console.log(`门落点枚举（x=${LANDING_CENTER_X}, z=${LANDING_CENTER_Z}，y=40 往下，1.16.1 判据）：`);
console.log(`  命中 ${LANDING_HITS.length} 个${LANDING_HITS.length === 1 ? '（唯一 ✅）' : `⇒ **按 1.16.1 判据服务端返回空、不出门** ❌`}`);
for (const h of LANDING_HITS.slice(0, 6)) console.log(`    y=${h.cell[1]} side=${JSON.stringify(h.sideDir)} 可站=${h.standableBody} 离 S3 ${h.distToS3Body}`);
out.landing.used = LANDING_HITS.length === 1 ? LANDING_HITS[0].cell : null;

/** 邻域普查：哪些 (x,z) 的列**恰好只有一个**合法 y（可以直接出门）、
 *  哪些有多个（1.16.1 判"多点"⇒ 返回空）、哪些是零。**这是"进门即死/卡住"的可执行判据。** */
function landingNeighborhood(x0, z0, r = 8, yStart = 40) {
    const rows = [];
    for (let x = x0 - r; x <= x0 + r; x++) for (let z = z0 - r; z <= z0 + r; z++) {
        const hits = landingCandidates(x, z, yStart);
        rows.push({ x, z, hitCount: hits.length, hits: hits.map((h) => h.cell[1]), standable: hits.filter((h) => h.standableBody).map((h) => h.cell[1]) });
    }
    return {
        scanned: { center: [x0, z0], r, yStart }, rows,
        uniqueAndStandable: rows.filter((r2) => r2.hitCount === 1 && r2.standable.length === 1),
        multiCandidate: rows.filter((r2) => r2.hitCount > 1).length,
        zeroCandidate: rows.filter((r2) => r2.hitCount === 0).length,
        note: '`hitCount===1 && standable.length===1` 才是"按 1.16.1 判据能出门且站得住"的列。'
            + '`hitCount>1` 的列服务端直接返回空；`hitCount===0` 的列也返回空。',
    };
}
const NB = landingNeighborhood(LANDING_CENTER_X, LANDING_CENTER_Z, 8, 40);
out.landing.neighborhood = {
    ...NB,
    uniqueAndStandable: NB.uniqueAndStandable.slice(0, 20),
    uniqueCount: NB.uniqueAndStandable.length,
};
console.log(`  邻域（±8）普查：唯一且站得住的列 ${NB.uniqueAndStandable.length} 个、多候选列 ${NB.multiCandidate} 个、零候选列 ${NB.zeroCandidate} 个`);
for (const r2 of NB.uniqueAndStandable.slice(0, 6)) console.log(`    ✅ (${r2.x},*,${r2.z}) 唯一 y=${r2.hits[0]}`);

// S3 → C3 与门落点**无关**，永远要算。
runLeg('S3_bastion->C3_fortress_spawner', S3_BODY, C3_BODY, {});

const L = out.landing.used;
if (L) {
    runLeg('S1_portal->S3_bastion', L, S3_BODY, { landingUsed: L, landingVerified: false, portalAt: S1_PORTAL_OW });
    runLeg('C3_fortress_spawner->S1_portal', C3_BODY, L, { landingUsed: L, landingVerified: false });
} else {
    out.unavailable.push({
        leg: 'S1_portal->S3_bastion 与 C3_fortress_spawner->S1_portal',
        measuredReason: `门落点枚举命中 ${LANDING_HITS.length} 个（≠1）⇒ 按 1.16.1 判据这个点**不出门**，两条依赖门落点的腿无法起算`,
        need: '要么换一个进下界的门点（枚举别的 x/z），要么先在 (23,38) 附近清出唯一一处"空气 + 其下空气/黑曜石"',
    });
    console.log('  ✗ 门落点未定 ⇒ S1→S3 与 C3→S1 两条腿算不出来（原因已写进 unavailable）');
}

out.verdict = out.legs.length ? 'LEGS_COMPUTED' : 'NO_NETHER_LEG_COMPUTABLE';
out.unknownHitsTotal = unknownHits;
out.coverageNote = `未知格（存档没覆盖）计数 ${unknownHits}。**这不等于"那里是空气"** —— 若某条腿报不可算，先看这条。`;

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
const back = JSON.parse(fs.readFileSync(OUT, 'utf8'));
if ((back.legs?.length ?? -1) !== out.legs.length) { console.error('✗ 写回读出不一致'); process.exit(1); }
console.log(`\n落盘并读回：${path.relative(process.cwd(), OUT)}（verdict=${out.verdict}，腿 ${out.legs.length}，未知格 ${unknownHits}）`);
