// route_guard_fallback_selftest.mjs — R6-4：route_guard 新增的 **fallback 三处一致性校验**的离线用例
//
// 【为什么单独一个文件】`stages/fullrun/route_selftest.mjs` 是 MC-ROUTE-02 的旧用例（验草稿闸门/
//   冻结态 sha/run 中被改），而 `stages/fullrun/` 现在也是 B 线 fullrun 工具链的目录
//   ⇒ 新增用例另开文件，**不改动别人也在用的旧用例**。
//
// 【要证明什么】SCHEMA §2.1 写的是「三处必须一致，route_guard 应校验」。
//   验收线是**反向**的：**故意弄错其中任意一处，必须报 violation**；弄对时必须 0 violations。
//   （只测"对的通过"是不够的 —— 一个永远返回 0 的校验同样能通过那种测试。）
//
// 用法：& .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\route_guard_fallback_selftest.mjs

import fs from 'fs';
import os from 'os';
import path from 'path';
import { readRouteFile } from '../../stages/fullrun/route_guard.mjs';

let pass = 0, fail = 0;
const A = (n, c, x = '') => { if (c) { pass++; console.log(`  ✔ ${n}`); } else { fail++; console.log(`  ✘ ${n}${x ? ` — ${x}` : ''}`); } };

// ---------------------------------------------------------------- 基准 route（10 站，7 正常 + 3 fallback-only）
function baseDoc() {
    const mk = (id, seq, extra = {}) => ({
        id, seq, kind: 'x', dim: 'overworld',
        station: { center: [0, 0], yHint: 'surface', radius: 32, lookFor: ['stone'] },
        scout: { verify: { status: 'REAL' } },
        fallback: [], ...extra,
    });
    return {
        schema: 'aidqq-route/1', frozenAt: null, sha256File: null,
        stations: [
            mk('S0_iron', 1),
            mk('S0_gravel', 2),
            mk('S0b_village_beds', 3, { fallback: ['S0_sheep'] }),
            mk('S1_portal', 4, { fallback: ['S1b_lava_pool'] }),
            mk('S3_bastion', 5),
            mk('C3_fortress_spawner', 6, { fallback: ['S4_fortress_spawner'] }),
            mk('S5_stronghold_room', 7),
            mk('S0_sheep', 8, { routeRole: 'fallback-only' }),
            mk('S1b_lava_pool', 9, { routeRole: 'fallback-only' }),
            mk('S4_fortress_spawner', 10, { routeRole: 'fallback-only' }),
        ],
        normalFlowStations: ['S0_iron', 'S0_gravel', 'S0b_village_beds', 'S1_portal', 'S3_bastion', 'C3_fortress_spawner', 'S5_stronghold_room'],
        fallbackOnlyStations: [
            { id: 'S0_sheep', seq: 8, fallbackOf: ['S0b_village_beds'] },
            { id: 'S1b_lava_pool', seq: 9, fallbackOf: ['S1_portal'] },
            { id: 'S4_fortress_spawner', seq: 10, fallbackOf: ['C3_fortress_spawner'] },
        ],
    };
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rgs-'));
const FILE = path.join(tmp, 'r.json');
function check(mutate, label) {
    const doc = baseDoc();
    if (mutate) mutate(doc);
    fs.writeFileSync(FILE, JSON.stringify(doc, null, 2));
    const v = readRouteFile(FILE).violations;
    return { v, label };
}
const st = (doc, id) => doc.stations.find((s) => s.id === id);

console.log('T0 基准：正确的 route 必须 0 violations');
{
    const { v } = check(null);
    A('基准 0 violations', v.length === 0, v.join(' | '));
}

console.log('\nT1 故意弄错 → 必须报 violation（每一条都要能被抓到）');
{
    const cases = [
        ['fallback 指向不存在的站', (d) => { st(d, 'S1_portal').fallback = ['NOPE']; }, /fallback 指向不存在的站 NOPE/],
        ['fallback 指向未标 fallback-only 的站（正常流程会顺路去它）', (d) => { st(d, 'S1_portal').fallback = ['S5_stronghold_room']; }, /没有标 routeRole="fallback-only"/],
        ['标了 fallback-only 却没人引用', (d) => { st(d, 'S0_sheep').fallback = []; delete st(d, 'S0b_village_beds').fallback; }, /没有任何站的 fallback 指向它/],
        ['fallbackOnlyStations 漏登记', (d) => { d.fallbackOnlyStations = d.fallbackOnlyStations.filter((x) => x.id !== 'S0_sheep'); }, /没登记进 fallbackOnlyStations/],
        ['normalFlowStations 里出现 fallback-only 站', (d) => { d.normalFlowStations.push('S0_sheep'); }, /normalFlowStations 里出现了 fallback-only 站 S0_sheep/],
        ['normalFlow + fallbackOnly 数量 != stations.length', (d) => { d.normalFlowStations.pop(); }, /!= stations\.length/],
        ['两表并集漏掉一个站', (d) => { d.stations = d.stations.filter((s) => s.id !== 'S3_bastion'); }, /既不在 normalFlowStations 也不在 fallbackOnlyStations|!= stations\.length/],
        ['fallbackOf 记录与实际引用不一致', (d) => { d.fallbackOnlyStations[0].fallbackOf = ['S1_portal']; }, /fallbackOf 记录与实际引用不一致/],
        ['fallbackOnlyStations.seq 与 stations.seq 不一致', (d) => { d.fallbackOnlyStations[0].seq = 99; }, /seq=99 与 stations\.seq=8 不一致/],
        ['routeRole 写成别的值', (d) => { st(d, 'S0_sheep').routeRole = 'optional'; }, /routeRole 只允许/],
        ['fallback 链（fallback-only 站之间互指）', (d) => { st(d, 'S0_sheep').fallback = ['S1b_lava_pool']; }, /会形成 fallback 链/],
        ['有 routeRole 但缺顶层 normalFlowStations', (d) => { delete d.normalFlowStations; }, /顶层缺 normalFlowStations/],
        ['有 routeRole 但缺顶层 fallbackOnlyStations', (d) => { delete d.fallbackOnlyStations; }, /顶层缺 fallbackOnlyStations/],
        ['normalFlowStations 里指向不存在的站', (d) => { d.normalFlowStations.push('GHOST'); d.stations.push({ ...st(d, 'S0_iron'), id: 'X', seq: 11 }); }, /normalFlowStations 里的 GHOST 不存在/],
        // ⚠ 不能只交换两个站的 seq（那不改变 seq 集合，仍连续）；要制造**跳号+重复**才测得到
        ['正常流程的 seq 不连续（编排器按 seq 走）', (d) => { st(d, 'S3_bastion').seq = 8; }, /正常流程站的 seq 应为/],
    ];
    for (const [name, mutate, re] of cases) {
        const { v } = check(mutate, name);
        A(`被抓到：${name}`, v.some((x) => re.test(x)), `实际 violations: ${JSON.stringify(v).slice(0, 180)}`);
    }
}

console.log('\nT2 向后兼容：没有新字段的旧 route 不受影响');
{
    const legacy = { schema: 'aidqq-route/1', frozenAt: null, sha256File: null, stations: baseDoc().stations.slice(0, 8).map((s) => ({ ...s, fallback: [], routeRole: undefined })) };
    for (const s of legacy.stations) delete s.routeRole;
    fs.writeFileSync(FILE, JSON.stringify(legacy, null, 2));
    const v = readRouteFile(FILE).violations;
    A('旧格式（无 routeRole / 无顶层两表）0 violations', v.length === 0, v.join(' | '));
}

console.log('\nT3 真实 route 文件（主种子 10 站）必须 0 violations');
{
    const r = readRouteFile('D:/AI斗蛐蛐/bench/route/4926685115947721762.json');
    A('主种子 0 violations', r.violations.length === 0, r.violations.join(' | '));
}

console.log(`\n${fail === 0 ? '✅' : '❌'} 自检 ${pass} 通过 / ${fail} 失败`);
process.exit(fail === 0 ? 0 : 1);
