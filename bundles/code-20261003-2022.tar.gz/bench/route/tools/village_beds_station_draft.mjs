// village_beds_station_draft.mjs — R6-4：**`village_beds` 站数据草稿**（**不写进 route**，等设计会话裁决）
//
// 【为什么单独一个文件而不是直接 emit】设计会话指令：「若建议新增"村庄床"站，按 SCHEMA 写好站数据草稿
//   （station + scout，kind 用 village_beds），但**不写进 route**，等设计会话裁决。」
//   所以这里只**生成 JSON 草稿**，不碰 bench/route/4926685115947721762.json。
//
// 【数据来源】bench/route/probe/bed_village_survey.round6c.json（±384 格普查，619 个区块）
//
// 【station 字段按 SCHEMA §2 的硬约束构造】
//   - center **必须是 8 格网格上的整数**（route_guard.mjs:49 会逐个校验）
//   - radius ≥ 16（SCHEMA 硬下限）
//   - lookFor 非空（到达确认闸门要用）
//   - 精确坐标**只进 scout**，不进 station

import fs from 'fs';
import path from 'path';
import { argOf, log } from '../../stages/_lib/runner_core.mjs';
import { ROUTE_DIR } from './console.mjs';

const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const SURVEY = readJson(path.join(PROBE_DIR, 'bed_village_survey.round6c.json'));
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const OUT = path.join(PROBE_DIR, 'village_beds.station.draft.json');

const SPAWN = { x: 216, z: 224 };
const S1 = { x: 176, z: 304 };
const align8 = (v) => Math.round(v / 8) * 8;

function readJson(p) { return JSON.parse(fs.readFileSync(p, 'utf8')); }

// ---- 选村：优先"到 S1 最近"，其次"到出生点最近"
const villages = [...SURVEY.villages].sort((a, b) => (a.distToS1 - b.distToS1) || (a.distToSpawn - b.distToSpawn));
const pick = villages[0];
if (!pick) throw new Error('普查里没有村庄，无法起草 station');
if (pick.reachableBeds < 4) {
    log(`⚠ 最近的村庄只有 ${pick.reachableBeds} 张可达床（末影龙要 4 张）⇒ 不建议以它为主站`);
}

const station = {
    id: 'S0b_village_beds',
    seq: null,                                   // 由设计会话定：建议插在 S0_gravel 之后、S1_portal 之前
    kind: 'village_beds',
    dim: 'overworld',
    station: {
        center: [align8(pick.center[0]), align8(pick.center[1])],
        yHint: 'surface',                        // 床在 y68..72，与出生点地表同层（sectionY=4）
        radius: 32,
        lookFor: ['yellow_bed', 'white_bed'],    // 该村实测只有这两种床色
    },
    fallback: [],
    _draft: {
        status: 'DRAFT_NOT_IN_ROUTE',
        note: '**这是草稿，没有写进 route**（设计会话指令：等裁决）。裁决通过后用 `emit` 类脚本并入，'
            + '并把 `seq` 填成实际站序；同时要把 `scout.points` 里的精确坐标留在 scout（SCHEMA §1）。',
        draftedAt: new Date().toISOString(),
        seed: SEED,
    },
};

const scout = {
    points: pick.bedsDetail.map((b) => ({ what: b.name, x: b.pos[0], y: b.pos[1], z: b.pos[2] })),
    pointsTotal: pick.bedsDetail.length,
    pointsTruncated: false,
    verify: {
        status: 'REAL',
        method: '存档解析（region_reader.mjs，只读 .mca）；世界由 worldgen_for_region.mjs 生成并 save-all flush',
        counts: { ...pick.bedColors, hay_block: SURVEY.supply.hay_block, chest: SURVEY.supply.chest, trapped_chest: SURVEY.supply.trapped_chest },
        terrain: { note: '村庄建筑材料以 cobblestone / oak_planks / mossy_cobblestone 为主' },
        at: new Date().toISOString(),
        evidence: 'bench/route/probe/bed_village_survey.round6c.json（±384 格、619 个区块普查）',
        blazeSpawners: null,
    },
    reachability: {
        beds: pick.bedCount,
        reachable: pick.reachableBeds,
        needsDig: pick.needsDig,
        criterion: '每张床判三件事：①正下方一格实心（床在地板上）②床上方 2 格空（站得下）③四个水平邻格里至少 1 个"脚下实心 + 身体两格空"（羊/玩家能站上去的位置）。',
        caveat: '**这是代理判据，不是寻路**：没有计算门、没有计算从村外怎么走。'
            + '但足以区分"完全够不着"和"够得着"。',
        layer: `所有床都在 sectionY=4（y ${pick.yRange[0]}..${pick.yRange[1]}），**与出生点地表同层** ⇒ 不存在"楼上够不着"的问题`
            + '（1.16.1 的羊不会跳上方块，这一层很关键）。',
    },
    supply: {
        hay_block: SURVEY.supply.hay_block,
        chest: SURVEY.supply.chest,
        trapped_chest: SURVEY.supply.trapped_chest,
        note: '**干草块与箱子是食物线索**：干草块可合成面包/ Hay bale 类铺垫，箱子是村庄的主要食物来源之一'
            + '（本区 45 干草 / 13 箱，分布在全部 2 个村庄范围内，不是单村的数）。',
    },
    notes: `床：末影龙要 4 张床做末影之眼。**该村 ${pick.bedCount} 张床全部可达、不需挖墙**，`
        + `到 S1 门 ${pick.distToS1} 格、到出生点 ${pick.distToSpawn} 格（在去 S1 的路上）。`
        + '⚠ 精确坐标只在 scout 区，**不得进 prompt / 模型记忆 / MISSION**；运行区只给 8 格对齐的中心 + radius 32。',
    otherVillages: villages.map((v) => ({
        center: v.center, beds: v.bedCount, reachable: v.reachableBeds, needsDig: v.needsDig,
        distToSpawn: v.distToSpawn, distToS1: v.distToS1, yRange: v.yRange,
    })),
};

const draft = { schema: 'aidqq-route-station-draft/1', station, scout, basedOn: 'bench/route/probe/bed_village_survey.round6c.json' };
fs.writeFileSync(OUT, JSON.stringify(draft, null, 2) + '\n');
log(`✓ 站数据草稿：${path.relative(process.cwd(), OUT)}`);
log(`  id=${station.id} kind=${station.kind} center=${JSON.stringify(station.station.center)} radius=${station.station.radius} lookFor=${JSON.stringify(station.station.lookFor)}`);
log(`  选中村庄 @(${pick.center})：床 ${pick.bedCount} 张（可达 ${pick.reachableBeds}）到 S1 ${pick.distToS1} 格`);
log('  **没有写进 route**（设计会话裁决前不动 bench/route/*.json）');
