// same_bastion_check.mjs — MC-ROUND5 §C 复核指令 2 的**前置判定**：
// 「S3_bastion 站级中心 [288,240]」与「C-2 实测片 [335.5,255.5]」**是不是同一个堡垒遗迹**？
//
// 【为什么必须先判这一步】设计会话要把 S3 的站级中心迁到 C-2 实测片，
//   但明确要求：**不是同一个堡垒就停下报告**。两个中心相距约 50 格，
//   而 ROUTE-02 的 S3 站数据（gold_block 22 / gilded_blackstone 227 / chest 5）
//   与 C-2 的逐格复核数据**数值完全相同** —— 这既可能是"同一片"，
//   也可能是"两片恰好都很大、计数撞车"。不能靠"数字一样"下结论。
//
// 【本脚本只做离线 cubiomes 这一半】零开服、零端口。
//   判据：枚举这一带所有过了 RNG 骰子门的 Bastion 起点（cubiomes `getRegPos`，
//   finders.c:205 区域型放置），看**有没有唯一一个起点**能把两个中心都圈进它的足迹。
//   足迹口径：1.16.1 堡垒遗迹是 jigsaw 拼装，实测外廓在 96–128 格量级；
//   这里用两个阈值分别判（96 严格 / 128 宽松），两个都成立才算"同一个"。
//   ⚠ cubiomes 的 Bastion 起点**不含群系门槛**（viableNote: needsNetherBiome），
//     所以枚举出来的是"过了骰子门的候选"，可能多于真实堡垒 —— 偏保守，不会漏。
//   若这一步有歧义（多个起点都能圈住、或一个都圈不住），本脚本会明确要求**上服务器查连续方块**。

import { candidates, getStructurePos, viableNote } from './cubiomes_struct.mjs';

const SEED = 4926685115947721762n;
const A = { name: 'S3 站级中心(/locate)', x: 288, z: 240 };
const B = { name: 'C-2 实测片中心(逐格复核)', x: 335.5, z: 255.5 };
const RANGE = 320;            // 枚举半径（格）—— 远大于两中心间距
const FOOOT = { strict: 96, loose: 128 };

console.log(`种子 ${SEED} · 两点：A(${A.x},${A.z}) B(${B.x},${B.z}) · 间距 ${Math.hypot(B.x - A.x, B.z - A.z).toFixed(1)} 格`);
console.log(`cubiomes Bastion 门槛说明：${viableNote('Bastion')}`);
console.log('');

const cs = candidates('Bastion', SEED, Math.round((A.x + B.x) / 2), Math.round((A.z + B.z) / 2), RANGE)
    .filter((c) => c.x !== null)
    .sort((p, q) => p.d2 - q.d2);

console.log(`这一带过了 RNG 门的 Bastion 起点共 ${cs.length} 个，最近 6 个：`);
for (const c of cs.slice(0, 6)) {
    const da = Math.hypot(c.x - A.x, c.z - A.z);
    const db = Math.hypot(c.x - B.x, c.z - B.z);
    console.log(`  (${String(c.x).padStart(5)},${String(c.z).padStart(5)})  到 A ${da.toFixed(1).padStart(6)} 格 · 到 B ${db.toFixed(1).padStart(6)} 格`
        + `   ${da <= FOOOT.strict && db <= FOOOT.strict ? '★严格圈内' : da <= FOOOT.loose && db <= FOOOT.loose ? '○宽松圈内' : ''}`);
}

const cover = (r) => cs.filter((c) => Math.hypot(c.x - A.x, c.z - A.z) <= r && Math.hypot(c.x - B.x, c.z - B.z) <= r);
const s = cover(FOOOT.strict), l = cover(FOOOT.loose);
console.log('');
console.log(`严格口径（足迹 ≤${FOOOT.strict} 格）能同时圈住 A、B 的起点：${s.length} 个`
    + (s.length ? ` → ${s.map((c) => `(${c.x},${c.z})`).join('、')}` : ''));
console.log(`宽松口径（足迹 ≤${FOOOT.loose} 格）能同时圈住 A、B 的起点：${l.length} 个`
    + (l.length ? ` → ${l.map((c) => `(${c.x},${c.z})`).join('、')}` : ''));

const verdict = s.length === 1 ? 'SAME_STRICT' : (l.length === 1 ? 'SAME_LOOSE_ONLY' : 'AMBIGUOUS');
console.log('');
console.log(`【离线判定】${verdict}`);
if (verdict === 'SAME_STRICT') {
    const b = s[0];
    console.log(`  ⇒ 两个中心都落在唯一那个 Bastion 起点 (${b.x},${b.z}) 的足迹内（距离 ${Math.hypot(b.x - A.x, b.z - A.z).toFixed(1)} / ${Math.hypot(b.x - B.x, b.z - B.z).toFixed(1)} 格），`);
    console.log('    离线证据支持"同一个堡垒"。建议仍补一条服务器侧连续性确认（两片之间数一下 nether_bricks/gilded_blackstone 是否连成一片），成本很低。');
} else if (verdict === 'SAME_LOOSE_ONLY') {
    console.log('  ⇒ 严格口径不成立、宽松口径唯一。**不能只靠这个下结论**：必须上服务器数"两片之间有没有连续的堡垒方块"，');
    console.log('    数不到就停下报告（按设计会话指令）。');
} else {
    console.log('  ⇒ 离线证据**不足以**判定是同一个堡垒。必须上服务器数连续方块；数不到就停下报告。');
}
console.log('');
console.log('（补充口径提醒：设计会话要求"两片之间有连续的堡垒方块"作为可接受的第二种证据；');
console.log('  cubiomes 的 Bastion 起点是**起点坐标**，不是足迹边界，所以上面的"圈内"只是必要条件、不是充分条件。）');
