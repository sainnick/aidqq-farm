// s3_bastion_worldgen.mjs — ROUND7-C 续单：**easy 难度**的 C2 堡垒存档（只生成，读数全离线）
//
// 【为什么还要起服】盘上已有的 `_world_A` 是 **Difficulty=0（peaceful）**。
//   派单要求「peaceful 与 easy 各一份存档」—— 猪灵在 peaceful 下也生成（F 线已证实），
//   但**生成数量/分布是否与难度无关**不能靠推断，必须实测（§5「超时/缺数据不是证据」）。
//   本单**只发三类命令**：`difficulty easy`（改难度，不碰任何方块）、`forceload add`（生成区块）、
//   `save-all flush`。**不发 fill / summon / setblock** —— 一发就污染世界（ROUTE-02 吃过三次亏）。
//   覆盖率窗口与 peaceful 那份**逐块对齐**（cx14..26 / cz10..22），让两��可逐格对拍。
//
// 【forceload 必须轮询，不能"发完就睡固定时间"】手册 §5：1.16.1 的 forceload 是异步的，
//   区块就绪前发别的命令会回 "That position is not loaded" 并被丢弃。
//   ⇒ 发完轮询 `forceload query`，等回执出现该矩形，再过一个 fill 就绪闸门。
//   单次 `forceload add` 上限 256 区块（手册 §5）⇒ 13×13=169 分两批沿 x 切（91 + 78）。

import fs from 'fs';
import path from 'path';
import { log, argOf } from '../../stages/_lib/runner_core.mjs';
import { bootLaneC, shutdownLaneC, ROUTE_DIR } from './console.mjs';

const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const TAG = argOf(process.argv, 'tag', 'easy');
const DIFFICULTY = argOf(process.argv, 'difficulty', 'easy');
const RUN_DIR = path.join(ROUTE_DIR, 'probe', `_run_round7c_s3`, TAG);
const OUT = path.join(ROUTE_DIR, 'probe', `worldgen_s3_${TAG}.json`);

// 与 peaceful 那份**同一块**窗口：cx 14..26 / cz 10..22 ⇒ blocks x224..431 / z160..367
// ⚠ 这里必须是**扁平**的 [[x0,x1],…]：写成 [[[…]],[[…]]] 时 `for (const [x0,x1] of BATCHES)`
//   解出来 x0=[14,20]、x1=undefined ⇒ 命令变成 `forceload add NaN 160 NaN 367`。
const CX0 = 14, CX1 = 26, CZ0 = 10, CZ1 = 22;
const BATCHES = [[CX0, 20], [21, CX1]];              // 沿 x 切两批：7×13=91 与 6×13=78，各 ≤128 区块

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function cmdOnce(con, cmd, re, timeoutMs = 20000) {
    con.drain();
    con.cmd(cmd);
    const t0 = Date.now();
    const seen = [];
    for (;;) {
        for (const line of con.drain()) { seen.push(line); if (re.test(line)) return line; }
        if (Date.now() - t0 > timeoutMs) throw new Error(`CMD_NO_RECEIPT: ${cmd}（${seen.slice(-2).join(' | ').slice(0, 160)}）`);
        await sleep(50);
    }
}

const out = {
    schema: 'aidqq-round7c-s3-worldgen/1', seed: SEED, tag: TAG, mcVersion: '1.16.1', lane: 'C',
    startedAt: new Date().toISOString(), status: 'NOT_RUN', batches: [], savedAt: null,
    purpose: `S3_bastion 的 ${DIFFICULTY} 难度存档（只生成区块，读数全离线）`,
    window: { chunks: { cx: [CX0, CX1], cz: [CZ0, CZ1] }, blocks: { x: [CX0 * 16, (CX1 + 1) * 16 - 1], z: [CZ0 * 16, (CZ1 + 1) * 16 - 1] } },
    difficultyCommand: null, difficultyQuery: null,
};

let h = null;
try {
    out.status = 'RUNNING';
    log(`=== ROUND7-C S3 堡垒世界生成（tag=${TAG}，difficulty=${DIFFICULTY}）===`);
    h = await bootLaneC({ seed: SEED, runDir: RUN_DIR, logFn: log });
    const con = h.con;
    const sp = fs.readFileSync(path.join(h.lane.dir, 'server.properties'), 'utf8');
    const levelName = (/level-name=(.*)/.exec(sp)?.[1] ?? 'world').trim();
    out.levelName = levelName;
    out.worldDir = path.join(h.lane.dir, levelName);
    out.bootMs = h.server.bootMs;
    out.difficultyInProperties = (/^difficulty=(.*)$/m.exec(sp)?.[1] ?? '?').trim();

    // ---- 改难度（用命令，不改 server.properties 文件；改完回读确认真的生效）
    out.difficultyCommand = await cmdOnce(con, `difficulty ${DIFFICULTY}`, /Set the difficulty|Difficulty/i, 20000);
    await sleep(500);
    out.difficultyQuery = await cmdOnce(con, 'difficulty', /Difficulty is|difficulty/i, 20000);
    log(`  难度：${out.difficultyCommand.trim()} / 回读 ${out.difficultyQuery.trim()}`);

    // ---- 分批 forceload + **轮询** 就绪
    //
    // ⚠⚠ 本文件第一版踩了两个坑，都由回执文本本身指出（记录在此避免再犯）：
    //   ① **回执是复数**：1.16.1 实发 `Marked 91 chunks in ...`（**chunks** 带 s）。
    //      我原来写 `/Marked chunk/`（单数）⇒ 正则不匹配 ⇒ 抛 CMD_NO_RECEIPT，
    //      **而命令其实成功了** —— "超时/无回执"被当成了失败，真值被丢掉（手册 §5：超时不是证据）。
    //   ② **下界必须切维度**：`forceload add` 不带前缀作用在 overworld。`scan.mjs` 的 `dimPre` 没导出，
    //      这里照它的写法内联：`execute in minecraft:the_nether run forceload add …`（**`run` 不能漏**，
    //      漏了回 `Incorrect argument for command`）。
    //   权威就绪判据用 **fill 探针**（回执不能是 "not loaded"），forceload query 只作参考、不当闸门
    //   —— 1.16.1 那句 query 文本随版本变，拿它当闸门就是拿一个正则赌一次成功。
    // ⚠⚠ 迭代的是 `BATCHES`，**不是 `BATCHES[0]`**：写成 `BATCHES[0]` 时只跑了第一批
    //   （91/169 区块），日志里照样打印"SAVED"、`forceload query` 也照样回 91 个 ——
    //   **"成功"与"只做了一半"在这条路径上长得一模一样**。对照 peaceful 存档的 169 块时才发现少了一半。
    for (const [x0, x1] of BATCHES) {
        const bx0 = x0 * 16, bx1 = (x1 + 1) * 16 - 1, bz0 = CZ0 * 16, bz1 = (CZ1 + 1) * 16 - 1;
        const chunks = (x1 - x0 + 1) * (CZ1 - CZ0 + 1);
        const marked = await cmdOnce(con, `execute in minecraft:the_nether run forceload add ${bx0} ${bz0} ${bx1} ${bz1}`,
            /Marked \d+ chunks?|Too many chunks|already force loaded|marked/i, 60000);
        if (/Too many chunks/i.test(marked)) throw new Error(`FORCELOAD_OVER_256：${marked}`);
        if (/minecraft:overworld/i.test(marked)) throw new Error(`FORCELOAD_WRONG_DIM：回执说作用在 overworld：${marked}`);
        log(`  forceload add ${bx0} ${bz0} ${bx1} ${bz1}（${chunks} 区块）→ ${marked}`);

        // 权威就绪闸门：轮询 fill 探针，直到回执不再是 "not loaded"（forceload 是异步的）
        // ⚠ `attempt` 必须声明在循环**外**：第一版写在 `for (let attempt…)` 里，循环结束后
        //   `out.batches.push({attempts: attempt})` 直接 ReferenceError —— 又一个"作用域外引用"。
        let probe = '', q = '', attempt = 0;
        for (attempt = 1; attempt <= 30; attempt++) {
            try {
                q = await cmdOnce(con, 'execute in minecraft:the_nether run forceload query', /chunks|loaded|Specified/i, 20000);
            } catch { q = '(query 无回执，不当闸门)'; }
            probe = await cmdOnce(con,
                `execute in minecraft:the_nether run fill ${bx0} 70 ${bz0} ${bx0} 70 ${bz0} minecraft:barrier replace minecraft:netherrack`,
                /Successfully filled|No blocks were filled|not loaded/i, 60000);
            if (!/not loaded/i.test(probe)) break;
            log(`    第 ${attempt} 次探针仍 not loaded，继续等（forceload 异步）`);
            await sleep(3000);
        }
        if (/not loaded/i.test(probe)) throw new Error(`CHUNK_GATE_NOT_LOADED（30 次轮询后）：${probe}`);
        out.batches.push({ chunks, blocks: `x${bx0}..${bx1} / z${bz0}..${bz1}`, marked: marked.trim(), forceloadQuery: q.trim(), readyProbe: probe, attempts: attempt });
        log(`    就绪（第 ${attempt} 次）：${probe}｜query=${q}`);
    }

    const saveLine = await cmdOnce(con, 'save-all flush', /Saved the game|Flushing|Saved/i, 300000);
    out.saveLine = saveLine;
    log(`  ${saveLine}`);
    await sleep(4000);
    await shutdownLaneC(h); h = null;
    out.status = 'SAVED';
    out.savedAt = new Date().toISOString();

    const dest = path.join(ROUTE_DIR, 'probe', `_s3_${TAG}`);
    fs.rmSync(dest, { recursive: true, force: true });
    fs.mkdirSync(dest, { recursive: true });
    // ⚠ 必须连 overworld 的 `region/` 一起复制：`region_reader.mjs` 的 World 构造器**硬要求**
    //   `region/` 存在，缺了就抛 REGION_DIR_MISSING ⇒ 明明下界数据齐全，分析器却打不开。
    for (const item of ['DIM-1', 'DIM1', 'region', 'level.dat', 'level.dat_old']) {
        const src = path.join(out.worldDir, item);
        if (fs.existsSync(src)) fs.cpSync(src, path.join(dest, item), { recursive: true });
    }
    out.copiedTo = dest;
    out.netherRegionFiles = fs.readdirSync(path.join(dest, 'DIM-1', 'region')).filter((f) => f.endsWith('.mca'));
    log(`  已复制到 ${dest}`);

    // ---- 收尾硬闸：盘上区块数必须**等于**请求的窗口，否则本单作废
    // （"只做了一半"和"做完了"在日志上长得一样，见上面 BATCHES 那条注释）
    const expected = (CX1 - CX0 + 1) * (CZ1 - CZ0 + 1);
    let saved = 0;
    for (let cx = CX0; cx <= CX1; cx++) for (let cz = CZ0; cz <= CZ1; cz++) {
        const rx = cx >> 5, rz = cz >> 5, idx = (cx - rx * 32) + (cz - rz * 32) * 32;
        const f = path.join(dest, 'DIM-1', 'region', `r.${rx}.${rz}.mca`);
        if (!fs.existsSync(f)) continue;
        const b = fs.readFileSync(f);
        if (b.length < 8192 + 4) continue;
        if (((b.readUInt8(idx * 4) << 16) | (b.readUInt8(idx * 4 + 1) << 8) | b.readUInt8(idx * 4 + 2)) > 0) saved++;
    }
    out.savedChunksInWindow = saved;
    out.expectedChunksInWindow = expected;
    out.coverageOK = saved === expected;
    log(`  收尾硬闸：盘上窗口内区块 ${saved}/${expected} ⇒ ${out.coverageOK ? 'OK' : '✗ 覆盖不全，本单作废'}`);
    if (!out.coverageOK) out.status = 'SAVED_INCOMPLETE';
} catch (e) {
    out.error = String(e && e.stack ? e.stack : e);
    if (out.status === 'RUNNING') out.status = 'FAILED';
    log(`✗ ${out.status}：${String(e).split('\n')[0]}`);
} finally {
    try { if (h) await shutdownLaneC(h); } catch { /* ignore */ }
    out.seconds = Math.round((Date.now() - Date.parse(out.startedAt)) / 1000);
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
    log(`落盘：${path.relative(process.cwd(), OUT)}（status=${out.status}，${out.seconds}s）`);
}
