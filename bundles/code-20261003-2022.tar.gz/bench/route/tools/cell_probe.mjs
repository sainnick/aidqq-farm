// cell_probe.mjs — 服务端权威的**逐格方块名**读取（fill 回执通道，非破坏性）
//
// 【踩坑史：本文件被推翻重写过一次，务必先读这段】
//   v1 用的是 `execute if block x y z <候选> run say CELLPROBE …`（靠 say 自标识）。
//   实测 **1.16.1 根本没有 `/say`**（1.17 才加）：每条命令都解析失败，服务器把带
//   `<--[HERE]` 标记的**失败命令回显**打进控制台，而我的解析器按 token/格号去匹配那行回显
//   ⇒ **把"命令失败"读成了"这一格是 air"** ⇒ 主种子框体判定整条作废（obsidian 0/12）。
//   补救测过 `tellraw @a {"text":…}`：命令**能执行**，但**零玩家时控制台不打印任何东西**
//   （tellraw 只发给玩家/广播，不落到服务端控制台）⇒ 同样不可用。
//   结论（已由 cmd_channel_smoke.mjs 实测钉死）：1.16.1 上唯一可靠的"条件真值"通道
//   **就是 `/fill` 的回执**（"Successfully filled N blocks" / "No blocks were filled"）。
//   本文件 v2 因此全部改用 fill，且做成**非破坏性**。
//
// 【非破坏性 2-fill 判据】
//   ① `fill <单格> barrier replace <候选>` → 回执 1 = 该格就是它（此时它已被换成 barrier）
//   ② `fill <单格> <候选> replace barrier`  → 回执 1 = **换回原方块**，世界复原
//   ② 的回执同时是"复原成功"的收据：两层都必须是 1，否则记 `restoreFailed`。
//   （可以只用①，接受"把这一格变成 barrier"，但那会让后续扫描读到假方块，**不要**。）
//
// 【为什么不一次性把 25 个候选都试一遍】
//   帧体那块 4×5×1 的**整片**用 `drill()` 一次扫+下钻更便宜（每种方块 ~19 次 fill）；
//   本文件的逐格判据只用来给"整片扫完仍然没归类"的少数格子兜底。

import { fillCount, MARKER_A } from './scan.mjs';

export { MARKER_A };

/** 1.16.1 里可能占据废弃/下界传送门框格子的方块（末尾必须有 air，否则空格子分不出来） */
export const DEFAULT_CANDIDATES = [
    'minecraft:obsidian',
    'minecraft:crying_obsidian',
    'minecraft:bedrock',
    'minecraft:barrier',
    'minecraft:netherrack',
    'minecraft:nether_brick',
    'minecraft:soul_soil',
    'minecraft:basalt',
    'minecraft:blackstone',
    'minecraft:magma_block',
    'minecraft:lava',
    'minecraft:water',
    'minecraft:stone',
    'minecraft:cobblestone',
    'minecraft:dirt',
    'minecraft:sand',
    'minecraft:gravel',
    'minecraft:chest',
    'minecraft:trapped_chest',
    'minecraft:glass',
    'minecraft:air',            // ← 空格的判据，必须能命中
];

/**
 * 单格的非破坏性判据。返回命中的候选名；没命中返回 null。
 * @returns {Promise<{hit:string|null, tests:number, restoreOk:boolean}>}
 */
export async function probeCell(con, dim, p, candidates = DEFAULT_CANDIDATES) {
    const box = { x1: p.x, y1: p.y, z1: p.z, x2: p.x, y2: p.y, z2: p.z };
    let tests = 0;
    for (const c of candidates) {
        tests++;
        const n = await fillCount(con, dim, box, c, { marker: MARKER_A });
        if (n === 0) continue;
        // 命中了：把原方块还回去。
        // ⚠ 参数别写反：`fill <单格> <候选> replace <marker>` = "把 marker 换回候选"。
        //   写成 `fill <单格> <marker> replace <候选>`（本单踩过）是**再做一遍命中那次**，
        //   方块被永久留在 marker 上 —— 后面所有读数全废（实测主种子 20 格全成 barrier）。
        const back = await fillCount(con, dim, box, c, { marker: MARKER_A, asReplace: true });
        tests++;
        return { hit: c, tests, restoreOk: back === 1 };
    }
    return { hit: null, tests, restoreOk: true };
}

/** 一批格子的逐格判据（顺序尝试候选，命中即停） */
export async function probeCells(con, dim, cells, opt = {}) {
    const candidates = opt.candidates ?? DEFAULT_CANDIDATES;
    const blocks = [];
    const misses = [];
    let tests = 0, restoreFails = 0;
    for (let i = 0; i < cells.length; i++) {
        const r = await probeCell(con, dim, cells[i], candidates);
        tests += r.tests;
        if (!r.restoreOk) restoreFails++;
        blocks[i] = r.hit;
        if (r.hit === null) misses.push({ index: i, pos: [cells[i].x, cells[i].y, cells[i].z] });
    }
    return { blocks, misses, unknown: misses.length, tests, restoreFails, candidates };
}

/** 判一批格子是不是某个**带方块状态**的方块（例如 `minecraft:lava[level=0]` = 源块） */
export async function probeBlockState(con, dim, cells, blockState, opt = {}) {
    const r = await probeCells(con, dim, cells, { ...opt, candidates: [blockState] });
    return {
        hits: r.blocks.map((b, i) => (b === blockState ? { x: cells[i].x, y: cells[i].y, z: cells[i].z } : null)).filter(Boolean),
        misses: r.misses, tests: r.tests, restoreFails: r.restoreFails,
    };
}

/**
 * 能力探测：**1.16.1 的 `/fill … replace <block>` 认不认方块状态**（如 `minecraft:lava[level=0]`）。
 * 判据就是"fill 有没有给出计数回执"——不认方块状态时服务器会报解析错误（没有计数行），
 * `fillCount` 按"回执超时=流不可信"抛错，这里捕获即判不支持。
 * **实测（本轮岩浆站）：支持**，回执 `No blocks were filled` ⇒ 源块可以直接当 target 下钻。
 */
export async function fillSupportsBlockState(con, dim, probeAt = { x: 0, y: 60, z: 0 }) {
    const box = { x1: probeAt.x, y1: probeAt.y, z1: probeAt.z, x2: probeAt.x, y2: probeAt.y, z2: probeAt.z };
    con.drain();
    try {
        const n = await fillCount(con, dim, box, 'minecraft:lava[level=0]', { marker: MARKER_A, timeoutMs: 8000 });
        return { supported: true, evidence: `fill 回执 ${n}（命令被接受即支持）` };
    } catch (e) {
        return { supported: false, evidence: String(e).slice(0, 160) };
    }
}
