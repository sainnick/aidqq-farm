// visibility_audit.mjs — ROUND7-C：**全站"看得见"审计**（只读预勘）
//
// 【为什么做这一单】B 线查出 `findBlocks` **不判遮挡**，到达确认曾经隔墙认出门框（透视）。
//   route 手册 §7 的公平口径白纸黑字：「方块/矿石/实体**只能选看得见、或者有暴露面的**」。
//   ⇒ 光有"这一片有多少块 X"不够：还要逐站回答"**这些 X 有没有面能看见**，
//   以及"看见它的那团空气，bot 走不走得到"。这一单就是补这条判据的**逐站真值**。
//
// 【只读预勘一律走存档解析器】（手册 §5）本文件**只** import `region_reader.mjs` 读 `.mca`，
//   不开服、不发控制台命令、不用 fill-replace（fill-replace 会真实改变世界，手册 §5 明确警告）。
//   借泳道仅用于**生成**缺失区块（`worldgen`），生成完立刻离线读。
//
// 【三条"静默失败"防线，全部来自手册 §5 / §3，本单逐条对位】
//   ① **"没找到"必须判失败，不能等价成"不需要处理"**：本文件在结论里**显式区分**
//      `total==0` 与 `toolFailed`（读到 unknown 导致的 0）。S5 第一次跑出来就是 `unknownCells == cells`
//      —— 那是"没读到"，**不是"没有"**，如果没有这条防线就会把 S5 判成"0 个门框、无需处理"（假阳性）。
//   ② **`unknown` 不许折算成"非空气"以外的任何语义**：判暴露面时，邻格 `unknown`
//      **不算空气**（保守 ⇒ 宁可少报暴露面，不假报"看得见"）；判连通性时 `unknown` 算**墙**（阻断）。
//   ③ **两个世界可比性**：暴露面/连通性只依赖地形本身，不依赖 fill-replace 计数，
//      所以可以用 _bedhunt 这类**纯 worldgen**存档（`readyProbe: "No blocks were filled"`），
//      不受 ROUTE-02 那些"实测石块被换成 bedrock / marker"的污染影响。
//
// 【判据口径（都写在这里，便于审阅逐条驳回）】
//   空气集   AIRLIKE = {air, cave_air, void_air} —— 1.13 起就有的三个方块，1.16.1 全有
//             （route 里 C3 站已把"只认 air"与"三件套"两套口径各跑一遍、结果相同；本单沿用三件套并**同时输出**只认 air 的对照数）
//   暴露面   目标块的 6 个面邻格里**至少 1 个是空气集** ⇒ exposed。
//             床等非整块方块：床占下半个格子、上面那格必然是空气 ⇒ 床天然"至少一面贴空气"，
//             这与真人能看见床一致（"站在床上方能看见"），不算宽松。
//   连通性   从该目标块**所有暴露的空气邻格**出发做 6 连通泛洪（只走空气集）⇒ 连通分量。
//             报三个数：① 分量大小 `compSize` ② 该分量里**有没有任何一格能站人**
//             （脚下实心 + 身体两格空）③ 该分量**有没有一格的整条竖列全是空气**（`sky` ⇒ 通到地表/顶）。
//   站得住   `standSpots > 0` 才叫"bot 站得到"；只有 `compSize` 大但 `standSpots == 0`
//             的分量（典型：2 格高的门框内腔、墙缝）**不算 bot 走得到**。
//
// 【为什么"隔墙看到"要拆成两个子类】B 线那个 bug 的本质是 `findBlocks` 按名字扫区块数据，
//   连**一个面都不贴空气**的方块都会返回 ⇒ 那是字面意义的透视。本单把两种都标出来：
//   - `nameOnly`  完全没暴露面（6 面全实）⇒ 运行时只能靠"名字"发现，**必然是透视**；
//   - `sealed`    有暴露面，但那一面贴的空气在一个 bot 走不到的小/封闭分量里（典型：墙缝、要挖才进得去）。
//
// 用法：
//   node bench/route/tools/visibility_audit.mjs --route bench/route/4926685115947721762.json \
//        --world overworld=<dir> --world the_nether=<dir> [--only S1_portal,C3_fortress_spawner] [--out <json>]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from './region_reader.mjs';

// ---------------------------------------------------------------- 判据常量（审计对象，不是可调旋钮）
/** 1.13 起就有的三个空气方块。cave_air/void_air 在 1.16.1 存在（route 的 C3 站已实证）。 */
export const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);
/** 只认严格 air 的那套口径（做对照用，见文件头"两套口径"）。 */
export const AIR_STRICT = new Set(['air']);
/** 非实心（会阻断"脚下实心"判据的液体）。其余一律按实心处理 —— 保守代理，不是寻路。 */
const NON_SOLID = new Set(['water', 'lava']);

/** 各维度的世界高度（1.16.1）。超出的 y 不存在 ⇒ 记 sky（不是"读不到"）。 */
export const BUILD_HEIGHT = { overworld: 256, the_nether: 128, the_end: 256 };

/** 站位判定：脚下实心 + 身体两格空。 */
function standable(footIsAir, belowSolid, plus1Air, plus2Air) {
    return footIsAir && belowSolid && plus1Air && plus2Air;
}

// ---------------------------------------------------------------- 体素卷（把 get() 的密集读取摊平）
/**
 * 把 `[box]` 读成一个密集卷，后续泛洪/统计全在 typed array 上跑。
 * ⚠ 用 `Int16Array` 存 palette 下标而不是字符串 —— 3M+ 格用字符串数组会 GC 抖动到不可用。
 * ⚠ `filled[i] === 0` 表示**读不到**（`unknown`）。它和"真 air"必须能区分（手册 §5）。
 */
export function loadVolume(get, box) {
    const W = box.x2 - box.x1 + 1, H = box.y2 - box.y1 + 1, D = box.z2 - box.z1 + 1;
    const n = W * H * D;
    const nameId = new Int16Array(n);
    const filled = new Uint8Array(n);
    const nameList = [];                       // nameId -> 名字（含 'unknown'）
    const nameIndex = new Map();
    const intern = (s) => {
        let i = nameIndex.get(s);
        if (i === undefined) { i = nameList.length; nameList.push(s); nameIndex.set(s, i); }
        return i;
    };
    intern('unknown');
    for (let y = box.y1; y <= box.y2; y++)
        for (let z = box.z1; z <= box.z2; z++)
            for (let x = box.x1; x <= box.x2; x++) {
                const o = ((y - box.y1) * D + (z - box.z1)) * W + (x - box.x1);
                const r = get(x, y, z);
                if (r == null || r === 'unknown') { nameId[o] = 0; filled[o] = 0; continue; }
                nameId[o] = intern(r); filled[o] = 1;
            }
    // ⚠ 方法不能写成对象字面量里的箭头函数再互相引用 `vol` —— 字面量自身没有名字（TDZ）。
    //   先造壳、再挂方法。
    const vol = {
        W, H, D, box, nameId, filled, nameList,
        at(x, y, z) {
            if (x < box.x1 || x > box.x2 || y < box.y1 || y > box.y2 || z < box.z1 || z > box.z2) return 0; // 卷外 = 墙
            const o = ((y - box.y1) * D + (z - box.z1)) * W + (x - box.x1);
            return filled[o] ? nameId[o] : 0;
        },
        name(x, y, z) { return nameList[vol.at(x, y, z)]; },
        isAir(x, y, z, set) { const o = vol.at(x, y, z); return o !== 0 && set.has(nameList[o]); },
        solid(x, y, z) { const o = vol.at(x, y, z); return o !== 0 && !NON_SOLID.has(nameList[o]); },
    };
    return vol;
}

// ---------------------------------------------------------------- 6 连通泛洪（只走空气集）
/** @returns {number} 标签数组（0 = 未访问），分量大小 Map */
function labelAirComponents(vol, box, airSet, seeds) {
    const comp = new Int32Array(vol.W * vol.H * vol.D).fill(-1);
    const sizes = new Map();
    const { D, W } = vol;
    const stack = [];
    const off = (x, y, z) => ((y - box.y1) * D + (z - box.z1)) * W + (x - box.x1);
    const inBox = (x, y, z) => x >= box.x1 && x <= box.x2 && y >= box.y1 && y <= box.y2 && z >= box.z1 && z <= box.z2;
    for (const s of seeds) {
        const [sx, sy, sz] = s;
        if (!inBox(sx, sy, sz)) continue;
        const so = off(sx, sy, sz);
        if (comp[so] !== -1) continue;
        if (!vol.isAir(sx, sy, sz, airSet)) continue;      // unknown/非空气 ⇒ 不作为种子
        const id = sizes.size;
        let size = 0;
        stack.length = 0; stack.push(sx, sy, sz); comp[so] = id;
        while (stack.length) {
            const z = stack.pop(), y = stack.pop(), x = stack.pop();
            size++;
            for (let k = 0; k < 6; k++) {
                const nx = x + (k === 0 ? 1 : k === 1 ? -1 : 0);
                const ny = y + (k === 2 ? 1 : k === 3 ? -1 : 0);
                const nz = z + (k === 4 ? 1 : k === 5 ? -1 : 0);
                if (!inBox(nx, ny, nz)) continue;
                const no = off(nx, ny, nz);
                if (comp[no] !== -1) continue;
                if (!vol.isAir(nx, ny, nz, airSet)) continue;
                comp[no] = id; stack.push(nx, ny, nz);
            }
        }
        sizes.set(id, size);
    }
    return { comp, sizes };
}

/** 每个分量：能站人的格数 + 有没有"整列通到顶"的格（sky）。 */
function componentTraits(vol, box, airSet, comp, sizes) {
    const traits = new Map();
    for (const [id] of sizes) traits.set(id, { size: sizes.get(id), standSpots: 0, skyCells: 0, sky: false });
    const { D, W } = vol;
    const off = (x, y, z) => ((y - box.y1) * D + (z - box.z1)) * W + (x - box.x1);
    for (let y = box.y1; y <= box.y2; y++)
        for (let z = box.z1; z <= box.z2; z++)
            for (let x = box.x1; x <= box.x2; x++) {
                const o = off(x, y, z);
                if (comp[o] < 0) continue;
                const t = traits.get(comp[o]);
                if (!vol.isAir(x, y, z, airSet)) continue;
                if (standable(true, vol.solid(x, y - 1, z), vol.isAir(x, y + 1, z, airSet), vol.isAir(x, y + 2, z, airSet))) t.standSpots++;
                // sky：整条竖列直到卷顶都是空气
                let open = true;
                for (let k = y + 1; k <= box.y2; k++) { if (!vol.isAir(x, k, z, airSet)) { open = false; break; } }
                if (open) { t.skyCells++; t.sky = true; }
            }
    return traits;
}

// ---------------------------------------------------------------- 单站审计
export const MIN_EXPOSED = 3;          // 派单给的"暴露块太少"阈值
export const MIN_COMPONENT = 8;        // 空气分量小于此值 ⇒ 视作"墙缝"，bot 走不到
export const MIN_STAND = 1;            // 分量里至少要有 1 个站位

/**
 * @param {object} p
 * @param {(x,y,z)=>string|null} p.get   读方块名（`null`/`'unknown'` = 读不到）
 * @param {[number,number]} p.center      站级中心 XZ
 * @param {number} p.radius               站级 radius
 * @param {string[]} p.lookFor            站级 lookFor
 * @param {string} p.dim
 * @param {number} [p.margin]             泛洪外扩（空气要能流出 radius 才能判连通）
 * @param {string[]} [p.terrainControl]   地形对照方块（手册 §5：读全零要先证伪工具）
 */
export function auditStation(p) {
    const [cx, cz] = p.center;
    const R = p.radius;
    const margin = p.margin ?? 24;
    const yMax = (BUILD_HEIGHT[p.dim] ?? 256) - 1;
    const box = { x1: cx - R - margin, y1: 0, z1: cz - R - margin, x2: cx + R + margin, y2: yMax, z2: cz + R + margin };
    const vol = loadVolume(p.get, box);

    // ---- 盘内（水平圆盘，半径 = 站级 radius）逐格扫描
    const want = p.lookFor.map((s) => s.replace(/^minecraft:/, ''));
    const perType = new Map(want.map((w) => [w, {
        total: 0, exposed: 0, nameOnly: 0, exposedStrict: 0, unknownCells: 0,
        discCells: 0, unknownInDisc: 0, faces: new Map(), samples: [],
    }]));
    const terrain = new Map();
    for (const t of (p.terrainControl ?? [])) terrain.set(t.replace(/^minecraft:/, ''), 0);
    let discCells = 0, unknownInDisc = 0;

    const inDisc = (x, z) => { const dx = x - cx, dz = z - cz; return dx * dx + dz * dz <= R * R; };

    for (let y = box.y1; y <= box.y2; y++)
        for (let z = box.z1; z <= box.z2; z++)
            for (let x = box.x1; x <= box.x2; x++) {
                if (!inDisc(x, z)) continue;
                discCells++;
                const o = ((y - box.y1) * vol.D + (z - box.z1)) * vol.W + (x - box.x1);
                if (!vol.filled[o]) { unknownInDisc++; continue; }
                const nm = vol.nameList[vol.nameId[o]];
                if (terrain.has(nm)) terrain.set(nm, terrain.get(nm) + 1);
                const rec = perType.get(nm);
                if (!rec) continue;
                rec.total++;
                rec.discCells++;
                // 6 面邻格
                const nb = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
                let nAir = 0, nAirStrict = 0;
                for (const [dx, dy, dz] of nb) {
                    const a = vol.at(x + dx, y + dy, z + dz);
                    if (a === 0) continue;                                    // unknown/卷外 ⇒ 不算空气
                    const an = vol.nameList[a];
                    if (AIRLIKE.has(an)) { nAir++; if (AIR_STRICT.has(an)) nAirStrict++; }
                }
                if (nAir > 0) {
                    rec.exposed++; rec.faces.set(nAir, (rec.faces.get(nAir) ?? 0) + 1);
                    rec.samples.push({ xyz: [x, y, z], block: nm, airFaces: nAir });
                } else rec.nameOnly++;
                if (nAirStrict > 0) rec.exposedStrict++;
            }

    // ---- 连通性
    // ⚠ 种子取**卷内全部空气格**（不是只取"贴目标的那些"）：这样"bot 落地的那个空气分量"
    //   也有编号，才能回答"目标所在的分量 == 我落脚的那个分量吗"这个真正要决的问题。
    const allAirSeeds = [];
    for (let y = box.y1; y <= box.y2; y++)
        for (let z = box.z1; z <= box.z2; z++)
            for (let x = box.x1; x <= box.x2; x++)
                if (vol.isAir(x, y, z, AIRLIKE)) allAirSeeds.push([x, y, z]);
    const lab = labelAirComponents(vol, box, AIRLIKE, allAirSeeds);
    const traits = componentTraits(vol, box, AIRLIKE, lab.comp, lab.sizes);

    // ---- bot 的落脚格：站中心那一列**最上面的空气格**（找不到就用盘内离中心最近的空气格）
    let arrival = null;
    for (let y = yMax; y >= 0 && !arrival; y--) if (vol.isAir(cx, y, cz, AIRLIKE)) arrival = [cx, y, cz];
    if (!arrival) {
        outer: for (let y = yMax; y >= 0; y--) for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++)
            if (inDisc(cx + dx, cz + dz) && vol.isAir(cx + dx, y, cz + dz, AIRLIKE)) { arrival = [cx + dx, y, cz + dz]; break outer; }
    }
    const ao = arrival ? ((arrival[1] - box.y1) * vol.D + (arrival[2] - box.z1)) * vol.W + (arrival[0] - box.x1) : -1;
    const arrivalComp = (arrival && lab.comp[ao] >= 0) ? lab.comp[ao] : -1;
    const arrivalTrait = arrivalComp >= 0 ? traits.get(arrivalComp) : null;

    // ---- 汇总
    const types = want.map((w) => {
        const r = perType.get(w);
        // 该类型每个暴露块所属的（最大）分量，以及"是不是 bot 落脚那个分量"
        const comps = [];
        const yHist = new Map();
        let sameAsArrival = 0;
        for (const s of r.samples) {
            const [x, y, z] = s.xyz;
            yHist.set(y, (yHist.get(y) ?? 0) + 1);
            const nb = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
            let best = null, bestId = -1;
            for (const [dx, dy, dz] of nb) {
                const nx = x + dx, ny = y + dy, nz = z + dz;
                if (nx < box.x1 || nx > box.x2 || ny < box.y1 || ny > box.y2 || nz < box.z1 || nz > box.z2) continue;
                const o = ((ny - box.y1) * vol.D + (nz - box.z1)) * vol.W + (nx - box.x1);
                const id = lab.comp[o];
                if (id < 0) continue;
                const t = traits.get(id);
                if (!best || t.size > best.size) { best = { size: t.size, standSpots: t.standSpots, sky: t.sky }; bestId = id; }
            }
            if (bestId === arrivalComp && bestId >= 0) sameAsArrival++;
            comps.push(best ?? { size: 0, standSpots: 0, sky: false });
        }
        const reachable = comps.filter((c) => c.standSpots >= MIN_STAND && (c.size >= MIN_COMPONENT || c.sky));
        return {
            block: w,
            total: r.total, exposed: r.exposed, nameOnly: r.nameOnly,
            exposedStrictAirOnly: r.exposedStrict,
            airFaceHistogram: Object.fromEntries([...r.faces.entries()].sort((a, b) => a[0] - b[0])),
            bestComponent: comps.length ? comps.reduce((a, b) => (b.size > a.size ? b : a), comps[0]) : null,
            reachableCount: reachable.length,
            sameAsArrivalComponent: sameAsArrival,
            exposedYHistogram: Object.fromEntries([...yHist.entries()].sort((a, b) => a[0] - b[0])),
            componentSizes: [...new Set(comps.map((c) => c.size))].sort((a, b) => b - a).slice(0, 8),
            samples: r.samples.slice(0, 6),
        };
    });

    const totalFound = types.reduce((a, t) => a + t.total, 0);
    const maxExposed = types.reduce((a, t) => Math.max(a, t.exposed), 0);
    const maxReachable = types.reduce((a, t) => Math.max(a, t.reachableCount), 0);
    const maxNameOnly = types.reduce((a, t) => Math.max(a, t.nameOnly), 0);

    // ---- 结论（对照派单的三分类）
    // ⚠ 判据顺序有讲究：**先判 OK**（有 ≥3 块"既有暴露面又站得到"），
    //   再判 只能隔墙看到（找到了块、但**一块都走不到** —— nameOnly 或全在墙缝里），
    //   最后才是 暴露块太少（0 < 可达 < 3，或干脆 0 块）。
    //   第一版把 暴露块太少 只挂在 "totalFound==0" 上 ⇒ "找到 2 块地面裸露的沙砾"会掉进
    //   只能隔墙看到 那个兜底分支，报出与事实相反的定性。定性的错比数字的错更难被发现。
    const nameOnlyTotal = types.reduce((a, t) => a + t.nameOnly, 0);
    let verdict, why;
    if (unknownInDisc > 0 && totalFound === 0) {
        verdict = 'INCONCLUSIVE_TOOL_FAILED';
        why = `盘内 ${discCells} 格里有 ${unknownInDisc} 格读不到（unknown），且 lookFor 一块都没读到 —— 这是"没读到"，不是"没有"（手册 §5）。`;
    } else if (maxReachable >= MIN_EXPOSED) {
        verdict = 'OK';
        why = `有 ${maxReachable} 块 lookFor 既有暴露面、其空气分量又有站位（≥${MIN_STAND}），bot 站得到、能看见。`;
    } else if (totalFound === 0) {
        verdict = '暴露块太少';
        why = `盘内（水平半径 ${R}）一种 lookFor 都没读到（且盘内无读不到的格），确实不足 ${MIN_EXPOSED} 块。`;
    } else if (maxReachable === 0) {
        verdict = '只能隔墙看到';
        why = nameOnlyTotal === totalFound
            ? `${totalFound} 块 lookFor **全部 6 面都贴着实体**（0 个暴露面）⇒ findBlocks 按名字仍会返回它们 = 字面透视，违反手册 §7 暴露面判据。`
            : `${totalFound} 块 lookFor 里 ${nameOnlyTotal} 块**完全没暴露面**，其余贴的空气都在 bot 站不到的小/封闭分量里（墙缝/门框内腔）⇒ 到达确认只能隔墙认。`;
    } else {
        verdict = '暴露块太少';
        why = `共 ${totalFound} 块 lookFor，但"既有暴露面 + 空气分量站得到人"的只有 ${maxReachable} 块（<${MIN_EXPOSED}）；另有 ${nameOnlyTotal} 块完全没暴露面。`;
    }

    return {
        station: p.id ?? null, dim: p.dim, center: p.center, radius: R, lookFor: p.lookFor,
        box, yMax,
        verdict, why,
        counts: { totalFound, maxExposed, maxReachable, maxNameOnly, discCells, unknownInDisc },
        arrival: {
            cell: arrival,
            componentSize: arrivalTrait?.size ?? null,
            standSpots: arrivalTrait?.standSpots ?? null,
            sky: arrivalTrait?.sky ?? null,
            note: 'bot 按站级 center 落地后脚下那一格所属的空气分量；`sameAsArrivalComponent` 回答"目标的暴露面和我落脚的空气是不是同一团"',
        },
        toolFailed: unknownInDisc > 0,
        types,
        terrainControl: Object.fromEntries(terrain),
        volume: { cells: vol.W * vol.H * vol.D, distinctNames: vol.nameList.length },
    };
}

// ---------------------------------------------------------------- route 驱动
function argOf(argv, name, dflt) {
    const i = argv.indexOf(`--${name}`);
    return (i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--')) ? argv[i + 1] : dflt;
}

export function run({ routeFile, worlds, only = null, margin = 24 }) {
    const route = JSON.parse(fs.readFileSync(routeFile, 'utf8'));
    const normal = route.normalFlowStations ?? route.stations.map((s) => s.id);
    const byId = new Map(route.stations.map((s) => [s.id, s]));
    const wcache = new Map();
    const openDim = (dim) => {
        const dir = worlds[dim];
        if (!dir) return null;
        if (!wcache.has(dir)) wcache.set(dir, openWorld(dir));
        return wcache.get(dir);
    };
    const results = [];
    for (const id of normal) {
        if (only && !only.includes(id)) continue;
        const st = byId.get(id);
        const w = openDim(st.dim);
        if (!w) { results.push({ station: id, dim: st.dim, verdict: 'INCONCLUSIVE_NO_WORLD', why: `没有传 --world ${st.dim}=<dir>` }); continue; }
        const dim = st.dim;
        // 生产用 get：把"最后一次区块"缓存住，避免每格都拼字符串做 Map key
        let lastKey = null, lastC = null;
        const get = (x, y, z) => {
            const cx = x >> 4, cz = z >> 4;
            const key = cx * 100000 + cz;
            if (key !== lastKey) { lastKey = key; lastC = w.chunk(cx, cz, dim); }
            if (!lastC) return 'unknown';
            const o = (x - cx * 16) + (z - cz * 16) * 16 + y * 256;
            if (y < 0 || y > 383 || !lastC.filled[o]) return 'unknown';
            return lastC.palette[lastC.idx[o]]?.name ?? 'unknown';
        };
        const dimDir = dim === 'overworld' ? null : (dim === 'the_nether' ? 'DIM-1' : 'DIM1');
        const control = dim === 'the_nether' ? ['netherrack', 'blackstone', 'nether_bricks'] : ['stone', 'dirt', 'grass_block', 'water', 'cave_air'];
        const r = auditStation({ id, center: st.station.center, radius: st.station.radius, lookFor: st.station.lookFor, dim, get, margin, terrainControl: control });
        r.routeMeta = { seq: st.seq, kind: st.kind, yHint: st.station.yHint, routeRole: st.routeRole ?? 'normal' };
        r.world = { dir: worlds[dim], dimSubdir: dimDir };
        results.push(r);
    }
    return { schema: 'aidqq-route-visibility-audit/1', seed: route.seed, mcVersion: route.mcVersion, routeFile, frozenAt: route.frozenAt, at: new Date().toISOString(), margin, stations: results };
}

// ⚠ 主模块判定**不能**用 `import.meta.url === 'file:///' + argv[1]`：
//   路径里有中文（`D:\AI斗蛐蛐\`）时 `import.meta.url` 是**百分号编码**的（%E6%96%97…），
//   字符串直接比永远不相等 ⇒ 脚本静默什么都不做、退出码 0（第一版就踩了，0.1s 空跑）。
//   用 fileURLToPath 才拿到真实路径。
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
    const argv = process.argv.slice(2);
    const routeFile = argOf(argv, 'route', 'bench/route/4926685115947721762.json');
    const worlds = {};
    for (let i = 0; i < argv.length; i++) {
        if (argv[i] === '--world') { const m = /^([^=]+)=(.*)$/.exec(argv[i + 1] ?? ''); if (m) worlds[m[1]] = m[2]; }
    }
    const only = argOf(argv, 'only', null)?.split(',').filter(Boolean) ?? null;
    const out = run({ routeFile, worlds, only, margin: parseInt(argOf(argv, 'margin', '24'), 10) });
    const outPath = argOf(argv, 'out', null);
    if (outPath) {
        fs.mkdirSync(path.dirname(outPath), { recursive: true });
        fs.writeFileSync(outPath, JSON.stringify(out, null, 2));
        console.log(`落盘：${outPath}`);
    }
    for (const s of out.stations) {
        const c = s.counts ?? {};
        console.log(`\n[${s.verdict}] ${s.station}  (${s.dim} center=${s.center} r=${s.radius})`);
        console.log(`   ${s.why}`);
        if (s.toolFailed) console.log(`   ⚠ toolFailed=true：盘内 ${c.unknownInDisc}/${c.discCells} 格读不到`);
        for (const t of s.types ?? []) {
            console.log(`   - ${t.block}: total=${t.total} exposed=${t.exposed} nameOnly=${t.nameOnly} 最好分量=${JSON.stringify(t.bestComponent)} 分量大小前几=${JSON.stringify(t.componentSizes)}`);
        }
        if (s.terrainControl) console.log(`   地形对照：${JSON.stringify(s.terrainControl)}`);
    }
    const tally = {};
    for (const s of out.stations) tally[s.verdict] = (tally[s.verdict] ?? 0) + 1;
    console.log(`\n汇总：${JSON.stringify(tally)}`);
}
