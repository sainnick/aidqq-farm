// freeze_route.mjs — R6-4：**route 冻结工具**（默认只演练；`--write` 才落盘）
//
// 【默认行为 = 演练，不落盘】派单要求：「默认只演练——打印将写入的 frozenAt、按 SCHEMA §4 计算的 sha256、
//   将生成的 <seed>.sha256 内容和 handover 记录行，**不落盘**；加 --write 才真正写文件（只由设计会话执行）」。
//   所以本文件**默认不写任何文件**（连 route 都不碰），`--write` 才执行，且那一步设计会话自己来。
//
// 【✅ 口径已统一（2026-10-02 夜设计会话定案，bench 74b1b5d / 73f7456）】
//   上一版这里有**双口径**（`--schema-literal`）：SCHEMA §2 的文字说"除 frozenAt 外"，
//   而消费方 `route_guard` 比的是"整个文件含 frozenAt" ⇒ 按 SCHEMA 文字冻结，guard 必然报
//   ROUTE_HASH_MISMATCH。设计会话已把 SCHEMA §4 升到 v1.1，**统一为整个文件的规范化 sha256**
//   （含 frozenAt 和 sha256File），并要求三处调用**同一个**哈希函数。
//   ⇒ 本工具现在直接 import `routeSha256` / `canonicalRouteText`（来自 route_guard.mjs），
//     **不再自己算、也不再保留 --schema-literal**（双口径本身就是这次要消灭的东西）。
//
// 用法：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\freeze_route.mjs            # 演练
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\freeze_route.mjs --write    # 真正冻结（设计会话执行）

import fs from 'fs';
import path from 'path';
import { argOf, log } from '../../stages/_lib/runner_core.mjs';
import { ROUTE_DIR } from './console.mjs';
import { readRouteFile, routeSha256, canonicalRouteText } from '../../stages/fullrun/route_guard.mjs';

const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const WRITE = process.argv.includes('--write');
const FROZEN_AT = argOf(process.argv, 'frozen-at', new Date().toISOString());
const FILE = path.join(ROUTE_DIR, `${SEED}.json`);
const SIDECAR = `${SEED}.sha256`;

log('==========================================================');
log(`route 冻结${WRITE ? '（--write：会真的写文件）' : '演练（默认，不落盘）'}`);
log('==========================================================');

const r = readRouteFile(FILE);
if (r.violations.length) {
    log(`✗ route_guard 有 ${r.violations.length} 条 violation，**拒绝冻结**：`);
    r.violations.forEach((v) => log(`    · ${v}`));
    process.exit(1);
}
const doc = r.doc;
if (doc.frozenAt) { log(`✗ 已经是冻结态（frozenAt=${doc.frozenAt}）；如需重冻请先手工清空该字段并说明理由。`); process.exit(1); }

const sidecarName = SIDECAR;
// ⚠ 顺序很重要：先定死 `sha256File` 的值（它作为字段名在文件里、但**值**是旁挂文件名），
//   再对**整个文件**算规范哈希。SCHEMA §4 v1.1 明确：哈希含 frozenAt 和 sha256File 两者。
const next = { ...doc, frozenAt: FROZEN_AT, sha256File: sidecarName };
const textCanonical = canonicalRouteText(next);   // 2 空格缩进 + 末尾换行（规范形式）
const hash = routeSha256(next);                   // 与 route_guard 完全同源

log(`文件            bench/route/${SEED}.json`);
log(`站数            ${doc.stations.length}（正常 ${(doc.normalFlowStations ?? []).length} + fallback ${(doc.fallbackOnlyStations ?? []).length}）`);
log(`route_guard     0 violations`);
log('');
log('── 将写入的字段 ──');
log(`  frozenAt     = ${FROZEN_AT}`);
log(`  sha256File   = ${sidecarName}`);
log('');
log('── sha256（SCHEMA §4 v1.1：整个文件的规范化 JSON 哈希，含 frozenAt）──');
log(`  ${hash}`);
log(`  口径          sha256(JSON.stringify(JSON.parse(原文), null, 2) + "\\n")`);
log(`  与 route_guard 同源（routeSha256），freeze 与 guard 不会再对不上。`);
log('');
log(`── 将生成的 ${sidecarName} 内容 ──`);
log(`${hash}  ${SEED}.json`);
log('');
log('── handover 记录行（请设计会话抄进 handover/minecraft.md）──');
log(`> **route 冻结**：种子 \`${SEED}\` · frozenAt \`${FROZEN_AT}\` · sha256 \`${hash}\`（SCHEMA §4 v1.1 规范化口径，含 frozenAt）· 旁挂 \`bench/route/${sidecarName}\` · 审阅人：<填> · 站数 ${doc.stations.length}（正常 ${(doc.normalFlowStations ?? []).length} + fallback ${(doc.fallbackOnlyStations ?? []).length}）`);

if (!WRITE) {
    log('');
    log('演练结束，**没有写任何文件**。真正冻结请加 --write（设计会话执行）。');
    process.exit(0);
}

// ---- --write：真正落盘
fs.writeFileSync(FILE, textCanonical, 'utf8');
fs.writeFileSync(path.join(ROUTE_DIR, sidecarName), `${hash}  ${SEED}.json\n`, 'utf8');
log('');
log(`✓ 已写 bench/route/${SEED}.json 与 bench/route/${sidecarName}`);
