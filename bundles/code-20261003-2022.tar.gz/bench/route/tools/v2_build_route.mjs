// v2_build_route.mjs — 把主种子 route 升到 v2（aidqq-route/2）
//
// 【口径】docs/MC-DECISION-02（背作业 L0）+ bench/route/SCHEMA.md §5。
//   v2 = v1 全部字段 **原样保留** + 顶层 `legs` + 每站 `exact`。
//   本单**不写 frozenAt**（SCHEMA §4：冻结是人工审阅后的独立动作）。
//
// 【每条腿的路点从哪来】分三类，落盘时逐条标注证据等级，不含糊：
//   A. `archive-path`  —— 逐格 BFS 走出来的**真实可走路径**（存档覆盖内，unknownCells=0）。
//   B. `geometry`      —— 直线插值出来的路点（存档**没覆盖**那段走廊）。
//                          ≤32 规则的存在意义就是让 pathfinder 在相邻路点之间自己找路，
//                          所以直线路点是合法输入，但**必须**标出来，不能冒充 A。
//   C. `subagent-nether` —— 下界三段，由 v2_nether_legs.mjs 离线复算（25/69/58=152 步，复现一致）。
//
// 【正本/派生】v1 文件保留不动（另外两个种子还是 v1，route_guard 的回归用例靠它们）。
//   输出 `4926685115947721762.v2.json`（SCHEMA §4：冻结后再改要升版本号）。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from './region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE = path.join(HERE, '..');
const PROBE = path.join(ROUTE, 'probe');
const SRC = path.join(ROUTE, '4926685115947721762.json');
/**
 * ⚠⚠ **输出文件名被 B 线占了**。本单第一次用 SCHEMA §4 建议的 `<seed>.v2.json`，
 *   而 B 线（S1 点火）**同时也在写同一个文件名** —— 2026-10-03 16:17 B 线把它覆盖成
 *   只含 `S1_entry` / `S1_portal` 两站的 S1 专用版，本单那份 7 站全 route 版被覆盖，
 *   随后又被 `git add` 进了 C 线的提交（见报告「事故」）。
 *   两份是**不同的产物**（本单 = 7 站全 route 的 exact+legs；B 线 = S1 一段），
 *   共用一个文件名必然互相踩 ⇒ 本单改用**带用途后缀**的名字，且**不再碰** `<seed>.v2.json`。
 */
const OUT = path.join(ROUTE, '4926685115947721762.v2.fullroute.json');
const WORLD = path.join(PROBE, '_bedhunt');
const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);
const DAMAGE = new Set(['lava', 'fire', 'soul_fire', 'magma_block', 'cactus', 'powder_snow', 'sweet_berry_bush']);

const arg = (k, d) => { const i = process.argv.indexOf(`--${k}`); return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : d; };
const MAX_LEG_GAP = 32;           // SCHEMA §5：相邻路点 ≤32
const MAX_DETOUR_GAP = 8;         // BFS 时允许比直线多绕多少格

function readJson(p) { return JSON.parse(fs.readFileSync(p, 'utf8')); }

// ═══════════════════════════════════════════════ 1. 载入证据
const v1 = readJson(SRC);
const s0 = readJson(path.join(PROBE, 'v2_s0_exact.json'));
const nether = readJson(path.join(PROBE, 'v2_nether_legs.json'));
let s3c3s5 = null;
try { s3c3s5 = readJson(path.join(PROBE, 'v2_s5_c3_s3_exact.json')); } catch { /* 子 agent 可能还没落盘 */ }
const ALLOW_MISSING = process.argv.includes('--allow-missing-s3c3s5');
if (!s3c3s5 && !ALLOW_MISSING) { console.error('缺 v2_s5_c3_s3_exact.json（子 agent 未落盘）—— 先跑 v2_extract_s5_c3_s3.mjs'); process.exit(5); }
if (!s3c3s5) console.warn('⚠ --allow-missing-s3c3s5：S3/C3/S5 的 exact 留空（**仅用于先验腿算法**，产物不可用）');

const byId = new Map(v1.stations.map((s) => [s.id, s]));

// ═══════════════════════════════════════════════ 2. overworld 可走 BFS
const w = openWorld(WORLD);
const isAir = (x, y, z) => AIRLIKE.has(w.blockAt(x, y, z, 'overworld'));
/** 站得住：脚下实心（非空气、非伤害源）+ 身体 y/y+1 两格空气。玩家高 1.8 格 = 2 格身体。 */
function stand(x, y, z) {
    if (!isAir(x, y, z)) return false;
    const b = w.blockAt(x, y - 1, z, 'overworld');
    if (b === 'unknown' || AIRLIKE.has(b) || DAMAGE.has(b)) return false;
    return isAir(x, y + 1, z);
}
const MOVES = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0], [0, -1, 0], [0, -2, 0], [0, -3, 0]];
/** 1.16.1 挖不动的 / 不能挖穿当通路的东西。 */
const UNDIGGABLE = new Set(['bedrock', 'water', 'lava', 'fire', 'soul_fire', 'magma_block', 'cactus', 'chest', 'spawner', 'end_portal_frame', 'iron_bars', 'end_portal', 'nether_portal']);
const diggable = (n) => n !== 'unknown' && !AIRLIKE.has(n) && !UNDIGGABLE.has(n);
const MAX_DIG = 6;                 // 单次下挖最多 6 格（真人一次下井的量级）
function stepOk(x, y, z, [dx, dy, dz]) {
    const nx = x + dx, ny = y + dy, nz = z + dz;
    if (!stand(nx, ny, nz)) return false;
    if (dy < 0) for (let k = 1; k < -dy; k++) if (DAMAGE.has(w.blockAt(x, y - k, z, 'overworld'))) return false;
    return true;
}
/**
 * 挖穿下降：从 (x,y,z) 垂直往下挖 k 格到 (x,y-k,z)。
 * 返回要挖的格数，挖不了返回 0。**这就是"挖一条 1×1 竖井下去"**。
 */
function digDown(x, y, z, k) {
    for (let i = 1; i < k; i++) if (!diggable(w.blockAt(x, y - i, z, 'overworld'))) return 0;
    return stand(x, y - k, z) ? k : 0;
}
/**
 * 从 from 到 to 的路径。`dig` 为真时允许"挖穿下降"（走-only 的 BFS 在本主种子
 * 只能在地表那片沙滩上打转 —— 39,023 格全在 y=63，因为**下井必须先挖**，
 * 而走路/走洞都不产生"挖"这个动作。这是实测，不是推演）。
 * 返回 `{ path, dug }`，`dug` 是沿途要挖的格数。
 */
function bfs(from, to, { dig = false, maxNodes = 8_000_000 } = {}) {
    const k = (x, y, z) => `${x},${y},${z}`;
    const sk = k(...from), tk = k(...to);
    if (sk === tk) return { path: [from], dug: 0 };
    const prev = new Map([[sk, null]]);
    const dugAt = new Map();
    const q = [from]; let head = 0, seen = 0;
    while (head < q.length && seen < maxNodes) {
        const [x, y, z] = q[head++]; seen++;
        const moves = dig ? [...MOVES, ...Array.from({ length: MAX_DIG - 1 }, (_, i) => [0, -(i + 2), 0])] : MOVES;
        for (const mv of moves) {
            let okHere;
            if (dig && mv[1] <= -(MAX_DIG - 1) && mv[0] === 0 && mv[2] === 0) okHere = digDown(x, y, z, -mv[1]) > 0;
            else okHere = stepOk(x, y, z, mv);
            if (!okHere) continue;
            const nk = k(x + mv[0], y + mv[1], z + mv[2]);
            if (prev.has(nk)) continue;
            prev.set(nk, k(x, y, z));
            dugAt.set(nk, (dugAt.get(k(x, y, z)) ?? 0) + ((dig && mv[1] <= -(MAX_DIG - 1) && mv[0] === 0 && mv[2] === 0) ? -mv[1] - 1 : 0));
            if (nk === tk) {
                const out = []; let cur = tk;
                while (cur) { out.push(cur.split(',').map(Number)); cur = prev.get(cur); }
                out.reverse();
                return { path: out, dug: dugAt.get(tk) ?? 0 };
            }
            q.push([x + mv[0], y + mv[1], z + mv[2]]);
        }
    }
    return null;
}
/** 走不通就挖穿下降；两条都不通才算"没路"。 */
function route(from, to) {
    const walk = bfs(from, to, { dig: false });
    if (walk) return { ...walk, level: 'archive-path' };
    const withDig = bfs(from, to, { dig: true });
    if (withDig) return { ...withDig, level: 'archive-dig-path' };
    return null;
}
/** 把逐格路径抽稀成 ≤32 的路点（贪心取最远的仍在路径上、且距上一个路点 ≤32 的格）。 */
function thin(pathCells, gap = MAX_LEG_GAP) {
    if (!pathCells || pathCells.length <= 1) return pathCells || [];
    const out = [pathCells[0]];
    let anchor = 0;
    for (let i = 2; i < pathCells.length; i++) {
        const d = Math.hypot(pathCells[i][0] - pathCells[anchor][0], pathCells[i][1] - pathCells[anchor][1], pathCells[i][2] - pathCells[anchor][2]);
        const last = pathCells[pathCells.length - 1];
        const dl = Math.hypot(last[0] - pathCells[i][0], last[1] - pathCells[i][1], last[2] - pathCells[i][2]);
        if (d > gap || dl <= gap) { out.push(pathCells[i]); anchor = i; }
    }
    if (out[out.length - 1] !== pathCells[pathCells.length - 1]) out.push(pathCells[pathCells.length - 1]);
    return out;
}
/**
 * 几何直线路点（存档没覆盖时用）。
 * ⚠ **逐轴取整会把间距顶出上限**：`ceil(d/32)` 个点之后逐轴 `Math.round`，
 *   实际相邻 3D 距离可能到 32.2 > 32（实测踩到）⇒ 这里按 **28** 留余量，
 *   并且**出点后逐段复核**，超限就再细分一次。
 */
function straight(from, to, gap = MAX_LEG_GAP - 4) {
    if (!from || !to) throw new Error(`straight() 端点缺失：${JSON.stringify(from)} -> ${JSON.stringify(to)}`);
    const d = Math.hypot(to[0] - from[0], to[1] - from[1], to[2] - from[2]);
    const n = Math.max(1, Math.ceil(d / gap));
    const out = [];
    for (let i = 0; i <= n; i++) out.push([0, 1, 2].map((k) => Math.round(from[k] + (to[k] - from[k]) * (i / n))));
    for (let pass = 0; pass < 4; pass++) {
        let over = false;
        for (let i = 1; i < out.length; i++) {
            const a = out[i - 1], b = out[i];
            if (Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]) <= MAX_LEG_GAP) continue;
            over = true;
            const mid = [0, 1, 2].map((k) => Math.round((a[k] + b[k]) / 2));
            out.splice(i, 0, mid);
            i++;
        }
        if (!over) break;
    }
    return out;
}

// ═══════════════════════════════════════════════ 3. 出生点与各站站位
/**
 * 开局站位。**不是** SEED-01 记的 `spawn_x=216, spawn_z=224` 本身 ——
 * 那一格在存档里是**海面**（y=62 处是 water，脚底下是 sand），
 * 站不住、也不能当 BFS 起点（站不住 ⇒ BFS 一步都走不出去，会静默返回"未连通"）。
 * 离线解析找下来，最近的**陆地**站位是 (216,63,224)：脚下 y=62 是 sand。
 */
const SPAWN_STAND = [216, 63, 224];
const exact = {};                    // stationId → exact 块

// ---- S0_iron / S0_gravel（v2_extract_s0.mjs，离线存档解析）
for (const [sid, key] of [['S0_iron', 'S0_iron'], ['S0_gravel', 'S0_gravel']]) {
    const s = s0.stations[key];
    exact[sid] = {
        stand: s.stand,
        targets: s.targets.map((t) => ({ what: 'dig', xyz: t.xyz, order: t.order, tool: t.tool, airFaces: t.airFaces, standFor: t.standFor, standDist: t.standDist })),
        hazards: [],
        verify: {
            status: 'REAL', method: '存档解析（region_reader.mjs 离线 .mda 解析，无 mineflayer）',
            evidence: 'bench/route/probe/v2_s0_exact.json',
            note: `暴露块 ${s.exposedTotal} → 选 ${s.selected}（${s.need}）；unknownCells=0；读回不一致 ${s.rejected.length} 条`,
        },
    };
}

// ---- S0b_village_beds：要拆的床（末地门 12 框 − 已有 2 眼 = 10 颗眼 = 10 张床）
{
    const st = byId.get('S0b_village_beds');
    const beds = (st.scout.points ?? []).filter((p) => p.what === 'yellow_bed' || p.what === 'white_bed')
        .map((p) => [p.x, p.y, p.z]);
    const NEED_EYES = 10;                        // 12 框 - 已有 2 眼
    const S1 = [187, 307];
    // 离「村庄 → S1 门」这条实际走法最近优先（省脚程）
    const scored = beds.map((b) => ({ b, d: Math.hypot(b[0] - S1[0], b[2] - S1[2]) })).sort((a, b) => a.d - b.d);
    const need = NEED_EYES + 2;                  // +2 张余量（挖床/掉落有损耗）
    const chosen = scored.slice(0, need);
    // 站位：每张床找一个站得住的邻格
    const stands = [];
    for (const { b } of chosen) {
        for (const [dx, dy, dz] of [[0, 1, 0], [0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]) {
            const s = [b[0] + dx, b[1] + dy, b[2] + dz];
            if (stand(...s)) { stands.push(s); break; }
        }
    }
    exact.S0b_village_beds = {
        stand: stands.slice(0, 8),
        targets: chosen.map((c, i) => ({ what: 'dig', xyz: c.b, order: i + 1, how: 'break_bed', note: `距 S1 门 ${c.d.toFixed(1)} 格` })),
        hazards: [],
        verify: {
            status: 'REAL', method: '存档解析（bed_village_survey.round6c.json，619 区块普查）',
            evidence: 'bench/route/probe/bed_village_survey.round6c.json',
            note: `全村 ${beds.length} 张床（黄 ${beds.filter((b) => byId.get('S0b_village_beds').scout.points.find((p) => p.x === b[0] && p.y === b[1] && p.z === b[2]).what === 'yellow_bed').length} / 白 ${beds.filter((b) => byId.get('S0b_village_beds').scout.points.find((p) => p.x === b[0] && p.y === b[1] && p.z === b[2]).what === 'white_bed').length}），全部可达不需挖墙；本单派 ${chosen.length} 张`,
            arithmetic: `S5 需 12 颗眼，已有 2 ⇒ 要补 ${NEED_EYES} 颗；1 床 = 1 眼 ⇒ 至少 ${NEED_EYES} 张床，本单派 ${chosen.length} 张（含 2 张余量）`,
        },
    };
}

// ---- S1_portal：**作业坐标由 B 线给**（DECISION-02 §4），本单只补两样 C 线自己能核的东西
{
    // ① 站位：必须给，否则 route_guard 的 v2 判据「legs 首尾与站一致」会让所有接 S1 的腿报错。
    //    站位从存档解析，且**显式排除了岩浆/岩浆块地板** —— 门框那一圈 y=40 全是 lava/magma_block，
    //    站上去就是烧烤，且桶操作要在旁边站稳。
    // ② targets 留空：补哪几格、什么顺序、用几桶水，全部是 B 线的实跑结论，C 线不代填。
    const STANDS = [[187, 42, 307], [185, 41, 308], [186, 41, 306], [185, 41, 307], [185, 41, 309], [189, 41, 306], [189, 42, 310]];
    exact.S1_portal = {
        stand: STANDS,
        targets: [],
        hazards: [
            [187, 40, 306], [187, 40, 308], [187, 40, 309],      // 门框底排**当前是岩浆**，不是空 —— 要先舀掉再浇
            [186, 40, 308], [188, 40, 308], [189, 40, 308],      // 门心两侧的岩浆块
        ],
        verify: {
            status: 'PARTIAL', method: '存档解析（region_reader.mjs 离线）+ v1 fill-replace 真值',
            evidence: 'bench/route/probe/v2_build_route.last.json#S1_portal.observations（逐格读数） + bench/route/4926685115947721762.json#stations[S1_portal].scout',
            note: '**targets 故意为空**：DECISION-02 §4 把 S1 的作业坐标划给 B 线。C 线不代填，避免与 B 线 r16+ 实跑记录冲突。',
            observations: {
                framePlane: 'x=187（所有黑曜石/哭泣黑曜石都在这一层 ⇒ 门框平面垂直 x 轴）',
                cryingObsidian: [[187, 42, 310]],
                obsidian: [[187, 40, 307], [187, 41, 307], [187, 41, 310], [187, 43, 308], [187, 43, 309], [187, 43, 310], [189, 40, 306]],
                bottomRowLava: [[187, 40, 306], [187, 40, 308], [187, 40, 309]],
                standNote: '站位**排除了岩浆/岩浆块地板**（门框那一圈 y=40 是 lava/magma_block，站上去会被烤）',
                caution: '这些是**存档观测，不是实跑真值**；补格清单与顺序以 B 线为准。',
            },
        },
    };
}

// ---- S3_bastion / C3_fortress_spawner / S5_stronghold_room（子 agent 产出）
// ---- S3_bastion / C3_fortress_spawner / S5_stronghold_room（子 agent 产出）
//     子 agent 的 JSON 形状是 `stations: { "0": {id, dim, exact}, … }`（按下标键控、站名在 id 上），
//     所以这里两种形状都认：按键取，或按下标找 id。
const subStations = {};
if (s3c3s5) {
    for (const [k, v] of Object.entries(s3c3s5.stations ?? {})) {
        const id = v.id ?? k;
        subStations[id] = v.exact ?? v;          // 有的包一层 exact，有的不包
    }
}
/**
 * 站位**优先级**覆盖（设计会话 10-03 指定）。只在**不改动输入文件**的前提下重排。
 * ⚠ 排完仍要过下面的站位回读硬闸 —— 优先级是"先用哪个"，不是"哪个站得住"。
 */
const STAND_PRIORITY = {
    // F 线实测作业点第一优先（`[331,56,238]`：脚下 = cracked_polished_blackstone_bricks、身体 57/58 空气）
    S3_bastion: [[331, 56, 238]],
};
for (const sid of ['S3_bastion', 'C3_fortress_spawner', 'S5_stronghold_room']) {
    if (!exact[sid]) {
        const s = subStations[sid];
        if (!s) { if (s3c3s5) { console.error(`子 agent 产物里缺站 ${sid}（现有：${Object.keys(subStations).join(',') || '空'}）`); process.exit(6); } continue; }
        exact[sid] = { stand: s.stand, targets: s.targets, hazards: s.hazards ?? [], verify: s.verify };
    }
    const s = subStations[sid];
    const pri = STAND_PRIORITY[sid];
    if (pri) {
        const seenSet = new Set(exact[sid].stand.map((c) => c.join(',')));
        const have = pri.filter((c) => seenSet.has(c.join(',')));
        const missing = pri.filter((c) => !seenSet.has(c.join(',')));
        if (missing.length) { console.error(`✗ ${sid} 指定的优先站位 ${JSON.stringify(missing)} 不在输入里（不凭空造坐标）`); process.exit(9); }
        exact[sid].stand = [...have, ...exact[sid].stand.filter((c) => !have.some((h) => h.join(',') === c.join(',')))];
        exact[sid].verify.notes = { ...(exact[sid].verify.notes ?? {}), standPriority: pri, standPriorityWhy: '设计会话 10-03 指定：F 线实测作业点第一优先' };
    }
}

// ═══════════════════════════════════════════════ 4. 站位口径统一 + 站点 stand 的代表格
//
// ⚠ **站位口径三套并存，而且它们不是"差 1"这么简单 —— 是"输入本来就混着两种口径"**
//   （本单 ROUND9-C 的病根就是这个，详见 `lib/stand_criterion.mjs` 文件头）：
//   ① **本项目口径（SCHEMA §5 + ROUND5C `stands[].pos` + 现状速览 ㊷ ①）**：
//      `stand` = **脚下那格 = 支撑方块**；玩家身体占 y+1 与 y+2；**玩家 Pos.y = stand.y + 1**。
//   ② F 线 `s3_bastion_gold_piglins.mjs` workPoints / `exact/s3_bastion.exact.json`：
//      `stand` = **身体格**（空气格）⇒ 换到 ① 要 **减 1**。
//   ③ 探针 `v2_nether_legs_corrected.json` 的 `standGround`：**已经是 ①**，**不要再减**。
//
// 🚨 **ROUND8-C 的 bug 就是把 ③ 当成 ② 又减了 1**，于是 S3 63→62、C3 69→68、
//   **S5 36→35 三站一起低 1 格**（S5 那处是 ROUND9-C 回读时新发现的，派单只点了 S3/C3）。
//   而且那一版的 `standAirCells = e.stand`（注释写"身体格 = +1"，代码却没 +1）也一起错。
//
// ⇒ 修法不是"再减/加一次"，而是**给每个输入标它自己的口径**，转换只认标注；
//   转完再对存档逐格回读一遍当硬闸（`readbackStands`），站不住就**非 0 退出**。
import { judgeStand, bodyToGround, groundToBody, standBodyCells } from '../lib/stand_criterion.mjs';

/** 输入站位的口径标注。**只认这张表**，没标注的输入一律拒绝（别再靠站名猜）。 */
const STAND_CONVENTION = {
    S0_iron: 'body',            // v2_extract_s0.mjs 的 `stand()` 判的是身体格
    S0_gravel: 'body',
    S0b_village_beds: 'body',   // 本文件 `stand()` 同样是身体格判据
    S1_portal: 'body',          // B 线交来的作业点 = 身体格（`[187,42,307]`）
    S3_bastion: 'ground',       // 探针 standGround / F 线换算后 = 支撑方块
    C3_fortress_spawner: 'ground',
    S5_stronghold_room: 'ground',
};
for (const [sid, e] of Object.entries(exact)) {
    const conv = STAND_CONVENTION[sid];
    if (!conv) { console.error(`✗ ${sid} 没标 stand 口径（STAND_CONVENTION）—— 不猜`); process.exit(7); }
    const src = e.stand;
    e.standAirCells = conv === 'body' ? src.map((c) => c) : src.map(groundToBody);   // 身体格一律存身体格
    e.stand = conv === 'body' ? src.map(bodyToGround) : src.map((c) => c);            // 本项目口径 = 支撑方块
    e.standConvention = { convention: 'ground_under_feet', inputWas: conv, note: 'stand=脚下那格(支撑方块)，玩家 Pos.y=stand.y+1；standAirCells 是两格身体' };
    e.verify.notes = { ...(e.verify.notes ?? {}), standConventions: e.standAirCells };
}

/**
 * 站位回读硬闸：每个 stand 都必须"支撑方块实心非危险 + 身体两格空气"。
 * **用存档解析器读，不看任何自报字段。** 站不住就退出码 8 并打印违规清单。
 * 证据落到 `probe/v2_stands_readback.json`。
 */
const STAND_READBACK_SAVE = {
    S0_iron: ['probe/_bedhunt', 'overworld'], S0_gravel: ['probe/_bedhunt', 'overworld'],
    S0b_village_beds: ['probe/_bedhunt', 'overworld'], S1_portal: ['probe/_bedhunt', 'overworld'],
    S5_stronghold_room: ['probe/_s5_s5', 'overworld'],
    S3_bastion: ['probe/_bedhunt', 'the_nether'], C3_fortress_spawner: ['probe/_bedhunt', 'the_nether'],
};
function readbackStands() {
    const opened = new Map();
    const report = { schema: 'aidqq-v2-stands-readback/1', at: new Date().toISOString(), stations: {} };
    const bad = [];
    for (const [sid, e] of Object.entries(exact)) {
        const [savename, dim] = STAND_READBACK_SAVE[sid];
        if (!savename) { report.stations[sid] = { skipped: 'no_save_mapped' }; continue; }
        if (!opened.has(savename)) {
            const d = path.join(PROBE, savename.replace(/^probe\//, ''));
            try { opened.set(savename, openWorld(d, { dims: ['overworld', 'the_nether', 'the_end'] })); }
            catch (e) { opened.set(savename, { __err: String(e) }); }
        }
        const world = opened.get(savename);
        if (world.__err) { report.stations[sid] = { save: savename, openError: world.__err }; bad.push({ stand: null, station: sid, reason: 'save_open_failed:' + world.__err.slice(0, 80) }); continue; }
        const rows = e.stand.map((st) => {
            const g = world.blockAt(st[0], st[1], st[2], dim);
            const b1 = world.blockAt(st[0], st[1] + 1, st[2], dim);
            const b2 = world.blockAt(st[0], st[1] + 2, st[2], dim);
            const j = judgeStand(g, b1, b2);
            if (!j.ok) bad.push({ station: sid, stand: st, reason: j.reason, ground: g, body: j.body });
            return { stand: st, bodyCells: standBodyCells(st), ground: g, body: [b1, b2], ...j };
        });
        report.stations[sid] = { save: savename, dim, stands: rows, allOk: rows.every((r) => r.ok) };
    }
    fs.mkdirSync(path.join(PROBE), { recursive: true });
    const dst = path.join(PROBE, 'v2_stands_readback.json');
    fs.writeFileSync(dst, JSON.stringify(report, null, 2));
    return { bad, dst };
}
const READBACK = readbackStands();
console.log(`站位回读：${Object.keys(READBACK.dst ? exact : {}).length} 站，违规 ${READBACK.bad.length} 条 → ${path.relative(process.cwd(), READBACK.dst)}`);
for (const b of READBACK.bad) console.log(`  ❌ ${b.station} ${JSON.stringify(b.stand)} ${b.reason}（ground=${b.ground} body=${JSON.stringify(b.body)}）`);
if (READBACK.bad.length) { console.error(`✗ 站位回读不通过（${READBACK.bad.length} 条）—— 产物不写`); process.exit(8); }

const STAND_OF = {};                    // 算腿用**身体格**（寻路节点）
for (const [sid, e] of Object.entries(exact)) if (e.standAirCells?.length) STAND_OF[sid] = e.standAirCells[0];
const FALLBACK_STAND = {
    S1_portal: [187, 41, 308],        // 门心（门框平面在 x=187，玩家身体格 y=41；脚下那格 = y=40 是岩浆，不能站）
    S3_bastion: [331, 57, 238],       // 身体格（脚下那格 = [331,56,238]）
    C3_fortress_spawner: [220, 70, -87],
    S5_stronghold_room: [1332, 37, 1159],
};

// ═══════════════════════════════════════════════ 5. 逐段算腿
const legs = [];
function addLeg(from, to, dim, waypoints, evidenceLevel, notes, extra = {}) {
    let maxGap = 0;
    for (let i = 1; i < waypoints.length; i++) {
        const a = waypoints[i - 1], b = waypoints[i];
        maxGap = Math.max(maxGap, Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]));
    }
    legs.push({ from, to, dim, waypoints, evidenceLevel, notes, maxGap: +maxGap.toFixed(2), ...extra });
    console.log(`  腿 ${from} → ${to} [${dim}] ${waypoints.length} 路点，最大间隔 ${maxGap.toFixed(1)}（${evidenceLevel}）`);
}
function legStand(sid) {
    const v = STAND_OF[sid] ?? FALLBACK_STAND[sid];
    if (!v) throw new Error(`腿算不出来：站 ${sid} 既没有 standAirCells 也没有 FALLBACK_STAND`);
    return v;
}
console.log('站位（身体格 / 脚下那格）：');
for (const sid of Object.keys(exact)) console.log(`  ${sid.padEnd(22)} ${JSON.stringify(STAND_OF[sid] ?? null)}  /  ${JSON.stringify(exact[sid].stand[0] ?? null)}`);

console.log('逐段算腿：');
/**
 * 统一处理一条 overworld 腿：`fromId`/`toId` 是**站 id**（不是坐标 —— 传坐标进来会被 BFS
 * 当成字符串展开成 NaN，静默返回 1 个点或 0 个点，看起来像"路很短"）。
 * 先走、再挖、最后才退化成几何。
 */
function overworldLeg(fromId, toId, label) {
    const from = fromId === 'SPAWN' ? SPAWN_STAND : legStand(fromId);
    const to = legStand(toId);
    const r = route(from, to);
    if (r) {
        const note = r.level === 'archive-path'
            ? `${label}：逐格 BFS **纯走** ${r.path.length} 格后抽稀（不用挖）`
            : `${label}：走-only 的 BFS 连不通（走到地表就没路了 —— 下井得先挖），改用**挖穿下降**的 BFS，${r.path.length} 格、沿途要挖 ${r.dug} 格`;
        addLeg(fromId, toId, 'overworld', thin(r.path), r.level, note, { fullPathLen: r.path.length, dugBlocks: r.dug, fromCell: from, toCell: to });
        return;
    }
    addLeg(fromId, toId, 'overworld', straight(from, to), 'geometry',
        `${label}：存档覆盖内 BFS（走 + 挖穿下降）均不连通 —— 几何路点，交给 pathfinder 现场找路`, { fromCell: from, toCell: to });
}
// ① 出生点 → S0_iron
//
// ⚠ **不建 `SPAWN` 这条腿**：SCHEMA §5 的 legs 是"站与站之间"，而 `SPAWN` 不是站。
//   route_guard 与 route_v2 两个校验器**各自独立**报了同一条（`from 指向不存在的站 "SPAWN"`）——
//   这就是对拍生效的证据。开局那一段（出生点 → 第一站）交给编排器自己走，
//   出生点站位记在 S0_iron 的 `exact.verify.notes.spawnStand` 里。
exact.S0_iron.verify.notes = {
    ...(exact.S0_iron.verify.notes ?? {}),
    spawnStand: SPAWN_STAND,
    spawnStandNote: '⚠ **不是** SEED-01 记的 spawn (216,224) 本身 —— 那一格在存档里是海面（y=62 water，脚下 sand），站不住，'
        + 'BFS 起点站不住会一步都走不出去、静默返回"未连通"。离线解析找下来最近��**陆地**站位是 (216,63,224)（脚下 y=62 是 sand）。'
        + '开局没有建 SPAWN 腿（SCHEMA §5 的 legs 是站与站之间，编排器自己走这一段）。',
};
overworldLeg('S0_iron', 'S0_gravel', `铁矿站位 ${legStand('S0_iron').join(',')} → 沙砾站位 ${legStand('S0_gravel').join(',')}`);
// ③ S0_gravel → S0b_village_beds
overworldLeg('S0_gravel', 'S0b_village_beds', `沙砾站位 → 村庄床站位 ${legStand('S0b_village_beds').join(',')}`);
// ④ S0b_village_beds → S1_portal
overworldLeg('S0b_village_beds', 'S1_portal', `村庄床站位 → S1 门框站位 ${legStand('S1_portal').join(',')}`);
// ⑤⑥⑦ 下界三段
//
// ⚠⚠ **ROUND9-C 更新（这条是本单最贵的一条）**：
//   · 上一单那三个"÷8 错点"已作废（保持）。
//   · **新的硬事实：门落点 (23,38) 那一列在真存档里是实心 netherrack**（y=36..44 netherrack、
//     31..34 magma_block、21..29 lava）。按 1.16.1 `PortalShape.findEmptyOrNotNullPortalDestination`
//     判据（空气 ∧ 其下空气/黑曜石/门 ∧ 一侧连续 3 格同）枚举 ⇒ **命中 0 个**；
//     ±8 邻域 289 列里：**唯一且站得住 0 列 / 多候选 88 列 / 零候选 186 列**。
//     ⇒ **进下界的门点必须先挖出唯一落点，或换一个门点**，否则这条腿连起点都没有。
//   · S3→C3：ROUND9-C 借泳道 C 生成了覆盖真实走廊的存档（1015 区块、零方块改动），
//     **直线走廊 325 横向格里 53 列不可站**；含挖隧道（≤8 格）的可达集 >400,000 格仍未到 C3。
//     ⇒ 仍是**几何路点 + 如实标注**，不谎称"可走"。
const NETHER_TERRAIN = (() => { try { return readJson(path.join(PROBE, 'v2_nether_legs_terrain.json')); } catch { return null; } })();
{
    const s3 = STAND_OF.S3_bastion ?? [331, 57, 238];
    const c3 = STAND_OF.C3_fortress_spawner ?? [220, 70, -87];
    const s1stand = legStand('S1_portal');
    const landingTxt = NETHER_TERRAIN?.landing
        ? `门落点枚举（1.16.1 判据）：(23,38) 命中 **${NETHER_TERRAIN.landing.hitCount}** 个 ⇒ ${NETHER_TERRAIN.landing.unique ? '唯一可用' : '**不出门**'}；`
        + `±8 邻域唯一且站得住的列 **${NETHER_TERRAIN.landing.neighborhood?.uniqueCount ?? '?'}** 个。`
        : '门落点未验（枚举产物缺失）。';
    addLeg('S1_portal', 'S3_bastion', 'the_nether', straight([23, 38, 38], s3), 'geometry',
        `⚠ **几何路点，未经地形核验**。${landingTxt} 进门在主世界 ${s1stand.join(',')} 点火 ⇒ 下界门心约 (23,38)（落点**未验**，需真服开一次门看 Pos）。`,
        { portalAt: s1stand, netherLandingGuess: [23, 38, 38], landingVerified: false, corridorSave: 'probe/_r9c_nether_corridor', terrainVerdict: NETHER_TERRAIN?.verdict ?? null });
    addLeg('S3_bastion', 'C3_fortress_spawner', 'the_nether', straight(s3, c3), 'geometry',
        `⚠ **几何路点，未经地形核验**。ROUND9-C 已在覆盖真实走廊的存档（${NETHER_TERRAIN?.world ?? 'probe/_r9c_nether_corridor'}，1015 区块）上实测：`
        + `**直线走廊 325 横向格里 53 列不可站**（含 1 列岩浆）⇒ 不是"一条直线走过去"；`
        + `含挖隧道（≤8 格，1×2）的可达集 >400,000 格仍未到 C3 ⇒ **搜索预算不够 + 地形不通，两者都有**。`,
        { corridorSave: 'probe/_r9c_nether_corridor', straightLineNonStandableColumns: 53, terrainVerdict: NETHER_TERRAIN?.verdict ?? null });
}
// ⑧ C3 → S5：**跨维度的合成腿**。正常流程的站序是 …C3_fortress_spawner → S5_stronghold_room，
//    但实际走法是"先原路回门 → 再从主世界走 ~1100 格到门室"。
//    route_guard 的 v2 判据要求**相邻两个 normalFlowStations 之间必须有腿**，
//    所以这里给一条合成腿，让编排器拿 C3→S5 有一条**完整可执行**的指令，不用自己去拼两条。
//    ⚠ 中间那 ~1100 格**没有存档**（见下条腿的说明），只有几何路点。
{
    const a = legStand('S1_portal');
    const frame = (byId.get('S5_stronghold_room').scout.points ?? []).find((p) => p.what === 'end_portal_frame');
    const b = [frame.x, frame.y, frame.z];
    const ow = straight(a, b);
    addLeg('C3_fortress_spawner', 'S5_stronghold_room', 'overworld', ow, 'composite',
        `合成腿 = ①下界从 C3 原路回门（**几何路点**，见 S3_bastion→C3 那条腿的不可算说明） + ②主世界 ${a.join(',')} → ${b.join(',')} 的几何路点。`
        + `**下界走廊与主世界长转场两段都没有存档支撑。**`,
        { compositeOf: ['C3_fortress_spawner->S1_portal', 'S1_portal->S5_stronghold_room'], via: 'S1_portal' });
}
// ⑨ S1 门 → S5 末地门室（长距离转场）
{
    const a = legStand('S1_portal');
    const s5 = byId.get('S5_stronghold_room');
    const frame = (s5.scout.points ?? []).find((p) => p.what === 'end_portal_frame');
    const b = [frame.x, frame.y, frame.z];
    // ⚠ 存档 `_bedhunt` 只覆盖 x 32..591 / z 48..431，**中间那段走廊没有任何存档**。
    //   所以这条腿只能是几何路点，且必须标 geometry —— 不能冒充"实测可走"。
    addLeg('S1_portal', 'S5_stronghold_room', 'overworld', straight(a, b), 'geometry',
        `⚠ **本腿没有任何存档支撑**：现有存档覆盖 x 32..591 / z 48..431 与 x 1024..1535 / z 1024..1535，`
        + `而 S1 门 (187,41,308) → 门室 (${b.join(',')}) 之间约 ${Math.round(Math.hypot(b[0] - a[0], b[2] - a[2]))} 格走廊**没有落盘的区块**。`
        + `SCHEMA §5 的 ≤32 规则本就是为了让 pathfinder 在相邻路点之间自己找路 ⇒ 几何路点是合法输入。`
        + `**要做成 A 级（逐格实测）必须借一次泳道生成这条走廊的存档**，见报告「未验项」。`,
        { straightXZ: +Math.hypot(b[0] - a[0], b[2] - a[2]).toFixed(1) });
}

// ═══════════════════════════════════════════════ 6. 组装 v2 文档
const doc = {
    ...v1,
    schema: 'aidqq-route/2',
    generatedAt: new Date().toISOString(),
    upgradedFrom: { file: '4926685115947721762.json', schema: 'aidqq-route/1', by: '开发线 C · ROUND8-C（2026-10-03）', basis: 'docs/MC-DECISION-02-背作业路线与整链优先.md + SCHEMA §5' },
    frozenAt: null,                                   // 本单**不写**（SCHEMA §4：冻结是人工审阅后的独立动作）
    sha256File: v1.sha256File,
    legs,
    stations: v1.stations.map((s) => (exact[s.id] ? { ...s, exact: exact[s.id] } : s)),
    v2Audit: {
        exactStations: Object.keys(exact),
        pendingStations: Object.entries(exact).filter(([, e]) => e.verify.status !== 'REAL').map(([k]) => k),
        legEvidence: legs.map((l) => ({ from: l.from, to: l.to, level: l.evidenceLevel, waypoints: l.waypoints.length, maxGap: l.maxGap })),
        unverified: [
            'S1_portal 的 exact **故意留空**（DECISION-02 §4 划给 B 线），只保留 v1 站级兜底。',
            'S1_portal → S5_stronghold_room 这条 ~1100 格转场腿是**几何路点**（geometry），走廊无存档支撑，未逐格核验。',
            '下界门实际落点坐标与 y 未验（需要真服开一次门看 Pos）；下界三段按"离目标 XZ 最近的可走格"代替。',
            '下界三段是**三段各自独立最短路**，不是一条连续巡回路线；往返不走同一条路这件事未验。',
        ],
    },
};

fs.writeFileSync(OUT, JSON.stringify(doc, null, 2) + '\n', 'utf8');
const back = JSON.parse(fs.readFileSync(OUT, 'utf8'));
console.log(`\n✔ 落盘 ${path.relative(process.cwd(), OUT)}（${fs.statSync(OUT).size} 字节，回读解析 OK）`);
console.log(`  exact 站=${back.stations.filter((s) => s.exact).map((s) => s.id).join(',')}`);
const bad = back.legs.filter((l) => l.maxGap > MAX_LEG_GAP);
console.log(`  相邻路点 >32 的腿：${bad.length ? bad.map((l) => `${l.from}→${l.to}(${l.maxGap})`).join(', ') : '无 ✔'}`);

// 站序完整性自查：相邻两个 normalFlowStations 之间必须有腿（与 route_guard 的 v2 判据同一条）
const nf = back.normalFlowStations;
const missing = [];
for (let i = 0; i + 1 < nf.length; i++) if (!back.legs.some((l) => l.from === nf[i] && l.to === nf[i + 1])) missing.push(`${nf[i]} -> ${nf[i + 1]}`);
console.log(`  正常流程站序缺腿：${missing.length ? missing.join(', ') : '无 ✔'}`);

// S1 逐格观测单独留档（S1_portal.exact.verify.evidence 指向它）
const LAST = path.join(PROBE, 'v2_build_route.last.json');
fs.writeFileSync(LAST, JSON.stringify({
    schema: 'aidqq-v2-build-audit/1', at: doc.generatedAt, seed: doc.seed,
    legs: back.legs.map((l) => ({ from: l.from, to: l.to, dim: l.dim, waypoints: l.waypoints.length, maxGap: l.maxGap, evidenceLevel: l.evidenceLevel })),
    S1_portal: back.stations.find((s) => s.id === 'S1_portal').exact.verify.observations,
    s0: { iron: s0.stations.S0_iron.selected, gravel: s0.stations.S0_gravel.selected },
    unverified: back.v2Audit.unverified,
}, null, 2) + '\n', 'utf8');
console.log(`  审计 ${path.relative(process.cwd(), LAST)}`);
if (bad.length || missing.length) { console.error('ABORT：有腿违反 ≤32 或站序缺腿 —— 不产出合格 v2'); process.exit(7); }
