// scan.mjs — MC-ROUTE-02：服务器权威真值扫描 + 递归下钻
//
// 方法沿用 SEED-03 R3（experiments/seed-scout/r3_fill.mjs），本文件做两处扩展：
//   ① **递归下钻**（新增，本单的核心）：R3 只能给出「r48 大盒里有多少个目标方块」，
//      本单要的是**结构内部的精确坐标**（12 个门框各自的 xyz、刷怪笼、堡垒金块…）。
//      做法 = 对 `fill ... replace` 的计数做八叉细分：盒内有计数就继续对半拆，
//      直到 1×1×1 → 返回全部命中点的精确坐标。全程只用服务器回执，不读客户端。
//   ② **到达确认用的地形对照**：每个盒都同时计一组地形方块（主世界 stone/dirt/water、
//      下界 netherrack）。手册 §5 的硬规矩：读出"全零"先证伪工具再证伪世界。
//      出现 boxes_zero_control > 0 视为该盒不可信 → 该次扫描标 UNVERIFIED，不当 REAL。
//
// 口径与副作用（必须知道）：
//   - `fill <box> <marker> replace <block>` 只替换匹配到的方块，**非破坏性**（对不匹配的方块）。
//   - 命中的方块会被换成 marker（barrier/bedrock）→ **同一区域重复扫同一 block 前，
//     上一次的命中已经变成 marker 了**。因此每个 block 类型在一个盒里只扫一次，
//     且下钻只对 target 展开、地形对照在下钻**之前**取。
//   - 每次扫描世界都是临时 fresh world（跑完删），marker 残留不出本工具。

const RE_FILLED = /^Successfully filled (\d+) blocks/;
const RE_NONE = /^No blocks were filled/;
const RE_NOTLOADED = /not loaded|unloaded/i;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * 下钻用的**双标记**。
 *
 * 为什么必须两个：下钻是递归细分，每层都要问「这个子盒里有几个命中」。
 * 而**唯一能返回计数的 fill 一定会替换掉被数的方块**；若替换目标 = 被数方块
 * （`fill … barrier replace barrier`），服务器认为「没有变化」，回 `No blocks were filled` = 0。
 * 实测踩过：命中盒 1 个、粗扫计数 12，但下钻读 0、points 为空。
 *
 * 解法 = **逐层交替**：A 层数 A 换成 B，B 层数 B 换成 A……每个盒轮到它时内容同质
 * （只被父盒那一次 fill 改过，兄弟盒互不干扰），计数恒准。
 *
 * 不变量：A/B 在主世界与下界都**不会自然生成**（barrier 只由末地传送门/传送门放置，
 * command_block 生存世界不生成）→ 读到的就是自己放的。事后另有
 * 「下钻点数 == 粗扫计数」自检（drill 供调用方核对），不靠自觉。
 */
export const MARKER_A = 'minecraft:barrier';
export const MARKER_B = 'minecraft:command_block';
export const MARKER_TARGET = MARKER_A; // 粗扫第一层标记
export const MARKER_CTRL = 'minecraft:bedrock';
/** 逐层交替：下一层用另一个标记 */
const other = (m) => (m === MARKER_A ? MARKER_B : MARKER_A);

export const TERRAIN = {
    overworld: ['minecraft:stone', 'minecraft:dirt', 'minecraft:water'],
    the_nether: ['minecraft:netherrack'],
    the_end: ['minecraft:end_stone'],
};
/** 地形对照的判据：至少一个计数 > 0（手册 §5：全零先证伪工具） */
export const CTRL_MIN = 1;

/** 命令前缀：下界/末地要先切维度 */
function dimPre(dim) {
    if (dim === 'the_nether') return 'execute in minecraft:the_nether run ';
    if (dim === 'the_end') return 'execute in minecraft:the_end run ';
    return '';
}

/** 回执判据 */
const isFillResp = (l) => RE_FILLED.test(l) || RE_NONE.test(l);

/**
 * 发一条 fill 并等它的回执。**返回 0 = 无命中；抛错 = 流不可信**。
 *
 * 为什么这么严（三条都是实测踩出来的）：
 *   ① **发前先排空缓冲**。上一条命令的迟到回执若留在缓冲里，会被当成本条命令的答案配错位。
 *      主种子首轮要塞扫描就出现过：粗扫计数 2、下钻却报 130 点 / 832 点，自相矛盾。
 *   ② **只认"本条之后到达的第一条"** fill 回执，不跨命令配对。
 *   ③ **超时直接抛错，不重试**。丢一条回执意味着流已经不可信；重试只会把错位继续放大，
 *      产出"看起来正常但坐标是错的"数据——那是最坏的结果。宁可这一类直接失败。
 *      （下钻点数与粗扫计数的自检是第二道防线，实测正是它把要塞那一站降级成了 UNVERIFIED。）
 */
export async function fillCount(con, dim, box, block, { marker = MARKER_TARGET, timeoutMs = 25000, asReplace = false } = {}) {
    const pre = dimPre(dim);
    // ① **先把上一条命令的回执补齐再发新的**。
    //    原实现只做「发前排空缓冲」，那对**已经**到位的回执有效，对**还在路上的**回执无效：
    //    新命令先发出去了，随后一次 drain 同时读到「迟到的旧回执 + 本条回执」，
    //    而代码只取第一条 ⇒ **迟到的旧回执被当成本条的答案**（配对错位）。
    //    实测症状：主种子框体片 obsidian 实为 7，紧挨着发命令却读成 0，
    //    下一条 crying_obsidian 读成 9（错位 + 上一轮残留 marker 被下钻挖出来的合成症状）。
    //    修法：用 `sent/got` 计数做**严格 FIFO 配对**——发出数 > 收到数时，先等并消费掉
    //    迟到的旧回执（计入 desync），再发新命令。真正的配对因此不可能错。
    const sent = con.sentFills ?? 0;
    const got = con.gotFills ?? 0;
    if (sent > got) {
        const tw = Date.now();
        while (Date.now() - tw < Math.min(timeoutMs, 5000)) {
            const late = con.drain().filter(isFillResp);
            if (late.length) { con.sentFills = sent; con.gotFills = got + late.length; con.desync = (con.desync ?? 0) + late.length; break; }
            await sleep(25);
        }
        if ((con.gotFills ?? 0) < (con.sentFills ?? 0)) {
            throw new Error(`FILL_DESYNC: 上一条命令的回执 ${(con.sentFills ?? 0) - (con.gotFills ?? 0)} 条始终未到（已等 5s）——流不可信，拒绝继续以免产出错坐标`);
        }
    }
    // `asReplace: true` 发出的是 `fill <box> <block> replace <marker>`（把 marker 换回 block）。
    // 这是**非破坏性逐格判据**的回程：cell_probe 先 `… barrier replace <候选>` 命中，
    // 再用这条把原方块还回去，回执 1 即"复原成功"的收据。见 cell_probe.mjs。
    const cmd = asReplace
        ? `${pre}fill ${box.x1} ${box.y1} ${box.z1} ${box.x2} ${box.y2} ${box.z2} ${block} replace ${marker}`
        : `${pre}fill ${box.x1} ${box.y1} ${box.z1} ${box.x2} ${box.y2} ${box.z2} ${marker} replace ${block}`;
    // ② 发 + 只等本条之后的回执
    con.sentFills = (con.sentFills ?? 0) + 1;
    con.cmd(cmd);
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
        for (const line of con.drain()) {
            if (con.child.exitCode !== null) throw new Error(`FILL_SERVER_DIED: server rc=${con.child.exitCode}`);
            let m;
            if ((m = line.match(RE_FILLED))) { con.gotFills = (con.gotFills ?? 0) + 1; return parseInt(m[1], 10); }
            if (RE_NONE.test(line)) { con.gotFills = (con.gotFills ?? 0) + 1; return 0; }
            if (RE_NOTLOADED.test(line)) {
                // 区块没加载：等 forceload 生效后重发（本条仍算一条，不进错位账）
                await sleep(600);
                con.cmd(cmd);
                break;
            }
        }
        await sleep(25);
    }
    // ③ 超时 = 不可信，硬失败
    throw new Error(`FILL_NO_RESPONSE: ${dim} ${JSON.stringify(box)} ${block}（${timeoutMs}ms 无回执；流可能已错位，本工具拒绝在此情况下继续以免产出错坐标）`);
}

/** forceload 方形区域（把区域变成"已加载"，fill 才有真值） */
export async function forceload(con, dim, x1, z1, x2, z2, settleMs = 400) {
    con.cmd(`${dimPre(dim)}forceload add ${Math.min(x1, x2)} ${Math.min(z1, z2)} ${Math.max(x1, x2)} ${Math.max(z1, z2)}`);
    await sleep(settleMs);
    // 排空 "Marked N chunks" 之流的回执，避免污染后续 fill 的应答配对
    con.drain();
}

/**
 * 把 [x1,x2]×[y1,y2]×[z1,z2] 切成盒列表。
 * XZ 用 32 格网格（与 R3 同款），**Y 额外切到 ≤16 格高**——原版 fill 单次上限 32768 格，
 * 32×32×32 正好顶满；下界大量生成区块时这种大 fill 会把服务器拖到 "Can't keep up!"，
 * 回执迟滞 → 配对错位（实测踩过）。降到 16384 格后回执稳定，代价只是盒数翻倍。
 */
export function boxesOf(cx, cz, r, ySlices) {
    const out = [];
    const MAX_Y = 16;
    const slices = [];
    for (const [ya, yb] of ySlices) {
        for (let y = ya; y <= yb; y += MAX_Y) slices.push([y, Math.min(y + MAX_Y - 1, yb)]);
    }
    for (let bx = cx - r; bx <= cx + r; bx += 32) {
        for (let bz = cz - r; bz <= cz + r; bz += 32) {
            for (const [ya, yb] of slices) {
                out.push({
                    x1: bx, y1: ya, z1: bz,
                    x2: Math.min(bx + 31, cx + r), y2: yb, z2: Math.min(bz + 31, cz + r),
                });
            }
        }
    }
    return out;
}

/**
 * 一趟完成：粗扫（找命中盒）+ 地形对照 +（按需）精确下钻。
 *
 * 两种粒度（对应 SCHEMA 的 L2 站级 vs scout 精确级）：
 *   - **点状目标**（末地门框 / 刷怪笼 / 金块 / 箱子）：`drillBlocks` 里列出 → 命中盒内下钻到 1×1×1，
 *     精确坐标进 `scout.points`。
 *   - **面状目标**（岩浆池 / 沙砾区 / 铁源区）：**不下钻**，只记「哪个 32×32 盒有货 + 计数」，
 *     盒中心就是站的区域中心。理由：站级粒度 radius ≥16，本来就不需要格级坐标；
 *     对成百上千个方块下钻既慢又没意义（还会把 probe 撑爆）。
 *
 * @returns {{counts, terrain, boxes, boxesZeroControl, hitBoxes, perBlock, fills, truncated, selfCheck}}
 */
export async function drill(con, dim, cx, cz, r, ySlices, targets, { maxBoxes = 4000, drillBlocks = [], drillUntil = 0, drillNearestBoxes = 0, logFn = null } = {}) {
    const ctrls = TERRAIN[dim] ?? TERRAIN.overworld;
    const boxes = boxesOf(cx, cz, r, ySlices);
    await forceload(con, dim, cx - r, cz - r, cx + r, cz + r);

    // `drillNearestBoxes: N` = **只下钻离参考点 (cx,cz) 最近的 N 个盒子**。
    // 为什么需要它（岩浆站踩出来的）：`drillUntil` 是"挖到 N 个点就收手"，而盒子是**按坐标序**
    // 遍历的——收手发生在**第一个有货的盒子里**，于是点集偏向扫描区域的边角而不是离门最近处。
    // 岩浆站因此拿到 y 0–15 的一堆源块，判成"没有一个满足 Δy≤8"，那是**抽样偏差不是结论**。
    // 用"最近 N 盒"把抽样锚定在参考点附近，结论才有意义。
    let drillBoxSet = null;
    if (drillNearestBoxes > 0) {
        drillBoxSet = new Set(boxes
            .map((b, i) => ({ i, d: Math.hypot((b.x1 + b.x2) / 2 - cx, (b.z1 + b.z2) / 2 - cz) }))
            .sort((a, b) => a.d - b.d).slice(0, drillNearestBoxes).map((o) => o.i));
    }

    const counts = Object.fromEntries(targets.map((t) => [t, 0]));
    const terrain = Object.fromEntries(ctrls.map((t) => [t, 0]));
    const perBlock = Object.fromEntries(targets.map((t) => [t, { block: t, coarse: 0, points: [] }]));
    const hitBoxes = [];
    let boxesZeroControl = 0, fills = 0, truncated = false;

    for (let bi = 0; bi < boxes.length; bi++) {
        const b = boxes[bi];
        // ① **先**把地形对照做完（用独立的 MARKER_CTRL），保证下钻时盒里只有"当前 target 的标记"
        let ctrlSum = 0;
        for (const c of ctrls) {
            const n = await fillCount(con, dim, b, c, { marker: MARKER_CTRL });
            fills++;
            terrain[c] += n;
            ctrlSum += n;
        }
        if (ctrlSum < CTRL_MIN) boxesZeroControl++;

        // ② 逐 target：填完**立刻**下钻，再去标下一个 target。
        // ⚠⚠ 顺序是硬要求，不能改成"先标完全部 target 再统一下钻"：
        //    所有 target 共用 MARKER_A，一旦同盒有第二个 target 被标记，下钻数到的 marker
        //    就是**所有 target 的总和**。实测踩过：要塞一盒里 spawner=2、nether_bricks 上百，
        //    下钻报 130 点——数字完全对不上。
        //
        // ⚠⚠ 下钻前必须**清场**（把盒里残留的 A/B 换成 CTRL），因为世界是**整个种子共用**的：
        //    上一类目的 `fill … replace` 标记会留在世界里。实测踩过：lava_pool 在 r=48 把 3502
        //    个岩浆块标成 barrier 留在原地，随后 ruined_portal 的扫描盒正好落在那片区域，
        //    下钻把残留一起数了 → crying_obsidian 粗扫 1、下钻 2（点集逐层包含：2→11→12）。
        //    注意：**粗扫计数不受影响**（它只数自己的 target），所以清场只需做在下钻前，
        //    代价 = 每个"要下钻的盒 × target"两次 fill，量级可忽略。
        const hit = [];
        for (const t of targets) {
            const willDrill = drillBlocks.includes(t) && (!drillBoxSet || drillBoxSet.has(bi));
            if (drillBlocks.includes(t) && !willDrill && logFn) {
                logFn(`    skip drill ${t}（盒 ${bi} 不在离参考点最近的 ${drillNearestBoxes} 盒内）`);
            }
            if (willDrill) {
                await fillCount(con, dim, b, MARKER_A, { marker: MARKER_CTRL }); // 清场 1/2
                await fillCount(con, dim, b, MARKER_B, { marker: MARKER_CTRL }); // 清场 2/2
                fills += 2;
            }
            const n = await fillCount(con, dim, b, t, { marker: MARKER_A });
            fills++;
            counts[t] += n;
            if (n === 0) continue;
            hit.push({ block: t, count: n });
            perBlock[t].coarse += n;
            if (!willDrill) continue;
            if (drillUntil > 0 && perBlock[t].points.length >= drillUntil) {
                if (logFn) logFn(`    skip drill ${t}（已达 drillUntil=${drillUntil}）`);
                continue;
            }
            const d = await descend(con, dim, b, MARKER_A, { maxBoxes });
            fills += d.fills;
            if (d.truncated) truncated = true;
            perBlock[t].points.push(...d.points);
            if (logFn) logFn(`    drill ${t} in box(${b.x1},${b.y1},${b.z1}-${b.x2},${b.y2},${b.z2}) → ${d.points.length} 点 / ${d.fills} fills`);
        }
        if (hit.length) hitBoxes.push({ box: b, hit, ctrlSum, zeroCtrl: ctrlSum < CTRL_MIN });
    }
    // 自检：下钻点数必须等于粗扫计数（**仅在"挖全了"的前提下**——drillUntil 提前收手时
    // 点数本来就该少于计数，这不是错，要显式区分开，否则会把"主动少挖"误判成"下钻出错"）
    const selfCheck = {};
    for (const t of targets) {
        perBlock[t].points.sort((a, b) => (a.x - b.x) || (a.y - b.y) || (a.z - b.z));
        const partial = drillUntil > 0 && perBlock[t].points.length > 0 && perBlock[t].points.length < perBlock[t].coarse;
        selfCheck[t] = {
            coarse: perBlock[t].coarse, drilled: perBlock[t].points.length,
            partialByDrillUntil: partial,
            ok: drillBlocks.includes(t) ? (partial ? 'partial' : perBlock[t].coarse === perBlock[t].points.length) : null,
        };
    }
    return {
        counts, terrain, boxes: boxes.length, boxesZeroControl, hitBoxes, perBlock, fills, truncated, selfCheck,
        desync: con.desync ?? 0, r, cx, cz, ySlices, dim,
    };
}

/** 从 hitBoxes 里挑离 ref 最近、且地形对照通过的盒（面状目标用） */
export function nearestHitBox(hitBoxes, ref) {
    const ok = hitBoxes.filter((h) => !h.zeroCtrl);
    const pool = ok.length ? ok : hitBoxes;
    if (!pool.length) return null;
    const cx = (b) => (b.x1 + b.x2) / 2, cz = (b) => (b.z1 + b.z2) / 2;
    return pool.slice().sort((a, b) => Math.hypot(cx(a.box) - ref.x, cz(a.box) - ref.z) - Math.hypot(cx(b.box) - ref.x, cz(b.box) - ref.z))[0];
}

/** 八叉细分：把一个盒里所有命中 block 的精确 xyz 挖出来 */
export function splitBox(b) {
    const mid = (a, c) => Math.floor((a + c) / 2);
    const xs = b.x1 === b.x2 ? [b.x1] : [b.x1, mid(b.x1, b.x2) + 1];
    const ys = b.y1 === b.y2 ? [b.y1] : [b.y1, mid(b.y1, b.y2) + 1];
    const zs = b.z1 === b.z2 ? [b.z1] : [b.z1, mid(b.z1, b.z2) + 1];
    const out = [];
    for (const x of xs) for (const y of ys) for (const z of zs) {
        out.push({ x1: x, y1: y, z1: z, x2: xs.length > 1 ? (x === xs[0] ? mid(b.x1, b.x2) : b.x2) : b.x2, y2: ys.length > 1 ? (y === ys[0] ? mid(b.y1, b.y2) : b.y2) : b.y2, z2: zs.length > 1 ? (z === zs[0] ? mid(b.z1, b.z2) : b.z2) : b.z2 });
    }
    return out;
}

/**
 * 递归下钻定位：对 box 内所有 block==startMarker 的方块求精确坐标。
 *
 * **双标记逐层交替**（本单踩坑后的定版做法）：
 *   每层问「这个子盒里有几个 `cur`」的**同时**把它们换成 `next`，然后带着
 *   (cur=next, next=cur) 递归下去。`fill X replace X` 不计数（服务器认为无变化 → 回 0），
 *   所以「数自己」这条路在原版是不存在的，必须靠两个标记交替才能既计数又递归。
 *   每个盒轮到它时内容同质（只被父盒那一次 fill 改过，兄弟盒互不干扰）→ 计数恒准。
 *
 * @param {object} opts.maxBoxes 保险丝（默认 4000 次 fill）
 * @returns {Promise<{points:Array<{x,y,z}>, fills:number, truncated:boolean, sum:number}>}
 *        sum = 沿递归路径累计的命中数（应等于 leaf 数，用于事后核对）
 */
export async function descend(con, dim, box, startMarker, { maxBoxes = 4000, minEdge = 1 } = {}) {
    const points = [];
    let fills = 0, truncated = false, sum = 0;
    const stack = [{ b: box, cur: startMarker }];
    while (stack.length) {
        if (fills > maxBoxes) { truncated = true; break; }
        const { b, cur } = stack.pop();
        const nxt = other(cur);
        const n = await fillCount(con, dim, b, cur, { marker: nxt }); // 数 cur、换成 nxt
        fills++;
        if (n === 0) continue;
        sum += n;
        const vol = (b.x2 - b.x1 + 1) * (b.y2 - b.y1 + 1) * (b.z2 - b.z1 + 1);
        if (vol === 1 || (b.x2 - b.x1 < minEdge && b.y2 - b.y1 < minEdge && b.z2 - b.z1 < minEdge)) {
            points.push({ x: b.x1, y: b.y1, z: b.z1 });
            continue;
        }
        const subs = splitBox(b);
        for (let i = subs.length - 1; i >= 0; i--) stack.push({ b: subs[i], cur: nxt });
    }
    points.sort((a, b) => (a.x - b.x) || (a.y - b.y) || (a.z - b.z));
    return { points, fills, truncated, sum };
}

/**
 * 解析 1.16.1 的 /locate 回执。
 * ⚠ 实测（主种子泳道 C 冒烟）：1.16.1 回执是 `[1560, ~, 360]`——**Y 是 `~` 不是数字**
 *   （"The nearest stronghold is at [1560, ~, 360] (1389 blocks away)"）。
 *   只按数字三元组解析会整条漏掉、每条 locate 白等 30s 超时，还会把服务器拖进
 *   "Can't keep up! Running 51949ms"（实测）。所以 XZ 按数字取，Y 允许 `~`。
 */
export function parseLocate(text) {
    const m = /\[?\s*(-?\d+)\s*,\s*(~|-?\d+)\s*,\s*(-?\d+)\s*\]?/.exec(text);
    if (!m) return null;
    return { x: parseInt(m[1], 10), y: m[2] === '~' ? null : parseInt(m[2], 10), z: parseInt(m[3], 10), raw: text.trim() };
}

/** 执行一条 /locate 并等回执（解析成功即刻返回，不吃满超时） */
export async function locate(con, structure, dim = 'overworld') {
    con.cmd(`${dimPre(dim)}locate ${structure}`); // 手册 §2：1.16.1 只认裸名
    const t0 = Date.now();
    let buf = [];
    while (Date.now() - t0 < 60000) {
        for (const line of con.drain()) {
            buf.push(line);
            if (/could not find|no .* found|can't find/i.test(line)) return { notFound: true, raw: line.trim() };
            if (/blocks away|is at|nearest/i.test(line)) {
                const p = parseLocate(line);
                if (p) return p;
            }
        }
        await sleep(30);
    }
    return { timeout: true, raw: buf.join(' | ').slice(0, 200) };
}
