// r7c_fix_s3_scout.mjs — ROUND7-C 续单：把 **S3 的金源地图 + 猪灵世界生成分布**写进 `S3_bastion.scout`
//
// 【硬约束】只写 `S3_bastion.scout`；`station`、`frozenAt`、`sha256File` 一个字节都不动（有硬闸断言）。
//   精确坐标清单（254 个金源 + 29 头猪灵）**留在 probe JSON 里**，route 只放摘要 + 指针 ——
//   SCHEMA §1 的 scout 区虽然允许精确坐标，但把 283 条坐标灌进 route 会让冻结审阅没法读；
//   完整清单按 `evidence` 指到 `bench/route/probe/s3_bastion_gold_piglins.*.json`。
//
// 【本单推翻/订正了三条】
//   ① F 线 MC-S2-03 §B5「金源没着落」**不成立** —— 它的计数盒 x336..368 / z256..288 / y32..47
//      只擦到堡垒一角（17424 格里只有 10 块黑曜石），而堡垒金源的真实范围是 x319..361 / y32..91 / z210..272。
//   ② `corroboration.box`（x320..351 / z240..271）与它自己列的 `goldBlockPoints`（x322..361 / z217..265）**互相矛盾**
//      —— 那一轮的计数其实是在**更大的区**上做的（本次存档复核 22/227/5 与它逐个相等）。
//   ③ `piglinPopulation.peaceful = 28`（F 线实跑 kill 回执）vs 本单存档 **29**：差 1 头，如实并列，不挑一个信。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE_DIR = path.resolve(HERE, '..');
const PROBE = path.join(ROUTE_DIR, 'probe');
const P = path.join(ROUTE_DIR, '4926685115947721762.json');
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };

const calm = readJson(path.join(PROBE, 's3_bastion_gold_piglins.peaceful.json'));
if (!calm) throw new Error('缺 s3_bastion_gold_piglins.peaceful.json —— 先跑分析工具');
const easy = readJson(path.join(PROBE, 's3_bastion_gold_piglins.easy.json'));   // 可能是 null（easy 存档没跑成）

const raw = fs.readFileSync(P, 'utf8');
const route = JSON.parse(raw);
if (raw !== JSON.stringify(route, null, 2) + '\n') throw new Error('文件不是规范化形式（SCHEMA §4）');
const S3 = route.stations.find((s) => s.id === 'S3_bastion');
if (!S3) throw new Error('找不到 S3_bastion');
const stationBefore = JSON.stringify(S3.station);
const frozenBefore = JSON.stringify([route.frozenAt, route.sha256File]);

const at = new Date().toISOString();
const top = calm.grid8x8.list.filter((g) => g.piglins > 0).slice(0, 6)
    .map((g) => ({ cell: [g.gx, g.gz], piglins: g.piglins, yRange: g.yRange, goldBlock: g.goldBlock, gilded: g.gilded, chest: g.chest }));

// ---------------------------------------------------------------- 金源
S3.scout.goldSources = {
    at,
    by: '开发线 C · ROUND7-C 续单（存档解析器，只读）',
    question: 'F 线 MC-S2-03 §B5 问「堡垒的金锭来源有没有着落」',
    answer: '**有着落，而且很富裕** —— 但绝大多数鎏金黑石是**结构墙体、没有暴露面**。',
    method: '存档解析（region_reader.mjs）逐格读 C2 堡垒全范围；**不开服、不发 fill/summon**',
    window: { blocks: calm.box, chunks: calm.coverage.cx?.length ? null : null, note: 'cx14..26 / cz10..22 ⇒ x224..431 / z160..367' },
    readHealth: calm.readHealth,
    counts: {
        gold_block: { total: calm.gold.byBlock.gold_block.total, exposed: calm.gold.byBlock.gold_block.exposed, hidden: calm.gold.byBlock.gold_block.hidden },
        gilded_blackstone: { total: calm.gold.byBlock.gilded_blackstone.total, exposed: calm.gold.byBlock.gilded_blackstone.exposed, hidden: calm.gold.byBlock.gilded_blackstone.hidden },
        chest: { total: calm.gold.byBlock.chest.total, exposed: calm.gold.byBlock.chest.exposed, hidden: calm.gold.byBlock.chest.hidden },
    },
    exposureCriterion: '目标块 6 个面邻格里 ≥1 个属于空气集 {air,cave_air,void_air}（与 visibility_audit.mjs 同一判据）',
    actionable: {
        note: '**能直接用的暴露金源共 61 处** = 14 金块 + 5 箱 + 42 鎏金黑石。',
        chests: calm.gold.list.filter((g) => g.block === 'chest').map((g) => g.xyz),
        goldBlockCluster: {
            note: '**22 块金块里有 12 块挤在一个 3×2×4 的小金库**：x359..361 / y70..71 / z245..248（附近还有 2 块单块）。这一簇**离猪灵密集区（x320..335）约 25 格**，且只有部分暴露。',
        },
        gildedWarning: '**227 块鎏金黑石里 185 块（81%）一个暴露面都没有** —— 它主要是墙体装饰，**不能当"可取金源"数**。要数金源只能数 42 块暴露的。',
    },
    coverageCheck: {
        rule: '手册 §5「扫描范围要比目标大一圈，并检查边界上有没有命中」（S5 门室 9→12 就是被扫描窗下界切掉的）',
        goldMinDistToEdge: Number((calm.gold.boundary?.minDistToEdge ?? 0).toFixed(1)),
        piglinMinDistToEdge: Number((calm.piglins.boundary?.minDistToEdge ?? 0).toFixed(1)),
        missingChunks: calm.coverage.missingChunks,
        verdict: '**充分**（金源最近的一处离覆盖边界 ' + Number((calm.gold.boundary?.minDistToEdge ?? 0).toFixed(1)) + ' 格、猪灵 ' + Number((calm.piglins.boundary?.minDistToEdge ?? 0).toFixed(1)) + ' 格，窗口内 0 个缺块）—— 与 S5 那次相反，本单**没有**被截断。',
    },
    crossCheck: {
        note: '两条**独立通道**逐个相等（存档解析器 vs ROUTE-02 的 fill-replace 回执）',
        result: calm.positiveControls.routeCrossCheck,
    },
    correctionB5: {
        at,
        field: 'F 线 MC-S2-03 §B5「S2 的金锭来源目前没有着落」',
        verdict: '**不成立**',
        cause: 'B5 的计数盒是 x336..368 / z256..288 / y32..47（17424 格），只擦到堡垒一角 —— 该盒内 chest 0 / gold_block 0 / blackstone 10。堡垒金源真实范围是 **x319..361 / y32..91 / z210..272**，盒子在 y 上也只盖到一半。',
        implication: '**S2 的金锭来源有着落**：14 块暴露金块 + 5 个箱子 + 42 块暴露鎏金黑石。F 线真正要解决的不是"有没有金"，而是"在猪灵密度最高的地方有没有金"。',
    },
    correctionCorroborationBox: {
        at,
        field: 'scout.corroboration.box',
        problem: '`box` 写 x320..351 / z240..271，但它自己列的 `goldBlockPoints` 跨 x322..361 / z217..265 —— **框和点互相矛盾**。',
        truth: '那一轮的 22/227/5 其实是在**更大的区**上做的：本单在 x224..431 / z160..367 上复核，得到**逐个相等**的 22/227/5。',
        action: '本单新增 `goldSources`（带 `window` 与 `coverageCheck`）作为权威口径；`corroboration` 原样保留作历史。',
    },
    evidence: 'bench/route/probe/s3_bastion_gold_piglins.peaceful.json#gold（254 条逐格坐标 + 暴露面）',
};

// ---------------------------------------------------------------- 猪灵
S3.scout.piglinsWorldgen = {
    at,
    by: '开发线 C · ROUND7-C 续单（存档解析器，只读）',
    question: '派单：世界生成时的猪灵实体分布（坐标、是否幼年），按 8×8 格网格统计密度',
    note: '这些是**世界生成时**就存在的猪灵（`PersistenceRequired = 1`，`NetherFortress` 生成时 `setPersistenceRequired()`）—— 不是加载后自然刷的。',
    peaceful: {
        total: calm.piglins.total, worldgen: calm.piglins.worldgen, nonWorldgen: calm.piglins.nonWorldgen,
        babies: calm.piglins.babies,
        adults: calm.piglins.worldgen - calm.piglins.babies,
        hoglins: calm.hoglins.length,
        agePositiveControl: calm.piglins.ageFieldPositiveControl,
        yRange: calm.piglins.boundary?.bbox?.y,
        bbox: calm.piglins.boundary?.bbox,
    },
    easy: easy ? {
        total: easy.piglins.total, worldgen: easy.piglins.worldgen, nonWorldgen: easy.piglins.nonWorldgen,
        babies: easy.piglins.babies, adults: easy.piglins.worldgen - easy.piglins.babies,
        difficultyInWorld: easy.difficulty ?? 'easy',
        bbox: easy.piglins.boundary?.bbox,
    } : null,
    difficultyAblation: easy ? {
        question: '难度会不会改变世界生成的猪灵数量/分布？',
        peacefulWorldgen: calm.piglins.worldgen, easyWorldgen: easy.piglins.worldgen,
        same: calm.piglins.worldgen === easy.piglins.worldgen,
        nonWorldgenOnEasy: easy.piglins.nonWorldgen,
        conclusion: calm.piglins.worldgen === easy.piglins.worldgen
            ? '**难度不影响世界生成的猪灵**：两份存档的 `PersistenceRequired=1` 猪灵数逐头相等 ⇒ 难度只影响"加载后自然刷新的"那部分（本单 easy 存档另有 ' + easy.piglins.nonWorldgen + ' 头非生成猪灵）。**做易物排班按世界生成分布即可，不必按难度改。**'
            : '⚠ 两份存档的世界生成猪灵数**不相等**（' + calm.piglins.worldgen + ' vs ' + easy.piglins.worldgen + '）—— 难度可能影响生成，结论待查。',
    } : { status: 'NOT_RUN', note: 'easy 存档未跑成，本条留空（F 线实测时可直接在真服上 `kill @e[type=piglin]` 复验）' },
    grid8x8: { cells: calm.grid8x8.cells, nonEmpty: calm.grid8x8.nonEmpty, top },
    discrepancyWithF: {
        note: '**与 F 线 MC-S2-01/03 的 28 头差 1**。两条都如实保留：存档是**世界生成后立刻 flush** 的真值（29）；F 线是**加载后**用 `kill @e[type=piglin]` 回执数的（28），其间可能有 1 头游出统计区或尚未加载。',
        rule: '手册 §5「取证动作要紧贴它要证明的时刻」—— 两个数**测的不是同一时刻**，不构成互相否证。',
    },
    evidence: 'bench/route/probe/s3_bastion_gold_piglins.peaceful.json#piglins（29 条逐头坐标 + 年龄 tag）',
};

// ---------------------------------------------------------------- 作业点
S3.scout.barterWorkPoints = {
    at,
    by: '开发线 C · ROUND7-C 续单（只给数据，F 线去实测）',
    criterion: calm.criteria,
    picks: calm.workPoints.picks,
    candidatesConsidered: calm.workPoints.candidates,
    reading: [
        '**`stand` 是站得住的空气格**（脚下实心 + 身体 2 格空气），`piglinWithin6` 是站位中心到猪灵 Pos 的 3D 欧氏距离 ≤6 的头数。',
        '**与 F 线实测的关系**：F 线 MC-S2-03 在 `[336,256]` 站位实测"3.4 格内最多 2 头"（596/596 样本）。本单存档显示**世界生成时**同一片可以到 3.4 格内 4 头 —— 差在**时刻**：生成时猪灵还聚在结构里，加载后它们会散开、也会被拉黑/被打死。⇒ **F 线的"最多 2 头"是稳态结论，不该用本单的生成态密度去推翻它**；本单的价值是指出"**还有更密的地方没试过**"。',
        '前两个作业点的金源是**箱子**（`stronghold`/`treasure` 型堡垒的箱子是开箱即得金锭的最短路径），第三个是鎏金黑石（要挖，会激怒 16 格内猪灵）。',
    ],
    notVerified: [
        '**未做寻路**：没有验这些站位从堡垒外能不能走到（没算门、没算走廊连通）。',
        '**未验站位在猪灵的实际行为下的可用性**：猪灵被打死/拉黑后会换位，密度会变。',
        '**未验开箱 loot**：箱子内容只有开箱时才生成，存档里读不出（与 S0b 村庄箱同一个限制）。',
    ],
    evidence: 'bench/route/probe/s3_bastion_gold_piglins.peaceful.json#workPoints',
};

// ---- 硬闸
if (JSON.stringify(S3.station) !== stationBefore) throw new Error('station 被改了 —— 违反派单');
if (JSON.stringify([route.frozenAt, route.sha256File]) !== frozenBefore) throw new Error('frozenAt/sha256File 被改了 —— 违反派单');

fs.writeFileSync(P, JSON.stringify(route, null, 2) + '\n');
console.log('S3 scout 已更新：');
console.log('  goldSources.counts =', JSON.stringify(S3.scout.goldSources.counts));
console.log('  覆盖检查 =', S3.scout.goldSources.coverageCheck.verdict.slice(0, 60) + '…');
console.log('  猪灵 peaceful =', calm.piglins.worldgen, 'worldgen /', calm.piglins.babies, '幼年');
console.log('  难度消融 =', S3.scout.piglinsWorldgen.difficultyAblation.status ?? (calm.piglins.worldgen === easy?.piglins.worldgen ? 'DONE' : 'NOT_RUN'));
console.log('  作业点 =', S3.scout.barterWorkPoints.picks.length, '个');
console.log('  station 逐字节不变 ✓  frozenAt/sha256File 不变 ✓');
