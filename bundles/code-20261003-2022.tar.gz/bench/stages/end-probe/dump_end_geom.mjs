// dump_end_geom.mjs — 一次性几何探针（不进产物）：连上泳道 C 的孤儿服，把中央岛的
// **真实断面** dump 出来。用途：定位「出口门柱到底在哪一格 Y、bot 落在什么上面」。
// 背景：SMOKE5 报 roofY=62，但 bot 站在 y=67——两者对不上，必须看原始方块。
//
// 用法：node dump_end_geom.mjs --port 25568 --username GeoProbe

import { createRequire } from 'module';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
const require = createRequire(path.join(ROOT, 'mindcraft-wt/end-probe', 'main.js'));
const { Vec3 } = require('vec3');
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const PORT = parseInt(arg('port', '25568'), 10);
const USERNAME = arg('username', 'GeoProbe');
const OUT = arg('out', path.join(HERE, 'runs', 'end_geom.json'));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const mineflayer = require('mineflayer');
const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: '1.16.1' });

bot.once('spawn', async () => {
    await sleep(3000);
    // 先把自己挪开中心（别占着要测的格子）
    const report = { at: null, columns: {}, dragon: null, portalFrame: [] };
    const p = bot.entity.position.floored();
    report.at = [p.x, p.y, p.z];

    const bAt = (x, y, z) => { try { const b = bot.blockAt(new Vec3(x, y, z)); return b ? b.name : null; } catch { return null; } };

    // 1) 中心十字断面：x=0 的 z=-6..6，和 z=0 的 x=-6..6，y 扫 55..75
    for (let y = 75; y >= 55; y--) {
        const rowZ = [], rowX = [];
        for (let d = -6; d <= 6; d++) { rowZ.push(bAt(0, y, d)); rowX.push(bAt(d, y, 0)); }
        if (rowZ.some((n) => n && n !== 'air') || rowX.some((n) => n && n !== 'air')) {
            report.columns[`y=${y}`] = { x0_z_minus6_to_6: rowZ, z0_x_minus6_to_6: rowX };
        }
    }
    // 2) 底下的基岩/传送门全扫（末地主岛可能有基岩层）
    const bedrock = [];
    for (let y = 80; y >= 0; y--) {
        for (let x = -8; x <= 8; x++) {
            for (let z = -8; z <= 8; z++) {
                const n = bAt(x, y, z);
                if (n === 'bedrock' || n === 'end_portal' || n === 'end_portal_frame' || n === 'end_stone_bricks') {
                    bedrock.push({ b: n, x, y, z });
                    if (bedrock.length > 400) break;
                }
            }
        }
        if (bedrock.length > 400) break;
    }
    report.portalFrame = bedrock;
    // 3) 脚下的块 + 眼下的块
    report.underFeet = bAt(p.x, p.y - 1, p.z);
    report.underFeet1 = bAt(p.x, p.y - 2, p.z);
    // 4) 龙
    for (const e of Object.values(bot.entities ?? {})) {
        if (e?.name === 'ender_dragon') {
            report.dragon = { pos: [+e.position.x.toFixed(1), +e.position.y.toFixed(1), +e.position.z.toFixed(1)], meta15: e.metadata?.[15], meta8: e.metadata?.[8] };
        }
    }
    const fs = await import('fs');
    fs.writeFileSync(OUT, JSON.stringify(report, null, 2));
    console.log(`at=${JSON.stringify(report.at)} underFeet=${report.underFeet} portalBlocks=${bedrock.length} dragon=${JSON.stringify(report.dragon)}`);
    console.log(`wrote ${OUT}`);
    bot.quit();
    setTimeout(() => process.exit(0), 500);
});
bot.on('error', (e) => { console.error('bot_error', String(e).slice(0, 200)); process.exit(1); });
setTimeout(() => { console.error('timeout'); process.exit(2); }, 90000);
