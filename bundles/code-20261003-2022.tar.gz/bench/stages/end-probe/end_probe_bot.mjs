// end_probe_bot.mjs — MC-END-01 探针执行机器人（standalone，单 bot 进程一个世界）
//
// 协议口径（与 basic-iron/fullrun 的 exec_bot 逐项对齐）：
//   - 零 LLM：不加载 prompter/history/self-prompt/dm_client（手册 §7，任务层不吃 MISSION 也不问模型）。
//   - 开发局允许 kit（验收协议 v3 §2）：kit 由 runner 走**服务器 stdin 控制台** give（手册 §2
//     明令「一律用服务器 stdin 发命令」，RCON 会毒化服务进程）。本 bot 只等 kit 到位，不自己造物品。
//   - 探针状态机与信号读取全部来自**任务层**（MC_MINDCRAFT_ROOT 指到 worktree mindcraft-wt/end-probe），
//     本文件只负责「连服 → 等 kit → 进末地 → 跑探针 → 落盘」。
//
// 用法（run_probe.mjs 自动拼好）：
//   node end_probe_bot.mjs --trial 1 --out <runDir> --port 25568 --username TaskBotC --mode kill

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
const MINDCRAFT = path.resolve(process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt/end-probe'));
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}

const TRIAL = parseInt(arg('trial', '0'), 10);
const SEED = arg('seed', 'unknown');
const OUT_DIR = arg('out', HERE);
const PORT = parseInt(arg('port', '25568'), 10);
const USERNAME = arg('username', 'TaskBotC');
const MODE = arg('mode', 'kill');                       // 'detect' | 'kill' | 'strafe' | 'easy'
const TIMEOUT_MS = parseInt(arg('timeout-ms', '300000'), 10);
const MC_VERSION = arg('mc-version', '1.16.1');
const HEAD_OFFSET_Y = parseFloat(arg('head-offset-y', '0'));
const HEAD_RANGE = parseFloat(arg('head-range', '4.3'));
const SETTLE_MS = parseInt(arg('settle-ms', '400'), 10);
const MAX_PERCH = parseInt(arg('max-perch', '10'), 10);
const PROBE_MS = parseInt(arg('probe-ms', '5000'), 10);
const WALK_TIMEOUT_MS = parseInt(arg('walk-timeout-ms', '90000'), 10);
// ---- 第二轮（MC-END-01 续单）----
const RIG_RADIUS = parseFloat(arg('rig-radius', '3'));
const RIG_ANGLE = parseFloat(arg('rig-angle', '0'));
const GATE_RANGE = parseFloat(arg('gate-range', '12'));
const USE_GROUND_RIG = !process.argv.includes('--no-ground-rig');
const RIG_PRESET = arg('rig-preset', '');
const RIG_STAND_TP = arg('rig-stand-tp', '');
const E2_BUILD = (arg('e2-build', '') || '').split(',').map((s) => s.trim()).filter(Boolean).map((s) => s.split(':').map(Number));
const E2_CELLS = (arg('e2-cells', '') || '').split(',').map((s) => s.trim()).filter(Boolean).map((s) => s.split(':').map(Number));
const E2_TOP_Y = parseInt(arg('e2-top-y', '67'), 10);
const E2_STAND = arg('e2-stand', '');
const RIG_SCHEDULE = (arg('rig-schedule', '') || '').split(',').map((s) => s.trim()).filter(Boolean).map((s) => { const [r, a] = s.split(':'); const an = Number(a); return { r: /^\d+(\.\d+)?$/.test(r) ? Number(r) : r, a: Number.isFinite(an) ? an : 0 }; });

const TELEMETRY = path.join(OUT_DIR, 'telemetry.jsonl');
const RESULT = path.join(OUT_DIR, 'result.json');
const LOG = path.join(OUT_DIR, 'bot.log');
const PROBE = path.join(OUT_DIR, 'probe.jsonl');
const READY = path.join(OUT_DIR, 'bot_ready.json');

fs.mkdirSync(OUT_DIR, { recursive: true });
const logLine = (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(LOG, line + '\n'); } catch { /* 忽略 */ }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let finished = false;
let _probeTimer = null;
let hardKillRef = null;

function tele(event, data) {
    const rec = JSON.stringify({ t: Date.now(), event, ...data });
    try { console.log(`[probe] ${rec}`); } catch { /* 忽略 */ }
    try { fs.appendFileSync(TELEMETRY, rec + '\n'); } catch { /* 遥测失败不影响主循环 */ }
}

function finish(status, payload) {
    if (finished) return;
    finished = true;
    clearInterval(_probeTimer);
    clearTimeout(hardKillRef);
    const body = { status, trial: TRIAL, seed: SEED, mode: MODE, ...payload };
    try { fs.writeFileSync(RESULT, JSON.stringify(body, null, 2)); } catch { /* 忽略 */ }
    logLine(`finish: ${status}`);
    setTimeout(() => process.exit(status === 'KILL' || status === 'PERCHES_DONE' ? 0 : 1), 300);
}

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const { runEndProbe } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/end_probe.js')).href);
    const { countBeds } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/bed_bomb.js')).href);
    const { readDragon } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/dragon_signal.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
    bot.loadPlugin(pf.pathfinder);

    hardKillRef = setTimeout(() => finish('RUNNER_TIMEOUT', { failReason: `timeout>${TIMEOUT_MS}ms` }), TIMEOUT_MS + 60000);
    bot.on('kicked', (r) => finish('KICKED', { reason: String(r) }));
    bot.on('error', (e) => { logLine(`bot_error: ${String(e).slice(0, 200)}`); if (!finished) finish('CONNECT_FAIL', { reason: String(e).slice(0, 140) }); });
    bot.on('end', () => finish('DISCONNECTED', { note: 'server closed' }));

    bot.once('spawn', async () => {
        try {
            await sleep(4000);   // 世界落定（basic-iron 同款）
            logLine(`spawn: seed=${SEED} dim=${bot.game?.dimension} pos=${JSON.stringify(bot.entity.position.floored())}`);

            // ---- 等 kit（runner 走控制台 give）----
            const kitT0 = Date.now();
            let beds = 0;
            while (Date.now() - kitT0 < 60000) {
                beds = countBeds(bot);
                if (beds > 0) break;
                await sleep(500);
            }
            if (beds <= 0) { finish('NO_KIT', { failReason: '60s 内没收到床' }); return; }
            logLine(`kit 就位：床×${beds}（等 ${((Date.now() - kitT0) / 1000).toFixed(1)}s）`);
            fs.writeFileSync(READY, JSON.stringify({ ready: true, beds, at: new Date().toISOString() }));
            // blast 模式要用：**别把 bot 传到远处**，平台就地建在它脚下上方（run_probe.mjs 会读这个文件）
            try {
                const p0 = bot.entity.position;
                fs.writeFileSync(path.join(OUT_DIR, 'bot_pos.json'), JSON.stringify({ x: p0.x, y: p0.y, z: p0.z }));
            } catch { /* 忽略 */ }

            // ---- 等 runner 把我们 tp 进末地（由 bot_ready.json 触发）----
            // 判定口径：**不**只看 bot.game.dimension——SMOKE3 实测死亡重生回主世界后，
            // 客户端的 dimension 字符串仍带着 'end'，用它判会以为还在末地、然后在主世界里
            // 空等 90s。末地是唯一有龙的地方，所以直接等龙出现即可（runEndProbe 里等 90s）。
            logLine(`当前 dim=${bot.game?.dimension}，等 runner 把我们投进末地（随后等龙出现）`);

            // ---- 探针期进度探针（runner 侧无进展中止也读它）----
            try { fs.rmSync(PROBE, { force: true }); } catch { /* 忽略 */ }
            _probeTimer = setInterval(() => {
                try {
                    const d = readDragon(bot, { headOffsetY: HEAD_OFFSET_Y });
                    const p = bot.entity?.position;
                    fs.appendFileSync(PROBE, JSON.stringify({
                        t: Date.now(), event: 'end_probe',
                        inv: bot.inventory.items().map((i) => `${i.name}:${i.count}`).sort().join(','),
                        pos: p ? [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)] : null,
                        hp: bot.health, food: bot.food, dim: bot.game?.dimension ?? null,
                        dragon: d.found ? { y: d.pos[1], hp: d.health, phase: d.phaseName, perch: d.isPerch } : null,
                        crystals: Object.values(bot.entities ?? {}).filter((e) => e?.name === 'end_crystal').length,
                    }) + '\n');
                } catch { /* 探针失败不影响主流程 */ }
            }, PROBE_MS);
            _probeTimer.unref?.();

            // ---- 落点 ----
            // 默认**不再自己走到中央岛**：SMOKE3 实测，1.16.1 走完那 100 格（35s）会被龙打死
            // （server.log:「TaskBotC was killed by Ender Dragon using magic」），死亡重生回主世界，
            // 探针就再也等不到龙。走到主岛测的是**接近段保命能力**，不是床爆可行性——那部分
            // 归 stage-06 S2 的安全网（骨头/水桶/末地石掩体），本单不测。
            // runner 直接把 bot tp 到中央岛上方（同样是任务单 §3 授权的控制台布景）。
            // 需要复现"从落点走到中央岛"时用 --walk-center 打开。
            const walkT0 = Date.now();
            let walked = false;
            if (process.argv.includes('--walk-center')) {
                try {
                    bot.pathfinder.setMovements(new pf.Movements(bot));
                    const g = new pf.goals.GoalNear(0, 4, 0, 3);
                    bot.pathfinder.setGoal(g);
                    await Promise.race([bot.pathfinder.goto(g).catch(() => {}), sleep(WALK_TIMEOUT_MS)]);
                    try { bot.pathfinder.stop(); } catch { /* 忽略 */ }
                    const p = bot.entity.position;
                    walked = Math.hypot(p.x, p.z) < 6;
                } catch (e) { logLine(`walk_threw: ${String(e).slice(0, 120)}`); }
            }
            const walkMs = Date.now() - walkT0;
            const here = bot.entity.position.floored();
            logLine(`落点：${walked ? '走到中央岛' : '控制台直投'} pos=${JSON.stringify(here)} dim=${bot.game?.dimension} (${(walkMs / 1000).toFixed(1)}s)`);
            tele('at_center', { ok: walked, ms: walkMs, pos: [here.x, here.y, here.z], dim: bot.game?.dimension ?? null });

            // ---- 爆心判别实验（--mode blast）：主世界高空平台，不进末地 ----
            if (MODE === 'blast') {
                const { runBlastProbe } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/blast_origin.js')).href);
                let plan = null;
                try { plan = JSON.parse(fs.readFileSync(path.join(OUT_DIR, 'blast_plan.json'), 'utf8')); } catch { plan = null; }
                for (let i = 0; i < 60 && !plan; i++) { try { plan = JSON.parse(fs.readFileSync(path.join(OUT_DIR, 'blast_plan.json'), 'utf8')); } catch { plan = null; } if (!plan) await sleep(500); }
                const r = await runBlastProbe(bot, {
                    plan,
                    y: plan ? plan.py : parseInt(arg('blast-y', '100'), 10),
                    half: parseInt(arg('blast-half', '7'), 10),
                    telemetry: tele, log: logLine,
                });
                finish(r.status === 'DONE' ? 'BLAST_DONE' : 'BLAST_FAIL', { blast: r });
                return;
            }

            // ---- 跑探针 ----
            const metrics = await runEndProbe(bot, {
                mode: MODE,
                timeoutMs: TIMEOUT_MS,
                headOffsetY: HEAD_OFFSET_Y,
                headRange: HEAD_RANGE,
                settleMs: SETTLE_MS,
                maxPerchEpisodes: MAX_PERCH,
                useGroundRig: USE_GROUND_RIG,
                rigRadius: RIG_RADIUS,
                rigAngleDeg: RIG_ANGLE,
                gateRange: GATE_RANGE,
                rigSchedule: RIG_SCHEDULE,
                rigPreset: RIG_PRESET || null,
                e2Build: E2_BUILD, e2Cells: E2_CELLS, e2TopY: E2_TOP_Y,
                e2Stand: E2_STAND ? (() => { const p = E2_STAND.split(' ').map(Number); return { x: p[0], y: p[1], z: p[2] }; })() : null,
                rigStandTp: RIG_STAND_TP || null,
                pfGoals: pf.goals,
                pfMovements: pf.Movements,
                telemetry: tele,
                log: logLine,
            });
            finish(metrics.status === 'KILL' ? 'KILL' : metrics.status, {
                walkMs, walkOk: walked, metrics,
            });
        } catch (e) {
            logLine(`fatal: ${String(e && e.stack ? e.stack : e).slice(0, 800)}`);
            finish('FAILED', { failReason: 'INTERNAL', error: String(e).slice(0, 300) });
        }
    });
}

main().catch((e) => { console.error(String(e)); process.exit(1); });
