# HANDOFF · 开发线 E（末地探针 end-probe）→ 移交云端泳道 X

> 交出方：本地开发线 E 会话（2026-10-02 下午）。接收方：云端泳道 X（Debian 12 / 2 vCPU / 3GB / 无 swap，
> 见 `bench/cloud/CLOUD-01-任务单.md`；**耗时不与本地比**）。
> 权威报告：`docs/MC-END-01-2.md`（**§0 是两条自我更正表，先看它**）。
> 本文件只回答四件事：**做到哪 / 哪些没验证 / 下一步跑什么 / 有哪些坑**。

---

## 0. 三十秒版本

| 问 | 答 |
|---|---|
| 这一轮改了什么结论 | **两条**：① 末地床爆的**爆心在「床的枕头半格」**，不在玩家 ⇒ 打法是「床贴龙头 1~2 格引爆」；② `DragonHoldingPatternPhase.findNewTarget` 的**追击目标是「门柱附近最近的玩家」**，不是末影水晶 |
| 两条结论的可信度 | **字节码侧已定论**（逐变量来源见报告 §2.4 / §2.5）；实验侧拿到**一路**干净证据（爆坑），**另一路（自身掉血）仍失效** |
| 最重要的欠账 | **龙头 E2（n≥5）** —— 没有它就定不了"4~5 张床"预算能不能成立 |
| 代码状态 | 两个仓库都已 commit，**工作区干净**；**都没 push**（见文末「待推送」） |
| 有没有跑完的在跑进程 | **没有**。`E2C` 在定位出 `occluded` 之后提前停掉了（每一轮都必然失败，留着只是白占泳道 C）；它的诊断写在 §2.3 |

---

## 1. 提交状态（都已 commit，工作区干净）

| 仓库 | 分支 | 本轮提交 | 内容 |
|---|---|---|---|
| `mindcraft-wt/end-probe` | `aidqq/end-probe` | `6c59a72` `eb45b7d` `1900517` `f5e48e4` | `perch_window.js`（新增）、`blast_origin.js`（新增）、`bed_bomb.js`、`end_probe.js`、`dragon_signal.js` |
| `bench` | 当前默认分支 | `b02aba6` `f79f619` `949066f` `6f68889` `e41d014` | `stages/end-probe/{run_probe.mjs,end_probe_bot.mjs,selftest.mjs,run_e2_chain.ps1,analysis/javap/*}` |

**共享文件零改动**（手册 §9）：只 import `place.js` 已导出的 `isSolidBlock`；`_lib/` 未动；
未碰 `mindcraft/` 主目录、其他 worktree、`server/`、`production/`、`episodes/`、key、LLM。
`bench/` 的提交只带 `stages/end-probe/` 自己的文件（手册 §9.2「提交只带自己的文件」）。

**离线自测**：`node bench/stages/end-probe/selftest.mjs` → **85/85**（迁移到云端后第一件事先跑它）。

---

## 2. 当前做到哪（含未验证项）

### 2.1 已完成且有数据

| 项 | 状态 | 数据在哪 |
|---|---|---|
| 有视线的对照实验（派单 item ②） | ✅ | 420 s 内追击退出 14 次 / 栖息 8 次 / 漏判 0 / 间隔中位 13.2 s ⇒ `runs/STRAFE1/` |
| 栖息判定准确率（16 次、1–61 ms、漏判 0） | ✅ 达标 | `runs/STRAFE1/`、`runs/STRAFE_B/` |
| **爆心在床（字节码定论）** | ✅ | 报告 §2.4（`analysis/javap/bvm_BedBlock.txt` 偏移 0-157） |
| **爆心的实验证据（爆坑这一路）** | ✅ 一路 | `runs/BLAST9/`：两臂里唯一被毁的方块是床自己的两半，质心落在床头半格 0.5 格；bot 脚下那格毫发无损 |
| **B3 更正（目标=玩家）** | ✅ | 报告 §2.5（`analysis/javap/bai.txt` 偏移 17-208） |
| 爆心的**另一路**（bot 自身掉血） | ❌ **失效** | BLAST8/9/10 三局都读到 0（20→20），**分不清是"没掉血"还是"读数坏了"** |

### 2.2 未完成 / 未验证（**别当成已完成**）

| 项 | 状态 | 卡在哪 |
|---|---|---|
| **龙头 E2（n≥5）** | ❌ **没有数字** | `mode=e2` 原语已就位（`end_probe.js` + `headBedCycle`），`runs/E2C/` 是最后一跑。**它把最后一个几何障碍定位出来了（见 §2.3）**，改完就能出数 |

### 2.3 龙头 E2 现在只差"机位几何"这一步（E2C 实测结论，直接照做）

E2C（`runs/E2C/`，收尾时已提前停）把失败原因收敛到**一条**，其余全通了：

1. 巡航期立柱搭好（5/5 成功，顶面 y=67）✅
2. 龙栖息后**支撑被龙的爆炸弹炸掉** ⇒ `ensureColumn()` 随爆随补，**不再报 `ref_not_solid`** ✅
3. **但补好之后放床必报 `occluded`** ❌ —— 原因是**自己搭的柱子挡住了自己的视线**：
   bot 站在坑底 `(1,63,0)`，眼睛在 y≈64.6；床在 `(2,67,0)`，而它的"顶面参照"要从眼睛打射线过去，
   射线正好穿过我们自己刚补的 `(2,65,0)`/`(2,66,0)` 两块圆石 ⇒ `placeExact` 的 `faceVisible` 正确地拒绝了。
   ⇒ **1 格宽的柱子天生放不上顶面的床**（原版 4.5 格伸手 + 视线判定，不是"够不着"那么简单）。

**⇒ 下一版机位应该是"2 格宽的平台"**：在坑内搭 **两格相邻**的 y=67 平台，
bot 站在其中一格、**床放另一格**（同高 ⇒ 视线水平、没有遮挡），床的枕头半格就是爆心。
跨维度的 `execute in minecraft:the_end run tp` **不会**触发本地那个"客户端坐标失步"的问题（§4-1），
所以让 runner 把 bot 投到台顶是可行的（`--rig-stand-tp "3 68 0"` 这类；本轮已验证 End 的 tp 正常）。

**床位表建议**（坑内、离门柱 2~3 格、y=67，成对相邻）：
`(3,67,0)+(3,67,1)`、`(0,67,3)+(1,67,3)`、`(0,67,-3)+(1,67,-3)`、`(3,67,-1)+(3,67,-2)` ……
每对里一格站人、一格放床；命中哪一格由实测伤害决定（`blastToHeadEst` 最小的那格）。
| 爆心判别的"两侧读数齐全" | ❌ | 掉血通道已改成订阅 `health` 事件流并落时间戳（commit `f5e48e4`），**未实跑验证**；`verdictOf()` 会因该通道无读数而拒绝下结论 |
| 两种站位各 ≥3 局 | ❌ 未跑 | 现有 n=1 vs n=1（132 s / 95 s），且同配置出现过 330 s 零栖息 |
| 整条龙 5 局 ≥3 杀 | ❌ 未跑 | 依赖龙头 E2 的结果 |
| easy 观察 2 局 | ❌ 未跑 | 上一轮就顺延 |

---

## 3. 下一步该跑的命令

前置（云端）：先 `node bench/stages/end-probe/selftest.mjs`（85/85），再按 `bench/cloud/CLOUD-01-任务单.md`
在泳道 X 上设好 `MC_MINDCRAFT_ROOT`（指向 cloud 侧 checkout 的 worktree）/`MC_BENCH_SERVER`/`MC_BENCH_JAR`。

```powershell
$env:MC_MINDCRAFT_ROOT = '<cloud>/mindcraft-wt/end-probe'
$env:MC_BENCH_SERVER   = '<cloud>/experiments/mc1161-gate/server-1161'
$env:MC_BENCH_JAR      = 'server-1.16.1.jar'
$node = '<cloud>/.runtime/node-v20.20.2-win-x64/node.exe'    # 或云端 node
```

**① 先把龙头 E2 跑出数字（最高优先）**
```powershell
& $node bench\stages\end-probe\run_probe.mjs --mode e2 --trials 1 --stamp E2D --god-mode `
    --tp '1 70 0' --crystal-janitor none --clear-on-first-perch `
    --e2-build '2:0,0:2,0:-2,2:1,1:2' --e2-top-y 67 `
    --e2-cells '2:67:0,0:67:2,0:67:-2,2:67:1,1:67:2' --e2-stand '1 63 0' `
    --kit 'red_bed:12,cobblestone:64,cooked_beef:16,golden_apple:4' `
    --gate-range 14 --timeout-ms 660000
```
- 要看的：`runs/<STAMP>/telemetry.jsonl` 里的 `head_bomb` 事件（每条含 `blastCenter` / `blastToDragonBody` /
  `blastToHeadEst` / `damage`），以及 `summary.jsonl` 的 `metrics.e2.damagePerBomb`。
- **n≥5 的判据**：`damagePerBomb` 至少 5 个非空值。
- 若某格反复 `bed_place_fail` / `support_missing`：说明该格的支撑被龙炸掉后补不回来（够不着），
  把该格从 `--e2-cells` 去掉，或换到坑内更近的格。

**② 爆心判别补"两侧读数齐全"（掉血通道修好后）**
```powershell
& $node bench\stages\end-probe\run_probe.mjs --mode blast --trials 1 --stamp BLAST11 `
    --timeout-ms 180000
```
- 判据在 `result.json → blast.verdict`：**只有 `BED_CENTERED` / `PLAYER_CENTERED` 才算成功**；
  `INCONCLUSIVE` 就去看 `arms[].hpEvents`（`health` 事件流）判断是"真没掉血"还是"通道还没活"。

**③ 两种站位各补到 ≥3 局**（各 3 局，串行；每局约 8~11 min）
```powershell
# (a) 门柱附近·保持视线：bot 站在门柱外沿，全程不动
& $node bench\stages\end-probe\run_probe.mjs --mode strafe --trials 1 --stamp POSa<N> --god-mode `
    --tp '3 70 0' --crystal-janitor none --timeout-ms 420000
# (b) 64 格外盘旋 + 降落 5s 内进 20 格
& $node bench\stages\end-probe\run_probe.mjs --mode strafe --trials 1 --stamp POSb<N> --god-mode `
    --tp '3 70 0' --park-tp '80 64 0' --park-fill 'fill 78 63 -3 82 63 3 minecraft:end_stone' `
    --come-in-on-landing --crystal-janitor none --timeout-ms 420000
```
- 指标：`metrics.perchGapsMs`（相邻两次栖息开始的间隔）与**到首次栖息的时间**（龙出现 → 第一个 `perch_begin`）。
- ⚠ 现有 n=1 的方差极大（132 s / 95 s / 330 s 零栖息）⇒ **n≥3 之前不要下结论**。

**④ 有了龙头 E2 再跑整条龙 5 局 ≥3 杀**
```powershell
& $node bench\stages\end-probe\run_probe.mjs --mode kill --trials 5 --stamp KILL6 --god-mode `
    --tp '1 70 0' --crystal-janitor none --clear-on-first-perch `
    --e2-build '2:0,0:2,0:-2,2:1,1:2' --e2-top-y 67 --e2-stand '1 63 0' `
    --kit 'red_bed:12,cobblestone:64,cooked_beef:16,golden_apple:4' `
    --gate-range 14 --timeout-ms 660000
```
（把 `mode kill` 换成 `mode e2` 就是龙头 E2 的多局版；`--trials N` 串行跑 N 局。）

**长持锁怎么起（手册 §9.2）**：`bench/stages/end-probe/run_e2_chain.ps1` 是一个"独立进程串跑"的样板
（`Start-Process` + `-NoProfile -ExecutionPolicy Bypass -File`）；**不要把长跑挂在会话后台任务上**
（后台任务 3600 s 硬上限，到点被杀但锁文件还留着、且没有任何告警）。

---

## 4. 已知的坑（每条都踩过，附现象→结论）

**布景/传送**
1. **1.16.1 同维度 `tp` 会让客户端坐标失步**：服务端明确回 `Teleported …`，客户端仍认为自己在原地，
   服务端持续刷 `moved too quickly!`；要访问的小节/高度全对不上（BLAST1~8 八局全灭在这条链上）。
   ⇒ **同维度不要远距传送**；跨维度的 `execute in <dim> run tp` 不受影响。判据要靠
   `bot.entity.position` / `blockAt`，**不能只看 server.log 的 `Teleported`**。
2. **控制台 `/fill` 落地很慢**：BLAST9 里等 **41.6 s** 才在客户端读到 `dirt`；BLAST8 的就绪探针读到的还是
   `grass_block` 就开测 ⇒ 那 247 格"爆坑"其实是**迟到的 `/fill`**。就绪闸门要
   **等到目标方块真的变成目标名**（`waitPlatform(..., want:'dirt')`）。
3. **别查 bot 自己脚下那一格**：客户端不会重新读自己脚下的小节（BLAST10：45 s 都不更新）。查旁边一格。
4. **布景坐标只能有一个真源**：runner 建、bot 查，两边各写一份必错（本轮因此白跑一局）。现在用 `blast_plan.json` 传递。
5. **布景开关的注释要连着"它成立的那条机制 + 类.方法·偏移"**：上一轮的"远端停泊 >128 格破 STRAFE 锁"
   建立在错误前提上（`findNewTarget` 根本不找玩家），照着它排期会一直踩。

**读数**
6. **实体元数据必须做合并缓存**：prismarine 的 `entity.metadata` 按包**整份替换**，而包是稀疏的 ⇒
   下一包只带相位时 `md[8]` 变 `undefined` ⇒ E2 从第二张床起整条空掉。已按实体 id 缓存 + `healthStale` 标记。
7. **`entity.position` 是普通对象**，没有 `distanceToSquared`（本轮踩到，一个火球就把探针打挂）。
8. **冷启动闸门**：`DATA_PHASE` 的初值是 `bas.k` = `HOVERING(10)`（不是 0、也不是 STRAFE_PLAYER(1)）。
   第一条龙的元数据事件到达前，相位只记不判。
9. **读混淆名必须先解析回官方类**（本轮最贵的一条）：我因为把 `fu` 当 Player、`cio$a` 当 EntityType，
   连续报错两条结论。工作区有现成工具：`docs/research/data/mappings-1161/resolve.ps1`、`findm.ps1`。

**玩法/机制（已在字节码层面定论，可直接当前提用）**
10. **爆心 = 床的枕头半格 + (0.5,0.5,0.5)**，威力 5.0，玩家位置无关（`bvm.a` 偏移 117/126/135 取自局部槽 3 的 `BlockPos`）。
    ⇒ 打法：**床贴龙头 1~2 格**；站位只管"够不够得着点床"和"自己会不会吃到自己的爆炸"。
11. **龙栖息时喷的爆炸弹会破坏方块** ⇒ 巡航期搭好的床柱到引爆时常常已被炸掉（本轮 E2A 连续 `ref_not_solid`）。
    ⇒ `ensureColumn()` 每次引爆前把支撑自下而上补齐。
12. **爆炸对单个实体的伤害** = `((f·7+f²)/2)·radius+1`，`f=(1−d/radius)×seen`；**非龙头部位再变成
    `amount/4 + min(amount,1)`**（`bac.a` 偏移 43-53，**少抄那个 `Math.min` 就会差 4 倍**）。
13. **`STRAFE_PLAYER` 只有 2 个 `setPhase` 出口**（目标为空 / 开出火球），攒火球硬闸 =「≤64 格 + `canSee(目标)`
    + 蓄满 5 + 瞄准 10°」，**无超时** ⇒ 目标看不见/够不着时它会一直卡着，落地骰子（只在持机模式里投）也就永远不出现。
14. **末地出口结构实测断面**（`runs/KILLGOD/trial_01/telemetry.jsonl` 的 `portal_geom.columnDump`）：
    中心柱 **1×1**、bedrock 到 y=66（顶面 67）；四周是 1 格深的坑（坑底 y=62）；半径 3 处 bedrock 顶面 64；
    **y=65 的 (±1,0)/(0,±1) 是 `wall_torch`** ⇒ 想在 x=±1 立柱会被 `dest_occupied` 挡住。

**协议/工程**
15. **`lookAt(point, true)` 不发旋转包**（手册 §3）⇒ 服务端按旧朝向判 `use_item_on`、**静默拒收**。
    `detonate()` 已改 `force=false`；这是上一轮"床点不爆"的隐形原因之一。
16. **同一条泳道会被别的开发线借走**：`waitForLaneC()` 会按心跳排队等它退出，**不抢**。长跑会被别人插队
    （本轮多次排队 2~10 分钟），排期时给足 `--lane-wait-s`。

---

## 5. 云端注意

- 本地开发线 E 用的**本地泳道 C 已让出**（`handover/minecraft.md` 的泳道分配：泳道 X 通过后 E 迁 X）。
- 云端 2 vCPU / 3GB：每局服务器 + bot 的内存比本地紧，`preflight` 的 `waitFreeMem(<2560MB)` 排队会更容易触发；
  本轮本地 3 泳道并行时出现过 `free<2.5GB` 排队，**云端建议单线串行**。
- `.lane-owners/` 在 `.gitignore` 里，**云端第一次跑要重新登记**；`preflight` 会因为"别人的进程"只报告不处置。
