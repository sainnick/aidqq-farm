$ErrorActionPreference = 'Continue'
$root = 'D:\AI斗蛐蛐'
Set-Location $root
$env:MC_MINDCRAFT_ROOT = "$root\mindcraft-wt\end-probe"
$env:MC_BENCH_SERVER = "$root\experiments\mc1161-gate\server-1161"
$env:MC_BENCH_JAR = 'server-1.16.1.jar'
$node = "$root\.runtime\node-v20.20.2-win-x64\node.exe"
$probe = "$root\bench\stages\end-probe\run_probe.mjs"
$log = "$root\bench\stages\end-probe\runs"


# ② 龙头 E2：坑内建一圈柱子（顶面 y=67，与龙实体 y≈66.9 同高），逐张引爆
Write-Output '=== E2B e2 (支撑随爆随补) ==='
& $node $probe --mode e2 --trials 1 --stamp E2C --god-mode --tp '1 70 0' --crystal-janitor none `
    --clear-on-first-perch --e2-build '2:0,0:2,0:-2,2:1,1:2' --e2-top-y 67 `
    --e2-cells '2:67:0,0:67:2,0:67:-2,2:67:1,1:67:2' --e2-stand '1 63 0' `
    --kit 'red_bed:12,cobblestone:64,cooked_beef:16,golden_apple:4' `
    --gate-range 14 --timeout-ms 660000 --lane-wait-s 900 *>&1 |
    Out-File -FilePath "$log\E2C_console.log" -Encoding utf8
Get-Content "$log\E2C_console.log" -Tail 3
Write-Output '=== chain done ==='
