// run_probe.mjs — MC-END-01 探针 runner（开发线 E，**只用泳道 C**，与开发线 C 按心跳排队共用）
//
// 为什么不复用 _lib/runner_core.mjs 的 runMatrix()：那套的语义是「一个 trial = 一个 fresh world +
// 一个 MISSION」（走任务层 MISSION 规划）。本单探针不吃 MISSION——它是一段**手写的末地控制流程**
// （tp 进末地 → 等龙 → 判栖息 → 床爆），走 runMatrix 会被任务层规划器拦在门口。所以编排层自写，
// 只复用 _lib 已导出的原子能力（freshWorld / bootServerWithRetry / stopServer / waitFreeMem /
// preflight / cleanup / injectKit），与 fullrun 的分工同构。
//
// 泳道纪律（手册 §9 + 任务单 §3）：
//   - **只有 C**（25568/25578，目录 experiments/mc1161-gate/server-1161_laneC）。自带 ensureLaneC()
//     只碰 _laneC 一个目录（不调 buildLanes——那会连带改写 B 目录的 server.properties）。
//   - 端口自检：preflight 按**名**选泳道（laneNames:['C']，06d P0 修好的按名选择），外加
//     assertLaneCPortsFree() 兜底；被别的会话占着就排队等心跳空出来，**不抢、不杀别人的进程**。
//   - 内存护栏：每局开服前 waitFreeMem(<min-free-mb>)，不够就排队，不降阈值。
//
// 1.16.1 环境（手册 §2 血泪：默认值是 1.21.1，漏带会起 1.21 Paper）：
//   MC_BENCH_SERVER / MC_BENCH_JAR=server-1.16.1.jar / MC_BENCH_JAVA / --mc-version 1.16.1
//   MC_MINDCRAFT_ROOT → **worktree mindcraft-wt/end-probe**（本单的任务层代码在那儿，不在 mindcraft/）
//
// 用法：
//   node run_probe.mjs --selftest
//   node run_probe.mjs --plan-only --mode detect --trials 1
//   node run_probe.mjs --mode detect  --trials 1 --stamp EP_DETECT
//   node run_probe.mjs --mode kill    --trials 5 --stamp EP_KILL
//   node run_probe.mjs --mode easy    --trials 2 --stamp EP_EASY

import { spawn, spawnSync } from 'child_process';
import os from 'os';
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { argOf, log, killTree, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, injectKit } from '../_lib/runner_core.mjs';
import { preflight, netstatListeners, ownerTable, OWNER_FRESH_MS, liveOwnerPids } from '../_lib/preflight.mjs';
import { cleanup, installRunnerHooks } from '../_lib/cleanup.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
const NODE20 = path.join(ROOT, '.runtime', 'node-v20.20.2-win-x64', 'node.exe');
// 任务层指向**本线的 worktree**（任务单 §2：探针实现改在 mindcraft-wt/end-probe）
const MINDCRAFT = path.resolve(process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt/end-probe'));

const TEMPLATE_DIR = path.resolve(process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161'));
const LANE = { name: 'C', idx: 2, dir: `${TEMPLATE_DIR}_laneC`, serverPort: 25568, rconPort: 25578, username: 'TaskBotC' };
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const JAVA = process.env.MC_BENCH_JAVA || (() => {
    const jdkRoot = path.join(ROOT, 'experiments', 'mc1161-gate', 'jdk');
    const hit = fs.readdirSync(jdkRoot).find((d) => fs.existsSync(path.join(jdkRoot, d, 'bin', 'java.exe')));
    if (!hit) throw new Error('找不到便携 JDK11：experiments/mc1161-gate/jdk/*/bin/java.exe（手册 §2）');
    return path.join(jdkRoot, hit, 'bin', 'java.exe');
})();
const MC_VERSION = argOf(process.argv, 'mc-version', '1.16.1');

const MODE = argOf(process.argv, 'mode', 'kill');                    // 'detect' | 'kill' | 'easy' | 'strafe'
const RUNSTAMP = argOf(process.argv, 'stamp', `EP_${MODE}_${new Date().toISOString().slice(0, 13).replace(/[-T:]/g, '')}`);
const TRIALS = parseInt(argOf(process.argv, 'trials', '1'), 10);
const START = parseInt(argOf(process.argv, 'start', '1'), 10);
const SEED_LITERAL = argOf(process.argv, 'seed', '-8839485814800629942');   // 主种子（几何与龙无关，但口径统一）
const PROBE_TIMEOUT_MS = parseInt(argOf(process.argv, 'timeout-ms', MODE === 'detect' ? '600000' : '420000'), 10);
const NO_PROGRESS_S = parseInt(argOf(process.argv, 'no-progress-s', '0'), 10);   // 0 = 关（末地是长等待，签名会长时间不变）
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const SERVER_XMX = argOf(process.argv, 'server-xmx', '1G');
const PROBE_MS = parseInt(argOf(process.argv, 'probe-ms', '5000'), 10);
const HEAD_OFFSET_Y = argOf(process.argv, 'head-offset-y', '0');
const HEAD_RANGE = argOf(process.argv, 'head-range', '4.3');
const SETTLE_MS = argOf(process.argv, 'settle-ms', '400');
const MAX_PERCH = parseInt(argOf(process.argv, 'max-perch', MODE === 'detect' ? '10' : '99'), 10);
const WALK_TIMEOUT_MS = parseInt(argOf(process.argv, 'walk-timeout-ms', '90000'), 10);
const DIFFICULTY = argOf(process.argv, 'difficulty', MODE === 'easy' ? 'easy' : 'peaceful');
const KIT = argOf(process.argv, 'kit', MODE === 'blast' ? 'red_bed:2' : 'red_bed:12,cobblestone:48,cooked_beef:16,stone_sword:1');
const JANITOR_MS = argOf(process.argv, 'crystal-janitor', '1500');   // 'none' = 关
const TP_TARGET = argOf(process.argv, 'tp', '0 70 0');   // 交战落点（中央岛上方，末地主岛顶面实测 y≈66）
// 停泊点：放在 **>128 格外**。这是本单最关键的布景开关——
// `DragonHoldingPatternPhase.findNewTarget()` 只在 128 格内找到玩家时才切 STRAFE_PLAYER，
// 而 `DragonStrafePlayerPhase.doServerTick()` 的**唯一出口是 player==null**；落地骰子
// `nextInt(3+水晶数)==0` 只在 HOLDING_PATTERN 里投。⇒ bot 一直在末地中央 = 龙被锁死、永不栖息
// （DETECT1 实测 4.7 分钟 56 次采样全在 STRAFE_PLAYER）。停泊到远处让骰子能投，
// 判到栖息再由控制台把 bot 投到门柱引爆。
const PARK_TP = argOf(process.argv, 'park-tp', '');     // 空 = 不启用远端停泊（沿用 --tp）
// ⚠⚠ 上一轮那条注释的依据（"findNewTarget 只在 128 格内找玩家"）已被本轮字节码核验**推翻**：
// `DragonHoldingPatternPhase.findNewTarget()`（javap bai 偏移 17-208）找的是 **END_CRYSTAL**
// （`bqb.a(cio$a.f, fu)`，cio$a.f = 末影水晶 EntityType），**从来不找玩家**；玩家只有在
// `onCrystalDestroyed(..., player)` 里才被 `strafePlayer`。所以"停泊到远处让龙投落地骰子"
// 这条布景是**建立在错误前提上的**——真正需要的是"龙不在 STRAFE_PLAYER 里"。
// 远端停泊反而更糟：`DragonStrafePlayerPhase.doServerTick()` 偏移 206-225 有一道 64 格距离门，
// bot 站到 100 格外 = 永远够不着 → 追击阶段的**正常出口**（开火后 setPhase）也走不了。
const SCRIPT = argOf(process.argv, 'script', '');   // 定时控制台布景："150:fill ...;300:kill @e[type=end_crystal]"
const CLEAR_AT = parseFloat(argOf(process.argv, 'clear-crystals-at', '0')) || 0;   // 0 = 不按秒清
const CLEAR_ON_FIRST_PERCH = process.argv.includes('--clear-on-first-perch');
const RIG_RADIUS = parseFloat(argOf(process.argv, 'rig-radius', '3'));
const RIG_ANGLE = parseFloat(argOf(process.argv, 'rig-angle', '0'));
// 机位巡测表："r:a,r:a,..."（每次栖息换一个站位，把「爆心离龙多远 → 每床伤害」扫成曲线）
const RIG_SCHEDULE = (argOf(process.argv, 'rig-schedule', '') || '').split(',').map((s) => s.trim()).filter(Boolean)
    .map((s) => { const [r, a] = s.split(':'); const an = Number(a); return { r: /^\d+(\.\d+)?$/.test(r) ? Number(r) : r, a: Number.isFinite(an) ? an : 0 }; });
// 站位策略 (b)：盘旋期间停在 64 格外，龙一开始降落就冲进 20 格。
//   --park-fill  : 在虚空里先铺一块落脚台（控制台 fill，**布景**不是信息通道），再把 bot 停上去
//   --come-in-on-landing : 遥测里出现 LANDING_APPROACH(2)/LANDING(3) 就立刻投回交战位
const PARK_FILL = argOf(process.argv, 'park-fill', '');
const COME_IN_ON_LANDING = process.argv.includes('--come-in-on-landing');
// 高机位：探针在巡航期把柱子搭好（它没有控制台），runner 看到 rig_built 就把 bot 投到台顶。
const RIG_PRESET = argOf(process.argv, 'rig-preset', '');      // 'high1'
const RIG_STAND_TP = argOf(process.argv, 'rig-stand-tp', '');  // 例 "1 68 0"
// ---- 龙头 E2（--mode e2）----
// --e2-build  "4:0,4:1,4:-1,3:0,5:0"   要搭的柱子（x:z），搭到 --e2-top-y
// --e2-cells  "4:67:0,4:67:1,4:67:-1,3:67:0,5:67:0,4:67:2"  床位表（爆心=枕头半格）
// --e2-stand  "1 63 0"  站位（偏心 1 格：正中时龙到玩家的水平向量退化、龙头朝向无定义）
const E2_BUILD = (argOf(process.argv, 'e2-build', '') || '').split(',').map((s) => s.trim()).filter(Boolean).map((s) => s.split(':').map(Number));
const E2_CELLS = (argOf(process.argv, 'e2-cells', '') || '').split(',').map((s) => s.trim()).filter(Boolean).map((s) => { const p = s.split(':').map(Number); return [p[0], p[1], p[2]]; });
const E2_TOP_Y = parseInt(argOf(process.argv, 'e2-top-y', '67'), 10);
const E2_STAND = argOf(process.argv, 'e2-stand', '');
// ---- 爆心判别实验（--mode blast）----
const BLAST_Y = parseInt(argOf(process.argv, 'blast-y', '100'), 10);      // 平台方块所在 y（bot 站在 y+1）
const BLAST_HALF = parseInt(argOf(process.argv, 'blast-half', '7'), 10);   // 平台半宽
const BLAST_RESIST = parseInt(argOf(process.argv, 'blast-resist', '2'), 10); // 抗性等级（II = 减半，10 血 vs 2 血 可分）
const BLAST_X0 = -BLAST_HALF, BLAST_X1 = BLAST_HALF, BLAST_Z0 = -BLAST_HALF, BLAST_Z1 = BLAST_HALF;
const BLAST_STAND_TP = `${BLAST_HALF - 7}.5 ${BLAST_Y + 1} ${BLAST_HALF - 7}.5`;   // 平台一角附近，避开中心弹坑
const GATE_RANGE = argOf(process.argv, 'gate-range', '12');
const NO_ROOF_GROUND = process.argv.includes('--no-ground-rig');   // 退回门柱顶那套（对照用）
const RETP_ON_DEATH = argOf(process.argv, 'retp-on-death', '4');   // 死亡后最多重投几次（0=关）
// ⚠ --god-mode：给 bot 抗性 V（近乎免疫），**只为把"床爆机制能不能打中龙"与"末地保命"两个变量摘开**。
// 实测依据：站着不动 4HP/5s（SMOKE4）、停泊点同样被冲死 5 次（DETECT3）——保命归 stage-06 S2。
// 这**不代表 S6 的保命已解决**，只是本单不测那一半，别把这里的"不死"读成"末地不死"。
const GOD_MODE = process.argv.includes('--god-mode');
const KEEP_WORLD = process.argv.includes('--keep-world');
const SKIP_CLEANUP = process.argv.includes('--skip-cleanup');
const LANE_WAIT_S = parseInt(argOf(process.argv, 'lane-wait-s', '3600'), 10);   // 与开发线 C 排队共用的最长等待
const RUNS_DIR = path.join(HERE, 'runs', RUNSTAMP);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- 泳道 C 装配（只碰 _laneC） ----------
function ensureLaneC() {
    const dir = LANE.dir;
    const sp = path.join(dir, 'server.properties');
    if (!fs.existsSync(sp)) {
        log(`lane C: 目录未 provisioned，从模板派生 ${dir}`);
        fs.mkdirSync(dir, { recursive: true });
        const tplJar = path.join(TEMPLATE_DIR, JAR_NAME);
        if (!fs.existsSync(tplJar)) throw new Error(`模板目录里没有 ${JAR_NAME}：${tplJar}`);
        fs.copyFileSync(tplJar, path.join(dir, JAR_NAME));
        const eula = path.join(TEMPLATE_DIR, 'eula.txt');
        if (fs.existsSync(eula)) fs.copyFileSync(eula, path.join(dir, 'eula.txt'));
        const lines = fs.readFileSync(path.join(TEMPLATE_DIR, 'server.properties'), 'utf8')
            .split(/\r?\n/)
            .map((l) => {
                if (l.startsWith('server-port=')) return `server-port=${LANE.serverPort}`;
                if (l.startsWith('rcon.port=')) return `rcon.port=${LANE.rconPort}`;
                return l;
            })
            .filter((l) => !l.startsWith('level-seed='));
        fs.writeFileSync(sp, lines.join('\n') + '\n');
    }
    const txt = fs.readFileSync(sp, 'utf8');
    const port = /^server-port=(\d+)$/m.exec(txt)?.[1];
    const rcon = /^rcon\.port=(\d+)$/m.exec(txt)?.[1];
    if (Number(port) !== LANE.serverPort || Number(rcon) !== LANE.rconPort) {
        throw new Error(`lane C 配置不对：server-port=${port} rcon.port=${rcon}（应为 ${LANE.serverPort}/${LANE.rconPort}）`);
    }
    if (!fs.existsSync(path.join(dir, JAR_NAME))) throw new Error(`lane C 缺 jar：${JAR_NAME}`);
    const diff = /^difficulty=(\w+)$/m.exec(txt)?.[1];
    log(`lane C: ${dir} | port=${port}/${rcon} | server.properties difficulty=${diff}（本单按 ${DIFFICULTY} 跑，开服后用控制台 ${DIFFICULTY} 覆盖）`);
    return { ...LANE, jarPath: path.join(dir, JAR_NAME), java: JAVA };
}

function assertLaneCPortsFree() {
    const listeners = netstatListeners();
    const busy = [LANE.serverPort, LANE.rconPort].filter((pt) => (listeners[String(pt)] ?? []).length > 0);
    if (busy.length) {
        const detail = busy.map((pt) => `:${pt} pid=${(listeners[String(pt)] ?? []).join(',')}`).join(' ');
        log(`preflight X 泳道 C 端口被占（${detail}）`);
        return false;
    }
    return true;
}

/** 泳道 C 与开发线 C 排队共用：端口空 ≠ 没人用（别的 runner 局与局之间端口会短暂空闲）。
 *  归属看 .lane-owners 心跳——手册 §9 明令「泳道归属看心跳，不能只看端口空闲」。 */
function laneCOwner() {
    const t = ownerTable();
    for (const [key, rec] of Object.entries(t)) {
        if (!/lane[_-]?c/i.test(key)) continue;
        if (rec.lane && String(rec.lane).toUpperCase() !== 'C') continue;
        const fresh = rec.ageMs <= OWNER_FRESH_MS;
        const live = liveOwnerPids().has(Number(rec.runnerPid));
        return { key, ...rec, fresh, live };
    }
    return null;
}

async function waitForLaneC() {
    const t0 = Date.now();
    for (;;) {
        const owner = laneCOwner();
        if (!owner || (!owner.fresh || !owner.live)) {
            if (owner) log(`lane C 心跳已过期（age=${Math.round(owner.ageMs / 1000)}s live=${owner.live}）→ 视为无人占用`);
            else log('lane C 无归属心跳 → 视为无人占用');
            if (assertLaneCPortsFree()) return true;
        } else {
            log(`lane C 被占用：runner pid=${owner.runnerPid} age=${Math.round(owner.ageMs / 1000)}s → 排队等待（不抢）`);
        }
        if (Date.now() - t0 > LANE_WAIT_S * 1000) { log(`lane C 等待超时（${LANE_WAIT_S}s）`); return false; }
        await sleep(15000);
    }
}

function tailLine(filePath) {
    try {
        const st = fs.statSync(filePath);
        if (!st.size) return null;
        const fd = fs.openSync(filePath, 'r');
        const len = Math.min(st.size, 8192);
        const buf = Buffer.alloc(len);
        fs.readSync(fd, buf, 0, len, st.size - len);
        fs.closeSync(fd);
        return JSON.parse(buf.toString('utf8').split('\n').filter((l) => l.trim()).at(-1));
    } catch { return null; }
}
function awaitBotExit(botProc, runDir, cfg, row) {
    return new Promise((resolve) => {
        let lastSig = null, lastChangeAt = Date.now();
        const t0b = Date.now();
        const poll = setInterval(() => {
            if (botProc.exitCode !== null) { clearInterval(poll); resolve(botProc.exitCode); return; }
            if (Date.now() - t0b > cfg.timeoutMs + 90000) { clearInterval(poll); killTree(botProc.pid); resolve(-9); return; }
            if (cfg.noProgressMs > 0) {
                const p = tailLine(path.join(runDir, 'probe.jsonl'));
                if (p) {
                    const sig = JSON.stringify({ pos: p.pos ?? null, hp: p.hp ?? null, dragon: p.dragon ?? null, crystals: p.crystals ?? null });
                    if (sig !== lastSig) { lastSig = sig; lastChangeAt = Date.now(); }
                    else if (Date.now() - lastChangeAt > cfg.noProgressMs) {
                        row.abort = { reason: 'no_progress', frozenMs: Date.now() - lastChangeAt };
                        clearInterval(poll); killTree(botProc.pid); resolve(-8);
                    }
                }
            }
        }, 1000);
        botProc.on('exit', (code) => { clearInterval(poll); resolve(code); });
    });
}

if (process.argv.includes('--selftest')) {
    const r = spawnSync(NODE20, [path.join(HERE, 'selftest.mjs')], { stdio: 'inherit' });
    process.exit(r.status ?? 1);
}

process.env.JAVA_TOOL_OPTIONS ||= '-Djava.net.preferIPv4Stack=true';
installRunnerHooks(() => `end-probe ${RUNSTAMP}`);

// 权威预校验：任务层模块能加载 + 信号自测过（起服前失败，别白烧机器时间）
try {
    await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/end_probe.js')).href);
} catch (e) {
    console.error(`[end-probe] 任务层模块加载失败，未起服：${String(e).slice(0, 200)}`);
    process.exit(2);
}

const trialNumbers = Array.from({ length: TRIALS }, (_, i) => START + i);
log(`END-PROBE ${RUNSTAMP}: mode=${MODE} trials=${TRIALS} difficulty=${DIFFICULTY} lane=C(25568) kit=${KIT}`);
log(`任务层 = ${MINDCRAFT}`);
log(`参数：timeout=${PROBE_TIMEOUT_MS / 1000}s headOffsetY=${HEAD_OFFSET_Y} headRange=${HEAD_RANGE} settle=${SETTLE_MS}ms maxPerch=${MAX_PERCH} janitor=${JANITOR_MS}`);

if (process.argv.includes('--plan-only')) {
    log(`PLAN OK：${TRIALS} trial（泳道 C，串行），mode=${MODE}`);
    process.exit(0);
}

const lane = ensureLaneC();

// preflight：只把**本线要用的 C 泳道**当放行条件（按名选，06d P0）。
//
// 阻塞分两类，处理方式不同（任务单 §3：C 与开发线 C **按心跳排队共用，不抢**）：
//   - 「本线进程归属活着的 runner」= 别的开发线正在用 C → **排队等待**，不是阻塞。
//     SMOKE2 实测踩过：ROUTE-02 的 gen_route.mjs 正占着 C，旧逻辑直接 PREFLIGHT BLOCKED 退出，
//     等于把"排队"做成了"放弃"。
//   - 「本线无归属残留」/「非本线进程占用」= 真的该拒跑（残留先用 --kill-stale 清）。
async function waitForPreflight() {
    const t0 = Date.now();
    for (;;) {
        const pf = await preflight({ killStale: true, laneNames: ['C'], logFn: () => { } });
        for (const n of pf.notes) log(`preflight: ${n}`);
        for (const w of pf.warns) log(`preflight ! ${w}`);
        const myPorts = new Set([LANE.serverPort, LANE.rconPort]);
        const queue = [], others = [], memShort = [], hard = [];
        for (const b of pf.blockers) {
            if (/空闲内存/.test(b)) { memShort.push(b); continue; }
            const mine = [...myPorts].some((pt) => b.includes(`:${pt}`));
            if (!mine) { others.push(b); continue; }
            if (/归属活着的 runner/.test(b)) queue.push(b);
            else hard.push(b);
        }
        for (const b of others) log(`preflight ~ 别的泳道/端口占用（本单只用 C，不动、不等）: ${b}`);
        for (const b of memShort) log(`preflight ~ 内存不足 → 按护栏排队等待（不降阈值）: ${b}`);
        if (!hard.length && !queue.length) return true;
        for (const b of hard) log(`preflight X ${b}`);
        if (hard.length) { log('PREFLIGHT BLOCKED（泳道 C 有真阻塞项，先自行处理残留）'); return false; }
        for (const b of queue) log(`preflight ⏳ ${b}`);
        const waited = Math.round((Date.now() - t0) / 1000);
        if (waited >= LANE_WAIT_S) { log(`排队超时：等泳道 C 已 ${waited}s（--lane-wait-s=${LANE_WAIT_S}），本单退出，不抢`); return false; }
        log(`⏳ 泳道 C 被别的开发线占用 → 排队等心跳空出（已等 ${waited}s / 上限 ${LANE_WAIT_S}s）`);
        await sleep(60000);
    }
}
if (!(await waitForPreflight())) process.exit(1);
if (!(await waitForLaneC())) process.exit(1);
log(`preflight: 泳道 C 可用；开每局前按 <${MIN_FREE_MB}MB 护栏排队（当前 free=${(os.freemem() / 1048576).toFixed(0)}MB）`);

fs.mkdirSync(RUNS_DIR, { recursive: true });
const SUMMARY = path.join(RUNS_DIR, 'summary.jsonl');
const META = path.join(RUNS_DIR, 'run_meta.json');
fs.writeFileSync(META, JSON.stringify({
    stamp: RUNSTAMP, stage: 'MC-END-01', mode: MODE, lane: 'C', ports: [LANE.serverPort, LANE.rconPort],
    mindcraftRoot: MINDCRAFT, mcVersion: MC_VERSION, jar: JAR_NAME, java: JAVA, serverXmx: SERVER_XMX,
    difficulty: DIFFICULTY, kit: KIT, crystalJanitorMs: JANITOR_MS, tp: TP_TARGET,
    headOffsetY: Number(HEAD_OFFSET_Y), headRange: Number(HEAD_RANGE), settleMs: Number(SETTLE_MS),
    maxPerch: MAX_PERCH, probeTimeoutMs: PROBE_TIMEOUT_MS, trials: trialNumbers, startedAt: new Date().toISOString(),
}, null, 2));

let done = 0, kills = 0;
const t0all = Date.now();

for (const n of trialNumbers) {
    const seed = SEED_LITERAL;
    const runDir = path.join(RUNS_DIR, `trial_${String(n).padStart(2, '0')}`);
    fs.mkdirSync(runDir, { recursive: true });
    const row = { trial: n, seed, lane: 'C', mode: MODE, difficulty: DIFFICULTY, startedAt: new Date().toISOString() };

    for (let attempt = 1; attempt <= 2; attempt++) {
        row.attempt = attempt;
        if (!(await waitForLaneC())) { row.outcome = 'LANE_BUSY'; break; }
        const waited = await waitFreeMem(MIN_FREE_MB * 1048576, log);
        if (waited) log(`trial ${n}: 内存护栏排队 ${(waited / 1000).toFixed(0)}s`);
        freshWorld(lane, seed);
        log(`trial ${n} [lane C]: fresh world seed=${seed}，起服（xmx=${SERVER_XMX} free=${(os.freemem() / 1048576).toFixed(0)}MB）`);
        let server;
        try { server = await bootServerWithRetry(lane, runDir, SERVER_XMX, log, 3); }
        catch (e) { row.outcome = 'SERVER_FAIL'; row.error = String(e).slice(0, 200); break; }
        row.bootMs = server.bootMs;
        log(`trial ${n} [lane C]: server up in ${(server.bootMs / 1000).toFixed(0)}s`);

        // **顺序：先起 bot，再发 kit。** injectKit 靠 server.log 里的 "joined the game" 等 bot 进服，
        // 反过来（先 injectKit 再 spawn）会白等 90s 拿不到 kit —— SMOKE1 实测踩过这一脚。
        const botArgs = [
            path.join(HERE, 'end_probe_bot.mjs'),
            '--trial', String(n), '--seed', seed, '--out', runDir,
            '--port', String(LANE.serverPort), '--username', LANE.username,
            '--mode', MODE, '--timeout-ms', String(PROBE_TIMEOUT_MS),
            '--mc-version', MC_VERSION, '--probe-ms', String(PROBE_MS),
            '--head-offset-y', HEAD_OFFSET_Y, '--head-range', HEAD_RANGE,
            '--settle-ms', SETTLE_MS, '--max-perch', String(MAX_PERCH),
            '--walk-timeout-ms', String(WALK_TIMEOUT_MS),
            '--rig-radius', String(RIG_RADIUS), '--rig-angle', String(RIG_ANGLE),
            '--gate-range', GATE_RANGE,
            '--rig-schedule', RIG_SCHEDULE.map((s) => s.r + ':' + s.a).join(','),
            '--rig-preset', RIG_PRESET, '--rig-stand-tp', RIG_STAND_TP,
            '--blast-y', String(BLAST_Y), '--blast-half', String(BLAST_HALF),
            '--e2-build', E2_BUILD.map((p) => p.join(':')).join(','),
            '--e2-cells', E2_CELLS.map((p) => p.join(':')).join(','),
            '--e2-top-y', String(E2_TOP_Y), '--e2-stand', E2_STAND,
        ];
        if (NO_ROOF_GROUND) botArgs.push('--no-ground-rig');
        const botOut = fs.openSync(path.join(runDir, 'bot_console.log'), 'a');
        const botProc = spawn(NODE20, botArgs, {
            cwd: HERE, stdio: ['ignore', botOut, botOut],
            env: { ...process.env, MC_MINDCRAFT_ROOT: MINDCRAFT },
        });

        // kit（控制台 give；手册 §2 一律走 stdin）
        const kit = await injectKit(server, lane, runDir, KIT, log);
        row.kit = kit.ok ? kit.kit : null;

        // 等 bot 报到（kit 到位）→ 下难度 + tp 进末地
        const readyPath = path.join(runDir, 'bot_ready.json');
        const readyT0 = Date.now();
        let setup = { ok: false };
        while (Date.now() - readyT0 < 90000) {
            if (fs.existsSync(readyPath)) {
                // 站位策略 (b)：先把落脚台铺好，再把 bot 停上去（否则 tp 完就掉进虚空）
                if (PARK_FILL) {
                    try { server.child.stdin.write(`${PARK_FILL}\n`); } catch { /* 忽略 */ }
                    log(`trial ${n}: 铺落脚台 ${PARK_FILL}`);
                    row.parkFill = PARK_FILL;
                    await sleep(2000);
                }
                // 爆心判别实验（--mode blast）：主世界高空铺一块泥土平台，把 bot 站上去，
                // 床放到离它 4~5 格 / 1~2 格两处，远程引爆看**掉血落在爆心哪一侧**。
                // 不需要龙，所以这一模式**不进末地**。
                if (MODE === 'blast') {
                    // 平台**建在 bot 脚下上方 2 格**，而不是把 bot 传送到远处：
                    // BLAST1~3 实测同维度远距 `tp`（175 格）之后，服务端持续刷
                    // "moved too quickly! -178,31,-244"，**客户端自己的坐标没被更新**，
                    // 于是它认为自己在 (178,70,244)，平台那一小节永远不加载，`waitPlatform` 读 45 s 全 air。
                    // 改成"就地升 3 格"的小位移就没有这个问题（跨维度的 `execute in … run tp` 不受影响）。
                    let pos = null;
                    try { pos = JSON.parse(fs.readFileSync(path.join(runDir, 'bot_pos.json'), 'utf8')); } catch { pos = null; }
                    const bx = pos ? Math.floor(pos.x) : 0;
                    const by = pos ? Math.floor(pos.y) : 64;
                    const bz = pos ? Math.floor(pos.z) : 0;
                    const py = by;                      // 平台层 = bot 脚底这层（**不做 tp**，见下）
                    // 1.16.1 同维度 `tp` 之后客户端坐标不跟随（BLAST1~7 七局全灭在这条链上）：服务端回了
                    // `Teleported …`，客户端仍认为自己在出生点 ⇒ 要访问的小节/高度全对不上。所以这里
                    // **把 bot 脚下那层铺平、头顶清空**，一步都不挪它。
                    row.blastPlatform = { bx, by, bz, py };
                    // bot 侧要用**同一份**平台坐标（上一版 bot 硬编码查 (0,y,0)，平台却建在 bot 出生点
                    // ⇒ lockAt 落到未加载小节，45 s 读到 null）
                    fs.writeFileSync(path.join(runDir, 'blast_plan.json'), JSON.stringify(row.blastPlatform));
                    const cmds = [
                        `difficulty ${DIFFICULTY}`,
                        `effect give ${LANE.username} minecraft:resistance 9999 ${BLAST_RESIST} true`,
                        `fill ${bx - BLAST_HALF} ${py} ${bz - BLAST_HALF} ${bx + BLAST_HALF} ${py} ${bz + BLAST_HALF} minecraft:dirt`,
                        `fill ${bx - BLAST_HALF} ${py + 1} ${bz - BLAST_HALF} ${bx + BLAST_HALF} ${py + 1} ${bz + BLAST_HALF} minecraft:air`,
                    ];
                    for (const c of cmds) { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } await sleep(250); }
                    setup = { ok: true, cmds, mode: 'blast', platform: row.blastPlatform };
                    row.setup = setup;
                    log(`trial ${n}: blast 布景完成（bot 出生点 ${bx},${by},${bz} → 平台层 y=${py}，抗性 ${BLAST_RESIST}）`);
                    break;
                }
                const cmds = [
                    `difficulty ${DIFFICULTY}`,
                    ...(GOD_MODE ? [`effect give ${LANE.username} minecraft:resistance 9999 4 true`] : []),
                    `execute in minecraft:the_end run tp ${LANE.username} ${PARK_TP || TP_TARGET}`,
                ];
                for (const c of cmds) { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } await sleep(200); }
                setup = { ok: true, cmds, at: new Date().toISOString() };
                log(`trial ${n}: 控制台已下发 ${cmds.join(' | ')}`);
                break;
            }
            if (botProc.exitCode !== null) break;
            await sleep(500);
        }
        row.setup = setup;

        // 水晶看门狗：控制台清末影水晶（**布景**，不是信息通道——与任务单 §3 授权的 give/tp 同类）
        let janitor = null;
        if (JANITOR_MS !== 'none' && setup.ok) {
            let kills0 = 0;
            janitor = setInterval(() => {
                try { server.child.stdin.write('kill @e[type=end_crystal]\n'); kills0++; } catch { /* 忽略 */ }
            }, parseInt(JANITOR_MS, 10) || 1500);
            janitor.unref?.();
            row.janitorEnabled = true;
        }
        row.janitorEnabled = !!janitor;

        // ---- 第二轮布景：定时控制台脚本 + 「首次栖息时清一次水晶」----
        //
        // 为什么要「首次栖息时清」而不是「一进服就清」：本轮字节码核出 `bai.j()` 里
        // **只有在发现末影水晶时才会 strafePlayer(crystal)**，而 `baq.c()` 的两个出口是
        // 「attackTarget==null」与「开火成功」——水晶被控制台 kill 掉之后，phase 里留的是
        // 一个**已移除但非 null** 的 EndCrystal 引用，出口①永远不成立；于是龙可以带着这个死目标
        // 在 STRAFE_PLAYER 里待到天荒地老（DETECT1：4.7 分钟 56 次采样全 STRAFE_PLAYER）。
        // 栖息期（SITTING_*）没有 onCrystalDestroyed 覆写 ⇒ **在龙坐着的时候清水晶是安全窗口**，
        // 起飞后它回到 HOLDING_PATTERN，而 `bai.j()` 的落地骰子是 `nextInt(3+存活水晶数)`：
        // 0 根水晶 = 每 tick 1/3 概率落地 ⇒ 栖息窗口从「几分钟一次」变成「十几秒一次」。
        const scriptTimers = [];
        if (setup.ok && SCRIPT) {
            for (const part of SCRIPT.split(';').map((s) => s.trim()).filter(Boolean)) {
                const i = part.indexOf(':');
                if (i <= 0) { log(`--script 段格式不对，跳过：${part}`); continue; }
                const at = parseFloat(part.slice(0, i)) * 1000;
                const cmd = part.slice(i + 1).trim();
                if (!Number.isFinite(at) || !cmd) { log(`--script 段解析失败，跳过：${part}`); continue; }
                const t = setTimeout(() => {
                    try { server.child.stdin.write(`${cmd}\n`); } catch { /* 忽略 */ }
                    log(`trial ${n} [script @${(at / 1000).toFixed(0)}s] ${cmd}`);
                    row.scriptFired = (row.scriptFired ?? []).concat([{ atS: at / 1000, cmd }]);
                }, at);
                t.unref?.();
                scriptTimers.push(t);
            }
            row.script = SCRIPT;
        }
        let clearTimer = null, cleared = false;
        const doClearCrystals = (why) => {
            if (cleared) return;
            cleared = true;
            try { server.child.stdin.write('kill @e[type=end_crystal]\n'); } catch { /* 忽略 */ }
            log(`trial ${n}: 清空末影水晶（${why}）`);
            row.clearedCrystals = { why, at: new Date().toISOString() };
        };
        if (setup.ok && Number(CLEAR_AT) > 0) {
            clearTimer = setTimeout(() => doClearCrystals(`--clear-crystals-at ${CLEAR_AT}s`), Number(CLEAR_AT) * 1000);
            clearTimer.unref?.();
        }
        let perchWatch = null;
        if (setup.ok && (CLEAR_ON_FIRST_PERCH || (Number(CLEAR_AT) > 0 && false))) {
            perchWatch = setInterval(() => {
                try {
                    if ((readTele().match(/"event":"perch_begin"/g) ?? []).length >= 1) {
                        doClearCrystals('首次栖息时清（--clear-on-first-perch）');
                        clearInterval(perchWatch); perchWatch = null;
                    }
                } catch { /* 遥测还没落盘 */ }
            }, 700);
            perchWatch.unref?.();
        }

        // 死亡重投看门狗：末地死亡重生回**主世界**，探针就再也等不到龙（SMOKE3 实测）。
        // runner 手里有控制台，所以由它盯着遥测里的 bot_death 事件并重投；
        // 死亡次数照实记进 metrics（不掩盖），重投只保证这一局还能继续打完。
        let retpCount = 0, seenDeaths = 0;
        const tele = path.join(runDir, 'telemetry.jsonl');
        const readTele = () => { try { return fs.readFileSync(tele, 'utf8'); } catch { return ''; } };
        const sendTp = (where) => { try { server.child.stdin.write(`execute in minecraft:the_end run tp ${LANE.username} ${where}\n`); } catch { /* 忽略 */ } };
        const retpTimer = setup.ok && Number(RETP_ON_DEATH) > 0 ? setInterval(() => {
            try {
                const deaths = (readTele().match(/"event":"bot_death"/g) ?? []).length;
                if (deaths > seenDeaths) {
                    seenDeaths = deaths;
                    if (retpCount < Number(RETP_ON_DEATH)) {
                        retpCount++;
                        // 高机位激活时重投要回**台顶**，不是回地面机位：爆心旁的 knockback
                        // 会把 1×1 台上的 bot 震下去（这本身是 S6 保命要解的问题，见报告），
                        // 投回地面就再也回不去台上了。
                        const back = (RIG_PRESET === 'high1' && RIG_STAND_TP) ? RIG_STAND_TP : (PARK_TP || TP_TARGET);
                        sendTp(back);
                        log(`trial ${n}: 检测到死亡（第 ${deaths} 次），重投回 ${back}（${retpCount}/${RETP_ON_DEATH}）`);
                    }
                }
            } catch { /* 遥测还没落盘 */ }
        }, 3000) : null;
        retpTimer?.unref?.();

        // 远端停泊 ⇄ 交战投送：判到栖息 → 投到门柱；栖息结束 → 撤回停泊点。
        // 这是把 §5.1 的机制直接编进布景。⚠ 与策略 (b) 互斥：策略 b 要的是「**降落一开始就冲进来**」，
        // 若这个计时器也开着，它会在 `perch_begin`（已经降完了）再投一次，两套策略混在一起
        // 就没法归因（STRAFE_B 实测踩到：8 次栖息全是这个计时器投的，降落触发器一次没响）。
        let lastPerchN = 0, lastEndedN = 0, fightSends = 0;
        const parkTimer = (setup.ok && PARK_TP && !COME_IN_ON_LANDING) ? setInterval(() => {
            try {
                const txt = readTele();
                const begun = (txt.match(/"event":"perch_begin"/g) ?? []).length;
                const ended = (txt.match(/"event":"perch_end"/g) ?? []).length;
                if (begun > lastPerchN) {           // 又开始栖息 → 打过去
                    lastPerchN = begun;
                    fightSends++;
                    sendTp(TP_TARGET);
                    log(`trial ${n}: 判到栖息 #${begun}，投送 bot 到门柱旁（投送 ${fightSends} 次）`);
                } else if (ended > lastEndedN) {    // **新**结束一段栖息 → 撤回停泊点
                    lastEndedN = ended;
                    sendTp(PARK_TP);
                    log(`trial ${n}: 栖息 #${ended} 结束，撤回停泊点 ${PARK_TP}`);
                }
            } catch { /* 遥测还没落盘 */ }
        }, 700) : null;
        parkTimer?.unref?.();

        // 站位策略 (b)：龙一开始降落就冲进 20 格。判据用 bot 自己落的 phase_change 遥测
        // （带 bot 位置与到门柱中心的水平距离），所以"5 秒内进 20 格"这条能从数据核。
        let landingWatch = null, cameIn = false, landingSeenAt = null;
        if (setup.ok && COME_IN_ON_LANDING) {
            landingWatch = setInterval(() => {
                try {
                    const lines = readTele().split('\n').filter((l) => l.includes('"event":"phase_change"'));
                    for (const l of lines) {
                        const r = JSON.parse(l);
                        if (r.phase !== 'LANDING_APPROACH' && r.phase !== 'LANDING') continue;
                        if (landingSeenAt != null) continue;
                        landingSeenAt = r.t;
                        if (cameIn) break;
                        cameIn = true;
                        sendTp(TP_TARGET);
                        const firedAt = Date.now();
                        log(`trial ${n}: 判到 ${r.phase}（t=${r.t}ms，bot 距门柱 ${r.distToCenter} 格）→ 投回交战位 ${TP_TARGET}`);
                        row.comeIn = { phase: r.phase, teleAtMs: r.t, botDistAtLanding: r.distToCenter, sentAt: new Date(firedAt).toISOString() };
                    }
                } catch { /* 遥测还没落盘 */ }
            }, 400);
            landingWatch.unref?.();
        }

        // 高机位：探针搭好柱子后落一条 rig_built 遥测，runner 把 bot 投到台顶（探针无控制台）
        let rigWatch = null, rigSent = false;
        if (setup.ok && RIG_PRESET === 'high1' && RIG_STAND_TP) {
            rigWatch = setInterval(() => {
                try {
                    if (rigSent) return;
                    if (!readTele().includes('"event":"rig_built"')) return;
                    rigSent = true;
                    sendTp(RIG_STAND_TP);
                    log(`trial ${n}: 高机位搭好，把 bot 投到台顶 ${RIG_STAND_TP}`);
                    row.rigStandTp = RIG_STAND_TP;
                    clearInterval(rigWatch); rigWatch = null;
                } catch { /* 遥测还没落盘 */ }
            }, 500);
            rigWatch.unref?.();
        }

        // tp 看门狗：`execute in <dim> run tp <name> …` 会**偶发** "No entity was found"
        // （E2A3 实测：bot 已 joined、kit/effect 都打上了，tp 仍报找不到实体）⇒ bot 留在主世界，
        // 探针干等 90 s 收工 NO_DRAGON。这属于**静默失败**：命令没有语法错、日志只有一行 INFO。
        // 判据用 bot 自己落的 `dragon_first_seen` 遥测（到达末地才会发），没到就补发 tp。
        let tpWatch = null, tpTries = 0;
        // ⚠ blast 模式**必须关掉**这个看门狗：它盯的是"到达末地"，而 blast 的 bot 应该待在
        // 主世界平台上。BLAST2 实测被它连发 5 次 `tp … 0 70 0`，把刚落到平台上的 bot 又拽回虚空，
        // 于是 `waitPlatform` 读到 45 s 全是 air（那一小节根本没进客户端）。
        if (setup.ok && MODE !== 'blast') {
            tpWatch = setInterval(() => {
                try {
                    if (tpTries >= 5) return;
                    const txt = readTele();
                    if (txt.includes('"event":"dragon_first_seen"')) {   // ⚠ 不能拿 at_center 当到达信号：它在 bot 还站在主世界时就发了（E2B 实测）
                        clearInterval(tpWatch); tpWatch = null; return;
                    }
                    tpTries++;
                    sendTp(PARK_TP || TP_TARGET);
                    log(`trial ${n}: 没收到末地到达信号，补发 tp（第 ${tpTries} 次）→ ${PARK_TP || TP_TARGET}`);
                    row.tpRetries = tpTries;
                } catch { /* 遥测还没落盘 */ }
            }, 6000);
            tpWatch.unref?.();
        }

        const exitCode = await awaitBotExit(botProc, runDir, { timeoutMs: PROBE_TIMEOUT_MS, noProgressMs: NO_PROGRESS_S * 1000 }, row);
        row.botExit = exitCode;
        if (janitor) clearInterval(janitor);
        for (const t of scriptTimers) clearTimeout(t);
        if (clearTimer) clearTimeout(clearTimer);
        if (perchWatch) clearInterval(perchWatch);
        if (landingWatch) clearInterval(landingWatch);
        if (tpWatch) clearInterval(tpWatch);
        if (rigWatch) clearInterval(rigWatch);
        if (retpTimer) clearInterval(retpTimer);
        if (parkTimer) clearInterval(parkTimer);
        row.retpCount = retpCount;
        row.fightSends = fightSends;
        log(`trial ${n} [lane C]: bot exit=${exitCode}，停服`);
        await stopServer(lane, server);
        await sleep(1500);
        try { fs.closeSync(botOut); } catch { /* 忽略 */ }

        try {
            const result = JSON.parse(fs.readFileSync(path.join(runDir, 'result.json'), 'utf8'));
            row.result = result;
            row.outcome = result.status;
            const m = result.metrics ?? {};
            row.metrics = {
                perches: m.perchEpisodes, misses: m.perchMisses, bombs: m.bombs,
                bombDamageTotal: m.bombDamageTotal, deaths: m.deaths, bedsUsed: m.bedsUsed,
                killedAtMs: m.killedAt, healthMin: m.healthMin, dragonHealthEnd: m.dragonHealthEnd,
                crystalMin: m.crystalMin, crystalMax: m.crystalMax, wallMs: m.wallMs,
                walkMs: result.walkMs, latencies: m.detectLatenciesMs, notes: m.notes,
                phaseHistogram: m.phaseHistogram, geom: m.geom, bombRecords: m.bombRecords,
                perchDetail: m.perchDetail, crystalSamples: m.crystalSamples,
                // 第二轮
                gate: m.gate, strafeEpisodes: m.strafeEpisodes, phaseDwellMs: m.phaseDwellMs,
                phaseTimeline: m.phaseTimeline, fireballs: m.fireballs, fireballDetail: m.fireballDetail,
                e2: m.e2, rig: m.rig, perchGapsMs: m.perchGapsMs, crystalTimeline: m.crystalTimeline,
            };
            if (result.status === 'KILL') kills++;
            if (result.status === 'CONNECT_FAIL' || result.status === 'RUNNER_TIMEOUT' || result.status === 'KICKED') {
                log(`trial ${n}: 基建级失败（${result.status}），15s 冷却后重试`);
                await sleep(15000);
                continue;
            }
        } catch {
            if (row.abort?.reason === 'no_progress') row.outcome = 'FAIL(NO_PROGRESS_ABORT)';
            else if (exitCode === -8) row.outcome = 'NO_PROGRESS_ABORT';
            else { row.outcome = 'NO_RESULT'; log(`trial ${n}: 无 result（exit=${exitCode}）`); }
        }
        break;
    }
    row.finishedAt = new Date().toISOString();
    fs.appendFileSync(SUMMARY, JSON.stringify(row) + '\n');
    done++;
    const m = row.metrics ?? {};
    log(`trial ${n} → ${row.outcome} | 栖息 ${m.perches ?? '?'} 漏判 ${m.misses ?? '?'} 引爆 ${m.bombs ?? '?'} 伤害 ${m.bombDamageTotal ?? '?'} 死亡 ${m.deaths ?? '?'} 墙钟 ${m.wallMs ? (m.wallMs / 1000).toFixed(1) : '?'}s`);
}

const allRows = fs.existsSync(SUMMARY)
    ? fs.readFileSync(SUMMARY, 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean)
    : [];
fs.writeFileSync(META, JSON.stringify({
    ...JSON.parse(fs.readFileSync(META, 'utf8')),
    finishedAt: new Date().toISOString(), wallMs: Date.now() - t0all,
    kills, success: allRows.filter((r) => r.outcome === 'KILL').length, total: allRows.length,
    thisInvocation: { kills, total: done, trials: trialNumbers },
}, null, 2));

const sum = spawnSync(NODE20, [path.join(HERE, 'summarize.mjs'), '--run', RUNSTAMP], { stdio: 'inherit' });

if (!SKIP_CLEANUP) {
    const cu = await cleanup({ label: `end-probe ${RUNSTAMP}`, rmWorlds: !KEEP_WORLD, dirs: [{ dir: lane.dir, port: LANE.serverPort }] });
    fs.writeFileSync(path.join(RUNS_DIR, 'cleanup.txt'), cu.lines.join('\n') + '\n');
}
log(`DONE: ${allRows.filter((r) => r.outcome === 'KILL').length} KILL / ${done} trials, wall=${((Date.now() - t0all) / 60000).toFixed(1)}min, 产物 ${path.relative(ROOT, RUNS_DIR)}`);
process.exit(0);
