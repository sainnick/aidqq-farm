// summarize.mjs — MC-BENCH-v2 BASIC-iron 结果汇总 + 失败归因自动化
//
// 用法：node summarize.mjs <runs目录|stamp名> [--version 1.16.1]
// 输出：<stamp目录>/bench_report.md + bench_summary.json + failures.md
//
// BENCH-v2 第 4 件事：每个失败局自动输出——停在哪个子任务（任务树最深非 SUCCESS 节点）
// + 最后 60s 遥测事件计数 + 关键计数器（search/relocate/death/smelt/branch...），
// 复核不用再手工翻遥测。NO_PROGRESS_ABORT 局（无 result.json）用 probe.jsonl 尾行归因。

import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));

const argVal = (name, dflt) => {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
};
const MC_VERSION = argVal('version', '1.16.1');
const RUNS_DIR = path.resolve(BENCH_DIR, 'runs');
const raw = process.argv.slice(2).find((a) => !a.startsWith('--'));

const hasTrials = (d) => fs.existsSync(d) && fs.readdirSync(d).some((e) => e.startsWith('trial_'));
let targetDir = null;
if (raw) {
    const p = raw.includes('\\') || raw.includes('/') || raw.startsWith('.') ? path.resolve(raw) : path.join(RUNS_DIR, raw);
    if (hasTrials(p)) targetDir = p;
    else { console.error(`no trial_* dirs under ${p}`); process.exit(1); }
} else {
    const stampDirs = fs.existsSync(RUNS_DIR) ? fs.readdirSync(RUNS_DIR).filter((d) => hasTrials(path.join(RUNS_DIR, d))).sort() : [];
    if (!stampDirs.length) { console.error('no stamp dirs; 用法: node summarize.mjs <stamp>'); process.exit(1); }
    targetDir = path.join(RUNS_DIR, stampDirs.at(-1));
}

const readJsonl = (p) => {
    if (!fs.existsSync(p)) return [];
    return fs.readFileSync(p, 'utf8').split('\n').filter(Boolean)
        .map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
};

// 任务树文本 → 最深非 SUCCESS 节点（停在哪儿）。行形如 "├─ Craft(x ×1) [FAILED(REASON), 3.2s]"
function stoppedAt(treeText) {
    if (!treeText) return null;
    let best = null;
    for (const line of treeText.split('\n')) {
        const indent = (line.match(/^[│ ]*/) ?? [''])[0].length;
        const m = line.match(/^(?:[│├└─\s]*)(.+?) \[([A-Z_]+)(?:\(([^)]*)\))?,/);
        if (!m) continue;
        const node = { label: m[1].trim(), status: m[2], reason: m[3] ?? null, depth: Math.floor(indent / 3) };
        if (node.status !== 'SUCCESS') {
            if (!best || node.depth >= best.depth) best = node; // 同深取后出现者（更接近收局时刻）
        }
    }
    return best;
}

function last60sEvents(events, endT) {
    const tEnd = endT ?? (events.length ? events.at(-1).t : 0);
    const win = events.filter((e) => tEnd - e.t <= 60000);
    const hist = {};
    for (const e of win) hist[e.event] = (hist[e.event] ?? 0) + 1;
    return Object.fromEntries(Object.entries(hist).sort((a, b) => b[1] - a[1]).slice(0, 12));
}

const KEY_COUNTERS = ['searches', 'relocates', 'navAttempts', 'navFailures', 'miningAttempts', 'successfulMines',
    'deaths', 'replans', 'craftAttempts', 'craftFailures', 'tablePlacementFailures', 'furnacePlacementFailures',
    'smeltOk', 'smeltFailures', 'flintPlaceRedigs', 'ironTargetsSelected', 'softStuckEvents', 'hardStuck'];

const rows = readJsonl(path.join(targetDir, 'summary.jsonl'));
const trials = [];
for (const row of rows) {
    const dir = path.join(targetDir, `trial_${String(row.trial).padStart(2, '0')}`);
    const resultPath = path.join(dir, 'result.json');
    let result = null;
    try { result = JSON.parse(fs.readFileSync(resultPath, 'utf8')); } catch { /* NO_RESULT/ABORT */ }
    const events = readJsonl(path.join(dir, 'telemetry.jsonl'));
    let probeTail = null;
    try { probeTail = readJsonl(path.join(dir, 'probe.jsonl')).at(-1) ?? null; } catch { /* 忽略 */ }

    const t = {
        trial: row.trial, seed: row.seed, lane: row.lane ?? null, attempt: row.attempt ?? null,
        outcome: row.outcome, abort: row.abort ?? null,
        status: result?.status ?? null, failReason: result?.failReason ?? null,
        durationSec: result?.durationMs ? +(result.durationMs / 1000).toFixed(1) : null,
        deaths: result?.metrics?.deaths ?? null,
        counters: result?.metrics ? Object.fromEntries(KEY_COUNTERS.map((k) => [k, result.metrics[k] ?? 0])) : null,
        stoppedAt: stoppedAt(result?.taskTree ?? ''),
        last60sEvents: Object.keys(last60sEvents(events)).length ? last60sEvents(events) : null,
    };
    if (!t.stoppedAt && probeTail?.tree) {
        // 无进展中止局：probe 尾行的树快照里全是 RUNNING —— 取最深链末端节点
        const lines = String(probeTail.tree).split('\n').filter(Boolean);
        const last = lines.at(-1)?.trim() ?? '';
        t.stoppedAt = { label: (last.match(/([A-Za-z][A-Za-z_]+\(.*?\))(?: \[|$)/) ?? [])[1] ?? last, status: 'RUNNING', reason: 'probe_tail', depth: lines.length - 1 };
    }
    if (t.abort) t.abort.lastProbe = undefined; // 大对象不进报告
    trials.push(t);
}

const done = trials.filter((t) => t.outcome !== 'EARLY_STOP');
const succ = done.filter((t) => t.outcome === 'SUCCESS');
const failed = done.filter((t) => t.outcome !== 'SUCCESS');
const durs = succ.map((t) => t.durationSec).filter((x) => x != null).sort((a, b) => a - b);
const median = (arr) => arr.length ? +(arr.length % 2 ? arr[(arr.length - 1) / 2] : (arr[arr.length / 2 - 1] + arr[arr.length / 2]) / 2).toFixed(1) : null;
const pct = (arr, p) => arr.length ? arr[Math.min(arr.length - 1, Math.ceil(p * arr.length) - 1)] : null;

// 重埋循环每轮耗时（BENCH-v2/TASK-06b 口径：flint_redig_round.ms 的中位）
const redigMs = [];
for (const t of trials) {
    const dir = path.join(targetDir, `trial_${String(t.trial).padStart(2, '0')}`);
    for (const e of readJsonl(path.join(dir, 'telemetry.jsonl'))) {
        if (e.event === 'flint_redig_round' && typeof e.ms === 'number') redigMs.push(e.ms);
    }
}
const redigSorted = [...redigMs].sort((a, b) => a - b);

const lavaDeaths = trials.reduce((s, t) => s + (t.counters?.deaths && 0) || 0, 0); // 占位：lava 数由 run_meta/server.log 口径
const metaPath = path.join(targetDir, 'run_meta.json');
let meta = {};
try { meta = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch { /* 旧串行 stamp 无此文件 */ }

const report = {
    stage: 'BASIC-iron', runsDir: targetDir, version: MC_VERSION,
    trialsTotal: trials.length, trialsRan: done.length,
    success: succ.length,
    lanes: meta.params?.lanes ?? 1,
    wallMin: meta.wallMs ? +(meta.wallMs / 60000).toFixed(1) : null,
    earlyStop: meta.earlyStop ?? null,
    completion: { medianSec: median(durs), p90Sec: pct(durs, 0.9), minSec: durs[0] ?? null, maxSec: durs.at(-1) ?? null },
    redigLoop: { rounds: redigSorted.length, medianMs: median(redigSorted), p90Ms: pct(redigSorted, 0.9) },
    deaths: done.reduce((s, t) => s + (t.deaths ?? 0), 0),
    failureReasons: Object.fromEntries(Object.entries(failed.reduce((m, t) => {
        const k = t.outcome.replace(/^FAIL\((.*)\)$/, '$1');
        m[k] = (m[k] ?? 0) + 1; return m;
    }, {})).sort((a, b) => b[1] - a[1])),
};
fs.writeFileSync(path.join(targetDir, 'bench_summary.json'), JSON.stringify(report, null, 2));

// 逐失败局归因
const failLines = failed.map((t) => {
    const c = t.counters ? Object.entries(t.counters).filter(([, v]) => v).map(([k, v]) => `${k}=${v}`).join(' ') : '';
    return [
        `## trial ${t.trial} seed=${t.seed} [${t.outcome}]${t.durationSec ? ` ${t.durationSec}s` : ''}（lane=${t.lane ?? '-'} attempt=${t.attempt ?? '-'}）`,
        `- 停在: ${t.stoppedAt ? `${t.stoppedAt.label} [${t.stoppedAt.status}${t.stoppedAt.reason && t.stoppedAt.reason !== 'probe_tail' ? `(${t.stoppedAt.reason})` : ''}]` : '(树缺失)'}`,
        t.abort ? `- runner 中止: 签名冻结 ${Math.round((t.abort.frozenMs ?? 0) / 1000)}s` : null,
        c ? `- 计数器: ${c}` : null,
        t.last60sEvents ? `- 最后60s事件: ${JSON.stringify(t.last60sEvents)}` : null,
    ].filter(Boolean).join('\n');
});
fs.writeFileSync(path.join(targetDir, 'failures.md'),
    (failed.length ? failed : ['（无失败局）']).length && failed.length
        ? `# 失败归因 — ${path.basename(targetDir)}\n\n${failLines.join('\n\n')}\n`
        : `# 失败归因 — ${path.basename(targetDir)}\n\n（无失败局）\n`);

const md = [];
md.push(`# BASIC-iron bench report — ${path.basename(targetDir)}`);
md.push('');
md.push('| 指标 | 值 |');
md.push('|---|---|');
md.push(`| trials | ${done.length}/${report.trialsTotal}（lanes=${report.lanes}，墙钟 ${report.wallMin ?? '-'}min） |`);
md.push(`| 成功 | ${report.success} |`);
md.push(`| completion median / P90 | ${report.completion.medianSec}s / ${report.completion.p90Sec}s |`);
md.push(`| 重埋循环 | ${report.redigLoop.rounds} 轮，median ${report.redigLoop.medianMs ?? '-'}ms，P90 ${report.redigLoop.p90Ms ?? '-'}ms |`);
md.push(`| 死亡（全部原因） | ${report.deaths} |`);
md.push(`| 提前收手 | ${report.earlyStop ? `EARLY_STOP @trial ${report.earlyStop.at}（取消 ${report.earlyStop.cancelled.length} 局）` : '无'} |`);
md.push('');
md.push(`失败原因分布: ${JSON.stringify(report.failureReasons)}`);
fs.writeFileSync(path.join(targetDir, 'bench_report.md'), md.join('\n') + '\n');

console.log(JSON.stringify({ success: report.success, total: report.trialsRan, wallMin: report.wallMin, redigMedianMs: report.redigLoop.medianMs, failures: report.failureReasons }, null, 2));
console.log(`report → ${path.join(targetDir, 'bench_report.md')}\nfailures → ${path.join(targetDir, 'failures.md')}`);
