// dev_plan_check.mjs — MC-M1-TASK-06 离线开发验证（不启服务器）
//
// 验证 BASIC-iron 的三条链在规划层闭环（1.16.1 registry）：
//   1. plan(iron_pickaxe ×1, 空背包)：acquire(iron_ore) + Smelt(iron_ingot) + Craft(furnace)
//      + 木器链全在；不再 DEPENDENCY_CYCLE（铁粒↔铁锭数据环被熔炼变体替换绕开）
//   2. plan(bucket) / plan(flint_and_steel)：同上，且 flint_and_steel 含 acquire(flint)
//   3. resolveSolvableTool：iron_ore → stone_pickaxe；diamond_ore → iron_pickaxe（铁链解锁后的闸门口径）
//   4. parseMission：obtain 1 iron_pickaxe / bucket / flint_and_steel 三种 MISSION 文本
//   5. 回归保底：wooden_pickaxe 规划与 TASK-02 口径一致（补丁没打坏旧链）
//
// 用法：node dev_plan_check.mjs [--version 1.16.1]

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const MINDCRAFT = path.join(ROOT, 'mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const md = require('minecraft-data');
const verIdx = process.argv.indexOf('--version');
const MC_VERSION = verIdx >= 0 ? process.argv[verIdx + 1] : '1.16.1';

const EXEC = (f) => pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec', f)).href;
const { RecipeResolver, SMELT_RECIPES } = await import(EXEC('recipe_resolver.js'));
const { resolveSolvableTool } = await import(EXEC('tool_requirement.js'));
const { parseMission } = await import(EXEC('mission.js'));
const { resourceDef } = await import(EXEC('resources.js'));

let failures = 0;
function check(name, cond, detail = '') {
    if (cond) console.log(`  ok  ${name}`);
    else { console.error(`FAIL  ${name} ${detail}`); failures++; }
}
const render = (plan) => plan.steps.map((s) =>
    s.kind === 'acquire' ? `Acq(${s.resource}×${s.count}${s.sideQuest ? `+${s.sideQuest.resource}×${s.sideQuest.count}` : ''})`
        : s.kind === 'smelt' ? `Smelt(${s.item}→${s.target})`
            : `Craft(${s.item}→${s.target}${s.station ? '@tbl' : ''})`).join(' > ');

const reg = md(MC_VERSION);
const resolver = new RecipeResolver(reg);

console.log(`== BASIC-iron plan check (${MC_VERSION}) ==`);
check('smelting applies (pre-1.17)', !!resolver.smelt);

for (const item of ['iron_pickaxe', 'bucket', 'flint_and_steel']) {
    const plan = resolver.plan(item, 1, {}, [], {});
    console.log(`  ${item}: ${plan.error ? plan.error + ' @' + (plan.item ?? '') : render(plan)}`);
    check(`${item} plan ok`, !plan.error, plan.error);
    if (plan.error) continue;
    check(`${item} has acquire(iron_ore)`, plan.steps.some((s) => s.kind === 'acquire' && s.resource === 'iron_ore'));
    check(`${item} has smelt(iron_ingot)`, plan.steps.some((s) => s.kind === 'smelt' && s.item === 'iron_ingot'));
    check(`${item} has craft(furnace)`, plan.steps.some((s) => s.kind === 'craft' && s.item === 'furnace'));
    check(`${item} furnace before smelt`, plan.steps.findIndex((s) => s.item === 'furnace') < plan.steps.findIndex((s) => s.kind === 'smelt'));
    check(`${item} has wood chain (log)`, plan.steps.some((s) => s.kind === 'acquire' && s.resource === 'log'));
}
const pf2 = resolver.plan('flint_and_steel', 1, {}, [], {});
if (!pf2.error) {
    // MC-M1-TASK-06b：flint 并进 iron_ore 的地下窗口（sideQuest），不再有独立 flint acquire
    const host = pf2.steps.find((s) => s.kind === 'acquire' && s.resource === 'iron_ore');
    check('flint_and_steel: iron_ore step carries sideQuest flint×1',
        !!host && host.sideQuest?.resource === 'flint' && host.sideQuest?.count === 1, JSON.stringify(host ?? pf2.steps));
    check('flint_and_steel: no standalone acquire(flint)', !pf2.steps.some((s) => s.kind === 'acquire' && s.resource === 'flint'));
}
// 铁粒环不再可达：iron_ingot 变体只有 smelt
const ingotVariants = resolver.recipeVariants('iron_ingot');
check('iron_ingot variants = [smelt] only', ingotVariants.length === 1 && ingotVariants[0].smelt === true, JSON.stringify(ingotVariants).slice(0, 120));
// 已有熔炉+矿+木板时不再排炉子
const planW = resolver.plan('iron_ingot', 3, { iron_ore: 5, oak_planks: 8, furnace: 1 }, [], {});
check('furnace in inv → no furnace craft', !planW.error && !planW.steps.some((s) => s.item === 'furnace'), JSON.stringify(planW.steps ?? planW.error));
// acquire 前置集中（TASK-06 实测教训：挖完矿再回头找树每趟 150s+）
const planFull = resolver.plan('iron_pickaxe', 1, {}, [], {});
if (!planFull.error) {
    const lastAcqIdx = planFull.steps.map((s) => s.kind === 'acquire').lastIndexOf(true);
    const firstOtherIdx = planFull.steps.findIndex((s) => s.kind !== 'acquire');
    check('acquire steps frontloaded', lastAcqIdx < firstOtherIdx || firstOtherIdx === -1, render(planFull));
    const logTotal = planFull.steps.filter((s) => s.kind === 'acquire' && s.resource === 'log').reduce((a, s) => a + s.count, 0);
    check(`log frontloaded total = ${logTotal} (含 +2 嵌套消耗余量，1-8)`, logTotal >= 1 && logTotal <= 8, render(planFull));
}

console.log('== tool gate ==');
const fakeBot = { registry: reg };
check('iron_ore → stone_pickaxe', resolveSolvableTool(fakeBot, 'iron_ore') === 'stone_pickaxe', resolveSolvableTool(fakeBot, 'iron_ore'));
check('diamond_ore → iron_pickaxe（铁链通后自动解锁）', resolveSolvableTool(fakeBot, 'diamond_ore') === 'iron_pickaxe', resolveSolvableTool(fakeBot, 'diamond_ore'));

console.log('== mission ==');
for (const [txt, res, cnt] of [['obtain 1 iron_pickaxe', 'iron_pickaxe', 1], ['obtain 1 bucket', 'bucket', 1], ['obtain 1 flint_and_steel', 'flint_and_steel', 1]]) {
    const m = parseMission(txt);
    check(`parse "${txt}"`, m.resource === res && m.count === cnt, JSON.stringify(m));
}
check('craft-type def: gather=false, drops=[item]', resourceDef('bucket').gather === false && resourceDef('bucket').drops[0] === 'bucket');

console.log('== regression guard (old chain unchanged) ==');
const wp = resolver.plan('wooden_pickaxe', 1, {}, [], {});
check('wooden_pickaxe plan ok', !wp.error, wp.error);
check('wooden chain has no smelt', !wp.error && !wp.steps.some((s) => s.kind === 'smelt'));
const sp = resolver.plan('stone_pickaxe', 1, {}, [], {});
check('stone_pickaxe plan ok', !sp.error, sp.error);
const noSmeltItem = resolver.plan('heart_of_the_sea', 1, {}, [], {});
check('truly unsupported dep still rejected (heart_of_the_sea)', !!noSmeltItem.error, noSmeltItem.error ?? 'no error');

console.log(failures ? `\n${failures} FAILURES` : '\nALL PASS');
process.exit(failures ? 1 : 0);
