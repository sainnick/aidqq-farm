// run_bench.mjs — MC-M1-TASK-06 BASIC-iron benchmark runner
//
// MC-BENCH-v2（2026-10-01）：编排层重构为泳道并行版，核心机制全部在
// bench/stages/_lib/runner_core.mjs（泳道/内存护栏/无进展硬中止/失败预算提前收手）。
// 本文件只做 CLI 解析与 stage 专属参数（--resource / 超时默认 540s）。
//   --lanes N        并行泳道数（默认 1 = 原串行语义；夜间建议 3，白天 1）
//   --seeds a,b,c    逗号分隔种子表（trial n = 第 n 个；优先于 --seed/--seed-prefix）
//   --no-progress-s  无进展硬中止窗（默认 120s；0 = 关闭）
//   --fail-budget N|lava=N  失败预算提前收手（默认关）
//   --min-free-mb    开服前空闲内存护栏（默认 2560）
//   --server-xmx     服务器堆上限（默认 1G，BENCH-v2 实测口径）
// 既有参数不变：--trials/--start/--target/--resource/--timeout-ms/--stamp/--seed/--seed-prefix
// 环境变量：MC_BENCH_SERVER / MC_BENCH_JAVA / MC_BENCH_JAR / MC_BENCH_VERSION

import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import { argOf, runMatrix, parseFailBudget, parseLanes } from '../_lib/runner_core.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const SERVER_DIR = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/exec-reuse-spike/server-spike');
const JAVA = process.env.MC_BENCH_JAVA || 'C:/Program Files/Eclipse Adoptium/jre-21.0.12.101-hotspot/bin/java.exe';
// MC-M1-TASK-03：jar 与 bot 协议版本可切换（默认 1.21.1 原口径；1.16.1 迁移用
// MC_BENCH_JAR=server-1.16.1.jar + --mc-version 1.16.1 + MC_BENCH_SERVER/MC_BENCH_JAVA 指向 1.16 环境）
const JAR = path.join(SERVER_DIR, process.env.MC_BENCH_JAR || 'paper-1.21.1-133.jar');
const MC_VERSION = argOf(process.argv, 'mc-version', process.env.MC_BENCH_VERSION || '1.21.1');
const RCON_PASS = 'spike-rcon';

const TRIALS = parseInt(argOf(process.argv, 'trials', '20'), 10);
const START = parseInt(argOf(process.argv, 'start', '1'), 10);
const TARGET = parseInt(argOf(process.argv, 'target', '16'), 10);
const RESOURCE = argOf(process.argv, 'resource', 'iron_pickaxe'); // MC-M1-TASK-06
const TIMEOUT_MS = parseInt(argOf(process.argv, 'timeout-ms', '540000'), 10);
const RUNSTAMP = argOf(process.argv, 'stamp', `B2R${new Date().toISOString().slice(0, 13).replace(/[-T:]/g, '')}`);
// MC-M1-TASK-04：seed 复跑参数（默认不设 → seed 仍由 stamp 派生，原行为不变）
const SEED_PREFIX = argOf(process.argv, 'seed-prefix', RUNSTAMP);
const SEED_LITERAL = argOf(process.argv, 'seed', '');
const SEED_LIST = argOf(process.argv, 'seeds', ''); // MC-BENCH-v2：非连续种子表（验收②/06b 岩浆种子用）
// MC-BENCH-v2 新参数
const LANES = parseInt(argOf(process.argv, 'lanes', '1'), 10);
// MC-M1-TASK-06d P0：--lane A,B,C 按名选泳道（手册 §9 每条线只占一条）；没给则回退 --lanes N
const LANE_NAMES = parseLanes(process.argv);
const NO_PROGRESS_S = parseInt(argOf(process.argv, 'no-progress-s', '120'), 10);
const FAIL_BUDGET = parseFailBudget(argOf(process.argv, 'fail-budget', ''));
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const SERVER_XMX = argOf(process.argv, 'server-xmx', '1G');
const PROBE_MS = parseInt(argOf(process.argv, 'probe-ms', '10000'), 10);
// MC-M1-TASK-06c（验收协议 v3 §0.1）：开发局 kit 起步，只测目标环节。
// 不传 --kit = 零 kit（正式矩阵/回归一律不传），give 通道在 runner_core 里根本不会执行。
const KIT = argOf(process.argv, 'kit', '');
const RUNS_DIR = path.join(BENCH_DIR, 'runs', RUNSTAMP);

const trialNumbers = Array.from({ length: TRIALS }, (_, i) => START + i);
const seedList = SEED_LIST ? SEED_LIST.split(',').map((s) => s.trim()) : null;
const seedFor = (n) => {
    if (seedList) return seedList[n - START] ?? `${SEED_PREFIX}-${String(n).padStart(2, '0')}`;
    return SEED_LITERAL || `${SEED_PREFIX}-${String(n).padStart(2, '0')}`;
};

await runMatrix({
    runsDir: RUNS_DIR,
    summaryPath: path.join(RUNS_DIR, 'summary.jsonl'),
    execBotPath: path.join(BENCH_DIR, 'exec_bot.mjs'),
    stageLabel: `BASIC-iron (${RESOURCE})`,
    templateDir: SERVER_DIR,
    jarPath: JAR,
    java: JAVA,
    rconPass: RCON_PASS,
    trials: trialNumbers,
    seedFor,
    extraBotArgs: () => ['--resource', RESOURCE, '--target', String(TARGET)],
    lanes: LANES,
    laneNames: LANE_NAMES,
    mcVersion: MC_VERSION,
    timeoutMs: TIMEOUT_MS,
    noProgressMs: NO_PROGRESS_S * 1000,
    probeMs: PROBE_MS,
    failBudget: FAIL_BUDGET,
    minFreeBytes: MIN_FREE_MB * 1048576,
    serverXmx: SERVER_XMX,
    kit: KIT || undefined,
}).then(({ ok, total }) => {
    fs.mkdirSync(RUNS_DIR, { recursive: true });
    process.exit(0);
}).catch((e) => { console.error(e); process.exit(1); });
