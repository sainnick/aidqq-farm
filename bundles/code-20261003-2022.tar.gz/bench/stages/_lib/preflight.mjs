// preflight.mjs — MC-M1-TASK-06c P0：开工自检（手册 §1）。run 开始时由 runner_core 自动调用，
// 也可单独跑：node bench/stages/_lib/preflight.mjs [--kill-stale] [--json] [--lane A] [--who <标识>]
//
// 查五件事，任一阻塞项 → 退出码非零：
//   1. 运行时：Node20（.runtime/node-v20.20.2-win-x64）与便携 JDK11（experiments/mc1161-gate/jdk/*/）存在；
//   2. 端口：**本次 --lane 指定的那几条泳道** + tasked 冒烟 8091 是否空闲。别人的泳道只报告不阻塞。
//   3. 进程登记（ROUND3 派单 P0-1）：`.lane-owners/<lane>.json` 是**唯一的「本 runner 起过哪些 pid」台账**
//      （记录 runnerPid / sessionId / children[]，每 3s 刷新）。
//      **--kill-stale 只结束「在登记表里、且登记它的 runner pid 已经死了」的孤儿**，并且永远排除
//      自己的 pid 与自己登记的子进程。
//      ⚠ **已删除全部「命令行匹配 bench/stages 就算残留」的逻辑**——它连着三次误杀别的开发线
//        （06c 杀 B 线 micro_bench、ROUTE-02 杀 E 线 run_probe；见 handover/minecraft.md）。
//        拿不到登记就当别人的，只报告、不处置；宁可漏清，不可误杀。
//   4. 拍摄预约（ROUND3 派单 P0-3）：`.lane-owners/RESERVE.json` 生效期间拒绝开新局
//      （正在跑的那一局可以跑完 → runMatrix 在局与局之间等预约到期自动恢复）。预约者本人不受限。
//   5. 空闲内存：按每条泳道 ≥2.5GB 给推荐泳道数（手册 §4.7：白天 2 条、夜间 3 条）。
//
// 历史判据「server.log 90s 内还在写 ⇒ 疑似并行会话」也已删除：活着的服务器本来就在写日志，
// 该判据对任何残留恒真，等于永远不许清（06c P0 验收已实证）。

import { spawnSync } from 'child_process';
import { randomUUID } from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { readReserve } from './reserve.mjs';

const LIB_DIR = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(LIB_DIR, '../../..'); // D:/AI斗蛐蛐
const ROOT_N = ROOT.replace(/\\/g, '/').toLowerCase();

export const LANE_PORTS = [[25566, 25576], [25567, 25577], [25568, 25578]];
export const LANE_LETTERS = ['A', 'B', 'C'];
export const TASKED_SMOKE_PORT = 8091;
export const MEM_PER_LANE_MB = 2560;

/** 本进程（runner / 独立 CLI）的会话标识。每个进程一个，写进心跳台账，用来区分「我的」和「别人的」。 */
export const SESSION_ID = process.env.MC_BENCH_SESSION_ID || randomUUID();

/** 泳道名 → 端口对（'C' → [25568, 25578]） */
export function lanePortsOf(names) {
    return names.map((n) => {
        const i = LANE_LETTERS.indexOf(String(n).toUpperCase());
        if (i < 0) throw new Error(`未知泳道 "${n}"（可用 ${LANE_LETTERS.join('/')}）`);
        return LANE_PORTS[i];
    });
}

const arg = (name) => process.argv.includes(`--${name}`);
const argVal = (name, dft = null) => { const i = process.argv.indexOf(`--${name}`); return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : dft; };
export const log = (msg) => console.log(`[preflight ${new Date().toISOString().slice(11, 19)}] ${msg}`);

// ---- 进程清单（wmic 在本机 10.0.26200 已不可用，走 PowerShell CIM）----
export function procInfo() {
    const ps = "Get-CimInstance Win32_Process -Filter \"name='java.exe' or name='javaw.exe' or name='node.exe'\" | Select-Object ProcessId,ParentProcessId,Name,CommandLine,@{n='ageSec';e={[int]((Get-Date)-$_.CreationDate).TotalSeconds}} | ConvertTo-Json -Compress";
    const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { encoding: 'utf8', maxBuffer: 32 * 1048576 });
    const txt = (r.stdout || '').trim();
    if (!txt) return [];
    try {
        const j = JSON.parse(txt);
        return (Array.isArray(j) ? j : [j]).map((p) => ({
            pid: Number(p.ProcessId), ppid: Number(p.ParentProcessId) || null, name: p.Name, cmd: String(p.CommandLine ?? ''),
            ageSec: Number.isFinite(p.ageSec) ? p.ageSec : null,
        }));
    } catch { return []; }
}

/** 本线测试服进程：命令行里带 <workspace>/experiments/ 或 <workspace>/bench/ 路径 */
export function isOurs(cmd = '') {
    const c = cmd.replace(/\\/g, '/').toLowerCase();
    return c.includes(`${ROOT_N}/experiments/`) || c.includes(`${ROOT_N}/bench/`);
}

/** 从命令行里取出服务器目录（-jar <dir>/<jar>），用于判断「这个进程在动哪个泳道」 */
export function serverDirOf(cmd = '') {
    const m = /-jar\s+"?([^"\s]+\.jar)"?/i.exec(cmd.replace(/\\/g, '/'));
    if (!m) return null;
    const p = m[1].toLowerCase().startsWith('d:') ? m[1] : path.resolve(ROOT, m[1]);
    return path.dirname(p);
}

export function netstatListeners() {
    const out = spawnSync('netstat', ['-ano'], { encoding: 'utf8' }).stdout ?? '';
    const map = {}; // port -> Set(pid)
    for (const line of out.split(/\r?\n/)) {
        if (!line.includes('LISTENING')) continue;
        const parts = line.trim().split(/\s+/);
        const pm = parts[1] ? parts[1].match(/:(\d+)$/) : null;
        if (!pm) continue;
        const pid = parts.at(-1);
        if (!/^\d+$/.test(pid)) continue;
        (map[pm[1]] ??= new Set()).add(Number(pid));
    }
    return Object.fromEntries(Object.entries(map).map(([k, v]) => [k, [...v]]));
}

export function killTree(pid) {
    spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { stdio: 'ignore' });
}

// ⚠ 旧判据 `looksActiveFor(serverDir)`（「server.log 90s 内还在写 ⇒ 有人在跑」）已**删除**：
//   活着的服务器本来就在写日志 → 对任何残留都恒真 → --kill-stale 永远不敢动手（06c P0 验收实证）。
//   归属一律看下面的 pid 台账。

// ---- 进程登记台账 + 泳道归属心跳（OWNER 目录）----
// 起服方（cleanup.mjs::registerChild / registerProc）每 3s 刷新 <lane>.json，内容是
//   { lane, port, serverDir, runnerPid, sessionId, children:[pid,...], at }
// `children` = **这个 runner 亲自起过、且还活着的全部子进程**（java 服务器 + mineflayer bot）。
// 手册 §9.2 / ROUND3 P0-1：**只有登记在册的 pid 才允许被结束**；不在册的一律只报告、不处置。
export const OWNER_DIR = path.join(ROOT, 'experiments', 'mc1161-gate', '.lane-owners');
export const OWNER_FRESH_MS = 20000;
export const RESERVE_FILE = 'RESERVE.json';   // 同目录下的拍摄预约文件，不是心跳台账

const ownerKey = (serverDir) => (serverDir ? path.basename(serverDir).replace(/[^a-z0-9_.-]/gi, '_').toLowerCase() : null);

/** runner 侧调用：登记/刷新/撤销心跳。info.children = 该泳道当前活着的子进程 pid 列表。 */
export function ownerHeartbeat(serverDir, info) {
    const key = ownerKey(serverDir);
    if (!key) return null;
    const p = path.join(OWNER_DIR, `${key}.json`);
    try {
        fs.mkdirSync(OWNER_DIR, { recursive: true });
        fs.writeFileSync(p, JSON.stringify({
            ...info, children: [...new Set(info?.children ?? [])],
            runnerPid: process.pid, sessionId: SESSION_ID, at: new Date().toISOString(),
        }));
        return p;
    } catch { return null; }
}
export function ownerHeartbeatClear(serverDir) {
    const key = ownerKey(serverDir);
    if (!key) return;
    try { fs.rmSync(path.join(OWNER_DIR, `${key}.json`), { force: true }); } catch { /* 忽略 */ }
}

/** 读回心跳台账：{ [serverDir basename]: {lane, port, runnerPid, sessionId, children[], at, ageMs} } */
export function ownerTable() {
    const out = {};
    let files = [];
    try { files = fs.readdirSync(OWNER_DIR); } catch { return out; }
    for (const f of files) {
        if (!f.endsWith('.json')) continue;
        if (f.toUpperCase() === RESERVE_FILE.toUpperCase()) continue;   // 预约文件不是心跳
        const p = path.join(OWNER_DIR, f);
        try {
            const j = JSON.parse(fs.readFileSync(p, 'utf8'));
            if (typeof j?.runnerPid !== 'number') continue;             // 非台账文件
            out[f.replace(/\.json$/i, '')] = { ...j, ageMs: Date.now() - fs.statSync(p).mtimeMs };
        } catch { /* 半写文件：忽略 */ }
    }
    return out;
}

/** 活着的 runner pid 集合（心跳新鲜 + 进程仍在） */
export function liveOwnerPids(alives = new Set(procInfo().map((p) => p.pid))) {
    const s = new Set();
    for (const rec of Object.values(ownerTable())) {
        if (rec.ageMs != null && rec.ageMs > OWNER_FRESH_MS) continue;   // 心跳过期 = runner 没了
        const rp = Number(rec.runnerPid);
        if (!Number.isFinite(rp) || !alives.has(rp)) continue;            // 进程不在 = runner 没了
        s.add(rp);
    }
    return s;
}

/**
 * 进程登记表：pid → { lane, port, serverDir, runnerPid, sessionId, ageMs, runnerAlive, mine }
 * 手册 §9.2 的唯一依据。**表里没有的 pid = 别人的进程 = 只报告、不处置。**
 */
export function pidRegistry(alives = new Set(procInfo().map((p) => p.pid))) {
    const reg = new Map();
    for (const [key, rec] of Object.entries(ownerTable())) {
        const runnerAlive = rec.ageMs <= OWNER_FRESH_MS && alives.has(Number(rec.runnerPid));
        for (const pid of rec.children ?? []) {
            const n = Number(pid);
            if (!Number.isFinite(n)) continue;
            reg.set(n, {
                pid: n, key, lane: rec.lane ?? null, port: rec.port ?? null,
                serverDir: rec.serverDir ?? null, runnerPid: Number(rec.runnerPid),
                sessionId: rec.sessionId ?? null, ageMs: rec.ageMs, runnerAlive,
                mine: rec.sessionId === SESSION_ID,
            });
        }
    }
    return reg;
}

/**
 * 可结束的孤儿 pid：**在登记表里**、登记它的 runner 已经不在（或心跳过期）、而它自己还活着。
 * 这条是硬闸的一半；另一半是调用方必须把自己的 pid 排除（见 killableOrphanTargets）。
 */
export function registeredOrphans(reg = pidRegistry(), alives = new Set(procInfo().map((p) => p.pid))) {
    return [...reg.values()].filter((r) => !r.runnerAlive && alives.has(r.pid));
}

/** 孤儿里再去掉「自己的 pid」与「自己登记、runner 还活着的子进程」——preflight 绝不能自杀
 *  （ROUTE-02 报告的事故形态：runner 匹配「本线残留」→ 起服前无心跳 → 自判孤儿 → taskkill 自杀）。 */
export function killableOrphanTargets(reg = pidRegistry(), { excludePids } = {}) {
    const mine = new Set(excludePids ?? []);
    mine.add(process.pid);
    return registeredOrphans(reg).filter((r) => !mine.has(r.pid) && !(r.mine && r.runnerAlive));
}

/**
 * 归属判定：这个进程（或它的任一祖先）是不是某个活着的 runner 带的？
 * 泳道服务器自身就在心跳表里 → 属于活会话；runner 起的 bot（无 -jar）靠祖先 pid 命中。
 */
export function ownedByLiveSession(p, procsById, owners = liveOwnerPids()) {
    if (!owners.size) return null;
    let cur = p, hops = 0;
    while (cur && hops++ < 6) {
        if (owners.has(cur.pid)) return cur.pid === p.pid ? 'self' : `runner:${cur.pid}`;
        cur = cur.ppid ? procsById.get(cur.ppid) : null;
    }
    return null;
}

/** 按服务器目录判定（给没有 pid 上下文的调用方用） */
export function ownedByLiveDir(serverDir, owners = liveOwnerPids(), procsById = new Map(procInfo().map((p) => [p.pid, p]))) {
    const key = ownerKey(serverDir);
    if (!key) return null;
    const rec = ownerTable()[key];
    if (!rec || rec.ageMs > OWNER_FRESH_MS) return null;
    const rp = Number(rec.runnerPid);
    return owners.has(rp) ? `runner:${rp}` : null;
}

/**
 * 这个进程是不是「登记在册、但登记它的 runner 已经死了」的孤儿？
 * 手册 §9.2 硬闸：返回 true 的才允许被结束。**改成直接查 pid 台账**（不再靠祖先链 + 目录名反推）——
 * 台账记的就是「这个 runner 亲手起的那个 pid」，没有推断余地。
 */
export function hasDeadHeartbeatOwner(p, procsById = new Map(procInfo().map((x) => [x.pid, x])), alives = new Set(procInfo().map((x) => x.pid))) {
    void procsById;
    const rec = pidRegistry(alives).get(Number(p?.pid));
    return !!rec && !rec.runnerAlive;
}

export function recommendedLanes(freeMB = os.freemem() / 1048576) {
    return Math.min(LANE_PORTS.length, Math.max(0, Math.floor(freeMB / MEM_PER_LANE_MB)));
}
function runtimeChecks() {
    const node20 = path.join(ROOT, '.runtime', 'node-v20.20.2-win-x64', 'node.exe');
    const jdkRoot = path.join(ROOT, 'experiments', 'mc1161-gate', 'jdk');
    let jdk11 = null;
    try {
        const hit = fs.readdirSync(jdkRoot).find((d) => fs.existsSync(path.join(jdkRoot, d, 'bin', 'java.exe')));
        if (hit) jdk11 = path.join(jdkRoot, hit, 'bin', 'java.exe');
    } catch { /* 目录不存在 */ }
    return { node20: fs.existsSync(node20) ? node20 : null, jdk11 };
}

/**
 * @param {{killStale?:boolean, logFn?:(m:string)=>void, requireLanes?:number, laneNames?:string[],
 *          who?:string, ignoreReserve?:boolean}} [opt]
 *   laneNames: MC-M1-TASK-06d P0——按名指定泳道（['A','C']）；requireLanes 保留兼容（= 从 A 起前 N 条）。
 *   who:       本次运行的归属标识（开发线名，如 'A' / 'CAM'）。**它自己预约的拍摄窗口不拦自己。**
 */
export async function preflight(opt = {}) {
    const { killStale = false, requireLanes = 0 } = opt;
    const say = opt.logFn ?? log;
    // 手册 §9 并行开发：A/B/C 三条线各占一条泳道。**只把「本次 run 真会用的那几条泳道」当阻塞项**，
    // 别的线正在用的端口只报告、不阻塞、绝不动。
    // 06d P0：泳道从「--lanes N 取前 N 条」改成「--lane 按名字」——旧口径下 --lanes 1 检查的是 A，
    // 而要跑 C 的开发线（FULLRUN-01 报告的前缀切片问题）永远被 A 的占用卡住。
    const laneNames = opt.laneNames?.length
        ? opt.laneNames.map((n) => String(n).toUpperCase())
        : (requireLanes > 0 ? LANE_LETTERS.slice(0, requireLanes) : LANE_LETTERS);
    const myLanes = lanePortsOf(laneNames);
    const blockingPorts = [...myLanes.flat(), TASKED_SMOKE_PORT];
    const foreignPorts = [...LANE_PORTS.flat(), TASKED_SMOKE_PORT].filter((p) => !blockingPorts.includes(p));
    const blockers = [], warns = [], notes = [];
    const ports = blockingPorts;   // 阻塞判定只看本次要用的泳道；foreignPorts 只报告
    const listeners = netstatListeners();
    const procs = procInfo();
    const byPid = new Map(procs.map((p) => [p.pid, p]));
    const procsById = byPid;
    const alives = new Set(procs.map((p) => p.pid));
    const owners = liveOwnerPids(alives);
    const registry = pidRegistry(alives);

    // 1) 运行时
    const rt = runtimeChecks();
    if (!rt.node20) blockers.push(`Node20 运行时缺失：${path.join(ROOT, '.runtime/node-v20.20.2-win-x64/node.exe')}`);
    else notes.push(`node20 ok ${rt.node20}`);
    if (!rt.jdk11) blockers.push('便携 JDK11 缺失：experiments/mc1161-gate/jdk/*/bin/java.exe');
    else notes.push(`jdk11 ok ${rt.jdk11}`);
    notes.push(`本次泳道 = ${laneNames.join(',')}（端口 ${myLanes.flat().join(',')}）`);

    // 1b) 别的开发线正在用的端口（手册 §9：A/B/C 各一条泳道）——只报告，不阻塞、不动
    const foreignBusy = foreignPorts.filter((p) => (listeners[String(p)] ?? []).length);
    if (foreignBusy.length) {
        notes.push(`其他开发线正在占用 ${foreignBusy.join(',')}（不属于本次 --lane ${laneNames.join(',')}，不阻塞、不触碰）`);
    }

    // 1c) 拍摄预约（ROUND3 派单 P0-3）：**现在落在窗口里**才拒绝开新局。未来的窗口只提示不拦
    //     （「订了今晚 20:00 的窗口」不等于「现在就把全机冻住」）。正在跑的那一局由 runMatrix
    //     在局与局之间等它到期。
    const rv = readReserve();
    if (rv.active && !opt.ignoreReserve && rv.who !== (opt.who ?? null)) {
        blockers.push(`拍摄预约生效中：${rv.who} 预留 ${rv.from} → ${rv.to}（剩 ${rv.remainingMin}min）`
            + `${rv.note ? `｜${rv.note}` : ''} → 预约期内不开新局（正在跑的局可以跑完）`);
    } else if (rv.active) {
        notes.push(`拍摄预约 ${rv.who} ${rv.from}→${rv.to} 生效中（本方即预约者 ${rv.who}，不拦自己）`);
    } else if (rv.upcoming) {
        warns.push(`拍摄预约 ${rv.who} ${rv.from}→${rv.to} 还有 ${rv.minutesToStart}min 开始（不拦本次；到点自动生效）${rv.note ? `｜${rv.note}` : ''}`);
    } else if (rv.notStarted) {
        notes.push(`拍摄预约 ${rv.who} ${rv.from}→${rv.to}（${rv.minutesToStart}min 后开始，现在不拦）`);
    } else if (rv.raw) {
        notes.push(`拍摄预约 ${rv.who} ${rv.from}→${rv.to} 已过期（自动失效）`);
    }

    // 2) 端口占用（一个 pid 常同时占 server+rcon 两个端口，按 pid 汇总只报一次）
    //    ⚠ ROUND3 P0-1：**处置只看 pid 台账**。台账里没有的进程 = 别人的 = 只报告、永不 kill。
    //    台账里有、但登记它的 runner 已死 = 真孤儿 → --kill-stale 才结束（且排除自己的 pid）。
    const occupied = new Map(); // pid -> [port,...]
    for (const port of ports) {
        for (const pid of listeners[String(port)] ?? []) {
            if (!occupied.has(pid)) occupied.set(pid, []);
            occupied.get(pid).push(port);
        }
    }
    let killed = 0;
    for (const [pid, portList] of occupied) {
        const p = byPid.get(pid);
        const cmd = p?.cmd ?? '(命令行不可读)';
        const where = portList.map((x) => `:${x}`).join('');
        const r = registry.get(Number(pid));
        if (!r) {
            // 不在台账 = 没有任何 runner 登记起它。不问命令行、不问路径，一律当别人的。
            blockers.push(`${where} 被未登记的进程占用 pid=${pid} ${p?.name ?? '?'}（不在 .lane-owners 台账 → 视为别的开发线，只报告不动）: ${cmd.slice(0, 140)}`);
            continue;
        }
        if (r.runnerAlive) {
            const self = r.runnerPid === process.pid;
            blockers.push(`${where} 登记在 lane ${r.lane} 台账下，归属${self ? '本进程' : `活着的 runner(${r.runnerPid})`} → 疑似另一会话正在跑，未动`);
            continue;
        }
        if (killStale && !r.mine && pid !== process.pid) {
            killTree(pid); killed++; say(`kill-stale: 结束登记孤儿 pid=${pid} (${where}) lane=${r.lane}（登记它的 runner ${r.runnerPid} 已死）`);
        } else {
            blockers.push(`${where} 登记孤儿 pid=${pid} lane=${r.lane}（runner ${r.runnerPid} 已死）${killStale ? '，但属于本会话 → 不处置' : '，--kill-stale 可清'}`);
        }
    }

    // 3) 台账里的孤儿（不占契约端口的：bot / 老 runner）——**只有这些**在 --kill-stale 的射程内
    for (const r of killableOrphanTargets(registry)) {
        const p = byPid.get(r.pid);
        if (killStale) { killTree(r.pid); killed++; say(`kill-stale: 结束登记孤儿 pid=${r.pid} lane=${r.lane} ${String(p?.cmd ?? '').slice(0, 110)}`); }
        else warns.push(`登记孤儿进程 pid=${r.pid} lane=${r.lane}（runner ${r.runnerPid} 已死）: ${String(p?.cmd ?? '').slice(0, 110)}`);
    }
    // 3b) 台账外的 java/node（**只报告，一条都不处置**）。这正是跨线误杀的根因：
    //     别的开发线的自定义 bench 脚本不经 runner_core::registerChild，在台账里没有条目。
    for (const p of procs.filter((x) => !registry.has(x.pid) && x.pid !== process.pid
        && /(-jar|bench[/\\]stages|mc1161-gate|run_tasked_smoke)/.test(x.cmd.replace(/\\/g, '/')))) {
        const live = ownedByLiveSession(p, procsById, owners);
        warns.push(`未登记进程 pid=${p.pid} ${p.name} age=${Math.round((p.ageSec ?? 0) / 60)}min${live ? `（活 runner ${live} 的后代）` : ''} → 别人的，只报告不处置: ${String(p.cmd).slice(0, 100)}`);
    }
    if (killed) await new Promise((r) => setTimeout(r, 1500));

    // 4) 内存 → 推荐泳道
    const freeMB = Math.round(os.freemem() / 1048576);
    const rec = recommendedLanes(freeMB);
    notes.push(`free=${freeMB}MB → 推荐泳道 ${rec}（每条 ≥${MEM_PER_LANE_MB}MB；手册 §4.7 白天 2 / 夜间 3）`);
    if (laneNames.length > rec) warns.push(`当前空闲内存只够 ${rec} 条泳道，但本次要求 ${laneNames.length} 条（--lane ${laneNames.join(',')}）（内存护栏会让多出的泳道排队，不会 OOM）`);
    if (freeMB < MEM_PER_LANE_MB) blockers.push(`空闲内存 ${freeMB}MB < 单条泳道下限 ${MEM_PER_LANE_MB}MB，不开跑`);

    // 5) 端口空闲汇总
    const stillBusy = ports.filter((pt) => (listeners[String(pt)] ?? []).length && !(killStale && killed));
    notes.push(`ports ${stillBusy.length ? `占用中: ${stillBusy.join(',')}` : `${ports.join(',')} 全空闲`}`);

    const lines = [...notes.map((n) => `  · ${n}`), ...warns.map((w) => `  ! ${w}`), ...blockers.map((b) => `  X ${b}`)];
    return { ok: blockers.length === 0, blockers, warns, notes, recommendedLanes: rec, freeMB, runtime: rt, killed, reserve: rv, lines };
}

if (process.argv[1] && path.resolve(process.argv[1]).endsWith('preflight.mjs')) {
    // ⚠ 这里**不能** `await import('./runner_core.mjs')` 去拿 parseLanes：runner_core 静态 import
    //   本模块 + line_lock，而本模块的 CLI 块是顶层 await → ESM 循环 + TLA 会死锁
    //   （症状：命令行跑 preflight 直接 exit 13「Unfinished top-level await」，零输出）。
    //   parseLanes 就地实现一份（与 runner_core 的口径一致），保持 preflight 单向依赖。
    const parseLanesCli = (argv) => {
        const i = argv.indexOf('--lane');
        if (i >= 0 && argv[i + 1]) {
            const names = String(argv[i + 1]).split(',').map((s) => s.trim().toUpperCase()).filter(Boolean);
            for (const n of names) if (!LANE_LETTERS.includes(n)) throw new Error(`--lane 里有未知泳道 "${n}"（可用 ${LANE_LETTERS.join('/')}）`);
            return [...new Set(names)];
        }
        const j = argv.indexOf('--lanes');
        const n = j >= 0 && argv[j + 1] ? parseInt(argv[j + 1], 10) : 1;
        if (!Number.isFinite(n) || n < 1) throw new Error(`--lanes 需要 ≥1 的整数（收到 "${argv[j + 1]}"）`);
        return LANE_LETTERS.slice(0, n);
    };
    const res = await preflight({
        killStale: arg('kill-stale'), laneNames: parseLanesCli(process.argv),
        who: argVal('who'),
    });
    if (arg('json')) console.log(JSON.stringify(res, null, 2));
    else {
        log(`start（--kill-stale=${arg('kill-stale')}）`);
        for (const l of res.lines) console.log(l);
        log(res.ok ? 'PASS：可以开跑' : `BLOCKED：${res.blockers.length} 项阻塞`);
    }
    process.exit(res.ok ? 0 : 1);
}
