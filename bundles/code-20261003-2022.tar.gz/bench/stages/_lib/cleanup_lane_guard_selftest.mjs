// cleanup_lane_guard_selftest.mjs — MC-M1-TASK-09-r3 ① 的离线用例
//
// 验的是什么：`cleanup.mjs` **独立调用**时若不带 `--lane`/`--lanes`，必须
//   ① 退出码 2（不是 0、不是 1，也不是"照跑"）；
//   ② 打印用法；
//   ③ **一个 world 都不删、任何进程都不碰**。
// 旧行为是不带泳道就默认按泳道 A 处理并删 A 的 world（G 线 10-02 踩过；
// 手册 §1 已改成"必须带 --lane"，脚本没跟上）。
//
// ⚠ 为什么不直接跑一次"带 --lane"的真 cleanup 来验"带 lane 行为不变"：
//   那会真的对**当前正在跑服的那条泳道**发 stop / 删 world —— 如果此时有本线
//   或别线的服在跑，这个自检就会**杀掉别人的服**。所以：
//   · "带 lane 放行"用**纯函数** `resolveCliScope` 离线验（零副作用）；
//   · 真实退出码只验**拒跑**那一条（拒跑路径在任何实现下都不该有副作用，
//     真删了 world 就说明闸门没生效 —— 用"泳道 A 的 world 目录清单前后一致"当证据）。
//
// 跑法：node cleanup_lane_guard_selftest.mjs     （退出码 0 = 全过）

import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const LIB = path.dirname(fileURLToPath(import.meta.url));
const NODE = process.execPath;
const CLEANUP = path.join(LIB, 'cleanup.mjs');

let pass = 0, fail = 0;
const ok = (cond, name, extra = '') => {
    if (cond) { pass++; console.log(`  ✅ ${name}`); }
    else { fail++; console.log(`  ❌ ${name}${extra ? '  → ' + extra : ''}`); }
};

// —— 泳道 A 的 world 目录清单（用来证明"拒跑时一个 world 都没删"）——
const LANE_A_DIR = path.resolve(LIB, '../../../experiments/mc1161-gate/server-1161');
function laneAWorldDirs() {
    if (!fs.existsSync(LANE_A_DIR)) return null;
    return fs.readdirSync(LANE_A_DIR).filter((d) => /^world/.test(d) || /level-name/.test(d)).sort();
}

console.log('=== cleanup 泳道闸门离线自检（MC-M1-TASK-09-r3 ①）===\n');

// ═══════ 一、纯函数层：resolveCliScope（零副作用，可穷举）═══════
console.log('--- 纯函数：resolveCliScope ---');
const { resolveCliScope, CLI_USAGE } = await import('./cleanup.mjs');

const cases = [
    { argv: [], ok: false, why: '无参数' },
    { argv: ['--keep-world'], ok: false, why: '只有 --keep-world' },
    { argv: ['--json'], ok: false, why: '只有 --json（JSON 输出同样有副作用，不能放行）' },
    { argv: ['--label', '收工'], ok: false, why: '只有 --label' },
    { argv: ['--lane', 'A'], ok: true, why: '单泳道' },
    { argv: ['--lane', 'A', '--keep-world'], ok: true, why: '单泳道 + 保留 world' },
    { argv: ['--lane', 'a,b', '--json'], ok: true, why: '小写多泳道' },
    { argv: ['--lanes', '2'], ok: true, why: '旧参数 --lanes' },
    { argv: ['--lanes', '3', '--keep-world'], ok: true, why: '旧参数 + 保留 world' },
    { argv: ['--all-lanes'], ok: false, why: '--all-lanes 不是泳道指定（不能当成"我全都要"放行）' },
];
for (const c of cases) {
    const r = resolveCliScope(c.argv);
    ok(r.ok === c.ok, `resolveCliScope([${c.argv.join(' ')}]) ⇒ ${c.ok ? '放行' : '拒绝'}（${c.why}）`,
        `实际 ${r.ok ? '放行' : '拒绝'}，reason=${r.reason}`);
}
ok(resolveCliScope(['--lane', 'a,b']).laneNames.join(',') === 'A,B', '--lane a,b 归一化成 A,B',
    JSON.stringify(resolveCliScope(['--lane', 'a,b']).laneNames));
ok(resolveCliScope(['--lane', 'A']).lanes === undefined, '带 --lane 时不产生 --lanes 的默认值',
    String(resolveCliScope(['--lane', 'A']).lanes));
ok(CLI_USAGE.length >= 2 && CLI_USAGE.every((l) => l.includes('--lane')), '用法文本里写明了 --lane');

// ═══════ 二、子进程层：真实退出码（只验拒跑路径，零副作用）═══════
console.log('\n--- 子进程：真实退出码与输出（只跑拒跑路径）---');
const before = laneAWorldDirs();
const r = spawnSync(NODE, [CLEANUP], { encoding: 'utf8', timeout: 30000 });
ok(r.status === 2, '不带 --lane ⇒ 退出码 2', `实际 ${r.status}（stdout=${String(r.stdout).slice(0, 80)}）`);
ok(/拒绝执行/.test(r.stderr), '打印了"拒绝执行"', JSON.stringify(String(r.stderr).slice(0, 120)));
ok(/--lane/.test(r.stderr), '打印了用法（含 --lane）');
ok(/没有起服|没起服|不需要跑 cleanup/.test(r.stderr), '说明了"没起服就别跑"的理由');
const after = laneAWorldDirs();
if (before === null || after === null) {
    console.log('  ⚠ 泳道 A 的 server 目录不存在 ⇒  world 目录清单这项**测不了**（toolFailed，不计通过）');
} else {
    ok(JSON.stringify(before) === JSON.stringify(after),
        '★ 拒跑时泳道 A 的 world 目录清单前后完全一致（一个都没删）',
        `${JSON.stringify(before)} → ${JSON.stringify(after)}`);
}

// —— 反向验收：把闸门摘掉，这一条必须变红（证明用例抓得住，而不是恒绿）——
//    做法：不改 cleanup.mjs，而是断言"闸门代码在文件里"这条**结构**事实；
//    真正的变异测试由主 agent 用编辑回退跑一次（见报告 §3.1）。
const src = fs.readFileSync(CLEANUP, 'utf8');
// 结构断言必须只看**代码**、不看注释：本次改动把旧分支的原文写进了注释里说明来历，
// 若不剥注释，"旧分支已移除"这条会被自己的注释判红。
// 顺序：先剥 /* */ 块注释，再剥 // 行注释（只剥一层块注释，够用且不会误伤字符串）。
const code = src
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .split(/\r?\n/).map((l) => l.replace(/\s*\/\/.*$/, '')).join('\n');
ok(/resolveCliScope\(process\.argv\.slice\(2\)\)/.test(code) && /process\.exit\(2\)/.test(code),
    '闸门代码确实在 cleanup.mjs 的 CLI 块里（结构断言）');
ok(!/live\.length \? \[\] : \[\{ dir: defaultTemplateDir\(\), port: LANE_PORTS\[0\]\[0\] \}\]/.test(code),
    '★ 旧的"独立 CLI 默认只管 A"分支已从**代码**里移除（不是仅在前面加了一道闸）');
ok(/: \[\]\)/.test(code) && /不删任何 world/.test(src),
    '未指定泳道时的兜底是"删 0 条"而不是"删 A"');

console.log(`\n=== ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail === 0 ? 0 : 2);
