// line_lock.mjs — MC 第三轮派单 P0-2：**每条开发线同一时间只能有一个会话**。
//
// 问题（ROUND3 §0.1 + 06c/ROUTE-02 事故）：B 线上一轮有两个会话在同一泳道、同一批文件上并行，
// 一边 killStale 一边起服，结果是「A 线的 preflight 把 B 线在跑的 micro_bench 当残留杀了」。
// 端口空闲**不能**代表泳道没人用——局与局之间端口会短暂空闲，心跳才是归属依据。
//
// 机制：`.line-locks/<LINE>.json`（放在 experiments/mc1161-gate/ 下，与 .lane-owners 同级）
//   { line, who, session, pid, startedAt, at, cmd }
//   - acquire(line) 时若发现**活锁**（心跳新鲜 且 持锁 pid 还在）→ **拒绝启动**并打印持锁者。
//     **不允许"接管"**（派单原话：发现已有活锁就停下）。
//   - 持锁期间每 10s 刷新心跳；进程正常退出时 release() 删文件。
//   - pid 已死 / 心跳超过 STALE_MS（默认 45s）→ 判定为陈旧锁，可被后来者接管（并留痕 overwrittenBy）。
//   - 锁是**按泳道**的：A 与 C 互不影响（E 线独占 C 时，A 照常起 A）。
//
// 用法（runner 侧，推荐一行）：
//   const held = await holdLocks(['A'], { who: 'A', label: 'basic-iron P2B' });  // 失败直接 throw
//   ... 跑 ...
//   await held.releaseAll();
// CLI：
//   node bench/stages/_lib/line_lock.mjs --lane A --who A --label "试一下"   # 拿锁并挂住到 Ctrl-C
//   node bench/stages/_lib/line_lock.mjs --status

import fs from 'fs';
import path from 'path';
import os from 'os';
import { spawnSync } from 'child_process';
import { fileURLToPath } from 'url';
import { SESSION_ID } from './preflight.mjs';

const LIB_DIR = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(LIB_DIR, '../../..');
export const LOCK_DIR = path.join(ROOT, 'experiments', 'mc1161-gate', '.line-locks');
export const LOCK_STALE_MS = 45000;
const BEAT_MS = 10000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 一次 tasklist 拿全部 pid 存活集合（缓存 2s：lockTable 会连着问十几次） */
let _aliveCache = { at: 0, set: null };
export function alivePids() {
    if (_aliveCache.set && Date.now() - _aliveCache.at < 2000) return _aliveCache.set;
    const set = new Set();
    try {
        const r = spawnSync('tasklist', ['/NH', '/FO', 'CSV'], { encoding: 'utf8', maxBuffer: 16 * 1048576 });
        for (const line of String(r.stdout ?? '').split(/\r?\n/)) {
            // tasklist /FO CSV 的 **PID 字段也是带引号的**： "node.exe","12345","Console","1","50,000 K"
            const m = /^"[^"]*",\s*"?(\d+)"?\s*,/.exec(line.trim());
            if (m) set.add(Number(m[1]));
        }
    } catch { /* 拿不到就当全死不合适 → 返回空，调用方按「查不到=不当孤儿」处理 */ }
    _aliveCache = { at: Date.now(), set };
    return set;
}

/** pid 是否还活着（查不到 → 一律当活着，宁可不接管） */
export function pidAlive(pid) {
    const n = Number(pid);
    if (!Number.isFinite(n) || n <= 0) return false;
    if (n === process.pid) return true;
    const s = alivePids();
    return s.size === 0 ? true : s.has(n);
}

const lockPath = (line) => path.join(LOCK_DIR, `${String(line).toUpperCase()}.json`);

/** 读锁：{ line, who, session, pid, startedAt, at, ageMs, live }，没有则 null */
export function readLock(line) {
    const p = lockPath(line);
    let j;
    try { j = JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; }
    if (!j || typeof j.pid !== 'number') return null;
    const ageMs = Date.now() - fs.statSync(p).mtimeMs;
    return { ...j, ageMs, live: ageMs <= LOCK_STALE_MS && pidAlive(j.pid) };
}

/** 全线锁一览：{ A: {...}, B: {...} }（只含存在的锁文件） */
export function lockTable() {
    const out = {};
    let files = [];
    try { files = fs.readdirSync(LOCK_DIR); } catch { return out; }
    for (const f of files) {
        if (!/^[A-Za-z0-9]+\.json$/.test(f)) continue;
        const rec = readLock(f.replace(/\.json$/i, ''));
        if (rec) out[rec.line ?? f.replace(/\.json$/i, '')] = rec;
    }
    return out;
}

/**
 * 拿线锁。已有**活锁**时拒绝（返回 { ok:false, holder }）；陈旧锁（pid 已死或心跳过期）可接管。
 * 同一进程重复 acquire 同一泳道是幂等的（返回 ok）。
 */
export function acquire(line, { who, label = '', force = false } = {}) {
    const L = String(line).toUpperCase();
    const holder0 = readLock(L);
    const mine = holder0 && holder0.pid === process.pid && holder0.session === SESSION_ID;
    if (holder0 && holder0.live && !mine && !force) {
        return {
            ok: false, line: L, holder: holder0,
            reason: `线锁被占：${holder0.who}（pid ${holder0.pid}）自 ${holder0.startedAt} 持有`
                + `${holder0.label ? `｜${holder0.label}` : ''}｜心跳 ${(holder0.ageMs / 1000).toFixed(0)}s 前`
                + ` → 手册 §9.2「每条线同一时间只能有一个会话」：不要接管，停下让路`,
        };
    }
    const rec = {
        line: L, who: who ?? os.userInfo().username, session: SESSION_ID, pid: process.pid,
        label, startedAt: mine ? holder0.startedAt : new Date().toISOString(),
        at: new Date().toISOString(), host: os.hostname(),
        ...(holder0 && !mine ? { overwritten: { who: holder0.who, pid: holder0.pid, at: new Date().toISOString(), reason: holder0.live ? 'force' : 'stale' } } : {}),
    };
    fs.mkdirSync(LOCK_DIR, { recursive: true });
    fs.writeFileSync(lockPath(L), JSON.stringify(rec, null, 2) + '\n');
    return { ok: true, line: L, lock: rec, tookOver: !!(holder0 && !mine) };
}

/** 刷新心跳（持锁期间定时调） */
export function refresh(handle) {
    if (!handle?.ok) return false;
    const cur = readLock(handle.line);
    if (!cur || cur.session !== SESSION_ID || cur.pid !== process.pid) return false;   // 锁被别人接管了 → 放弃
    cur.at = new Date().toISOString();
    fs.writeFileSync(lockPath(handle.line), JSON.stringify({ ...cur, ageMs: undefined }, (k, v) => (v === undefined ? undefined : v), 2) + '\n');
    return true;
}

/** 释放线锁（只删自己那把） */
export function release(handle) {
    if (!handle?.ok) return false;
    const cur = readLock(handle.line);
    if (cur && cur.session !== SESSION_ID) return false;   // 已被别人接管，不动
    try { fs.rmSync(lockPath(handle.line), { force: true }); return true; } catch { return false; }
}

/**
 * runner 一行接入：拿多条泳道的锁 + 自动心跳 + 退出时释放。
 * 任一条被占 → 释放已拿到的并抛错（**不接管**）。
 */
export async function holdLocks(lines, { who, label = '', logFn = null, throwOnBusy = true } = {}) {
    const say = logFn ?? ((m) => console.log(`[line_lock ${new Date().toISOString().slice(11, 19)}] ${m}`));
    const held = [];
    for (const L of lines) {
        const r = acquire(L, { who, label });
        if (!r.ok) {
            for (const h of held) release(h);
            say(`✗ ${r.reason}`);
            if (throwOnBusy) { const e = new Error(`LINE_LOCKED:${L}`); e.lockReason = r.reason; e.holder = r.holder; throw e; }
            return { ok: false, reason: r.reason, holder: r.holder, releaseAll: async () => {} };
        }
        held.push(r);
        say(`线锁 ${L} 已拿到（who=${who ?? '?'} pid=${process.pid}${r.tookOver ? '，接管了一把陈旧锁' : ''}）`);
    }
    const timer = setInterval(() => { for (const h of held) refresh(h); }, BEAT_MS);
    if (timer.unref) timer.unref();
    const releaseAll = async () => { clearInterval(timer); for (const h of held) if (release(h)) say(`线锁 ${h.line} 已释放`); };
    process.once('exit', () => { clearInterval(timer); for (const h of held) release(h); });
    return { ok: true, held, releaseAll };
}

if (process.argv[1] && path.resolve(process.argv[1]).endsWith('line_lock.mjs')) {
    const has = (n) => process.argv.includes(`--${n}`);
    const val = (n, d = null) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : d; };
    const tag = (m) => console.log(`[line_lock ${new Date().toISOString().slice(11, 19)}] ${m}`);
    if (has('status') || !val('lane')) {
        const t = lockTable();
        if (!Object.keys(t).length) tag('当前没有任何线锁');
        for (const [k, v] of Object.entries(t)) {
            tag(`${k}: ${v.live ? '🔒 活锁' : '（陈旧）'} ${v.who} pid=${v.pid} 起 ${v.startedAt}${v.label ? `｜${v.label}` : ''}｜心跳 ${(v.ageMs / 1000).toFixed(0)}s 前`);
        }
        process.exit(0);
    } else {
        const r = acquire(val('lane'), { who: val('who'), label: val('label', ''), force: has('force') });
        if (!r.ok) { tag(`✗ ${r.reason}`); process.exit(3); }
        tag(`✔ 拿到线锁 ${r.line}（pid=${process.pid}，Ctrl-C 释放）`);
        const t = setInterval(() => refresh(r), BEAT_MS);
        for (const s of ['SIGINT', 'SIGTERM']) process.on(s, async () => { clearInterval(t); release(r); tag('已释放'); process.exit(0); });
        await sleep(24 * 3600 * 1000);
        clearInterval(t); release(r);
    }
}
