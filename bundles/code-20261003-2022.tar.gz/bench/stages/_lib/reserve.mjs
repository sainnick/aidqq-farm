// reserve.mjs — MC 第三轮派单 P0-3：拍摄预约窗口。
//
// 问题（ROUND3 §0.1）：上一轮 6 条开发线抢 3 条泳道，拍摄线（CAM-01）一整晚没等到窗口——
// 门控四项全过、内存也够，但发起开测的两分钟内 A 泳道又起了新 trial（runner pid 19752→29840→
// 34188→26316 四个都不同 = 夜间连轴开新局）。**机器同时只跑得下 2–3 个测试服**，所以必须
// 由被让的那条线**显式预约**，而不是让每条线各自猜内存。
//
// 机制：`.lane-owners/RESERVE.json`（与 pid 台账同目录）
//   { who, from, to, note, createdAt }
//  - **生效期间**（now < to）preflight 拒绝任何泳道**开新局**；**已经跑着的那一局可以跑完**
//    → runMatrix 在「局与局之间」检查预约并等待，到期自动继续（见 runner_core.waitReserveClear）。
//  - 预约者本人不受限（preflight 的 `who` 参数 == 预约的 who 就放行），否则 D 线自己被自己拦。
//  - **到期自动失效**：readReserve() 只按时间戳判，不看进程，不需要谁去清。
//
// 用法：
//   node bench/stages/_lib/reserve.mjs --who CAM --from 2026-10-02T20:00 --minutes 60
//   node bench/stages/_lib/reserve.mjs --status
//   node bench/stages/_lib/reserve.mjs --clear --who CAM      # 只允许预约者自己清
//   node bench/stages/_lib/reserve.mjs --clear --force        # 强制清（需要人工判断）

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const LIB_DIR = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(LIB_DIR, '../../..');
export const OWNER_DIR = path.join(ROOT, 'experiments', 'mc1161-gate', '.lane-owners');
export const RESERVE_PATH = path.join(OWNER_DIR, 'RESERVE.json');

const pad = (n) => String(n).padStart(2, '0');

/** 解析 'now' / '2026-10-02T20:00' / '2026-10-02 20:00' / '20:00'（今天的 HH:mm） → Date */
export function parseWhen(s) {
    if (!s || s === 'now') return new Date();
    const t = String(s).trim();
    if (/^\d{1,2}:\d{2}$/.test(t)) {
        const [h, m] = t.split(':').map(Number);
        const d = new Date(); d.setHours(h, m, 0, 0);
        if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);   // 只给时刻且已过 → 当它指明天
        return d;
    }
    const d = new Date(t.replace(' ', 'T'));
    if (Number.isNaN(d.getTime())) throw new Error(`时间解析不了：${s}（用 now / 20:00 / 2026-10-02T20:00）`);
    return d;
}

// ⚠ 秒必须留着：曾经只存到分钟，于是「预约 30 秒」会被截成 `10:44` 而当场判定为已过期
//   （写进去的时刻是 10:44:30，读回来变成 10:44:00 < now）。ISO 本地时间也不带时区偏移，
//   所以这里自己拼，不能用 toISOString()。
const isoLocal = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;

/**
 * 读预约状态。**永不抛错**：文件不存在 / 半写 / 字段缺失一律当"没有预约"。
 *
 * ⚠ active 的口径是「**现在**落在窗口里」：`from <= now < to`。
 *   曾经写成 `now < to`，于是**订了今晚 20:00–21:00 的窗口，白天 11:00 就把全机冻住**——
 *   D 线第一次用 reserve.mjs 订窗口时立刻撞上（A 线起服被 preflight 拦死）。
 *   未来窗口只作提示（imminentSoon），不拦人；到点自动生效，不需要谁再去动它。
 */
export function readReserve({ imminentWithinMs = 30 * 60000 } = {}) {
    const none = { active: false, upcoming: false, notStarted: false, who: null, from: null, to: null, note: null, remainingMin: 0, minutesToStart: null, expired: false, raw: null };
    let j;
    try { j = JSON.parse(fs.readFileSync(RESERVE_PATH, 'utf8')); } catch { return none; }
    if (!j || typeof j !== 'object' || !j.who || !j.to) return none;
    const to = new Date(j.to);
    if (Number.isNaN(to.getTime())) return none;
    const from = j.from ? new Date(j.from) : null;
    const now = Date.now();
    const active = (!from || from.getTime() <= now) && now < to.getTime();
    const notStarted = !!from && from.getTime() > now;
    return {
        active,
        notStarted,
        upcoming: notStarted && from.getTime() - now <= imminentWithinMs,
        who: String(j.who),
        from: j.from ?? null,
        to: isoLocal(to),
        note: j.note ?? null,
        remainingMin: active ? Math.max(1, Math.ceil((to.getTime() - now) / 60000)) : 0,
        minutesToStart: notStarted ? Math.ceil((from.getTime() - now) / 60000) : null,
        expired: now >= to.getTime(),
        raw: j,
    };
}

/** 写预约。minutes 与 to 二选一；from 默认 now。 */
export function setReserve({ who, from, minutes, to, note } = {}) {
    if (!who) throw new Error('要一个 who（预约者标识，例如 CAM / D）');
    const start = from ? parseWhen(from) : new Date();
    const end = to ? parseWhen(to) : new Date(start.getTime() + (Number(minutes) || 60) * 60000);
    if (end.getTime() <= start.getTime()) throw new Error(`预约结束时间必须晚于开始：${isoLocal(start)} → ${isoLocal(end)}`);
    const rec = { who: String(who), from: isoLocal(start), to: isoLocal(end), note: note ?? null, createdAt: new Date().toISOString() };
    fs.mkdirSync(OWNER_DIR, { recursive: true });
    fs.writeFileSync(RESERVE_PATH, JSON.stringify(rec, null, 2) + '\n');
    return rec;
}

/** 清预约。默认只允许预约者本人清；force=true 无条件清。 */
export function clearReserve({ who, force = false } = {}) {
    const cur = readReserve();
    if (!cur.raw) return { cleared: false, reason: '没有预约' };
    if (!force && who && cur.who !== String(who)) return { cleared: false, reason: `预约属于 ${cur.who}，${who} 不能清（要强制清用 --force）` };
    try { fs.rmSync(RESERVE_PATH, { force: true }); return { cleared: true, was: cur }; } catch (e) { return { cleared: false, reason: String(e) }; }
}

/**
 * 局与局之间的等待闸：预约生效时**不结束 runner**，只停在队头等它到期（默认最多 6h）。
 * 预约者本人（who === rv.who）直接放行。
 * 返回 { waited, resumed }，供 runner 落日志。
 */
export async function waitReserveClear({ who = null, logFn = null, pollMs = 10000, maxWaitMs = 6 * 3600 * 1000 } = {}) {
    const t0 = Date.now();
    let announced = false;
    for (;;) {
        const rv = readReserve();
        if (!rv.active || (who && rv.who === String(who))) {
            if (announced && logFn) logFn(`拍摄预约 ${rv.who} 已到期/解除 → 继续开新局（等了 ${((Date.now() - t0) / 60000).toFixed(1)}min）`);
            return { waited: announced, ms: Date.now() - t0 };
        }
        if (!announced) {
            announced = true;
            if (logFn) logFn(`⏸ 拍摄预约生效中：${rv.who} ${rv.from}→${rv.to}（剩 ${rv.remainingMin}min）→ 本局跑完后**不再开新局**，到期自动恢复`);
        }
        if (Date.now() - t0 > maxWaitMs) {
            if (logFn) logFn(`✗ 等拍摄预约超过 ${(maxWaitMs / 60000).toFixed(0)}min，放弃剩余排队局`);
            return { waited: true, ms: Date.now() - t0, gaveUp: true };
        }
        await new Promise((r) => setTimeout(r, pollMs));
    }
}

// ---- CLI ----
if (process.argv[1] && path.resolve(process.argv[1]).endsWith('reserve.mjs')) {
    const has = (n) => process.argv.includes(`--${n}`);
    const val = (n, d = null) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : d; };
    const tag = (m) => console.log(`[reserve ${new Date().toISOString().slice(11, 19)}] ${m}`);
    if (has('clear')) {
        const r = clearReserve({ who: val('who'), force: has('force') });
        tag(r.cleared ? `已清预约（原 ${r.was?.who} ${r.was?.from}→${r.was?.to}）` : `没清：${r.reason}`);
        process.exit(r.cleared ? 0 : 1);
    } else if (has('status') || (!has('minutes') && !has('to'))) {
        const r = readReserve();
        if (!r.raw) { tag('当前没有预约'); process.exit(0); }
        const state = r.active ? `生效中（剩 ${r.remainingMin}min）`
            : (r.notStarted ? `${r.minutesToStart}min 后开始（现在不拦）` : '已过期（自动失效）');
        tag(`${state}：${r.who} ${r.from} → ${r.to}${r.note ? `｜${r.note}` : ''}`);
        console.log(JSON.stringify(r, null, 2));
        process.exit(0);
    } else {
        const rec = setReserve({ who: val('who'), from: val('from'), minutes: val('minutes'), to: val('to'), note: val('note') });
        tag(`已预约：${rec.who} ${rec.from} → ${rec.to}（${rec.note ?? ''}）→ 期间所有泳道不开新局，正在跑的局可以跑完`);
        process.exit(0);
    }
}
