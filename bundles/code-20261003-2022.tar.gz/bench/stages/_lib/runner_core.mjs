// runner_core.mjs — MC-BENCH-v2 benchmark runner 核心（泳道并行 + 内存护栏 +
// 无进展硬中止 + 失败预算提前收手）。basic-iron / basic-bootstrap 两个 run_bench 共用。
//
// BENCH-v2 任务单四件事：
//   1. 多路并行：N 条泳道，每条独立服务器目录/端口/bot 名。泳道 A=25566/25576（现有
//      契约目录原样用），B=25567/25577、C=25568/25578（目录按模板自动派生：
//      <MC_BENCH_SERVER>_laneB/_laneC，jar+eula 复制、server.properties 改端口）。
//      内存护栏：每局开服前查空闲内存，< min-free-mb 就排队等待不起服。服务器 -Xmx
//      可调（默认 1G，BENCH-v2 实测口径）。汇总按 seed 合并进同一个 summary.jsonl，
//      行结构与串行完全同口径（新增 lane/attempt 字段，纯增量）。
//   2. 快速判负：runner 层无进展硬中止——exec_bot 周期性落 probe.jsonl（任务树+背包+
//      位置+挖掘+熔炉进度签名），runner 连续 no-progress-s（默认 120s）签名不变 →
//      NO_PROGRESS_ABORT 收局。合法长等待（熔炼读秒/下挖）由签名里的熔炉秒数与
//      digging/pos 通道保活，不误杀（BENCH-v2 验收②实测）。
//   3. 提前收手：--fail-budget N（第 N 个非 SUCCESS 终局出现 → 取消剩余排队局，
//      报告标 EARLY_STOP；已在跑的局跑完）。--fail-budget lava=N 专用于「第 N 次
//      岩浆死亡收手」（读局内 server.log 的 tried to swim in lava）。
//   4. 失败归因自动化：见 basic-iron/summarize.mjs（读 summary + 每局遥测/probe）。
//
// 兼容性：--lanes 1（默认）= 原串行语义（逐局顺序、stdout inherit、summary 行结构不变）；
// JAVA_TOOL_OPTIONS=-Djava.net.preferIPv4Stack=true 在本进程内补设（原由 run_with_retry.sh
// 外部注入，防 JVM NIO loopback 启动抖动；TASK-04 实证 flag 不能根治、靠启动重试兜底）。

import { spawn, spawnSync } from 'child_process';
import os from 'os';
import fs from 'fs';
import path from 'path';
import net from 'net';
import { preflight, netstatListeners, pidRegistry } from './preflight.mjs';
import { cleanup, registerChild, registerProc, unregisterChild, installRunnerHooks } from './cleanup.mjs';
import { holdLocks } from './line_lock.mjs';
import { waitReserveClear } from './reserve.mjs';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function argOf(argv, name, dflt) {
    const i = argv.indexOf(`--${name}`);
    return i >= 0 ? argv[i + 1] : dflt;
}

export const log = (msg) => { console.log(`[bench ${new Date().toISOString().slice(11, 19)}] ${msg}`); };

export function killTree(pid) {
    try { spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { stdio: 'ignore' }); } catch { /* 忽略 */ }
}

// （TASK-06c P0）端口/残留进程预检从 runner_core 内的 netstat 片段升级为
// _lib/preflight.mjs：区分「本线测试服残留」与「非本线进程/并行会话在跑」，只动前者。
// RCON 停服通道删除（手册 §2：RCON 会毒化服务进程）→ stopServer 改走 stdin 控制台。

// ---- 内存护栏 ----
export async function waitFreeMem(minBytes, logFn) {
    let waited = 0;
    while (os.freemem() < minBytes) {
        if (waited % 30000 === 0) logFn(`memory guard: free=${(os.freemem() / 1048576).toFixed(0)}MB < ${(minBytes / 1048576).toFixed(0)}MB, queuing...`);
        await sleep(5000);
        waited += 5000;
    }
    return waited;
}

// ---- 泳道 ----
export function parseFailBudget(s) {
    if (!s) return null;
    const m = /^lava=(\d+)$/.exec(String(s));
    if (m) return { mode: 'lava', n: parseInt(m[1], 10) };
    if (/^\d+$/.test(String(s))) return { mode: 'fail', n: parseInt(s, 10) };
    throw new Error(`bad --fail-budget: ${s}（用 N 或 lava=N）`);
}

// MC-M1-TASK-06d P0：泳道按名选择。手册 §9 每条开发线只占一条泳道（A/B/C），
// 旧口径 buildLanes 写死 serverPort = 25566 + i，从 A 顺序占 → 只占一条线的开发线没法从 B/C 起跑，
// 而 preflight 又按「前 N 条」检查端口（--lanes 1 时查的是 A，而不是自己要用的 C）。
// 统一口径：**--lane A,B,C 按名字指定**；--lanes N 保留 = 从 A 开始的前 N 条（兼容）。
export const LANE_NAMES = ['A', 'B', 'C', 'D', 'E'];
export const LANE_BASE_PORT = 25566;
export const LANE_BASE_RCON = 25576;

/** 把 '--lane A,C' / '--lanes 2' 解析成 ['A','C'] / ['A','B']；都没给则 ['A'] */
export function parseLanes(argv = process.argv, { defaultLanes = 1 } = {}) {
    const i = argv.indexOf('--lane');
    if (i >= 0 && argv[i + 1]) {
        const names = String(argv[i + 1]).split(',').map((s) => s.trim().toUpperCase()).filter(Boolean);
        for (const n of names) {
            if (!LANE_NAMES.includes(n)) throw new Error(`--lane 里有未知泳道 "${n}"（可用 ${LANE_NAMES.slice(0, 3).join('/')}）`);
        }
        if (!names.length) throw new Error('--lane 后面要跟泳道名，例如 --lane A,C');
        return [...new Set(names)];
    }
    const j = argv.indexOf('--lanes');
    const n = j >= 0 && argv[j + 1] ? parseInt(argv[j + 1], 10) : defaultLanes;
    if (!Number.isFinite(n) || n < 1) throw new Error(`--lanes 需要 ≥1 的整数（收到 "${argv[j + 1]}"）`);
    return LANE_NAMES.slice(0, n);
}

export function buildLanes({ count, names, templateDir, jarPath, rconPass, logFn }) {
    // names 优先（06d）；count 保留给老调用方与 dryRun
    const laneNames = names && names.length ? names : LANE_NAMES.slice(0, Math.max(1, count ?? 1));
    const lanes = laneNames.map((name, i) => {
        const idx = LANE_NAMES.indexOf(name);
        return {
            idx,
            name,
            dir: idx === 0 ? templateDir : `${templateDir}_lane${name}`,
            serverPort: LANE_BASE_PORT + idx,
            rconPort: LANE_BASE_RCON + idx,
            username: idx === 0 ? 'TaskBot' : `TaskBot${name}`,
            rconPass,
            jarPath,
        };
    });
    for (const lane of lanes) {
        if (lane.idx === 0) continue; // 泳道 A = 模板目录原样（既有契约，不重写配置）
        provisionLaneDir(lane, templateDir, logFn);
    }
    return lanes;
}

function provisionLaneDir(lane, templateDir, logFn) {
    fs.mkdirSync(lane.dir, { recursive: true });
    const jarName = path.basename(lane.jarPath);
    const dstJar = path.join(lane.dir, jarName);
    if (!fs.existsSync(dstJar)) {
        logFn(`lane ${lane.name}: copying ${jarName} → ${lane.dir}`);
        fs.copyFileSync(lane.jarPath, dstJar);
    }
    const eulaSrc = path.join(templateDir, 'eula.txt');
    if (fs.existsSync(eulaSrc)) fs.copyFileSync(eulaSrc, path.join(lane.dir, 'eula.txt'));
    // server.properties：模板内容 + 本泳道端口（level-seed 由 freshWorld 逐局注入）
    const tpl = fs.readFileSync(path.join(templateDir, 'server.properties'), 'utf8');
    const lines = tpl.split(/\r?\n/).map((l) => {
        if (l.startsWith('server-port=')) return `server-port=${lane.serverPort}`;
        if (l.startsWith('rcon.port=')) return `rcon.port=${lane.rconPort}`;
        return l;
    }).filter((l) => !l.startsWith('level-seed='));
    fs.writeFileSync(path.join(lane.dir, 'server.properties'), lines.join('\n') + '\n');
    lane.jarPath = dstJar;
}

function worldDirsOf(serverDir) {
    return ['spike_world', 'spike_world_nether', 'spike_world_the_end'].map((d) => path.join(serverDir, d));
}

export function freshWorld(lane, seed) {
    for (const d of worldDirsOf(lane.dir)) fs.rmSync(d, { recursive: true, force: true });
    const spPath = path.join(lane.dir, 'server.properties');
    const lines = fs.readFileSync(spPath, 'utf8').split(/\r?\n/).filter((l) => !l.startsWith('level-seed='));
    lines.push(`level-seed=${seed}`);
    fs.writeFileSync(spPath, lines.join('\n') + '\n');
}

// ---- 起服判据 / 端口闸（2026-10-03，F 线 S2-04 授权修；B 线 r16 撞过同一现象）----
//
// 旧实现三个病，按严重度排：
//  ① **成功判据只有一条**：日志里出现 `Done (`。1.16.1 只要进程活着但这一行没打出来（重定向缓冲、
//     改过启动文案）就一直空转到 300s 超时，**活着的服被报成 boot timeout / crashed**。
//  ② **`exit=0` 被当成"JVM 启动即崩"**，归因写的是 NIO loopback 抖动。源码钉死这是误判：
//     `DedicatedServer.initServer()` 端口被占时**不抛异常**，打三行 WARN 后 `return false`
//     （src-1161 `net/minecraft/server/dedicated/DedicatedServer.java:147-154`）⇒ 服务端干净
//     停机、**退出码 0**。而未捕获异常才会走 `Bootstrap.fatal → Runtime.halt(1)`（exit=1）。
//     ⇒ `exit=0` 的真实含义是"启动期失败被吞掉"，最常见就是**端口被上一个服占着**。
//  ③ **失败后不收尸**：`bootServer` 抛错前只 `unregisterChild`，**没停那个可能还活着的子进程**；
//     `bootServerWithRetry` 直接再起一个 ⇒ 端口互撞，每次重试都加深一层。
//
// 修法：成功判据改为「`Done (` **或** 端口在监听且进程存活」；任何失败路径都先收干净子进程
// 并确认端口释放；每次起服（含第一次）前过端口闸 —— 端口上有人就不许起，别人的进程只报告不处置
// （手册 §9.2）。判据拆成纯函数 `classifyBoot`，可离线测。

/** 这个 TCP 端口有没有在监听。走真实握手，不用 netstat 文本解析（§9.1 授权的 runner_core 改动范围内）。 */
export function tcpListening(port, host = '127.0.0.1', timeoutMs = 1000) {
    return new Promise((resolve) => {
        const sock = new net.Socket();
        let done = false;
        const finish = (v) => { if (done) return; done = true; try { sock.destroy(); } catch { /* 已销毁 */ } resolve(v); };
        sock.setTimeout(timeoutMs);
        sock.once('connect', () => finish(true));
        sock.once('timeout', () => finish(false));
        sock.once('error', () => finish(false));
        try { sock.connect(port, host); } catch { finish(false); }
    });
}

/** 轮询到端口不再监听为止（收尸用）。 */
export async function waitPortFree(port, { timeoutMs = 20000, intervalMs = 300 } = {}) {
    const t0 = Date.now();
    for (;;) {
        if (!(await tcpListening(port))) return { free: true, waitedMs: Date.now() - t0 };
        if (Date.now() - t0 >= timeoutMs) return { free: false, waitedMs: Date.now() - t0 };
        await sleep(intervalMs);
    }
}

/** 轮询到端口开始监听（成功判据②的独立探针）。进程先死就立刻放弃，不再空等。 */
export async function waitPortListening(port, { timeoutMs = 3000, intervalMs = 250, alive = () => true } = {}) {
    const t0 = Date.now();
    for (;;) {
        if (await tcpListening(port)) return { listening: true, alive: true, waitedMs: Date.now() - t0 };
        if (!alive()) return { listening: false, alive: false, waitedMs: Date.now() - t0 };
        if (Date.now() - t0 >= timeoutMs) return { listening: false, alive: true, waitedMs: Date.now() - t0 };
        await sleep(intervalMs);
    }
}

/**
 * 起服成功/失败判据（纯函数，离线可测；S2-04 的 `server crashed on boot (exit=0)` 与
 * B 线 r16 同名现象都出在这里）。判据顺序有讲究：
 *  - 先看死活：进程已经退了，打过 `Done (` 也不算成功（端口不会有人听）。
 *  - 再看日志 `Done (`（原判据，保留）。
 *  - 再看「端口在监听 + 进程存活」（新判据，1.16.1 不打 Done( 时靠它）。
 *  - 都没命中 = 还在起（pending），交给调用方继续等。
 */
export function classifyBoot({ logText = '', listening = false, alive = false, exitCode = null } = {}) {
    // ★ 端口占用是**终止性**失败，优先于一切其它判据：1.16.1 绑定失败后 `return false`，
    //   不可能再走到 `Done (`（物理上不会同时出现），所以先判它不会误伤正常路径。
    if (/FAILED TO BIND TO PORT/.test(logText)) {
        return { ok: false, via: 'dead', reason: 'bind_failed', exitCode };
    }
    if (!alive) return { ok: false, via: 'dead', reason: 'exited', exitCode };
    if (logText.includes('Done (')) return { ok: true, via: 'log' };
    if (listening) return { ok: true, via: 'port' };
    return { ok: false, via: 'pending' };
}

/** 失败路径的收尸：把可能还活着的子进程停掉、注销、关 fd，并确认端口已释放。 */
export async function reapBootChild(lane, child, reg, out, { port, portFreeMs = 20000, logFn = () => {} } = {}) {
    const wasAlive = child.exitCode === null;
    if (wasAlive) {
        logFn(`lane ${lane?.name}: 收尸上一个服（pid ${child.pid}，仍存活）→ stdin stop → SIGKILL`);
        try { await stopServer(lane, { child, reg }); } catch { /* 收不干净也要继续确认端口 */ }
    } else {
        unregisterChild(reg);
    }
    try { fs.closeSync(out); } catch { /* 已关闭 */ }
    const freed = port ? await waitPortFree(port, { timeoutMs: portFreeMs }) : { free: true, waitedMs: 0 };
    return { wasAlive, stopped: child.exitCode !== null, portFree: freed.free, portWaitMs: freed.waitedMs };
}

/**
 * 起服前的端口闸（每次 attempt 都过，含第一次）。
 * 端口上有进程时：属于**本 runner** 的（pid 台账 `mine`）收掉；**别人的**只报告并抛错，
 * 不自动结束（手册 §9.2：表里没有的 pid = 别人的进程 = 只报告、不处置）。重试对"别人的服"没意义，
 * 所以 LANE_PORT_FOREIGN 直接上抛、不进重试循环。
 */
export async function ensureLanePortFree(lane, { logFn = () => {}, listenersFn = netstatListeners, registryFn = pidRegistry, portFreeMs = 20000 } = {}) {
    const port = lane?.serverPort;
    if (!port) return { ok: true, port: null, stopped: [], foreign: [] };
    const pids = (listenersFn()[String(port)] ?? []).filter((n) => Number.isFinite(n));
    if (!pids.length) return { ok: true, port, stopped: [], foreign: [] };
    const reg = registryFn();
    const mine = pids.filter((p) => reg.get(p)?.mine === true);
    const others = pids.filter((p) => !mine.includes(p));
    const orphan = others.filter((p) => reg.has(p));
    if (others.length) {
        const e = new Error(`lane ${lane.name}: 端口 ${port} 被非本 runner 的进程占用（pid ${others.join(', ')}`
            + `${orphan.length ? `，其中 ${orphan.join(', ')} 登记在册但登记它的 runner 已死（孤儿）` : ''}）`
            + '——按手册 §9.2 不自动结束；请先 preflight --kill-stale 或 cleanup 处理');
        e.code = 'LANE_PORT_FOREIGN';
        e.foreignPids = others;
        e.orphanPids = orphan;
        throw e;
    }
    for (const p of mine) logFn(`lane ${lane.name}: 端口 ${port} 上有本 runner 的遗留服（pid ${p}），先结束再起`);
    for (const p of mine) killTree(p);
    const r = await waitPortFree(port, { timeoutMs: portFreeMs });
    if (!r.free) {
        const e = new Error(`lane ${lane.name}: 端口 ${port} 上本 runner 的遗留服（pid ${mine.join(', ')}）收不掉，仍在监听`);
        e.code = 'LANE_PORT_STUCK';
        throw e;
    }
    return { ok: true, port, stopped: mine, foreign: [] };
}

/** 起服轮询环（注入式纯逻辑，离线可测；bootServer 只负责提供真实探针）。
 *
 *  判据优先级与**兜底语义**（2026-10-03 设计会话授权 + 一处我自查出的坑）：
 *  ① `Done (` → 立刻成功（原判据，一个字没改）。
 *  ② 端口在监听 + 进程存活 → 成功，**但只在 `portReadyAfterMs` 之后**。
 *     ⚠ 不能一绑定就报成功：1.16.1 的 `initServer()` 是**先绑定端口**（DedicatedServer.java:145-148）
 *     **再加载世界**，端口在监听时世界往往还没生成完。一绑定就放行 ⇒ 所有泳道的 bot 提前进服、
 *     卡在登录队列里。⇒ 端口判据定位成"**Done( 永远不来的逃生门**"，不是加速判据。
 *  ③ 进程退出 → 立刻判负，并从日志区分 `bind_failed`（端口被占，1.16.1 `return false` ⇒ exit=0）
 *     与 `exited`；日志里已出现 `FAILED TO BIND TO PORT` 时不等进程退，直接判负走端口闸。
 *  ④ 300s 都没命中 → 超时（不重试，重试只会再烧 300s）。
 */
export async function pollBoot({
    readLog = () => '',
    isAlive = () => false,
    isListening = async () => false,
    timeoutMs = 300000,
    portReadyAfterMs = 90000,
    intervalMs = 2000,
    sleepFn = sleep,
    nowFn = Date.now,
} = {}) {
    const t0 = nowFn();
    let via = 'pending';
    for (;;) {
        await sleepFn(intervalMs);
        const logText = readLog() || '';
        const alive = !!isAlive();
        const bindFailed = /FAILED TO BIND TO PORT/.test(logText);
        if (bindFailed) return { ok: false, via: 'dead', reason: 'bind_failed', waitedMs: nowFn() - t0, timedOut: false };
        if (!alive) {
            const v = classifyBoot({ logText, listening: false, alive: false, exitCode: null });
            return { ok: false, via: v.via, reason: v.reason, waitedMs: nowFn() - t0, timedOut: false };
        }
        const elapsed = nowFn() - t0;
        const v = classifyBoot({ logText, listening: false, alive: true });   // 先只认 Done(
        if (v.ok) return { ok: true, via: 'log', waitedMs: elapsed, timedOut: false };
        if (elapsed >= portReadyAfterMs && await isListening()) {
            return { ok: true, via: 'port', waitedMs: elapsed, timedOut: false };
        }
        if (elapsed >= timeoutMs) return { ok: false, via, reason: 'timeout', waitedMs: elapsed, timedOut: true };
        via = 'pending';
    }
}

export async function bootServer(lane, runDir, xmx, logFn, opts = {}) {
    const timeoutMs = Number(opts.timeoutMs) > 0 ? Number(opts.timeoutMs) : 300000;
    const portReadyAfterMs = Number(opts.portReadyAfterMs) > 0 ? Number(opts.portReadyAfterMs) : 90000;
    const attempt = Number(opts.attempt) > 0 ? Number(opts.attempt) : 0;
    const serverLog = path.join(runDir, 'server.log');
    const out = fs.openSync(serverLog, 'w');
    const child = spawn(lane.java, ['-Xms512M', `-Xmx${xmx}`, '-jar', lane.jarPath, '--nogui'],
        { cwd: lane.dir, stdio: ['pipe', out, out] });
    const reg = registerChild(child, lane, runDir);
    const readLog = () => { try { return fs.readFileSync(serverLog, 'utf8'); } catch { return ''; } };
    const r = await pollBoot({
        readLog,
        isAlive: () => child.exitCode === null,
        isListening: async () => (await tcpListening(lane.serverPort)),
        timeoutMs, portReadyAfterMs,
    });
    if (r.ok) {
        if (r.via === 'port') logFn(`lane ${lane.name}: Done( 未出现，但端口 ${lane.serverPort} 在监听且进程存活（${Math.round(r.waitedMs / 1000)}s，兜底判据），按成功收`);
        else logFn(`lane ${lane.name}: Done( 出现（${Math.round(r.waitedMs / 1000)}s）`);
        return { child, reg, bootMs: r.waitedMs, via: r.via, serverLog, attempt };
    }
    // 失败：**先把可能还活着的服收干净**，否则下一次重试必然撞端口（2026-10-03 修）。
    const tail = readLog().slice(-4000);
    const bindFailed = r.reason === 'bind_failed' || /FAILED TO BIND TO PORT/.test(tail);
    const reaped = await reapBootChild(lane, child, reg, out, { port: lane.serverPort, logFn });
    // 失败 attempt 的 server.log 会被下一次 attempt 用 'w' 打开抹掉 → 留副本（F 线 S2-04 的现场就是这么丢的）
    let snapshot = null;
    if (attempt) {
        try {
            snapshot = path.join(runDir, `server.boot-fail.${attempt}.${new Date().toISOString().slice(11, 19).replace(/:/g, '')}.log`);
            fs.copyFileSync(serverLog, snapshot);
        } catch { /* 留副本失败不影响主流程 */ }
    }
    // ★ 口径（`HANDOVER.md` 跨线通告 2026-10-03 11:35，MC-M1-TASK-07 §4.16-③）：
    //   **只有"真正的崩"才允许重试**。`FAILED TO BIND TO PORT` 不算崩（1.16.1 `return false`
    //   ⇒ 干净退出、exit=0），重试只会再撞同一个端口；手册 §2 那条 loopback 抖动走的是
    //   未捕获异常 ⇒ `Bootstrap.fatal → Runtime.halt(1)` ⇒ exit=1，仍然照常重试。
    const crashed = child.exitCode !== null && child.exitCode !== 0;
    const e = new Error(bindFailed
        ? `server port ${lane.serverPort} was already in use (FAILED TO BIND TO PORT; 1.16.1 return false → 退出码 ${child.exitCode})`
        : crashed ? `server exited on boot (exit=${child.exitCode})` : 'server boot timeout');
    e.crashed = crashed;
    e.via = r.via;
    e.reason = r.reason;
    e.bindFailed = bindFailed;
    e.attempt = attempt;
    e.snapshot = snapshot;
    e.reaped = reaped;
    throw e;
}

/** 起服 + 启动重试（手册 §2：Windows 偶发 Unable to establish loopback connection → 重试 3 次）。
 *  2026-10-01：micro-place 的 MP_LEG laneC 直接调 bootServer、没走重试，整条泳道 BOOTFAIL 掉。
 *  → 所有起服入口都必须走这个，别再各写一遍 retry 循环。
 *  2026-10-03（F 线 S2-04 授权）：重试前先过端口闸，确认上一个服已停；别人的服占用端口直接上抛不重试。 */
export async function bootServerWithRetry(lane, runDir, xmx, logFn, tries = 3, opts = {}) {
    const cooldownMs = Number(opts.cooldownMs) >= 0 ? Number(opts.cooldownMs) : 15000;
    for (let a = 1; a <= tries; a++) {
        await ensureLanePortFree(lane, { logFn });   // 含第一次：端口被占就别浪费 attempt
        try { return await bootServer(lane, runDir, xmx, logFn, { ...opts, attempt: a }); }
        catch (e) {
            // 端口被占 = 别人的服还活着，重试没有意义（而且会把上面那条准确的报错冲掉）
            if (a >= tries || e.bindFailed || e.code === 'LANE_PORT_FOREIGN' || e.code === 'LANE_PORT_STUCK') throw e;
            if (!e.crashed) throw e;   // 超时 / 干净退出（非崩溃）不重试：重试只会再烧一轮
            logFn(`lane ${lane.name}: 起服未成功（${String(e).slice(0, 110)}；判据 ${e.via}/${e.reason}，端口已释放 ${e.reaped?.portFree ? '是' : '否'}），冷却 ${Math.round(cooldownMs / 1000)}s 后重试 ${a + 1}/${tries}`);
            await sleep(cooldownMs);
        }
    }
    throw new Error('unreachable');
}

export async function stopServer(lane, server) {
    // TASK-06c P0：停服改走 stdin 控制台（手册 §2「一律用服务器 stdin 发命令」；RCON 通道删除）。
    // 实测 1.16.1 --nogui + 管道 stdin：`stop` → 1.5s 干净退出（experiments/task06c/stdin_probe.mjs）
    const child = server.child;
    try { if (child.stdin && !child.stdin.destroyed) child.stdin.write('stop\n'); } catch { /* 已断 */ }
    const t0 = Date.now();
    while (child.exitCode === null && Date.now() - t0 < 15000) await sleep(500);
    if (child.exitCode === null) { try { child.kill('SIGKILL'); } catch { /* 忽略 */ } killTree(child.pid); }
    unregisterChild(server.reg);
    await sleep(1500); // 端口/文件句柄释放窗口（TASK-05 停服时序加固保留）
}

// ---- 无进展探针（runner 侧）----
function tailLine(filePath) {
    try {
        const st = fs.statSync(filePath);
        if (!st.size) return null;
        const fd = fs.openSync(filePath, 'r');
        const len = Math.min(st.size, 8192);
        const buf = Buffer.alloc(len);
        fs.readSync(fd, buf, 0, len, st.size - len);
        fs.closeSync(fd);
        const text = buf.toString('utf8');
        const lines = text.split('\n').filter((l) => l.trim());
        return JSON.parse(lines.at(-1));
    } catch { return null; }
}

function probeSig(probe) {
    if (!probe) return null;
    return JSON.stringify({ i: probe.inv ?? null, p: probe.pos ?? null, d: !!probe.digging, f: probe.furnace ?? null, t: probe.tree ?? '' });
}

// bot 进程监控（live 与 dryRun 共用）：退出 / 无进展硬中止（probe 签名冻结 > noProgressMs）
// / 硬超时兜底。返回进程退出码（-8 = 判负中止，-9 = 硬超时）。
function awaitBotExit(botProc, runDir, cfg, row) {
    return new Promise((resolve) => {
        let probePoll = 0, lastSig = null, lastChangeAt = Date.now();
        const t0b = Date.now();
        const poll = setInterval(() => {
            if (botProc.exitCode !== null) { clearInterval(poll); resolve(botProc.exitCode); return; }
            if (Date.now() - t0b > cfg.timeoutMs + 90000) { clearInterval(poll); killTree(botProc.pid); resolve(-9); return; }
            probePoll++;
            if (cfg.noProgressMs > 0 && probePoll % 5 === 0) {
                const sig = probeSig(tailLine(path.join(runDir, 'probe.jsonl')));
                if (sig) {
                    if (sig !== lastSig) { lastSig = sig; lastChangeAt = Date.now(); }
                    else if (Date.now() - lastChangeAt > cfg.noProgressMs) {
                        row.abort = { reason: 'no_progress', frozenMs: Date.now() - lastChangeAt };
                        clearInterval(poll);
                        killTree(botProc.pid);
                        resolve(-8);
                    }
                }
            }
        }, 1000);
        botProc.on('exit', (code) => { clearInterval(poll); resolve(code); });
    });
}

function lavaDeathsIn(runDir) {
    try {
        const txt = fs.readFileSync(path.join(runDir, 'server.log'), 'utf8');
        return (txt.match(/tried to swim in lava/g) ?? []).length;
    } catch { return 0; }
}

// ---- 开发局 kit 注入（验收协议 v3 §0.1；只有 run_bench --kit 传了才走这里）----
// 通道 = 服务器 stdin 控制台（手册 §2：RCON 会毒化服务进程）。给完落 kit.json + kit_done.json，
// exec_bot 读到 marker 才起任务，避免「计划器读背包时物品还没到」的竞态。
export async function injectKit(server, lane, runDir, kit, logFn) {
    const items = String(kit).split(',').map((s) => s.trim()).filter(Boolean).map((raw) => {
        // ⚠ 必须留 raw：`exec:` 后面跟的是**服务器命令**，里面自带冒号
        //   （`fill … minecraft:air`）。按 ':' 切成 [name,count] 会把命令从最后一个冒号处截断
        //   ——实测 kit.json 里存成了 `… ~1 ~3 ~12 minecraft`，隧道根本没挖出来，面板白跑。
        const [name, count] = raw.split(':');
        return { raw, name: name.trim(), count: String(count ?? '1').trim() };
    });
    const logPath = path.join(runDir, 'server.log');
    const t0 = Date.now();
    let joined = false;
    while (Date.now() - t0 < 90000) {
        try { if (/joined the game/.test(fs.readFileSync(logPath, 'utf8'))) { joined = true; break; } } catch { /* 还没落盘 */ }
        if (server.child.exitCode !== null) break;
        await sleep(700);
    }
    if (!joined) { logFn(`kit: bot 90s 未进服（lane ${lane.name}），跳过注入`); return { ok: false, joined: false }; }
    // MC-M1-TASK-06d P2-1：--kit 里可以写 `exec:<服务器命令>`，在 give 之前跑。
    // 验收协议 v3 §0.2：「kit 起步必须复现真实前置状态，不只是背包，还包括位置和深度」——
    // 地下找原木那一项的 kit 就要先把人塞进 y41 的隧道里。
    //
    // ⚠ 两条实测踩出来的坑（都不是"命令写错"这么简单）：
    //  ① **控制台没有 @s**。命令走服务器 stdin，命令源没有实体，`execute at @s` 直接解析失败，
    //    **而且一个字都不打**（既无成功也无报错）——面板会安静地退化成"人在地表"的普通工况，
    //    跑完还是绿的，看不出任何异常。一律替换成 `at <用户名>`。
    //  ② **不执行 = 零输出**。手册 §5 早记过「/fill 失败不会打出成功日志」；这里更糟：命令压根没跑
    //    也同样零输出。所以每条 exec 之后回读 server.log 增量并原样打出来，不执行就不放过。
    const cmds = [];
    for (const it of items) {
        if (it.name === 'exec') cmds.push(it.raw.slice('exec'.length).replace(/^:/, '').trim().replace(/@s\b/g, lane.username));
    }
    const logSize = () => { try { return fs.statSync(logPath).size; } catch { return 0; } };
    for (const c of cmds) {
        const at0 = logSize();
        try { server.child.stdin.write(`${c}\n`); } catch (e) { logFn(`kit: exec 发送失败 ${c}: ${e}`); }
        await sleep(300);
        let delta = '';
        try { delta = fs.readFileSync(logPath, 'utf8').slice(at0).trim(); } catch { /* 还没落盘 */ }
        logFn(delta
            ? `kit exec [lane ${lane.name}] ${c} → ${delta.split(/\r?\n/).slice(0, 2).join(' | ').slice(0, 150)}`
            : `kit exec [lane ${lane.name}] ${c} → ⚠ 服务端零输出（没执行？控制台无 @s / 语法错）`);
    }
    if (cmds.length) { logFn(`kit [lane ${lane.name}]: 先跑 ${cmds.length} 条 exec（复现真实位置/深度）`); await sleep(1200); }
    for (const it of items) {
        if (it.name === 'exec') continue;
        try { server.child.stdin.write(`give ${lane.username} minecraft:${it.name} ${it.count}\n`); } catch (e) { logFn(`kit: give 发送失败 ${it.name}: ${e}`); }
        await sleep(120);
    }
    await sleep(700);
    const rec = { kit: items.map((i) => `${i.name}:${i.count}`).join(','), username: lane.username, at: new Date().toISOString(), joined: true };
    fs.writeFileSync(path.join(runDir, 'kit.json'), JSON.stringify(rec, null, 2));
    fs.writeFileSync(path.join(runDir, 'kit_done.json'), JSON.stringify(rec, null, 2));
    logFn(`kit [lane ${lane.name}]: 已注入 ${rec.kit}`);
    return { ok: true, ...rec };
}

// ---- 矩阵编排 ----
// cfg = {
//   runsDir, summaryPath, execBotPath, stageLabel,
//   trials: [n,...], seedFor: (n) => seed, extraBotArgs: (lane) => [...],
//   lanes, mcVersion, timeoutMs, noProgressMs, probeMs,
//   failBudget: {mode:'fail'|'lava', n} | null,
//   minFreeBytes, serverXmx, java,
// }
export async function runMatrix(cfg) {
    process.env.JAVA_TOOL_OPTIONS ||= '-Djava.net.preferIPv4Stack=true';
    // MC-M1-TASK-06d P0：泳道按名。cfg.laneNames（['A','C']）优先；否则 cfg.lanes = 从 A 起前 N 条（兼容）。
    const laneNames = cfg.laneNames?.length ? cfg.laneNames : LANE_NAMES.slice(0, Math.max(1, cfg.lanes ?? 1));
    const lanes = laneNames.length;
    // ROUND3 P0-2 线锁：每条开发线同一时间只能有一个会话。**已有活锁就停下，不接管**（抛 LINE_LOCKED）。
    const lockRef = await holdLocks(laneNames, {
        who: cfg.who ?? cfg.stageLabel ?? 'bench',
        label: `${cfg.stageLabel} ${path.basename(cfg.runsDir ?? '')}`.trim(), logFn: log,
    });
    installRunnerHooks(() => cfg.stageLabel ?? 'bench run', () => { try { lockRef.releaseAll?.(); } catch { /* 忽略 */ } });
    let lanesArr;
    if (cfg.dryRun) {
        // 离线模拟（BENCH-v2 验收③）：不派生泳道目录、不碰端口，只验编排层
        lanesArr = laneNames.map((n, i) => {
            const idx = LANE_NAMES.indexOf(n);
            return { idx, name: n, dir: '.', serverPort: 0, rconPort: 0, username: '-', rconPass: '-', jarPath: '.', java: 'node' };
        });
    } else {
        lanesArr = buildLanes({
            names: laneNames,
            templateDir: cfg.templateDir,
            jarPath: cfg.jarPath,
            rconPass: cfg.rconPass,
            logFn: log,
        });
        for (const lane of lanesArr) lane.java = cfg.java;
        // P0 接线：run 开始自动 preflight（**按名检查这几条泳道**；只清「登记在册且 runner 已死」的孤儿，
        // 别的开发线在用的端口/进程只报告不碰）
        const pf = await preflight({ killStale: !cfg.keepStale, laneNames, who: cfg.who ?? null, logFn: log });
        for (const l of pf.notes) log(`preflight: ${l}`);
        for (const w of pf.warns) log(`preflight ! ${w}`);
        if (!pf.ok) { for (const b of pf.blockers) log(`preflight X ${b}`); await lockRef.releaseAll?.(); throw new Error(`PREFLIGHT BLOCKED（${pf.blockers.length} 项）`); }
    }

    const queue = [...cfg.trials];
    const summaryPath = cfg.summaryPath;
    fs.mkdirSync(cfg.runsDir, { recursive: true });
    const metaPath = path.join(cfg.runsDir, 'run_meta.json');
    fs.writeFileSync(metaPath, JSON.stringify({
        stamp: path.basename(cfg.runsDir), stage: cfg.stageLabel, lanes,
        ports: lanesArr.map((l) => [l.serverPort, l.rconPort]),
        startedAt: new Date().toISOString(),
        params: {
            timeoutMs: cfg.timeoutMs, noProgressMs: cfg.noProgressMs,
            failBudget: cfg.failBudget, minFreeMb: Math.round(cfg.minFreeBytes / 1048576),
            serverXmx: cfg.serverXmx, trials: cfg.trials.length,
            kit: cfg.kit ?? null,
        },
    }, null, 2));

    log(`${cfg.stageLabel}: ${cfg.trials.length} trials, lanes=${lanes}（${lanesArr.map((l) => `${l.name}:${l.serverPort}/${l.rconPort}`).join(' ')}）, no-progress-abort=${cfg.noProgressMs / 1000}s, fail-budget=${cfg.failBudget ? `${cfg.failBudget.mode}:${cfg.failBudget.n}` : 'off'}`);

    let failures = 0, lavaDeaths = 0, earlyStop = null;
    const t0 = Date.now();

    const shouldStop = () => cfg.failBudget && (
        (cfg.failBudget.mode === 'fail' && failures >= cfg.failBudget.n)
        || (cfg.failBudget.mode === 'lava' && lavaDeaths >= cfg.failBudget.n));

    const worker = async (lane) => {
        while (queue.length && !earlyStop) {
            // ROUND3 P0-3 拍摄预约：**在局与局之间**检查。预约生效时不结束 runner，只停在队头等它到期，
            // 到期自动继续（正在跑的那一局本来就已经跑完了）。预约者本人不受限。
            if (queue.length) {
                const rw = await waitReserveClear({ who: cfg.who ?? null, logFn: log });
                if (rw.gaveUp) { earlyStop = { at: null, failures, lavaDeaths, cancelled: queue.splice(0).map((x) => x), reason: 'RESERVE_TIMEOUT' }; break; }
            }
            const n = queue.shift();
            const row = await runTrial(n, lane);
            fs.appendFileSync(summaryPath, JSON.stringify(row) + '\n');
            if (row.outcome !== 'SUCCESS' && row.outcome !== 'EARLY_STOP') failures++;
            lavaDeaths += row.lavaDeaths ?? 0;
            log(`trial ${n} [lane ${lane.name}]: ${row.outcome}${row.result ? ` dur=${((row.result.durationMs ?? 0) / 1000).toFixed(1)}s` : ''}`);
            if (!earlyStop && shouldStop()) {
                earlyStop = { at: n, failures, lavaDeaths, cancelled: queue.splice(0).map((x) => x) };
                log(`EARLY_STOP: fail budget ${cfg.failBudget.mode}=${cfg.failBudget.n} reached at trial ${n}; cancelling ${earlyStop.cancelled.length} queued trials (in-flight finish)`);
            }
        }
    };

    async function runTrial(n, lane) {
        const seed = cfg.seedFor(n);
        const runDir = path.join(cfg.runsDir, `trial_${String(n).padStart(2, '0')}`);
        fs.mkdirSync(runDir, { recursive: true });
        const row = { trial: n, seed, lane: lane.name, startedAt: new Date().toISOString() };
        for (let attempt = 1; attempt <= 2; attempt++) {
            row.attempt = attempt;
            const res = await runTrialOnce(n, seed, runDir, lane, row);
            if (res !== 'RETRY') return row;
            log(`trial ${n} [lane ${lane.name}]: attempt ${attempt} infra-failed, retrying after cooldown`);
            await sleep(15000);
        }
        return row;
    }

    async function runTrialOnce(n, seed, runDir, lane, row) {
        // dryRun（测试专用）：跳过起服/停服，只验编排层（队列/预算/EARLY_STOP 台账）与
        // 无进展监控（noProgressMs>0 时走与 live 完全相同的 awaitBotExit）。
        // FAKE_BENCH_MODE=freeze：假 bot 落一行静态 probe 后挂起 → 应在 ~noProgressMs 被判负中止。
        if (cfg.dryRun) {
            const freeze = process.env.FAKE_BENCH_MODE === 'freeze';
            const botProc = spawn(process.execPath, [cfg.execBotPath, '--trial', String(n), '--seed', seed, '--out', runDir], { stdio: 'ignore' });
            const exitCode = await awaitBotExit(botProc, runDir, cfg, row);
            row.botExit = exitCode;
            if (row.abort?.reason === 'no_progress') row.outcome = 'FAIL(NO_PROGRESS_ABORT)';
            else if (exitCode === -8) row.outcome = 'NO_PROGRESS_ABORT';
            else {
                try {
                    const result = JSON.parse(fs.readFileSync(path.join(runDir, 'result.json'), 'utf8'));
                    row.result = result;
                    row.outcome = result.status === 'SUCCESS' ? 'SUCCESS' : `FAIL(${result.failReason ?? '?'})`;
                } catch { row.outcome = 'NO_RESULT'; }
            }
            return freeze ? (row.abort ? 'DONE' : 'DONE') : 'DONE';
        }
        await waitFreeMem(cfg.minFreeBytes, log);
        freshWorld(lane, seed);
        log(`trial ${n} [lane ${lane.name}]: fresh world seed=${seed}, booting server (xmx=${cfg.serverXmx}, free=${(os.freemem() / 1048576).toFixed(0)}MB)...`);
        let server;
        for (let bootAttempt = 1; bootAttempt <= 3; bootAttempt++) {
            try { server = await bootServerWithRetry(lane, runDir, cfg.serverXmx, log, 1); break; }
            catch (e) {
                if (e.crashed && bootAttempt < 3) {
                    log(`trial ${n} [lane ${lane.name}]: boot crash (${String(e).slice(0, 80)}), cooldown 15s, retry ${bootAttempt + 1}/3`);
                    await sleep(15000);
                    continue;
                }
                row.outcome = 'SERVER_FAIL'; row.error = String(e);
                return 'DONE';
            }
        }
        row.bootMs = server.bootMs;
        log(`trial ${n} [lane ${lane.name}]: server up in ${(server.bootMs / 1000).toFixed(0)}s, launching exec_bot`);

        const botArgs = [
            cfg.execBotPath,
            '--trial', String(n), '--seed', seed, '--out', runDir,
            '--port', String(lane.serverPort),
            '--username', lane.username, '--timeout-ms', String(cfg.timeoutMs),
            '--mc-version', cfg.mcVersion, '--probe-ms', String(cfg.probeMs),
            ...cfg.extraBotArgs(lane),
            ...(cfg.kit ? ['--kit-desc', String(cfg.kit)] : []),
        ];
        const botOut = lanes === 1 ? 'inherit' : fs.openSync(path.join(runDir, 'bot_console.log'), 'a');
        const botProc = spawn(process.execPath, botArgs, { stdio: lanes === 1 ? 'inherit' : ['ignore', botOut, botOut] });
        // 登记进 pid 台账（ROUND3 P0-1）：runner 崩了以后，这个 bot 才是可被回收的对象；
        // 不登记的 node 进程在别的线眼里就是「无归属」，谁都不敢碰，也就永远清不掉。
        const botReg = registerProc(botProc, lane, runDir);
        // 验收协议 v3 §0.1：开发局允许 kit 从中间状态起步（--kit 才走这段；正式矩阵不传 = 零 kit，
        // 这条 give 通道根本不执行）。命令一律走服务器 stdin 控制台（手册 §2），并落 kit.json 留痕。
        if (cfg.kit) await injectKit(server, lane, runDir, cfg.kit, log);

        // 监控：退出 / 无进展硬中止 / 硬超时兜底（与 dryRun 共用 awaitBotExit）
        const exitCode = await awaitBotExit(botProc, runDir, cfg, row);
        row.botExit = exitCode;
        log(`trial ${n} [lane ${lane.name}]: bot exit=${exitCode}, stopping server...`);
        await stopServer(lane, server);
        await sleep(2000);
        unregisterChild(botReg);
        if (botOut !== 'inherit') { try { fs.closeSync(botOut); } catch { /* 忽略 */ } }

        row.lavaDeaths = lavaDeathsIn(runDir);
        try {
            const result = JSON.parse(fs.readFileSync(path.join(runDir, 'result.json'), 'utf8'));
            row.result = result;
            row.outcome = result.status === 'SUCCESS' ? 'SUCCESS' : `FAIL(${result.failReason ?? '?'})`;
            // 基建级终态（连接失败/硬看门狗/被踢）不是 bot 的真实成绩 → 重跑（与
            // run_with_retry.sh「只重试基建失败、不重试 bot 级真实失败」同语义）
            if (result.status === 'CONNECT_FAIL' || result.status === 'RUNNER_TIMEOUT' || result.status === 'KICKED') {
                return 'RETRY';
            }
        } catch {
            if (row.abort?.reason === 'no_progress') {
                row.outcome = 'FAIL(NO_PROGRESS_ABORT)';
            } else if (exitCode === -8) {
                row.outcome = 'NO_PROGRESS_ABORT';
            } else {
                row.outcome = 'NO_RESULT';
                return 'RETRY'; // bot 进程异常死亡且无结果：基建级失败，重跑一次
            }
        }
        return 'DONE';
    }

    await Promise.all(lanesArr.slice(0, Math.min(lanes, cfg.trials.length)).map(worker));

    // 被提前收手取消的局：台账补 EARLY_STOP 行（trial 号齐全，验收口径可见）
    if (earlyStop) {
        for (const n of earlyStop.cancelled) {
            const row = { trial: n, seed: cfg.seedFor(n), lane: null, startedAt: new Date().toISOString(), outcome: 'EARLY_STOP', earlyStop: true };
            fs.appendFileSync(summaryPath, JSON.stringify(row) + '\n');
        }
    }

    const lines = fs.existsSync(summaryPath)
        ? fs.readFileSync(summaryPath, 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean)
        : [];
    const ok = lines.filter((r) => r.outcome === 'SUCCESS').length;
    log(`DONE: ${ok}/${lines.length} SUCCESS${earlyStop ? ` (EARLY_STOP at trial ${earlyStop.at})` : ''}, wall=${((Date.now() - t0) / 60000).toFixed(1)}min`);
    fs.writeFileSync(metaPath, JSON.stringify({
        ...JSON.parse(fs.readFileSync(metaPath, 'utf8')),
        finishedAt: new Date().toISOString(),
        wallMs: Date.now() - t0,
        success: ok, total: lines.length,
        earlyStop: earlyStop ? { at: earlyStop.at, cancelled: earlyStop.cancelled, failures, lavaDeaths } : null,
    }, null, 2));
    // P0 接线：run 结束自动 cleanup（stdin stop 残余 → 只强杀本 runner 登记过的 pid → 删 world → 复核端口/进程）
    if (!cfg.dryRun && !cfg.skipCleanup) {
        const cu = await cleanup({
            label: `${cfg.stageLabel} ${path.basename(cfg.runsDir)}`, rmWorlds: !cfg.keepWorld,
            dirs: lanesArr.map((l) => ({ dir: l.dir, port: l.serverPort })), laneNames,
        });
        fs.writeFileSync(path.join(cfg.runsDir, 'cleanup.txt'), cu.lines.join('\n') + '\n');
    }
    // P0-2：线锁用完即放（异常路径由 installRunnerHooks 的 onExit 兜底）
    await lockRef.releaseAll?.();
    return { ok, total: lines.length, earlyStop };
}
