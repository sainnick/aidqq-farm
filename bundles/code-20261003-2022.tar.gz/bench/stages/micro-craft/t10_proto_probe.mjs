// t10_proto_probe.mjs — TASK-10 离线协议取证（**不连服、不开泳道**）
//
// 目的：把 TASK-09 §4.5 那条"1.16.1 没有光标线上字段 ⇒ set_slot(-1) 不会来"的
// 否定结论，用**协议表 + 真实编解码往返**钉死或推翻。
//
// 设计会话的源码实读结论：1.16.1 服务端确实用
//   ClientboundContainerSetSlotPacket(-1, -1, carried)   （ServerPlayer.broadcastCarriedItem）
// 发光标。TASK-09 之所以等不到，只可能是**判据写错了**，不是包没来。
//
// 本脚本要回答三个问题（全部离线）：
//   Q1 1.16.1 `set_slot` 的 windowId / slot 字段到底是什么类型？-1 能编进去吗？
//   Q2 客户端**收到** windowId=-1 的光标包时，protodef 解出来的值是 -1 还是 255？
//      （若字段是 u8，-1 会被写成 255，判据必须同时认这两个值）
//   Q3 `window_click` 在 1.16.1 上的信封 + mode=1（QUICK_MOVE）能不能正常编出包？
//
// 判读纪律：这里给出的都是**协议层事实**，不是实服行为；实服行为由 furnace_truth.mjs 取证。

import { createRequire } from 'module';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');   // 协议库在任务层的 node_modules 里（bench 不装依赖）
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

const VERSIONS = ['1.16.1', '1.16.5', '1.17.1', '1.20.1'];
const out = [];
const say = (s) => { out.push(s); console.log(s); };

/** 在 protodef 的 types 树里递归找名为 set_slot 的 packet 定义，返回它的 type 描述 */
function findSetSlot(protocol) {
    const seen = new Set();
    const hit = { def: null, path: null };
    (function walk(node, path) {
        if (hit.def || !node || typeof node !== 'object' || seen.has(node)) return;
        seen.add(node);
        for (const key of Object.keys(node)) {
            const v = node[key];
            if (key === 'set_slot' && v && v.name === 'set_slot') { hit.def = v; hit.path = path + '.' + key; return; }
            if (v && typeof v === 'object') walk(v, path + '.' + key);
        }
    })(protocol.types, 'types');
    return hit;
}

say('===== Q1/Q2：set_slot 的字段类型与 -1 的往返 =====');
for (const v of VERSIONS) {
    const s = require('minecraft-protocol').createSerializer({ state: 'play', isServer: false, version: v });
    const hit = findSetSlot(s.proto);
    let line = `[${v}] `;
    if (!hit.def) { say(line + '找不到 set_slot 定义'); continue; }
    const innerName = hit.def.type?.[2]?.type?.[0]?.type?.[1]?.name;
    const inner = innerName ? s.proto.types[innerName] : null;
    const fields = inner ? Object.keys(inner.mappings ?? {}) : null;
    line += `容器=${innerName} 字段=${fields ? fields.join(',') : '??'}`;
    if (fields) {
        for (const f of ['windowId', 'slot']) {
            const t = inner.mappings[f];
            line += ` | ${f}:${(t.type ?? []).map((x) => x[1]?.name ?? x[0]?.name ?? JSON.stringify(x)).join('')}`;
        }
    }
    say(line);

    // 真实往返：编一个 windowId=-1, slot=-1 的光标包，再用 protodef 解回来
    for (const [wid, sl] of [[-1, -1], [255, -1], [3, -1], [3, 2]]) {
        let r;
        try {
            const buf = s.createPacketBuffer({ name: 'set_slot', params: { windowId: wid, slot: sl, item: { present: false } } });
            const parsed = s.proto.parsePacket(buf, 0, 'set_slot');
            r = `bytes=${buf.length} → 解出 windowId=${parsed.packet.windowId} slot=${parsed.packet.slot}`;
        } catch (e) { r = 'THROW ' + String(e.message ?? e).slice(0, 90); }
        say(`    in(win=${wid},slot=${sl}) ${r}`);
    }
}

say('');
say('===== Q3：1.16.1 window_click 信封 + mode=1 =====');
for (const v of ['1.16.1', '1.17.1']) {
    const s = require('minecraft-protocol').createSerializer({ state: 'play', isServer: false, version: v });
    const actionIdUsed = !!require('minecraft-protocol').createSerializer({ state: 'play', isServer: false, version: v });
    const flavor = v.startsWith('1.16') ? { action: 7, item: { present: false } } : { stateId: 1, changedSlots: [], cursorItem: { present: false } };
    for (const mode of [0, 1]) {
        let r;
        try {
            const params = { windowId: 3, slot: 2, mouseButton: 0, mode, ...flavor };
            const buf = s.createPacketBuffer({ name: 'window_click', params });
            r = `OK bytes=${buf.length}`;
        } catch (e) { r = 'THROW ' + String(e.message ?? e).slice(0, 90); }
        say(`[${v}] mode=${mode} ${r}`);
    }
}

say('');
say('===== 结论提示 =====');
say('判读：若 1.16.1 的 windowId 是 u8，则服务端发的 -1 在线上是 255、');
say('      客户端解出来是 255 ⇒ 光标判据必须写 `windowId === -1 || windowId === 255`，');
say('      且**不能**再要求 `windowId === 当前窗口 id`（服务端光标包的 windowId 不是窗口 id）。');
