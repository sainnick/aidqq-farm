// t10_sequence.mjs — TASK-10 收尾编排：一条泳道、一台服，按优先级把 ①②③④ 跑完
//
// 为什么要有这个：本单的实跑窗口被**拍摄预约**（CAM）压掉一大半，而
// `runTrialOnce`（runner_core.mjs:419）是**每局起一次服**——每一步之间的人工
// 决策空档在剩余预算里就是白扔的墙钟。这个脚本把顺序固定下来、每步落一份
// summary，并且**只在第①步达标时才继续**（熔炉没治好就去跑整局回归 = 烧机器时间）。
//
// 用法（泳道 A 专用）：
//   node t10_sequence.mjs --deadline 02:58 [--skip-truth] [--truth-n 4] [--m4b4-cap 20]
//
// 步骤：
//   ① furnace_truth.mjs   服务端真值：三臂 × N 轮（原始 set_slot / window_items /
//                         transaction / 服务端背包 / 关窗前后地面掉落物）
//      ↓ 闸门：quickMove 臂 ok 数 < ceil(N*0.75) ⇒ 停在这里，不往下跑
//   ② run_t09.mjs         熔炉取件微基准 30 轮（old vs self = 生产入口）
//   ③ basic-iron          主种子 obtain 1 iron_pickaxe × 5
//   ④ basic-bootstrap     M4B4 × min(cap, 剩余预算能装下的局数)
//
// 纪律：只跑泳道 A；不碰别线端口/目录；失败不吞（每步的 exit code 记进 summary.json）。

import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
const BENCH = path.join(ROOT, 'bench');
const NODE20 = path.join(ROOT, '.runtime/node-v20.20.2-win-x64/node.exe');
const RUNS = path.join(HERE, 'runs');
const LOG = path.join(RUNS, 't10_sequence.log');
const SUMMARY = path.join(RUNS, 't10_sequence.summary.json');

const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const DEADLINE = arg('deadline', '02:58');           // 本地墙钟 HH:MM（预算到点）
const TRUTH_N = parseInt(arg('truth-n', '4'), 10);
const M4B4_CAP = parseInt(arg('m4b4-cap', '20'), 10);
const SKIP_TRUTH = process.argv.includes('--skip-truth');
const STAMP = `T10_${new Date().toISOString().slice(5, 10).replace(/[-T]/g, '')}`;

// 1.16.1 环境（手册 §2：漏带这些会起 1.21.1 Paper，表现为 0.3s DEPENDENCY_CYCLE）
const ENV = {
    ...process.env,
    MC_BENCH_SERVER: process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161'),
    MC_BENCH_JAVA: process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe'),
    MC_BENCH_JAR: process.env.MC_BENCH_JAR || 'server-1.16.1.jar',
};

fs.mkdirSync(RUNS, { recursive: true });
const logLines = [];
const say = (s) => { const line = `[seq ${new Date().toISOString().slice(11, 19)}] ${s}`; console.log(line); logLines.push(line); fs.appendFileSync(LOG, line + '\n'); };

function deadlineMs() {
    const [h, m] = DEADLINE.split(':').map(Number);
    const d = new Date(); d.setHours(h, m, 0, 0);
    // ⚠ 第一版这里没处理"今天这个时刻已经过去了"：`--deadline 06:00` 在 23:49 跑
    //   会算成**今天** 06:00 ⇒ leftMin = -1069 ⇒ 三步全被当成"预算不足"跳过，
    //   而且 summary 里写的是 `skipped: budget`，**看起来像正常收工**。
    //   跨零点/凌晨跑批时必须顺延到次日。
    if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
    return d.getTime();
}
const leftMin = () => (deadlineMs() - Date.now()) / 60000;

/** 起一个子进程，stdout/stderr 全部落到独立文件，返回 exit code */
function run(name, args, timeoutMs) {
    return new Promise((resolve) => {
        const out = path.join(RUNS, `${name}.out.log`);
        const fd = fs.openSync(out, 'w');
        say(`▶ ${name} → ${path.relative(ROOT, out)}`);
        const p = spawn(NODE20, args, { cwd: BENCH, env: ENV, stdio: ['ignore', fd, fd] });
        const t = setTimeout(() => { say(`! ${name} 超时 ${Math.round(timeoutMs / 1000)}s，杀掉`); try { p.kill(); } catch { /* 忽略 */ } }, timeoutMs);
        p.on('exit', (code) => { clearTimeout(t); fs.closeSync(fd); say(`■ ${name} exit=${code} 剩 ${leftMin().toFixed(0)}min`); resolve(code ?? -1); });
        p.on('error', (e) => { clearTimeout(t); fs.closeSync(fd); say(`✗ ${name} ${String(e.message)}`); resolve(-2); });
    });
}

const results = [];
const record = (step, code, extra = {}) => { results.push({ step, code, at: new Date().toISOString(), ...extra }); fs.writeFileSync(SUMMARY, JSON.stringify(results, null, 2)); };

// ─────────────────────────── ① 服务端真值 ───────────────────────────
if (!SKIP_TRUTH) {
    const code = await run('01_truth', [path.join(HERE, 'furnace_truth.mjs'), '--lane', 'A', '--arms', 'old,twoStep,quickMove', '--n', String(TRUTH_N), '--stamp', `${STAMP}_TRUTH`], 15 * 60000);
    const truthPath = path.join(HERE, 'runs', `${STAMP}_TRUTH`, 'furnace_truth.json');
    let arms = null, quickOk = 0, need = Math.ceil(TRUTH_N * 0.75);
    try { arms = JSON.parse(fs.readFileSync(truthPath, 'utf8')); } catch { /* 落盘失败也算没拿到 */ }
    const rounds = Array.isArray(arms?.rounds) ? arms.rounds : (Array.isArray(arms) ? arms : []);
    const qm = rounds.filter((r) => r.arm === 'quickMove' && r.result?.ok);
    quickOk = qm.length;
    say(`闸门：quickMove ok=${quickOk}/${TRUTH_N}（需 ≥${need}）`);
    record('01_truth', code, { quickMoveOk: quickOk, need, rounds: rounds.length });
    if (code !== 0 || quickOk < need) {
        say('⛔ 熔炉侧没达标，按派单停在这里，不跑整局回归（手册 §6：先证明再扩大）');
        say(`详见 ${truthPath}`);
        process.exit(3);
    }
} else {
    say('① 按 --skip-truth 跳过');
    record('01_truth', 0, { skipped: true });
}

// ─────────────────────────── ② 熔炉微基准 30 轮 ───────────────────────────
if (leftMin() > 12) {
    // ⚠ `--arms` 传的是**开关名**：熔炉块的入口是 `if (ARMS.includes('furnace'))`（craft_bot_t09.mjs:203），
    //   进去以后 old/self 两臂各跑 N 轮。传 `--arms old,self` 反而把 'furnace' 漏掉 ⇒ 一轮都不跑，
    //   而且日志只留一句"墙钟 0.8min"，**看起来像跑完了**。
    //   同理 `--cells` 是**合成格子**的过滤，熔炉臂不吃它 —— 传 `--cells furnace` 会把合成格子全滤空。
    const code = await run('02_furnbench', [path.join(HERE, 'run_t09.mjs'), '--stamp', `${STAMP}_FURN`, '--n', '30', '--lane', 'A', '--arms', 'furnace'], 40 * 60000);
    record('02_furnbench', code);
    // ②跑完立刻自检：**一轮都没跑**要当场喊出来，不能让它滑过去。
    //   （第一版就是这么把 0.8min 的空跑当成"跑完了"，一路放行到 ③④。）
    try {
        const rows = JSON.parse(fs.readFileSync(path.join(HERE, 'runs', `${STAMP}_FURN`, 'craft_result.json'), 'utf8')).rows ?? [];
        const arms = [...new Set(rows.map((r) => `${r.cell}`))];
        say(`② 自检：落盘 ${rows.length} 行，臂=${JSON.stringify(arms)}`);
        if (rows.length < 40) { say('⛔ ② 落盘行数远少于 2 臂 × 30 轮，判为"没真跑"，不进 ③④'); record('02_furnbench', code, { rows: rows.length, suspect: 'empty_run' }); process.exit(4); }
        record('02_furnbench_rows', rows.length, { arms });
    } catch (e) { say(`⛔ ② 读不到 craft_result.json（${String(e.message).slice(0, 80)}），判为没真跑，不进 ③④`); process.exit(4); }
} else { say('② 预算不足，跳过熔炉 30 轮'); record('02_furnbench', -3, { skipped: 'budget' }); }

// ─────────────────────────── ③ 主种子 iron_pickaxe ×5 ───────────────────────────
if (leftMin() > 30) {
    const code = await run('03_iron', [path.join(ROOT, 'bench/stages/basic-iron/run_bench.mjs'), '--trials', '5', '--resource', 'iron_pickaxe', '--mc-version', '1.16.1', '--stamp', `${STAMP}_REG_IRON`, '--seed', '4926685115947721762', '--lanes', '1', '--lane', 'A'], 45 * 60000);
    record('03_iron', code);
} else { say('③ 预算不足，跳过 iron_pickaxe'); record('03_iron', -3, { skipped: 'budget' }); }

// ─────────────────────────── ④ M4B4 回归 ───────────────────────────
// 每局 = 一次 fresh world + 一次起服（runner_core:419-456）；06c 基线 REG_M4B4 的
// 局时长中位 75s ⇒ 按 170s/局（含起服）估，能装多少装多少，装不满就如实报局数。
if (leftMin() > 6) {
    const fit = Math.max(1, Math.min(M4B4_CAP, Math.floor(leftMin() / 2.9)));
    say(`④ M4B4：预算剩 ${leftMin().toFixed(0)}min → 跑 ${fit} 局（上限 ${M4B4_CAP}）`);
    const code = await run('04_m4b4', [path.join(ROOT, 'bench/stages/basic-bootstrap/run_bench.mjs'), '--trials', String(fit), '--mc-version', '1.16.1', '--stamp', `${STAMP}_REG_M4B4`, '--seed-prefix', 'P2C_M4B4', '--start', '1', '--lanes', '1', '--lane', 'A'], (leftMin() - 2) * 60000);
    record('04_m4b4', code, { requestedTrials: fit });
} else { say('④ 预算不足，跳过 M4B4'); record('04_m4b4', -3, { skipped: 'budget' }); }

say(`全部结束，剩 ${leftMin().toFixed(0)}min；summary → ${SUMMARY}`);
process.exit(0);
