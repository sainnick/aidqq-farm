// craft_diag.mjs — P1 归因探针：工作台 3×3「静默丢件」到底丢在哪一步。
//
// 06d 微基准测到：wooden_pickaxe 走工作台 21/30，stone_pickaxe 30/30，失败**不抛错**、
// 耗时与成功一致、失败后背包与成功完全相同（材料没少也没多）。所以不是"料被消耗"，
// 只能是"服务端压根没出产物"。
//
// mineflayer 4.38 的 craft() 收尾是 grabResult()：
//     window.updateSlot(0, new Item(result))   ← **本地伪造**产物槽
//     await bot.putAway(0)                     ← 再点一下 0 号槽拿走
// 也就是说：产物不是等服务端算出来的，是客户端先塞进去再点。只要**服务端的合成格状态**
// 和客户端以为的不一样，服务端 0 号槽就是空的，putAway 点了个寂寞 → 静默丢件。
//
// 本探针做的事：把**服务端真值**（set_slot 包）和**客户端本地 updateSlot** 分开记账，
// 逐次对比「点 0 号槽之前那一刻，服务端发过什么」。失败局要能一眼看出是哪一步分叉的。
//
// 用法：node craft_diag.mjs --out <dir> --port 25566 --username TaskBot --n 20

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const OUT = path.resolve(arg('out', HERE));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const N = parseInt(arg('n', '20'), 10);
const ITEM = arg('item', 'wooden_pickaxe');
// 热手：06d 的 wooden_pickaxe/table 是整批的第 5 格，前面已经跑过 120 次合成。
// 只跑目标格 20/20 复现不出丢件 → 必须把同样的热手前缀复现出来（--warmup 0 可关）。
const WARMUP = arg('warmup', '30');
const SETUP = path.join(OUT, 'setup.json');
const RES = path.join(OUT, 'craft_diag_result.json');
const DONE = path.join(OUT, 'done.json');
for (const f of [RES, DONE]) { try { fs.rmSync(f, { force: true }); } catch { /* 忽略 */ } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[cdiag ${new Date().toISOString().slice(11, 19)}] ${m}`);
const mcData = require('minecraft-data')('1.16.1');
const nbt = require('prismarine-nbt');   // 直接是对象（不是工厂）
const jname = (id) => (id === -1 ? 'EMPTY' : `${mcData.items[id]?.name ?? id}`);
// 1.16.1 的 set_slot 里 item 是个 { present, slot:{...NBT} } 的槽结构，名字在 NBT.id 上
const pktName = (it) => {
    if (!it) return 'EMPTY';
    try {
        if (typeof it === 'number') return jname(it);
        const s = nbt.simplify(it.slot ?? it);
        if (!s || s.id === undefined) return 'EMPTY';
        return `${String(s.id).replace('minecraft:', '')}x${s.Count ?? 1}`;
    } catch { return `?(${Object.keys(it).join('/')})`; }
};

async function main() {
    const mineflayer = require('mineflayer');
    const { Vec3 } = require('vec3');
    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: '1.16.1' });
    await new Promise((resolve, reject) => {
        bot.once('spawn', resolve); bot.once('error', reject); setTimeout(() => reject(new Error('spawn timeout')), 60000);
    });
    log(`spawned`);
    await sleep(3500);
    for (let i = 0; i < 120 && !fs.existsSync(SETUP); i++) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('no setup.json（runner 没 op）');

    let seq = 0, msgQueue = [];
    bot.on('message', (m) => { try { msgQueue.push(String(m.toString ? m.toString() : m)); } catch { msgQueue.push('?'); } });
    async function cmd(text, { waitMs = 500 } = {}) {
        const id = `@@D${++seq}`;
        msgQueue = [];
        bot.chat(`/say ${id}`);
        const t0 = Date.now();
        while (Date.now() - t0 < 3000 && !msgQueue.some((s) => s.includes(id))) await sleep(25);
        msgQueue = [];
        bot.chat(`/${text}`);
        const tw = Date.now();
        while (Date.now() - tw < waitMs && !msgQueue.length) await sleep(25);
        await sleep(40);
        const r = msgQueue.join(' | '); msgQueue = []; return r;
    }
    const count = (name) => bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0);

    const SX = 200, SY = 68, SZ = 200;
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(2000);
    await cmd(`fill ${SX - 4} ${SY} ${SZ - 4} ${SX + 4} ${SY} ${SZ + 4} minecraft:stone`, { waitMs: 900 });
    await cmd(`fill ${SX - 4} ${SY + 1} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:air`, { waitMs: 900 });
    await cmd(`setblock ${SX + 1} ${SY + 1} ${SZ} minecraft:crafting_table`, { waitMs: 700 });
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(1500);
    const table = bot.blockAt(new Vec3(SX + 1, SY + 1, SZ));
    log(`工作台 ${table?.name} @${SX + 1},${SY + 1},${SZ}`);

    // ---- 真值记账：服务端 set_slot 包 vs 客户端本地 updateSlot ----
    const serverPackets = [];
    const clientWrites = [];
    bot._client.on('packet', (data, meta) => {
        if (meta?.name !== 'set_slot' && meta?.name !== 'window_items') return;
        if (meta.name === 'set_slot') {
            const it = data.item;
            serverPackets.push({ t: Date.now(), kind: 'set_slot', win: data.windowId, slot: data.slot, item: pktName(it) });
        } else {
            serverPackets.push({ t: Date.now(), kind: 'window_items', win: data.windowId, n: (data.items ?? data.slots ?? []).length });
        }
    });
    const hookClicks = () => {
        const orig = bot.clickWindow.bind(bot);
        bot.clickWindow = async function patched(slot, mouseButton, mode) {
            const w = bot.currentWindow;
            const before = w ? { sel: w.selectedItem ? `${jname(w.selectedItem.type)}x${w.selectedItem.count}` : 'none', grid: gridOf(w) } : null;
            const r = await orig(slot, mouseButton, mode);
            const after = w ? { sel: w.selectedItem ? `${jname(w.selectedItem.type)}x${w.selectedItem.count}` : 'none', grid: gridOf(w) } : null;
            clientWrites.push({
                t: Date.now(), op: `click slot=${slot} btn=${mouseButton} mode=${mode}`,
                win: w?.id ?? null, winType: w?.type ?? null, before, after,
            });
            return r;
        };
        const origUpdate = null; void origUpdate;
    };
    const gridOf = (w) => {
        if (!w) return null;
        const out = [];
        for (let s = 0; s <= 9; s++) {
            const it = w.slots[s];
            out.push(s === 0 ? `R:${it ? jname(it.type) : 'EMPTY'}` : `${s}:${it ? jname(it.type) : '-'}`);
        }
        return out.join(' ');
    };
    hookClicks();

    const rows = [];
    const refuel = async () => {
        for (const junk of [ITEM, 'stone_pickaxe', 'stick', 'oak_planks', 'cobblestone', 'oak_log']) await cmd(`clear @s minecraft:${junk}`, { waitMs: 120 });
        await cmd(`give @s minecraft:oak_planks 16`, { waitMs: 200 });
        await cmd(`give @s minecraft:cobblestone 16`, { waitMs: 200 });
        await cmd(`give @s minecraft:stick 16`, { waitMs: 200 });
        await cmd(`give @s minecraft:oak_log 8`, { waitMs: 200 });
        await sleep(400);
    };
    const simpleCraft = async (itemName, useTable) => {
        await refuel();
        const id = bot.registry.itemsByName[itemName]?.id;
        const rs = bot.recipesFor(id, null, 1, useTable ? table : null);
        if (!rs.length) return;
        try { await bot.craft(rs[0], 1, useTable ? table : null); } catch { /* 忽略 */ }
        try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow); } catch { /* 忽略 */ }
    };

    // ---- 热身：逐字复现 06d 批次的顺序与次数（前面 4 格 × N 次），不记账 ----
    if (Number(WARMUP) > 0) {
        const wn = Number(WARMUP);
        const plan = [['stick', false], ['stick', false], ['stick', true], ['oak_planks', false]];
        for (const [nm, useT] of plan) {
            for (let k = 0; k < wn; k++) await simpleCraft(nm, useT);
            log(`热身 ${nm}/${useT ? 'table' : 'inv2x2'} ×${wn} 完成（累计 ${count('stick')} 根木棍）`);
        }
    }

    for (let i = 0; i < N; i++) {
        await refuel();
        const invBefore = bot.inventory.items().map((x) => `${x.slot}:${x.name}x${x.count}`).join(' ');

        const tableBlock = table;
        const itemId = bot.registry.itemsByName[ITEM]?.id;
        const recipes = bot.recipesFor(itemId, null, 1, tableBlock);
        if (!recipes.length) { log(`没有配方`); break; }
        const recipe = recipes[0];
        const variants = bot.recipesAll(itemId, null, tableBlock).length;

        serverPackets.length = 0; clientWrites.length = 0;
        const before = count(ITEM);
        const t0 = Date.now();
        let err = null;
        try { await bot.craft(recipe, 1, tableBlock); } catch (e) { err = String(e?.message ?? e).slice(0, 140); }
        const ms = Date.now() - t0;
        let gained = count(ITEM) - before;
        const dl = Date.now() + 2000;
        while (gained <= 0 && Date.now() < dl) { await sleep(150); gained = count(ITEM) - before; }
        const win = bot.currentWindow;
        const row = {
            i, item: ITEM, variants, err, ms, gained, verified: gained > 0,
            invBefore,
            invAfter: bot.inventory.items().map((x) => `${x.slot}:${x.name}x${x.count}`).join(' '),
            // 客户端这一轮做了哪些点击
            clicks: clientWrites.map((c) => c.op),
            // 每次点击后客户端眼中的合成格
            gridAfterEachClick: clientWrites.map((c) => c.after?.grid ?? null),
            // 服务端这一轮真正发回来的槽位更新
            server: serverPackets.map((p) => (p.kind === 'set_slot' ? `w${p.win}#${p.slot}=${p.item}` : `${p.kind}@w${p.win}(${p.n})`)),
            // 点 0 号槽（取产物）前后，服务端有没有发过 result slot
            resultSlotFromServer: serverPackets.filter((p) => p.kind === 'set_slot' && p.slot === 0).map((p) => `w${p.win}#0=${p.item}`),
            winAtEnd: win ? `${win.type}#${win.id}` : 'null',
        };
        rows.push(row);
        log(`#${i} ${gained > 0 ? 'OK ' : 'DROPPED'} ${ms}ms err=${err ?? '-'} 服务端result包=${JSON.stringify(row.resultSlotFromServer)} 包数=${serverPackets.length}`);
        try { if (win) bot.closeWindow(win); } catch { /* 忽略 */ }
        await sleep(200);
    }
    const ok = rows.filter((r) => r.verified).length;
    fs.writeFileSync(RES, JSON.stringify({ item: ITEM, n: N, ok, total: rows.length, rows }, null, 2));
    fs.writeFileSync(DONE, JSON.stringify({ done: true }));
    log(`=== ${ITEM}: ${ok}/${rows.length} ===`);

    // 打印第一失败局与第一成功局的逐步对照
    const f = rows.find((r) => !r.verified); const g = rows.find((r) => r.verified);
    for (const [tag, r] of [['失败局', f], ['成功局', g]]) {
        if (!r) continue;
        console.log(`\n──── ${tag} i=${r.i} ────`);
        console.log(`invBefore: ${r.invBefore}`);
        console.log(`invAfter : ${r.invAfter}`);
        r.clicks.forEach((c, k) => console.log(`  ${String(k).padStart(2)} ${c.padEnd(26)} grid: ${r.gridAfterEachClick[k] ?? '-'}`));
        console.log(`  服务端包: ${r.server.join(' ') || '（无）'}`);
    }
    bot.quit();
    process.exit(0);
}
main().catch((e) => { log(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 500)}`); process.exit(1); });
