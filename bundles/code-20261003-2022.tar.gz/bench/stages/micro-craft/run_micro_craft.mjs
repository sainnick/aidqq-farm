// run_micro_craft.mjs — MC-M1-TASK-06d P1-2：背包合成 A/B 微基准的编排（一条泳道，一台服）。
// 手工 §9：主线 A 只用泳道 A。
// 用法：node run_micro_craft.mjs --stamp M1 [--n 30] [--lane A]

import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { parseLanes, buildLanes, bootServerWithRetry, stopServer, freshWorld, log } from '../_lib/runner_core.mjs';
import { cleanup, installRunnerHooks } from '../_lib/cleanup.mjs';
import { preflight } from '../_lib/preflight.mjs';
import { holdLocks } from '../_lib/line_lock.mjs';
import { waitReserveClear } from '../_lib/reserve.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const NODE20 = path.join(ROOT, '.runtime/node-v20.20.2-win-x64/node.exe');
const JAR = path.join(TEMPLATE, process.env.MC_BENCH_JAR || 'server-1.16.1.jar');
const RCON_PASS = 'spike-rcon';

const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const N = parseInt(arg('n', '30'), 10);
const STAMP = arg('stamp', `MC1_${new Date().toISOString().slice(5, 10).replace(/[-T]/g, '')}`);
const LANE_NAMES = parseLanes(process.argv);
const XMX = arg('server-xmx', '1G');

const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
fs.mkdirSync(RUNS_DIR, { recursive: true });
process.env.JAVA_TOOL_OPTIONS ||= '-Djava.net.preferIPv4Stack=true';
// ROUND3 P0：线锁（同一泳道只能一个会话）+ 拍摄预约（预约期内不开新局）+ preflight
const lock = await holdLocks([LANE_NAMES[0]], { who: 'A', label: `micro-craft ${STAMP}`, logFn: log });
installRunnerHooks(() => `micro-craft ${STAMP}`, () => { try { lock.releaseAll?.(); } catch { /* 忽略 */ } });
const pf = await preflight({ killStale: true, laneNames: [LANE_NAMES[0]], who: 'A', logFn: log });
for (const l of pf.notes) log(`preflight: ${l}`);
for (const w of pf.warns) log(`preflight ! ${w}`);
if (!pf.ok) { for (const b of pf.blockers) log(`preflight X ${b}`); await lock.releaseAll?.(); process.exit(1); }
await waitReserveClear({ who: 'A', logFn: log });

const t0 = Date.now();
log(`micro-craft n=${N} lane=${LANE_NAMES.join(',')} → ${path.relative(ROOT, RUNS_DIR)}`);
const [lane] = buildLanes({ names: [LANE_NAMES[0]], templateDir: TEMPLATE, jarPath: JAR, rconPass: RCON_PASS, logFn: log });
lane.java = JAVA;
freshWorld(lane, `MICROCRAFT-${STAMP}`);
const server = await bootServerWithRetry(lane, RUNS_DIR, XMX, log);
log(`server up in ${(server.bootMs / 1000).toFixed(0)}s`);

const botLog = fs.openSync(path.join(RUNS_DIR, 'bot_console.log'), 'w');
const BOT = arg('bot', 'craft_bot.mjs');
const bot = spawn(NODE20, [path.join(BENCH_DIR, BOT), '--out', RUNS_DIR, '--port', String(lane.serverPort), '--username', lane.username, '--n', String(N),
    ...(process.argv.includes('--item') ? ['--item', arg('item')] : []),
    ...(process.argv.includes('--warmup') ? ['--warmup', arg('warmup')] : [])],
    { stdio: ['ignore', botLog, botLog] });
try {
    const tj = Date.now();
    while (!/joined the game/.test(fs.readFileSync(path.join(RUNS_DIR, 'server.log'), 'utf8')) && Date.now() - tj < 120000) await new Promise((r) => setTimeout(r, 1000));
    server.child.stdin.write(`op ${lane.username}\n`);
    await new Promise((r) => setTimeout(r, 1500));
    fs.writeFileSync(path.join(RUNS_DIR, 'setup.json'), JSON.stringify({ op: lane.username }));
    log('bot 已 op，放行');
    const td = Date.now();
    while (!fs.existsSync(path.join(RUNS_DIR, 'done.json')) && bot.exitCode === null && Date.now() - td < 1800000) await new Promise((r) => setTimeout(r, 3000));
} finally {
    try { bot.kill(); } catch { /* 忽略 */ }
    fs.closeSync(botLog);
    await stopServer(lane, server);
}

const resPath = path.join(RUNS_DIR, BOT === 'craft_bot.mjs' ? 'craft_result.json' : 'craft_diag_result.json');
const md = [`# micro-craft A/B — ${STAMP}`, ''];
if (fs.existsSync(resPath) && BOT === 'craft_bot.mjs') {
    const r = JSON.parse(fs.readFileSync(resPath, 'utf8'));
    md.push('| 物品/通道 | n | 背包增量确认成功 | 成功率 | 中位 ms | 报错分布 |', '|---|---|---|---|---|---|');
    for (const [k, v] of Object.entries(r.cells)) md.push(`| ${k} | ${v.n} | ${v.verified} | **${v.rate}%** | ${v.medianMs} | ${JSON.stringify(v.errs)} |`);
    md.push('', '> 2×2 = window 0 背包通道；table = 工作台通道。验收线：每格 ≥29/30。');
} else if (fs.existsSync(resPath)) {
    const r = JSON.parse(fs.readFileSync(resPath, 'utf8'));
    md.push(`归因探针：${r.item} ${r.ok}/${r.total}`);
    const bad = r.rows.filter((x) => !x.verified);
    md.push('', `失败序号: [${bad.map((b) => b.i).join(',')}]`, '', '| i | ms | err | 客户端点击 | 服务端 result 包 |', '|---|---|---|---|---|');
    for (const x of r.rows) md.push(`| ${x.i} | ${x.ms} | ${x.err ?? '-'} | ${x.clicks.length} | ${JSON.stringify(x.resultSlotFromServer)} |`);
} else md.push('（探针没产出结果，看 bot_console.log）');
fs.writeFileSync(path.join(RUNS_DIR, 'craft_report.md'), md.join('\n') + '\n');
log(`墙钟 ${((Date.now() - t0) / 60000).toFixed(1)}min → ${path.join(RUNS_DIR, 'craft_report.md')}`);
const cu = await cleanup({ label: `micro-craft ${STAMP}`, rmWorlds: true, dirs: [{ dir: lane.dir, port: lane.serverPort }], laneNames: [LANE_NAMES[0]] });
fs.writeFileSync(path.join(RUNS_DIR, 'cleanup.txt'), cu.lines.join('\n') + '\n');
await lock.releaseAll?.();
process.exit(fs.existsSync(resPath) ? 0 : 2);
