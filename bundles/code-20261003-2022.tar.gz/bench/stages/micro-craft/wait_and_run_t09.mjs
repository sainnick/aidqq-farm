﻿// wait_and_run_t09.mjs — MC-M1-TASK-09：等 preflight 放行再跑（不抢别的泳道）。
//
// 为什么需要它：本单开工时 B 线（P8R8_MICRO）、C 线、F 线同时在跑，机器空闲内存掉到
// 1866MB < 单泳道下限 2560MB，preflight 直接拒绝。手册 §4.7 的口径是「preflight 不放行
// 就排队，不抢别的泳道」，所以这里**只等**，不碰别人的进程、不降配硬跑。
//
// 用法：node wait_and_run_t09.mjs --stamp T09_SMOKE --n 3 --arms old,self,tableCraft --max-wait-min 50 -- ...

import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';
import os from 'os';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const arg = (n, d) => { const a = process.argv.slice(2); const i = a.indexOf(`--${n}`); return i >= 0 ? a[i + 1] : d; };
const MAX_WAIT_MIN = parseFloat(arg('max-wait-min', '50'));
const passthru = process.argv.slice(2).filter((v, i, a) => !(v.startsWith('--max-wait-min')));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[wait ${new Date().toISOString().slice(11, 19)}] ${m}`);

const freeMb = () => os.freemem() / (1024 * 1024);
const NEED = 2900;   // preflight 的下限 2560 + 余量

const t0 = Date.now();
let lastLog = 0;
while (Date.now() - t0 < MAX_WAIT_MIN * 60000) {
    const f = freeMb();
    if (f >= NEED) { log(`内存够了 free=${f.toFixed(0)}MB → 起飞`); break; }
    if (Date.now() - lastLog > 60000) { lastLog = Date.now(); log(`排队中 free=${f.toFixed(0)}MB < ${NEED}MB，等 ${Math.round((MAX_WAIT_MIN * 60000 - (Date.now() - t0)) / 60000)}min 上限`); }
    await sleep(20000);
}
if (freeMb() < NEED) { log(`等满 ${MAX_WAIT_MIN}min 仍只有 ${freeMb().toFixed(0)}MB，放弃本轮（不抢泳道）`); process.exit(3); }

const child = spawn(process.execPath, [path.join(HERE, 'run_t09.mjs'), ...passthru], { stdio: 'inherit' });
child.on('exit', (code) => process.exit(code ?? 0));
