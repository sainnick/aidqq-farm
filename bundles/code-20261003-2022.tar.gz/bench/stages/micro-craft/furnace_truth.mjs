﻿// furnace_truth.mjs — MC-M1-TASK-10 取证脚本（主线 A，泳道 A）
//
// 本脚本**不是修 bug**，是**取证**。要回答的唯一问题：
//   1.16.1 上「熔炉取产物」0–2/30，点输出格被服务端 accepted、输出格清空、
//   **背包增量恒 0** —— 那么产物到底去了哪？三条候选：
//     (a) 停在**光标**：服务端 set_slot(windowId=-1, slot=-1, carried) 里出现产物
//     (b) 被**扔在地上**：关窗时 bot 周围出现 `item` 实体
//     (c) **凭空消失**：服务端背包没有、地上也没有
//   并把服务端背包（`data get entity <bot> Inventory`）在取件前/后/关窗后三个时刻各拍一次。
//
// 为什么要**单进程**（服 + bot 同进程）：
//   只有拿到 `server.child.stdin` 的那个进程能发控制台命令（`/data get entity …`），
//   而取证必须和「取件前/取件后/关窗后」三个时刻**紧贴**（手册 §5：
//   A/B/C 三次快照若放在同一状态之后，对照全部失效）。
//   run_t09.mjs 是「runner 起服 + spawn bot 子进程」，那条路拿不到 stdin ⇒ 换成本进程内建 bot。
//   其余启动/收工结构**逐行照抄** run_t09.mjs（线锁 + preflight + 预约 + freshWorld +
//   bootServerWithRetry + cleanup），只换了 bot 的存活方式。
//
// 依赖从任务层解析（bench 目录没有 node_modules）——照抄 window_ops_selftest.mjs:18-29。
//
// 用法：node furnace_truth.mjs --stamp FT1 [--n 10] [--smoke] [--lane A]

import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { createRequire } from 'module';
import { parseLanes, buildLanes, bootServerWithRetry, stopServer, freshWorld, log } from '../_lib/runner_core.mjs';
import { cleanup, installRunnerHooks } from '../_lib/cleanup.mjs';
import { preflight } from '../_lib/preflight.mjs';
import { holdLocks } from '../_lib/line_lock.mjs';
import { waitReserveClear } from '../_lib/reserve.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
// 依赖从任务层解析（bench 无 node_modules）
const require2 = createRequire(path.join(MINDCRAFT, 'main.js'));

const TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR = path.join(TEMPLATE, process.env.MC_BENCH_JAR || 'server-1.16.1.jar');
const RCON_PASS = 'spike-rcon';
const XMX = argRaw('server-xmx', '1G');

function argRaw(n, d) { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; }
const SMOKE = process.argv.includes('--smoke');
const N = SMOKE ? 3 : parseInt(argRaw('n', '10'), 10);
const STAMP = argRaw('stamp', `FT_${new Date().toISOString().slice(5, 10).replace(/[-T]/g, '')}`);
const LANE_NAMES = parseLanes(process.argv);
const ARMS = argRaw('arms', 'old,twoStep,quickMove').split(',').map((s) => s.trim()).filter(Boolean);
// 每轮投几个铁矿。**这是复现失败的关键变量**：
//   1 个 → 熔完就熄火（10s/轮），三臂都 4/4；
//   8 个 → 熔炉持续工作（80s/轮），**历史微基准的 `old` 臂在这个配置下只有 1/30**。
// 探针默认 1（跑得快），要复现用 `--ore 8`。
const ORE = Math.max(1, parseInt(argRaw('ore', '1'), 10));
const TAKEOUT = parseInt(argRaw('takeout-timeout', '2500'), 10);

const RUNS_DIR = path.join(HERE, 'runs', STAMP);
fs.mkdirSync(RUNS_DIR, { recursive: true });
const OUT_JSON = path.join(RUNS_DIR, 'furnace_truth.json');
const OUT_MD = path.join(RUNS_DIR, 'furnace_truth.md');
const OUT_DONE = path.join(RUNS_DIR, 'done.json');
const OUT_LOG = path.join(RUNS_DIR, 'furnace_truth.log');
for (const f of [OUT_JSON, OUT_DONE]) { try { fs.rmSync(f, { force: true }); } catch { /* 忽略 */ } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const say = (m) => { const line = `[ft ${new Date().toISOString().slice(11, 19)}] ${m}`; log(m); try { fs.appendFileSync(OUT_LOG, line + '\n'); } catch { /* 忽略 */ } };

// 任务层原语（探针必须调**真代码**，不是抄一份形状 —— 抄的形状测不出真 bug）
const OPS = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/window_ops.js')).href);
const { takeFromSlotConfirmed, takeFurnaceOutputQuickMove, closeWindowConfirmed, countItemsWindowAware, clickFlavor } = OPS;

const NOTES = [
    'groundItems 是**客户端通道**（bot.entities）：掉在 bot 脚下的掉落物必然在渲染距离内，但只覆盖已加载区块；服务端交叉验证看 serverItemCount。',
    'serverItemCount 口径 = overworld 维度**全量** @e[type=item]（execute in overworld at <bot> as @e[type=item] run time query day，回执行数=个数），**不是** bot 周围 3 格。',
    'data get entity 的回执解析是**启发式**（在同一条 NBT 元素里配对 Count:…b 与 id:"minecraft:…"），原文一律原样存在 serverInv.*.raw；解析不成立时以 raw 为准，本脚本不猜。',
    'setSlotLog **不按 windowId 过滤**：windowId=-1 / slot=-1 的正是服务端光标包（ServerPlayer.java:947/962 的 set_slot(-1,-1,carried)）。',
    'cursorPackets 的 at 是相对**开炉**时刻的毫秒；即使 after 快照被有界等待推迟，期间所有包仍按真实时间戳入账（避免"快照晚了就看不到瞬时光标包"）。',
    '取件后快照固定在取件动作结束后 +400ms；背包增量另用 ≤2.5s 有界等待单独量（量在快照之后，不污染"取件后"这个时刻）。',
];

// ══════════════ 编排层：照抄 run_t09.mjs ══════════════
process.env.JAVA_TOOL_OPTIONS ||= '-Djava.net.preferIPv4Stack=true';
const lock = await holdLocks([LANE_NAMES[0]], { who: 'A-TASK10', label: `furnace-truth ${STAMP}`, logFn: log });
installRunnerHooks(() => `furnace-truth ${STAMP}`, () => { try { lock.releaseAll?.(); } catch { /* 忽略 */ } });
const pf = await preflight({ killStale: true, laneNames: [LANE_NAMES[0]], who: 'A-TASK10', logFn: log });
for (const l of pf.notes) say(`preflight: ${l}`);
for (const w of pf.warns) say(`preflight ! ${w}`);
if (!pf.ok) { for (const b of pf.blockers) say(`preflight X ${b}`); await lock.releaseAll?.(); process.exit(1); }
await waitReserveClear({ who: 'A', logFn: log });

const t0 = Date.now();
say(`furnace-truth n=${N}${SMOKE ? '(smoke)' : ''} arms=${ARMS.join(',')} lane=${LANE_NAMES.join(',')} → ${path.relative(ROOT, RUNS_DIR)}`);
const [lane] = buildLanes({ names: [LANE_NAMES[0]], templateDir: TEMPLATE, jarPath: JAR, rconPass: RCON_PASS, logFn: log });
lane.java = JAVA;
freshWorld(lane, `FURNTRUTH-${STAMP}`);
const server = await bootServerWithRetry(lane, RUNS_DIR, XMX, log);
say(`server up in ${(server.bootMs / 1000).toFixed(0)}s`);

// ══════════════ 控制台通道：单队列串行 + **字节游标** ══════════════
// 手册 §5 的两个坑都在这里：
//   ① 迟到的旧回执会被当成本条的答案 ⇒ 每条命令开跑前先**静默收尾**吸干上一条的尾巴，
//      且全局**串行**（同一时刻只允许一条在途 ⇒ 两条 time query 绝不同在途）。
//   ② 日志里有中文 ⇒ **按字节切行**。用字符串长度回退偏移会算错字节数 → 偏移漂移 → 回执重复/丢失。
const SERVER_LOG = path.join(RUNS_DIR, 'server.log');
const RE_TIME = /The time is (\d+)/;
const RE_CMD_ERR = /Unknown or incomplete command|Incorrect argument|Invalid|Expected|is not a valid/;

let logCursor = 0;              // 已消费的**字节**数；永远落在行尾
let logTail = Buffer.alloc(0);  // 还没凑成一整行的尾巴字节（可能劈开一个中文字符）
const logMark = () => logCursor;

/** 推进字节游标，返回本次新凑齐的完整行。⚠ 全程按 Buffer 字节算，绝不按字符串长度。 */
function pumpLog() {
    let buf;
    try { buf = fs.readFileSync(SERVER_LOG); } catch { return []; }
    if (buf.length <= logCursor) return [];
    const chunk = buf.subarray(logCursor);
    const all = logTail.length ? Buffer.concat([logTail, chunk]) : chunk;
    const cut = all.lastIndexOf(0x0a);            // 0x0a = '\n'
    if (cut < 0) { logTail = all; return []; }    // 还没攒够一整行：留在尾巴里，绝不提前推进游标
    const usable = all.subarray(0, cut + 1);
    logTail = all.subarray(cut + 1);
    logCursor += usable.length;                   // ⚠ 只在行尾推进；未成行的部分留在 logTail
    return usable.toString('utf8').split('\n');    // 只对**完整行**解码 ⇒ 多字节字符永不被劈开
}
/** 从字节锚点 `from` 到现在，原始文本（静默后使用；末尾可能带半行，末尾残缺无害） */
function logRegionText(from) {
    try {
        const buf = fs.readFileSync(SERVER_LOG);
        if (buf.length <= from) return '';
        return buf.subarray(from).toString('utf8');
    } catch { return ''; }
}
/** 等日志**连续 quietMs 没有新字节**（0 匹配通道唯一的收尾手段） */
async function settleLog({ quietMs = 400, maxMs = 2500 } = {}) {
    const dl = Date.now() + maxMs;
    let last = -1, quietSince = Date.now();
    while (Date.now() < dl) {
        pumpLog();
        const now = logCursor + logTail.length;
        if (now !== last) { last = now; quietSince = Date.now(); }
        else if (Date.now() - quietSince >= quietMs) return true;
        await sleep(80);
    }
    return false;
}
let consoleQ = Promise.resolve();
function consoleExclusive(fn) { const r = consoleQ.then(() => fn(), () => fn()); consoleQ = r.then(() => { }, () => { }); return r; }

/**
 * 发一条控制台命令并等**自己那条**回执。
 * expect：每类回执共用一个队列、各自只取**第一条**匹配自己的正则的那条。
 */
async function consoleOnce(cmd, { expect = null, timeoutMs = 4000, quietMs = 400 } = {}) {
    return consoleExclusive(async () => {
        await settleLog({ quietMs: 300, maxMs: 2000 });   // ① 先把上一条迟到的尾巴吸干
        const from = logMark();
        try { server.child.stdin.write(cmd + '\n'); }
        catch (e) { return { cmd, ok: false, error: `write_failed:${String(e && e.message || e)}`, raw: '' }; }
        const dl = Date.now() + timeoutMs;
        while (Date.now() < dl) {
            pumpLog();
            const text = logRegionText(from);
            if (expect) {
                const m = expect.exec(text);
                if (m) return { cmd, ok: true, matched: m[0], raw: text, latencyMs: timeoutMs - (dl - Date.now()) };
            } else {
                await settleLog({ quietMs, maxMs: 1500 });
                return { cmd, ok: true, raw: logRegionText(from), latencyMs: timeoutMs - (dl - Date.now()) };
            }
            await sleep(80);
        }
        await settleLog({ quietMs, maxMs: 1500 });
        return { cmd, ok: false, timedOut: true, raw: logRegionText(from) };
    });
}

/**
 * 计数通道：1.16.1 的 `time query` 回执是 `The time is N`（**不是** "The game time is"），
 * 而 gametime/day/daytime 三者文本**完全一样** ⇒ 绝不能有两条 time query 同时在途（上面已串行）。
 * `as` 对每个匹配实体各执行一次 ⇒ **回执行数 = 个数**；0 匹配是**零输出**，只能用静默窗收尾。
 * 手动数时**按字节区间内的匹配数**数（区间用字节游标锚定），不按全文件行数。
 */
async function consoleCount(cmd, { timeoutMs = 8000, quietMs = 500 } = {}) {
    return consoleExclusive(async () => {
        await settleLog({ quietMs: 300, maxMs: 2000 });
        const from = logMark();
        server.child.stdin.write(cmd + '\n');
        const dl = Date.now() + timeoutMs;
        while (Date.now() < dl) {
            pumpLog();
            const text = logRegionText(from);
            const n = (text.match(new RegExp(RE_TIME.source, 'g')) || []).length;
            if (n > 0) return { cmd, ok: true, count: n, raw: text };
            if (await settleLog({ quietMs, maxMs: 1200 })) return { cmd, ok: true, count: 0, zeroBySilence: true, raw: logRegionText(from) };
        }
        return { cmd, ok: false, timedOut: true, count: null, raw: logRegionText(from) };
    });
}

// ── 服务端背包回执：启发式解析 + **原文必存**（解析失败不吞）──
function parseInvCount(raw, itemName) {
    const res = { count: null, matched: 0, method: null, parseOk: false, note: null, rawBytes: Buffer.byteLength(raw || '', 'utf8') };
    if (!raw || !raw.trim()) { res.note = '回执为空（命令可能没被执行）'; return res; }
    if (!/has the following entity data/.test(raw)) { res.note = '回执不是 data get 的形状，原文见 raw'; res.count = null; return res; }
    const tag = `minecraft:${itemName}`;
    if (!raw.includes(tag)) { res.count = 0; res.matched = 0; res.method = 'text-absence'; res.parseOk = true; res.note = `回执里没有 ${tag}`; return res; }
    // ⚠⚠ 1.16.1 的 `data get` 回执是 **带空格的 SNBT**：`{Slot: 8b, id: "minecraft:iron_ingot", Count: 1b}`。
    //   第一版正则写成 `id:"…"`（冒号后没空格）⇒ **全部 0 命中**，把"服务端背包里明明有铁锭"
    //   报成 count=0（假阴性）。这就是手册 §5 说的"读出全零先证伪工具"，
    //   幸好原文 always 落盘，直接看 raw 就一眼看穿。⇒ `id:\s*"` 必须容许空白。
    let n = 0, hit = 0, m;
    const reA = new RegExp(`Count:\\s*(\\d+)b[^\\}]*id:\\s*"${tag}"`, 'g');   // Count 在前
    while ((m = reA.exec(raw)) !== null) { n += parseInt(m[1], 10); hit++; }
    const reB = new RegExp(`id:\\s*"${tag}"[^\\}]*Count:\\s*(\\d+)b`, 'g');   // id 在前
    while ((m = reB.exec(raw)) !== null) { n += parseInt(m[1], 10); hit++; }
    res.count = n; res.matched = hit; res.parseOk = true;
    res.method = 'heuristic: 同一 NBT 元素内配对 Count:…b 与 id:"…"（容许空白）';
    res.note = hit > 0 ? '启发式解析；原文见 raw，以 raw 为准' : `⚠ 回执里有 ${tag} 但没配上 Count（解析不可信），以 raw 为准`;
    if (hit === 0) res.parseOk = false;
    return res;
}
const INV_TAG = 'data get entity';
async function serverInvSnapshot(tag) {
    const cmd = `${INV_TAG} ${lane.username} Inventory`;
    const r = await consoleOnce(cmd, { expect: /has the following entity data|Unknown|Incorrect|Expected/i, timeoutMs: 3000 });
    return { tag, at: Date.now(), cmd, ok: r.ok, commandError: RE_CMD_ERR.test(r.raw || ''), ...parseInvCount(r.raw, 'iron_ingot'), raw: r.raw ?? '' };
}
/** 服务端口径的地面掉落物数（维度全量）。⚠ `execute at <x> <y> <z>` 坐标形式在 1.16.1 被拒，只能 at <实体>。 */
async function serverCountGroundItems() {
    const primary = `execute in overworld at ${lane.username} as @e[type=item] run time query day`;
    let r = await consoleCount(primary);
    let fallbackUsed = false;
    if (RE_CMD_ERR.test(r.raw || '')) {   // 1.16.1 可能不认 `execute in`（1.16.2+ 才有）⇒ 去掉维度前缀重试，如实记录
        const noDim = `execute at ${lane.username} as @e[type=item] run time query day`;
        const r2 = await consoleCount(noDim);
        r2.fallbackFrom = primary; r2.fallbackUsed = true; r2.primaryRaw = r.raw;
        r = r2; fallbackUsed = true;
    }
    return { ...r, fallbackUsed, scope: 'overworld 全量 @e[type=item]（维度口径，非 bot 周围 3 格）', stamp: STAMP };
}

// ══════════════ 主流程 ══════════════
let bot = null, exitCode = 0;
try {
    // 吸收启动期全部输出，之后游标才干净
    await settleLog({ quietMs: 300, maxMs: 2000 });

    const mineflayer = require2('mineflayer');
    const { Vec3 } = require2('vec3');

    // ── 建连（照抄 craft_bot_t09.mjs）──
    bot = mineflayer.createBot({ host: '127.0.0.1', port: lane.serverPort, username: lane.username, version: '1.16.1' });
    bot.loadPlugin(require2('mineflayer-pathfinder').pathfinder);
    await new Promise((resolve, reject) => {
        bot.once('spawn', resolve); bot.once('error', reject);
        setTimeout(() => reject(new Error('spawn timeout')), 60000);
    });
    say(`spawned ${bot.entity.position.toArray().map((v) => v.toFixed(0))}｜协议 ${bot.version}｜窗口通道 ${JSON.stringify(clickFlavor(bot))}`);
    await sleep(3000);

    // ── op（照抄 run_t09.mjs：只有拿到 stdin 的进程能 op）──
    // ⚠ 闸门不能只看 `list`：`list` 只列**在线玩家**，**不显示权限等级**，
    //   op 没生效时它照样能看到 bot ⇒ 闸门会"通过"，然后每一轮都栽在
    //   `/clear @s` / `/give` 权限不足上（静默：kit 没到位 → 全轮 kit_failed）。
    // ⇒ 改成**功能性闸门**：让 bot 自己发一条只有 op(等级2)能执行的命令，
    //   再从**客户端**确认背包真的被清空了。清空成功 = 权限真的到位。
    server.child.stdin.write(`op ${lane.username}\n`);
    await sleep(1500);
    const opList = await consoleOnce('list', { expect: new RegExp(lane.username), timeoutMs: 5000 });
    say(`op 名单回执: ${opList.ok ? 'OK' : 'FAIL'} raw=${JSON.stringify((opList.raw || '').slice(0, 160))}`);
    // 功能性验证：先塞一个可辨识的物品，再 /clear @s，看它有没有真的消失
    await bot.chat('/give @s minecraft:cobblestone 1'); await sleep(1200);
    const hadProbe = bot.inventory.items().some((i) => i.name === 'cobblestone');
    await bot.chat('/clear @s'); await sleep(1500);
    const opWorks = hadProbe && bot.inventory.items().every((i) => i.name !== 'cobblestone');
    say(`op 功能性闸门: ${opWorks ? 'OK' : 'FAIL'}（塞进探针=${hadProbe}，clear 后还在=${!opWorks}）`);
    if (!opWorks) {
        NOTES.push('op 未生效：/give 或 /clear 权限不足 ⇒ 全部 kit 与布景命令都会静默失效，本轮数据作废');
        throw new Error('op 未生效（/give 或 /clear 无权限），kit 与布景全部会静默失败，停');
    }

    // ── 布景（坐标/几何照抄 craft_bot_t09.mjs，不改）──
    const SX = 200, SY = 68, SZ = 200, FX = SX - 1, FY = SY + 1, FZ = SZ;
    await bot.chat(`/tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`); await sleep(2500);
    await bot.chat(`/fill ${SX - 4} ${SY} ${SZ - 4} ${SX + 4} ${SY} ${SZ + 4} minecraft:stone`); await sleep(1200);
    await bot.chat(`/fill ${SX - 4} ${SY + 1} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:air`); await sleep(1200);
    await bot.chat(`/tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`); await sleep(2000);
    say(`布景就绪：平台 @${SX},${SY},${SZ}｜熔炉位 @${FX},${FY},${FZ}`);

    // ── 三个全量包通道（**不按 windowId 过滤**：windowId=-1 就是光标包）──
    const setSlotLog = [], windowItemsLog = [], transactions = [];
    bot._client.on('set_slot', (p) => {
        const it = OPS.toItem(bot, p && p.item);
        setSlotLog.push({
            atMs: Date.now(), windowId: p?.windowId ?? null, slot: p?.slot ?? null,
            itemType: p?.item?.itemId ?? null, itemCount: p?.item?.itemCount ?? null, itemName: it?.name ?? null,
            isCursor: p?.windowId === -1 && p?.slot === -1,
        });
    });
    bot._client.on('window_items', (p) => {
        windowItemsLog.push({ atMs: Date.now(), windowId: p?.windowId ?? null, items: Array.isArray(p?.items) ? p.items.length : null });
    });
    bot._client.on('transaction', (p) => {
        transactions.push({ atMs: Date.now(), windowId: p?.windowId ?? null, action: p?.action ?? null, accepted: p?.accepted ?? null });
    });

    // ── kit：发命令后**轮询真实背包**直到对上（1.16.1 没有 /say，自验证通道）
    const countInv = (name) => bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0);
    const KIT = { oak_planks: 16, cobblestone: 16, stick: 16, oak_log: 8, coal: 1, iron_ore: ORE };
    const wants = {};
    async function kit() {
        for (const k of Object.keys(wants)) delete wants[k];
        await bot.chat('/clear @s'); await sleep(250);
        for (const [name, n] of Object.entries(KIT)) { await bot.chat(`/give @s minecraft:${name} ${n}`); wants[name] = n; }
        const dl = Date.now() + 12000;
        while (Date.now() < dl) {
            if (Object.entries(wants).every(([name, n]) => countInv(name) >= n)) return true;
            await sleep(200);
        }
        say(`! kit 没到位：${Object.entries(wants).map(([k, v]) => `${k}=${countInv(k)}/${v}`).join(' ')}`);
        return false;
    }
    /** 客户端可见的地面掉落物（bot 3 格内） */
    function groundItems(radius = 3) {
        const p = bot.entity.position; const list = [];
        for (const e of Object.values(bot.entities)) {
            if (e.type !== 'item' && e.name !== 'item') continue;
            const d = e.position.distanceTo(p);
            if (d > radius) continue;
            list.push({ id: e.id, dist: +d.toFixed(2), dropped: (() => { try { return e.getDroppedItem?.()?.name ?? null; } catch { return null; } })() });
        }
        list.sort((a, b) => a.dist - b.dist);
        return { channel: 'client(bot.entities)', radius, count: list.length, nearest: list[0]?.dist ?? null, entities: list.slice(0, 8) };
    }
    /** 三个时刻的客户端模型 */
    function clientModel(win) {
        const s2 = win?.slots?.[2] ?? null;
        return {
            winId: win?.id ?? null,
            windowOpen: !!(win && bot.currentWindow && bot.currentWindow.id === win.id),
            winSlot2: s2 ? `${s2.name}:${s2.count}` : null,
            winSlot2Raw: s2 ? { name: s2.name, count: s2.count, type: s2.type } : null,
            cursorModel: win?.selectedItem ? `${win.selectedItem.name}:${win.selectedItem.count}` : null,
            heldModel: bot.heldItem ? `${bot.heldItem.name}:${bot.heldItem.count}` : null,
            ingotWindowAware: countItemsWindowAware(bot, 'iron_ingot', win ?? null),
        };
    }
    const rounds = [];
    let cur = null;
    const flush = () => fs.writeFileSync(OUT_JSON, JSON.stringify({
        stamp: STAMP, lane: lane.name, n: N, smoke: SMOKE, arms: ARMS, takeoutTimeoutMs: TAKEOUT,
        kit: KIT, orePerRound: ORE, scene: { SX, SY, SZ, furnace: [FX, FY, FZ] }, notes: NOTES, current: cur, rounds,
        global: { setSlotLog, windowItemsLog, transactions },
    }, null, 2));

    for (const arm of ARMS) {
        say(`▶ ${arm} ×${N}`);
        for (let i = 0; i < N; i++) {
            const m = { setSlot: setSlotLog.length, winItems: windowItemsLog.length, tx: transactions.length };
            const base = { arm, i, startedAt: Date.now() };
            cur = { ...base };
            rounds.push(cur);
            if (!(await kit())) { Object.assign(cur, { fail: 'kit_failed' }); continue; }

            // ⚠ **每轮换一口新炉**（先 air 再 furnace）——熔炉跨轮累积会让投料抛 destination full，
            //   把两个臂都污染成假失败（craft_bot_t09.mjs:208-213 的原注释）。不要改成复用。
            await bot.chat(`/setblock ${FX} ${FY} ${FZ} minecraft:air`); await sleep(350);
            await bot.chat(`/setblock ${FX} ${FY} ${FZ} minecraft:furnace`); await sleep(500);
            const furnaceBlock = bot.blockAt(new Vec3(FX, FY, FZ));
            if (furnaceBlock?.name !== 'furnace') { Object.assign(cur, { fail: `scene_gate:${furnaceBlock?.name}` }); continue; }

            let win = null;
            try {
                win = await bot.openFurnace(furnaceBlock);
                await sleep(400);
                await win.putInput(bot.registry.itemsByName.iron_ore.id, null, ORE); await sleep(400);
                await win.putFuel(bot.registry.itemsByName.coal.id, null, 1);
                // 等产物出现在**服务端**输出格（服务端 set_slot 驱动）
                const wdl = Date.now() + 25000;
                while (!(win.slots[2]?.count > 0) && Date.now() < wdl) await sleep(300);
                if (!(win.slots[2]?.count > 0)) { Object.assign(cur, { fail: 'no_output', waitedMs: 25000 }); try { await closeWindowConfirmed(bot, win); } catch { /* 忽略 */ } continue; }

                const openedAt = Date.now();            // 所有相对时间从这里起算
                const marks = { ...m, openedAt };
                cur.outCount = win.slots[2].count;

                // ────────── 时刻 A：取件前 ──────────
                cur.clientModel_before = clientModel(win);
                cur.serverInv_before = await serverInvSnapshot('before');

                // ────────── 取件（三个臂各调一个不同的函数）──────────
                const tTake = Date.now();
                let raw = null, takeErr = null;
                try {
                    if (arm === 'old') raw = await win.takeOutput();                       // 现网复合动作
                    else if (arm === 'twoStep') raw = await takeFromSlotConfirmed(bot, win, 2, { timeoutMs: TAKEOUT, itemName: 'iron_ingot', expectName: 'iron_ingot' });
                    else if (arm === 'quickMove') raw = await takeFurnaceOutputQuickMove(bot, win, { timeoutMs: TAKEOUT, itemName: 'iron_ingot', expectName: 'iron_ingot' });
                    else throw new Error(`未知臂 ${arm}`);
                } catch (e) { takeErr = String(e && e.message ? e.message : e).slice(0, 180); }
                const takeMs = Date.now() - tTake;
                await sleep(400);                       // 让服务端包落地

                // ────────── 时刻 B：取件后 ──────────
                cur.clientModel_after = clientModel(win);
                cur.serverInv_after = await serverInvSnapshot('after');

                // 背包增量单独在后面量（有界），不污染"取件后"这个时刻
                const beforeAware = cur.clientModel_before.ingotWindowAware;
                const gdl = Date.now() + TAKEOUT;
                let gained = countItemsWindowAware(bot, 'iron_ingot', win) - beforeAware;
                while (gained <= 0 && Date.now() < gdl) { await sleep(120); gained = countItemsWindowAware(bot, 'iron_ingot', win) - beforeAware; }
                cur.gained = gained; cur.gainedWaitMs = Date.now() - tTake - takeMs;
                cur.result = arm === 'old'
                    ? { source: 'mineflayer win.takeOutput()', ok: !takeErr && gained > 0, took: raw?.count ?? null, gained, reason: takeErr ? 'threw' : (gained > 0 ? null : 'no_inv_delta'), ms: takeMs, dest: null, cursorUntouched: null, raw: raw ?? null }
                    : { source: arm === 'twoStep' ? 'window_ops.takeFromSlotConfirmed(bot, win, 2, …)' : 'window_ops.takeFurnaceOutputQuickMove(bot, win, …)', ok: !!raw?.ok, took: raw?.took ?? null, gained: raw?.gained ?? null, reason: raw?.reason ?? null, ms: takeMs, dest: raw?.dest ?? null, cursorUntouched: raw?.cursorUntouched ?? null, raw: raw ?? null };
                cur.takeErr = takeErr;

                // ────────── 关窗（任务层 closeWindowConfirmed）──────────
                const closeAt = Date.now();
                cur.groundItems_before = groundItems(3);        // 关窗**前**脚下的掉落物
                cur.closeOk = await closeWindowConfirmed(bot, win);
                cur.closeMs = Date.now() - closeAt;

                // ────────── 时刻 C：关窗后 ──────────
                cur.clientModel_closed = clientModel(win);      // 窗已关 ⇒ windowOpen=false，winSlot2 为陈旧值
                cur.leakedCursor = win?.selectedItem ? `${win.selectedItem.name}:${win.selectedItem.count}` : null;
                cur.serverInv_closed = await serverInvSnapshot('closed');
                cur.groundItems_after = groundItems(3);
                cur.serverItemCount_after = await serverCountGroundItems();

                // 包日志切片（相对开炉时刻）
                const rel = (arr, from) => arr.slice(from).map((e) => ({ ...e, at: e.atMs - openedAt }));
                cur.setSlotLog = rel(setSlotLog, marks.setSlot);
                cur.windowItemsLog = rel(windowItemsLog, marks.winItems);
                cur.transactions = rel(transactions, marks.tx);
                cur.cursorPackets = rel(setSlotLog, marks.setSlot).filter((e) => e.isCursor)
                    .map((e) => ({ at: e.at, windowId: e.windowId, slot: e.slot, itemName: e.itemName, itemCount: e.itemCount }));
                cur.cursorPacketsBeforeClose = cur.cursorPackets.filter((e) => e.at <= closeAt - openedAt);
                cur.cursorAtClose = cur.cursorPacketsBeforeClose.length ? cur.cursorPacketsBeforeClose[cur.cursorPacketsBeforeClose.length - 1] : null;
                cur.cursorGotProduct = cur.cursorPackets.some((e) => e.itemName === 'iron_ingot');
                cur.groundGotProduct = cur.groundItems_after.entities.some((e) => e.dropped === 'iron_ingot');

                // ── 复位：光标（若漏）与炉子（每轮已换新炉，天然干净）──
                if (cur.leakedCursor) {
                    // 服务端在关窗那一刻就把光标物**丢到地上**（1.16.1 vanilla 行为）⇒
                    // 上面 close 后的 groundItems 已是"丢在地上"证据，这里补一次延迟快照再复位。
                    await sleep(700);
                    cur.groundItems_afterLeak = groundItems(3);
                    cur.groundLeakEvidence = cur.groundItems_afterLeak.entities.some((e) => e.dropped === 'iron_ingot');
                    let via = 'none';
                    if (bot.currentWindow || win?.selectedItem) {
                        try { await win.clickWindow(-999, 0, 0); via = 'click_outside(-999)'; } catch { via = 'click_outside_failed'; }
                    }
                    await sleep(400);
                    if (win?.selectedItem) { try { await bot.chat('/clear @s'); via += '+clear_command'; } catch { /* 忽略 */ } }
                    cur.cursorReset = via;
                    await sleep(400);
                } else cur.cursorReset = 'no_leak';

                if ((i + 1) % 3 === 0) {
                    const rs = rounds.filter((r) => r.arm === arm);
                    say(`${arm} ${i + 1}/${N}：拿到=${rs.filter((r) => r.gained > 0).length} 失败签名=${JSON.stringify(rs.filter((r) => !(r.gained > 0)).map((r) => r.result?.reason || r.fail).reduce((a, k) => (a[k] = (a[k] ?? 0) + 1, a), {}))} cursor见产物=${rs.filter((r) => r.cursorGotProduct).length} 地上见产物=${rs.filter((r) => r.groundGotProduct).length}`);
                    flush();
                }
            } catch (e) {
                Object.assign(cur, { fail: String(e && e.message ? e.message : e).slice(0, 200) });
                try { if (win) await closeWindowConfirmed(bot, win); } catch { /* 忽略 */ }
            }
            try { if (bot.currentWindow) await closeWindowConfirmed(bot, bot.currentWindow); } catch { /* 忽略 */ }
            flush();
        }
    }
    cur = null;

    // ── 汇总 ──
    const agg = {};
    for (const r of rounds) {
        const k = r.arm;
        if (!agg[k]) agg[k] = { arm: k, n: 0, got: 0, reasons: {}, cursorGotProduct: 0, groundGotProduct: 0, srvInvDelta: 0, srvInvDeltaKnown: 0 };
        agg[k].n++;
        if (r.gained > 0) agg[k].got++;
        const sig = r.result?.reason || r.fail || (r.gained > 0 ? null : 'no_inv_delta');
        if (sig) agg[k].reasons[sig] = (agg[k].reasons[sig] ?? 0) + 1;
        if (r.cursorGotProduct) agg[k].cursorGotProduct++;
        if (r.groundGotProduct) agg[k].groundGotProduct++;
        const b = r.serverInv_before?.parseOk ? r.serverInv_before.count : null;
        const c = r.serverInv_closed?.parseOk ? r.serverInv_closed.count : null;
        if (b !== null && c !== null) { agg[k].srvInvDelta += (c - b); agg[k].srvInvDeltaKnown++; }
    }
    flush();

    // ── 报告（照抄 run_t09.mjs 的 md 落盘约定）──
    const md = [`# 熔炉取产物真值取证 — ${STAMP}`, '', `泳道 ${lane.name}｜每臂 n=${N}｜1.16.1｜背包增量窗口感知计数`, '',
        '| 臂 | n | 拿到(gained>0) | 失败签名 | cursorPackets 见产物 | 客户端地上见产物 | 服务端背包增量(前→后) |', '|---|---|---|---|---|---|---|'];
    for (const k of Object.keys(agg)) {
        const v = agg[k];
        md.push(`| ${k} | ${v.n} | **${v.got}/${v.n}** | ${JSON.stringify(v.reasons)} | ${v.cursorGotProduct} | ${v.groundGotProduct} | ${v.srvInvDelta} (${v.srvInvDeltaKnown}/${v.n} 可解析) |`);
    }
    md.push('', '> 结论读法：cursorPackets 见产物=停在光标；地上见产物=被丢下；两者都为 0 且服务端背包增量=0 ⇒ 凭空消失。',
        '', '## 口径与局限', ...NOTES.map((x) => `- ${x}`));
    const srvInvParseFail = rounds.filter((r) => r.serverInv_before && !r.serverInv_before.parseOk).length;
    if (srvInvParseFail) md.push('', `> ⚠ **服务端背包通道解析失败 ${srvInvParseFail}/${rounds.length} 次**：本脚本未臆造解析器，原文见 JSON 的 serverInv.*.raw。`);
    const srvItemParseFail = rounds.filter((r) => r.serverItemCount_after && r.serverItemCount_after.ok === false).length;
    if (srvItemParseFail) md.push('', `> ⚠ **服务端物品计数通道失败 ${srvItemParseFail}/${rounds.length} 次**，原文见 serverItemCount_after.raw。`);
    fs.writeFileSync(OUT_MD, md.join('\n') + '\n');
    fs.writeFileSync(OUT_DONE, JSON.stringify({ done: true, ok: true, json: OUT_JSON, md: OUT_MD, rounds: rounds.length }, null, 2));
    say(`墙钟 ${((Date.now() - t0) / 60000).toFixed(1)}min → ${OUT_MD}`);
    for (const k of Object.keys(agg)) say(`${k}: 拿到 ${agg[k].got}/${agg[k].n}｜cursor见产物 ${agg[k].cursorGotProduct}｜地上见产物 ${agg[k].groundGotProduct}｜服务端背包增量 ${agg[k].srvInvDelta}`);
} catch (e) {
    exitCode = 1;
    say(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 600)}`);
    try { fs.writeFileSync(OUT_DONE, JSON.stringify({ done: true, ok: false, fatal: true }, null, 2)); } catch { /* 忽略 */ }
} finally {
    try { bot?.quit?.(); } catch { /* 忽略 */ }
    await sleep(500);
    await stopServer(lane, server);
}

const cu = await cleanup({ label: `furnace-truth ${STAMP}`, rmWorlds: true, dirs: [{ dir: lane.dir, port: lane.serverPort }], laneNames: [LANE_NAMES[0]] });
fs.writeFileSync(path.join(RUNS_DIR, 'cleanup.txt'), cu.lines.join('\n') + '\n');
await lock.releaseAll?.();
process.exit(fs.existsSync(OUT_JSON) ? exitCode : 2);

