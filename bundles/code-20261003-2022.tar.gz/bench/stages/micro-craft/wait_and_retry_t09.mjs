// wait_and_retry_t09.mjs — TASK-09：等「线锁空 + 内存够」再跑；被别的线占线就**让路重试**。
//
// 为什么不直接抢：本单开工后 C 段 2026-10-02 09:07 起，G 线（S0 生存）拿着 **A 线**的线锁在跑
// BASIC-survival，而手册 §9 的分工表写的是「A 主线 = 泳道 A；G 线 = 先离线，实跑送农场 Y」。
// 手册 §9.2 明写「发现已有活锁就停下，不要接管」，§9.2 又写「只许结束自己 runner 登记过的进程」，
// 所以本脚本**只等、只重试**，不碰别人的进程、不接管别人的锁。
//
// 退出码：0=跑完；3=等到上限仍未轮到（不是失败，是没排上）。
//
// 用法：node wait_and_retry_t09.mjs --max-wait-min 90 -- <run_t09 参数…>

import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';
import os from 'os';
import fs from 'fs';
import { spawnSync } from 'child_process';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const RUN = path.join(HERE, 'run_t09.mjs');
// ⚠ 路径必须是 bench/stages/micro-craft → 上溯**三级**才是仓库根。
//   写成两级会读到 bench/experiments/…（不存在）→ 读文件失败 → 返回 busy:false
//   ⇒ 明明被别人占着却报"lane A 空"，然后被 line_lock 拒（实测踩过一次，
//   09:11:30 误判起飞、09:11:31 被 BASIC-survival 拒）。自己的测量通道也得先证伪。
const LOCK_DIR = path.resolve(HERE, '../../../experiments/mc1161-gate/.line-locks');
const argv = process.argv.slice(2);
const mi = argv.indexOf('--max-wait-min');
const MAX_WAIT_MIN = parseFloat(mi >= 0 ? argv[mi + 1] : '90');
const rest = argv.filter((v, i) => i !== mi && i !== mi + 1);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[retry ${new Date().toISOString().slice(11, 19)}] ${m}`);
const NEED = 2900;

const laneOf = (a) => { const i = a.indexOf('--lane'); return i >= 0 ? a[i + 1] : 'A'; };
const LANE = laneOf(rest);

let _alive = { at: 0, set: null };
function alivePids() {
    if (_alive.set && Date.now() - _alive.at < 2000) return _alive.set;
    const set = new Set();
    try {
        const r = spawnSync('tasklist', ['/NH', '/FO', 'CSV'], { encoding: 'utf8', maxBuffer: 16 * 1048576 });
        for (const line of String(r.stdout ?? '').split(/\r?\n/)) {
            const m = /^"[^"]*",\s*"?(\d+)"?\s*,/.exec(line.trim());
            if (m) set.add(Number(m[1]));
        }
    } catch { /* 查不到就当"查不到=不当空闲" */ }
    _alive = { at: Date.now(), set };
    return set;
}

/** 只读地问"这条泳道现在有没有**活**锁"（不申请、不接管） */
function laneBusy(lane) {
    try {
        const j = JSON.parse(fs.readFileSync(path.join(LOCK_DIR, `${lane}.json`), 'utf8'));
        const beatAge = Date.now() - Date.parse(j.at ?? 0);
        const pidAlive = alivePids().has(Number(j.pid));
        return { busy: pidAlive && beatAge < 60000, who: j.who ?? '?', age: Math.round(beatAge / 1000) };
    } catch { return { busy: false, who: null }; }
}

const t0 = Date.now();
let lastLog = 0;
for (;;) {
    const free = os.freemem() / (1024 * 1024);
    const lk = laneBusy(LANE);
    if (!lk.busy && free >= NEED) { log(`轮到本线：lane ${LANE} 空闲、free=${free.toFixed(0)}MB → 起飞`); break; }
    if (Date.now() - t0 > MAX_WAIT_MIN * 60000) {
        log(`等满 ${MAX_WAIT_MIN}min 仍未轮到（lane ${LANE} ${lk.busy ? `被 ${lk.who} 占（心跳 ${lk.age}s 前）` : '空'}、free=${free.toFixed(0)}MB）→ 放弃本轮，不抢`);
        process.exit(3);
    }
    if (Date.now() - lastLog > 90000) {
        lastLog = Date.now();
        log(`让路等待：lane ${LANE} ${lk.busy ? `被 ${lk.who} 占（心跳 ${lk.age}s 前）` : '空'}、free=${free.toFixed(0)}MB / 需 ${NEED}MB`);
    }
    await sleep(30000);
}

const child = spawn(process.execPath, [RUN, ...rest], { stdio: 'inherit' });
child.on('exit', (code) => process.exit(code ?? 0));
