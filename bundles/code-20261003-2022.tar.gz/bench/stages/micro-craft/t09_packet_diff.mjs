// t09_packet_diff.mjs — TASK-09 诊断：同一次点击，mineflayer 发的 window_click 与
// window_ops 发的 window_click，**参数差在哪**。
//
// 为什么必须这么查：服务端只给 accepted/rejected 两个 bit，光看它猜不出病因
// （我先后猜了"action 号不递增"和"Slot 形状不对"，两个都被数据否掉了）。
// 唯一能定位的办法是**把两个包都抓下来逐字段对比**，再拿服务端的 accepted 当判据。
//
// 做法：monkey-patch bot._client.write 抓所有出站 window_click；
//       同一个槽位上先跑一次 bot.craft（已知能成），再跑一次 _selfCraft（已知被拒）。
//
// 用法：node t09_packet_diff.mjs --out <dir> --port 25566 --username TaskBot

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const OUT = path.resolve(arg('out', HERE));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const SETUP = path.join(OUT, 'setup.json');
const DONE = path.join(OUT, 'done.json');
const RES = path.join(OUT, 'packet_diff.json');
for (const f of [DONE, RES]) { try { fs.rmSync(f, { force: true }); } catch { /* 忽略 */ } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[pdiff ${new Date().toISOString().slice(11, 19)}] ${m}`);

const { CraftingTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/crafting_task.js')).href);
const { clickFlavor, clickRawConfirmed, windowClickPacket } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/window_ops.js')).href);

const Item = require('prismarine-item');

async function main() {
    const mineflayer = require('mineflayer');
    const { Vec3 } = require('vec3');
    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: '1.16.1' });
    bot.loadPlugin(require('mineflayer-pathfinder').pathfinder);
    await new Promise((resolve, reject) => {
        bot.once('spawn', resolve); bot.once('error', reject); setTimeout(() => reject(new Error('spawn timeout')), 60000);
    });
    log(`spawned｜协议 ${bot.version}｜${JSON.stringify(clickFlavor(bot))}`);
    await sleep(3500);
    for (let i = 0; i < 120 && !fs.existsSync(SETUP); i++) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('no setup.json');

    // 抓所有出站 window_click + 入站 transaction
    const sent = [];
    const txs = [];
    const origWrite = bot._client.write.bind(bot._client);
    bot._client.write = (name, params) => {
        if (name === 'window_click') sent.push({ at: Date.now(), params: JSON.parse(JSON.stringify(params, (k, v) => (typeof v === 'object' && v !== null && v.type !== undefined ? { __Item: true, type: v.type, count: v.count, name: v.name } : v))) });
        return origWrite(name, params);
    };
    bot._client.on('transaction', (p) => txs.push({ at: Date.now(), action: p.action, accepted: p.accepted, windowId: p.windowId }));

    const tele = [];
    const ctx = { bot, telemetry: (n, d) => tele.push({ n, d, t: Date.now() }), run: { counters: {} } };
    const count = (n) => bot.inventory.items().filter((i) => i.name === n).reduce((s, i) => s + i.count, 0);

    const SX = 200, SY = 68, SZ = 200;
    await bot.chat(`/tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`); await sleep(2500);
    await bot.chat(`/fill ${SX - 4} ${SY} ${SZ - 4} ${SX + 4} ${SY} ${SZ + 4} minecraft:stone`); await sleep(1000);
    await bot.chat(`/fill ${SX - 4} ${SY + 1} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:air`); await sleep(1000);
    await bot.chat(`/setblock ${SX + 1} ${SY + 1} ${SZ} minecraft:crafting_table`); await sleep(800);
    await bot.chat(`/tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`); await sleep(2000);
    const table = bot.blockAt(new Vec3(SX + 1, SY + 1, SZ));
    if (table?.name !== 'crafting_table') throw new Error(`布景硬闸门未过 table=${table?.name}`);

    const kit = async () => {
        await bot.chat('/clear @s'); await sleep(250);
        await bot.chat('/give @s minecraft:oak_planks 16'); await bot.chat('/give @s minecraft:stick 16');
        const dl = Date.now() + 10000;
        while (Date.now() < dl) { if (count('oak_planks') >= 16 && count('stick') >= 16) return true; await sleep(200); }
        return false;
    };
    const task = new CraftingTask({ item: 'stick', count: 1, craftChannel: 'self' });

    // ── 臂 A：mineflayer 自己的 bot.craft（已知能成）──
    await kit();
    const itemId = bot.registry.itemsByName.stick.id;
    const recipes = bot.recipesFor(itemId, null, 1, table);
    const recipe = recipes[0];
    sent.length = 0; txs.length = 0;
    const beforeA = count('stick');
    await bot.craft(recipe, 1, table);
    await sleep(800);
    const armA = {
        label: 'mineflayer bot.craft (已知能成)',
        gained: count('stick') - beforeA,
        packets: sent.slice(),
        txs: txs.slice(),
        tele: tele.slice(),
    };
    tele.length = 0;
    try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow); } catch { /* 忽略 */ }
    await sleep(400);

    // ── 臂 B：window_ops 自己的 clickRawConfirmed（已知被拒）──
    await kit();
    sent.length = 0; txs.length = 0;
    const beforeB = count('stick');
    const w = await task._openCraftingWindow(bot, table);
    const bClicks = [];
    if (w) {
        const src = w.slots.findIndex((s, i) => s && s.name === 'oak_planks' && i >= w.inventoryStart);
        log(`窗口 #${w.id} 源槽 slot=${src} 真实内容=${w.slots[src] ? `${w.slots[src].name}x${w.slots[src].count}` : 'null'}`);
        const r = await clickRawConfirmed(bot, w, { slot: src, mouseButton: 0, mode: 0, timeoutMs: 1500 });
        bClicks.push({ step: 'pickup_planks', verdict: r });
    }
    const armB = {
        label: 'window_ops clickRawConfirmed (已知被拒)',
        gained: count('stick') - beforeB,
        packets: sent.slice(),
        txs: txs.slice(),
        tele: tele.slice(),
    };

    // ── 关键对照：把两边"第一次点击"的包并排 ──
    const pa = armA.packets[0]?.params ?? null;
    const pb = armB.packets[0]?.params ?? null;
    const diff = {};
    if (pa && pb) {
        const keys = [...new Set([...Object.keys(pa), ...Object.keys(pb)])];
        for (const k of keys) {
            const va = JSON.stringify(pa[k]); const vbv = JSON.stringify(pb[k]);
            if (va !== vbv) diff[k] = { mineflayer: va ?? '(undefined)', windowOps: vbv ?? '(undefined)' };
        }
    }
    // 顺手把"如果按 window_ops 的 item 直接编码"和"按 toNotch 编码"各编一次，看差别
    let encDirect = null, encToNotch = null;
    try {
        const { createSerializer } = require('minecraft-protocol');
        const s = createSerializer({ state: 'play', isServer: false, version: bot.version });
        const raw = w?.slots?.find((x) => x && x.name === 'oak_planks');
        const base = pb ? { ...pb } : { windowId: w?.id, slot: 0, mouseButton: 0, action: 1, mode: 0 };
        encDirect = s.createPacketBuffer({ name: 'window_click', params: { ...base, item: raw ?? null } }).toString('hex');
        encToNotch = s.createPacketBuffer({ name: 'window_click', params: { ...base, item: Item(bot.registry).toNotch(raw ?? null) } }).toString('hex');
    } catch (e) { encDirect = 'ERR ' + e.message; encToNotch = 'ERR ' + e.message; }

    const out = {
        armA, armB, diff,
        encode: {
            note: 'window_ops 传的是 prismarine Item；toNotch 才产出协议的 {present,itemId,itemCount}',
            itemDirect: encDirect, itemToNotch: encToNotch,
            differ: encDirect !== encToNotch,
        },
    };
    fs.writeFileSync(RES, JSON.stringify(out, null, 2));
    fs.writeFileSync(DONE, JSON.stringify({ done: true }));
    log('=== 臂 A（mineflayer，能成）第一次点击包 ===');
    log(JSON.stringify(armA.packets[0]?.params));
    log('=== 臂 B（window_ops，被拒）第一次点击包 ===');
    log(JSON.stringify(armB.packets[0]?.params));
    log(`=== 参数差异 === ${JSON.stringify(diff)}`);
    log(`=== 编码差异（direct vs toNotch） === differ=${out.encode.differ}\n  direct=${encDirect}\n  toNotch=${encToNotch}`);
    log(`=== 判决 === A tx=${JSON.stringify(armA.txs.slice(0, 3))} B tx=${JSON.stringify(armB.txs.slice(0, 3))}`);
    bot.quit();
    process.exit(0);
}
main().catch((e) => { log(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 500)}`); try { fs.writeFileSync(DONE, JSON.stringify({ done: true, fatal: true })); } catch { /* 忽略 */ } process.exit(1); });
