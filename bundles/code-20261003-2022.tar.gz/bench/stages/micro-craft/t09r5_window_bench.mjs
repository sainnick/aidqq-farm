﻿// t09r5_window_bench.mjs — MC-M1-TASK-09-r5：窗口原语的微基准（2×2 合成 + 熔炉装料/取件）
//
// 为什么不用现成的 craft_bot.mjs：它逐字照抄的是**旧**路径 `bot.craft(recipe, 1, tableBlock)`，
// 而 r4 起 2×2 已经改走自研 `craftInGridConfirmed`、熔炉走 `quickMoveInto/OutOfFurnace`
// ⇒ 拿旧基准测新代码，等于没测（手册 §5「比较要同口径」）。
//
// 两条链**解耦**（派单要求）：2×2 坏掉时熔炉段照样出数据，不再被"到不了熔炉"挡住。
//   段 A：2×2 背包合成 —— oak_planks×4 ⇒ stick×4（1.16.1 配方是 "#"/"#" = 2×1）
//   段 B：熔炉 —— 装料(iron_ore→输入格) + 加燃料(coal→燃料格) + 熔炼 + 取件(iron_ingot)
//
// 判据全部是**服务端真值**：产物/产物进背包靠背包增量，装料靠服务端 0/1 两格内容。
//
// 用法（由 run_t09r5_bench.mjs 调起）：
//   node t09r5_window_bench.mjs --out <dir> --port 25566 --username TaskBot --n 30

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const OUT = path.resolve(arg('out', HERE));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const N = parseInt(arg('n', '30'), 10);
const SETUP = path.join(OUT, 'setup.json');
const RES = path.join(OUT, 'r5_bench_result.json');
const DONE = path.join(OUT, 'done.json');
for (const f of [RES, DONE]) { try { fs.rmSync(f, { force: true }); } catch { /* 忽略 */ } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[r5bench ${new Date().toISOString().slice(11, 19)}] ${m}`);

const SX = 200, SY = 68, SZ = 200;   // 与 craft_bot.mjs 同一块平台（场景只有一个真源）

async function main() {
    const mineflayer = require('mineflayer');
    const { Vec3 } = require('vec3');
    const {
        craftInGridConfirmed, quickMoveIntoFurnace, quickMoveOutOfFurnace,
        closeWindowConfirmed, playerInvRange, countItemsInRange,
    } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/window_ops.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: '1.16.1' });
    bot.loadPlugin(require('mineflayer-pathfinder').pathfinder);
    await new Promise((resolve, reject) => {
        bot.once('spawn', resolve); bot.once('error', reject); setTimeout(() => reject(new Error('spawn timeout')), 60000);
    });
    log(`spawned ${bot.entity.position.toArray().map((v) => v.toFixed(0))}`);
    await sleep(3500);
    for (let i = 0; i < 120 && !fs.existsSync(SETUP); i++) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('no setup.json（runner 没 op）');

    let seq = 0; let msgQueue = [];
    bot.on('message', (m) => { try { msgQueue.push(String(m.toString ? m.toString() : m)); } catch { msgQueue.push('?'); } });
    async function cmd(text, { waitMs = 700 } = {}) {
        const id = `@@C${++seq}`;
        msgQueue = [];
        bot.chat(`/say ${id}`);
        const t0 = Date.now();
        while (Date.now() - t0 < 3000 && !msgQueue.some((s) => s.includes(id))) await sleep(25);
        msgQueue = [];
        bot.chat(`/${text}`);
        const tw = Date.now();
        while (Date.now() - tw < waitMs && !msgQueue.length) await sleep(25);
        await sleep(40);
        const r = msgQueue.join(' | '); msgQueue = []; return r;
    }
    const count = (name) => bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0);
    const wipe = async (names) => { for (const j of names) await cmd(`clear @s minecraft:${j}`, { waitMs: 110 }); };

    // ── 布景：平台 + 一个熔炉（坐标只在本文件，任务层拿不到）──
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(2000);
    await cmd(`fill ${SX - 4} ${SY} ${SZ - 4} ${SX + 4} ${SY} ${SX + 4} minecraft:stone`, { waitMs: 900 });
    await cmd(`fill ${SX - 4} ${SY + 1} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:air`, { waitMs: 900 });
    await cmd(`setblock ${SX - 1} ${SY + 1} ${SZ} minecraft:furnace`, { waitMs: 700 });
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(1500);
    const furnaceBlock = bot.blockAt(new Vec3(SX - 1, SY + 1, SZ));
    // ★ 硬闸门：布景没建起来就别开测（手册 §5：失败耗时异常短时先查测试框架）
    if (furnaceBlock?.name !== 'furnace') throw new Error(`布景失败：${furnaceBlock?.name} @${SX - 1},${SY + 1},${SZ}`);
    log(`熔炉就位 ${furnaceBlock.name} @${SX - 1},${SY + 1},${SZ}`);

    const rows = { craft: [], furnaceLoad: [], furnaceTake: [] };

    // ══ 段 A：2×2 背包合成（window 0，craftInGridConfirmed）══
    // ⚠ kit 口径：真实整局里 2×2 合成发生在**地表/浅层**（开局就有原木），
    //   这里在 y=69 的平台上，深度与真实链同量级（真实链木板合成在 y≈68–70）。
    // ⚠⚠ 摆料方向：本单第一版把两个木板**横着**摆（(0,0),(1,0)），服务端给出的是
    //   **oak_pressure_plate**（2 木板一行 = 压力板）—— 1.16.1 的木棍配方是
    //   **竖着的 1×2**，横着摆压根不匹配。
    //   （生产侧不受影响：`crafting_task._gridCells` 是**按配方 inShape 摊平**的。）
    {
        const PL = bot.registry.itemsByName.oak_planks.id;
        for (let i = 0; i < N; i++) {
            await wipe(['oak_planks', 'stick', 'oak_log', 'oak_pressure_plate']);
            await cmd(`give @s minecraft:oak_planks 4`, { waitMs: 220 });
            await sleep(320);
            const before = count('stick');
            const t0 = Date.now();
            let r = null, err = null;
            try {
                r = await craftInGridConfirmed(bot, bot.inventory, {
                    cells: [{ x: 0, y: 0, id: PL }, { x: 0, y: 1, id: PL }],   // 竖着 = 1.16.1 木棍配方
                    gridW: 2, gridH: 2, resultSlot: 0, expectName: 'stick', timeoutMs: 1500,
                });
            } catch (e) { err = String(e && e.message ? e.message : e).slice(0, 200); }
            const ms = Date.now() - t0;
            let gained = count('stick') - before;
            const dl = Date.now() + 2000;
            while (gained <= 0 && Date.now() < dl) { await sleep(120); gained = count('stick') - before; }
            rows.craft.push({
                i, ms, gained, verified: r?.ok === true && gained > 0,
                reason: r?.reason ?? null, err,
                took: r?.took ?? null, cursorSource: r?.cursorSource ?? null,
                cursorMismatches: r?.cursorMismatches ?? null,
                // 失败时把 verdict 全量留档（服务端回执 + 我们上报了什么）——排障第一手
                verdict: r?.ok ? null : r,
                inv: `oak_planks=${count('oak_planks')},stick=${count('stick')}`,
            });
            if (!r?.ok) {
                // 每次失败都打一行（否则要等 30 次跑完才看得到 reason，等于没有诊断）
                log(`  A#${i} FAIL reason=${r?.reason} err=${err ?? '-'} verdict=${JSON.stringify(r?.verdict ?? null)} model[0..4]=${Array.from({ length: 5 }, (_, k) => { const s = bot.inventory.slots[k]; return `${k}:${s ? s.name + 'x' + s.count : '-'}`; }).join(' ')}`);
            }
            if ((i + 1) % 10 === 0) {
                const k = rows.craft;
                log(`A 2×2 ${i + 1}/${N}：ok=${k.filter((r) => r.verified).length} 失败=${k.filter((r) => !r.verified).length}`);
            }
        }
    }

    // ══ 段 B：熔炉 装料 / 加燃料 / 取件（kit 起步，与段 A 解耦）══
    // ⚠ kit 口径（手册 §4.2）：这里**不复现**真实链"熔炉在 y13–18 的地下竖井旁"，
    //   只测窗口原语本身（装料/取件不依赖深度）。这条 caveat 写进报告，不当"整局等价"。
    for (let i = 0; i < N; i++) {
        await wipe(['iron_ore', 'coal', 'iron_ingot']);
        await cmd(`give @s minecraft:iron_ore 3`, { waitMs: 220 });
        await cmd(`give @s minecraft:coal 3`, { waitMs: 220 });
        await sleep(350);
        // 打开熔炉窗：先**真的**转朝向再点（手册 §3：activateBlock 内部要靠服务端看到新朝向）
        let openErr = null;
        try {
            const eye = furnaceBlock.position.offset(0.5, 0.5, 0.5);
            await bot.lookAt(eye, false);          // force=false ⇒ 真的发旋转包
            await sleep(300);
            await bot.activateBlock(furnaceBlock);
            // 等窗口真的开出来（mineflayer 可能在下一 tick 才设 bot.furnace）
            const dl = Date.now() + 4000;
            while (!bot.furnace && Date.now() < dl) await sleep(100);
        } catch (e) { openErr = String(e && e.message ? e.message : e).slice(0, 160); }
        await sleep(300);
        const fw = bot.currentWindow;
        // ⚠⚠ **不要用 `bot.furnace`**：1.16.1 上服务端发的 open_window 类型号与
        //   prismarine-windows 自己那套编号对不上（本项目 r4 已定位）⇒ mineflayer 不认得
        //   窗口类型 ⇒ **`bot.furnace` 恒为 null**，可窗口**确实开出来了**
        //   （本 run 实测 `curWindowId=1, hasFurnace=false, dist=1.58`）。
        //   ⇒ 直接用 `bot.currentWindow`（它就是那扇真窗口，槽位/区间都对）。
        //   ⚠ 同一条缺陷会打到生产：`smelt_task.js:306` 的 `bot.openFurnace()` 返回 `bot.furnace`
        //   ⇒ 熔炼链在 1.16.1 上有拿不到窗口的风险（见报告 §7）。
        const furnaceWin = bot.furnace ?? (fw && fw.id != null ? fw : null);
        if (!furnaceWin) {
            // 响亮失败：把"为什么没开出来"记下来，别让它退化成 30 条 no_furnace_window
            rows.furnaceLoad.push({
                i, verified: false, reason: 'no_furnace_window', openErr,
                curWindowId: bot.currentWindow?.id ?? null, hasFurnace: !!bot.furnace,
                pos: bot.entity.position.toArray().map((v) => +v.toFixed(1)),
                dist: +bot.entity.position.distanceTo(furnaceBlock.position).toFixed(2),
            });
            rows.furnaceTake.push({ i, verified: false, reason: 'no_furnace_window', openErr });
            try { await closeWindowConfirmed(bot, bot.currentWindow); } catch { /* 忽略 */ }
            continue;
        }

        // B1 装料：矿石 → 输入格(0)
        const t1 = Date.now();
        const load = await quickMoveIntoFurnace(bot, furnaceWin, { itemName: 'iron_ore', target: 'input', timeoutMs: 2500 });
        const loadMs = Date.now() - t1;
        rows.furnaceLoad.push({
            i, verified: load?.ok === true, ms: loadMs,
            reason: load?.reason ?? null, moved: load?.moved ?? null, dest: load?.dest ?? null,
            slotCount: load?.slotCount ?? null, range: load?.range ? load.range.join('-') : null,
            verdict: load?.verdict ?? null,
        });

        // B2 加燃料：煤 → 燃料格(1)
        const fuel = load?.ok ? await quickMoveIntoFurnace(bot, furnaceWin, { itemName: 'coal', target: 'fuel', timeoutMs: 2500 }) : { ok: false, reason: 'skipped(load failed)' };
        rows.furnaceLoad[i].fuelOk = fuel?.ok === true;
        rows.furnaceLoad[i].fuelReason = fuel?.reason ?? null;

        // B3 取件：等熔炼出铁锭（1.16.1 铁锭 10s/个）后 shift 点输出格(2)
        const t3 = Date.now();
        let take = null, tookMs = 0, waited = 0;
        if (fuel?.ok) {
            const beforeIngot = count('iron_ingot');
            // 等输出格(2)出现铁锭：有界轮询，**上限 45s**（3 个矿 = 10s 熔 1 个 + 燃料时间）
            const dl = Date.now() + 45000;
            while (Date.now() < dl) {
                if (fw.slots[2] && fw.slots[2].name === 'iron_ingot') break;
                await sleep(400); waited += 400;
            }
            take = await quickMoveOutOfFurnace(bot, furnaceWin, { slot: 2, expectName: 'iron_ingot', timeoutMs: 2500 });
            tookMs = Date.now() - t3;
            const gainedIngot = count('iron_ingot') - beforeIngot;
            rows.furnaceTake.push({
                i, verified: take?.ok === true && gainedIngot > 0, ms: tookMs, waitedMs: waited,
                reason: take?.reason ?? null, gained: gainedIngot, took: take?.took ?? null,
                verdict: take?.verdict ?? null,
            });
        } else {
            rows.furnaceTake.push({ i, verified: false, reason: fuel?.reason ?? 'fuel_failed', waitedMs: 0 });
        }
        try { await closeWindowConfirmed(bot, bot.currentWindow); } catch { /* 忽略 */ }
        await sleep(200);
        if ((i + 1) % 5 === 0) {
            const L = rows.furnaceLoad, T = rows.furnaceTake;
            log(`B 熔炉 ${i + 1}/${N}：装料 ok=${L.filter((r) => r.verified).length}/${L.length} 取件 ok=${T.filter((r) => r.verified).length}/${T.length}`);
        }
    }

    // ── 汇总（逐段分开，不混账）──
    const agg = (rs) => {
        const n = rs.length;
        const okc = rs.filter((r) => r.verified).length;
        const reasons = {};
        for (const r of rs) if (!r.verified) reasons[r.reason ?? r.err ?? 'unknown'] = (reasons[r.reason ?? r.err ?? 'unknown'] ?? 0) + 1;
        const ms = rs.map((r) => r.ms).filter((v) => typeof v === 'number').sort((a, b) => a - b);
        return {
            n, ok: okc, rate: n ? +((okc / n) * 100).toFixed(1) : 0,
            medianMs: ms.length ? ms[Math.floor((ms.length - 1) / 2)] : null,
            failReasons: reasons,
        };
    };
    const result = {
        stamp: STAMP(), n: N,
        segments: {
            craft2x2: agg(rows.craft),
            furnaceLoad: agg(rows.furnaceLoad),
            furnaceTake: agg(rows.furnaceTake),
        },
        rows,
        caveats: [
            'kit 起步：只测窗口原语；段 B 的熔炉在 y=69 平台，**不复现**真实链 y13–18 地下竖井旁的深度',
            '段 A 的 2×2 合成在 y=69，与真实链木板合成同量级',
        ],
    };
    fs.writeFileSync(RES, JSON.stringify(result, null, 2));
    fs.writeFileSync(DONE, JSON.stringify({ done: true }));
    log('=== 汇总 ===');
    for (const [k, v] of Object.entries(result.segments)) {
        log(`${k}: ${v.ok}/${v.n} = ${v.rate}%  中位 ${v.medianMs}ms  失败原因 ${JSON.stringify(v.failReasons)}`);
    }
    bot.quit();
    process.exit(0);
}
const STAMP = () => path.basename(OUT);
main().catch((e) => { log(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 600)}`); try { fs.writeFileSync(DONE, JSON.stringify({ done: true, fatal: true })); } catch { /* 忽略 */ } process.exit(1); });
