// t09r5_debug_craft.mjs — MC-M1-TASK-09-r5：**一次** 2×2 合成，逐点击抓包诊断。
//
// 回答的问题：2×2 的失败到底卡在**哪一击**、我们上报的 `item` 是什么、服务端回什么。
// 做法：在 `bot._client` 上挂原始包监听（send window_click / recv transaction / recv window_items），
// 每次点击前后把"被点格的模型内容"打出来 ⇒ 能直接看出是预测错了还是模型没落定。
//
// 用法：node t09r5_debug_craft.mjs --out <dir> --port 25566 --username TaskBot

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const OUT = path.resolve(arg('out', HERE));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const SETUP = path.join(OUT, 'setup.json');
const DONE = path.join(OUT, 'done_debug.json');
try { fs.rmSync(DONE, { force: true }); } catch { /* 忽略 */ }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[dbg ${new Date().toISOString().slice(11, 19)}] ${m}`);

const SX = 200, SY = 68, SZ = 200;
const sig = (s) => (s ? `${s.name}x${s.count}` : '-');
const wire = (p) => (p && p.present ? `${p.itemId}:${p.itemCount}` : 'EMPTY');

async function main() {
    const mineflayer = require('mineflayer');
    const { Vec3 } = require('vec3');
    const { craftInGridConfirmed } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/window_ops.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: '1.16.1' });
    bot.loadPlugin(require('mineflayer-pathfinder').pathfinder);
    await new Promise((resolve, reject) => {
        bot.once('spawn', resolve); bot.once('error', reject); setTimeout(() => reject(new Error('spawn timeout')), 60000);
    });
    log(`spawned ${bot.entity.position.toArray().map((v) => v.toFixed(0))}`);
    await sleep(3000);
    for (let i = 0; i < 120 && !fs.existsSync(SETUP); i++) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('no setup.json');

    let seq = 0; let msgQueue = [];
    bot.on('message', (m) => { try { msgQueue.push(String(m.toString ? m.toString() : m)); } catch { msgQueue.push('?'); } });
    async function cmd(text, { waitMs = 700 } = {}) {
        const id = `@@C${++seq}`; msgQueue = [];
        bot.chat(`/say ${id}`);
        const t0 = Date.now();
        while (Date.now() - t0 < 3000 && !msgQueue.some((s) => s.includes(id))) await sleep(25);
        msgQueue = [];
        bot.chat(`/${text}`);
        const tw = Date.now();
        while (Date.now() - tw < waitMs && !msgQueue.length) await sleep(25);
        await sleep(40);
        const r = msgQueue.join(' | '); msgQueue = []; return r;
    }

    // ── 抓包：原始包层，不经 mineflayer 的窗口模型 ──
    const trace = [];
    const origWrite = bot._client.write.bind(bot._client);
    bot._client.write = (name, params) => {
        if (name === 'window_click') {
            trace.push({ dir: 'S', name, slot: params.slot, btn: params.mouseButton, mode: params.mode, action: params.action, item: wire(params.item), t: Date.now() });
        } else if (name === 'transaction') {
            trace.push({ dir: 'S', name, windowId: params.windowId, action: params.action, accepted: params.accepted, t: Date.now() });
        }
        return origWrite(name, params);
    };
    bot._client.on('transaction', (p) => trace.push({ dir: 'R', name: 'transaction', windowId: p.windowId, action: p.action, accepted: p.accepted, t: Date.now() }));
    bot._client.on('window_items', (p) => {
        if (p.windowId === 0) trace.push({ dir: 'R', name: 'window_items', n: p.items.length, t: Date.now() });
    });
    // ★ 逐格 set_slot 也记：accepted 路径上服务端到底发不发槽位更新，就看这一条
    bot._client.on('set_slot', (p) => {
        if (p.windowId !== 0) return;
        trace.push({ dir: 'R', name: 'set_slot', slot: p.slot, item: wire(p.item), t: Date.now() });
    });

    // 布景 + kit
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(2000);
    await cmd(`fill ${SX - 4} ${SY} ${SZ - 4} ${SX + 4} ${SY} ${SX + 4} minecraft:stone`, { waitMs: 900 });
    await cmd(`fill ${SX - 4} ${SY + 1} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:air`, { waitMs: 900 });
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(1500);
    for (const j of ['oak_planks', 'stick', 'oak_log']) await cmd(`clear @s minecraft:${j}`, { waitMs: 150 });
    await cmd(`give @s minecraft:oak_planks 4`, { waitMs: 300 });
    await sleep(800);

    const win = bot.inventory;
    log(`窗口 id=${win.id} slots=${win.slots.length}｜kit 后 9..45: ${Array.from({ length: 36 }, (_, i) => sig(win.slots[9 + i])).filter((s) => s !== '-').join(',') || '(全空)'}`);

    // 先记一份"点击前的模型"基线
    const baseline = Array.from({ length: 46 }, (_, i) => sig(win.slots[i]));

    const PL = bot.registry.itemsByName.oak_planks.id;
    trace.length = 0;
    const r = await craftInGridConfirmed(bot, win, {
        // 竖着摆：1.16.1 木棍配方是 1×2（横着摆会被判成压力板）
        cells: [{ x: 0, y: 0, id: PL }, { x: 0, y: 1, id: PL }],
        gridW: 2, gridH: 2, resultSlot: 0, expectName: 'stick', timeoutMs: 1500,
    });

    log('── 逐条抓包 ──');
    const t0 = trace.length ? trace[0].t : 0;
    for (const e of trace) {
        const dt = e.t - t0;
        if (e.name === 'window_click') {
            log(`  +${String(dt).padStart(5)}ms S window_click  slot=${e.slot} btn=${e.btn} mode=${e.mode} action=${e.action} item=${e.item}`);
        } else if (e.name === 'transaction' && e.dir === 'R') {
            log(`  +${String(dt).padStart(5)}ms R transaction  win=${e.windowId} action=${e.action} accepted=${e.accepted}`);
        } else if (e.name === 'transaction') {
            log(`  +${String(dt).padStart(5)}ms S transaction  win=${e.windowId} action=${e.action} accepted=${e.accepted}  ← 道歉`);
        } else if (e.name === 'window_items') {
            log(`  +${String(dt).padStart(5)}ms R window_items n=${e.n}`);
        } else if (e.name === 'set_slot') {
            log(`  +${String(dt).padStart(5)}ms R set_slot slot=${e.slot} item=${e.item}`);
        }
    }
    log(`── 结果 ── ${JSON.stringify(r)}`);
    log('── 窗口模型 0..8（结果格/网格/护甲）──');
    log('  ' + Array.from({ length: 9 }, (_, i) => `${i}:${sig(win.slots[i])}`).join(' '));
    log('── 窗口模型 9..45 非空 ──');
    log('  ' + Array.from({ length: 36 }, (_, i) => { const s = win.slots[9 + i]; return s ? `${9 + i}:${sig(s)}` : null; }).filter(Boolean).join(' ') || '(全空)');
    log('── 与点击前基线不同的格 ──');
    const diff = [];
    for (let i = 0; i < 46; i++) if (baseline[i] !== sig(win.slots[i])) diff.push(`${i}: ${baseline[i]} → ${sig(win.slots[i])}`);
    log('  ' + (diff.join(' | ') || '(无变化)'));
    log(`── bot.inventory.items(): ${bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(', ') || '(空)'}`);

    fs.writeFileSync(DONE, JSON.stringify({ ok: r?.ok, reason: r?.reason, trace, r }, null, 2));
    bot.quit();
    process.exit(0);
}
main().catch((e) => { log(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 600)}`); try { fs.writeFileSync(DONE, JSON.stringify({ fatal: String(e) })); } catch { /* 忽略 */ } process.exit(1); });
