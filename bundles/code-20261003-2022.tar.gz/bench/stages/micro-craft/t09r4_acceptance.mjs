// t09r4_acceptance.mjs — MC-M1-TASK-09-r4 验收统计（纯离线，不开服不占端口）
//
// 与 r3 的 t09r3_acceptance.mjs 同源，但**按 r4 的验收线**重算，并统计 r4 新增的遥测。
// 两层验收分开算（手册 §5「归因必须引用遥测」）：
//
//   ① **窗口操作层**（本单真正要修的东西）
//      归零线：smelt_take_unverified / craft_error / craft_fail
//      新增观测：smelt_load_ok / smelt_load_fail / smelt_load_error（r4 新事件，带结构化
//                reason + slotCount/playerRange/winType 自证字段）
//                smelt_ok —— **全 bench 历史上第一次可能出现**（r3 子 agent 普查：0 次）
//                craft_replan.cause —— r4 新字段，用来验"replan 只因物资"这条验收线
//                craft_ok.viaTable / grid —— r4 新字段，用来分清 2x2 / 3x3
//
//   ② **整局层 / 导航层 / 死亡层**（分开记，不混进窗口层的账）
//      outcome、durationMs、deaths、phase.nav、idleMs、nav_fail、NO_PROGRESS/TIMEOUT
//
// 口径纪律（手册 §5，本脚本内置）：
//   · **「没读到」与「读到 0」分开**：telemetry.jsonl 缺失/解析失败 ⇒ 记 TELEMETRY_MISSING，
//     **不**当成 0 事件（否则会把"遥测自己坏了"读成"全绿"）。
//   · 每个事件计数都附带"该事件名在本语料里是否出现过"，便于分辨
//     「原语从未触发」与「原语触发了但没记账」——这两者的处置完全不同。
//   · `craft_replan` 的 `cause` 缺失（旧数据）单独计数，不并进任何一个 cause。
//
// 用法：
//   node t09r4_acceptance.mjs --runs <runDir1,runDir2> [--json out.json]
//   node t09r4_acceptance.mjs --runs ... --expect-total 5 --expect-success 5
//   node t09r4_acceptance.mjs --runs ... --compare <r3RunDir>   # 与 r3 同口径对比

import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const argOf = (n, d) => { const i = argv.indexOf(`--${n}`); return i >= 0 ? argv[i + 1] : d; };
const RUNS = (argOf('runs', '') || '').split(',').map((s) => s.trim()).filter(Boolean);
const COMPARE = argOf('compare', '');
const JSON_OUT = argOf('json', '');
const EXPECT_TOTAL = parseInt(argOf('expect-total', '0'), 10);
const EXPECT_SUCCESS = parseInt(argOf('expect-success', '0'), 10);

if (!RUNS.length) {
    console.error('用法：node t09r4_acceptance.mjs --runs <runDir,...> [--json out.json] [--compare <r3RunDir>]');
    process.exit(2);
}

// ── 窗口层「必须归零」的事件（验收线）──
const ZERO_LINE = ['smelt_take_unverified', 'craft_error', 'craft_fail'];
// ── 窗口层观测事件（不要求归零，但要看分布）──
const OBSERVE = [
    'smelt_start', 'smelt_ok', 'smelt_load_ok', 'smelt_load_fail', 'smelt_load_error',
    'smelt_fuel_in', 'smelt_refuel', 'smelt_unload_fail', 'smelt_unload_error',
    'smelt_take_checked', 'furnace_open_fail',
    'craft_ok', 'craft_no_gain', 'craft_needs_table', 'craft_unverified', 'craft_replan',
    'table_craft_take_fail', 'self_craft_take_fail', 'craft_error',
];
// ── 整局/导航层事件（与窗口层分开记）──
const RUN_LEVEL = ['nav_fail', 'soft_stuck', 'place_fail', 'wander', 'relocate', 'hard_stuck'];

function readTrials(runDir) {
    if (!fs.existsSync(runDir)) return { runDir, missing: true, trials: [] };
    const dirs = fs.readdirSync(runDir, { withFileTypes: true })
        .filter((e) => e.isDirectory() && /^trial_/.test(e.name))
        .map((e) => e.name).sort();
    const trials = dirs.map((name) => {
        const d = path.join(runDir, name);
        const tele = path.join(d, 'telemetry.jsonl');
        const res = path.join(d, 'result.json');
        const out = { name, events: [], telemetryOk: false, telemetryNote: null, result: null };
        if (fs.existsSync(tele)) {
            try {
                out.events = fs.readFileSync(tele, 'utf8').split(/\r?\n/)
                    .filter((l) => l.trim())
                    .map((l) => { try { return JSON.parse(l); } catch { return { __bad: true, raw: l.slice(0, 120) }; } });
                out.telemetryOk = true;
                const bad = out.events.filter((e) => e.__bad).length;
                if (bad) out.telemetryNote = `${bad} 行解析失败`;
            } catch (e) { out.telemetryNote = `读失败：${e.message}`; }
        } else {
            out.telemetryNote = 'TELEMETRY_MISSING（telemetry.jsonl 不存在）';
        }
        if (fs.existsSync(res)) { try { out.result = JSON.parse(fs.readFileSync(res, 'utf8')); } catch (e) { out.resultNote = e.message; } }
        return out;
    });
    return { runDir, missing: false, trials };
}

function tally(trial) {
    const c = {};
    for (const e of trial.events) { const n = e.event; if (!n) continue; c[n] = (c[n] || 0) + 1; }
    return c;
}

function analyse(runDir) {
    const r = readTrials(runDir);
    if (r.missing) return { runDir, missing: true };
    const rows = r.trials.map((t) => {
        const c = tally(t);
        const res = t.result ?? {};
        const m = res.metrics ?? {};
        // craft_replan 的 cause 分布（r4 新字段）
        const causes = {};
        const replans = t.events.filter((e) => e.event === 'craft_replan');
        for (const e of replans) {
            const k = e.cause ?? (e.__noCause ? 'no' : 'MISSING(旧口径/未记录)');
            causes[k] = (causes[k] || 0) + 1;
        }
        // craft_ok 的 2x2 / 3x3 分布（r4 新字段）
        const oks = t.events.filter((e) => e.event === 'craft_ok');
        const gridDist = { '2x2': 0, '3x3': 0, 'MISSING(旧口径/未记录)': 0 };
        for (const e of oks) {
            if (e.viaTable === false) gridDist['2x2']++;
            else if (e.viaTable === true) gridDist['3x3']++;
            else gridDist['MISSING(旧口径/未记录)']++;
        }
        // 窗口层装料失败的结构化 reason
        const loadReasons = {};
        for (const e of t.events) {
            if (e.event === 'smelt_load_fail' || e.event === 'smelt_load_error') {
                const k = e.reason ?? e.error ?? 'UNKNOWN';
                loadReasons[k] = (loadReasons[k] || 0) + 1;
            }
        }
        return {
            trial: t.name,
            telemetryOk: t.telemetryOk,
            telemetryNote: t.telemetryNote,
            events: c,
            zeroLine: Object.fromEntries(ZERO_LINE.map((k) => [k, c[k] ?? 0])),
            observe: Object.fromEntries(OBSERVE.map((k) => [k, c[k] ?? 0])),
            runLevel: Object.fromEntries(RUN_LEVEL.map((k) => [k, c[k] ?? 0])),
            replans: replans.length,
            causes,
            gridDist,
            loadReasons,
            outcome: res.status ?? null,
            failReason: res.failReason ?? null,
            durationMs: res.durationMs ?? m.durationMs ?? null,
            deaths: m.deaths ?? null,
            smeltOk: m.smeltOk ?? null,
            craftFailures: m.craftFailures ?? null,
            craftAttempts: m.craftAttempts ?? null,
            phase: m.phaseMs ?? m.phases ?? null,
            idleMs: m.idleMs ?? null,
            fullInventory: res.fullInventory ?? null,
        };
    });
    return { runDir, missing: false, rows, meta: (() => { try { return JSON.parse(fs.readFileSync(path.join(runDir, 'run_meta.json'), 'utf8')); } catch { return null; } })() };
}

function sum(rows, pathFn) {
    const out = {};
    for (const r of rows) for (const [k, v] of Object.entries(pathFn(r) ?? {})) out[k] = (out[k] ?? 0) + (typeof v === 'number' ? v : 0);
    return out;
}

// ───────────────────────── 输出 ─────────────────────────
const results = RUNS.map(analyse);
const report = { generatedAt: new Date().toISOString(), runs: [], verdict: {} };

for (const r of results) {
    if (r.missing) { console.log(`\n❌ run 不存在：${r.runDir}`); report.runs.push(r); continue; }
    const rows = r.rows;
    const total = rows.length;
    const success = rows.filter((x) => x.outcome === 'SUCCESS').length;
    const teleBad = rows.filter((x) => !x.telemetryOk).length;
    const zero = sum(rows, (x) => x.zeroLine);
    const obs = sum(rows, (x) => x.observe);
    const runl = sum(rows, (x) => x.runLevel);
    const causes = {}; for (const x of rows) for (const [k, v] of Object.entries(x.causes)) causes[k] = (causes[k] ?? 0) + v;
    const grids = {}; for (const x of rows) for (const [k, v] of Object.entries(x.gridDist)) grids[k] = (grids[k] ?? 0) + v;
    const loads = {}; for (const x of rows) for (const [k, v] of Object.entries(x.loadReasons)) loads[k] = (loads[k] ?? 0) + v;
    const deaths = rows.reduce((s, x) => s + (x.deaths ?? 0), 0);
    const durations = rows.map((x) => x.durationMs).filter((d) => typeof d === 'number' && d > 0).sort((a, b) => a - b);

    console.log(`\n${'='.repeat(78)}\n▶ run: ${path.basename(r.runDir)}   trials=${total}  success=${success}  deaths=${deaths}`);
    if (r.meta) console.log(`  meta: ${JSON.stringify(r.meta.params ?? {}).slice(0, 160)}`);
    if (teleBad) console.log(`  ⚠ ${teleBad} 个 trial 遥测不可读（TELEMETRY_MISSING / 解析失败）—— 不计入 0 事件`);

    console.log(`\n  ① 窗口操作层 · 归零线`);
    for (const k of ZERO_LINE) console.log(`     ${zero[k] === 0 ? '✅' : '❌'} ${k.padEnd(22)} ${zero[k]}`);
    console.log(`     ${obs.smelt_ok > 0 ? '✅' : '⚠ '} smelt_ok（全 bench 史上前无记录） ${obs.smelt_ok}`);

    console.log(`\n  ② 窗口操作层 · 观测分布`);
    for (const k of OBSERVE) if (obs[k]) console.log(`     ${k.padEnd(24)} ${obs[k]}`);
    if (Object.keys(loads).length) { console.log(`     ── 装料/加燃料的结构化 reason ──`); for (const [k, v] of Object.entries(loads)) console.log(`     ${k.padEnd(28)} ${v}`); }

    console.log(`\n  ③ craft_replan.cause 分布（验收线：只应因物资）`);
    if (!Object.keys(causes).length) console.log(`     （本 run 没有 craft_replan）`);
    for (const [k, v] of Object.entries(causes)) console.log(`     ${k.padEnd(28)} ${v}`);
    const badCause = (causes['no_gain'] ?? 0) + (causes['station_unavailable'] ?? 0);
    console.log(`     ⇒ 非物资原因（no_gain + station_unavailable）= ${badCause} ${badCause === 0 ? '✅' : '❌'}`);
    if (causes['MISSING(旧口径/未记录)']) console.log(`     ⚠ ${causes['MISSING(旧口径/未记录)']} 条没有 cause 字段（旧数据或非本单代码路径）`);

    console.log(`\n  ④ craft_ok 的网格分布（r4 新字段）`);
    for (const [k, v] of Object.entries(grids)) if (v) console.log(`     ${k.padEnd(28)} ${v}`);

    console.log(`\n  ⑤ 整局 / 导航 / 死亡层（与窗口层分开记）`);
    for (const x of rows) {
        const tree = (x.fullInventory && typeof x.fullInventory === 'object') ? '' : '';
        console.log(`     ${x.trial}  ${String(x.outcome ?? '?').padEnd(8)} ${String(x.failReason ?? '-').padEnd(18)} ` +
            `${String(x.durationMs ? (x.durationMs / 1000).toFixed(1) + 's' : '?').padStart(8)}  deaths=${x.deaths}  ` +
            `smeltOk=${x.smeltOk}  craftFail=${x.craftFailures}/${x.craftAttempts}  ${x.telemetryOk ? '' : '⚠遥测不可读'}`);
    }
    if (durations.length) {
        const med = durations[Math.floor(durations.length / 2)];
        const p90 = durations[Math.min(durations.length - 1, Math.floor(durations.length * 0.9))];
        console.log(`     墙钟（全部 trial 口径，含失败局）：median=${(med / 1000).toFixed(1)}s  P90=${(p90 / 1000).toFixed(1)}s  n=${durations.length}`);
    }
    const nav = Object.entries(runl).filter(([, v]) => v > 0);
    if (nav.length) { console.log(`     导航层事件：${nav.map(([k, v]) => `${k}=${v}`).join('  ')}`); }

    report.runs.push({ runDir: r.runDir, total, success, deaths, zero, obs, causes, grids, loads, rows });
}

// ── 总判决 ──
const all = report.runs.filter((x) => !x.missing);
const totTrials = all.reduce((s, x) => s + x.total, 0);
const totSuccess = all.reduce((s, x) => s + x.success, 0);
const totDeaths = all.reduce((s, x) => s + x.deaths, 0);
const totZero = {}; for (const x of all) for (const [k, v] of Object.entries(x.zero)) totZero[k] = (totZero[k] ?? 0) + v;
const totSmeltOk = all.reduce((s, x) => s + (x.obs.smelt_ok ?? 0), 0);
const totBadCause = all.reduce((s, x) => s + (x.causes.no_gain ?? 0) + (x.causes.station_unavailable ?? 0), 0);

console.log(`\n${'='.repeat(78)}\n■ 总判决（验收线逐条）`);
const lines = [];
for (const k of ZERO_LINE) lines.push([`窗口层 ${k} 归零`, totZero[k] === 0, `${totZero[k]}`]);
// ⚠ 没给 --expect-* 时**不能**打 ✅：那会让"没设线"读成"达标"，
//   正是手册 §5 点名的"把没有数据折算成通过"。
lines.push([EXPECT_TOTAL ? `整局层 iron 达标（≥${EXPECT_SUCCESS}/${EXPECT_TOTAL}）` : '整局层 iron 达标',
    EXPECT_TOTAL ? totSuccess >= EXPECT_SUCCESS : null, `${totSuccess}/${totTrials}${EXPECT_TOTAL ? '' : '（未设线）'}`]);
lines.push(['craft_replan 只因物资（cause 非 no_gain/station_unavailable）', totBadCause === 0, `非物资 ${totBadCause}`]);
lines.push(['死亡硬线', totDeaths === 0, `deaths=${totDeaths}`]);
lines.push(['smelt_ok 首次出现（旁证，不设线）', null, `${totSmeltOk}`]);
for (const [name, pass, detail] of lines) console.log(`  ${pass === null ? '·' : (pass ? '✅' : '❌')} ${name.padEnd(52)} ${detail}`);
report.verdict = { totTrials, totSuccess, totDeaths, totZero, totSmeltOk, totBadCause, lines: lines.map(([n, p, d]) => ({ name: n, pass: p, detail: d })) };

if (COMPARE && fs.existsSync(COMPARE)) {
    const c = analyse(COMPARE);
    if (!c.missing) {
        const cz = sum(c.rows, (x) => x.zeroLine);
        const cobs = sum(c.rows, (x) => x.observe);
        console.log(`\n${'='.repeat(78)}\n■ 与 r3 对比（同口径才可比；r3 run = ${path.basename(COMPARE)}）`);
        console.log(`  ${'事件'.padEnd(24)} ${'r3'.padStart(6)} ${'r4'.padStart(6)}`);
        for (const k of ZERO_LINE) console.log(`  ${k.padEnd(24)} ${String(cz[k] ?? 0).padStart(6)} ${String(totZero[k] ?? 0).padStart(6)}`);
        for (const k of ['smelt_ok', 'craft_ok', 'craft_replan']) {
            console.log(`  ${k.padEnd(24)} ${String(cobs[k] ?? 0).padStart(6)} ${String(all.reduce((s, x) => s + (x.obs[k] ?? 0), 0)).padStart(6)}`);
        }
        console.log(`  ⚠ 口径提醒：r3 的 REG_M4B4 基线跑在 e92bd3e（比 r3 HEAD 落后 3 个 crafting_task.js 提交），`);
        console.log(`    且 craft_replan 当时**没有 cause 字段** ⇒ 那一列不可直接比，只能看窗口层归零线。`);
    }
}

if (JSON_OUT) { fs.writeFileSync(JSON_OUT, JSON.stringify(report, null, 2), 'utf8'); console.log(`\n已写 ${JSON_OUT}`); }
process.exit(0);
