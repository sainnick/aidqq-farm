// craft_table_probe.mjs — P1 验收探针：**同一条工作台通道，两条实现 A/B**。
//
// 背景：06d 微基准测到 `bot.craft`（mineflayer 4.38）做 wooden_pickaxe 只有 21/30，
//   失败形态是「不抛错 + 背包无增量」的静默丢件。看 mineflayer 的 craft() 源码，
//   grabResult() 是这么写的：
//       window.updateSlot(0, new Item(result))   ← **本地伪造**产物槽
//       await bot.putAway(0)                     ← 再点一下 0 号槽拿走
//   产物不是等服务端算的，是客户端先塞进去再点。服务端合成格一旦和客户端以为的不一样，
//   0 号槽就是空的，putAway 点了个寂寞 —— 静默丢件，且不报任何错。
//
// 任务层其实早就有一份自研实现 `CraftingTask._tableCraft`：每次点击都等服务端 set_slot 回显，
//   并且**抓结果前先检查 w.slots[0]（服务端真实结果位）**，没有就 `table_craft_no_result` 判负。
//   它被 gate 在 `supportsWindowStateId(bot.registry)`（1.17+）上，1.16.1 走不到。
//   本探针直接**调任务层那份真代码**（不是抄一遍），在 1.16.1 上量它到底行不行：
//   arm=tablecraft → CraftingTask._tableCraft；arm=botcraft → mineflayer bot.craft（现状）。
//
// 用法：node craft_table_probe.mjs --out <dir> --port 25566 --username TaskBot --n 30

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const OUT = path.resolve(arg('out', HERE));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const N = parseInt(arg('n', '30'), 10);
const WARMUP = parseInt(arg('warmup', '30'), 10);
const SETUP = path.join(OUT, 'setup.json');
const RES = path.join(OUT, 'craft_table_probe.json');
const DONE = path.join(OUT, 'done.json');
for (const f of [RES, DONE]) { try { fs.rmSync(f, { force: true }); } catch { /* 忽略 */ } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[ctab ${new Date().toISOString().slice(11, 19)}] ${m}`);

async function main() {
    const mineflayer = require('mineflayer');
    const { Vec3 } = require('vec3');
    const { CraftingTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/crafting_task.js')).href);
    const task = new CraftingTask({});
    const tele = [];
    const ctx = { bot: null, telemetry: (e, d) => tele.push({ e, d }) };

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: '1.16.1' });
    // ⚠ 刻意**不**加载 pathfinder：06d 的 craft_bot.mjs 也没加载，而带 pathfinder 时
    //   同一份 bot.craft 调 30 次是 30/30、不带时是 24/30。丢件是时序敏感的竞态，
    //   要做有意义的 A/B，对照臂必须和复现出 bug 的那份时序一致。
    if (arg('pf', '0') === '1') bot.loadPlugin(require('mineflayer-pathfinder').pathfinder);
    await new Promise((resolve, reject) => {
        bot.once('spawn', resolve); bot.once('error', reject); setTimeout(() => reject(new Error('spawn timeout')), 60000);
    });
    ctx.bot = bot;
    log('spawned');
    await sleep(3500);
    for (let i = 0; i < 120 && !fs.existsSync(SETUP); i++) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('no setup.json（runner 没 op）');

    let seq = 0, msgQueue = [];
    bot.on('message', (m) => { try { msgQueue.push(String(m.toString ? m.toString() : m)); } catch { msgQueue.push('?'); } });
    async function cmd(text, { waitMs = 400 } = {}) {
        const id = `@@T${++seq}`;
        msgQueue = [];
        bot.chat(`/say ${id}`);
        const t0 = Date.now();
        while (Date.now() - t0 < 3000 && !msgQueue.some((s) => s.includes(id))) await sleep(25);
        msgQueue = [];
        bot.chat(`/${text}`);
        const tw = Date.now();
        while (Date.now() - tw < waitMs && !msgQueue.length) await sleep(25);
        await sleep(40);
        const r = msgQueue.join(' | '); msgQueue = []; return r;
    }
    const count = (name) => bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0);

    const SX = 200, SY = 68, SZ = 200;
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(2000);
    await cmd(`fill ${SX - 4} ${SY} ${SZ - 4} ${SX + 4} ${SY} ${SZ + 4} minecraft:stone`, { waitMs: 900 });
    await cmd(`fill ${SX - 4} ${SY + 1} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:air`, { waitMs: 900 });
    await cmd(`setblock ${SX + 1} ${SY + 1} ${SZ} minecraft:crafting_table`, { waitMs: 700 });
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(1500);
    const table = bot.blockAt(new Vec3(SX + 1, SY + 1, SZ));
    log(`工作台 ${table?.name} @${SX + 1},${SY + 1},${SZ}`);

    const refuel = async () => {
        for (const junk of ['wooden_pickaxe', 'stone_pickaxe', 'stick', 'oak_planks', 'cobblestone', 'oak_log']) await cmd(`clear @s minecraft:${junk}`, { waitMs: 120 });
        await cmd(`give @s minecraft:oak_planks 16`, { waitMs: 200 });
        await cmd(`give @s minecraft:cobblestone 16`, { waitMs: 200 });
        await cmd(`give @s minecraft:stick 16`, { waitMs: 200 });
        await cmd(`give @s minecraft:oak_log 8`, { waitMs: 200 });
        await sleep(400);
    };

    // 热身：逐字复现 06d 的前缀（丢件只在长会话里出现）
    for (const [nm, useT] of [['stick', false], ['stick', false], ['stick', true], ['oak_planks', false]]) {
        for (let k = 0; k < WARMUP; k++) {
            await refuel();
            const rs = bot.recipesFor(bot.registry.itemsByName[nm]?.id, null, 1, useT ? table : null);
            if (rs.length) { try { await bot.craft(rs[0], 1, useT ? table : null); } catch { /* 忽略 */ } }
            try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow); } catch { /* 忽略 */ }
        }
        log(`热身 ${nm} ×${WARMUP} 完成`);
    }

    const arms = ['botcraft', 'doCraft'];
    const cells = [];
    for (const arm of arms) {
        for (const item of ['wooden_pickaxe', 'stone_pickaxe']) {
            const rows = [];
            for (let i = 0; i < N; i++) {
                await refuel();
                const before = count(item);
                const teleN = tele.length;
                const t0 = Date.now();
                let err = null, ok = false;
                try {
                    const rs = bot.recipesFor(bot.registry.itemsByName[item]?.id, null, 1, table);
                    if (!rs.length) { err = 'no_recipe'; } else if (arm === 'botcraft') { await bot.craft(rs[0], 1, table); ok = true; } else { ok = await task._doCraft(ctx, rs[0], 1, table); }
                } catch (e) { err = String(e?.message ?? e).slice(0, 120); }
                const ms = Date.now() - t0;
                let gained = count(item) - before;
                const dl = Date.now() + 2000;
                while (gained <= 0 && Date.now() < dl) { await sleep(150); gained = count(item) - before; }
                try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow); } catch { /* 忽略 */ }
                const evs = tele.slice(teleN).map((x) => x.e);
                rows.push({ i, ms, err, ret: ok, gained, verified: gained > 0, events: evs });
                try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow); } catch { /* 忽略 */ }
                await sleep(150);
            }
            const okN = rows.filter((r) => r.verified).length;
            cells.push({ arm, item, n: rows.length, ok: okN, rate: +((okN / rows.length) * 100).toFixed(1), rows });
            log(`${arm}/${item}: ${okN}/${rows.length} = ${(okN / rows.length * 100).toFixed(1)}%  中位 ${rows.map((r) => r.ms).sort((a, b) => a - b)[Math.floor((rows.length - 1) / 2)]}ms  失败事件=${JSON.stringify([...new Set(rows.filter((r) => !r.verified).flatMap((r) => r.events))])}`);
        }
    }
    fs.writeFileSync(RES, JSON.stringify({ n: N, warmup: WARMUP, cells, mcVersion: '1.16.1' }, null, 2));
    fs.writeFileSync(DONE, JSON.stringify({ done: true }));
    log('=== 汇总 ===');
    for (const c of cells) log(`${c.arm.padEnd(11)} ${c.item.padEnd(16)} ${c.ok}/${c.n} = ${c.rate}%`);
    bot.quit();
    process.exit(0);
}
main().catch((e) => { log(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 600)}`); process.exit(1); });
