// run_t09r5_bench.mjs — MC-M1-TASK-09-r5：窗口原语微基准的编排（一条泳道，一台服）。
//
// 复用 run_micro_craft.mjs 的骨架（线锁 / preflight / 拍摄预约 / 起服 / 收工），
// 区别只在 bot 脚本换成 t09r5_window_bench.mjs（它自己跑 2×2 + 熔炉两段，一条链坏不挡另一条）。
//
// 用法：node run_t09r5_bench.mjs --stamp T09R5 [--n 30] [--lane A]

import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { parseLanes, buildLanes, bootServerWithRetry, stopServer, freshWorld, log } from '../_lib/runner_core.mjs';
import { cleanup, installRunnerHooks } from '../_lib/cleanup.mjs';
import { preflight } from '../_lib/preflight.mjs';
import { holdLocks } from '../_lib/line_lock.mjs';
import { waitReserveClear } from '../_lib/reserve.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const NODE20 = path.join(ROOT, '.runtime/node-v20.20.2-win-x64/node.exe');
const JAR = path.join(TEMPLATE, process.env.MC_BENCH_JAR || 'server-1.16.1.jar');
const RCON_PASS = 'spike-rcon';

const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const N = parseInt(arg('n', '30'), 10);
const STAMP = arg('stamp', `T09R5_${new Date().toISOString().slice(5, 10).replace(/[-T]/g, '')}`);
const LANE_NAMES = parseLanes(process.argv);
const XMX = arg('server-xmx', '1G');
const BOT_SCRIPT = arg('bot', 't09r5_window_bench.mjs');
const TIMEOUT_MS = parseInt(arg('timeout-ms', '1500000'), 10);   // 熔炉段要等真熔炼，默认 25min

const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
fs.mkdirSync(RUNS_DIR, { recursive: true });
process.env.JAVA_TOOL_OPTIONS ||= '-Djava.net.preferIPv4Stack=true';
const lock = await holdLocks([LANE_NAMES[0]], { who: 'A', label: `r5bench ${STAMP}`, logFn: log });
installRunnerHooks(() => `r5bench ${STAMP}`, () => { try { lock.releaseAll?.(); } catch { /* 忽略 */ } });
const pf = await preflight({ killStale: true, laneNames: [LANE_NAMES[0]], who: 'A', logFn: log });
for (const l of pf.notes) log(`preflight: ${l}`);
for (const w of pf.warns) log(`preflight ! ${w}`);
if (!pf.ok) { for (const b of pf.blockers) log(`preflight X ${b}`); await lock.releaseAll?.(); process.exit(1); }
await waitReserveClear({ who: 'A', logFn: log });

const t0 = Date.now();
log(`r5 window bench n=${N} lane=${LANE_NAMES.join(',')} → ${path.relative(ROOT, RUNS_DIR)}`);
const [lane] = buildLanes({ names: [LANE_NAMES[0]], templateDir: TEMPLATE, jarPath: JAR, rconPass: RCON_PASS, logFn: log });
lane.java = JAVA;
freshWorld(lane, `T09R5-${STAMP}`);
const server = await bootServerWithRetry(lane, RUNS_DIR, XMX, log);
log(`server up in ${(server.bootMs / 1000).toFixed(0)}s`);

const botLog = fs.openSync(path.join(RUNS_DIR, 'bot_console.log'), 'w');
const bot = spawn(NODE20, [path.join(BENCH_DIR, BOT_SCRIPT), '--out', RUNS_DIR, '--port', String(lane.serverPort), '--username', lane.username, '--n', String(N)],
    { stdio: ['ignore', botLog, botLog] });
try {
    const tj = Date.now();
    while (!/joined the game/.test(fs.readFileSync(path.join(RUNS_DIR, 'server.log'), 'utf8')) && Date.now() - tj < 120000) await new Promise((r) => setTimeout(r, 1000));
    server.child.stdin.write(`op ${lane.username}\n`);
    await new Promise((r) => setTimeout(r, 1500));
    fs.writeFileSync(path.join(RUNS_DIR, 'setup.json'), JSON.stringify({ op: lane.username }));
    log('bot 已 op，放行');
    const td = Date.now();
    while (!fs.existsSync(path.join(RUNS_DIR, 'done.json')) && bot.exitCode === null && Date.now() - td < TIMEOUT_MS) {
        await new Promise((r) => setTimeout(r, 3000));
    }
    if (!fs.existsSync(path.join(RUNS_DIR, 'done.json'))) log(`⚠ 超时 ${(TIMEOUT_MS / 60000).toFixed(0)}min 仍未产出 done.json`);
} finally {
    try { bot.kill(); } catch { /* 忽略 */ }
    fs.closeSync(botLog);
    await stopServer(lane, server);
}

const resPath = path.join(RUNS_DIR, 'r5_bench_result.json');
const md = [`# T09-r5 窗口原语微基准 — ${STAMP}`, '', '> 验收线：每段 ≥29/30。三段**分开算**（2×2 坏不挡熔炉）。', ''];
if (fs.existsSync(resPath)) {
    const r = JSON.parse(fs.readFileSync(resPath, 'utf8'));
    md.push('| 段 | n | 成功 | 成功率 | 中位 ms | 失败原因分布 |', '|---|---|---|---|---|---|');
    for (const [k, v] of Object.entries(r.segments)) {
        const pass = v.rate >= (29 / 30) * 100;
        md.push(`| ${k} | ${v.n} | ${v.ok} | **${v.rate}%** ${pass ? '✅' : '❌'} | ${v.medianMs} | ${JSON.stringify(v.failReasons)} |`);
    }
    md.push('', '## caveat', '');
    for (const c of r.caveats ?? []) md.push(`- ${c}`);
    const bad = { craft: r.rows.craft.filter((x) => !x.verified), load: r.rows.furnaceLoad.filter((x) => !x.verified), take: r.rows.furnaceTake.filter((x) => !x.verified) };
    md.push('', '## 失败明细', '', `- 2×2 失败序号: [${bad.craft.map((b) => b.i).join(',')}]`);
    md.push(`- 装料失败序号: [${bad.load.map((b) => b.i).join(',')}]`);
    md.push(`- 取件失败序号: [${bad.take.map((b) => b.i).join(',')}]`);
} else md.push('（没产出结果文件，看 bot_console.log）');
fs.writeFileSync(path.join(RUNS_DIR, 'r5_bench_report.md'), md.join('\n') + '\n');
log(`墙钟 ${((Date.now() - t0) / 60000).toFixed(1)}min → ${path.join(RUNS_DIR, 'r5_bench_report.md')}`);
const cu = await cleanup({ label: `r5bench ${STAMP}`, rmWorlds: true, dirs: [{ dir: lane.dir, port: lane.serverPort }], laneNames: [LANE_NAMES[0]] });
fs.writeFileSync(path.join(RUNS_DIR, 'cleanup.txt'), cu.lines.join('\n') + '\n');
await lock.releaseAll?.();
process.exit(fs.existsSync(resPath) ? 0 : 2);
