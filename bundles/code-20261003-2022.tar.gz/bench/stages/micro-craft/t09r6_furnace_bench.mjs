﻿// t09r6_furnace_bench.mjs — MC-M1-TASK-09-r6：熔炉装料/取件微基准（真服，泳道 A）
//
// 与 r5 基准的差别（都是 r5 报告 §7 自己点的三条）：
//   ① **每轮用 /setblock 重置熔炉** —— r5 只 clear 了玩家背包、没清炉子，
//      第 2 轮起输入/燃料格是脏的（`dest_occupied`×8 的混淆项）。
//   ② **槽位映射的服务端真值对账**（r5 §4.2 的 INCONCLUSIVE ②）：
//      用控制台 `data merge block <熔炉> {Items:[…]}` 直接往服务端方块实体里写标记物，
//      再看**本地窗口模型**里它们落在哪几个下标 ⇒ 一次拿到「服务端容器槽 ⇔ 本地下标」的映射表。
//      这是**阳性对照**：通道能测出"有"，读出"无"才可信（手册 §4.11）。
//   ③ **服务端读回**（`data get block`）：装料成功与否以服务端方块实体为准，
//      不只看客户端模型。
//
// 装料实现（r6）：**两次 PICKUP**（`loadIntoFurnaceSlot`），不再用 shift ——
//   shift 在 1.16.1 上必被拒（`doClick:243` + `ItemStack.isSame` 规则，见 window_ops.js 注释）。
//
// 用法（由 run_t09r5_bench.mjs --bot 调起）：
//   node t09r6_furnace_bench.mjs --out <dir> --port 25566 --username TaskBot --n 30

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 1 ? process.argv[i + 1] : d; };
const OUT = path.resolve(arg('out', HERE));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const N = parseInt(arg('n', '30'), 10);
const SETUP = path.join(OUT, 'setup.json');
const RES = path.join(OUT, 'r5_bench_result.json');   // 复用编排器的读法与报告格式
const DONE = path.join(OUT, 'done.json');
for (const f of [RES, DONE]) { try { fs.rmSync(f, { force: true }); } catch { /* 忽略 */ } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[r6furn ${new Date().toISOString().slice(11, 19)}] ${m}`);

const SX = 200, SY = 68, SZ = 200;   // 场景只有一个真源（与 r5 同一块平台）
const FX = SX - 1, FY = SY + 1, FZ = SZ;
const ORE = parseInt(arg('ore', '1'), 10);
const COAL = parseInt(arg('coal', '1'), 10);
const SMELT_WAIT_MS = parseInt(arg('smelt-wait', '20000'), 10);

function agg(rows) {
    const ok = rows.filter((r) => r.verified).length;
    const ms = rows.filter((r) => r.ms != null).map((r) => r.ms).sort((a, b) => a - b);
    const failReasons = {};
    for (const r of rows) if (!r.verified) failReasons[r.reason ?? 'unknown'] = (failReasons[r.reason ?? 'unknown'] ?? 0) + 1;
    return { n: rows.length, ok, rate: rows.length ? +((ok / rows.length) * 100).toFixed(1) : 0, medianMs: ms.length ? ms[Math.floor(ms.length / 2)] : null, failReasons };
}

async function main() {
    const mineflayer = require('mineflayer');
    const { Vec3 } = require('vec3');
    const {
        loadIntoFurnaceSlot, takeOutOfFurnaceSlot, takeFurnaceOutputConfirmed, closeWindowConfirmed,
        playerInvRange, windowSlotCount, slotCountSource, countItemsInRange,
    } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/window_ops.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: '1.16.1' });
    bot.loadPlugin(require('mineflayer-pathfinder').pathfinder);
    await new Promise((resolve, reject) => {
        bot.once('spawn', resolve); bot.once('error', reject); setTimeout(() => reject(new Error('spawn timeout')), 60000);
    });
    log(`spawned ${bot.entity.position.toArray().map((v) => v.toFixed(0))}`);
    await sleep(3500);
    for (let i = 0; i < 120 && !fs.existsSync(SETUP); i++) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('no setup.json（runner 没 op）');

    let seq = 0; let msgQueue = [];
    bot.on('message', (m) => { try { msgQueue.push(String(m.toString ? m.toString() : m)); } catch { msgQueue.push('?'); } });
    async function cmd(text, { waitMs = 700 } = {}) {
        const id = `@@C${++seq}`;
        msgQueue = [];
        bot.chat(`/say ${id}`);
        const t0 = Date.now();
        while (Date.now() - t0 < 3000 && !msgQueue.some((s) => s.includes(id))) await sleep(25);
        msgQueue = [];
        bot.chat(`/${text}`);
        const tw = Date.now();
        while (Date.now() - tw < waitMs && !msgQueue.length) await sleep(25);
        await sleep(60);
        const r = msgQueue.join(' | '); msgQueue = []; return r;
    }
    const count = (name) => bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0);

    // ── 布景（硬闸门：没建成就别开测，手册 §5）──
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(2000);
    await cmd(`fill ${SX - 4} ${SY} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:stone`, { waitMs: 900 });
    await cmd(`fill ${SX - 4} ${SY + 1} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:air`, { waitMs: 900 });
    await cmd(`setblock ${FX} ${FY} ${FZ} minecraft:furnace`, { waitMs: 700 });
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(1500);
    const furnaceBlock = bot.blockAt(new Vec3(FX, FY, FZ));
    if (furnaceBlock?.name !== 'furnace') throw new Error(`布景失败：${furnaceBlock?.name} @${FX},${FY},${FZ}`);
    log(`熔炉就位 @${FX},${FY},${FZ}`);

    const rows = { craft: [], furnaceLoad: [], furnaceTake: [] };
    let mapping = null;   // 服务端容器槽 ⇔ 本地下标 的对账表（第 0 轮做一次）

    const winMeta = (win) => ({
        id: win.id, type: String(win.type ?? ''), slotsLen: win.slots?.length ?? null,
        libInv: win.slots ? `${win.inventoryStart}-${win.inventoryEnd}` : null,
        libHotbar: win.slots ? String(win.hotbarStart) : null,
        slotCount: windowSlotCount(bot, win), slotCountVia: slotCountSource(bot, win),
        playerRange: (() => { const g = playerInvRange(bot, win); return g ? `${g.start}-${g.end}#${g.via}` : null; })(),
        hasFurnace: !!bot.furnace,
    });

    for (let i = 0; i < N; i++) {
        // ── ① 每轮重置熔炉（r5 的混淆项：只 clear 了玩家、没清炉子）──
        try { await closeWindowConfirmed(bot, bot.currentWindow); } catch { /* 忽略 */ }
        await cmd(`setblock ${FX} ${FY} ${FZ} minecraft:air`, { waitMs: 350 });
        await cmd(`setblock ${FX} ${FY} ${FZ} minecraft:furnace`, { waitMs: 450 });
        await sleep(250);
        if (bot.blockAt(new Vec3(FX, FY, FZ))?.name !== 'furnace') log(`  ! 第 ${i} 轮熔炉重置没生效`);
        for (const j of ['iron_ore', 'coal', 'iron_ingot']) await cmd(`clear @s minecraft:${j}`, { waitMs: 110 });
        await cmd(`give @s minecraft:iron_ore ${ORE}`, { waitMs: 250 });
        await cmd(`give @s minecraft:coal ${COAL}`, { waitMs: 250 });
        await sleep(350);
        if (count('iron_ore') !== ORE || count('coal') !== COAL) { log(`  ! 第 ${i} 轮 kit 没到位 ore=${count('iron_ore')} coal=${count('coal')}`); }

        // ── ② 开窗（自己按 open_window 认，不用 bot.openFurnace —— 它在 1.16.1 必抛）──
        let openErr = null;
        try {
            await bot.lookAt(furnaceBlock.position.offset(0.5, 0.5, 0.5), false);
            await sleep(250);
            const opened = await bot.openBlock(furnaceBlock);
            const win = (opened && opened.id != null && opened.id !== 0) ? opened : bot.currentWindow;
            if (!win || win.id == null || win.id === 0) throw new Error(`窗口没开出来 curWindowId=${bot.currentWindow?.id ?? 'null'}`);
            await sleep(250);

            // ── ③ 槽位映射的服务端真值对账（只做第 0 轮）──
            if (!mapping) {
                const before = Array.from({ length: win.slots.length }, (_, k) => (win.slots[k] ? `${k}:${win.slots[k].name}` : `${k}:-`));
                const mergeRet = await cmd(`data merge block ${FX} ${FY} ${FZ} {Items:[{Slot:0b,Count:1b,id:"minecraft:iron_ingot"},{Slot:1b,Count:2b,id:"minecraft:golden_apple"}]}`, { waitMs: 900 });
                await sleep(700);
                const srvRead = await cmd(`data get block ${FX} ${FY} ${FZ} Items`, { waitMs: 900 });
                const after = Array.from({ length: win.slots.length }, (_, k) => ({ k, s: win.slots[k] ? `${win.slots[k].name}x${win.slots[k].count}` : null }));
                const mIngot = after.filter((x) => x.s && x.s.startsWith('iron_ingot')).map((x) => x.k);
                const mApple = after.filter((x) => x.s && x.s.startsWith('golden_apple')).map((x) => x.k);
                mapping = {
                    meta: winMeta(win), beforeNonEmpty: before.filter((s) => !s.endsWith(':-')).slice(0, 6),
                    srvContainer0_seenAtLocalIndex: mIngot, srvContainer1_seenAtLocalIndex: mApple,
                    serverReadbackHasBoth: /iron_ingot/.test(srvRead) && /golden_apple/.test(srvRead),
                    mergeRet: String(mergeRet).slice(0, 200), srvRead: String(srvRead).slice(0, 300),
                    verdict: (mIngot.length && mApple.length) ? `srv0→local${mIngot.join(',')} srv1→local${mApple.join(',')}` : 'INCONCLUSIVE(标记物没进本地模型)',
                };
                log(`映射对账：${mapping.verdict} 服务端读回=${mapping.serverReadbackHasBoth}`);
                await cmd(`data remove block ${FX} ${FY} ${FZ} Items`, { waitMs: 700 });
                await sleep(500);
                // 标记必须清干净，否则这一轮不再是"全新熔炉"
                const dirty = [0,1,2].map((k) => win.slots[k]).filter(Boolean);
                if (dirty.length) {
                    await cmd(`setblock ${FX} ${FY} ${FZ} minecraft:air`, { waitMs: 350 });
                    await cmd(`setblock ${FX} ${FY} ${FZ} minecraft:furnace`, { waitMs: 450 });
                    await sleep(300);
                    await closeWindowConfirmed(bot, bot.currentWindow);
                    await bot.lookAt(furnaceBlock.position.offset(0.5, 0.5, 0.5), false);
                    await sleep(200);
                    await bot.openBlock(furnaceBlock);
                    await sleep(250);
                    log(`  (对账残留已重置熔炉；残留=${dirty.map((d) => d.name).join(',')})`);
                }
            }

            const win2 = bot.currentWindow;
            const meta = winMeta(win2);

            // ── ④ 装料（两次 PICKUP）+ 加燃料 ──
            const t1 = Date.now();
            const load = await loadIntoFurnaceSlot(bot, win2, { itemName: 'iron_ore', target: 'input', timeoutMs: 2500 });
            const fuel = load?.ok
                ? await loadIntoFurnaceSlot(bot, win2, { itemName: 'coal', target: 'fuel', timeoutMs: 2500 })
                : { ok: false, reason: 'skipped(load failed)' };
            const loadMs = Date.now() - t1;
            // ★ 服务端读回：熔炉方块实体里到底有什么（不是客户端模型）
            const srvItems = await cmd(`data get block ${FX} ${FY} ${FZ} Items`, { waitMs: 900 });
            const srvOk = /iron_ore/.test(srvItems) && /coal/.test(srvItems);
            rows.furnaceLoad.push({
                i, verified: load?.ok === true && fuel?.ok === true && srvOk, ms: loadMs, meta,
                reason: load?.ok ? (fuel?.reason ?? null) : (load?.reason ?? null),
                fuelReason: fuel?.reason ?? null, moved: load?.moved ?? null, via: load?.via ?? null,
                fuelMoved: fuel?.moved ?? null, fuelVia: fuel?.via ?? null,
                serverTruthOk: srvOk, serverTruth: String(srvItems).slice(0, 240),
                cursorAfter: win2.selectedItem ? `${win2.selectedItem.name}x${win2.selectedItem.count}` : null,
                verdict: load?.ok ? null : load,
            });

            // ── ⑤ 取件（等真熔炼）──
            const t3 = Date.now();
            const beforeIngot = count('iron_ingot');
            let take = { ok: false, reason: 'load_failed' }, waitedMs = 0;
            if (load?.ok && fuel?.ok) {
                const dl = Date.now() + SMELT_WAIT_MS;
                while (Date.now() < dl) {
                    const out = win2.slots?.[2];
                    if (out && out.name === 'iron_ingot' && out.count > 0) break;
                    await sleep(400); waitedMs += 400;
                }
                take = await takeFurnaceOutputConfirmed(bot, win2, { via: 'pickup', timeoutMs: 3000, expectName: 'iron_ingot' });
            }
            const tookMs = Date.now() - t3;
            const gainedIngot = count('iron_ingot') - beforeIngot;
            rows.furnaceTake.push({
                i, verified: take?.ok === true && gainedIngot > 0, ms: tookMs, waitedMs,
                reason: take?.reason ?? null, gained: gainedIngot, took: take?.took ?? null,
                outBefore: load?.ok ? (win2.slots?.[2]?.count ?? null) : null,
                verdict: take?.ok ? null : take,
            });
        } catch (e) {
            openErr = String(e && e.message ? e.message : e).slice(0, 200);
            rows.furnaceLoad.push({ i, verified: false, reason: 'open_error', openErr });
            rows.furnaceTake.push({ i, verified: false, reason: 'open_error', openErr });
            log(`  ! 第 ${i} 轮异常：${openErr}`);
        }

        try { await closeWindowConfirmed(bot, bot.currentWindow); } catch { /* 忽略 */ }
        await sleep(200);
        if ((i + 1) % 5 === 0 || i < 3) {
            log(`B ${i + 1}/${N}：装料 ok=${rows.furnaceLoad.filter((r) => r.verified).length} 取件 ok=${rows.furnaceTake.filter((r) => r.verified).length}` +
                (rows.furnaceLoad.at(-1)?.reason ? ` lastLoadReason=${rows.furnaceLoad.at(-1).reason}` : '') +
                (rows.furnaceTake.at(-1)?.reason ? ` lastTakeReason=${rows.furnaceTake.at(-1).reason}` : ''));
        }
    }

    fs.writeFileSync(RES, JSON.stringify({
        stamp: process.argv.includes('--out') ? path.basename(OUT) : '', n: N,
        mapping,
        segments: { craft2x2: agg(rows.craft), furnaceLoad: agg(rows.furnaceLoad), furnaceTake: agg(rows.furnaceTake) },
        rows,
        caveats: [
            `kit 起步：ore=${ORE} coal=${COAL}，**不复现**真实链"熔炉在 y13–18 地下竖井旁"，只测窗口原语本身`,
            '每轮 /setblock 重置熔炉（r5 的混淆项已消除）',
            `装料判据 = 服务端回读 \`data get block\`（客户端模型不算数）；映射对账见 mapping`,
            '取件走两次 PICKUP（via=pickup）',
        ],
    }, null, 2));
    fs.writeFileSync(DONE, JSON.stringify({ ok: true }));
    log('done');
    bot.quit();
}

main().then(() => process.exit(0)).catch((e) => {
    log(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 600)}`);
    try { fs.writeFileSync(DONE, JSON.stringify({ ok: false, error: String(e && e.message ? e.message : e) })); } catch { /* 忽略 */ }
    process.exit(3);
});

