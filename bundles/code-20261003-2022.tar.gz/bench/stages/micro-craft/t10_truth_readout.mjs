// t10_truth_readout.mjs — 从 ① 已落盘的 furnace_truth.json **离线**重算服务端背包口径
//
// 为什么单独写一个：跑 ① 的那个版本里 `parseInvCount` 的正则漏了 SNBT 的空格
// （`id:"…"` vs 实际 `id: "…"`）⇒ 把"服务端背包里明明有铁锭"报成 count=0。
// 重跑一趟要占泳道，而**原文 always 落盘**（raw 字段）⇒ 直接离线重算，不用再起服。
//
// 用法：node t10_truth_readout.mjs <furnace_truth.json>
// 输出：每臂逐轮的「服务端背包（before/after/closed）铁锭数」+ 增量，以及逐轮结论。

import fs from 'fs';

const path = process.argv[2];
if (!path) { console.error('用法：node t10_truth_readout.mjs <furnace_truth.json>'); process.exit(2); }
const j = JSON.parse(fs.readFileSync(path, 'utf8'));

/** 1.16.1 `data get entity` 的 SNBT 是 `{Slot: 8b, id: "minecraft:iron_ingot", Count: 1b}`（冒号后有空格） */
function ingots(raw) {
    if (!raw || !raw.includes('minecraft:iron_ingot')) return 0;
    const re = /id:\s*"minecraft:iron_ingot"\s*,\s*Count:\s*(\d+)b/g;
    const re2 = /Count:\s*(\d+)b\s*,\s*id:\s*"minecraft:iron_ingot"/g;
    let n = 0, m;
    while ((m = re.exec(raw)) !== null) n += parseInt(m[1], 10);
    while ((m = re2.exec(raw)) !== null) n += parseInt(m[1], 10);
    return n;
}

const arms = [...new Set(j.rounds.map((r) => r.arm))];
console.log(`# ① 服务端真值重算｜${j.stamp}｜lane=${j.lane}｜n=${j.n}｜arms=${arms.join(',')}`);
console.log('');
const table = [];
for (const arm of arms) {
    const rows = j.rounds.filter((r) => r.arm === arm);
    const per = rows.map((r) => {
        const b = ingots(r.serverInv_before?.raw);
        const a = ingots(r.serverInv_after?.raw);
        const c = ingots(r.serverInv_closed?.raw);
        return {
            arm, i: r.i, ok: r.result?.ok, clientGained: r.gained,
            srvBefore: b, srvAfter: a, srvClosed: c, srvDelta: a - b, srvDeltaClosed: c - b,
            cursorPkts: r.cursorPackets?.length ?? null, cursorGotProduct: r.cursorGotProduct,
            groundAfter: r.groundItems_after?.count ?? null, leak: r.leakedCursor || null, dest: r.result?.dest ?? null,
        };
    });
    table.push(...per);
    const okN = per.filter((p) => p.ok).length;
    const srvUp = per.filter((p) => p.srvDelta > 0).length;
    const srvUpClosed = per.filter((p) => p.srvDeltaClosed > 0).length;
    console.log(`## 臂 ${arm}：客户端判定 ${okN}/${per.length}｜服务端背包(取件后) +铁锭 ${srvUp}/${per.length}｜(关窗后) +铁锭 ${srvUpClosed}/${per.length}｜光标见过产物 ${per.filter((p) => p.cursorGotProduct).length}｜关窗时漏光标 ${per.filter((p) => p.leak).length}`);
    console.log('| i | ok | 客户端 gained | 服务端 before→after→closed | 服务端增量 | 光标包数 | dest | 地上掉落 | 漏光标 |');
    console.log('|---|---|---|---|---|---|---|---|---|');
    for (const p of per) console.log(`| ${p.i} | ${p.ok} | ${p.clientGained} | ${p.srvBefore}→${p.srvAfter}→${p.srvClosed} | ${p.srvDelta} | ${p.cursorPkts} | ${p.dest ?? '-'} | ${p.groundAfter} | ${p.leak ?? '-'} |`);
    console.log('');
}

// 全局：光标包里有没有出现过产物
const cursorNames = {};
for (const p of (j.global?.setSlotLog ?? [])) {
    if (!p.isCursor) continue;
    const k = p.itemName || '(empty)';
    cursorNames[k] = (cursorNames[k] ?? 0) + 1;
}
console.log('## 全局光标包（windowId=-1, slot=-1）内容分布：');
console.log('```');
for (const [k, v] of Object.entries(cursorNames)) console.log(`  ${v} × ${k}`);
console.log('```');
console.log(`transaction 总数=${j.global?.transactions?.length}｜window_items 总数=${j.global?.windowItemsLog?.length}｜set_slot 总数=${j.global?.setSlotLog?.length}`);
const rejected = (j.global?.transactions ?? []).filter((t) => t.accepted === false);
console.log(`服务端拒收的 transaction：${rejected.length} 条 ${JSON.stringify(rejected.slice(0, 8))}`);
