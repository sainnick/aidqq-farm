﻿// craft_bot_t09.mjs — MC-M1-TASK-09 微基准：三种丢件的「改前 / 改后」对照。
//
// 要回答的三个问题（派单 A 节）：
//   ① 三种丢件（工作台 3×3 / 2×2 背包 / 熔炉取产物）在**现网代码**上各复现多少？
//   ② 换成「自己一步步点 + 每步等服务端确认」（窗口操作确认化）后各是多少？验收线 ≥29/30。
//   ③ `_tableCraft`（自研 3×3 通道）在 1.16.1 上**到底能不能启用**？—— 本单订正了它此前
//      「发不出包」的结论，本基准用**实服**给出答案。
//
// 方法纪律（手册 §5 + ROUND3-A §3.2.6 的教训）：
//   · 探针**直接调任务层真代码**（`CraftingTask._doCraft` / `_selfCraft` / `_tableCraft`），
//     不是抄一份形状 —— 抄的形状测不出真 bug。
//   · kit 不用 `/say` 同步（1.16.1 没有 /say，MC-FRAME-BATCH-01 §4 已证）：改成
//     **轮询真实背包直到数量对上**（有界），这是自验证的，不依赖任何假同步通道。
//   · 布景后有**硬闸门**：工作台/熔炉/箱子读不到就立刻退出，不把假场景当数据（06c 教训）。
//   · 丢件是时序敏感竞态：每臂之间做热身，且**同一台服、同一条通道、同样次数**做对照。
//
// 用法：node craft_bot_t09.mjs --out <dir> --port 25566 --username TaskBot --n 30 [--arms old,self,tableCraft,furnace,chest]

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const OUT = path.resolve(arg('out', HERE));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const N = parseInt(arg('n', '30'), 10);
const WARMUP = parseInt(arg('warmup', '10'), 10);
const SETUP = path.join(OUT, 'setup.json');
const RES = path.join(OUT, 'craft_result.json');
const DONE = path.join(OUT, 'done.json');
for (const f of [RES, DONE]) { try { fs.rmSync(f, { force: true }); } catch { /* 忽略 */ } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[t09 ${new Date().toISOString().slice(11, 19)}] ${m}`);

const ARMS = (arg('arms', 'old,self,tableCraft,furnace,chest')).split(',').map((s) => s.trim()).filter(Boolean);

const { CraftingTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/crafting_task.js')).href);
const { takeFurnaceOutputConfirmed, withdrawFromContainerConfirmed, clickFlavor, countItemsWindowAware, closeWindowConfirmed } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/window_ops.js')).href);
const CLOSE_CONFIRMED = process.argv.includes('--close-confirmed');

async function main() {
    const mineflayer = require('mineflayer');
    const { Vec3 } = require('vec3');
    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: '1.16.1' });
    bot.loadPlugin(require('mineflayer-pathfinder').pathfinder);
    await new Promise((resolve, reject) => {
        bot.once('spawn', resolve); bot.once('error', reject); setTimeout(() => reject(new Error('spawn timeout')), 60000);
    });
    log(`spawned ${bot.entity.position.toArray().map((v) => v.toFixed(0))}｜协议 ${bot.version}｜窗口通道 ${JSON.stringify(clickFlavor(bot))}`);
    await sleep(3500);
    for (let i = 0; i < 120 && !fs.existsSync(SETUP); i++) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('no setup.json（runner 没 op）');

    // ── 假 ctx：形状与 runner 一致，telemetry 全收集（手册 §5：归因必须引用遥测）──
    const tele = [];
    const ctx = {
        bot,
        telemetry: (name, data) => { tele.push({ name, data, t: Date.now() }); },
        run: { counters: { craftAttempts: 0, craftFailures: 0, smeltOk: 0, smeltFailures: 0, replans: 0, recipeResolves: 0 } },
    };
    const count = (name) => bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0);

    // kit：发命令后**轮询真实背包**直到对上（有界）。不依赖 /say（1.16.1 没有）。
    const wants = {};
    async function kit(spec) {
        for (const k of Object.keys(wants)) delete wants[k];
        await bot.chat('/clear @s');
        await sleep(250);
        for (const [name, n] of Object.entries(spec)) {
            await bot.chat(`/give @s minecraft:${name} ${n}`);
            wants[name] = n;
        }
        // 有界轮询：数量对上就算到位
        const dl = Date.now() + 12000;
        while (Date.now() < dl) {
            const okAll = Object.entries(wants).every(([name, n]) => count(name) >= n);
            if (okAll) return true;
            await sleep(200);
        }
        log(`! kit 没到位：${Object.entries(wants).map(([k, v]) => `${k}=${count(k)}/${v}`).join(' ')}`);
        return false;
    }
    const KIT_BASE = { oak_planks: 16, cobblestone: 16, stick: 16, oak_log: 8 };

    // ── 布景 + 硬闸门 ──
    const SX = 200, SY = 68, SZ = 200;
    await bot.chat(`/tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`); await sleep(2500);
    await bot.chat(`/fill ${SX - 4} ${SY} ${SZ - 4} ${SX + 4} ${SY} ${SZ + 4} minecraft:stone`); await sleep(1200);
    await bot.chat(`/fill ${SX - 4} ${SY + 1} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:air`); await sleep(1200);
    await bot.chat(`/setblock ${SX + 1} ${SY + 1} ${SZ} minecraft:crafting_table`); await sleep(800);
    await bot.chat(`/setblock ${SX - 1} ${SY + 1} ${SZ} minecraft:furnace`); await sleep(800);
    await bot.chat(`/setblock ${SX + 3} ${SY + 1} ${SZ} minecraft:chest`); await sleep(800);
    await bot.chat(`/tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`); await sleep(2000);
    const table = bot.blockAt(new Vec3(SX + 1, SY + 1, SZ));
    const furnace = bot.blockAt(new Vec3(SX - 1, SY + 1, SZ));
    const chest = bot.blockAt(new Vec3(SX + 3, SY + 1, SZ));
    // 硬闸门：布景没建起来就退出，绝不产出"原语坏了"的假数据
    if (table?.name !== 'crafting_table' || furnace?.name !== 'furnace' || chest?.name !== 'chest') {
        throw new Error(`布景硬闸门未过 table=${table?.name} furnace=${furnace?.name} chest=${chest?.name}`);
    }
    log(`布景就绪：工作台 @${SX + 1},${SY + 1},${SZ}｜熔炉 @${SX - 1},${SY + 1},${SZ}｜箱子 @${SX + 3},${SY + 1},${SZ}`);

    const rows = [];
    const task = new CraftingTask({ item: 'stick', count: 1, craftChannel: 'self' });

    function rec(row) { rows.push(row); return row; }
    function flush() {
        fs.writeFileSync(RES, JSON.stringify({ rows, telemetry: tele, note: 'TASK-09 三种丢件改前/改后对照' }, null, 2));
    }

    // ── 合成臂 ──
    // cell: {item, channel: 'table'|'inv2x2', arm: 'old'|'self'|'tableCraft'}
    const CRAFT_CELLS = [
        { item: 'stick', channel: 'table', kit: { ...KIT_BASE } },
        { item: 'oak_planks', channel: 'table', kit: { ...KIT_BASE } },
        { item: 'wooden_pickaxe', channel: 'table', kit: { ...KIT_BASE } },
        { item: 'stone_pickaxe', channel: 'table', kit: { ...KIT_BASE } },
        { item: 'stick', channel: 'inv2x2', kit: { ...KIT_BASE } },
        { item: 'oak_planks', channel: 'inv2x2', kit: { ...KIT_BASE } },
        { item: 'wooden_pickaxe', channel: 'inv2x2', kit: { ...KIT_BASE } },
    ];
    async function runCraftCell(cell, arm, n) {
        for (let i = 0; i < n; i++) {
            if (!(await kit(cell.kit))) { rec({ kind: 'craft', cell: cellName(cell, arm), arm, i, verified: false, err: 'kit_failed' }); continue; }
            const tableBlock = cell.channel === 'table' ? table : null;
            const itemId = bot.registry.itemsByName[cell.item]?.id;
            const recipes = bot.recipesFor(itemId, null, 1, tableBlock);
            if (!recipes.length) {
                // 3×3 配方进不了 2×2 = 结构性拒绝，**不是 bug**（06d 已定案），单列不算失败
                rec({ kind: 'craft', cell: cellName(cell, arm), arm, i, item: cell.item, channel: cell.channel, noRecipe: true, verified: false, err: 'no_recipe_in_channel' });
                continue;
            }
            const recipe = recipes[0];
            const before = count(cell.item);
            const t0 = Date.now();
            let err = null;
            const teleMark = tele.length;
            try {
                if (arm === 'old') {
                    // 现网口径：mineflayer 原生 bot.craft（收尾 grabResult 会伪造产物槽）
                    await bot.craft(recipe, 1, tableBlock);
                } else if (arm === 'tableCraft') {
                    const r = await task._tableCraft(ctx, tableBlock, recipe);
                    if (!r) err = 'tableCraft_false';
                } else {
                    const r = await task._doCraft(ctx, recipe, 1, tableBlock);
                    if (!r) err = 'doCraft_false';
                }
            } catch (e) { err = String(e && e.message ? e.message : e).slice(0, 180); }
            const ms = Date.now() - t0;
            // 按背包增量确认（手册 §3）——所有臂同一判据，才叫对照
            let gained = count(cell.item) - before;
            const dl = Date.now() + 1200;
            while (gained <= 0 && Date.now() < dl) { await sleep(150); gained = count(cell.item) - before; }
            try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow); } catch { /* 忽略 */ }
            await sleep(200);
            rec({
                kind: 'craft', cell: cellName(cell, arm), arm, i, item: cell.item, channel: cell.channel,
                noThrow: !err, err, ms, gained, verified: gained > 0,
                tele: tele.slice(teleMark).map((t) => t.name).join(','),
                inv: ['oak_planks', 'cobblestone', 'stick', 'oak_log'].map((n) => `${n}=${count(n)}`).join(','),
            });
            if ((i + 1) % 10 === 0) {
                const rs = rows.filter((r) => r.cell === cellName(cell, arm));
                flush();
                log(`${cellName(cell, arm)} ${i + 1}/${n}：verified=${rs.filter((r) => r.verified).length} 失败=${rs.filter((r) => !r.verified && !r.noRecipe).length}`);
            }
        }
    }
    const cellName = (cell, arm) => `${cell.item}/${cell.channel}/${arm}`;

    if (ARMS.includes('old') || ARMS.includes('self') || ARMS.includes('tableCraft')) {
        // --cells 过滤：合成臂的验收线只压在有意义的格子上。
        //   3×3 配方进 2×2 是**结构性拒绝**（recipesFor 直接不给配方），只留 1 次留档，
        //   不占 30 次的机器时间（06d 已定案：这不是 bug）。
        const want = (arg('cells', '') || '').split(',').map((s) => s.trim()).filter(Boolean);
        const cells = CRAFT_CELLS.filter((c) => {
            if (!want.length) return true;
            if (!want.includes(c.item) && !want.includes(`${c.item}/${c.channel}`)) return false;
            return true;
        });
        // tableCraft 是"1.16.1 能不能启用"的**能力问题**，不是验收线，给 --tablecraft-n 次即可
        const tcN = parseInt(arg('tablecraft-n', String(N)), 10);
        for (const cell of cells) {
            const structural = (cell.channel === 'inv2x2') && cell.item.endsWith('_pickaxe');
            const reps = structural ? 1 : N;
            if (WARMUP > 0 && !structural) { log(`热身 ${cellName(cell, 'warmup')} ×${WARMUP}`); await runCraftCell(cell, 'self', WARMUP); }
            for (const arm of ARMS.filter((a) => ['old', 'self', 'tableCraft'].includes(a))) {
                if (arm === 'tableCraft' && cell.channel !== 'table') continue;
                const n = arm === 'tableCraft' ? Math.min(tcN, reps) : reps;
                log(`▶ ${cellName(cell, arm)} ×${n}`);
                await runCraftCell(cell, arm, n);
                flush();
            }
        }
    }

    // ── 熔炉取产物臂 ──
    if (ARMS.includes('furnace')) {
        for (const arm of ['old', 'self']) {
            log(`▶ furnace/take/${arm} ×${N}`);
            for (let i = 0; i < N; i++) {
                if (!(await kit({ ...KIT_BASE, coal: 1, iron_ore: 8 }))) { rec({ kind: 'furnace', cell: `furnace/take/${arm}`, arm, i, verified: false, err: 'kit_failed' }); continue; }
                // ⚠ **每轮换一口新炉**（先 air 再 furnace）。原因：熔炉是**跨轮次累积**的——
                //   每次投 8 个矿石、只取走产物，30 轮下来炉子的输入格会堆满，
                //   于是 `putInput` 抛 mineflayer 的 `destination full`
                //   （inventory.js:330，putSelectedItemRange 里），两个臂都会被污染成假失败。
                //   探针第一版就栽在这里：old 臂 0/5、self 臂 30/30 全是 `destination full`，
                //   **没有一个是真正的取件失败**。造场景必须每轮复位（手册 §5「同口径」）。
                await bot.chat(`/setblock ${SX - 1} ${SY + 1} ${SZ} minecraft:air`); await sleep(350);
                await bot.chat(`/setblock ${SX - 1} ${SY + 1} ${SZ} minecraft:furnace`); await sleep(500);
                const furnaceBlock = bot.blockAt(new Vec3(SX - 1, SY + 1, SZ));
                if (furnaceBlock?.name !== 'furnace') { rec({ kind: 'furnace', cell: `furnace/take/${arm}`, arm, i, verified: false, err: `scene_gate:${furnaceBlock?.name}` }); continue; }
                // 开炉 → 投料 → 等产物（真实熔炼时间；用煤一次烧 8 个，省得反复点）
                let furnaceWin = null;
                try {
                    furnaceWin = await bot.openFurnace(furnaceBlock);
                    await sleep(400);
                    await furnaceWin.putInput(bot.registry.itemsByName.iron_ore.id, null, 8);
                    await sleep(400);
                    await furnaceWin.putFuel(bot.registry.itemsByName.coal.id, null, 1);
                    // 等产物出现在**服务端**输出格（轮询 model，服务端 set_slot 驱动的）
                    const wdl = Date.now() + 25000;
                    while (!(furnaceWin.slots[2]?.count > 0) && Date.now() < wdl) await sleep(300);
                    if (!(furnaceWin.slots[2]?.count > 0)) {
                        rec({ kind: 'furnace', cell: `furnace/take/${arm}`, arm, i, verified: false, err: 'no_output', waited: 25000 });
                        try { bot.closeWindow(furnaceWin); } catch { /* 忽略 */ }
                        continue;
                    }
                    const outCount = furnaceWin.slots[2].count;
                    // ⚠ 必须用**窗口感知**计数：熔炉开着时，服务端把产物放进的是熔炉窗口的
                    //   镜像背包区，`bot.inventory` 读 0 —— 探针第一版就是栽在这里，
                    //   把「old 臂 0/5」误报成"复现了 smelt 丢件"，其实是自己读错了地方。
                    const before = countItemsWindowAware(bot, 'iron_ingot', furnaceWin);
                    const t0 = Date.now();
                    let err = null, reason = null;
                    if (arm === 'old') {
                        // 现网口径：furnace.takeOutput()（= putAway 复合动作）
                        await furnaceWin.takeOutput();
                    } else {
                        const r = await takeFurnaceOutputConfirmed(bot, furnaceWin, { timeoutMs: 2500, itemName: 'iron_ingot', expectName: 'iron_ingot' });
                        if (!r.ok) { reason = r.reason; err = `take_fail:${r.reason}`; }
                    }
                    const ms = Date.now() - t0;
                    let gained = countItemsWindowAware(bot, 'iron_ingot', furnaceWin) - before;
                    const dl = Date.now() + 2500;
                    while (gained <= 0 && Date.now() < dl) { await sleep(150); gained = countItemsWindowAware(bot, 'iron_ingot', furnaceWin) - before; }
                    rec({
                        kind: 'furnace', cell: `furnace/take/${arm}`, arm, i, outCount, noThrow: !err, err, reason, ms, gained,
                        verified: gained > 0,
                        stillInFurnace: furnaceWin.slots[2]?.count ?? 0,
                        held: bot.heldItem ? `${bot.heldItem.name}x${bot.heldItem.count}` : 'none',
                    });
                    // ═══ MC-M1-TASK-09-r2：关窗口径 A/B 开关 ═══
                    // 默认 false = **历史口径**（fire-and-forget），保留下划线可复现 1/30 的那个数。
                    // true  = 等服务端真的把窗关掉（任务层 closeWindowConfirmed）。
                    // 见 docs/MC-M1-TASK-09-r2.md §4.2：这一行是历史 2/30 的根因。
                    if (CLOSE_CONFIRMED) { try { await closeWindowConfirmed(bot, furnaceWin); } catch { /* 忽略 */ } }
                    else { try { bot.closeWindow(furnaceWin); } catch { /* 忽略 */ } }
                } catch (e) {
                    rec({ kind: 'furnace', cell: `furnace/take/${arm}`, arm, i, verified: false, err: String(e && e.message ? e.message : e).slice(0, 180) });
                    try { if (furnaceWin) bot.closeWindow(furnaceWin); } catch { /* 忽略 */ }
                }
                if ((i + 1) % 5 === 0) {
                    const rs = rows.filter((r) => r.cell === `furnace/take/${arm}`);
                    flush();
                    log(`furnace/take/${arm} ${i + 1}/${N}：verified=${rs.filter((r) => r.verified).length} 失败=${rs.filter((r) => !r.verified).length}`);
                }
            }
            flush();
        }
    }

    // ── 开箱取物臂（1.16.1 的箱子是 requiresConfirmation=false 的那一类）──
    if (ARMS.includes('chest')) {
        log(`▶ chest/take/self ×${N}`);
        for (let i = 0; i < N; i++) {
            if (!(await kit({ ...KIT_BASE }))) { rec({ kind: 'chest', cell: 'chest/take/self', arm: 'self', i, verified: false, err: 'kit_failed' }); continue; }
            // 每次把箱子内容重置成已知值（服务端权威）
            await bot.chat(`/setblock ${SX + 3} ${SY + 1} ${SZ} minecraft:chest`); await sleep(500);
            await bot.chat(`/data merge block ${SX + 3} ${SY + 1} ${SZ} {Items:[{Slot:0b,id:"minecraft:oak_log",Count:4b},{Slot:1b,id:"minecraft:cobblestone",Count:7b}]}`); await sleep(500);
            await bot.chat(`/tp ${SX + 2.5} ${SY + 1} ${SZ + 0.5}`); await sleep(800);
            let container = null;
            try {
                container = await bot.openContainer(chest);
                await sleep(500);
                // 同上：箱子开着时物品落在箱子窗口的镜像区，必须窗口感知计数
                const before = countItemsWindowAware(bot, 'oak_log', container);
                const t0 = Date.now();
                const r = await withdrawFromContainerConfirmed(bot, container, (s) => s.name === 'oak_log', { timeoutMs: 2000 });
                const ms = Date.now() - t0;
                const gained = countItemsWindowAware(bot, 'oak_log', container) - before;
                rec({
                    kind: 'chest', cell: 'chest/take/self', arm: 'self', i, noThrow: true,
                    err: r.ok ? null : `withdraw_fail:${r.failed.map((f) => f.reason).join('|')}`,
                    ms, gained, verified: r.ok && gained > 0,
                    taken: JSON.stringify(r.taken), failed: r.failed.length,
                });
                try { bot.closeWindow(container); } catch { /* 忽略 */ }
            } catch (e) {
                rec({ kind: 'chest', cell: 'chest/take/self', arm: 'self', i, verified: false, err: String(e && e.message ? e.message : e).slice(0, 180) });
                try { if (container) bot.closeWindow(container); } catch { /* 忽略 */ }
            }
            if ((i + 1) % 10 === 0) {
                const rs = rows.filter((r) => r.cell === 'chest/take/self');
                flush();
                log(`chest/take/self ${i + 1}/${N}：verified=${rs.filter((r) => r.verified).length}`);
            }
        }
    }

    // ── 汇总 ──
    const agg = {};
    for (const r of rows) {
        if (r.noRecipe) continue;   // 结构性拒绝不算成绩
        const k = r.cell;
        if (!agg[k]) agg[k] = { kind: r.kind, arm: r.arm, n: 0, verified: 0, noRecipe: 0, ms: [], errs: {}, reasons: {} };
        agg[k].n++;
        if (r.verified) agg[k].verified++;
        const ms = r.ms ?? 0;
        agg[k].ms.push(ms);
        if (r.err) agg[k].errs[r.err] = (agg[k].errs[r.err] ?? 0) + 1;
        if (r.reason) agg[k].reasons[r.reason] = (agg[k].reasons[r.reason] ?? 0) + 1;
    }
    for (const v of Object.values(agg)) {
        v.ms.sort((a, b) => a - b);
        v.medianMs = v.ms[Math.floor((v.ms.length - 1) / 2)] ?? 0;
        v.rate = v.n ? +((v.verified / v.n) * 100).toFixed(1) : 0;
        delete v.ms;
    }
    const out = { cells: agg, rows, telemetry: tele, note: 'TASK-09 三种丢件改前/改后对照' };
    fs.writeFileSync(RES, JSON.stringify(out, null, 2));
    fs.writeFileSync(DONE, JSON.stringify({ done: true }));
    log('=== 汇总 ===');
    for (const [k, v] of Object.entries(agg)) log(`${k}: ${v.verified}/${v.n} = ${v.rate}%  中位 ${v.medianMs}ms  errs ${JSON.stringify(v.errs)} ${Object.keys(v.reasons).length ? 'reasons ' + JSON.stringify(v.reasons) : ''}`);
    bot.quit();
    process.exit(0);
}
main().catch((e) => { log(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 600)}`); try { fs.writeFileSync(DONE, JSON.stringify({ done: true, fatal: true })); } catch { /* 忽略 */ } process.exit(1); });
