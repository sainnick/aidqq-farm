// t09r3_acceptance.mjs — MC-M1-TASK-09-r3 验收统计（纯离线，不开服不占端口）
//
// 干什么：把「窗口操作层」与「整局层」两层验收从落盘数据里算出来，避免人工数。
//   窗口操作层：smelt_take_unverified / craft_error / craft_fail 必须归零；
//                craft_replan 按 why + childReason 拆开（它本身不是窗口原语事件，
//                是上游资源/物流失败的下游表现 —— 手册 §5「归因必须引用遥测」）。
//   整局层    ：每个 run 的 success/total（iron 期望 5/5，M4B4 期望 ≥19/20）。
//
// 口径纪律（手册 §5，本脚本内置）：
//   · **「没读到」与「读到 0」分开**：`telemetry.jsonl` 缺失/解析失败 ⇒ 该 trial 记
//     `TELEMETRY_MISSING`，**不**当成 0 事件（否则会把「遥测自己坏了」读成「全绿」）。
//   · 每个计数都同时给出「该事件名在本语料里是否出现过」，便于事后分辨
//     「原语从未触发」和「原语触发了但没记账」。
//
// 用法：
//   node t09r3_acceptance.mjs --runs <runDir1,runDir2> [--json out.json]
//   node t09r3_acceptance.mjs --runs ... --min-total 5 --min-success 5

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
void HERE;

const argv = process.argv.slice(2);
const argOf = (n, d) => { const i = argv.indexOf(`--${n}`); return i >= 0 ? argv[i + 1] : d; };
const RUNS = (argOf('runs', '') || '').split(',').map((s) => s.trim()).filter(Boolean);
const JSON_OUT = argOf('json', '');
const MIN_TOTAL = parseInt(argOf('min-total', '0'), 10);
const MIN_SUCCESS = parseInt(argOf('min-success', '0'), 10);

// —— 窗口操作层必须归零的三个事件（按名称精确匹配，不用前缀）——
const MUST_BE_ZERO = ['smelt_take_unverified', 'craft_error', 'craft_fail'];
// —— 参考计数（不判达标，只让人看见原语到底跑没跑）——
const REFERENCE = ['smelt_start', 'smelt_take_checked', 'smelt_ok', 'craft_ok', 'craft_unverified',
    'craft_no_gain', 'table_craft_no_result', 'table_craft_click_rejected', 'self_craft_click_rejected'];

function readJsonl(p) {
    const txt = fs.readFileSync(p, 'utf8').replace(/\r/g, '');
    return txt.split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l); } catch { return null; } });
}

function trialDirs(runDir) {
    if (!fs.existsSync(runDir)) return { error: `run 目录不存在：${runDir}` };
    const subs = fs.readdirSync(runDir).filter((s) => /^trial_\d+$/.test(s) && fs.statSync(path.join(runDir, s)).isDirectory());
    if (subs.length) return subs.sort().map((s) => path.join(runDir, s));
    if (fs.existsSync(path.join(runDir, 'server.log'))) return [runDir];
    return { error: `${runDir} 下既没有 trial_XX 也没有 server.log` };
}

const rows = [];
const runSummaries = [];

for (const runDir of RUNS) {
    const tds = trialDirs(runDir);
    if (!Array.isArray(tds)) { runSummaries.push({ run: runDir, error: tds.error }); continue; }
    let meta = {};
    try { meta = JSON.parse(fs.readFileSync(path.join(runDir, 'run_meta.json'), 'utf8')); } catch { meta = {}; }
    let success = 0, total = 0;
    for (const td of tds) {
        const name = path.basename(td);
        // —— result.json ——
        let res = null, resErr = null;
        const rj = path.join(td, 'result.json');
        if (fs.existsSync(rj)) { try { res = JSON.parse(fs.readFileSync(rj, 'utf8')); } catch (e) { resErr = String(e).slice(0, 80); } }
        else resErr = 'result.json 缺失';

        // —— telemetry.jsonl（缺失 ≠ 0）——
        const tj = path.join(td, 'telemetry.jsonl');
        let evs = null, teleErr = null, seen = new Set();
        if (fs.existsSync(tj)) {
            const parsed = readJsonl(tj);
            const bad = parsed.filter((x) => x === null).length;
            evs = parsed.filter(Boolean);
            if (bad) teleErr = `${bad} 行解析失败`;
            if (!evs.length) { teleErr = 'telemetry.jsonl 为空'; evs = null; }
        } else teleErr = 'telemetry.jsonl 缺失';

        const counts = {}; const replans = [];
        if (evs) {
            for (const e of evs) {
                seen.add(e.event);
                counts[e.event] = (counts[e.event] || 0) + 1;
                if (e.event === 'craft_replan') replans.push({ item: e.item, why: e.why, childReason: e.childReason, step: e.step });
            }
        }
        const outcome = res?.outcome ?? res?.status ?? (resErr ? 'UNKNOWN' : 'UNKNOWN');
        if (String(outcome).startsWith('SUCCESS')) success++;
        total++;

        rows.push({
            run: path.basename(runDir), trial: name,
            seed: res?.result?.seed ?? res?.seed ?? null,
            outcome, durationMs: res?.result?.durationMs ?? res?.durationMs ?? null,
            deathsMetrics: res?.result?.metrics?.deaths ?? null,
            telemetryOk: !!evs, telemetryErr: teleErr, resultErr: resErr,
            counts, replans,
            mustZero: Object.fromEntries(MUST_BE_ZERO.map((k) => [k, evs ? (counts[k] || 0) : null])),
            reference: Object.fromEntries(REFERENCE.map((k) => [k, evs ? (counts[k] || 0) : null])),
            eventsSeen: [...seen].sort(),
        });
    }
    runSummaries.push({
        run: path.basename(runDir), stage: meta.stage ?? null, trials: total, success,
        successRate: total ? +(success / total).toFixed(4) : null,
    });
}

// ———————————————————————— 输出 ————————————————————————
const pad = (s, n) => String(s ?? '-').padEnd(n);
const out = [];
out.push('=== TASK-09-r3 验收统计（窗口操作层 / 整局层）===\n');

out.push('【整局层】');
out.push(['run', 'stage', 'trials', 'success', 'rate'].join('\t'));
for (const r of runSummaries) {
    out.push(r.error
        ? [r.run, '-', '-', '-', `ERROR: ${r.error}`].join('\t')
        : [r.run, r.stage ?? '-', r.trials, r.success, r.successRate].join('\t'));
}

out.push('\n【逐局】');
out.push(['run/trial', 'outcome', 'sec', 'deaths(metrics)', 'telemetry', 'unverified', 'craft_error', 'craft_fail', 'craft_ok', 'smelt_checked', 'smelt_unver', 'replan'].join('\t'));
for (const r of rows) {
    out.push([
        `${r.run}/${r.trial}`,
        r.outcome,
        r.durationMs ? (r.durationMs / 1000).toFixed(1) : '-',
        r.deathsMetrics ?? '-',
        r.telemetryOk ? 'ok' : `MISSING(${r.telemetryErr})`,
        r.mustZero.smelt_take_unverified ?? 'n/a',
        r.mustZero.craft_error ?? 'n/a',
        r.mustZero.craft_fail ?? 'n/a',
        r.reference.craft_ok ?? 'n/a',
        r.reference.smelt_take_checked ?? 'n/a',
        r.reference.smelt_ok ?? 'n/a',
        r.replans.length,
    ].join('\t'));
}

out.push('\n【窗口操作层：四事件合计】');
const totals = {};
for (const k of MUST_BE_ZERO) totals[k] = 0;
const refTotals = {};
for (const k of REFERENCE) refTotals[k] = 0;
let missingTele = 0;
for (const r of rows) {
    if (!r.telemetryOk) { missingTele++; continue; }
    for (const k of MUST_BE_ZERO) totals[k] += r.mustZero[k];
    for (const k of REFERENCE) refTotals[k] += r.reference[k];
}
for (const k of MUST_BE_ZERO) out.push(`  ${pad(k, 24)} ${totals[k]}`);
out.push('  —— 参考计数（不判达标）——');
for (const k of REFERENCE) out.push(`  ${pad(k, 24)} ${refTotals[k]}`);

out.push('\n【craft_replan 逐条归因】');
if (!rows.some((r) => r.replans.length)) out.push('  （一条都没有）');
for (const r of rows) {
    for (const p of r.replans) {
        out.push(`  ${r.run}/${r.trial}  item=${p.item}  why=${p.why}  childReason=${p.childReason ?? '-'}  step=${p.step ?? '-'}`);
    }
}

const teleOkRows = rows.filter((r) => r.telemetryOk).length;
const windowLayerPass = missingTele === 0 && MUST_BE_ZERO.every((k) => totals[k] === 0);
out.push(`\n【判定】`);
out.push(`  遥测可读的局：${teleOkRows}/${rows.length}（读不到的 ${missingTele} 局**不计入 0**）`);
out.push(`  窗口操作层：${windowLayerPass ? '✅ 归零' : '❌ 未归零'}`);
const runPass = runSummaries.every((r) => !r.error && r.trials >= MIN_TOTAL && r.success >= MIN_SUCCESS);
if (MIN_TOTAL > 0 || MIN_SUCCESS > 0) {
    out.push(`  整局层：${runPass ? '✅' : '❌'}（门槛 total≥${MIN_TOTAL} 且 success≥${MIN_SUCCESS}）`);
}
if (!teleOkRows) out.push('  ⚠ 一局遥测都没读到 ⇒ 本次统计**不能**用于判定（工具自身失效）');

const text = out.join('\n');
console.log(text);
if (JSON_OUT) { fs.writeFileSync(JSON_OUT, JSON.stringify({ runSummaries, rows, totals, refTotals, windowLayerPass, teleOkRows }, null, 2)); console.log(`\n[json] ${JSON_OUT}`); }
process.exit(windowLayerPass ? 0 : 2);
