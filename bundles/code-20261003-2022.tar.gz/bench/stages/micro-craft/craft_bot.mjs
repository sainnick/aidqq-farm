// craft_bot.mjs — MC-M1-TASK-06d P1-2：背包合成（2×2 window 0）vs 工作台（3×3）的 A/B 微基准。
//
// 要回答的问题（06c P2b 归因）：「合成通道从 window 3 / 1-of-13 恶化到 window 0 / 15-of-23」
// 到底是「2×2 背包通道本身坏了」还是别的因素？做法：同一个 bot、同一批材料，把两条通道各跑 N 次，
// 逐次记录：是否成功、window id（bot.currentWindow?.id）、耗时、报错文本、成品是否进背包。
// 格子：{背包,工作台} × {wooden_pickaxe, stone_pickaxe}。
//
// 任务层走的是 crafting_task._doCraft：1.16.x 一律 bot.craft(recipe, ops, tableBlock)，
// tableBlock 为 null = 2×2 背包通道；非 null = 工作台通道。本基准逐字照抄这个调用形状。
//
// 用法：node craft_bot.mjs --out <dir> --port 25566 --username TaskBot --n 30

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const OUT = path.resolve(arg('out', HERE));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const N = parseInt(arg('n', '30'), 10);
const SETUP = path.join(OUT, 'setup.json');
const RES = path.join(OUT, 'craft_result.json');
const DONE = path.join(OUT, 'done.json');
for (const f of [RES, DONE]) { try { fs.rmSync(f, { force: true }); } catch { /* 忽略 */ } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[craft ${new Date().toISOString().slice(11, 19)}] ${m}`);

// 合成格子。`dirty=true` = 每次尝试前先开关一次熔炉窗口，再立刻合成——
// 复现 06c P2b t01 的真实序列（丢镐时刚在熔炼，craft 报 window 0 事务被拒）。
const CELLS = [
    { item: 'stick', channel: 'inv2x2' },              // 2×2 基准（1 木板 → 4 木棍）
    { item: 'stick', channel: 'inv2x2', dirty: true },   // ★ 2×2 + 刚关过熔炉窗口
    { item: 'stick', channel: 'table' },                // 同配方走工作台（对照）
    { item: 'oak_planks', channel: 'inv2x2' },          // 另一个 2×2 配方
    { item: 'wooden_pickaxe', channel: 'table' },       // 3×3 配方走工作台
    { item: 'wooden_pickaxe', channel: 'inv2x2' },      // ★ 3×3 配方硬塞 2×2（recipesFor 应直接拒绝）
    { item: 'stone_pickaxe', channel: 'table' },
    { item: 'stone_pickaxe', channel: 'inv2x2' },
];

async function main() {
    const mineflayer = require('mineflayer');
    const { Vec3 } = require('vec3');
    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: '1.16.1' });
    bot.loadPlugin(require('mineflayer-pathfinder').pathfinder);
    await new Promise((resolve, reject) => {
        bot.once('spawn', resolve); bot.once('error', reject); setTimeout(() => reject(new Error('spawn timeout')), 60000);
    });
    log(`spawned ${bot.entity.position.toArray().map((v) => v.toFixed(0))}`);
    await sleep(3500);
    for (let i = 0; i < 120 && !fs.existsSync(SETUP); i++) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('no setup.json（runner 没 op）');

    let seq = 0, msgQueue = [];
    bot.on('message', (m) => { try { msgQueue.push(String(m.toString ? m.toString() : m)); } catch { msgQueue.push('?'); } });
    async function cmd(text, { waitMs = 700 } = {}) {
        const id = `@@C${++seq}`;
        msgQueue = [];
        bot.chat(`/say ${id}`);
        const t0 = Date.now();
        while (Date.now() - t0 < 3000 && !msgQueue.some((s) => s.includes(id))) await sleep(25);
        msgQueue = [];
        bot.chat(`/${text}`);
        const tw = Date.now();
        while (Date.now() - tw < waitMs && !msgQueue.length) await sleep(25);
        await sleep(40);
        const r = msgQueue.join(' | '); msgQueue = []; return r;
    }
    const count = (name) => bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0);

    // 摆一个工作台（1.16.1 放 2×2 在 y-1 的面上方即可），位置记在 bench 侧，不进任务层
    const SX = 200, SY = 68, SZ = 200;
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(2000);
    await cmd(`fill ${SX - 4} ${SY} ${SZ - 4} ${SX + 4} ${SY} ${SZ + 4} minecraft:stone`, { waitMs: 900 });
    await cmd(`fill ${SX - 4} ${SY + 1} ${SZ - 4} ${SX + 4} ${SY + 4} ${SZ + 4} minecraft:air`, { waitMs: 900 });
    await cmd(`setblock ${SX + 1} ${SY + 1} ${SZ} minecraft:crafting_table`, { waitMs: 700 });
    await cmd(`setblock ${SX - 1} ${SY + 1} ${SZ} minecraft:furnace`, { waitMs: 700 });
    await cmd(`tp ${SX + 0.5} ${SY + 1} ${SZ + 0.5}`, { waitMs: 500 }); await sleep(1500);
    const table = bot.blockAt(new Vec3(SX + 1, SY + 1, SZ));
    const furnace = bot.blockAt(new Vec3(SX - 1, SY + 1, SZ));
    log(`工作台 ${table?.name} @${SX + 1}｜熔炉 ${furnace?.name} @${SX - 1}（当前窗口 id=${bot.currentWindow?.id ?? 'null'}）`);

    const rows = [];
    for (const cell of CELLS) {
        for (let i = 0; i < N; i++) {
            // 每轮清干净背包 + 补料（kit 走服务器控制台，坐标只在 bench 侧）
            for (const junk of ['wooden_pickaxe', 'stone_pickaxe', 'stick', 'oak_planks', 'cobblestone', 'oak_log']) {
                await cmd(`clear @s minecraft:${junk}`, { waitMs: 120 });
            }
            await cmd(`give @s minecraft:oak_planks 16`, { waitMs: 200 });
            await cmd(`give @s minecraft:cobblestone 16`, { waitMs: 200 });
            // 镐的配方要木棍、木板（原木→木板）也要原木；缺哪样 recipesFor 就直接不给配方
            await cmd(`give @s minecraft:stick 16`, { waitMs: 200 });
            await cmd(`give @s minecraft:oak_log 8`, { waitMs: 200 });
            await sleep(400);
            // dirty 格子：先开关一次熔炉窗口，立刻再合成（复现 06c t01 的序列）
            let afterWindow = null;
            if (cell.dirty && furnace) {
                try {
                    await bot.activateBlock(furnace);
                    await sleep(350);
                    afterWindow = bot.currentWindow?.id ?? null;
                    bot.closeWindow(bot.currentWindow);
                } catch { /* 忽略 */ }
                await sleep(120);
            }
            const tableBlock = cell.channel === 'table' ? table : null;
            const itemId = bot.registry.itemsByName[cell.item]?.id;
            const recipes = bot.recipesFor(itemId, null, 1, tableBlock);
            if (!recipes.length) {
                // ★ 这本身是一条数据：recipesFor 拿不到配方 = **这条通道根本造不出这个物品**
                //   （镐是 3×3 配方，2×2 背包网格放不下）。06c P2b 的「补镐时背包合成被拒」
                //   正是任务层在没有工作台时仍去试 2×2 通道。逐次留档，不算成功也不算失败。
                rows.push({
                    cell: `${cell.item}/${cell.channel}${cell.dirty ? '+dirty' : ``}`, item: cell.item, channel: cell.channel, dirty: !!cell.dirty, i,
                    noThrow: false, err: 'no_recipe_in_channel', noRecipe: true, ms: 0, gained: 0,
                    verified: false, winBefore: bot.currentWindow?.id ?? null, winAfter: null, inv: '',
                });
                log(`· ${cell.item}/${cell.channel}：该通道拿不到配方（3×3 配方进不了 2×2）`);
                continue;
            }
            const recipe = recipes[0];
            const before = count(cell.item);
            const winBefore = bot.currentWindow?.id ?? null;
            const t0 = Date.now();
            let err = null, ok = false;
            try {
                // 逐字照抄 crafting_task._doCraft 的 1.16.x 分支：每次只做 1 个 op
                // （crafting_task.js:285 `const ops = 1`；dev2 实测多 op 连发必被服务端拒）
                await Promise.race([
                    bot.craft(recipe, 1, tableBlock),
                    sleep(10000).then(() => { throw new Error('craft_timeout'); }),
                ]);
                ok = true;
            } catch (e) { err = String(e && e.message ? e.message : e).slice(0, 160); }
            const ms = Date.now() - t0;
            // 按背包增量确认（手册 §3）
            let gained = count(cell.item) - before;
            const dl = Date.now() + 2000;
            while (gained <= 0 && Date.now() < dl) { await sleep(150); gained = count(cell.item) - before; }
            try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow); } catch { /* 忽略 */ }
            const row = {
                cell: `${cell.item}/${cell.channel}${cell.dirty ? '+dirty' : ``}`, item: cell.item, channel: cell.channel, dirty: !!cell.dirty, i,
                noThrow: ok, err, ms, gained,
                verified: gained > 0,
                afterWindow,
                winBefore, winAfter: bot.currentWindow?.id ?? null,
                inv: ['oak_planks', 'cobblestone', 'stick', 'oak_log'].map((n) => `${n}=${count(n)}`).join(','),
            };
            rows.push(row);
            if ((i + 1) % 10 === 0) log(`${cell.item}/${cell.channel} ${i + 1}/${N}：verified=${rows.filter((r) => r.cell === row.cell && r.verified).length} 失败=${rows.filter((r) => r.cell === row.cell && !r.verified).length}`);
        }
    }
    const agg = {};
    for (const c of CELLS) {
        const key = `${c.item}/${c.channel}`;
        const rs = rows.filter((r) => r.cell === key);
        if (!rs.length) continue;
        const errs = {};
        for (const r of rs) if (r.err) errs[r.err] = (errs[r.err] ?? 0) + 1;
        agg[key] = {
            n: rs.length, verified: rs.filter((r) => r.verified).length,
            noThrow: rs.filter((r) => r.noThrow).length,
            rate: +((rs.filter((r) => r.verified).length / rs.length) * 100).toFixed(1),
            medianMs: rs.map((r) => r.ms).sort((a, b) => a - b)[Math.floor((rs.length - 1) / 2)],
            errs,
        };
    }
    fs.writeFileSync(RES, JSON.stringify({ cells: agg, rows, note: '2×2=window 0 背包通道，table=工作台通道' }, null, 2));
    fs.writeFileSync(DONE, JSON.stringify({ done: true }));
    log('=== 汇总 ===');
    for (const [k, v] of Object.entries(agg)) log(`${k}: ${v.verified}/${v.n} = ${v.rate}%  中位 ${v.medianMs}ms  报错 ${JSON.stringify(v.errs)}`);
    bot.quit();
    process.exit(0);
}
main().catch((e) => { log(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 400)}`); process.exit(1); });
