// t09_report.mjs — TASK-09：把微基准结果整理成可直接贴进报告的表。
//
// ⚠ 一个必须说清的口径问题：探针里**热身行和正式行用同一个 cell 名**
// （`runCraftCell(cell,'self',WARMUP)` 走的是同一个 cellName），所以
// `stick/table/self` 的行数 = 热身 8 + 正式 30 = 38。
// 本脚本按**行序**切：每个 (cell,arm) 分组里，热身总是**最先**出现的那批
// （主循环顺序固定为 warmup → old → self → tableCraft），且热身只跑 'self' 臂。
// 切完再算合格率，避免把热身的成功算进正式成绩。
//
// 用法：node t09_report.mjs <run_dir> [--warmup 8]

import fs from 'fs';
import path from 'path';

const dir = process.argv[2];
const warmup = parseInt((() => { const i = process.argv.indexOf('--warmup'); return i >= 0 ? process.argv[i + 1] : '8'; })(), 10);
const res = JSON.parse(fs.readFileSync(path.join(dir, 'craft_result.json'), 'utf8'));
const rows = res.rows;

// 分组（保持行序）
const groups = new Map();
for (const r of rows) {
    if (!groups.has(r.cell)) groups.set(r.cell, []);
    groups.get(r.cell).push(r);
}

const fmt = (n, w) => String(n).padEnd(w);
console.log(`# TASK-09 微基准汇总（${path.basename(dir)}）\n`);
console.log('| 物品/通道/臂 | n | 拿到 | 成功率 | 中位 ms | 失败原因分布 |');
console.log('|---|---|---|---|---|---|');
const detail = {};
for (const [cell, rs] of groups) {
    // 热身切分：只对 'self' 臂切，且只切一次（分组内前 warmup 行）
    let measured = rs;
    let warmRows = [];
    if (cell.endsWith('/self') && rs.length > warmup) {
        warmRows = rs.slice(0, warmup);
        measured = rs.slice(warmup);
    }
    const counted = measured.filter((r) => !r.noRecipe);
    const noRecipe = measured.filter((r) => r.noRecipe).length;
    const ok = counted.filter((r) => r.verified).length;
    const ms = counted.map((r) => r.ms ?? 0).sort((a, b) => a - b);
    const med = ms.length ? ms[Math.floor((ms.length - 1) / 2)] : 0;
    const reasons = {};
    for (const r of counted) if (!r.verified) {
        const k = r.err ?? (r.reason ? `reason:${r.reason}` : 'unknown');
        reasons[k] = (reasons[k] ?? 0) + 1;
    }
    const rate = counted.length ? ((ok / counted.length) * 100).toFixed(1) : '—';
    console.log(`| \`${cell}\` | ${counted.length} | **${ok}** | **${rate}%** | ${med} | ${JSON.stringify(reasons)}${noRecipe ? ` ｜no_recipe ${noRecipe}` : ''} |`);
    detail[cell] = { n: counted.length, ok, rate: +rate, medianMs: med, reasons, warmupRows: warmRows.length, warmupOk: warmRows.filter((r) => r.verified).length, noRecipe };
}

console.log('\n## 热身（不计入成绩，仅证明时序敏感竞态的冷启动）\n');
for (const [cell, d] of Object.entries(detail)) {
    if (d.warmupRows) console.log(`- \`${cell}\`：热身 ${d.warmupOk}/${d.warmupRows}`);
}

console.log('\n## 逐局（正式臂的全部失败行）\n');
for (const [cell, rs] of groups) {
    const bad = rs.filter((r) => !r.verified && !r.noRecipe && !(cell.endsWith('/self') && rs.indexOf(r) < warmup));
    if (bad.length) {
        console.log(`- \`${cell}\`：失败序号 [${bad.map((b) => b.i).join(',')}]`);
        for (const b of bad.slice(0, 6)) console.log(`  - i=${b.i} ms=${b.ms} err=${b.err ?? '-'} reason=${b.reason ?? '-'} gained=${b.gained}`);
    }
}
fs.writeFileSync(path.join(dir, 'summary.json'), JSON.stringify(detail, null, 2));
console.log(`\n（明细写入 ${path.join(dir, 'summary.json')}）`);
