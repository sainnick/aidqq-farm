// window_ops_selftest.mjs — MC-M1-TASK-09 离线自检
//
// 为什么先写它：本单要改的是「按 action 号配对服务端回执」这条通道。ROUND3-A 的教训
// （手册 §5）——C 线在命令回执上栽过一次：迟到的旧回执会被当成本条的答案，读出来是
// 「看起来正常但坐标/计数是错的」数据，**零报错**。窗口回执通道一坏，产出的是
// 「看起来成功但产物没到手」的数据。所以先把配对逻辑在**假包流**上跑绿，再去烧服务器时间。
//
// 覆盖：
//   ① 1.16.1 vs 1.17.1 的 window_click 包封（两个方向都要能编、错的那个必须报错的字段名）
//   ② 1.16.1 的 Slot 形状（present 容器）在**所有**版本上一致 —— 推翻 ROUND3-A 的旧归因
//   ③ action 号配对：迟到回执 / 别人的 action / 乱序 action 一律不认
//   ④ set_slot 配对：只认原始包，不认本地 updateSlot（客户端自改模型骗不过它）
//   ⑤ 光标真值只从 set_slot(-1) 读，不读 win.selectedItem
//   ⑥ takeFromSlotConfirmed 的成功/拒绝/光标空 三条路径
//
// 用法：node window_ops_selftest.mjs

import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import { createRequire } from 'module';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MINDCRAFT = path.resolve(HERE, '../../../mindcraft');
const require2 = createRequire(path.join(MINDCRAFT, 'main.js'));

const { createSerializer } = require2('minecraft-protocol');
const minecraftData = require2('minecraft-data');

const mod = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/window_ops.js')).href);

let pass = 0, fail = 0;
const results = [];
function check(name, cond, detail = '') {
    if (cond) { pass++; results.push(`  PASS  ${name}`); }
    else { fail++; results.push(`  FAIL  ${name}${detail ? ' :: ' + detail : ''}`); }
}

// ─────────── 假 bot：够 window_ops 用就行 ───────────
class FakeEmitter {
    constructor() { this._h = new Map(); }
    on(ev, fn) { if (!this._h.has(ev)) this._h.set(ev, []); this._h.get(ev).push(fn); return this; }
    removeListener(ev, fn) { const a = this._h.get(ev); if (a) { const i = a.indexOf(fn); if (i >= 0) a.splice(i, 1); } return this; }
    once(ev, fn) { const w = (...a) => { this.removeListener(ev, w); fn(...a); }; return this.on(ev, w); }
    emit(ev, ...a) { for (const fn of (this._h.get(ev) ?? []).slice()) fn(...a); }
}
function makeBot(version) {
    const mc = minecraftData(version);
    const bot = new FakeEmitter();
    bot.version = version;
    bot.registry = mc;
    bot.supportFeature = (f) => mc.supportFeature(f);
    bot._client = new FakeEmitter();
    bot.written = [];
    bot._client.write = (name, params) => { bot.written.push({ name, params }); return true; };
    bot.clicked = [];
    bot.clickWindow = async (slot, mb, mode) => {
        bot.clicked.push({ slot, mb, mode });
        if (bot.rejectNextClick) { bot.rejectNextClick = false; throw new Error(`Server rejected transaction for clicking on slot ${slot}, on window with id ${bot.currentWindow?.id}.`); }
        const w = bot.currentWindow ?? bot.inventory;
        w.acceptClick({ slot, mouseButton: mb, mode, id: ++bot._actionSeq, windowId: w.id, item: w.slots[slot] });
    };
    bot._actionSeq = 0;
    return bot;
}
function makeWindow(id, { inventoryStart = 10, inventoryEnd = 46, requiresConfirmation = true } = {}) {
    const w = new FakeEmitter();
    w.id = id; w.type = 'minecraft:crafting_table';
    w.slots = new Array(46).fill(null);
    w.inventoryStart = inventoryStart; w.inventoryEnd = inventoryEnd;
    w.selectedItem = null; w.requiresConfirmation = requiresConfirmation;
    w.updateSlot = (slot, item) => { if (slot === -1) { w.slots[-1] = item; } else { w.slots[slot] = item; if (item) item.slot = slot; } w.emit('updateSlot', slot); w.emit(`updateSlot:${slot}`); };
    w.acceptClick = (click) => {
        // 仿 prismarine-windows 的真实语义：左键空槽 = 整摞拿起（光标拿到、槽清空）
        // 真实实现在 Window.js swapSelectedItem / clickWindow。假实现只做这一步，
        // 因为 1.16.x 上光标就是靠 acceptClick（被 transaction accepted 驱动）赋值的。
        const s = w.slots[click.slot];
        if (click.mouseButton === 0) {
            if (w.selectedItem == null && s) { w.selectedItem = s; w.slots[click.slot] = null; }
            else if (w.selectedItem != null) { w.slots[click.slot] = w.selectedItem; w.selectedItem = s; }
        }
        return [click.slot];
    };
    return w;
}
const item = (type, count = 1) => ({ type, count, name: `item_${type}`, stackSize: 64 });
const inv = (bot, entries) => { bot.inventory = makeWindow(0, { inventoryStart: 9, inventoryEnd: 45, requiresConfirmation: true }); bot.inventory.slots = new Array(46).fill(null); entries.forEach(([s, it]) => { bot.inventory.slots[s] = it; }); bot.inventory.items = () => bot.inventory.slots.filter((i, idx) => i && idx >= 9 && idx < 45); };
const emitSetSlot = (bot, windowId, slot, itemOrNull) => bot._client.emit('set_slot', { windowId, slot, item: itemOrNull ? { present: true, itemId: itemOrNull.type, itemCount: itemOrNull.count } : { present: false } });
const emitTransaction = (bot, windowId, action, accepted) => bot._client.emit('transaction', { windowId, action, accepted });

console.log('=== MC-M1-TASK-09 window_ops 离线自检 ===\n');

// ── ① 包封：1.16.1 用 action/item；1.17.1 用 stateId/changedSlots/cursorItem ──
{
    const b16 = makeBot('1.16.1');
    const p16 = mod.windowClickPacket(b16, mod.clickFlavor(b16), { windowId: 3, slot: 0, mouseButton: 0, mode: 0, item: null });
    check('1.16.1 包封用 action 字段', typeof p16.params.action === 'number', JSON.stringify(Object.keys(p16.params)));
    check('1.16.1 包封用 item 字段（不是 cursorItem）', 'item' in p16.params && !('cursorItem' in p16.params));
    check('1.16.1 包封没有 stateId', !('stateId' in p16.params));
    const b17 = makeBot('1.17.1');
    const p17 = mod.windowClickPacket(b17, mod.clickFlavor(b17), { windowId: 3, slot: 0, cursorItem: null, changedSlots: [] });
    check('1.17.1 包封用 stateId 字段', 'stateId' in p17.params);
    check('1.17.1 包封用 cursorItem/changedSlots', 'cursorItem' in p17.params && Array.isArray(p17.params.changedSlots));
    check('1.17.1 包封没有 action', !('action' in p17.params));
}

// ── ② 真实序列化：对的信封能编，错的信封必须报错 ──
{
    const ser = (ver) => createSerializer({ state: 'play', isServer: false, version: ver });
    const write = (ver, params) => { try { return { ok: true, n: ser(ver).createPacketBuffer({ name: 'window_click', params }).length }; } catch (e) { return { ok: false, e: String(e.message).slice(0, 90) }; } };
    const ok16 = write('1.16.1', { windowId: 3, slot: 0, mouseButton: 0, action: 7, mode: 0, item: { present: false } });
    check('1.16.1 action 信封可序列化', ok16.ok, ok16.e);
    const bad16 = write('1.16.1', { windowId: 3, stateId: 0, slot: 0, mouseButton: 0, mode: 0, changedSlots: [], cursorItem: { present: false } });
    check('1.16.1 用 1.17 信封必须报错（旧 _tableCraft 的症状）', !bad16.ok, '居然编过了');
    check('旧症状报错文本命中 present', !bad16.ok && /present/.test(bad16.e), bad16.e);
    const ok17 = write('1.17.1', { windowId: 3, stateId: 0, slot: 0, mouseButton: 0, mode: 0, changedSlots: [], cursorItem: { present: false } });
    check('1.17.1 stateId 信封可序列化', ok17.ok, ok17.e);
    const bad17 = write('1.17.1', { windowId: 3, slot: 0, mouseButton: 0, action: 7, mode: 0, item: { present: false } });
    check('1.17.1 用 1.16 信封必须报错', !bad17.ok, '居然编过了');
}

// ── ③ 推翻旧归因：slot 类型 {present,…} 在 1.16→1.18.2 逐字相同 ──
{
    const shapes = ['1.16', '1.16.1', '1.16.2', '1.17', '1.17.1', '1.18.2'].map((v) => JSON.stringify(minecraftData(v).protocol.types.slot));
    check('slot 类型在 1.16~1.18.2 全部相同', new Set(shapes).size === 1, `出现 ${new Set(shapes).size} 种`);
    const b16 = makeBot('1.16.1');
    const Item = require2('prismarine-item')(minecraftData('1.16.1'));
    check('prismarine-item toNotch(null) 就是 {present:false}', Item.toNotch(null).present === false, JSON.stringify(Item.toNotch(null)));
    check('prismarine-item toNotch(item) 带 present:true', Item.toNotch({ type: 5, count: 1 }).present === true);
    // 两边都拿 toNotch 的产物去编 1.16.1 的包，必须都能编过（形状对所有版本都对）
    const ser = createSerializer({ state: 'play', isServer: false, version: '1.16.1' });
    let allOk = true, why = '';
    for (const it of [null, { type: 5, count: 1 }]) {
        try { ser.createPacketBuffer({ name: 'window_click', params: { windowId: 3, slot: 0, mouseButton: 0, action: 1, mode: 0, item: Item.toNotch(it) } }); }
        catch (e) { allOk = false; why = e.message.slice(0, 90); }
    }
    check('toNotch() 的产物在 1.16.1 上直接可用（形状不是病因）', allOk, why);
}

// ── ④ action 号配对：迟到的 / 别人的 / 乱序的回执一律不认 ──
{
    const b = makeBot('1.16.1');
    const w = makeWindow(3); b.currentWindow = w; inv(b, []);
    const p = (async () => await mod.waitServerTransaction(b, 3, 7, 400))();
    setTimeout(() => { emitTransaction(b, 3, 5, false); emitTransaction(b, 3, 6, false); }, 20);   // 迟到/别人的
    setTimeout(() => { emitTransaction(b, 9, 7, false); }, 40);                                      // 别的窗口
    setTimeout(() => { emitTransaction(b, 3, 7, true); }, 60);                                       // 正确的
    const r = await p;
    check('只认自己 action 号的回执', r.ok && r.accepted === true, JSON.stringify(r));

    const b2 = makeBot('1.16.1');
    const p2 = (async () => await mod.waitServerTransaction(b2, 3, 7, 300))();
    setTimeout(() => { emitTransaction(b2, 3, 7, false); }, 20);
    const r2 = await p2;
    check('自己的 action 被拒要如实返回 accepted:false', r2.ok && r2.accepted === false, JSON.stringify(r2));

    const b3 = makeBot('1.16.1');
    const r3 = await mod.waitServerTransaction(b3, 3, 7, 120);
    check('超时要如实返回 timedOut（不猜通过）', r3.timedOut === true && r3.ok === false, JSON.stringify(r3));
}

// ── ⑤ set_slot 配对：本地 updateSlot 骗不过它 ──
{
    const b = makeBot('1.16.1');
    const w = makeWindow(3); b.currentWindow = w; inv(b, []);
    const p = (async () => await mod.waitServerSlot(b, 3, 0, 400))();
    w.updateSlot(0, item(5));                 // ← 客户端自己改模型（老 grabResult 就是这么干的）
    const early = await Promise.race([p, new Promise((r) => setTimeout(() => r('pending'), 60))]);
    check('本地 updateSlot 不算服务端确认', early === 'pending', `提前返回了 ${JSON.stringify(early)}`);
    setTimeout(() => { emitSetSlot(b, 3, 0, item(5)); }, 120);
    const r = await p;
    check('服务端 set_slot 才算确认', r.ok === true, JSON.stringify(r));
}

// ── ⑥ 光标真值只从 set_slot(-1,-1) 读（MC-M1-TASK-10 订正）──
// 服务端 `ServerPlayer.broadcastCarriedItem()` 发的是 `set_slot(windowId=**-1**, slot=-1, carried)`。
// 老用例发的是 `set_slot(windowId=**窗口id**, slot=-1)` —— 那是**服务端从不发的形状**，
// 正是 TASK-09「等不到光标包」的判据根因。现在把它钉死成回归用例。
{
    const b = makeBot('1.16.1');
    const w = makeWindow(3); b.currentWindow = w; inv(b, []);
    w.selectedItem = item(5, 1);               // 客户端预测：模型里有东西
    const t0 = await mod.readCursorTruth(b, 3, { from: [] });
    check('没有服务端包时，光标真值判空（不信 selectedItem）', t0.ok === false, JSON.stringify(t0));
    const tap = mod.makeSlotTap(b, 3);
    emitSetSlot(b, 3, -1, item(5, 1));          // ← 错误形状：窗口 id + slot -1
    const tBad = await tap.cursorTruth(150);
    check('窗口id+slot(-1) 不是光标真值（TASK-09 的判据根因）', tBad.ok === false, JSON.stringify(tBad));
    emitSetSlot(b, -1, -1, item(5, 1));         // ← 真形状：(-1,-1)
    const t1 = await tap.cursorTruth(1000);
    check('服务端 set_slot(-1,-1) 才算光标真值', t1.ok === true && !!t1.item, JSON.stringify(t1));
    tap.stop();
}

// ── ⑥b TASK-10 回归钉：窗口 id 与光标包无关，且不按窗口过滤 ──
{
    const b = makeBot('1.16.1');
    const w = makeWindow(7); b.currentWindow = w; inv(b, []);
    const tap = mod.makeSlotTap(b, 7);
    check('isCursorPacket 只认 windowId=-1 且 slot=-1',
        mod.isCursorPacket({ windowId: -1, slot: -1 }) === true
        && mod.isCursorPacket({ windowId: 7, slot: -1 }) === false
        && mod.isCursorPacket({ windowId: -1, slot: 0 }) === false
        && mod.isCursorPacket({ windowId: 0, slot: -1 }) === false, '谓词不对');
    emitSetSlot(b, -1, -1, item(5, 2));
    const t = await tap.cursorTruth(1000);
    check('窗口 id=7 时也能读到 windowId=-1 的光标包', t.ok === true && t.item?.count === 2, JSON.stringify(t));
    tap.stop();
}

// ── ⑥c TASK-10 回归钉：1.16.1 的 set_slot.windowId 是 i8，-1 原样上线 ──
// 协议表 pc/1.16.1：packet_set_slot = [{windowId: i8}, {slot: i16}, {item: slot}]。
// 若它是 u8，服务端的 -1 会变成 255，判据就必须同时认 255 —— 这里把"是 i8"钉住。
{
    const protoPath = path.join(MINDCRAFT, 'node_modules/minecraft-data/minecraft-data/data/pc/1.16.1/protocol.json');
    const protoJson = JSON.parse(fs.readFileSync(protoPath, 'utf8'));
    const fields = protoJson.play.toClient.types.packet_set_slot[1];
    const wid = fields.find((f) => f.name === 'windowId')?.type;
    check('协议表里 set_slot.windowId 是 i8（-1 不会被截成 255）', wid === 'i8', `实际=${wid}`);
    const sl = fields.find((f) => f.name === 'slot')?.type;
    check('协议表里 set_slot.slot 是 i16（能表示 -1）', sl === 'i16', `实际=${sl}`);
    // 对照：window_click 的 windowId 才是 u8 —— 所以"窗口 id"和"光标 id"在协议里
    // 本来就是两种东西，老代码把两者混为一谈是 TASK-09 判据失效的根因。
    const wc = protoJson.play.toServer.types.packet_window_click[1];
    const wWid = wc.find((f) => f.name === 'windowId')?.type;
    check('对照：window_click.windowId 是 u8（窗口 id 不可能为负）', wWid === 'u8', `实际=${wWid}`);
}

// ── ⑦ takeFromSlotConfirmed 三条路径 ──
{
    // (a) 成功：服务端依次确认「结果格变空 → 光标拿到 → 背包格拿到」
    const b = makeBot('1.16.1');
    const w = makeWindow(3); b.currentWindow = w; inv(b, []);
    const Item = require2('prismarine-item')(minecraftData('1.16.1'));
    const pick = new Item(minecraftData('1.16.1').itemsByName['oak_planks'].id, 1, 0);
    w.slots[0] = pick;
    w.slots[3] = null;
    const p = mod.takeFromSlotConfirmed(b, w, 0, { itemName: 'oak_planks', timeoutMs: 800 });
    setTimeout(() => {                       // 服务端：结果格清空
        w.slots[0] = null; emitSetSlot(b, 3, 0, null);
    }, 30);
    setTimeout(() => {                       // 服务端：光标拿到产物（真形状 -1,-1）
        emitSetSlot(b, -1, -1, pick);
    }, 90);
    setTimeout(() => {                       // 服务端：背包格收到
        w.slots[10] = pick; emitSetSlot(b, 3, 10, pick);
    }, 150);
    const r = await p;
    check('成功路径：产物经服务端三次确认进背包', r.ok === true, JSON.stringify(r));
    check('成功路径：took 有值', (r.took ?? 0) >= 1, JSON.stringify(r));

    // (b) 服务端拒收
    const b2 = makeBot('1.16.1');
    const w2 = makeWindow(3); b2.currentWindow = w2; inv(b2, []);
    w2.slots[0] = pick;
    b2.rejectNextClick = true;
    const r2 = await mod.takeFromSlotConfirmed(b2, w2, 0, { itemName: 'oak_planks', timeoutMs: 400 });
    check('服务端拒收要判失败（不吞异常）', r2.ok === false && r2.reason === 'server_rejected', JSON.stringify(r2));

    // (c) 1.17+ 的严格光标口径：服务端**不发** set_slot(-1) ⇒ 必须判失败（不靠猜）
    //     （1.16.x 上做不到这一条——线上没有光标字段，见第 ⑩ 组）
    const b3 = makeBot('1.17.1');
    const w3 = makeWindow(3); b3.currentWindow = w3; inv(b3, []);
    w3.slots[0] = pick;
    b3.clickWindow = async (slot, mb, mode) => { w3.acceptClick({ slot, mouseButton: mb, mode, id: 1, windowId: 3, item: w3.slots[slot] }); };
    const p3 = mod.takeFromSlotConfirmed(b3, w3, 0, { itemName: 'oak_planks', timeoutMs: 400 });
    setTimeout(() => { w3.slots[0] = null; emitSetSlot(b3, 3, 0, null); }, 30);  // 服务端确认了结果格，但**不发** slot=-1
    const r3 = await p3;
    check('1.17+ 服务端不回 set_slot(-1) → 判失败（严格口径，不靠猜）', r3.ok === false && r3.reason === 'cursor_empty_from_server', JSON.stringify(r3));

    // (d) 光标非空时必须拒绝（ROUND3-A §5 真凶：会变成"交换"）
    const b4 = makeBot('1.16.1');
    const w4 = makeWindow(3); b4.currentWindow = w4; inv(b4, []);
    w4.selectedItem = item(9, 1);
    const r4 = await mod.takeFromSlotConfirmed(b4, w4, 0, { itemName: 'oak_planks', timeoutMs: 200 });
    check('光标非空直接拒绝（防止"交换"语义）', r4.ok === false && r4.reason === 'cursor_not_empty', JSON.stringify(r4));
}

// ── ⑧ requiresConfirmation=false 的窗口（1.16.1 箱子）必须走服务端 set_slot 通道 ──
{
    const b = makeBot('1.16.1');
    const w = makeWindow(5, { requiresConfirmation: false }); b.currentWindow = w; inv(b, []);
    w.slots[0] = item(5, 3);
    const p = mod.takeFromSlotConfirmed(b, w, 0, { itemName: 'item_5', timeoutMs: 700 });
    setTimeout(() => { w.slots[0] = null; emitSetSlot(b, 5, 0, null); }, 30);
    setTimeout(() => { emitSetSlot(b, 5, -1, item(5, 3)); }, 90);
    setTimeout(() => { w.slots[10] = item(5, 3); emitSetSlot(b, 5, 10, item(5, 3)); }, 150);
    const r = await p;
    check('箱子（requiresConfirmation=false）走服务端确认也能取到', r.ok === true, JSON.stringify(r));
    check('箱子通道用的是直发包而非 bot.clickWindow', b.clicked.length === 0 && b.written.length >= 2, `clicked=${b.clicked.length} written=${b.written.length}`);
    check('直发包在 1.16.1 上用 action 信封', b.written.every((x) => x.name === 'window_click' && typeof x.params.action === 'number'), JSON.stringify(b.written.map((x) => Object.keys(x.params))));
}

// ── ⑨ 编码不变量：item/cursorItem 必须是协议 slot 形状，且**编出来的字节不能把物品丢掉** ──
// 这条是实服血的教训：T09_PDIFF 上 mineflayer 发 16 字节 accepted:true，
// 本模块发 9 字节 accepted:false —— 因为把 prismarine 的 Item 直接塞进了协议字段，
// protodef 读 `present` 得到 undefined ⇒ 静默编码成"光标是空的"。**不报任何错。**
{
    const mc = minecraftData('1.16.1');
    const Item = require2('prismarine-item')(mc);
    const planks = new Item(mc.itemsByName['oak_planks'].id, 16, 0);
    const b = makeBot('1.16.1');
    const p = mod.windowClickPacket(b, mod.clickFlavor(b), { windowId: 1, slot: 37, item: planks });
    check('① item 字段被转成协议 slot 形状', p.params.item && p.params.item.present === true && p.params.item.itemId === planks.type, JSON.stringify(p.params.item));
    const ser = createSerializer({ state: 'play', isServer: false, version: '1.16.1' });
    const bytesOk = ser.createPacketBuffer(p).length;
    const bytesBad = ser.createPacketBuffer({ name: 'window_click', params: { ...p.params, item: planks } }).length;
    check('② 正确编码比"直接塞 Item"长（物品没被丢）', bytesOk > bytesBad, `ok=${bytesOk}B bad=${bytesBad}B`);
    check('③ 空物品编成 present:false', mod.toNotchSlot(b, null).present === false);
    const b17 = makeBot('1.17.1');
    const p17 = mod.windowClickPacket(b17, mod.clickFlavor(b17), { windowId: 1, slot: 0, cursorItem: planks, changedSlots: [{ location: 3, item: planks }] });
    check('④ 1.17+ 的 cursorItem 也是协议形状', p17.params.cursorItem.present === true);
    check('⑤ 1.17+ 的 changedSlots[].item 也是协议形状', p17.params.changedSlots[0].item.present === true && p17.params.changedSlots[0].item.itemId === planks.type, JSON.stringify(p17.params.changedSlots[0]));
    const enc17 = createSerializer({ state: 'play', isServer: false, version: '1.17.1' }).createPacketBuffer(p17).length;
    check('⑥ 1.17+ 也能编出来', enc17 > 9, `${enc17}B`);
}

// ── ⑩ 1.16.x 没有 carriedItem 线上字段：光标确认必须降级，且最终判据必须是背包增量 ──
// 依据：1.16.1 window_items = {windowId, items}（无 carriedItem），1.17.1 才有。
// 实服 T09_FURN3：点击被 accepted、输出格 set_slot 清零，但 set_slot(-1) 永不到达 ⇒ 取件 0/30。
{
    const b16 = makeBot('1.16.1');
    const b17 = makeBot('1.17.1');
    check('① 1.16.1 判为"无光标线上字段"', mod.hasCarriedItemWire(b16) === false);
    check('② 1.17.1 判为"有光标线上字段"', mod.hasCarriedItemWire(b17) === true);

    // 1.16.x：点击被 accepted（本地 selectedItem 随之更新），服务端**不发** set_slot(-1)
    const bb = makeBot('1.16.1');
    const w = makeWindow(3); bb.currentWindow = w; inv(bb, []);
    const Item = require2('prismarine-item')(minecraftData('1.16.1'));
    const pick = new Item(minecraftData('1.16.1').itemsByName['oak_planks'].id, 1, 0);
    w.slots[2] = pick; w.slots[5] = null;
    bb.clickWindow = async (slot) => { w.selectedItem = pick; };   // 服务端 accepted 之后才赋值
    const p = mod.takeFromSlotConfirmed(bb, w, 2, { itemName: 'oak_planks', timeoutMs: 600 });
    setTimeout(() => { w.slots[2] = null; emitSetSlot(bb, 3, 2, null); }, 30);      // 输出格清零（服务端）
    setTimeout(() => { w.slots[10] = pick; emitSetSlot(bb, 3, 10, pick); }, 120);   // 目标格到账（服务端，dest=10）
    const r = await p;
    check('③ 1.16.x 不发 set_slot(-1) 也能确认成功（降级口径）', r.ok === true, JSON.stringify(r));
    check('④ 降级时记录 cursorHow 以便审计', r.cursorHow === 'selectedItem(after accepted)', String(r.cursorHow));

    // 1.16.x：光标压根没有 → 必须判失败，不能"看起来在动"就算成功
    const b3 = makeBot('1.16.1');
    const w3 = makeWindow(3); b3.currentWindow = w3; inv(b3, []);
    w3.slots[2] = item(5, 1);
    b3.clickWindow = async () => { /* accepted 了但光标还是空 */ };
    const r3 = await mod.takeFromSlotConfirmed(b3, w3, 2, { itemName: 'oak_planks', timeoutMs: 300 });
    check('⑤ 1.16.x 光标为空要判失败', r3.ok === false && r3.reason === 'no_cursor_after_accept', JSON.stringify(r3));

    // 1.16.x：点击被 accepted、也点了目标格，但**背包增量没到** → 仍判失败（最终判据是增量）
    const b4 = makeBot('1.16.1');
    const w4 = makeWindow(3); b4.currentWindow = w4; inv(b4, []);
    const pick4 = new Item(minecraftData('1.16.1').itemsByName['oak_planks'].id, 1, 0);
    w4.slots[2] = pick4; w4.slots[6] = null;
    b4.clickWindow = async (slot) => { if (slot === 2) w4.selectedItem = pick4; };
    const r4 = await mod.takeFromSlotConfirmed(b4, w4, 2, { itemName: 'oak_planks', timeoutMs: 250 });
    check('⑥ 背包增量没到账要判失败（不能只看 accepted）', r4.ok === false && r4.reason === 'no_inv_delta', JSON.stringify(r4));
}

// ══════════════ MC-M1-TASK-10：shift 点击取产物（不经光标）══════════════
// 本单修的病：旧的两步取件**必然经过光标**，产物"停在光标"这个失效模式没法排除。
// 新原语走 mode=1（QUICK_MOVE），1.16.1 服务端 `AbstractFurnaceMenu.b(Player,int)`
// 对 index==2 有专门分支：整摞直接进背包槽 3..39，光标全程不参与。
{
    const Item = require2('prismarine-item')(minecraftData('1.16.1'));
    const ingot = new Item(minecraftData('1.16.1').itemsByName['iron_ingot'].id, 1, 0);

    // ⑴ 发出去的包，`item` 字段必须是**光标**（空），不能是被点那一格的产物
    //     —— 否则服务端 `matches(包的carried, 点击后光标)` 判 false ⇒ accepted=false。
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3); b.currentWindow = w; inv(b, []);
        w.slots[2] = ingot;                      // 输出格有产物
        w.selectedItem = null;                   // 光标空
        const p = mod.clickCursorClaimConfirmed(b, w, { slot: 2, mode: 1, timeoutMs: 400 });
        setTimeout(() => b._client.emit('transaction', { windowId: 3, action: b.written[0]?.params?.action ?? 1, accepted: true }), 40);
        const r = await p;
        const pkt = b.written[0];
        check('⑴ shift 点击真的发了 mode=1 的包', pkt?.name === 'window_click' && pkt.params.mode === 1, JSON.stringify(pkt?.params));
        check('⑵ 包封用 1.16.x 的 action + item', pkt?.params.action !== undefined && pkt?.params.item !== undefined, JSON.stringify(Object.keys(pkt?.params ?? {})));
        check('⑶ item 字段填的是**光标（空）**而不是输出格的产物',
            pkt?.params.item?.present === false, `实际=${JSON.stringify(pkt?.params.item)}`);
        check('⑷ 服务端 accepted 后才算成功', r.ok === true, JSON.stringify(r));
    }

    // ⑸ 成功路径：背包区收到服务端 set_slot + 增量到账 ⇒ 成功，且光标全程没拿到产物
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3, { inventoryStart: 3, inventoryEnd: 39 }); b.currentWindow = w; inv(b, []);
        w.slots[2] = ingot; w.selectedItem = null;
        const p = mod.takeFurnaceOutputQuickMove(b, { window: w }, { itemName: 'iron_ingot', expectName: 'iron_ingot', timeoutMs: 700 });
        setTimeout(() => {
            w.slots[2] = null;                                   // 服务端：输出格清空
            b._client.emit('transaction', { windowId: 3, action: 1, accepted: true });
        }, 30);
        setTimeout(() => {
            w.slots[3] = ingot;                                  // 服务端：产物落在背包第 3 格
            b._client.emit('set_slot', { windowId: 3, slot: 3, item: mod.toNotchSlot(b, ingot) });
        }, 90);
        const r = await p;
        check('⑸ 背包区拿到服务端 set_slot ⇒ 成功', r.ok === true, JSON.stringify(r));
        check('⑹ 判据记的是服务端那一格（dest=3）', r.dest === 3, `dest=${r.dest}`);
        check('⑺ 不变量：产物没经过光标', r.cursorUntouched === true && r.cursorPackets === 0, `cursorPackets=${r.cursorPackets}`);
    }

    // ⑻b 关键：1.16.1 被 accepted 的点击**不发逐格 set_slot**（ignoreSlotUpdateHack），
    //      服务端只发整窗 window_items + 光标包。判据必须认这条通道，否则结构性等不到。
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3, { inventoryStart: 3, inventoryEnd: 39 }); b.currentWindow = w; inv(b, []);
        w.slots[2] = ingot; w.selectedItem = null;
        const p = mod.takeFurnaceOutputQuickMove(b, { window: w }, { itemName: 'iron_ingot', timeoutMs: 700 });
        setTimeout(() => {
            // ⚠ 复现**真实的服务端顺序**：先 Ack，紧接着（同一个 tick、同一段 TCP）整窗 window_items。
            //   老实现在 await 回执之后才挂监听 ⇒ 整窗包已经被派发掉 ⇒ 判据② 整条是死代码
            //   （实服 ① 那轮 quickMove 的 dest 全是 null 就是这么来的）。
            b._client.emit('transaction', { windowId: 3, action: 1, accepted: true });
            // 服务端整窗重发：第 3 格（背包区第一格）现在是产物
            const items = new Array(39).fill(null).map(() => ({ present: false }));
            items[3] = mod.toNotchSlot(b, ingot);
            w.slots[3] = ingot;
            b._client.emit('window_items', { windowId: 3, items });
        }, 30);
        const r = await p;
        check('⑻b 只发 window_items（无逐格 set_slot）也能确认成功', r.ok === true, JSON.stringify(r));
        check('⑻c 判据能指出是哪一格、从哪条通道来的', r.dest === 3 && r.destVia === 'window_items', `dest=${r.dest} via=${r.destVia}`);
    }

    // ⑽b 背包满（无空槽、无同型可叠加）⇒ 提前判 inventory_full，且**不点**
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3, { inventoryStart: 3, inventoryEnd: 39 }); b.currentWindow = w; inv(b, []);
        w.slots[2] = ingot; w.selectedItem = null;
        for (let i = 3; i < 39; i++) w.slots[i] = new Item(minecraftData('1.16.1').itemsByName['cobblestone'].id, 64, 0);
        const r = await mod.takeFurnaceOutputQuickMove(b, { window: w }, { itemName: 'iron_ingot', timeoutMs: 300 });
        check('⑽b 背包满提前判 inventory_full 且不发包', r.ok === false && r.reason === 'inventory_full' && b.written.length === 0, JSON.stringify(r));
    }

    // ⑻ 关键反例：产物真的停在光标上 ⇒ 必须判失败（这正是旧原语静默通过的形态）
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3, { inventoryStart: 3, inventoryEnd: 39 }); b.currentWindow = w; inv(b, []);
        w.slots[2] = ingot; w.selectedItem = null;
        const p = mod.takeFurnaceOutputQuickMove(b, { window: w }, { itemName: 'iron_ingot', timeoutMs: 700 });
        setTimeout(() => {
            w.slots[2] = null; w.selectedItem = ingot;
            b._client.emit('transaction', { windowId: 3, action: 1, accepted: true });
        }, 30);
        setTimeout(() => {
            b._client.emit('set_slot', { windowId: -1, slot: -1, item: mod.toNotchSlot(b, ingot) });   // 光标里出现产物
        }, 80);
        setTimeout(() => {
            w.slots[3] = ingot;
            b._client.emit('set_slot', { windowId: 3, slot: 3, item: mod.toNotchSlot(b, ingot) });     // 背包也"增了"
        }, 120);
        const r = await p;
        check('⑻ 产物经过光标必须判失败（cursor_got_product）', r.ok === false && r.reason === 'cursor_got_product', JSON.stringify(r));
    }

    // ⑼ 光标起点非空 ⇒ 直接拒绝（shift 点击的语义完全不同）
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3, { inventoryStart: 3, inventoryEnd: 39 }); b.currentWindow = w; inv(b, []);
        w.slots[2] = ingot; w.selectedItem = ingot;
        const r = await mod.takeFurnaceOutputQuickMove(b, { window: w }, { itemName: 'iron_ingot', timeoutMs: 300 });
        check('⑼ 光标非空直接拒绝', r.ok === false && r.reason === 'cursor_not_empty', JSON.stringify(r));
    }

    // ⑽ 输出格空 ⇒ 不点（避免把光标里的东西丢出去）
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3, { inventoryStart: 3, inventoryEnd: 39 }); b.currentWindow = w; inv(b, []);
        const r = await mod.takeFurnaceOutputQuickMove(b, { window: w }, { itemName: 'iron_ingot', timeoutMs: 300 });
        check('⑽ 输出格空不点', r.ok === false && r.reason === 'output_empty' && b.written.length === 0, JSON.stringify(r));
    }

    // ⑾ 服务端拒收 ⇒ 原语如实判失败（生产入口再换协议重试，那是 ⑳ 验的）
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3, { inventoryStart: 3, inventoryEnd: 39 }); b.currentWindow = w; inv(b, []);
        w.slots[2] = ingot; w.selectedItem = null;
        const p = mod.takeFurnaceOutputQuickMove(b, { window: w }, { itemName: 'iron_ingot', timeoutMs: 400 });
        setTimeout(() => b._client.emit('transaction', { windowId: 3, action: 1, accepted: false }), 40);   // 拒收
        const r = await p;
        check('⑾ 服务端拒收要判失败（不吞）', r.ok === false && r.reason === 'server_rejected', JSON.stringify(r));
    }

    // ⑿ 生产入口：shift 点击被服务端拒收 ⇒ 换协议（两步）重试一次，并把原因记下来
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3, { inventoryStart: 3, inventoryEnd: 39 }); b.currentWindow = w; inv(b, []);
        w.slots[2] = ingot; w.selectedItem = null;
        const p = mod.takeFurnaceOutputConfirmed(b, { window: w }, { itemName: 'iron_ingot', timeoutMs: 500 });
        setTimeout(() => b._client.emit('transaction', { windowId: 3, action: 1, accepted: false }), 40);
        const r = await p;
        check('⑿ 拒收时生产入口回退到两步原语（并记 quickReason）',
            r.fellBackFrom === 'quickmove' && r.quickReason === 'server_rejected', JSON.stringify(r));
    }
    // ⓫ 生产入口默认走 shift 点击：成功路径里**不会**出现 mode=0 的点击
    {
        const b = makeBot('1.16.1');
        const w = makeWindow(3, { inventoryStart: 3, inventoryEnd: 39 }); b.currentWindow = w; inv(b, []);
        w.slots[2] = ingot; w.selectedItem = null;
        const p = mod.takeFurnaceOutputConfirmed(b, { window: w }, { itemName: 'iron_ingot', timeoutMs: 700 });
        setTimeout(() => {
            w.slots[2] = null;
            b._client.emit('transaction', { windowId: 3, action: 1, accepted: true });
        }, 30);
        setTimeout(() => {
            w.slots[3] = ingot;
            b._client.emit('set_slot', { windowId: 3, slot: 3, item: mod.toNotchSlot(b, ingot) });
        }, 90);
        const r = await p;
        const modes = b.written.map((x) => x.params.mode);
        check('⓫ 生产入口默认只发 mode=1（不经过光标那两步）',
            r.ok === true && modes.length === 1 && modes[0] === 1, `modes=${JSON.stringify(modes)} ok=${r.ok}`);
    }
}

console.log(results.join('\n'));
console.log(`\n=== ${pass}/${pass + fail} PASS${fail ? `  (${fail} FAIL)` : ''} ===`);
process.exit(fail ? 1 : 0);
