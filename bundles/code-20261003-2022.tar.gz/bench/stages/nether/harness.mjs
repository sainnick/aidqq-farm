// harness.mjs — MC-H-NETHER（开发线 H）共用台架：泳道 C 的拿锁/起服/连 bot/tp/kit/收工
//
// 【为什么自己写一份而不直接 import F 线的】
//   F 线 `bench/stages/barter/harness.mjs` 的 `moduleUrl()` **硬编码断言**路径必须在
//   `mindcraft-wt/s2-barter` 内（`MODULE_OUT_OF_WORKTREE` 闸门），本线的任务层在
//   `mindcraft-wt/nether-run` ⇒ 直接 import 会在**第一次加载本线任务层时就抛**。
//   按手册 §9.2「共享文件要改先报告」的口径，**本单零改动 F 线文件**，改为：
//   ① 复用它的**只读**依赖：`_lib/runner_core.mjs`（共享基础设施）、`barter/truth.mjs`
//      （服务端真值通道，纯逻辑无 F 线私有状态）、`barter/lane_guard.mjs`（泳道心跳）；
//   ② 本文件自己实现局生命周期，MINDCRAFT 指向本线 worktree。
//
// 【纪律（手册 §9.2）】
//   1. **只拿泳道 C 的锁，一局一放**（F 线与 C 线在两局之间借道）。H 线线锁由独立进程长期持有。
//   2. 只用服务器 stdin 控制台发命令（RCON 会毒化服务进程）。**控制台没有 @s**，
//      一律替换成 `at <username>`；`execute` 链**必须带 `run`**。
//   3. 跨维度/远距 tp 之后**必须校验客户端坐标**（E 线实测 "moved too quickly" 会让
//      客户端坐标停在旧位置，代码读到幻影位置却不报错）。
//   4. **kit 起步必须复现真实前置状态**（手册 §4.2）：本单下界三段起点 = 门落点，
//      位置与背包都按真实链给（见 nether_run.mjs 的 PRIOR）。

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log } from '../_lib/runner_core.mjs';
import { holdLocks } from '../_lib/line_lock.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from '../barter/lane_guard.mjs';
import { Truth } from '../barter/truth.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(BENCH_DIR, '../../..');
/** 任务层代码只从**本线 worktree** 读（§9 禁令：不碰主目录 mindcraft/ 与别人的 worktree） */
export const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 'nether-run');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
export const { Vec3 } = require('vec3');
export const mineflayer = require('mineflayer');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = 'server-1.16.1.jar';
export const MC_VERSION = '1.16.1';
export const SEED = argOf(process.argv, 'seed', '4926685115947721762');
export const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const state = { bot: null, server: null, truth: null, clock: null, stamp: null, runDir: null, locks: null };

/** 泳道 C（派单：H 线用泳道 C，与 F 线按心跳共用，单次 ≤20 分钟，不抢） */
export const LANE = {
    idx: 2, name: 'C', dir: `${SERVER_TEMPLATE}_laneC`,
    serverPort: 25568, rconPort: 25578, username: 'HBotC', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneC`, JAR_NAME), java: JAVA,
};

/** 本线任务层模块的绝对路径（只能落在 nether-run worktree 里） */
export function moduleUrl(rel) {
    const abs = path.join(MINDCRAFT, rel);
    if (!abs.startsWith(path.join(ROOT, 'mindcraft-wt', 'nether-run'))) {
        throw new Error(`MODULE_OUT_OF_WORKTREE: ${rel} 不在本线 worktree 内（§9 禁令）`);
    }
    return pathToFileURL(abs).href;
}

export const S = () => state;
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export function cmd(c) { return state.truth ? state.truth.raw(c) : false; }
export const truth = () => state.truth;
export const bot = () => state.bot;
export const botPos = () => state.bot?.entity?.position ?? null;
export function posStr(p) { return p ? `${p.x.toFixed(1)},${p.y.toFixed(1)},${p.z.toFixed(1)}` : '?'; }
export const dim = () => state.bot?.game?.dimension ?? '?';
export const invCount = () => {
    const out = {};
    for (const i of (state.bot?.inventory?.items?.() ?? [])) out[i.name] = (out[i.name] ?? 0) + i.count;
    return out;
};
export const countItem = (name) => (state.bot?.inventory?.items?.() ?? []).filter((i) => i.name === name).reduce((a, b) => a + b.count, 0);

const DRIVE = path.parse(ROOT).root.replace(/[\\\/]+$/, '');
export function diskFreeGB() {
    try { return +(execSync(`powershell -NoProfile -Command "[math]::Round((Get-PSDrive ${DRIVE.replace(':', '')}).Free/1GB,1)"`, { encoding: 'utf8' }).trim()); } catch { return null; }
}

/** 开一局：拿泳道 C 锁 → 等泳道 → 等内存。closeRun 释放。 */
export async function openRun(stamp) {
    state.stamp = stamp;
    state.runDir = path.join(BENCH_DIR, 'runs', stamp);
    fs.mkdirSync(state.runDir, { recursive: true });
    installRunnerHooks(() => stamp, () => { try { state.locks?.releaseAll?.(); } catch { /* 忽略 */ } });
    const waitMin = parseInt(argOf(process.argv, 'lock-wait', '25'), 10);
    const t0 = Date.now();
    for (;;) {
        try {
            state.locks = await holdLocks(['C'], { who: 'H', label: `MC-H-NETHER ${stamp}`, logFn: log });
            break;
        } catch (e) {
            if (!/LINE_LOCKED/.test(String(e?.message ?? e)) || Date.now() - t0 > waitMin * 60000) throw e;
            log(`泳道 C 线锁被占（${e.lockReason ?? e}）→ 排队等（最多 ${waitMin}min，不接管）`);
            await sleep(20000);
        }
    }
    const st = await waitLane(LANE, {
        maxMs: parseInt(argOf(process.argv, 'lane-wait-min', '45'), 10) * 60 * 1000,
        pollMs: 15000,
        onWait: (s) => log(`泳道 C 不可用（${s.why}）→ 等 C/F 线让路（只等不接管，手册 §9.2）`),
    });
    if (!st.usable) throw new Error(`等不到泳道 C（${st.why}）`);
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE).usable) throw new Error('泳道 C 在等内存期间被占');
    log(`局 ${stamp} 就绪：runDir=${state.runDir}`);
    return state;
}

/** 起一局世界（每次 freshWorld：同种子重开地形确定、只清上一局残留） */
export async function bootWorld({ difficulty = 'easy', minDiskFreeGB = 15 } = {}) {
    const free = diskFreeGB();
    if (free != null && free < minDiskFreeGB) {
        throw new Error(`DISK_LOW：${DRIVE} 盘空闲 ${free.toFixed(1)}GB < ${minDiskFreeGB}GB ⇒ 不开新局`);
    }
    log(`[disk] ${DRIVE} 空闲 ${free?.toFixed?.(1) ?? '?'}GB（闸门 ${minDiskFreeGB}GB）`);
    freshWorld(LANE, SEED);
    state.server = await bootServerWithRetry(LANE, state.runDir, '1G', log);
    LANE.serverChild = state.server.child;
    log(`server up in ${(state.server.bootMs / 1000).toFixed(0)}s`);
    state.truth = new Truth({ child: state.server.child, logPath: path.join(state.runDir, 'server.log'), log });
    state.clock = state.truth.startClock({ hz: 4, dim: 'the_nether' });
    state.bot = mineflayer.createBot({
        host: '127.0.0.1', port: LANE.serverPort, username: LANE.username, version: MC_VERSION,
    });
    await new Promise((res, rej) => {
        state.bot.once('spawn', res);
        state.bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    const pf = require('mineflayer-pathfinder');
    state.bot.loadPlugin(pf.pathfinder);
    state.bot.pf = pf;
    await sleep(3500);
    cmd(`gamemode survival ${LANE.username}`);
    cmd(`difficulty ${difficulty}`);
    await sleep(800);
    log(`bot 已进服：dim=${state.bot.game?.dimension} pos=${posStr(botPos())}`);
    return state;
}

export async function stopWorld() {
    try { state.bot?.quit?.('done'); } catch { /* 忽略 */ }
    try { state.clock?.stop?.(); } catch { /* 忽略 */ }
    if (state.server) { await stopServer(LANE, state.server); state.server = null; }
    state.bot = null; state.truth = null; state.clock = null;
    log('本局世界已停');
}

export async function closeRun() {
    try { await stopWorld(); } catch (e) { log(`stopWorld 失败：${e}`); }
    if (state.locks) { try { await state.locks.releaseAll(); } catch { /* 忽略 */ } state.locks = null; }
}

export async function waitLog(pat, ms = 30000) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
        for (const l of state.truth.drain()) if (pat.test(l)) return l;
        if (state.server?.child?.exitCode != null) throw new Error('server died');
        await sleep(100);
    }
    throw new Error(`waitLog 超时 ${ms}ms：${pat}`);
}

/** 下界里 tp 并**校验客户端坐标**（1.16.1 支持 `execute in minecraft:the_nether run tp`） */
export async function tpNether(x, y, z, { verify = true, tries = 6 } = {}) {
    for (let i = 1; i <= tries; i++) {
        cmd(`execute in minecraft:the_nether run tp ${LANE.username} ${x} ${y} ${z}`);
        await sleep(1500);
        const p = botPos();
        if (!verify) return true;
        const ok = p && Math.abs(p.x - x) < 1.5 && Math.abs(p.z - z) < 1.5;
        if (ok && String(dim()).includes('nether')) return true;
        log(`tp 第 ${i} 次未生效（dim=${dim()} pos=${posStr(p)}），重发`);
        await sleep(1200);
    }
    throw new Error(`tpNether 失败：目标 ${x},${y},${z}，现在 dim=${dim()} pos=${posStr(botPos())}`);
}

/**
 * 开发期 kit。给完**回读背包**做确认，不靠"命令发出去了"（手册 §5：kit 没报错 ≠ 生效）。
 *
 * 🚨 **必须带 `execute in <当前维度>`**（N1b 实测踩到）：本单 kit 是在 **bot 已进下界之后**给的，
 *   而 1.16.1 的控制台 `give <玩家>` **不带 `execute in` 时作用在主世界**——
 *   玩家不在主界�� ⇒ 物品给了个寂寞，**server.log 零回执、零报错**，
 *   症状是"kit 回读 4 件里少 1 件"，看起来像背包满了或名字写错了。
 *   ⇒ 维度按 `bot.game.dimension` 自动取，**每条 give 都读回执**（没回执就报出来）。
 */
export async function kit(items, { verifyMs = 12000 } = {}) {
    const d = String(dim());
    const pre = d.includes('nether') ? 'execute in minecraft:the_nether run '
        : d.includes('end') ? 'execute in minecraft:the_end run ' : '';
    const logPath = state.runDir ? path.join(state.runDir, 'server.log') : null;
    const logSize = () => { try { return fs.statSync(logPath).size; } catch { return 0; } };
    for (const it of items) {
        const [name, n = '1'] = it.split(':');
        const at0 = logSize();
        const c = `${pre}give ${LANE.username} minecraft:${name} ${n}`;
        const ok = cmd(c);
        if (!ok) log(`kit: ❌ 发送失败 ${c}`);
        await sleep(300);
        // 零输出 = 没执行（手册 §5：不执行 = 零输出）。原样打出来，不放过。
        let delta = '';
        try { delta = fs.readFileSync(logPath, 'utf8').slice(at0).trim(); } catch { /* 还没落盘 */ }
        if (!delta) log(`kit: ⚠ 服务端零输出（没执行？）${c}｜dim=${d} pre=${pre ? 'YES' : 'overworld'}`);
        else log(`kit: ${c} → ${delta.split(/\r?\n/).slice(0, 1).join('').slice(0, 120)}`);
    }
    const t0 = Date.now();
    while (Date.now() - t0 < verifyMs) {
        const inv = invCount();
        if (Object.keys(inv).length) return inv;
        await sleep(300);
    }
    return invCount();
}

/** 死亡监视：四通道对账用（server.log × bot.log × metrics × telemetry） */
export function watchDeaths(logPath = null, onDeath = null) {
    const rec = { deaths: [], seen: new Set() };
    if (logPath) {
        const RE = /(?:<[^>]*>\s+)?(\w+) (?:tried to swim in lava|drowned|died|was slain|was shot by|was blown up|was killed by|hit the ground too hard|went off with a bang|was squashed|was impaled|was pricked to death|drowned|fell from a high place|was fireballed|was burned|was struck by lightning|was killed|burned to death|suffocated in a wall|was starved to death|died)/;
        setInterval(() => {
            let txt = '';
            try { txt = fs.readFileSync(logPath, 'utf8'); } catch { return; }
            for (const line of txt.split(/\r?\n/)) {
                if (rec.seen.has(line) || !/ died |tried to swim|drowned|was slain|suffocated|blew up|hit the ground|was fireballed|burned to death|was squashed|was killed by|was impaled|was pricked|fell from a high|was starved|was blown up|struck by lightning/.test(line)) continue;
                rec.seen.add(line);
                rec.deaths.push({ at: new Date().toISOString(), line: line.trim() });
                try { onDeath?.(line.trim()); } catch { /* 忽略 */ }
            }
        }, 2000);
    }
    return rec;
}

export function record(phase, data) {
    const line = JSON.stringify({ t: new Date().toISOString(), phase, ...data });
    try { fs.appendFileSync(path.join(state.runDir, 'harness_log.jsonl'), line + '\n'); } catch { /* 忽略 */ }
    log(`[${phase}] ${JSON.stringify(data)}`);
}

export function writeSummary(extra = {}) {
    if (!state.runDir) return null;
    const p = path.join(state.runDir, 'summary.json');
    fs.writeFileSync(p, JSON.stringify({ stamp: state.stamp, at: new Date().toISOString(), ...extra }, null, 2));
    return p;
}

export const argv = (n, d = null) => argOf(process.argv, n, d);
