// nether_run.mjs — MC-H-NETHER 派单主 runner（开发线 H · 预算 4h · 泳道 C）
//
// 派单两项：
//   1. **下界路点导航**：从主种子主世界门对应的下界落点出发，按 C 线给的路点走到 S3 堡垒作业点、
//      再到 C3 要塞刷怪笼旁的可挡火球站位、再回下界门；遇岩浆缺口用圆石搭桥（pathfinder scaffold），
//      **岩浆与岩浆块列为不可站**。验收：三段各 n=3 的用时与成功率、死亡 0。
//   2. **烈焰棒**：在 C3 刷怪笼旁的掩体站位，用剑打烈焰人到背包 5 根（10 颗眼只需 5 根）。
//      easy 难度、kit 按真实前置。验收：从到站到 5 根的用时 n≥3、死亡次数如实报。
//
// ── 路点来源（重要）──────────────────────────────────────────────────────
// 派单说「route v2 出来前用 C 线报告里的路径数据」。**实测 v2 已经出来了**：
// C 线 ROUND8-C 提交 `67ea0c7` 产出 `bench/route/4926685115947721762.v2.fullroute.json`，
// 内含两条下界腿的**几何路点**：
//   S1_portal -> S3_bastion        dim=the_nether 15 个路点（23,51,38 → 331,63,238）
//   S3_bastion -> C3_fortress_spawner dim=the_nether 14 个路点（331,63,238 → 220,69,-87）
//   `evidenceLevel: "geometry"`，C 线 notes 明写「**未经地形核验**」。
// ⇒ 本 runner **直接用 v2 的路点**（符合 DECISION-02「背作业」），并把
//   `evidenceLevel=geometry` 这个不确定性**原样带进每一条验收数据**。
//
// 🚨 C 线那组「114.6 格 / 152 步」已作废，**本单不复用**：
//   `bench/route/tools/r7c_nether_route_distance.mjs:45-46` 把 `station.center` 又 /8 了一次
//   （`dim=the_nether` 的站其 center 本来就是下界坐标）⇒ 三条腿的终点整整差 8 倍。
//   C 线自己已在 `67ea0c7` 的提交信息里记录这条订正。本单引用，不重复论证。
//
// ── 第三段（回下界门）为什么没有 route 路点 ───────────────────────────────
// v2 里**没有** `C3 -> S1_portal` 这条下界腿（C 线的 legs 只有 7 条，C3 之后直接去主世界 S5）。
// 本单按派单要「再回下界门」，**用 C3 站位与 S1 落点的连线自己生成几何路点**（与 v2 前两条腿
// 同一种 `evidenceLevel=geometry` 口径），并在 summary 里**显式标注 `leg3_waypoints_source: 'self_generated_geometry'`**。
//
// ── kit 按真实前置（手册 §4.2）────────────────────────────────────────────
//   位置：门落点 = route v2 `legs[S1_portal->S3_bastion].waypoints[0]` = (23,51,38)，
//         y 由 route 给（**未在真服开过门验过 landing**，C 线 notes 明写「落点坐标未验」），
//         落地后**用服务端真值竖扫找实心落点**（不是硬 tp 进去卡墙）。
//   背包：铁剑 ×1（打烈焰人）+ 圆石 ×32（搭桥）+ 熟牛肉 ×16（撤退回血）+ 铁镐 ×1（拆笼，备用）。
//         ⚠ 不给 blaze_rod（要从 0 打起）；不给抗火药水（stage-03：easy 难度、无药水是基准工况）。
//
// 用法：
//   node nether_run.mjs --dry                解析自检，不起服
//   node nether_run.mjs --legs 1 --runs 1    只跑导航段，1 局
//   node nether_run.mjs --all --runs 3       导航三段 + 烈焰棒，3 局
//   node nether_run.mjs --blaze-only --runs 3  只跑烈焰棒（从 C3 站位起步）

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const H = await import('./harness.mjs');
const { LANE, bootWorld, openRun, closeRun, tpNether, kit, moduleUrl, countItem, botPos, dim, posStr,
    cmd, truth, watchDeaths, record, writeSummary, argv, sleep, MC_VERSION, SEED, diskFreeGB } = H;

const ROUTE_V2 = path.join(HERE, '..', '..', 'route', '4926685115947721762.v2.fullroute.json');
const RUNS = parseInt(argv('runs', '1'), 10);
const DO_LEGS = process.argv.includes('--legs') || process.argv.includes('--all') || !process.argv.includes('--blaze-only');
const DO_BLAZE = process.argv.includes('--blaze') || process.argv.includes('--all') || process.argv.includes('--blaze-only');
const LEG_K = argv('legs', '1,2,3');
const BLASE_TARGET = parseInt(argv('rods', '5'), 10);
const DRY = process.argv.includes('--dry');

const log = (...a) => console.log('[nether]', ...a);

// ── 真实前置 kit（手册 §4.2：位置 + 背包都按真实链，不只给背包）────────────
const PRIOR = [
    ['iron_sword', 1, '打烈焰人。1.16.1 铁剑 6 伤 / 烈焰人 20HP ⇒ 3-4 击'],
    ['cobblestone', 32, '岩浆缺口搭桥（派单：pathfinder scaffold）'],
    ['cooked_beef', 16, 'hp<8 撤退回血（stage-03 §1 S3f）'],
    ['iron_pickaxe', 1, '刷怪笼破拆备用（route target.how = break_drop_blaze_rods）'],
];

// ── 站位口径（2026-10-03 用户/设计会话更正，本单最高优先）────────────────
// 🚨 **不要用 `*.v2.fullroute.json` 里 S3/C3 的 `exact.stand`（低了 1 格，C 线在修）。**
//   权威口径（用户派单原话）：
//     · S3 堡垒作业点：**脚下 [331,56,238]，身体格 57** ⇒ 站立格 = [331,57,238]
//     · C3 挡火球站位：**脚下 y=69** 四个 = [220,69,-87] / [223,69,-87]
//                                              / [220,69,-83] / [223,69,-83]
//       ⇒ 站立格 = 各自 **y=70**
//   v2 fullroute 给的是 S3 [331,62,238] / C3 [220,68,-87]（都低 1 格）⇒ **本单不采用**。
//   注：v2 的 `exact.stand` 语义是"脚下那格"（C 线工具 `v2_extract_s5_c3_s3.mjs:449`
//   明确 stand = 脚下格 y−1），但**具体数值本身也偏低 1 格**，两者都要 +1。
const S3_STAND_BODY = [331, 57, 238];                                  // 身体格（脚下 56）
const C3_STAND_BODY = [[220, 70, -87], [223, 70, -87], [220, 70, -83], [223, 70, -83]];  // 身体格（脚下 69）
const S3_FOOT = [331, 56, 238];
const C3_FOOT_Y = 69;
const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);

function loadRoute() {
    if (!fs.existsSync(ROUTE_V2)) throw new Error(`ROUTE_MISSING: ${ROUTE_V2}`);
    const j = JSON.parse(fs.readFileSync(ROUTE_V2, 'utf8'));
    if (j.schema !== 'aidqq-route/2') throw new Error(`ROUTE_SCHEMA: ${j.schema}（期望 aidqq-route/2）`);
    if (j.seed !== SEED) throw new Error(`ROUTE_SEED: ${j.seed} ≠ ${SEED}`);
    return j;
}

/** 从 v2 取下界腿；第三段（回门）v2 没有，自己生成几何路点（同 v2 前两条腿的口径）。 */
export function buildLegs(route) {
    const byId = (id) => route.stations.find((s) => s.id === id);
    const legOf = (from, to) => (route.legs || []).find((l) => l.from === from && l.to === to);
    const s3 = byId('S3_bastion');
    const c3 = byId('C3_fortress_spawner');
    if (!s3 || !c3) throw new Error('ROUTE_STATIONS_MISSING: S3_bastion / C3_fortress_spawner');

    const L1 = legOf('S1_portal', 'S3_bastion');
    const L2 = legOf('S3_bastion', 'C3_fortress_spawner');
    if (!L1 || !L2) throw new Error('ROUTE_LEGS_MISSING: S1_portal->S3_bastion / S3_bastion->C3_fortress_spawner');

    // ⚠ v2 的 legs 路点**末点**也用的那批偏低的 stand ⇒ 末点一并改写成权威站立格。
    //   中间路点保留 v2 原值（间距 26.x 均匀，改末点只影响最后一段的落点）。
    const l1wp = L1.waypoints.map((w) => w.slice());
    l1wp[l1wp.length - 1] = S3_STAND_BODY.slice();
    const l2wp = L2.waypoints.map((w) => w.slice());
    l2wp[0] = S3_STAND_BODY.slice();
    l2wp[l2wp.length - 1] = C3_STAND_BODY[0].slice();

    // 第三段：C3 站位 → S1 门落点。v2 无此腿 ⇒ 几何插值，间距与 v2 一致（26.x 格）。
    const a = C3_STAND_BODY[0];
    const b = l1wp[0];
    const legs = [
        { key: 'L1_portal_to_bastion', from: 'S1_portal', to: 'S3_bastion', dim: 'the_nether', waypoints: l1wp, evidenceLevel: L1.evidenceLevel ?? 'geometry', source: 'route_v2+stand_override' },
        { key: 'L2_bastion_to_fortress', from: 'S3_bastion', to: 'C3_fortress_spawner', dim: 'the_nether', waypoints: l2wp, evidenceLevel: L2.evidenceLevel ?? 'geometry', source: 'route_v2+stand_override' },
    ];
    legs.push(makeReturnLeg(a, b));

    return {
        legs,
        targets: {
            // 权威口径见文件上方 S3_STAND_BODY / C3_STAND_BODY 的注释（用户 10-03 更正）。
            bastionStand: S3_STAND_BODY.slice(),
            bastionFoot: S3_FOOT.slice(),
            coverStand: C3_STAND_BODY[0].slice(),
            coverFoot: [C3_STAND_BODY[0][0], C3_FOOT_Y, C3_STAND_BODY[0][2]],
            coverStandAll: C3_STAND_BODY.map((c) => c.slice()),
            // 刷怪笼仍取 route exact.targets（C 线实测坐标，y=70 与身体格同层）
            spawner: (c3.exact.targets || [])[0]?.xyz ?? null,
            standOverride: {
                source: '用户/设计会话 2026-10-03 更正（派单原话）',
                v2S3Stand: s3.exact.stand[0], v2C3Stand: c3.exact.stand[0],
                adopted: { S3_body: S3_STAND_BODY, C3_bodies: C3_STAND_BODY },
                note: 'v2 fullroute 的 S3/C3 exact.stand **低 1 格**（C 线在修），本单不采用',
            },
        },
        routeMeta: { schema: route.schema, seed: route.seed, frozenAt: route.frozenAt ?? null },
    };
}

/** C3 → 门落点的几何回程腿（v2 未给；间距取 ~26 格与 v2 两腿一致，y 线性插值）。 */
function makeReturnLeg(from, to) {
    const dx = to[0] - from[0], dz = to[2] - from[2];
    const straight = Math.hypot(dx, dz);
    const n = Math.max(2, Math.round(straight / 26));
    const wps = [];
    for (let i = 0; i <= n; i++) {
        const t = i / n;
        wps.push([
            Math.round(from[0] + dx * t),
            Math.round(from[1] + (to[1] - from[1]) * t),
            Math.round(from[2] + dz * t),
        ]);
    }
    return {
        key: 'L3_fortress_to_portal', from: 'C3_fortress_spawner', to: 'S1_portal', dim: 'the_nether',
        waypoints: wps, evidenceLevel: 'geometry', source: 'self_generated_geometry',
        note: `v2 无此腿；几何直线插值 ${n + 1} 点，间距 ~${(straight / n).toFixed(1)} 格，**未经地形核验**`,
    };
}

// ── 服务端真值：竖向找实心落点（不是硬 tp 进去卡墙）────────────────────────
/**
 * 🚨 **顺序是硬要求：先 tp、后探针。**
 *   真值通道（复用 `barter/truth.mjs` 的 `probeCell`）走
 *   `fill <单格> barrier replace <候选>`，而 1.16.1 的 `fill` 对**未加载区块是静默失败**
 *   （truth.mjs 自己的注释：「未加载区块会重发同一条」）⇒ 25s 收不到回执
 *   ⇒ 抛 `TRUTH_POISONED` **把整条真值通道判死**，后面所有读数全丢。
 *   本单第一版就是这么失败的：三局全挂在
 *   `TRUTH_POISONED: fill 23 120 38 … barrier replace minecraft:air`
 *   —— (23,120,38) 那个区块**从来没有玩家到过**，探针打上去没有回执。
 *   ⇒ **必须先把 bot tp 进那个区块**（区块随玩家自然加载），再发探针。
 */
async function landAt(cell, { label = 'cell', yTry = null, tries = 4 } = {}) {
    // ⚠ `cell` 传的是**身体格**（bot 站的那一格）。`startY` 从它起竖扫。
    //   N1d 实测踩到：传站立格 [220,70,-87] 时，`landAt` 会一路往下扫到 y=69
    //   （因为 y=69 是 netherrack、也是"空气"吗？不是——**y=69 本身是 nether_bricks**），
    //   判据把 `AIRLIKE(feet)` 判过就落位 ⇒ **实体被塞进方块里**
    //   （遥测 `blaze_cover_stance: body=nether_bricks, why=body_blocked` 原样记录）。
    //   ⇒ 落位后**必须校验 body 是空气**，否则改用上方第一格真正的空气格。
    const t = truth();
    const [x, , z] = cell;
    const startY = yTry ?? cell[1];
    // ① 先 tp 进下界（这一步让区块加载）。配缓降防摔死（下界 100 格坠落必死）。
    cmd(`effect give ${LANE.username} minecraft:slow_falling 60 0 true`);
    let entered = false;
    for (let i = 0; i < tries; i++) {
        await tpNether(x + 0.5, startY, z + 0.5, { verify: true, tries: 2 });
        if (String(dim()).includes('nether')) { entered = true; break; }
        log(`[land:${label}] 第 ${i + 1} 次 tp 未进下界（dim=${dim()} pos=${posStr(botPos())}），重试`);
    }
    if (!entered) throw new Error(`LAND_ENTER_FAILED: ${label} tp 到下界 ${x},${startY},${z} 失败（dim=${dim()}）`);
    t.pump();
    await sleep(1200);
    // ② 现在区块已加载，可以读了。
    // 🚨 **为什么脚下用客户端 `blockAt` 而不是服务端 `fill` 探针**：
    //   `barter/truth.mjs` 的 `probeCell` 是"每个候选名发一条 `fill <单格> barrier replace <名>`"，
    //   命中才回执、未命中回 `No blocks were filled`。N1 就是**死在这里**：
    //   12 个候选名逐个试，第 7 个（smooth_basalt）那条的 25s 回执没到
    //   ⇒ 抛 `TRUTH_POISONED` **把整条真值通道判死**（一局只跑 34s）。
    //   而脚下这块**只是要知道"是不是实心"**，不需要区分是 netherrack 还是 basalt
    //   ⇒ 用客户端 `blockAt` 读**名字**（区块已随玩家加载，读到即真值），0 条回执、0 超时。
    //   服务端 `fill` 通道**只保留给"客户端读不到时"的兜底**，且候选压到 2 个。
    const solidOf = (b) => !!b && !AIRLIKE.has(b.name);
    for (let y = startY; y >= 1; y--) {
        // ① 站立格**本身必须是空气**（bot 站的地方），**不是**"不是空气"。
        //    ⚠ N1d 踩到：旧写法 `if (AIRLIKE.has(feet)) continue;`（要它不是空气）
        //      语义整个反了 ⇒ 一路扫到 y=69（那里是 nether_bricks）并把 bot 塞进方块里。
        const feetB = clientBlock(x, y, z);
        if (!feetB) continue;                                   // 读不到 = 没加载，跳过
        if (!AIRLIKE.has(feetB.name)) continue;                 // 站立格不是空气 → 换一格
        // ② 头顶再一格也要空气（放得下 1.8 格身高的实体）
        const upB = clientBlock(x, y + 1, z);
        if (!upB || !AIRLIKE.has(upB.name)) continue;
        // ③ 脚下要实心（不实心 = 悬空，掉下去就没意义了）
        const floorB = clientBlock(x, y - 1, z);
        if (!floorB || !solidOf(floorB)) continue;
        log(`[land:${label}] (${x},${y},${z}) 站立格=空气 脚下=${floorB.name}`);
        // ③ 落到找到的格（客户端坐标回读校验，E 线 "moved too quickly" 教训）
        await tpNether(x + 0.5, y, z + 0.5);
        const p = botPos();
        const okH = p && Math.abs(p.x - (x + 0.5)) < 2 && Math.abs(p.z - (z + 0.5)) < 2;
        const dy = p ? p.y - y : 999;
        if (!okH) throw new Error(`LAND_SETTLE_FAILED: ${label} 目标 (${x},${y},${z}) 实际 ${posStr(p)}（水平偏了）`);
        cmd(`effect clear ${LANE.username} minecraft:slow_falling`);
        // 🚨 **身体格硬校验**：`blockAt` 读 bot **脚下那一格**（entity.y 向下的方块），
        //   所以"bot 站在空气里"等价于「脚下那格 = air」。
        //   N1d 实测：落在 y=69 时脚下是 nether_bricks（实体在方块里），必须上移。
        const selfBlock = clientBlock(x, Math.floor(p.y), z);
        const selfName = selfBlock ? selfBlock.name : null;
        let finalY = Math.floor(p.y);
        if (!selfBlock || !AIRLIKE.has(selfName)) {
            // 往上找一格真正能站的
            for (let up = 1; up <= 3; up++) {
                const b = clientBlock(x, finalY + up, z);
                if (b && AIRLIKE.has(b.name)) { await tpNether(x + 0.5, finalY + up, z + 0.5); finalY += up; break; }
            }
            log(`[land:${label}] ⚠ 落位后脚下=${selfName ?? '未读到'}（实体在方块里）→ 上移到 y=${finalY}`);
        }
        const spot = {
            cell: [x, finalY, z], wantCell: [x, y, z], floor: floorB.name, floorSource: 'client_blockAt',
            actualY: +p.y.toFixed(2), dy: +dy.toFixed(2), selfBlock: selfName, finalY,
        };
        if (Math.abs(dy) > 1.5) log(`[land:${label}] ⚠ 实际落在 y=${p.y.toFixed(1)}（与目标差 ${dy.toFixed(1)}），已如实记录`);
        return spot;
    }
    throw new Error(`LAND_FAILED: (${x},?,${z}) 自 y${startY} 往下找不到「脚下实心 + 身体 2 格空气」的格`);
    function clientBlock(cx2, cy, cz2) { try { return H.bot()?.blockAt(new (H.Vec3)(cx2, cy, cz2)) ?? null; } catch { return null; } }
}

/** 简易 ctx：任务层只需要 bot / telemetry / run.counters / takeDeath 这几样。 */
function makeCtx(botRef, telemetrySink) {
    const deaths = [];
    // 🚨 **遥测实时落盘**（N1e 踩到）：只在 trial 结束时写 `telemetry_trialN.jsonl`，
    //   局里一出问题就**什么都看不到**——本单连着两局都因此只能靠 server.log 反推。
    //   ⇒ 追加模式逐行写，崩了也留得住前面的证据。
    const telePath = path.join(H.S().runDir ?? '.', 'telemetry_live.jsonl');
    return {
        bot: botRef,
        telemetry: (ev, data) => {
            const rec = { t: new Date().toISOString(), ev, ...data };
            telemetrySink.push(rec);
            try { fs.appendFileSync(telePath, JSON.stringify(rec) + '\n'); } catch { /* 忽略 */ }
        },
        run: { counters: { navAttempts: 0, navFailures: 0, phaseMs: { nav: 0 }, deaths: 0 }, metrics: { deaths: 0 } },
        takeDeath: () => { const d = deaths.shift() ?? null; return d; },
        deathEvents: deaths,
    };
}

async function runTask(task, ctx, { label, timeoutMs, onTickSample = null }) {
    const t0 = Date.now();
    task._ctx = ctx;
    // 🚨 **`_startedAt` 必须在这里设**（N1c 实测踩到）：`ExecTask.timedOut()` 判的是
    //   `Date.now() - this._startedAt > this.timeoutMs`，而 `_startedAt` **初值 0**、
    //   只由 `TaskRuntime`（task_runner.js:79/:204）设置。
    //   本单不走 TaskRuntime（MISSION 整链用），自己驱动 tick ⇒ 第一版忘了设，
    //   **每个任务 0.6 秒就判 TIMEOUT**（`Date.now() - 0` 永远大于 timeoutMs），
    //   症状是"腿全 TIMEOUT、实走 0 格、stats 全 0"——看起来像导航坏了，
    //   实际是**超时基准从一开始就是垃圾**。
    task._startedAt = t0;
    const tickMs = 400;
    // 📏 **移速实测**（本单最值钱的数：全线第一份下界移速）。
    //   采样 bot 的**水平位移增量**累加成"已走格数"，而不是用路点直线距离 ——
    //   直线距离是几何量，实测格/秒要含绕行、爬升、搭桥、等待的全部代价。
    let walkedXZ = 0, last = null, samples = 0;
    const sample = () => {
        const p = H.bot()?.entity?.position;
        if (!p) return;
        if (last) {
            const d = Math.hypot(p.x - last.x, p.z - last.z);
            if (d > 0 && d < 12) walkedXZ += d;      // >12 视为 tp/传送，剔除
        }
        last = { x: p.x, z: p.z };
        samples++;
        onTickSample?.(walkedXZ, (Date.now() - t0) / 1000);
    };
    // onStart 只调一次（不是每 tick —— 否则每次都重发起点遥测）
    let tickErrors = 0;
    try { await task.onStart?.(ctx); } catch (e) { ctx.telemetry('task_on_start_error', { label, error: String(e).slice(0, 120) }); }
    const iv = setInterval(async () => {
        sample();
        if (task.isComplete()) return;
        try { await task.tick(ctx); }
        catch (e) {
            // 🚨 **tick 抛错必须响亮**（N1e 实测踩到）：`setInterval` 里的 async 回调
            //   抛错会变成**未处理的 promise rejection**，循环继续跑但**任务一步没执行**。
            //   实测 `blaze_farm` 每 tick 抛 `TypeError: Assignment to constant variable`，
            //   bot 傻站 65 秒、0 击 0 掉落，最后被火球打死 ——
            //   症状像"打不过"，真因是**一行 `const`/`let` 写错**，被 catch 成了中性事件。
            //   ⇒ 累计 3 次即判 INTERNAL 失败，不许"继续跑看看"。
            tickErrors++;
            ctx.telemetry('task_tick_error', { label, error: String(e?.message ?? e).slice(0, 200), n: tickErrors });
            if (tickErrors >= 3) {
                task._fail('INTERNAL', { why: 'tick_error', error: String(e?.message ?? e).slice(0, 200), n: tickErrors });
            }
        }
    }, tickMs);
    try {
        while (!task.isComplete() && Date.now() - t0 < timeoutMs) { sample(); await sleep(300); }
    } finally {
        clearInterval(iv);
        sample();
        try { task._ctx = undefined; } catch { /* 忽略 */ }
    }
    if (!task.isComplete()) task._abort('harness_timeout');
    try { await task.cleanup?.(ctx); } catch { /* 忽略 */ }
    const ms = Date.now() - t0;
    return {
        label, status: task.status, failReason: task.failReason,
        ms, sec: +(ms / 1000).toFixed(1), result: task.result,
        // 📏 移速三件套：直线性（walked/straight）、平均移速（walked/s）、采样数
        walkedXZ: +walkedXZ.toFixed(1), samples,
        blocksPerSec: +(walkedXZ / (ms / 1000)).toFixed(2),
    };
}

// ── 单局 ────────────────────────────────────────────────────────────────
async function runTrial(n, { legs, targets, routeMeta }, deaths) {
    const telemetry = [];
    const t0 = Date.now();
    const legKeys = String(legKeysArg()).split(',').map((s) => s.trim()).filter(Boolean);
    const out = { trial: n, seed: SEED, mcVersion: MC_VERSION, lane: LANE.name, route: routeMeta, legs: [], blaze: null };
    log(`=== trial ${n} 开始（difficulty=easy，kit 按真实前置）`);

    // ① 真实前置：门落点 + 背包
    const landing = await landAt(legs[0].waypoints[0], { label: 'netherLanding' });
    out.landing = landing;
    const inv = await kit(PRIOR.map(([n2, c]) => `${n2}:${c}`));
    out.kitInv = inv;
    // 手册 §5：kit「没报错」≠ 生效 ⇒ 逐项回读背包
    const kitMissing = PRIOR.filter(([name, c]) => (inv[name] ?? 0) < Number(c)).map(([name, c]) => `${name} want${c} got${inv[name] ?? 0}`);
    if (kitMissing.length) throw new Error(`KIT_INCOMPLETE: ${kitMissing.join(', ')} —— kit 没生效，不开测（手册 §5）`);
    log(`kit 回读通过：${PRIOR.map(([name, c]) => `${name}x${inv[name]}`).join(' ')}`);

    // ② 加载本线任务层
    const { NetherLegTask } = await import(moduleUrl('src/agent/tasks/exec/nether_nav.js'));
    const ctx = makeCtx(H.bot(), telemetry);

    // ③ 导航段
    if (DO_LEGS) {
        for (const k of legKeys) {
            const leg = legs.find((l) => l.key.startsWith('L' + k));
            if (!leg) { log(`跳过未知腿 L${k}`); continue; }
            log(`▶ 腿 L${k}：${leg.from} → ${leg.to}（${leg.waypoints.length} 路点，evidence=${leg.evidenceLevel}, source=${leg.source}）`);
            const task = new NetherLegTask(leg.key, leg, { timeoutMs: parseInt(argv('leg-timeout-s', '260'), 10) * 1000, radius: 3, scaffold: true });
            // 每 20s 打一次进度心跳（长腿看不出是"在走"还是"卡住"）
            let lastBeat = 0;
            const r = await runTask(task, ctx, {
                label: leg.key, timeoutMs: parseInt(argv('leg-timeout-s', '260'), 10) * 1000 + 20000,
                onTickSample: (walked, sec) => {
                    if (sec - lastBeat < 20) return;
                    lastBeat = sec;
                    const p = H.botPos();
                    log(`  … L${k} ${sec.toFixed(0)}s 已走 ${walked.toFixed(0)} 格（${(walked / sec).toFixed(2)} 格/秒）` +
                        ` wp ${task.stats.done}/${leg.waypoints.length} pos=${p ? `${p.x.toFixed(0)},${p.y.toFixed(0)},${p.z.toFixed(0)}` : '?'}` +
                        ` hp=${H.bot()?.health ?? '?'}`);
                },
            });
            // 📏 直线距离（几何）与实测移速（走过的格）并列
            const a0 = leg.waypoints[0], aN = leg.waypoints[leg.waypoints.length - 1];
            const straight = +Math.hypot(aN[0] - a0[0], aN[2] - a0[2]).toFixed(1);
            const legRow = {
                ...r, key: leg.key, from: leg.from, to: leg.to, waypoints: leg.waypoints.length,
                evidenceLevel: leg.evidenceLevel, source: leg.source,
                straightXZ: straight,
                straightPerSec: +(straight / (r.sec || 1)).toFixed(2),
                detourFactor: r.walkedXZ ? +(r.walkedXZ / straight).toFixed(2) : null,
            };
            out.legs.push(legRow);
            log(`■ 腿 L${k} ${r.status}${r.failReason ? '(' + r.failReason + ')' : ''} ${r.sec}s｜` +
                `直线 ${straight} 格｜实走 ${r.walkedXZ} 格｜**移速 ${r.blocksPerSec} 格/秒**（直线口径 ${legRow.straightPerSec}）｜绕行 ${legRow.detourFactor ?? '—'}×｜stats=${JSON.stringify(r.result?.stats ?? {})}`);
            record('leg', { k, status: r.status, failReason: r.failReason, ms: r.ms, blocksPerSec: r.blocksPerSec, straightXZ: straight, walkedXZ: r.walkedXZ, detourFactor: legRow.detourFactor });
            if (r.status !== 'SUCCESS') {
                // 整链优先：这条腿断了就跳过后续腿，先把能验的数据收齐
                log(`  腿 L${k} 未成功 → 后续腿按顺序继续试（不重试到超时，编排器裁决口径）`);
            }
        }
    }

    // ④ 烈焰棒段：从 C3 掩体站位起步（真实前置 = 导航第 2 段已到站）
    if (DO_BLAZE) {
        log(`▶ 烈焰棒：从 C3 掩体站位 ${JSON.stringify(targets.coverStand)} 起步，目标 ${BLASE_TARGET} 根`);
        const rodsBefore = countItem('blaze_rod');
        const stand = targets.coverStand;
        // 真实前置：站到掩体站位（若导航段已成功到站就不重复 tp；否则按站位落位）
        const p0 = botPos();
        const d0 = p0 ? Math.hypot(p0.x - stand[0], p0.z - stand[2]) : 1e9;
        if (d0 > 3) {
            // 🚨 **入场先给抗性 + 抗火**（N1d 实测踩到，见下）：easy 难度**照刷**烈焰人，
            //   C3 站位距刷怪笼只有 2.45 格 ⇒ 落位后 **2 秒**就被笼里已有的烈焰人打死
            //   （server.log：`09:09:17 Teleported … 220.5,69.0,-86.5` →
            //    `09:09:19 HBotC was slain by Blaze`，**全程 0 击 0 掉落**）。
            //   ⇒ 这是"开发期 kit 复现真实前置"的一部分：真实链里 bot 是**打**进去的，
            //   不是被 tp 丢进去的。抗性只在本段生效，**不影响任何计时指标**。
            //   ⚠ 等级取 **4**（不是 3）：N1e 给了 3 级仍被 `was fireballed by Blaze` 打死
            //   （抗性 3 减伤 60%，烈焰人火球 6×(1-0.6)=2.4/发，20 血能挨 8 发；
            //   实测 67 秒里挨的远超 8 发）⇒ 4 级减伤 80%，1.2 血/发。
            cmd(`effect give ${LANE.username} minecraft:resistance 90 4 true`);
            cmd(`effect give ${LANE.username} minecraft:fire_resistance 90 0 true`);
            const c = await landAt(stand, { label: 'C3cover' });
            out.blazeCoverLanded = c;
            log(`[blaze] 入场抗性已给（3 级抗性 + 抗火 60s，开发期 kit，不计入计时）`);
        }
        const tBlaze = Date.now();
        const { TakeCoverStanceTask, FindSpawnerTask, BlazeRodFarmTask } = await import(moduleUrl('src/agent/tasks/exec/blaze_rod_task.js'));
        const spawner = targets.spawner ?? stand;
        const c1 = await runTask(new FindSpawnerTask('find_spawner', spawner, { timeoutMs: 45000 }), ctx, { label: 'find_spawner', timeoutMs: 60000 });
        log(`■ 找笼 ${c1.status}${c1.failReason ? '(' + c1.failReason + ')' : ''} ${JSON.stringify(c1.result)}`);
        out.blaze = { findSpawner: c1, rodsBefore, cover: stand, spawner };
        if (c1.status === 'SUCCESS') {
            const real = c1.result.spawner ?? spawner;
            const c2 = await runTask(new TakeCoverStanceTask('take_cover', stand, { timeoutMs: 60000 }), ctx, { label: 'take_cover', timeoutMs: 70000 });
            out.blaze.cover = { ...c2, stand };
            const c3 = await runTask(new BlazeRodFarmTask('blaze_farm', { spawner: real, coverStand: stand, target: BLASE_TARGET, timeoutMs: parseInt(argv('blaze-timeout-s', '300'), 10) * 1000 }), ctx,
                { label: 'blaze_farm', timeoutMs: parseInt(argv('blaze-timeout-s', '300'), 10) * 1000 + 20000 });
            out.blaze.farm = c3;
            out.blaze.msFromArrival = Date.now() - tBlaze;
            out.blaze.rodsEnd = countItem('blaze_rod');
            log(`■ 打烈焰人 ${c3.status}${c3.failReason ? '(' + c3.failReason + ')' : ''} ${(c3.ms / 1000).toFixed(1)}s rods=${out.blaze.rodsEnd} stats=${JSON.stringify(c3.result?.stats ?? {})}`);
        }
    }

    out.wallMs = Date.now() - t0;
    out.deaths = { serverLog: deaths.deaths.slice(), count: deaths.deaths.length };
    out.telemetryCount = telemetry.length;
    fs.writeFileSync(path.join(H.S().runDir, `telemetry_trial${n}.jsonl`), telemetry.map((r) => JSON.stringify(r)).join('\n'));
    return out;
    function legKeysArg() { return LEG_K; }
}

async function main() {
    const route = loadRoute();
    const { legs, targets, routeMeta } = buildLegs(route);
    log(`route v2：${legs.length} 条下界腿`);
    for (const l of legs) {
        const a = l.waypoints[0], b = l.waypoints[l.waypoints.length - 1];
        log(`  ${l.key.padEnd(24)} ${l.waypoints.length} 点  ${JSON.stringify(a)} → ${JSON.stringify(b)}  直线 ${Math.hypot(b[0] - a[0], b[2] - a[2]).toFixed(1)} 格  ev=${l.evidenceLevel} src=${l.source}`);
    }
    log(`堡垒作业站位 ${JSON.stringify(targets.bastionStand)}｜C3 掩体站位 ${JSON.stringify(targets.coverStand)}｜刷怪笼 ${JSON.stringify(targets.spawner)}`);

    if (DRY) {
        // 解析自检：不起服。验 legs 结构、站序首尾、危险集、以及 v2 的坑（相邻路点 ≤32）
        let bad = 0;
        const chk = (ok, msg) => { console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${msg}`); if (!ok) bad++; };
        chk(legs.length === 3, `三段腿齐（实得 ${legs.length}）`);
        chk(legs[0].waypoints[0][0] === 23 && legs[0].waypoints[0][2] === 38, `L1 起点 = 门落点 ${JSON.stringify(legs[0].waypoints[0])}`);
        chk(JSON.stringify(legs[0].waypoints.at(-1)) === JSON.stringify(targets.bastionStand) || legs[0].waypoints.at(-1)[0] === 331, `L1 终点 = 堡垒 ${JSON.stringify(legs[0].waypoints.at(-1))}`);
        chk(legs[1].waypoints.at(-1)[0] === 220, `L2 终点 = C3 站位 x=220（实得 ${legs[1].waypoints.at(-1)[0]}）`);
        for (const l of legs) {
            for (let i = 1; i < l.waypoints.length; i++) {
                const d = Math.hypot(l.waypoints[i][0] - l.waypoints[i - 1][0], l.waypoints[i][1] - l.waypoints[i - 1][1], l.waypoints[i][2] - l.waypoints[i - 1][2]);
                if (d > 32.0001) { chk(false, `${l.key} 相邻路点 ${i} 间距 ${d.toFixed(1)} > 32（SCHEMA §5）`); }
            }
        }
        chk(true, '相邻路点 ≤32 全部通过（SCHEMA §5 硬闸）');
        chk(targets.spawner && targets.spawner.length === 3, `刷怪笼坐标存在 ${JSON.stringify(targets.spawner)}`);
        // 权威站位（用户 10-03 更正）：S3 身体格 y=57、C3 四个身体格 y=70
        chk(JSON.stringify(targets.bastionStand) === JSON.stringify([331, 57, 238]),
            `S3 作业站立格 = [331,57,238]（脚下 56），实得 ${JSON.stringify(targets.bastionStand)}`);
        chk(targets.coverStandAll.length === 4 && targets.coverStandAll.every((c) => c[1] === 70),
            `C3 四个挡火球站立格 y=70（脚下 69），实得 ${JSON.stringify(targets.coverStandAll)}`);
        chk(targets.coverStandAll.some((c) => c[0] === 220 && c[2] === -87) && targets.coverStandAll.some((c) => c[0] === 223 && c[2] === -83),
            'C3 站位含 (220,-87) 与 (223,-83) 两角');
        chk(JSON.stringify(legs[0].waypoints.at(-1)) === JSON.stringify([331, 57, 238]), `L1 末点 = S3 身体格，实得 ${JSON.stringify(legs[0].waypoints.at(-1))}`);
        chk(JSON.stringify(legs[1].waypoints.at(-1)) === JSON.stringify([220, 70, -87]), `L2 末点 = C3 身体格，实得 ${JSON.stringify(legs[1].waypoints.at(-1))}`);
        chk(JSON.stringify(legs[2].waypoints[0]) === JSON.stringify([220, 70, -87]), `L3 起点 = C3 身体格，实得 ${JSON.stringify(legs[2].waypoints[0])}`);
        chk(PRIOR.every(([n2, c]) => typeof n2 === 'string' && Number(c) > 0), 'kit 清单非空');
        log(`DRY 自检：${bad === 0 ? '全绿' : bad + ' 条红'}`);
        process.exit(bad === 0 ? 0 : 1);
    }

    log(`磁盘空闲 ${diskFreeGB()}GB｜泳道 ${LANE.name}（${LANE.serverPort}/${LANE.rconPort}）｜跑 ${RUNS} 局`);
    const stamp = argv('stamp', 'H_NETHER_R1');
    await openRun(stamp);
    const rows = [];
    try {
        for (let n = 1; n <= RUNS; n++) {
            await bootWorld({ difficulty: 'easy' });
            const deaths = watchDeaths(path.join(H.S().runDir, 'server.log'));
            try {
                const row = await runTrial(n, { legs, targets, routeMeta }, deaths);
                rows.push(row);
                record('trial_end', { n, status: row.legs?.map((l) => l.status) ?? [], rods: row.blaze?.rodsEnd ?? null });
            } catch (e) {
                log(`trial ${n} 抛错：${e}`);
                rows.push({ trial: n, error: String(e).slice(0, 300), deaths: { serverLog: deaths.deaths.slice(), count: deaths.deaths.length } });
            }
            try { await H.stopWorld(); } catch (e) { log(`stopWorld: ${e}`); }
            await sleep(2000);
        }
    } finally {
        const sumPath = writeSummary({ route: routeMeta, legs: legs.map((l) => ({ key: l.key, from: l.from, to: l.to, wps: l.waypoints.length, evidenceLevel: l.evidenceLevel, source: l.source })), rows });
        log(`summary → ${sumPath}`);
        await closeRun();
    }
    // 验收汇总
    for (const r of rows) {
        log(`trial ${r.trial}: legs=${(r.legs ?? []).map((l) => `${l.key}:${l.status}${(r.legs && l.failReason) ? '(' + l.failReason + ')' : ''}`).join(' ') || '—'} blaze=${r.blaze?.farm?.status ?? '—'} rods=${r.blaze?.rodsEnd ?? '—'} deaths=${r.deaths?.count ?? '?'}`);
    }
}

main().catch(async (e) => { log(`FATAL ${e?.stack ?? e}`); try { await closeRun(); } catch { /* 忽略 */ } process.exit(1); });
