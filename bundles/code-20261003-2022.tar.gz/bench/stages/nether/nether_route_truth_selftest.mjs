// nether_route_truth_selftest.mjs — MC-H-NETHER 离线自检：下界三段真值 + 危险集 + 静态判据
//
// 【为什么必须有这个自检】C 线 ROUND7-C 报过一组「三段直线 114.6 格 / 可走 152 步」，
//   数字自洽、可复算，但**量的是错的点**：`bench/route/tools/r7c_nether_route_distance.mjs:45-46`
//   把 `station.center` 又 /8 了一次，而 `dim=the_nether` 的站其 center **本来就是下界坐标**。
//   手册 §5「报'错'必须带阳性对照」+ §4.11「下结论前先证明测量通道能测出'有'」——
//   本文件就是那个阳性对照：**它证明"下界坐标"这条判据能测出「是」，也能测出「不是」。**
//
// 【覆盖三件事】
//   ① 下界站点的 center 确实是 nether 坐标（阳性对照：scout 逐格坐标落在 center 邻域）
//   ② 两种坐标口径的三段距离（÷8 vs 不÷8）并列，断言 C 线那组数字属于**作废**口径
//   ③ 危险集（岩浆 + 岩浆块）与"读失败 ≠ 目标"的判据静态性质
//
// 【变异测试】`--mutate=<名>` 至少 6 种，每种必须让自检变红（抓不到变异 = 自检无效）。
//
// 用法：
//   node nether_route_truth_selftest.mjs
//   node nether_route_truth_selftest.mjs --mutate=div8
//   node nether_route_truth_selftest.mjs --mutate=swapStations
//   node nether_route_truth_selftest.mjs --mutate=centerAsOverworld
//   node nether_route_truth_selftest.mjs --mutate=dropMagma
//   node nether_route_truth_selftest.mjs --mutate=dropReadFailed
//   node nether_route_truth_selftest.mjs --mutate=l2AsOverworld

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
const ROUTE_V1 = path.join(ROOT, 'bench', 'route', '4926685115947721762.json');
const ROUTE_V2 = path.join(ROOT, 'bench', 'route', '4926685115947721762.v2.fullroute.json');
const C_TOOL = path.join(ROOT, 'bench', 'route', 'tools', 'r7c_nether_route_distance.mjs');
const C_OUT = path.join(ROOT, 'bench', 'route', 'probe', 'nether_route_distance.round7c.json');
const NAV_MODULE = path.join(ROOT, 'mindcraft-wt', 'nether-run', 'src', 'agent', 'tasks', 'exec', 'nether_nav.js');

// ⚠ 同时支持 `--mutate div8` 与 `--mutate=div8` 两种写法：
//   只认分离参数的话，`--mutate=div8` 会静默返回 null ⇒ **六个变异全部"全绿"**，
//   看起来像自检很稳，实际是变异一个都没跑（这本身就是本项目最贵的一类假绿）。
const argOf = (n, d = null) => {
    const i = process.argv.indexOf('--' + n);
    if (i >= 0 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--')) return process.argv[i + 1];
    const eq = process.argv.find((a) => a.startsWith('--' + n + '='));
    return eq ? eq.slice(n.length + 3) : d;
};
const MUTATE = argOf('mutate', null);

let pass = 0, fail = 0;
const lines = [];
function chk(ok, msg, detail = '') {
    if (ok) { pass++; lines.push(`  [PASS] ${msg}`); }
    else { fail++; lines.push(`  [FAIL] ${msg}${detail ? ' — ' + detail : ''}`); }
    return ok;
}
const readJson = (f) => JSON.parse(fs.readFileSync(f, 'utf8'));

// ── 变异开关：每个变异**必须**让某些断言变红 ──────────────────────────────
const V = {
    div8: MUTATE === 'div8',                      // 误用 ÷8 口径
    swapStations: MUTATE === 'swapStations',      // S3/C3 对调
    centerAsOverworld: MUTATE === 'centerAsOverworld',   // 假设 center 是主世界坐标
    dropMagma: MUTATE === 'dropMagma',            // 危险集漏掉 magma_block
    dropReadFailed: MUTATE === 'dropReadFailed',  // 判据把 null 折算成"安全"
    l2AsOverworld: MUTATE === 'l2AsOverworld',    // L2 终点误当主世界坐标
};
if (MUTATE) lines.push(`=== 变异模式：${MUTATE} ===`);

if (!fs.existsSync(ROUTE_V1)) { console.log(`ROUTE_MISSING: ${ROUTE_V1}`); process.exit(1); }
const r1 = readJson(ROUTE_V1);
const byId = (id) => r1.stations.find((s) => s.id === id);   // 🚨 stations 是数组
const s3 = byId('S3_bastion');
const c3 = byId('C3_fortress_spawner');
const s4 = byId('S4_fortress_spawner');
const s1 = byId('S1_portal');

// ── ① 阳性对照：center 是不是 nether 坐标 ────────────────────────────────
// 判据本身必须能测出"匹配"，也要能测出"不匹配"（否则它是个恒真的摆设）。
lines.push('--- ① center 坐标约定（阳性对照）---');
chk(!!s3 && !!c3 && !!s4, '三个下界站都在 route 里');
chk(s3?.dim === 'the_nether' && c3?.dim === 'the_nether' && s4?.dim === 'the_nether',
    '三站 dim 都是 the_nether', `实得 ${s3?.dim}/${c3?.dim}/${s4?.dim}`);
chk(s1?.dim === 'overworld', 'S1_portal dim 是 overworld（对照：它才需要 ÷8）', `实得 ${s1?.dim}`);

/**
 * 点到 XZ 中心的水平距离。
 * 🚨 **`station.center` 是 [x, z] 两元素，不是 [x, y, z]** —— SCHEMA §2 写的是
 *   `center: [176, 352], // XZ`（只有 XZ，y 由 `yHint` 给提示不给真值）。
 *   把它当三元素解构会得到 `z = undefined` ⇒ 距离恒 NaN，
 *   而 `NaN <= 32` 是 false、`NaN > 32` 也是 false ⇒ **阳性对照与阴性对照会同时失效**。
 */
const hdist = (a, b) => Math.hypot(a[0] - b[0], a[2] - b[2]);
/** [x,z] 中心 → [x, y, z]（y 由调用方给，默认 0；XZ 距离不受影响） */
const c3v = (center, y = 0) => [center[0], y, center[1]];
/** 3D 距离（v2 legs 的 SCHEMA §5 硬闸用） */
const d3 = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

// 阳性：A —— C3 的四个掩体站位在 center 的 radius(32) 内
const c3stands = (c3.scout.cover?.stands ?? []).map((s) => s.pos);
chk(c3stands.length === 4, 'C3 有 4 个掩体站位', `实得 ${c3stands.length}`);
const c3max = Math.max(0, ...c3stands.map((p) => hdist(p, c3v(c3.station.center))));
const c3maxDiv = Math.max(0, ...c3stands.map((p) => hdist(p, [c3.station.center[0] / 8, 0, c3.station.center[1] / 8])));
const radius = c3.station.radius ?? 32;
if (!V.centerAsOverworld) {
    chk(c3max <= radius, `【阳性对照】C3 站位全在 center 的 radius=${radius} 内（最大 ${c3max.toFixed(1)} 格）`);
    chk(c3maxDiv > radius, `【阴性对照】同一个判据对 center÷8 **不成立**（${c3maxDiv.toFixed(1)} 格 > ${radius}）—— 证明判据能测出不匹配`, c3maxDiv <= radius ? '判据恒真，是摆设' : '');
} else {
    chk(c3maxDiv <= radius, '【变异】假设 center 是主世界坐标：站位应落在 center÷8 内', `实得 ${c3maxDiv.toFixed(1)} 格`);
}

// 阳性：B —— S3 的猪灵 bbox 在 center 邻域（用 bbox 而不是 scout.points[0]：
//   points[0] 是 hit_box (288,32,240)，相对 center 偏移 -48，**超出 ±32 会假红**）
const pig = s3.scout.piglinsWorldgen?.peaceful?.bbox;
if (!V.centerAsOverworld) {
    chk(!!pig, 'S3 有猪灵 bbox');
    if (pig) {
        const cx = (pig.x[0] + pig.x[1]) / 2, cz = (pig.z[0] + pig.z[1]) / 2;
        const off = Math.hypot(cx - s3.station.center[0], cz - s3.station.center[1]);
        chk(off <= 64, `【阳性对照】S3 猪群 bbox 中心距 center ${off.toFixed(1)} 格（≤64）`);
    }
} else {
    const cx = (pig.x[0] + pig.x[1]) / 2, cz = (pig.z[0] + pig.z[1]) / 2;
    const off = Math.hypot(cx - s3.station.center[0] / 8, cz - s3.station.center[1] / 8);
    chk(off <= 64, '【变异】假设 S3 center 是主世界坐标：猪群 bbox 中心应落在 center÷8 邻域', `实得 ${off.toFixed(1)} 格`);
}

// 阳性：C —— S4 备用要塞的刷怪笼相对 center 的偏移很小
const s4spawn = s4.scout.points?.[0];
if (s4spawn) {
    const off = hdist([s4spawn.x, s4spawn.y, s4spawn.z], c3v(s4.station.center));
    chk(off <= radius, `S4 刷怪笼距 center ${off.toFixed(1)} 格（≤${radius}）`);
}

// ── ② 两种坐标口径的三段距离 ───────────────────────────────────────────
lines.push('--- ② 三段距离（两种口径并列）---');
// S1 门在**主世界** (187,41,308) ⇒ nether = ÷8（这一步是对的）
const landing = [187 / 8, 41, 308 / 8];
// center 是 [x,z] ⇒ 先转成三元素再进后续计算
const sw = c3v(V.swapStations ? c3.station.center : s3.station.center);
const fw = c3v(V.swapStations ? s3.station.center : c3.station.center);
const asNether = (p3) => (V.div8 ? [p3[0] / 8, p3[1] / 8, p3[2] / 8] : p3);
const S3p = asNether(sw);
const C3p = asNether(fw);
const legs = [
    ['S1落点→S3', landing, S3p],
    ['S3→C3', S3p, C3p],
    ['C3→S1落点', C3p, landing],
];
const dXZ = (a, b) => Math.hypot(a[0] - b[0], a[2] - b[2]);
// ⚠ 口径 A 必须**精确复刻 C 线的错法**：它只对 S3/C3 的 center 额外 ÷8 一次，
//   **S1 落点本来就是主世界 ÷8 来的、不再动**。三个点统统再 ÷8 一次算出来是 122.5，
//   与 C 线报的 114.6 对不上 —— 那是"连错两次"，不是"错一次"。
//   复刻错法，阳性对照才咬得合。
const swA = [sw[0] / 8, sw[1], sw[2] / 8];       // C 线的错：S3 center 又 ÷8
const fwA = [fw[0] / 8, fw[1], fw[2] / 8];       // C 线的错：C3 center 又 ÷8
const legsA = [[landing, swA], [swA, fwA], [fwA, landing]];
const legsB = [[landing, S3p], [S3p, C3p], [C3p, landing]];
const totA = legsA.reduce((s, [a, b]) => s + dXZ(a, b), 0);
const totB = legsB.reduce((s, [a, b]) => s + dXZ(a, b), 0);
lines.push(`    口径A（复刻 C 线的错：S3/C3 各多 ÷8 一次）合计 ${totA.toFixed(1)} 格`);
lines.push(`    口径B（正确，不÷8）                      合计 ${totB.toFixed(1)} 格`);
chk(Math.abs(totA - 114.66) < 0.5, '口径A 复算 ≈ 114.6 格（与 C 线 round7c 逐位吻合 ⇒ 证明我复刻的就是它那个错）', `实得 ${totA.toFixed(2)}`);
chk(Math.abs(totB - 979.79) < 0.5, '口径B 复算 ≈ 979.8 格（真实量级）', `实得 ${totB.toFixed(2)}`);
// ⚠ 只断言"合计"会漏掉 **对调**这类变异：S3↔C3 对调后往返合计**逐位相同**
//   （去程+回程是同一对点的两向距离），只有**逐段**能咬住它。
const segA = legsA.map(([a, b]) => dXZ(a, b));
const segB = legsB.map(([a, b]) => dXZ(a, b));
lines.push(`    口径B 逐段：${segB.map((d) => d.toFixed(1)).join(' / ')} 格`);
chk(Math.abs(segB[0] - 380.84) < 0.5, `B 第1段（门落点→S3）≈ 380.8 格，实得 ${segB[0].toFixed(2)}`);
chk(Math.abs(segB[1] - 361.77) < 0.5, `B 第2段（S3→C3）≈ 361.8 格，实得 ${segB[1].toFixed(2)}`);
chk(Math.abs(segB[2] - 237.18) < 0.5, `B 第3段（C3→门落点）≈ 237.2 格，实得 ${segB[2].toFixed(2)}`);
chk(segB[0] > segB[2] && segB[1] > segB[2], 'B 逐段大小关系：门→S3 > C3→门 且 S3→C3 > C3→门（对调即破）');
if (!V.div8) {
    chk(totB > totA * 5, `真实量级远大于 C 线那组：${totB.toFixed(0)} / ${totA.toFixed(0)} = ${(totB / totA).toFixed(1)}×`);
} else {
    chk(Math.abs(totB - 114.66) < 0.5, '【变异】误用 ÷8 口径后应等于 C 线那组数字（因此作废）', `实得 ${totB.toFixed(2)}`);
}
// 自指断言：证明"多除一次 8"是**代码事实**而不是推测。
// ⚠ 行号精确：L44=S1(÷8 正确) / L45=S3(÷8 错) / L46=C3(÷8 错)。**别把 L44 一起判红。**
const csrc = fs.readFileSync(C_TOOL, 'utf8').split(/\r?\n/);
const line45 = csrc[44] ?? '';
const line46 = csrc[45] ?? '';
lines.push(`    源码 L45: ${line45.trim().slice(0, 90)}`);
lines.push(`    源码 L46: ${line46.trim().slice(0, 90)}`);
chk(/\b336\s*\/\s*8\b/.test(line45), 'C 线脚本 L45 对 S3 的 [336,256] 写了 /8（= 多除一次）');
chk(/\b224\s*\/\s*8\b/.test(line46), 'C 线脚本 L46 对 C3 的 [224,-88] 写了 /8（= 多除一次）');
chk(/\b187\s*\/\s*8\b/.test(csrc[43] ?? ''), '对照：C 线脚本 L44 对 S1 的 187 写 /8（**这次是对的**，S1 是主世界坐标）');

// 走廊窗断言：直接钉死"C 线量的是错点"
const cOut = readJson(C_OUT);
const win = cOut.world.window;
const inWin = (p) => p[0] >= win.x1 && p[0] <= win.x2 && p[2] >= win.z1 && p[2] <= win.z2;
if (!V.div8) {
    chk(!inWin(S3p) && !inWin(C3p), `【关键】真实目标 ${JSON.stringify(S3p)} / ${JSON.stringify(C3p)} **都在走廊存档窗外**（窗 x${win.x1}..${win.x2} z${win.z1}..${win.z2}）⇒ round7c 的 BFS 没测过真地形`);
    const wA = [sw[0] / 8, sw[1], sw[2] / 8];
    chk(inWin(wA), `【关键】而 ÷8 后的点 ${JSON.stringify(wA)} 恰好在窗内 ⇒ round7c 量的是主世界对应点的地形`);
}

// ── ③ route v2 的下界腿结构 ────────────────────────────────────────────
lines.push('--- ③ route v2 legs（BACKING：H 线实际使用的路点）---');
if (fs.existsSync(ROUTE_V2)) {
    const r2 = readJson(ROUTE_V2);
    chk(r2.schema === 'aidqq-route/2', 'v2 schema = aidqq-route/2', `实得 ${r2.schema}`);
    const l1 = (r2.legs ?? []).find((l) => l.from === 'S1_portal' && l.to === 'S3_bastion');
    const l2 = (r2.legs ?? []).find((l) => l.from === 'S3_bastion' && l.to === 'C3_fortress_spawner');
    chk(!!l1 && !!l2, 'v2 有两条 the_nether 腿');
    if (l1) {
        chk(l1.dim === 'the_nether' && l1.waypoints.length === 15, `L1 = 15 个下界路点（实得 ${l1.waypoints?.length}）`);
        chk(l1.evidenceLevel === 'geometry', `L1 evidenceLevel=geometry（C 线标注"未经地形核验"），实得 ${l1.evidenceLevel}`);
        chk(String(l1.notes ?? '').includes('未经地形核验') || String(l1.notes ?? '').includes('作废'), 'L1 notes 明写路点未经地形核验 / 旧数据作废');
        // 终点必须是 S3 作业点（**站立格**，不是脚下格）
        const s3stand = r2.stations.find((s) => s.id === 'S3_bastion').exact.stand[0];
        const end = l1.waypoints.at(-1);
        chk(end[0] === s3stand[0] && end[1] === s3stand[1] + 1 && end[2] === s3stand[2],
            `L1 终点 = S3 站立格（exact.stand+1）${JSON.stringify(end)} vs ${JSON.stringify([s3stand[0], s3stand[1] + 1, s3stand[2]])}`);
    }
    if (l2) {
        chk(l2.dim === 'the_nether' && l2.waypoints.length === 14, `L2 = 14 个下界路点（实得 ${l2.waypoints?.length}）`);
        const c3stand = r2.stations.find((s) => s.id === 'C3_fortress_spawner').exact.stand[0];
        const end = l2.waypoints.at(-1);
        if (V.l2AsOverworld) {
            chk(false, '【变异】把 L2 终点当主世界坐标：应断言不成立', `实得 ${JSON.stringify(end)}`);
        } else {
            chk(end[0] === c3stand[0] && end[1] === c3stand[1] + 1 && end[2] === c3stand[2],
                `L2 终点 = C3 站立格（exact.stand+1）${JSON.stringify(end)}`);
        }
    }
    // SCHEMA §5 硬闸：相邻路点 ≤32
    let over = 0, worst = 0;
    for (const l of [l1, l2].filter(Boolean)) {
        for (let i = 1; i < l.waypoints.length; i++) {
            const d = d3(l.waypoints[i - 1], l.waypoints[i]);
            worst = Math.max(worst, d);
            if (d > 32.0001) over++;
        }
    }
    chk(over === 0, `相邻路点 ≤32（SCHEMA §5 硬闸），最大间距 ${worst.toFixed(1)} 格，越界 ${over} 处`);
} else {
    chk(false, `route v2 存在`, ROUTE_V2);
}

// ── ④ 危险集与"读失败"判据（静态性质，直接读任务层源码）───────────────
lines.push('--- ④ 危险集 / 读失败判据（任务层静态）---');
const navsrc = fs.existsSync(NAV_MODULE) ? fs.readFileSync(NAV_MODULE, 'utf8') : '';
chk(!!navsrc, 'nether_nav.js 存在');
const HAZ_LINE = /HAZARD_NAMES\s*=\s*new Set\(\[([^\]]*)\]\)/.exec(navsrc);
const hazList = HAZ_LINE ? HAZ_LINE[1] : '';
lines.push(`    HAZARD_NAMES = [${hazList.replace(/\s+/g, ' ').trim()}]`);
const wantHaz = ['lava', 'magma_block'];
for (const h of wantHaz) {
    if (V.dropMagma) chk(!hazList.includes(h), `【变异】危险集应漏掉 ${h}`, '变异本意就是漏掉它');
    else chk(hazList.includes(h), `危险集含 ${h}（1.16.1 MagmaBlock 每 tick 扣血，站 1 秒即死）`);
}
if (!V.dropMagma) chk(hazList.includes('soul_sand'), '危险集含 soul_sand（灵魂沙下陷，同样致死）');
// 读失败必须单独成字段
const hasReadFailed = /readFailed/.test(navsrc);
if (V.dropReadFailed) chk(!hasReadFailed, '【变异】判据应不再区分 readFailed', '');
else chk(hasReadFailed, '判据显式区分 readFailed（blockAt 未加载返回 null ≠ 空气）');
chk(/function standable/.test(navsrc) && /if \(here\.readFailed \|\| up\.readFailed \|\| under\.readFailed\)/.test(navsrc),
    'standable() 三格读失败时**直接判不可站**（不把 null 折算成空气）');
// 挖穿能力：S3 作业点被壁封住
chk(/canDig\s*=\s*true/.test(navsrc), 'Movements.canDig = true（S3 被 polished_blackstone_bricks 封住，不挖穿到不了）');
// 撤离不能用 len||1（M-01 修过的那条）
chk(/nearest_spot/.test(navsrc) && !/len\s*=\s*Math\.hypot\([^)]*\)\s*\|\|\s*1/.test(navsrc),
    '撤离用最近安全落脚点（不用 len||1 —— 那是 M-01 修掉的真 bug）');

// 5 击确认
console.log(lines.join('\n'));
const total = pass + fail;
console.log(`\n${MUTATE ? '[变异 ' + MUTATE + '] ' : ''}自检：${pass}/${total} 通过，${fail} 条红`);
if (MUTATE && fail === 0) {
    console.log(`❌ 变异 ${MUTATE} 没被任何断言抓住 ⇒ **自检无效**（手册 §5：自检抓不住自己要防的错就等于没有自检）`);
    process.exit(2);
}
process.exit(fail === 0 ? 0 : 1);
