// route_guard.mjs — MC-ROUTE-02：编排器侧的 route 守卫
//
// 本单**不实现**任务层的 `route_loader`（那是开发线 B 的活，SCHEMA §1 的三条校验都在那边：
// sha 校验、丢弃 scout、8 格粗化 + radius≥16 兜底）。本文件只做编排器该做的四件事，
// 全部是"编排器自己的账"，不碰任务层：
//
//   1. **文件选择 + 结构校验**：读 route 文件，校验 schema / 站序 / 站区字段。
//   2. **sha256 记录与复验**：开跑记一次；**每个段开始前**与整局结束时各复验一次。
//      任何一次对不上 → 整局判 `VOID`（SCHEMA §3：run 中 route 文件被修改 = 该局作废）。
//   3. **草稿闸门**：`frozenAt === null` 是草稿，SCHEMA 规定只能用于开发局；
//      正式矩阵/拍摄局必须显式 `--allow-draft` 才放行，默认拒。
//   4. **黑名单跨段台账**（任务单 §3 定的语义：预算按段重置、黑名单跨段保留）：
//      预算按段重置是任务层**现有**行为（FULLRUN-01 已实证：每次 TaskRuntime.run() 新建
//      TaskStack，budgets/blacklist/deathEpoch 都不跨段）。
//      「黑名单跨段保留」当前**没有注入通道**——黑名单是 ctx.run.blacklist，任务层未开放外部
//      runState 注入。所以本单把每段实测到的失败目标收集成**跨段台账**（从遥测
//      `nav_blacklist_expand{target,why,radius,expanded}` 解析），随 splits.json 落盘，
//      供设计会话排期任务层钩子时直接用。台账只读不改，不影响本局行为。

import fs from 'fs';
import crypto from 'crypto';
import path from 'path';

const STATION_ID_RE = /^[A-Za-z0-9_]{1,64}$/;
/** MISSION 形态白名单：只允许 `do station <id>`，从形态上杜绝坐标混进 MISSION */
const MISSION_RE = /^do station ([A-Za-z0-9_]{1,64})$/;

/** 本守卫认识的 schema：v1（站级粗粒度）和 v2（SCHEMA §5，L0 精确坐标 + legs）。别的全拒。 */
const KNOWN_SCHEMAS = new Set(['aidqq-route/1', 'aidqq-route/2']);
const V2_SCHEMA = 'aidqq-route/2';
/** SCHEMA §5：leg 里**相邻路点**最大 3D 欧氏距离 = 32 格，**正好 32 合法**。
 *  eps 只为吸收浮点表示误差（32.0000000001 之类），不影响 32.0001 的判定。 */
const LEG_WAYPOINT_MAX = 32;
const DIST_EPS = 1e-9;
const isInt3 = (a) => Array.isArray(a) && a.length === 3 && a.every(Number.isInteger);
const dist3 = (a, b) => Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);

export class RouteError extends Error {
    constructor(code, msg) { super(`${code}: ${msg}`); this.code = code; }
}

export function sha256Of(text) {
    return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
}

// ---------------------------------------------------------------------------
// 【SCHEMA §4 v1.1 的**唯一**哈希口径】设计会话 2026-10-02 夜定案（bench 74b1b5d / 73f7456）
//
//   sha256( JSON.stringify(JSON.parse(文件原文), null, 2) + "\n" )
//
// 对**整个文件**算，**包括 frozenAt 和 sha256File**。哈希值存在**旁挂** `.sha256` 文件里、
// 不在 route 文件内部 ⇒ 没有循环依赖（`sha256File` 字段名在文件里是常量，它的**值**只是文件名，
// 不参与自身哈希的求解）。
//
// **为什么用规范化而不是原始字节**：原始字节哈希对换行符敏感 —— 本地 Windows 的 git 会把
// LF 转成 CRLF，而云端泳道 X / 农场 Y 是 LF ⇒ 同一个冻结文件在本地算出的哈希到了云端就对不上，
// 而且**本地自检全绿也不会报错**。规范化把换行/缩进/字段序差异全部消掉，跨机器可复现。
//
// ⚠ **三处必须共用这一个函数**（SCHEMA §4 明写）：冻结工具、checkRouteIntegrity 的冻结校验、
//   RouteGuard 开跑/段间复验。以前这三处各算各的（freeze_route.mjs 还有 --schema-literal
//   双口径），是"按 SCHEMA 文字冻结、guard 必然报 ROUTE_HASH_MISMATCH"那个🚨冲突的根因。
//   离线用例见 bench/route/tools/route_hash_selftest.mjs。
// ---------------------------------------------------------------------------

/** 规范化文本：2 空格缩进 + 末尾换行。接受**对象**或**文件原文字符串**。 */
export function canonicalRouteText(input) {
    const doc = typeof input === 'string' ? JSON.parse(input) : input;
    return JSON.stringify(doc, null, 2) + '\n';
}

/** route 文件的规范哈希（SCHEMA §4 v1.1）。`input` 可以是原文，也可以是已 parse 的对象。 */
export function routeSha256(input) {
    return sha256Of(canonicalRouteText(input));
}

/**
 * SCHEMA §5（v2）的四组判据。**只在 `schema === 'aidqq-route/2'` 时调用** ——
 * v1 文件走原路径，行为逐字不变。
 *
 * 【作用域，刻意收紧，别过度执法】
 *   - `exact` 的形态校验只覆盖 **`normalFlowStations` 里的站**：有 exact 就必须合规，
 *     没有 exact 允许（fallback-only 站没有 L0 作业坐标是正常的，SCHEMA §5 也没要求）。
 *     fallback 站若写了 exact，坐标同样会进 route_loader，但本守卫不强制它存在。
 *   - `waypoints` 的**整数性**不在 SCHEMA §5 的枚举里（§5 只点名 stand/targets/hazards），
 *     所以本守卫只判**距离**，不判路点整数性 —— 留给下游 pathfinder 兜。
 *
 * 【fallback traffic 的判据（保持简单，可复核）】
 *   - 正常腿 = 两端都在 `normalFlowStations`。
 *   - **非正常腿**（至少一端不在正常流程里）本身**允许**：§2.1 的 fallback 本来就是要走到
 *     fallback-only 站。这类腿会被记进返回值的 `fallbackTraffic`，只作观察、不报 violation。
 *   - 唯一报错的情形：一端在正常流程、另一端**既不在正常流程、也不在 `fallbackOnlyStations`、
 *     也没有任何站的 `fallback` 指向它** —— 等于把正常流程带进一个没有任何 fallback 声明
 *     背书的站，只能是漏登记。
 *
 * @param {object} doc 已 parse 的 route 文件
 * @param {string[]} v 收集 violation 的数组（就地 push）
 * @returns {{fallbackTraffic: {at:number,from:string,to:string,fromDim:boolean,toDim:boolean}[]}}
 */
export function checkRouteV2(doc, v = []) {
    const fallbackTraffic = [];
    const stations = Array.isArray(doc.stations) ? doc.stations : [];
    const byId = new Map(stations.map((s) => [s.id, s]));
    const nf = Array.isArray(doc.normalFlowStations) ? doc.normalFlowStations : null;
    const normalSet = new Set(nf ?? []);

    // ---- (1) exact 存在即须有证据，坐标须是整数三元组 ---------------------------
    for (const id of nf ?? []) {
        const s = byId.get(id);
        if (!s) continue;                     // 站不存在由 v1.1 的 normalFlowStations 检查报
        const ex = s.exact;
        if (ex === undefined || ex === null) continue;   // 没有 exact 允许（见上方作用域说明）
        if (typeof ex !== 'object' || Array.isArray(ex)) { v.push(`${id} exact 必须是对象，实得 ${JSON.stringify(ex)}`); continue; }
        if (typeof ex.verify?.evidence !== 'string' || !ex.verify.evidence.trim()) {
            v.push(`${id} exact.verify.evidence=${JSON.stringify(ex.verify?.evidence ?? null)} 为空（SCHEMA §5：没有证据的精确坐标不许进 v2）`);
        }
        // stand 是"作业站位"：必须非空，且每项是整数三元组
        if (!Array.isArray(ex.stand) || !ex.stand.length) v.push(`${id} exact.stand=${JSON.stringify(ex.stand ?? null)} 为空（v2 必须有落脚站位）`);
        else ex.stand.forEach((p, i) => { if (!isInt3(p)) v.push(`${id} exact.stand[${i}]=${JSON.stringify(p)} 不是整数三元组 [x,y,z]`); });
        // hazards 允许为空数组（没有危险格是常态），但一旦有项就必须是整数三元组
        if (ex.hazards !== undefined) {
            if (!Array.isArray(ex.hazards)) v.push(`${id} exact.hazards=${JSON.stringify(ex.hazards)} 不是数组`);
            else ex.hazards.forEach((p, i) => { if (!isInt3(p)) v.push(`${id} exact.hazards[${i}]=${JSON.stringify(p)} 不是整数三元组 [x,y,z]`); });
        }
        for (const [i, t] of (Array.isArray(ex.targets) ? ex.targets : []).entries()) {
            if (!isInt3(t?.xyz)) v.push(`${id} exact.targets[${i}](${t?.what ?? '?'}).xyz=${JSON.stringify(t?.xyz)} 不是整数三元组 [x,y,z]`);
        }
    }

    if (!Array.isArray(doc.legs)) {
        v.push('顶层缺 legs 数组（SCHEMA §5：v2 用 legs 记站与站之间怎么走）');
        return { fallbackTraffic };
    }
    const declaredFallbackOnly = new Set((Array.isArray(doc.fallbackOnlyStations) ? doc.fallbackOnlyStations : []).map((r) => r.id));
    const referencedByFallback = new Set();
    for (const s of stations) for (const f of s.fallback ?? []) if (typeof f === 'string') referencedByFallback.add(f);

    // ---- (2)(3) 逐条腿：端点存在 + 端点有站位 + 相邻路点 ≤ 32 ------------------
    const legs = doc.legs;
    legs.forEach((leg, li) => {
        const tag = `legs[${li}](${leg?.from}->${leg?.to})`;
        for (const end of ['from', 'to']) {
            if (!byId.has(leg?.[end])) v.push(`${tag} ${end} 指向不存在的站 ${JSON.stringify(leg?.[end] ?? null)}`);
        }
        // 「首尾与站一致」：腿的每一端都得踩在某个站的作业站位上，否则这条腿没法起跳/落脚
        for (const end of ['from', 'to']) {
            const s = byId.get(leg?.[end]);
            if (!s) continue;
            const stand = s.exact?.stand;
            if (!Array.isArray(stand) || !stand.length) v.push(`${tag} ${end} 站 ${leg[end]} 没有非空 exact.stand（腿的首尾必须与站位一致，否则这条腿无法执行）`);
        }
        const wps = leg?.waypoints;
        if (wps === undefined) return;   // 没有 waypoints 的腿只做端点/覆盖检查（维度跳转腿允许没有路点）
        if (!Array.isArray(wps) || wps.length < 2) { v.push(`${tag} waypoints=${JSON.stringify(wps)} 少于 2 个点（至少要有起终点两个路点）`); return; }
        for (let i = 1; i < wps.length; i++) {
            const a = wps[i - 1], b = wps[i];
            if (!Array.isArray(a) || !Array.isArray(b) || a.length !== 3 || b.length !== 3) continue;  // 形态不对没法量距离
            const d = dist3(a, b);
            if (d > LEG_WAYPOINT_MAX + DIST_EPS) v.push(`${tag} 相邻路点 waypoints[${i - 1}]->waypoints[${i}] 距离 ${d.toFixed(4)} > ${LEG_WAYPOINT_MAX} 格`);
        }
    });

    // ---- (4) legs 覆盖正常流程 + fallback traffic 标注 ---------------------------
    const normalLegs = new Set();
    legs.forEach((leg, li) => {
        const from = leg?.from ?? null, to = leg?.to ?? null;
        const aN = normalSet.has(from), bN = normalSet.has(to);
        if (aN && bN) { normalLegs.add(`${from}->${to}`); return; }
        fallbackTraffic.push({ at: li, from, to, fromNormal: aN, toNormal: bN });
        const on = aN ? from : (bN ? to : null);    // 还在正常流程里的那一端
        const off = aN ? to : (bN ? from : null);   // 离开正常流程的那一端
        if (on === null) return;                    // 两端都不在正常流程 = 纯 fallback 内部走线，允许
        if (declaredFallbackOnly.has(off) && referencedByFallback.has(off)) return;   // 有 fallback 声明背书，允许
        v.push(`legs[${li}](${from}->${to}) 从正常流程站 ${on} 连到未登记站 ${off}`
            + `（既不在 normalFlowStations，也不在 fallbackOnlyStations，且没有任何站的 fallback 指向它）`);
    });
    if (nf) {
        for (let i = 0; i + 1 < nf.length; i++) {
            const a = nf[i], b = nf[i + 1];
            if (!normalLegs.has(`${a}->${b}`)) v.push(`legs 缺 ${a} -> ${b} 这条腿（normalFlowStations 第 ${i + 1}、${i + 2} 个正常流程站之间必须有腿，跨维度也要有）`);
        }
    } else if (!v.some((x) => x.startsWith('顶层缺 normalFlowStations'))) {
        v.push('顶层缺 normalFlowStations（SCHEMA §2.1/§5：编排器只按这张表走，legs 覆盖率也无从判定）');
    }
    return { fallbackTraffic };
}

/** 读 + 结构校验（不校验 hash：那是冻结态的事） */
// ═══════════════════════════════════════════════ 站位回读判据（v2 only，ROUND9-C 新增）
/**
 * **每个 stand 都必须"脚下实心非危险 + 身体两格空气"**，而且必须**回读存档**判。
 *
 * 【为什么这条判据是必需的、而且是"回读"而不是"看字段"】
 *   ROUND8-C 的 v2 把 S3/C3/**S5** 三站的 stand 整体低 1 格（S3 63→62、C3 69→68、S5 36→35），
 *   当时**每一处单独看都自洽**：整数三元组 ✅、有证据路径 ✅、两套校验器对拍 0 violations ✅。
 *   病根是"站位有三套差 +1 的口径"，而组装时对其中一套又减了 1。
 *   ⇒ **结构判据原理上抓不到它**，只有拿存档逐格读"这一格到底实不实、两格空不空"才抓得到。
 *
 * 【口径（唯一真源 `bench/route/lib/stand_criterion.mjs`，三处共用）】
 *   `stand` = **脚下那格 = 支撑方块**；玩家身体占 y+1 与 y+2；**玩家 Pos.y = stand.y + 1**。
 *   合法 ⟺ blockAt(stand) 实心非危险 ∧ blockAt(stand+1) ∈ AIR ∧ blockAt(stand+2) ∈ AIR
 *
 * 【通道坏了必须报 read_failed，不能折算成"站不住"】—— `unknown` 不当空气
 *   （与 memory 里「`blockAt` 返回 null 是"没读到"不是"方块没了"」同一条纪律）。
 *
 * @param {object} doc
 * @param {object} opt
 * @param {string} opt.overworldWorld 主世界世界目录（含 region/）
 * @param {string} [opt.netherWorld]   下界世界目录；不给则下界站只做形态检查并记 skipped
 * @param {string[]} v violation 收集数组（就地 push）
 * @returns {Promise<{checked:number, skipped:string[], rows:object[]}>}
 */
export async function checkStandsAgainstSave(doc, { overworldWorld, netherWorld = null, moreWorlds = [] }, v = []) {
    const rows = [];
    const skipped = [];
    let world = null;
    try {
        const { openWorld } = await import('../../route/tools/region_reader.mjs');
        const { judgeStand, dimOf } = await import('../../route/lib/stand_criterion.mjs');
        const need = new Set((doc.stations ?? []).map((s) => dimOf(s.dim ?? 'overworld')));
        if (need.has('overworld') && !overworldWorld) skipped.push('overworld:no_world_given');
        if (need.has('the_nether') && !netherWorld) skipped.push('the_nether:no_world_given');
        if (!overworldWorld) return { checked: 0, skipped, rows };
        world = openWorld(overworldWorld, { dims: ['overworld', 'the_nether', 'the_end'] });
        // ⚠ **一个站的权威存档不一定是同一份**（现状速览 ㊷ ③：S0/S1 读 `_bedhunt`、
        //   S5 读 `_s5_s5`、S3/C3 读 `_bedhunt`/`_s3_easy`）。
        //   所以按"**第一个覆盖该区块的世界**"挑，而不是死用一份 —— 否则不在覆盖范围内的站
        //   会读出 `unknown`，而 `unknown` 必须报 `read_failed`（不能折算成"站不住"）。
        const extra = [];
        for (const dir of moreWorlds) {
            try { extra.push({ dir, w: openWorld(dir, { dims: ['overworld', 'the_nether', 'the_end'] }) }); }
            catch (e) { skipped.push(`${dir}:open_failed:${String(e).slice(0, 60)}`); }
        }
        const pick = (x, z, dim) => {
            if (world.hasChunk(x >> 4, z >> 4, dim)) return { w: world, dir: overworldWorld };
            for (const e of extra) if (e.w.hasChunk(x >> 4, z >> 4, dim)) return { w: e.w, dir: e.dir };
            return null;
        };

        for (const s of doc.stations ?? []) {
            const stands = s.exact?.stand;
            if (!Array.isArray(stands) || !stands.length) continue;
            const dim = dimOf(s.dim ?? 'overworld');
            if (dim === 'the_nether' && !netherWorld) { skipped.push(`${s.id}:the_nether:no_world_given`); continue; }
            for (const st of stands) {
                if (!isInt3(st)) continue;                    // 形态问题由 checkRouteV2 报
                const use = pick(st[0], st[2], dim);
                if (!use) {
                    rows.push({ station: s.id, dim, stand: st, ok: false, reason: `read_failed:no_save_covers_chunk(${st[0] >> 4},${st[2] >> 4})` });
                    v.push(`${s.id} exact.stand=${JSON.stringify(st)} 没有任何一份回读存档覆盖该区块`
                        + `（**这是"没读到"，不是"站不住"** —— 别把它当成站位合法或非法）`);
                    continue;
                }
                const g = use.w.blockAt(st[0], st[1], st[2], dim);
                const b1 = use.w.blockAt(st[0], st[1] + 1, st[2], dim);
                const b2 = use.w.blockAt(st[0], st[1] + 2, st[2], dim);
                const j = judgeStand(g, b1, b2);
                rows.push({ station: s.id, dim, stand: st, readFrom: use.dir, ground: g, body: [b1, b2], ok: j.ok, reason: j.reason, warn: j.warn });
                if (!j.ok) {
                    v.push(`${s.id} exact.stand=${JSON.stringify(st)} 在存档里站不住：${j.reason}`
                        + `（脚下那格读回 ${g}，身体两格读回 [${b1}, ${b2}]；口径：stand=脚下那格=支撑方块，玩家 Pos.y=stand.y+1）`);
                }
            }
        }
    } catch (e) {
        v.push(`站位回读通道坏了：${String(e && e.message ? e.message : e).slice(0, 160)}（**这不等于"站位没问题"**）`);
    }
    return { checked: rows.length, skipped, rows };
}

export function readRouteFile(file) {    if (!fs.existsSync(file)) throw new RouteError('ROUTE_FILE_MISSING', file);
    const raw = fs.readFileSync(file, 'utf8');
    let doc;
    try { doc = JSON.parse(raw); } catch (e) { throw new RouteError('ROUTE_BAD_JSON', `${file}: ${String(e).slice(0, 120)}`); }
    const v = [];
    if (!KNOWN_SCHEMAS.has(doc.schema)) v.push(`schema=${doc.schema}（期望 aidqq-route/1 或 aidqq-route/2）`);
    // ⚠ SCHEMA §5：v1 字段全部保留、v1 规则逐字保留。v2 只是**追加** exact/legs 判据。
    const isV2 = doc.schema === V2_SCHEMA;
    if (!Array.isArray(doc.stations) || !doc.stations.length) v.push('stations 为空');
    for (const s of doc.stations ?? []) {
        if (!STATION_ID_RE.test(s.id ?? '')) v.push(`站 id 非法：${s.id}`);
        if (!Number.isInteger(s.seq)) v.push(`${s.id} seq 非整数`);
        if (!s.station || !Array.isArray(s.station.center) || s.station.center.length !== 2) v.push(`${s.id} station.center 非法`);
        // ⚠ **v2 不再查下面这三样**（DECISION-02 §3 已作废：到达确认闸门、暴露面判据、
        //   "站级区域 + 自己找"、8 格粗化与 radius≥16 硬约束，都不再是验收要求）。
        //   B 线的 `route_loader` 在 v2 下**已经不查**它们 ⇒ guard 再查就成了
        //   "**比 loader 严**"，v2 文件会被自己的守卫判死（这类"守卫比被守卫的代码更严"
        //   的不一致，永远以"文件非法"的形式出现，看不出是口径问题）。
        //   v1 走原三条，**行为逐字不变**（SCHEMA §5：v1 字段全部保留、v1 规则逐字保留）。
        if (isV2) {
            if (s.station && Array.isArray(s.station.center) && !s.station.center.every(Number.isInteger))
                v.push(`${s.id} station.center=${JSON.stringify(s.station.center)} 不是两个整数`);
        } else {
            if (s.station && Array.isArray(s.station.center) && s.station.center.length === 2
                && (!s.station.center.every(Number.isInteger) || s.station.center.some((c) => c % 8 !== 0))) {
                // SCHEMA §1 说加载器会把 center 对齐到 8 格作兜底；这里**再加一道**：文件本身就必须
                // 已经是粗粒度的。否则有人把精确坐标写进 station，加载器虽会兜底，但"误写"已经发生。
                v.push(`${s.id} center=${JSON.stringify(s.station.center)} 未对齐 8 格网格（站级数据必须是粗粒度）`);
            }
            if (!Number.isInteger(s.station?.radius) || s.station.radius < 16) v.push(`${s.id} radius=${s.station?.radius} < 16（SCHEMA 硬下限）`);
            if (!Array.isArray(s.station?.lookFor) || !s.station.lookFor.length) v.push(`${s.id} lookFor 为空（运行时无法做到达确认）`);
        }
    }
    const seqs = (doc.stations ?? []).map((s) => s.seq);
    if (seqs.length && (Math.min(...seqs) !== 1 || seqs.length !== new Set(seqs).size)) v.push('seq 必须是从 1 起的不重复整数');

    // ---- v1.1（SCHEMA §2.1，2026-10-02 夜设计会话要求补）：fallback 三处一致性 ----
    // `routeRole=fallback-only`、各主站 `fallback`、顶层 `fallbackOnlyStations` 三处必须一致。
    // ⚠ **条件触发**：另两个旧种子（-8839485814800629942 / -6850455172235562789）没有这些字段，
    //   对它们报 violation 会让旧 route 一律不可用 ⇒ 只有"文件里出现过任一新字段"才校验。
    {
        const stations = doc.stations ?? [];
        const hasRole = stations.some((s) => s.routeRole);
        const hasLists = Array.isArray(doc.normalFlowStations) || Array.isArray(doc.fallbackOnlyStations);
        if (hasRole || hasLists) {
            const byId = new Map(stations.map((s) => [s.id, s]));
            const roleFallback = stations.filter((s) => s.routeRole === 'fallback-only').map((s) => s.id);
            const badRole = stations.filter((s) => s.routeRole !== undefined && s.routeRole !== 'fallback-only').map((s) => `${s.id}=${s.routeRole}`);
            if (badRole.length) v.push(`routeRole 只允许 "fallback-only"，否则视为普通站：${badRole.join(', ')}`);

            // (a) 每个 fallback-only 站必须被 ≥1 个站引用，且引用者自己不是 fallback-only（否则会链式套娃）
            for (const id of roleFallback) {
                const refs = stations.filter((s) => Array.isArray(s.fallback) && s.fallback.includes(id)).map((s) => s.id);
                if (!refs.length) v.push(`${id} 标了 fallback-only 却没有任何站的 fallback 指向它`);
                const chain = refs.filter((r) => roleFallback.includes(r));
                if (chain.length) v.push(`${id} 被 fallback-only 站 ${chain.join(',')} 引用（会形成 fallback 链，SCHEMA §2.1 不允许）`);
            }
            // (b) 任何 fallback 指向的目标必须存在、且必须标了 fallback-only
            for (const s of stations) {
                for (const f of s.fallback ?? []) {
                    if (!byId.has(f)) v.push(`${s.id}.fallback 指向不存在的站 ${f}`);
                    else if (byId.get(f).routeRole !== 'fallback-only') v.push(`${s.id}.fallback 指向 ${f}，但它没有标 routeRole="fallback-only"（正常流程会顺路去它，与语义矛盾）`);
                }
            }
            // (c) 顶层两表 vs routeRole 三处一致
            if (Array.isArray(doc.fallbackOnlyStations)) {
                const listed = doc.fallbackOnlyStations.map((x) => x.id);
                const dup = listed.filter((x, i) => listed.indexOf(x) !== i);
                if (dup.length) v.push(`fallbackOnlyStations 有重复 id：${[...new Set(dup)].join(',')}`);
                for (const id of listed) if (!roleFallback.includes(id)) v.push(`fallbackOnlyStations 里的 ${id} 没有 routeRole="fallback-only"`);
                for (const id of roleFallback) if (!listed.includes(id)) v.push(`${id} 有 routeRole="fallback-only" 但没登记进 fallbackOnlyStations`);
                for (const rec of doc.fallbackOnlyStations) {
                    const st = byId.get(rec.id);
                    const actual = stations.filter((s) => Array.isArray(s.fallback) && s.fallback.includes(rec.id)).map((s) => s.id).sort();
                    const claimed = [...(rec.fallbackOf ?? [])].sort();
                    if (JSON.stringify(actual) !== JSON.stringify(claimed)) {
                        v.push(`${rec.id} 的 fallbackOf 记录与实际引用不一致：记录 ${JSON.stringify(rec.fallbackOf)} 实际 ${JSON.stringify(actual)}`);
                    }
                    if (st && Number.isInteger(st.seq) && rec.seq !== st.seq) v.push(`${rec.id} 的 fallbackOnlyStations.seq=${rec.seq} 与 stations.seq=${st.seq} 不一致`);
                }
            } else {
                v.push('有站标了 routeRole="fallback-only"，但顶层缺 fallbackOnlyStations');
            }
            if (Array.isArray(doc.normalFlowStations)) {
                for (const id of doc.normalFlowStations) {
                    if (!byId.has(id)) v.push(`normalFlowStations 里的 ${id} 不存在`);
                    else if (byId.get(id).routeRole === 'fallback-only') v.push(`normalFlowStations 里出现了 fallback-only 站 ${id}（正常流程不应去它）`);
                }
                const overlap = doc.normalFlowStations.filter((id) => roleFallback.includes(id));
                if (overlap.length) v.push(`normalFlowStations 与 fallback-only 站重叠：${[...new Set(overlap)].join(',')}`);
            } else {
                v.push('顶层缺 normalFlowStations');
            }
            // (d) 两表并集 = 全部站，且不重不漏
            const nf = doc.normalFlowStations ?? [];
            const fo = (doc.fallbackOnlyStations ?? []).map((x) => x.id);
            if (nf.length + fo.length !== stations.length) {
                v.push(`normalFlowStations(${nf.length}) + fallbackOnlyStations(${fo.length}) != stations.length(${stations.length})`);
            }
            const union = new Set([...nf, ...fo]);
            const missing = stations.filter((s) => !union.has(s.id)).map((s) => s.id);
            if (missing.length) v.push(`这些站既不在 normalFlowStations 也不在 fallbackOnlyStations：${missing.join(',')}`);
            const normalSet = new Set(nf);
            for (const id of fo) if (normalSet.has(id)) v.push(`${id} 同时出现在 normalFlowStations 和 fallbackOnlyStations`);
            // 正常流程的 seq 应当就是 1..N 连续（编排器按 seq 走）
            const normalSeqs = nf.map((id) => byId.get(id)?.seq).filter(Number.isInteger).sort((a, b) => a - b);
            for (let i = 0; i < normalSeqs.length; i++) {
                if (normalSeqs[i] !== i + 1) { v.push(`正常流程站的 seq 应为 1..${normalSeqs.length} 连续，实得 ${JSON.stringify(normalSeqs)}`); break; }
            }
        }
    }
    // ---- v2（SCHEMA §5）追加判据。**只有 v2 才跑**，v1 文件到这里行为与从前逐字一致。 ----
    const v2 = isV2 ? checkRouteV2(doc, v) : null;

    // `sha256` 走 SCHEMA §4 v1.1 的**规范化**口径（见 routeSha256）。
    // ⚠ 这里同时保留 `rawSha256`（原始字节哈希）**只作诊断**：它和 sha256 不相等只说明
    //   文件被换行风格改写过（CRLF/LF），不代表内容变了 —— 别拿它判"route 被改"。
    // ⚠ `v2FallbackTraffic` 是**纯增量**字段：非正常腿（fallback traffic）只作观察，
    //   不进 violations，老调用方（RouteGuard / checkRouteIntegrity）不受影响。
    return { file, raw, sha256: routeSha256(doc), rawSha256: sha256Of(raw), doc, violations: v, schema: doc.schema, v2FallbackTraffic: v2 ? v2.fallbackTraffic : [] };
}

/** 开局闸门：草稿 / 冻结态 / sha 一致性 */
export function checkRouteIntegrity(file, { allowDraft = false, requireFrozen = false } = {}) {
    const r = readRouteFile(file);
    const out = { file, sha256: r.sha256, rawSha256: r.rawSha256, frozenAt: r.doc.frozenAt ?? null, frozen: !!r.doc.frozenAt, sha256File: r.doc.sha256File ?? null, violations: [...r.violations], ok: true, reason: null };

    if (out.violations.length) { out.ok = false; out.reason = `SCHEMA_VIOLATIONS: ${out.violations.join(' | ')}`; return out; }

    if (!out.frozen) {
        if (requireFrozen || !allowDraft) {
            out.ok = false;
            out.reason = `ROUTE_IS_DRAFT: frozenAt=null（草稿只能用于开发局；正式矩阵/拍摄局必须用冻结版）。`
                + `开发局请显式 --allow-draft`;
            return out;
        }
    } else {
        // 冻结态：与 <seed>.sha256 旁挂文件比对
        const side = r.doc.sha256File ? path.join(path.dirname(file), r.doc.sha256File) : null;
        if (side && fs.existsSync(side)) {
            const frozen = fs.readFileSync(side, 'utf8').trim().split(/\s+/)[0];
            if (frozen !== r.sha256) {
                out.ok = false;
                out.reason = `ROUTE_HASH_MISMATCH: 文件 sha=${r.sha256.slice(0, 16)}… 冻结值 sha=${String(frozen).slice(0, 16)}…`;
                return out;
            }
        } else if (requireFrozen) {
            out.ok = false;
            out.reason = `ROUTE_SIDECAR_MISSING: 冻结态必须有 ${r.doc.sha256File ?? '<seed>.sha256'}`;
            return out;
        }
    }
    return out;
}

export class RouteGuard {
    /**
     * @param {string} file route 文件路径
     * @param {{allowDraft?:boolean, requireFrozen?:boolean, onViolation?:(r:object)=>void}} opt
     */
    constructor(file, opt = {}) {
        this.file = file;
        this.opt = opt;
        this.started = checkRouteIntegrity(file, opt);
        this.voided = !this.started.ok;
        this.voidReason = this.started.reason;
        this.ledger = [];          // 跨段黑名单台账（只读观测，不注入任务层）
        this.checks = [{ at: 'start', ...this.started }];
    }
    get sha256() { return this.started.sha256; }
    get stations() { return (this.started.violations.length ? [] : this.started.doc.stations) ?? []; }

    /** 段开始前复验：文件被改过 → 整局作废 */
    verify(where) {
        let now;
        try { now = checkRouteIntegrity(this.file, this.opt); }
        catch (e) { now = { ok: false, reason: `ROUTE_READ_FAIL: ${e.message}`, sha256: null, violations: [] }; }
        const changed = !this.voided && now.sha256 !== this.started.sha256;
        const rec = {
            at: where, sha256: now.sha256, same: now.sha256 === this.started.sha256,
            ok: now.ok && !changed, changed,
            reason: changed ? `ROUTE_CHANGED_MID_RUN: 开局 sha=${String(this.started.sha256).slice(0, 16)}… 现在 sha=${String(now.sha256).slice(0, 16)}… → 该局作废` : now.reason,
        };
        this.checks.push(rec);
        if (!rec.ok) { this.voided = true; this.voidReason = rec.reason; }
        return rec;
    }

    /**
     * 吸收一段的遥测，提取实测失败目标 → 跨段黑名单台账。
     * 事件形如 nav_blacklist_expand{why,target:"x y z",radius,expanded}
     */
    absorbSegmentTelemetry(telemetryPath, { dim = 'overworld' } = {}) {
        if (!fs.existsSync(telemetryPath)) return { added: 0, ledger: this.ledger };
        let added = 0;
        for (const line of fs.readFileSync(telemetryPath, 'utf8').split('\n')) {
            if (!line.trim()) continue;
            let e; try { e = JSON.parse(line); } catch { continue; }
            if (e.event !== 'nav_blacklist_expand' || !e.target) continue;
            const [x, y, z] = String(e.target).split(/\s+/).map(Number);
            if (![x, y, z].every(Number.isFinite)) continue;
            const key = `${x},${y},${z}`;
            if (this.ledger.some((r) => r.key === key)) continue;
            this.ledger.push({ key, x, y, z, dim, why: e.why ?? null, radius: e.radius ?? null, expanded: e.expanded ?? null, at: e.t ?? null });
            added++;
        }
        return { added, ledger: this.ledger };
    }

    /**
     * 测试专用：模拟「外部在 run 中改了 route 文件」。
     * 改一个字节（把某站的 radius 从 32 改成 33，仍是合法 JSON），用来在真实 bot 路径上
     * 触发 verify() 的作废判定——干跑时每段耗时 ~0ms，人手改文件根本抢不到窗口，
     * 所以把"被改"这一步自动化；判定逻辑与外部修改完全同一条路径（重新读文件 + 比 sha）。
     * 离线等价验证见 route_selftest.mjs 第 3 组（那里是真·外部改文件）。
     */
    simulateExternalEdit() {
        try {
            const doc = JSON.parse(fs.readFileSync(this.file, 'utf8'));
            const st = doc.stations?.[0];
            if (!st) return null;
            const before = st.station.radius;
            st.station.radius = before + 1; // 只动一个字符
            fs.writeFileSync(this.file, JSON.stringify(doc, null, 2) + '\n');
            return { field: 'stations[0].station.radius', before, after: st.station.radius };
        } catch (e) {
            return { error: String(e).slice(0, 120) };
        }
    }

    report() {
        return {
            file: this.file,
            sha256AtStart: this.started.sha256,
            frozen: this.started.frozen,
            frozenAt: this.started.frozenAt,
            voided: this.voided,
            voidReason: this.voidReason,
            checks: this.checks,
            blacklistLedgerSize: this.ledger.length,
            blacklistLedger: this.ledger,
            blacklistPolicy: '预算按段重置（任务层现有行为，已实证）；黑名单跨段保留 = 台账已建，注入通道待任务层钩子（本单不改任务层）',
        };
    }
}

/** MISSION 形态自检：站 id 序列里**不允许出现任何坐标**（手册 §7 / SCHEMA §3） */
export function assertStationOnlyMissions(missions) {
    for (const m of missions) {
        const hit = MISSION_RE.exec(m.raw);
        if (!hit) throw new RouteError('MISSION_NOT_STATION_FORM', `序列项不是 "do station <id>"：${m.raw}`);
        if (/\d/.test(hit[1]) && !/^S\d/.test(hit[1])) throw new RouteError('STATION_ID_HAS_DIGITS', `站 id 含数字且不像 S 编号：${hit[1]}`);
    }
    return true;
}
