// run_bench.mjs — MC-FULLRUN-01 整局编排器 runner（开发线 C，**只用泳道 C**）
//
// 与 bench/stages/basic-iron/run_bench.mjs 的分工：
//   basic-iron 的 run_bench 走 _lib/runner_core.mjs 的 runMatrix()——那套的语义是
//   **一个 trial = 一个 fresh world + 一个 MISSION**（buildLanes + freshWorld + 每局一个 exec_bot）。
//   本单要的是「一个 trial = 一个 fresh world + 一串 MISSION」，编排层形状不同，所以本文件
//   只**复用 _lib 已导出的原子能力**（freshWorld / bootServerWithRetry / stopServer / waitFreeMem /
//   preflight / cleanup），编排层自己写在本文件里：
//
//   1. 泳道：**只有 C**（25568/25578，目录 experiments/mc1161-gate/server-1161_laneC）。
//      手册 §9「各开发线测试服泳道只归主 agent 一个人调度」+ 本单禁区「不抢 A、B 泳道」。
//      buildLanes() 会连带派生/改写 B 目录的 server.properties，所以本文件自带 ensureLaneC()，
//      **只碰 _laneC 这一个目录**（这是不调 buildLanes 的原因，也是提效条目①）。
//   2. 内存护栏：开每局前 waitFreeMem(<min-free-mb>)，不够就排队等（手册 §9）。
//   3. 无进展硬中止：probe.jsonl 签名冻结 > no-progress-s → NO_PROGRESS_ABORT（口径同 BENCH-v2，
//      但默认 180s 比单 MISSION 的 120s 宽：连跑里段边界会换任务树，窄窗容易误杀）。
//   4. 基建级失败重试：CONNECT_FAIL / RUNNER_TIMEOUT / KICKED / 无 result → 冷却 15s 重试 1 次；
//      bot 级真实失败（段终态非 SUCCESS）不重试（同 run_bench 的既有语义）。
//   5. 收工：stdin stop → 删 lane C 的 world → 复核端口/进程（cleanup 只传 C 目录，不碰 A/B）。
//
// 环境（手册 §2 血泪：1.16.1 必须显式带全套，默认值是 1.21.1，漏带会起 1.21 Paper → 0.3s DEPENDENCY_CYCLE）：
//   MC_MINDCRAFT_ROOT  任务层只读引用根（默认 D:/AI斗蛐蛐/mindcraft）
//   MC_BENCH_SERVER    1.16.1 闸门模板目录（C 目录由它派生）
//   MC_BENCH_JAR       默认 server-1.16.1.jar
//   MC_BENCH_JAVA      默认便携 JDK11（不动系统 JAVA_HOME）
//   --mc-version       默认 1.16.1
//
// 用法：
//   node run_bench.mjs --selftest
//   node run_bench.mjs --plan-only --missions script:missions/seq-bucket-flint.json
//   node run_bench.mjs --stamp FR1 --seed -8839485814800629942 --trials 3 \
//        --missions script:missions/seq-bucket-flint.json --on-fail retry:1

import { spawn, spawnSync } from 'child_process';
import os from 'os';
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { argOf, log, killTree, waitFreeMem, freshWorld, bootServerWithRetry, stopServer } from '../_lib/runner_core.mjs';
import { preflight, netstatListeners, LANE_PORTS } from '../_lib/preflight.mjs';
import { cleanup, installRunnerHooks } from '../_lib/cleanup.mjs';
import { loadMissionSource, describeSource } from './mission_source.mjs';
import { parsePolicy, describePolicy } from './policy.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
const NODE20 = path.join(ROOT, '.runtime', 'node-v20.20.2-win-x64', 'node.exe');
const MINDCRAFT = path.resolve(process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft'));

// 1.16.1 环境（手册 §2：默认值是 1.21.1，必须显式带全套）
const TEMPLATE_DIR = path.resolve(process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161'));
const LANE = { name: 'C', idx: 2, dir: `${TEMPLATE_DIR}_laneC`, serverPort: 25568, rconPort: 25578, username: 'TaskBotC' };
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const JAVA = process.env.MC_BENCH_JAVA || (() => {
    const jdkRoot = path.join(ROOT, 'experiments', 'mc1161-gate', 'jdk');
    const hit = fs.readdirSync(jdkRoot).find((d) => fs.existsSync(path.join(jdkRoot, d, 'bin', 'java.exe')));
    if (!hit) throw new Error('找不到便携 JDK11：experiments/mc1161-gate/jdk/*/bin/java.exe（手册 §2）');
    return path.join(jdkRoot, hit, 'bin', 'java.exe');
})();
const MC_VERSION = argOf(process.argv, 'mc-version', process.env.MC_BENCH_VERSION || '1.16.1');

const MISSIONS_SPEC = argOf(process.argv, 'missions', `script:${path.join(HERE, 'missions/seq-bucket-flint.json')}`);
const ON_FAIL = argOf(process.argv, 'on-fail', 'retry:1');
const RUNSTAMP = argOf(process.argv, 'stamp', `FR${new Date().toISOString().slice(0, 13).replace(/[-T:]/g, '')}`);
const TRIALS = parseInt(argOf(process.argv, 'trials', '1'), 10);
const START = parseInt(argOf(process.argv, 'start', '1'), 10);
const SEED_LITERAL = argOf(process.argv, 'seed', '');
const SEED_LIST = argOf(process.argv, 'seeds', '');
const SEG_TIMEOUT_MS = parseInt(argOf(process.argv, 'segment-timeout-ms', '540000'), 10);
const TOTAL_TIMEOUT_MS = parseInt(argOf(process.argv, 'total-timeout-ms', '1500000'), 10);
const NO_PROGRESS_S = parseInt(argOf(process.argv, 'no-progress-s', '180'), 10);
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const SERVER_XMX = argOf(process.argv, 'server-xmx', '1G');
const PROBE_MS = parseInt(argOf(process.argv, 'probe-ms', '10000'), 10);
const KEEP_WORLD = process.argv.includes('--keep-world');
const SKIP_CLEANUP = process.argv.includes('--skip-cleanup');
/** 透传给 bot 的额外参数（可重复）。route 干跑验收用：--dry-route --allow-draft [--mutate-route-after N] */
const EXTRA_BOT_ARGS = process.argv.reduce((a, v, i, arr) => (v === '--extra-bot-arg' ? [...a, arr[i + 1]] : a), []);
const RUNS_DIR = path.join(HERE, 'runs', RUNSTAMP);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- 泳道 C 装配（只碰 _laneC） ----------
function ensureLaneC() {
    const dir = LANE.dir;
    const sp = path.join(dir, 'server.properties');
    if (!fs.existsSync(sp)) {
        log(`lane C: 目录未 provisioned，从模板派生 ${dir}`);
        fs.mkdirSync(dir, { recursive: true });
        const tplJar = path.join(TEMPLATE_DIR, JAR_NAME);
        if (!fs.existsSync(tplJar)) throw new Error(`模板目录里没有 ${JAR_NAME}：${tplJar}`);
        fs.copyFileSync(tplJar, path.join(dir, JAR_NAME));
        const eula = path.join(TEMPLATE_DIR, 'eula.txt');
        if (fs.existsSync(eula)) fs.copyFileSync(eula, path.join(dir, 'eula.txt'));
        const lines = fs.readFileSync(path.join(TEMPLATE_DIR, 'server.properties'), 'utf8')
            .split(/\r?\n/)
            .map((l) => {
                if (l.startsWith('server-port=')) return `server-port=${LANE.serverPort}`;
                if (l.startsWith('rcon.port=')) return `rcon.port=${LANE.rconPort}`;
                return l;
            })
            .filter((l) => !l.startsWith('level-seed='));
        fs.writeFileSync(sp, lines.join('\n') + '\n');
    }
    const txt = fs.readFileSync(sp, 'utf8');
    const port = /^server-port=(\d+)$/m.exec(txt)?.[1];
    const rcon = /^rcon.port=(\d+)$/m.exec(txt)?.[1];
    if (Number(port) !== LANE.serverPort || Number(rcon) !== LANE.rconPort) {
        throw new Error(`lane C 配置不对：server-port=${port} rcon.port=${rcon}（应为 ${LANE.serverPort}/${LANE.rconPort}）`);
    }
    if (!fs.existsSync(path.join(dir, JAR_NAME))) throw new Error(`lane C 缺 jar：${JAR_NAME}`);
    const diff = /^difficulty=(\w+)$/m.exec(txt)?.[1];
    const gm = /^gamemode=(\w+)$/m.exec(txt)?.[1];
    log(`lane C: ${dir} | port=${port}/${rcon} | difficulty=${diff} gamemode=${gm} jar=${JAR_NAME}`);
    if (diff !== 'peaceful') log(`! lane C difficulty=${diff}（本单口径是 peaceful；不自动改配置，报出来由人决定）`);
    return { ...LANE, jarPath: path.join(dir, JAR_NAME), java: JAVA };
}

// ---------- probe 签名（连跑口径：段边界也要进签名） ----------
function tailLine(filePath) {
    try {
        const st = fs.statSync(filePath);
        if (!st.size) return null;
        const fd = fs.openSync(filePath, 'r');
        const len = Math.min(st.size, 8192);
        const buf = Buffer.alloc(len);
        fs.readSync(fd, buf, 0, len, st.size - len);
        fs.closeSync(fd);
        return JSON.parse(buf.toString('utf8').split('\n').filter((l) => l.trim()).at(-1));
    } catch { return null; }
}
function probeSig(p) {
    if (!p) return null;
    return JSON.stringify({
        seg: p.seg ?? null, inv: p.inv ?? null, pos: p.pos ?? null,
        d: !!p.digging, f: p.furnace ?? null, t: p.tree ?? '',
    });
}
function awaitBotExit(botProc, runDir, cfg, row) {
    return new Promise((resolve) => {
        let probePoll = 0, lastSig = null, lastChangeAt = Date.now();
        const t0b = Date.now();
        const poll = setInterval(() => {
            if (botProc.exitCode !== null) { clearInterval(poll); resolve(botProc.exitCode); return; }
            if (Date.now() - t0b > cfg.timeoutMs + 90000) { clearInterval(poll); killTree(botProc.pid); resolve(-9); return; }
            probePoll++;
            if (cfg.noProgressMs > 0 && probePoll % 5 === 0) {
                const sig = probeSig(tailLine(path.join(runDir, 'probe.jsonl')));
                if (sig) {
                    if (sig !== lastSig) { lastSig = sig; lastChangeAt = Date.now(); }
                    else if (Date.now() - lastChangeAt > cfg.noProgressMs) {
                        row.abort = { reason: 'no_progress', frozenMs: Date.now() - lastChangeAt };
                        clearInterval(poll);
                        killTree(botProc.pid);
                        resolve(-8);
                    }
                }
            }
        }, 1000);
        botProc.on('exit', (code) => { clearInterval(poll); resolve(code); });
    });
}

// ---------- 主流程 ----------
if (process.argv.includes('--selftest')) {
    const r = spawnSync(NODE20, [path.join(HERE, 'selftest.mjs')], { stdio: 'inherit' });
    process.exit(r.status ?? 1);
}

process.env.JAVA_TOOL_OPTIONS ||= '-Djava.net.preferIPv4Stack=true';
installRunnerHooks(() => `fullrun ${RUNSTAMP}`);

let src, policy;
try {
    src = await loadMissionSource(MISSIONS_SPEC, { cwd: HERE });
    policy = parsePolicy(ON_FAIL);
} catch (e) {
    console.error(`[fullrun] 序列/策略不合法，未起服：${e.message}`);
    process.exit(2);
}

// 权威预校验：用任务层真 parseMission 过一遍（起服前失败，别白烧机器时间）
// route 模式例外：`do station <id>` 不是物品目标，任务层的 mission.js 表达不了
//（它要等 B 线的 route_loader），所以这里只做形态自检，不丢给 parseMission。
try {
    if (src.kind === 'route') {
        const { assertStationOnlyMissions } = await import(pathToFileURL(path.join(HERE, 'route_guard.mjs')).href);
        assertStationOnlyMissions(src.missions);
        log(`route 模式：${src.missions.length} 个 do station 段，形态自检通过（无坐标）`);
    } else {
        const { parseMission } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/mission.js')).href);
        for (const m of src.missions) parseMission(m.raw);
    }
} catch (e) {
    console.error(`[fullrun] 序列预校验失败（${String(e).slice(0, 200)}），未起服`);
    process.exit(2);
}

const trialNumbers = Array.from({ length: TRIALS }, (_, i) => START + i);
const seedList = SEED_LIST ? SEED_LIST.split(',').map((s) => s.trim()) : null;
const seedFor = (n) => (seedList ? (seedList[n - START] ?? `${RUNSTAMP}-${n}`) : (SEED_LITERAL || `${RUNSTAMP}-${String(n).padStart(2, '0')}`));

log(`FULLRUN ${RUNSTAMP}: ${describeSource(src)}`);
log(`policy=${describePolicy(policy)} | 段超时=${SEG_TIMEOUT_MS / 1000}s 整局超时=${TOTAL_TIMEOUT_MS / 1000}s 无进展中止=${NO_PROGRESS_S}s`);
log(`任务层只读引用：${MINDCRAFT}${MINDCRAFT === path.join(ROOT, 'mindcraft') ? '' : '（env 覆盖）'}`);

if (process.argv.includes('--plan-only')) {
    log(`PLAN OK：${trialNumbers.length} trial（泳道 C，串行），seeds=${trialNumbers.map(seedFor).join(',')}`);
    process.exit(0);
}

// 泳道 C 端口断言（**自建，不依赖 _lib/preflight 的 scope 语义**）
// 2026-10-01 22:00 记录：另一条开发线在 21:59 改了 _lib/preflight.mjs，加了
// `myLanes = LANE_PORTS.slice(0, requireLanes)` 的按需预检（14565→15654 字节）。前缀切片只服务
// A/B 线——分配到 lane C 的线用 requireLanes:1 反而**不再检查 25568/25578**。所以这里自己查一遍
// 本线的两个端口：被占就拒跑（残留清理由 preflight --kill-stale 负责，本单不强杀别人的进程）。
function assertLaneCPortsFree() {
    const listeners = netstatListeners();
    const busy = [LANE.serverPort, LANE.rconPort].filter((pt) => (listeners[String(pt)] ?? []).length > 0);
    if (busy.length) {
        const detail = busy.map((pt) => `:${pt} pid=${(listeners[String(pt)] ?? []).join(',')}`).join(' ');
        log(`preflight X 泳道 C 端口被占（${detail}）→ 拒跑。请先确认残留来源；本线孤儿残留用 `
            + `node bench/stages/_lib/preflight.mjs --kill-stale 清，不要手杀非本线进程。`);
        return false;
    }
    return true;
}

// preflight：只把**本线要用到的 C 泳道**当放行条件（手册 §9 不抢别的泳道）
//
// ⚠ `killStale` **必须为 false**，这不是保守，是实测踩到的自杀地雷（2026-10-02）：
//   preflight 的「本线残留且不占契约端口」判定是**命令行匹配 `bench/stages`**，
//   而任何住在 bench/stages 下的 runner 自己都匹配（`bench\stages\fullrun\run_bench.mjs`）。
//   起服之前 runner 还没登记心跳 → 自己被判成"无主孤儿" → `taskkill /T /F` 把自己连同父进程
//   一起杀掉 → 进程**静默 exit 1，没有任何报错**（实测干跑验收卡在这里，日志里那条
//   "本线残留进程（不占契约端口）pid=8180 … run_bench.mjs --stamp ROUTE_DRY4" 就是我自己）。
//   这与 06c「cleanup 杀了线 B 的进程」是同一类地雷：自动清理靠"命令行像不像自己"判断归属，
//   而住在同一目录树下的进程天然"像自己"。
//   所以这里只让 preflight **报告**残留，由人决定；孤儿清理请显式跑
//   `node bench/stages/_lib/preflight.mjs --kill-stale`（那时它是独立进程，不会自杀）。
//
// laneNames: ['C'] —— 用主线 A 在 TASK-06d P0 新增的**按名选泳道**能力
//   （此前只有 requireLanes=N 的"从 A 起前 N 条"前缀切片，给不了 C/D 线；见 §6 提效条目①）。
const pf = await preflight({ killStale: false, laneNames: [LANE.name], logFn: log });
for (const n of pf.notes) log(`preflight: ${n}`);
for (const w of pf.warns) log(`preflight ! ${w}`);
const myPorts = new Set([LANE.serverPort, LANE.rconPort]);
const mine = [], others = [], memShort = [];
for (const b of pf.blockers) {
    if (/空闲内存/.test(b)) { memShort.push(b); continue; }          // 内存不足 = 排队，不是硬阻塞
    const hit = [...myPorts].find((pt) => b.includes(`:${pt}`));
    (hit ? mine : others).push(b);
}
for (const b of others) log(`preflight ~ 别的泳道/端口占用（本单只用 C，不动、不等）: ${b}`);
for (const b of memShort) log(`preflight ~ 内存不足 → 按护栏排队等待（不降阈值）: ${b}`);
// 有本线孤儿残留时**拒跑**（不自杀、不代劳清理）；**先排除自己**——
//   preflight 会把「住在 bench/stages 下、起服前还没心跳」的 runner 报成残留（见上），
//   那条永远指向本进程自己，不能拿来拒自己。
const selfPid = process.pid;
const staleForeign = pf.warns.filter((w) => /本线残留进程（不占契约端口）/.test(w) && !new RegExp(`pid=${selfPid}\\b`).test(w));
if (staleForeign.length) {
    for (const w of staleForeign) log(`preflight ! ${w}`);
    log('preflight X 存在本线孤儿残留 → 拒跑（不自动清理，见上方注释里的自杀地雷说明）。'
        + '确认残留来源后再显式执行：node bench/stages/_lib/preflight.mjs --kill-stale');
    process.exit(1);
}
if (mine.length) {
    for (const b of mine) log(`preflight X ${b}`);
    // 泳道 C 与开发线 E 排队共用（手册 §9）：别人占着就**等**，不抢、不清。
    if (mine.every((b) => /归属活着的 runner/.test(b)) && process.argv.includes('--wait-lane')) {
        log('preflight: 泳道 C 被别的活 runner 占用 → 按心跳排队等待（--wait-lane）');
        const t0w = Date.now();
        const { ownerTable, liveOwnerPids } = await import(pathToFileURL(path.join(HERE, '../_lib/preflight.mjs')).href);
        const { procInfo } = await import(pathToFileURL(path.join(HERE, '../_lib/preflight.mjs')).href);
        for (;;) {
            await new Promise((r) => setTimeout(r, 5000));
            const st = netstatListeners();
            const busy = [LANE.serverPort, LANE.rconPort].some((pt) => (st[String(pt)] ?? []).length > 0);
            const rec = ownerTable()['server-1161_lanec'];
            const foreign = rec && rec.ageMs != null && rec.ageMs <= 20000
                && liveOwnerPids(new Set(procInfo().map((p) => p.pid))).has(Number(rec.runnerPid))
                && Number(rec.runnerPid) !== process.pid;
            const freeMB = Math.round(os.freemem() / 1048576);
            if (!busy && !foreign && freeMB >= MIN_FREE_MB) {
                log(`preflight: 泳道 C 已让出（排队 ${((Date.now() - t0w) / 1000).toFixed(0)}s，free=${freeMB}MB）`);
                break;
            }
            if (Date.now() - t0w > 45 * 60 * 1000) { log('preflight X 排队超时 45min'); process.exit(1); }
        }
    } else { log('PREFLIGHT BLOCKED（泳道 C 不可用；要排队请加 --wait-lane）'); process.exit(1); }
}
if (!assertLaneCPortsFree()) process.exit(1);
log(`preflight: 泳道 C 端口可用；开每局前按 <${MIN_FREE_MB}MB 护栏排队（当前 free=${(os.freemem() / 1048576).toFixed(0)}MB）`);

const lane = ensureLaneC();
fs.mkdirSync(RUNS_DIR, { recursive: true });
const SUMMARY = path.join(RUNS_DIR, 'summary.jsonl');
const META = path.join(RUNS_DIR, 'run_meta.json');
fs.writeFileSync(META, JSON.stringify({
    stamp: RUNSTAMP, stage: 'MC-FULLRUN-01', lane: 'C', ports: [LANE.serverPort, LANE.rconPort],
    mindcraftRoot: MINDCRAFT, mcVersion: MC_VERSION, jar: JAR_NAME, java: JAVA, serverXmx: SERVER_XMX,
    missionSource: { id: src.id, kind: src.kind, origin: src.origin, label: src.label, missions: src.missions.map((m) => m.raw) },
    policy: policy.raw, policyDesc: describePolicy(policy),
    segmentTimeoutMs: SEG_TIMEOUT_MS, totalTimeoutMs: TOTAL_TIMEOUT_MS, noProgressMs: NO_PROGRESS_S * 1000,
    minFreeMb: MIN_FREE_MB, startedAt: new Date().toISOString(),
}, null, 2));

let done = 0, complete = 0;
const t0all = Date.now();
for (const n of trialNumbers) {
    const seed = seedFor(n);
    const runDir = path.join(RUNS_DIR, `trial_${String(n).padStart(2, '0')}`);
    fs.mkdirSync(runDir, { recursive: true });
    const row = { trial: n, seed, lane: 'C', startedAt: new Date().toISOString(), source: src.id, policy: policy.raw };
    for (let attempt = 1; attempt <= 2; attempt++) {
        row.attempt = attempt;
        // 内存护栏：不够就排队等（手册 §9）
        const waited = await waitFreeMem(MIN_FREE_MB * 1048576, log);
        if (waited) log(`trial ${n}: 内存护栏排队 ${(waited / 1000).toFixed(0)}s`);
        freshWorld(lane, seed);
        log(`trial ${n} [lane C]: fresh world seed=${seed}，起服（xmx=${SERVER_XMX} free=${(os.freemem() / 1048576).toFixed(0)}MB）`);
        let server;
        try { server = await bootServerWithRetry(lane, runDir, SERVER_XMX, log, 3); }
        catch (e) { row.outcome = 'SERVER_FAIL'; row.error = String(e).slice(0, 200); break; }
        row.bootMs = server.bootMs;
        log(`trial ${n} [lane C]: server up in ${(server.bootMs / 1000).toFixed(0)}s，起 fullrun_bot（单进程连跑 ${src.missions.length} 段）`);

        // ⚠ 必须**连 kind 前缀一起传**：src.origin 只是解析后的路径，丢掉 `route:` 前缀的话
        //   bot 会把 route 文件当 script 源去找 `{missions:[...]}` → MISSION_SOURCE_BAD_SHAPE
        //   （实测干跑验收第一次就栽在这，bot 起服后立刻 boot fail）。
        const botMissions = src.kind === 'route' ? `route:${src.origin}` : src.origin;
        const botArgs = [
            path.join(HERE, 'fullrun_bot.mjs'),
            '--trial', String(n), '--seed', seed, '--out', runDir,
            '--port', String(LANE.serverPort), '--username', LANE.username,
            '--missions', botMissions, '--on-fail', policy.raw,
            '--segment-timeout-ms', String(SEG_TIMEOUT_MS), '--total-timeout-ms', String(TOTAL_TIMEOUT_MS),
            '--mc-version', MC_VERSION, '--probe-ms', String(PROBE_MS),
            // 透传：route 干跑与作废验收（--dry-route / --allow-draft / --mutate-route-after N）
            ...EXTRA_BOT_ARGS,
        ];
        const botOut = fs.openSync(path.join(runDir, 'bot_console.log'), 'a');
        const botProc = spawn(NODE20, botArgs, {
            cwd: HERE, stdio: ['ignore', botOut, botOut],
            env: { ...process.env, MC_MINDCRAFT_ROOT: MINDCRAFT },
        });
        const exitCode = await awaitBotExit(botProc, runDir, { timeoutMs: TOTAL_TIMEOUT_MS, noProgressMs: NO_PROGRESS_S * 1000 }, row);
        row.botExit = exitCode;
        log(`trial ${n} [lane C]: bot exit=${exitCode}，停服`);
        await stopServer(lane, server);
        await sleep(1500);
        try { fs.closeSync(botOut); } catch { /* 忽略 */ }

        try {
            const result = JSON.parse(fs.readFileSync(path.join(runDir, 'result.json'), 'utf8'));
            row.result = result;
            row.outcome = result.status === 'SUCCESS' ? 'SUCCESS' : `FAIL(${result.failReason ?? result.status})`;
            if (result.status === 'CONNECT_FAIL' || result.status === 'RUNNER_TIMEOUT' || result.status === 'KICKED') {
                log(`trial ${n}: 基建级失败（${result.status}），15s 冷却后重试`);
                await sleep(15000);
                continue;
            }
        } catch {
            if (row.abort?.reason === 'no_progress') row.outcome = 'FAIL(NO_PROGRESS_ABORT)';
            else if (exitCode === -8) row.outcome = 'NO_PROGRESS_ABORT';
            else { row.outcome = 'NO_RESULT'; log(`trial ${n}: 无 result（exit=${exitCode}），15s 冷却后重试`); await sleep(15000); continue; }
        }
        break;
    }
    row.finishedAt = new Date().toISOString();
    fs.appendFileSync(SUMMARY, JSON.stringify(row) + '\n');
    done++;
    if (row.outcome === 'SUCCESS') complete++;
    log(`trial ${n} → ${row.outcome}${row.result?.wallMs ? ` wall=${(row.result.wallMs / 1000).toFixed(1)}s` : ''}${row.result?.segmentsOk != null ? ` segs=${row.result.segmentsOk}/${row.result.segmentsTotal}` : ''}`);
}

// run_meta 先落终态，再汇总（否则 report.md 里墙钟/成功数会是 '?'）。
// 成功/总数按 summary.jsonl 全量统计（--start>1 的续跑会把之前的 trial 一起算进去，
// 只统计本轮会与分段表行数对不上）。
const allRows = fs.existsSync(SUMMARY)
    ? fs.readFileSync(SUMMARY, 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean)
    : [];
fs.writeFileSync(META, JSON.stringify({
    ...JSON.parse(fs.readFileSync(META, 'utf8')),
    finishedAt: new Date().toISOString(), wallMs: Date.now() - t0all,
    success: allRows.filter((r) => r.outcome === 'SUCCESS').length, total: allRows.length,
    thisInvocation: { success: complete, total: done, trials: trialNumbers },
}, null, 2));

// 汇总（连跑 vs 单独跑对照 + 分段表）
const sumRun = spawnSync(NODE20, [path.join(HERE, 'summarize.mjs'), '--run', RUNSTAMP], { stdio: 'inherit' });

// 收工（cleanup 只传 C 目录；不碰 A/B 泳道的 world）
if (!SKIP_CLEANUP) {
    const cu = await cleanup({ label: `fullrun ${RUNSTAMP}`, rmWorlds: !KEEP_WORLD, dirs: [{ dir: lane.dir, port: LANE.serverPort }] });
    fs.writeFileSync(path.join(RUNS_DIR, 'cleanup.txt'), cu.lines.join('\n') + '\n');
}
log(`DONE: ${complete}/${done} COMPLETE, wall=${((Date.now() - t0all) / 60000).toFixed(1)}min, 产物 ${path.relative(ROOT, RUNS_DIR)}`);
process.exit(0);
