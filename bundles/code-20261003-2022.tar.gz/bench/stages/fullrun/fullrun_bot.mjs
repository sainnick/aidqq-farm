// fullrun_bot.mjs — MC-FULLRUN-01 整局编排执行机器人（standalone，单 bot 进程连跑 MISSION 序列）
//
// 与 bench/stages/basic-iron/exec_bot.mjs 的关系：协议、探针、任务层调用**逐行同构**（便于维护者对照），
// 差别只有一处、但它是本单的全部意义：**一个进程、一个世界、一个背包里连续跑完一串 MISSION**。
// 原来每个 bench 局 = 一个 fresh world + 一个 MISSION，所以"阶段交接"这类问题在旧口径下**结构上测不到**：
//   背包残留 / 人在地下还是地面 / 阶段交接的状态 / 死亡后从哪续 —— 只有连跑才会暴露。
//
// 分段数据（splits.json，每段一条）：
//   墙钟 wallMs | 游戏刻 tick{age 增量, TPS 估计} | 背包快照 inventory | 位置+维度 position/dimension
//   | 死亡次数 deaths | 交接态 handoff（与上一段的差：位置/维度/背包） | 任务层计数器 metrics
//   失败也**完整落盘**（任务单 §1.3）。
//
// 零 LLM 是结构性保证：不加载 prompter/history/self-prompt/dm_client（同 TASK-01 起各 bench 的口径）。
// 零 kit：本 bench 不提供任何 give 通道（正式口径）。任务层只吃 MISSION（手册 §7）。
//
// 用法（run_bench.mjs 会自动拼好；手跑见 README）：
//   node fullrun_bot.mjs --trial 1 --seed <seed> --out <runDir> --port 25568 --username TaskBotC
//       --missions script:missions/seq-bucket-flint.json --on-fail retry:1
//       [--segment-timeout-ms 540000] [--total-timeout-ms 1200000] [--mc-version 1.16.1] [--probe-ms 10000]

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import { loadMissionSource, describeSource } from './mission_source.mjs';
import { parsePolicy, describePolicy, nextAction, notRunStub } from './policy.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
// 任务层**只读引用**（任务单 §1.2 / §禁区）：路径走环境变量，以后要指到别的 worktree 只改 env。
// 本单绝不写 mindcraft/ 下任何文件。
const MINDCRAFT = path.resolve(process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft'));
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}

const TRIAL = parseInt(arg('trial', '0'), 10);
const SEED = arg('seed', 'unknown');
const OUT_DIR = arg('out', HERE);
const PORT = parseInt(arg('port', '25568'), 10);
const USERNAME = arg('username', 'TaskBotC');
const MISSIONS = arg('missions', 'script:missions/seq-bucket-flint.json');
const POLICY = parsePolicy(arg('on-fail', 'abort'));
const SEG_TIMEOUT_MS = parseInt(arg('segment-timeout-ms', '540000'), 10);
const GATHER_TIMEOUT_MS = parseInt(arg('gather-timeout-ms', '420000'), 10);
const TOTAL_TIMEOUT_MS = parseInt(arg('total-timeout-ms', String(SEG_TIMEOUT_MS * 3)), 10);
const MC_VERSION = arg('mc-version', '1.16.1');
const PROBE_MS = parseInt(arg('probe-ms', '10000'), 10);
const STACK_MAX_DEPTH = parseInt(arg('stack-max-depth', '8'), 10);
// MC-ROUTE-02（route 驱动模式）
const ALLOW_DRAFT = process.argv.includes('--allow-draft');   // 草稿 route 只给开发局（SCHEMA §3）
const REQUIRE_FROZEN = process.argv.includes('--require-frozen');
/** 干跑：B 线的 `do station` 落地前，route 模式只生成序列 + 记 sha + 跳执行（任务单 §3） */
const DRY_ROUTE = process.argv.includes('--dry-route');
/** 测试钩子：第 N 段之后模拟一次"外部改了 route"（默认 -1 = 关）。仅用于验收作废判定。 */
const MUTATE_AFTER = parseInt(arg('mutate-route-after', '-1'), 10);

const TELEMETRY = path.join(OUT_DIR, 'telemetry.jsonl');
const SPLITS = path.join(OUT_DIR, 'splits.json');
const SPLITS_MD = path.join(OUT_DIR, 'splits.md');
const RESULT = path.join(OUT_DIR, 'result.json');
const LOG = path.join(OUT_DIR, 'bot.log');
const PROBE = path.join(OUT_DIR, 'probe.jsonl');

fs.mkdirSync(OUT_DIR, { recursive: true });
const logLine = (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(LOG, line + '\n'); } catch { /* 忽略 */ }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let finished = false;
let _spawned = false;
let deathsTotal = 0;
let _runtime = null;
let _probeTimer = null;
let _curSeg = null;
let hardKillRef = null;
let botRef = null;
/** MC-ROUTE-02：整局的 route 账（sha 复验 + 黑名单跨段台账），finish 时落进 splits.json */
let routeReport = null;
/** 进行中的分段（异常/看门狗路径也要能落盘已跑过的段，任务单 §1.3「失败也要落盘」） */
let globalSegments = [];

// ---- 分段取样工具 ----
function invSnapshot(bot) {
    const o = {};
    for (const it of bot.inventory.items()) o[it.name] = (o[it.name] ?? 0) + it.count;
    return o;
}
function invCompact(inv, limit = 8) {
    const parts = Object.entries(inv ?? {}).sort((a, b) => b[1] - a[1]);
    const head = parts.slice(0, limit).map(([n, c]) => `${n}:${c}`).join(',');
    return parts.length > limit ? `${head},…(+${parts.length - limit})` : (head || '(empty)');
}
function posOf(bot) {
    const p = bot.entity?.position;
    return p ? [+p.x.toFixed(2), +p.y.toFixed(2), +p.z.toFixed(2)] : null;
}
/** 游戏刻取样：1.16.1 的 update_time 包带 age(世界年龄) 与 time(时刻)；
 *  mineflayer time 插件把 age 放进 bot.time.age（见 node_modules/mineflayer/lib/plugins/time.js）。
 *  不猜：取不到就记 null，由上层用 tps 估计自证。 */
function tickOf(bot) {
    const t = bot.time;
    return {
        age: Number.isFinite(t?.age) ? t.age : null,           // 世界年龄（单调，分段差值用这个）
        time: Number.isFinite(t?.time) ? t.time : null,         // 当日时刻
        timeOfDay: Number.isFinite(t?.timeOfDay) ? t.timeOfDay : null,
        day: Number.isFinite(t?.day) ? t.day : null,
    };
}
function tickDelta(a, b, wallMs) {
    if (!Number.isFinite(a?.age) || !Number.isFinite(b?.age)) {
        return { source: 'unavailable', startAge: a?.age ?? null, endAge: b?.age ?? null, delta: null, tpsEst: null, ok: false, note: 'bot.time.age 不可用（未收到 update_time）' };
    }
    const delta = b.age - a.age;
    const wallSec = wallMs / 1000;
    const tpsEst = wallSec > 0 ? delta / wallSec : null;
    return {
        source: 'bot.time.age(worldAge)', startAge: a.age, endAge: b.age, delta,
        startTimeOfDay: a.timeOfDay ?? null, endTimeOfDay: b.timeOfDay ?? null,
        tpsEst: tpsEst == null ? null : +tpsEst.toFixed(2),
        ok: delta > 0 && tpsEst != null && tpsEst >= 5 && tpsEst <= 20.6,
    };
}

// ---- runner 级进度探针（schema 同 basic-iron，多 seg/segStatus 两列）----
function probeTree(rt) {
    try {
        const trace = rt?._ctx?.stack?.renderTrace?.() ?? '';
        return trace.replace(/\[[^\]]*\]/g, '[]');
    } catch { return ''; }
}
function startProbe(bot) {
    if (!(PROBE_MS > 0)) return;
    try { fs.rmSync(PROBE, { force: true }); } catch { /* 忽略 */ }
    _probeTimer = setInterval(() => {
        try {
            const invParts = bot.inventory.items().map((i) => `${i.name}:${i.count}`).sort();
            const p = bot.entity?.position;
            const w = bot.currentWindow;
            const furnace = w && String(w.type).includes('furnace')
                ? { f: Math.round(w.fuelSeconds ?? 0), p: Math.round(w.progressSeconds ?? 0) }
                : null;
            fs.appendFileSync(PROBE, JSON.stringify({
                t: Date.now(), event: 'bench_probe',
                inv: invParts.join(','),
                pos: p ? [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)] : null,
                digging: !!bot.targetDigBlock,
                furnace,
                tree: probeTree(_runtime),
                seg: _curSeg ? { i: _curSeg.index, id: _curSeg.id, attempt: _curSeg.attempt } : null,
                segStatus: _curSeg ? 'RUNNING' : 'IDLE',
                deaths: deathsTotal,
            }) + '\n');
        } catch { /* 探针失败不影响试局 */ }
    }, PROBE_MS);
    _probeTimer.unref?.();
}

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const toolPlugin = require('mineflayer-tool').plugin;
    const { TaskRuntime } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/task_runner.js')).href);
    const { AcquireResourceTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/acquire_resource_task.js')).href);
    const { CraftingTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/crafting_task.js')).href);
    const { parseMission } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/mission.js')).href);
    const { resourceDef } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/resources.js')).href);

    // ---- 源与策略：先解析，起服后才发现序列不合法就是白烧机器时间 ----
    const src = await loadMissionSource(MISSIONS, { cwd: HERE });
    logLine(`source: ${describeSource(src)} (${src.origin})`);
    logLine(`policy: on-fail=${describePolicy(POLICY)}  segment-timeout=${SEG_TIMEOUT_MS}ms  total-timeout=${TOTAL_TIMEOUT_MS}ms`);

    // MC-ROUTE-02：route 驱动模式 —— 编排器侧只做文件选择 / sha 记录 / 分段统计，
    // **不读 scout、不把站数据传给任务层**（任务层的 route_loader 是 B 线的活）。
    let routeGuard = null;
    if (src.kind === 'route') {
        const { RouteGuard, assertStationOnlyMissions } = await import(pathToFileURL(path.join(HERE, 'route_guard.mjs')).href);
        assertStationOnlyMissions(src.missions);
        routeGuard = new RouteGuard(src.origin, { allowDraft: ALLOW_DRAFT, requireFrozen: REQUIRE_FROZEN });
        if (!routeGuard.started.ok) {
            logLine(`route 闸门拒绝：${routeGuard.started.reason}`);
            finish({ status: 'ROUTE_REJECTED', failReason: routeGuard.started.reason, outcome: 'REJECTED' }, 2, { src, segments: [] });
            return;
        }
        logLine(`route 闸门通过：sha256=${routeGuard.sha256.slice(0, 16)}… frozen=${routeGuard.started.frozen} 站数=${src.missions.length}`);
    } else {
        // 权威校验：任务层真 parseMission（资源表 + 计数上限）——预校验失败就不该连上服
        for (const m of src.missions) {
            try { parseMission(m.raw); }
            catch (e) { finish({ status: 'MISSION_SOURCE_REJECTED', failReason: String(e).slice(0, 160) }, 1, { src, segments: [] }); return; }
        }
    }

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
    botRef = bot;
    bot.loadPlugin(pf.pathfinder);
    bot.loadPlugin(toolPlugin);

    hardKillRef = setTimeout(() => {
        logLine('HARD_TIMEOUT: 整局看门狗触发，尝试落盘已跑分段后退出');
        finish({ status: 'RUNNER_TIMEOUT', failReason: `total>${TOTAL_TIMEOUT_MS}ms` }, 1, { src, segments: globalSegments });
    }, TOTAL_TIMEOUT_MS + 60000);

    bot.on('kicked', (r) => { logLine(`kicked: ${r}`); if (!finished) finish({ status: 'KICKED', reason: String(r) }, 1, { src, segments: globalSegments }); });
    bot.on('error', (e) => {
        logLine(`bot_error: ${String(e).slice(0, 200)}`);
        if (!finished && !_spawned) finish({ status: 'CONNECT_FAIL', reason: String(e).slice(0, 120) }, 1, { src, segments: [] });
    });
    // 死亡 → 计数 + 重生。**全 run 有效**（不是每段重挂）：连跑里"死亡后从哪续"是要被观测的对象。
    bot.on('death', () => {
        deathsTotal++;
        logLine(`death #${deathsTotal}（${_curSeg ? `${_curSeg.id} attempt${_curSeg.attempt}` : 'between-segments'}）→ 800ms 后重生`);
        setTimeout(() => { try { bot.respawn(); } catch { /* 忽略 */ } }, 800);
    });

    bot.once('spawn', async () => {
        _spawned = true;
        const runT0 = Date.now();
        const runTick0 = tickOf(bot);
        try {
            await sleep(4000); // 世界落定（TASK-01 同款）
            const spawnPos = bot.entity.position.floored();
            logLine(`spawn: seed=${SEED} pos=[${spawnPos.x},${spawnPos.y},${spawnPos.z}] dim=${bot.game.dimension} tickAge=${runTick0.age}`);
            logLine('protocol: NO KIT, NO LLM（整局只吃 MISSION 序列）');
            startProbe(bot);

            const spawnInv = invSnapshot(bot);
            logLine(`spawn inventory: ${invCompact(spawnInv)}`);

            const segments = [];
            globalSegments = segments; // 异常/看门狗路径也要能落盘已跑段
            let aborted = null;
            let prevEnd = null; // 上一段的末态，用于算交接态

            for (const m of src.missions) {
                // MC-ROUTE-02：每段开始前复验 route 文件——被改过就整局作废（SCHEMA §3）
                if (routeGuard) {
                    const v = routeGuard.verify(`before:${m.id}`);
                    tele('route_hash_check', v);
                    if (!v.ok) {
                        logLine(`✗ route 校验失败：${v.reason} → 整局作废，剩余站按 NOT_RUN 落盘`);
                        segments.push(...notRunStub(src, m.index, `route_void:${m.id}`));
                        aborted = { at: m.id, index: m.index, reason: v.reason, policy: 'route_void' };
                        break;
                    }
                    // 测试钩子：模拟"外部在 run 中改了 route"（干跑时段耗时 ~0ms，抢不到人工窗口）。
                    // 判定路径与真实外部修改完全相同：重新读文件 + 比 sha256。
                    if (MUTATE_AFTER >= 0 && segments.length === MUTATE_AFTER) {
                        const ed = routeGuard.simulateExternalEdit();
                        logLine(`[test-hook] 模拟外部修改 route：${JSON.stringify(ed)}（下一段复验应判作废）`);
                        tele('route_test_hook_mutate', ed);
                    }
                }
                let attempt = 1;
                for (;;) {
                    const seg = DRY_ROUTE && routeGuard
                        ? drySegment(m, attempt, prevEnd, runT0)          // 干跑：不进任务层
                        : await runSegment(bot, { m, attempt, prevEnd, src, runT0 });
                    segments.push(seg);
                    _curSeg = null;
                    if (routeGuard) {
                        // 黑名单跨段台账：吸收本段遥测里的实测失败目标（只读观测，不注入任务层）
                        const ab = routeGuard.absorbSegmentTelemetry(TELEMETRY, { dim: m.dim ?? 'overworld' });
                        seg.blacklistLedgerAfter = ab.ledger.length;
                    }
                    // 干跑段不执行任何东西，既不会失败也不该触发失败策略——
                    // 早期版本把 DRY_RUN 当成"非 SUCCESS"，导致第 1 段后整局 abort、
                    // 后面的站全变 NOT_RUN（连作废钩子都没机会触发）。
                    const effStatus = DRY_ROUTE ? 'SUCCESS' : seg.status;
                    const act = nextAction(POLICY, effStatus, attempt);
                    logLine(`seg ${seg.id} (${seg.raw}) attempt${attempt}: ${seg.status}${seg.failReason ? `/${seg.failReason}` : ''} ${seg.wallSec}s → ${act}${DRY_ROUTE ? '（干跑：按 SUCCESS 记账）' : ''}`);
                    if (act === 'continue') { prevEnd = seg; break; }
                    if (act === 'retry') { attempt++; prevEnd = seg; continue; }
                    aborted = { at: seg.id, index: m.index, reason: seg.failReason ?? seg.status, policy: POLICY.raw };
                    break;
                }
                if (aborted) {
                    const rest = notRunStub(src, m.index + 1, `abort_by_policy@${m.id}`);
                    segments.push(...rest);
                    if (rest.length) logLine(`abort: 剩余 ${rest.length} 段按 NOT_RUN 落盘（${rest.map((r) => r.id).join(',')}）`);
                    break;
                }
            }
            if (routeGuard) {
                const vEnd = routeGuard.verify('run_end');
                tele('route_hash_check', vEnd);
                logLine(`route 终检：${vEnd.ok ? 'OK' : `作废（${vEnd.reason}）`} 复验 ${routeGuard.checks.length} 次，台账 ${routeGuard.ledger.length} 条`);
                routeReport = routeGuard.report();
            }

            const ranSegments = segments.filter((s) => s.attempt > 0);
            const okSegments = ranSegments.filter((s) => s.status === 'SUCCESS');
            const outcome = aborted ? (okSegments.length === ranSegments.length ? 'ABORTED' : 'PARTIAL')
                : (okSegments.length === src.missions.length ? 'COMPLETE' : 'INCOMPLETE');
            const wallMs = Date.now() - runT0;

            finish({
                status: outcome === 'COMPLETE' ? 'SUCCESS' : `FULLRUN_${outcome}`,
                failReason: aborted ? `${aborted.reason}@${aborted.at}` : (outcome === 'COMPLETE' ? null : 'SEGMENT_NOT_SUCCESS'),
                outcome, wallMs, deaths: deathsTotal,
                segmentsTotal: src.missions.length,
                segmentsRan: ranSegments.length,
                segmentsOk: okSegments.length,
                aborted,
            }, outcome === 'COMPLETE' ? 0 : 1, {
                src, segments, runT0, runTick0, spawnPos: [spawnPos.x, spawnPos.y, spawnPos.z], spawnInv,
            });
        } catch (e) {
            logLine(`fatal: ${String(e && e.stack ? e.stack : e).slice(0, 600)}`);
            finish({ status: 'FAILED', failReason: 'INTERNAL', error: String(e).slice(0, 300) }, 1, { src, segments: globalSegments, runT0 });
        }
    });

    // ---- 单段执行 ----
    async function runSegment(bot, { m, attempt, prevEnd, src, runT0 }) {
        const t0 = Date.now();
        const tick0 = tickOf(bot);
        const inv0 = invSnapshot(bot);
        const pos0 = posOf(bot);
        const dim0 = bot.game.dimension ?? null;
        const deaths0 = deathsTotal;
        _curSeg = { index: m.index, id: m.id, attempt };

        // 交接态：与上一段末态的差（阶段交接问题的主要观测面）
        const handoff = prevEnd ? {
            fromSegment: prevEnd.id,
            invUnchanged: JSON.stringify(prevEnd.inventory ?? {}) === JSON.stringify(inv0),
            invDelta: diffInv(prevEnd.inventory ?? {}, inv0),
            posDelta: (prevEnd.position && pos0) ? +dist(prevEnd.position, pos0).toFixed(2) : null,
            yDelta: (prevEnd.position && pos0) ? +(pos0[1] - prevEnd.position[1]).toFixed(2) : null,
            dimensionChanged: (prevEnd.dimension ?? null) !== dim0,
            prevDimension: prevEnd.dimension ?? null,
        } : { fromSegment: null, note: '首段（世界/背包起点）' };

        logLine(`── seg ${m.id} attempt${attempt} start: ${m.raw} pos=${JSON.stringify(pos0)} dim=${dim0} y=${pos0?.[1] ?? '?'} inv=${invCompact(inv0)} deaths=${deaths0}`);
        tele('fullrun_segment_start', { seg: m.index, id: m.id, attempt, mission: m.raw, pos: pos0, dimension: dim0, deaths: deaths0, handoff });

        const mission = parseMission(m.raw);
        const def = resourceDef(mission.resource);
        const runtime = new TaskRuntime(bot, { mission, telemetryPath: TELEMETRY, stackMaxDepth: STACK_MAX_DEPTH });
        _runtime = runtime;
        // 根任务路由与 basic-iron 逐字一致（craft 型 → CraftingTask 自理整条链；gather 型 → AcquireResourceTask）
        const root = def.gather === false
            ? new CraftingTask({ item: def.item, count: mission.count, timeoutMs: SEG_TIMEOUT_MS, gatherTimeoutMs: GATHER_TIMEOUT_MS })
            : new AcquireResourceTask({ resource: mission.resource, count: mission.count, timeoutMs: SEG_TIMEOUT_MS });

        let summary = null, guard = null;
        try {
            // 段级看门狗：根任务自带 timeoutMs，这里再兜一层（任务层自身卡死时不让整局一起陪葬）
            summary = await Promise.race([
                runtime.run(root),
                sleep(SEG_TIMEOUT_MS + 30000).then(() => ({ __guard: `seg_timeout>${SEG_TIMEOUT_MS + 30000}ms` })),
            ]);
        } catch (e) {
            logLine(`seg ${m.id} 异常: ${String(e).slice(0, 200)}`);
            summary = { status: 'INTERNAL', failReason: String(e).slice(0, 160) };
        }
        if (summary?.__guard) { guard = summary.__guard; summary = { status: 'TIMEOUT', failReason: guard }; }
        _runtime = null;

        const wallMs = Date.now() - t0;
        const tick1 = tickOf(bot);
        const inv1 = invSnapshot(bot);
        const pos1 = posOf(bot);
        const dim1 = bot.game.dimension ?? null;

        const seg = {
            index: m.index, id: m.id, raw: m.raw, resource: mission.resource, count: mission.count,
            attempt, status: summary?.status ?? 'UNKNOWN', failReason: summary?.failReason ?? null,
            detail: summary?.detail ?? null,
            wallMs, wallSec: +(wallMs / 1000).toFixed(1),
            startedAt: new Date(t0).toISOString(), finishedAt: new Date(t0 + wallMs).toISOString(),
            runElapsedSec: +((t0 - runT0) / 1000).toFixed(1),
            tick: tickDelta(tick0, tick1, wallMs),
            inventory: inv1, inventoryCompact: invCompact(inv1),
            carryIn: inv0,
            position: pos1, positionStart: pos0,
            y: pos1?.[1] ?? null,
            dimension: dim1, dimensionStart: dim0,
            deaths: deathsTotal - deaths0, deathsTotal,
            handoff,
            metrics: summary?.metrics ?? null,
            blacklistSize: summary?.blacklistSize ?? null,
            transitions: summary?.transitions ?? null,
            taskTree: summary?.taskTree ?? null,
            guard,
        };
        tele('fullrun_segment_end', { ...seg, taskTree: undefined, inventory: undefined, carryIn: undefined });
        if (seg.taskTree) logLine(`seg ${m.id} task tree:\n${seg.taskTree}`);
        logLine(`── seg ${m.id} attempt${attempt} end: ${seg.status} ${seg.wallSec}s tickΔ=${seg.tick.delta ?? 'n/a'} tps≈${seg.tick.tpsEst ?? 'n/a'} y=${seg.y} dim=${seg.dimension} deaths=${seg.deaths} inv=${seg.inventoryCompact}`);
        return seg;
    }
}

/**
 * route 干跑段（MC-ROUTE-02 任务单 §3）：B 线的 `do station` 在任务层落地之前，
 * route 模式**只生成序列、记录 sha256、跳执行**。这一段不进任务层、不发任何 MISSION，
 * 但分段结构与落盘格式和真跑完全一致（同一份 splits.json 消费方不用改）。
 */
function drySegment(m, attempt, prevEnd, runT0) {
    const t0 = Date.now();
    return {
        index: m.index, id: m.id, raw: m.raw, resource: null, count: null, dim: m.dim ?? null,
        attempt, status: 'DRY_RUN', failReason: null,
        detail: { note: 'route 干跑：B 线 do station 未落地，跳过执行（只生成序列 + 记 sha）' },
        wallMs: Date.now() - t0, wallSec: 0,
        startedAt: new Date(t0).toISOString(), finishedAt: new Date(t0).toISOString(),
        runElapsedSec: +((t0 - runT0) / 1000).toFixed(1),
        tick: { source: 'unavailable', ok: false, note: 'dry-run 未执行' },
        inventory: null, inventoryCompact: null, carryIn: null,
        position: null, positionStart: null, y: null,
        dimension: null, dimensionStart: null,
        deaths: 0, deathsTotal,
        handoff: prevEnd ? { fromSegment: prevEnd.id, invUnchanged: null, invDelta: null, posDelta: null, yDelta: null, dimensionChanged: null, prevDimension: null, note: 'dry-run' } : { fromSegment: null, note: '首段（dry-run）' },
        metrics: null, blacklistSize: null, transitions: null, taskTree: null, guard: null,
    };
}

function tele(event, data) {
    const rec = JSON.stringify({ t: Date.now(), event, ...data });
    try { console.log(`[task-layer] ${rec}`); } catch { /* 忽略 */ }
    try { fs.appendFileSync(TELEMETRY, rec + '\n'); } catch { /* 遥测失败不影响主循环 */ }
}
function diffInv(a, b) {
    const keys = new Set([...Object.keys(a ?? {}), ...Object.keys(b ?? {})]);
    const out = {};
    for (const k of keys) {
        const d = (b?.[k] ?? 0) - (a?.[k] ?? 0);
        if (d !== 0) out[k] = d;
    }
    return Object.keys(out).length ? out : null;
}
function dist(a, b) {
    return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
}

// ---- 人看的分段表 + 机器读的 splits.json ----
function renderSplitsMd(payload) {
    const { src, segments, outcome, wallMs, deaths, seed, trial, lane, mcVersion, policy } = payload;
    const ran = segments.filter((s) => s.attempt > 0);
    const L = [];
    L.push(`# FULLRUN 分段表 — trial ${trial}（seed ${seed}）`);
    L.push('');
    L.push(`- 序列：**${src.label ?? src.id}**（${src.kind}，${src.missions.length} 段）`);
    L.push(`- 环境：泳道 ${lane} · 1.16.1 vanilla · 零 kit · 零 LLM · 失败策略 \`${policy}\``);
    L.push(`- 整局：墙钟 **${(wallMs / 1000).toFixed(1)}s** · 终态 **${outcome}** · 死亡 **${deaths}** · 段 ${ran.filter((s) => s.status === 'SUCCESS').length}/${src.missions.length} 成功`);
    L.push('');
    L.push('| # | 尝试 | MISSION | 终态 | 墙钟 | 游戏刻Δ | TPS≈ | 段末位置 | y | 维度 | 段内死亡 | 末态背包 |');
    L.push('|---|------|---------|------|------|---------|------|----------|---|------|----------|----------|');
    for (const s of segments) {
        const y = s.y ?? '—';
        L.push(`| ${s.id} | ${s.attempt || 0} | \`${s.raw}\` | ${s.status}${s.failReason ? ` (${s.failReason})` : ''} | ${s.wallSec}s | ${s.tick?.delta ?? '—'} | ${s.tick?.tpsEst ?? '—'} | ${s.position ? s.position.join(',') : '—'} | ${y} | ${s.dimension ?? '—'} | ${s.deaths} | ${s.inventoryCompact ?? '—'} |`);
    }
    L.push('');
    L.push('## 交接态（每段开始时 vs 上一段末态）');
    L.push('');
    L.push('| 段 | 来自 | 背包是否零变化 | 背包增量 | 位置位移 | y 位移 | 维度切换 |');
    L.push('|---|------|----------------|----------|----------|--------|----------|');
    for (const s of ran) {
        const h = s.handoff ?? {};
        L.push(`| ${s.id} | ${h.fromSegment ?? '—'} | ${h.fromSegment == null ? '—' : (h.invUnchanged ? '是' : '**否**')} | ${h.invDelta ? JSON.stringify(h.invDelta) : '—'} | ${h.posDelta ?? '—'} | ${h.yDelta ?? '—'} | ${h.dimensionChanged ? `**是**（${h.prevDimension}→${s.dimensionStart}）` : '否'} |`);
    }
    L.push('');
    L.push('## 任务层计数器（分段）');
    L.push('');
    const keys = ['deaths', 'searches', 'navFailures', 'successfulMines', 'hardStuck', 'softStuckEvents', 'recoveries', 'craftAttempts', 'craftFailures', 'tablePlacements', 'tablePlacementFailures', 'furnacePlacements', 'furnacePlacementFailures', 'smeltOk', 'smeltFailures', 'flintPlaceRedigs', 'ironTargetsSelected', 'maxDepth', 'childTasks', 'recipeResolves', 'depResolutions', 'depResolutionFailures', 'toolRescues'];
    L.push(`| 段 | ${keys.join(' | ')} |`);
    L.push(`|---|${keys.map(() => '---').join('|')}|`);
    for (const s of ran) {
        const m = s.metrics ?? {};
        L.push(`| ${s.id} | ${keys.map((k) => m[k] ?? 0).join(' | ')} |`);
    }
    L.push('');
    return L.join('\n');
}

function finish(summary, code, extra = {}) {
    if (finished) return;
    finished = true;
    clearTimeout(hardKillRef);
    if (_probeTimer) clearInterval(_probeTimer);
    const segments = extra.segments ?? globalSegments;
    globalSegments = segments;
    const src = extra.src ?? null;
    const payload = {
        trial: TRIAL, seed: SEED, port: PORT, username: USERNAME, mcVersion: MC_VERSION,
        mindcraftRoot: MINDCRAFT, missionSource: src ? { id: src.id, kind: src.kind, origin: src.origin, label: src.label } : null,
        policy: POLICY.raw, policyDesc: describePolicy(POLICY),
        segmentTimeoutMs: SEG_TIMEOUT_MS, totalTimeoutMs: TOTAL_TIMEOUT_MS,
        kit: 'none', llm: 'none',
        mode: DRY_ROUTE ? 'dry-route' : 'live',
        route: routeReport,   // MC-ROUTE-02：sha 复验账 + 黑名单跨段台账（非 route 模式为 null）
        spawnPos: extra.spawnPos ?? null, spawnInventory: extra.spawnInv ?? null,
        runTick0: extra.runTick0 ?? null,
        ...summary,
        segments,
    };
    try { fs.writeFileSync(SPLITS, JSON.stringify(payload, null, 2)); } catch (e) { logLine(`splits 写失败: ${e.message}`); }
    try {
        fs.writeFileSync(SPLITS_MD, renderSplitsMd({
            src: src ?? { id: '?', kind: '?', label: '?', missions: [] },
            segments, outcome: summary.outcome ?? summary.status, wallMs: summary.wallMs ?? 0,
            deaths: summary.deaths ?? deathsTotal, seed: SEED, trial: TRIAL,
            lane: `C:${PORT}`, mcVersion: MC_VERSION, policy: describePolicy(POLICY),
        }));
    } catch (e) { logLine(`splits.md 写失败: ${e.message}`); }
    try {
        fs.writeFileSync(RESULT, JSON.stringify({
            trial: TRIAL, seed: SEED, port: PORT, kit: 'none',
            status: summary.status, failReason: summary.failReason ?? null, outcome: summary.outcome ?? null,
            wallMs: summary.wallMs ?? null, deaths: summary.deaths ?? deathsTotal,
            segmentsTotal: summary.segmentsTotal ?? null, segmentsRan: summary.segmentsRan ?? null,
            segmentsOk: summary.segmentsOk ?? null, aborted: summary.aborted ?? null,
            error: summary.error ?? null, reason: summary.reason ?? null,
        }, null, 2));
    } catch (e) { logLine(`result 写失败: ${e.message}`); }
    logLine(`end: ${summary.status} ${summary.outcome ?? ''} wall=${((summary.wallMs ?? 0) / 1000).toFixed(1)}s deaths=${summary.deaths ?? deathsTotal} segs=${summary.segmentsOk ?? '?'}/${summary.segmentsTotal ?? '?'}`);
    setTimeout(() => {
        try { botQuit(); } catch { /* 忽略 */ }
        process.exit(code);
    }, 1200);
}

function botQuit() { try { botRef?.quit(); } catch { /* 忽略 */ } }

main().catch((e) => { logLine(`boot fail: ${String(e && e.stack ? e.stack : e).slice(0, 600)}`); process.exit(1); });
