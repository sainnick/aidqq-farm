// summarize.mjs — MC-FULLRUN-01 汇总与「连跑 vs 单独跑」对照
//
// 两件事：
//   1) 把一个 run stamp 的所有 trial 汇成一张跨局表（口径 = 全部 trial，失败局也进表，手册 §5）。
//   2) 分段耗时对照：连跑的每段耗时 vs 单独跑同一 MISSION 的 bench 耗时。
//      对照源有两种，都支持：
//        --control <stamp>        本 stage 的「1 段序列」对照局（--missions inline:"obtain 1 X"，
//                                 同一 runner / 同一泳道 / 同时段窗口 → 唯一的差别就是前面有没有跑过别的段，
//                                 这是最干净的同口径对照）
//        --baseline <summary.jsonl>  历史 bench 的单 MISSION 局（basic-iron 等），按 --baseline-seed 过滤
//
// 用法：
//   node summarize.mjs --run <stamp> [--control <stamp>...] [--baseline <p.jsonl> --baseline-seed <s>]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const RUNS = path.join(HERE, 'runs');
const argOf = (a, n, d) => { const i = a.indexOf(`--${n}`); return i >= 0 ? a[i + 1] : d; };
const argv = process.argv;
const RUNSTAMP = argOf(argv, 'run', '');
const CONTROLS = argOf(argv, 'control', '').split(',').map((s) => s.trim()).filter(Boolean);
const BASELINES = argOf(argv, 'baseline', '').split(',').map((s) => s.trim()).filter(Boolean);
const BASELINE_SEED = argOf(argv, 'baseline-seed', '');

const sleep0 = () => { };
const num = (x) => (Number.isFinite(x) ? x : null);
const sec = (ms) => (Number.isFinite(ms) ? +(ms / 1000).toFixed(1) : null);
function stats(samples) {
    const v = samples.filter(Number.isFinite).sort((a, b) => a - b);
    if (!v.length) return null;
    const med = v.length % 2 ? v[(v.length - 1) / 2] : +(((v[v.length / 2 - 1] + v[v.length / 2]) / 2).toFixed(1));
    const mean = +(v.reduce((a, b) => a + b, 0) / v.length).toFixed(1);
    return { n: v.length, median: med, mean, min: v[0], max: v.at(-1), samples: v };
}
function readJsonl(p) {
    if (!fs.existsSync(p)) return [];
    return fs.readFileSync(p, 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}
function loadRun(stamp) {
    const dir = path.join(RUNS, stamp);
    if (!fs.existsSync(dir)) { console.error(`[fullrun summarize] 找不到 run 目录 ${dir}`); return null; }
    const rows = readJsonl(path.join(dir, 'summary.jsonl'));
    const trials = [];
    for (const r of rows) {
        const sp = path.join(dir, `trial_${String(r.trial).padStart(2, '0')}`, 'splits.json');
        let splits = null;
        try { splits = JSON.parse(fs.readFileSync(sp, 'utf8')); } catch { /* 缺失也算数：数据完整性要报出来 */ }
        trials.push({ row: r, splits, dir: path.dirname(sp) });
    }
    let meta = null;
    try { meta = JSON.parse(fs.readFileSync(path.join(dir, 'run_meta.json'), 'utf8')); } catch { /* 忽略 */ }
    return { stamp, dir, rows, trials, meta };
}
function segSamples(run, resource) {
    const out = [];
    for (const t of run.trials) {
        for (const s of (t.splits?.segments ?? [])) {
            if (s.attempt > 0 && s.resource === resource) out.push({ wallSec: s.wallSec, status: s.status, trial: t.row.trial, attempt: s.attempt, seed: t.row.seed });
        }
    }
    return out;
}
function firstAttempt(samples) { return samples.filter((s) => s.attempt === 1); }

const run = loadRun(RUNSTAMP);
if (!run) process.exit(1);
const controlRuns = CONTROLS.map(loadRun).filter(Boolean);
const baselineRows = BASELINES.flatMap(readJsonl);

const L = [];
const P = (s = '') => L.push(s);
P(`# FULLRUN 汇总 — ${run.stamp}`);
P('');
if (run.meta) {
    P(`- 序列：${run.meta.missionSource?.missions?.join(' → ') ?? '?'}（source \`${run.meta.missionSource?.kind}:${path.basename(run.meta.missionSource?.origin ?? '')}\`）`);
    P(`- 口径：泳道 ${run.meta.lane} · ${run.meta.mcVersion} · 零 kit · 零 LLM · 失败策略 \`${run.meta.policy}\` · 段超时 ${(run.meta.segmentTimeoutMs / 1000) | 0}s×${run.meta.missionSource?.missions?.length} · 整局超时 ${(run.meta.totalTimeoutMs / 1000) | 0}s · 无进展中止 ${(run.meta.noProgressMs / 1000) | 0}s`);
    P(`- 任务层只读引用：\`${run.meta.mindcraftRoot}\``);
    P(`- 起跑 ${run.meta.startedAt} · 墙钟 ${run.meta.wallMs ? (run.meta.wallMs / 60000).toFixed(1) + 'min' : '?'} · 成功 ${run.meta.success ?? '?'}/${run.meta.total ?? '?'}`);
}
P('');

// 1) 跨局表
P('## 1. 整局结果（全部 trial 口径）');
P('');
P('| trial | seed | 终态 | 整局墙钟 | 段成功 | 死亡 | 段数落盘 | 备注 |');
P('|---|---|---|---|---|---|---|---|');
for (const t of run.trials) {
    const r = t.row, s = t.splits;
    P(`| ${r.trial} | ${r.seed} | ${r.outcome} | ${sec(r.result?.wallMs) ?? '—'}s | ${r.result?.segmentsOk ?? '—'}/${r.result?.segmentsTotal ?? '—'} | ${r.result?.deaths ?? '—'} | ${s?.segments?.length ?? '—'} | ${r.result?.aborted ? `abort@${r.result.aborted.at}:${r.result.aborted.reason}` : (r.attempt > 1 ? `attempt${r.attempt}` : '')} |`);
}
P('');

// 2) 分段明细
P('## 2. 分段明细（每段一行）');
P('');
P('| trial | 段 | 尝试 | MISSION | 终态 | 墙钟 | 游戏刻Δ | TPS≈ | y | 维度 | 段内死亡 | 段末背包 |');
P('|---|---|---|---|---|---|---|---|---|---|---|---|');
for (const t of run.trials) {
    for (const s of (t.splits?.segments ?? [])) {
        P(`| ${t.row.trial} | ${s.id} | ${s.attempt || 0} | \`${s.raw}\` | ${s.status}${s.failReason ? ` (${s.failReason})` : ''} | ${s.wallSec}s | ${s.tick?.delta ?? '—'} | ${s.tick?.tpsEst ?? '—'} | ${s.y ?? '—'} | ${s.dimension ?? '—'} | ${s.deaths} | ${s.inventoryCompact ?? '—'} |`);
    }
}
P('');

// 3) 交接态
P('## 3. 阶段交接态（连跑独有：单独跑根本不存在这一面）');
P('');
P('| trial | 段 | 来自 | 背包零变化 | 背包增量 | 位置位移 | y 位移 | 维度切换 | 死亡累计 |');
P('|---|---|---|---|---|---|---|---|---|');
for (const t of run.trials) {
    for (const s of (t.splits?.segments ?? []).filter((x) => x.attempt > 0)) {
        const h = s.handoff ?? {};
        P(`| ${t.row.trial} | ${s.id} | ${h.fromSegment ?? '—'} | ${h.fromSegment == null ? '—' : (h.invUnchanged ? '是' : '**否**')} | ${h.invDelta ? '`' + JSON.stringify(h.invDelta) + '`' : '—'} | ${h.posDelta ?? '—'} | ${h.yDelta ?? '—'} | ${h.dimensionChanged ? `**是**(${h.prevDimension}→${s.dimensionStart})` : '否'} | ${s.deathsTotal} |`);
    }
}
P('');

// 4) 对照
P('## 4. 连跑分段 vs 单独跑同一 MISSION（手册 §5：必须同种子同口径）');
P('');
const resources = [...new Set(run.trials.flatMap((t) => (t.splits?.segments ?? []).map((s) => s.resource)).filter(Boolean))];
if (!resources.length) P('_本 run 没有分段数据_');
for (const res of resources) {
    const inRun = segSamples(run, res);
    const inRunFirst = stats(firstAttempt(inRun).map((s) => s.wallSec));
    const inRunOk = stats(inRun.filter((s) => s.status === 'SUCCESS').map((s) => s.wallSec));
    const ctrlAll = controlRuns.flatMap((c) => segSamples(c, res));
    const ctrlFirst = stats(ctrlAll.filter((s) => s.attempt === 1).map((s) => s.wallSec));
    const ctrlOk = stats(ctrlAll.filter((s) => s.status === 'SUCCESS').map((s) => s.wallSec));
    const baseRows = baselineRows.filter((r) => r.result?.resource === res
        && (!BASELINE_SEED || String(r.seed) === BASELINE_SEED)
        && r.result?.status === 'SUCCESS');
    const base = stats(baseRows.map((r) => sec(r.result.durationMs)));
    P(`### \`${res}\``);
    P('');
    P('| 口径 | n | median | mean | min | max | 样本 |');
    P('|---|---|---|---|---|---|---|');
    if (inRunFirst) P(`| **连跑·本段·首尝试** | ${inRunFirst.n} | **${inRunFirst.median}s** | ${inRunFirst.mean}s | ${inRunFirst.min}s | ${inRunFirst.max}s | ${inRunFirst.samples.join(', ')} |`);
    if (inRunOk && inRunOk.n !== inRunFirst?.n) P(`| 连跑·本段·成功局 | ${inRunOk.n} | ${inRunOk.median}s | ${inRunOk.mean}s | ${inRunOk.min}s | ${inRunOk.max}s | ${inRunOk.samples.join(', ')} |`);
    if (ctrlFirst) P(`| 单独跑·同 stage 对照·首尝试 | ${ctrlFirst.n} | ${ctrlFirst.median}s | ${ctrlFirst.mean}s | ${ctrlFirst.min}s | ${ctrlFirst.max}s | ${ctrlFirst.samples.join(', ')} |`);
    if (ctrlOk && ctrlOk.n !== ctrlFirst?.n) P(`| 单独跑·同 stage 对照·成功局 | ${ctrlOk.n} | ${ctrlOk.median}s | ${ctrlOk.mean}s | ${ctrlOk.min}s | ${ctrlOk.max}s | ${ctrlOk.samples.join(', ')} |`);
    if (base) P(`| 单独跑·历史 bench${BASELINE_SEED ? `（seed ${BASELINE_SEED}）` : ''} | ${base.n} | ${base.median}s | ${base.mean}s | ${base.min}s | ${base.max}s | ${base.samples.join(', ')} |`);
    if (!ctrlFirst && !base) P('| 单独跑·（无对照数据） | 0 | — | — | — | — | — |');
    const cmpBase = ctrlOk ?? ctrlFirst;
    if (inRunFirst && cmpBase) {
        const d = +(inRunFirst.median - cmpBase.median).toFixed(1);
        const pct = +((d / cmpBase.median) * 100).toFixed(1);
        P('');
        P(`→ 连跑首尝试比${ctrlOk && !ctrlFirst ? '独跑成功局' : '独跑首尝试'} **${d >= 0 ? '+' : ''}${d}s（${pct >= 0 ? '+' : ''}${pct}%）**`
            + (ctrlFirst && ctrlOk && ctrlFirst.n !== ctrlOk.n ? `；注：独跑首尝试有未成功局（见样本与成功局行）` : ''));
    } else if (inRunFirst && base) {
        const d = +(inRunFirst.median - base.median).toFixed(1);
        const pct = +((d / base.median) * 100).toFixed(1);
        P('');
        P(`→ 连跑比历史独跑 **${d >= 0 ? '+' : ''}${d}s（${pct >= 0 ? '+' : ''}${pct}%）**`);
    }
    P('');
}

// 5) 数据完整性
P('## 5. 数据完整性自检');
P('');
let missing = 0, ticked = 0, tickBad = 0;
for (const t of run.trials) {
    const s = t.splits;
    if (!s) { missing++; continue; }
    for (const seg of (s.segments ?? []).filter((x) => x.attempt > 0)) {
        if (seg.tick?.ok) ticked++; else if (seg.tick?.delta === 0 || seg.tick?.delta == null) tickBad++;
    }
}
P(`- summary 行 ${run.rows.length} · splits.json 齐 ${run.trials.length - missing}/${run.trials.length}${missing ? `（**缺 ${missing}**）` : ''}`);
P(`- 分段游戏刻可用 ${ticked} 局段 · 不可用/异常 ${tickBad} 段`);
const notRun = run.trials.flatMap((t) => (t.splits?.segments ?? []).filter((s) => s.status === 'NOT_RUN'));
P(`- NOT_RUN 占位段 ${notRun.length} 条（策略终止时按段数补齐，保证台账不丢段）`);
P('');

const out = L.join('\n');
fs.writeFileSync(path.join(run.dir, 'report.md'), out);
console.log(`\n${out}\n\n→ ${path.join(run.dir, 'report.md')}`);
