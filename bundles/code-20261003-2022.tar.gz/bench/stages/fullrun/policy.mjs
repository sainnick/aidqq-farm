// policy.mjs — MC-FULLRUN-01：段失败策略（纯函数，可离线自测）
//
// 任务单 §1.3：某个 MISSION 失败时按策略处理（重试 N 次 / 跳过 / 终止），做成参数；失败也要落盘。
// 这里把它抽成**纯状态机**，好处有两个：
//   1) fullrun_bot 只管调 nextAction，不掺判定逻辑；
//   2) 三种策略可以在不开服、不烧机器时间的条件下被 selftest.mjs 穷举验证（手册 §4.2：
//      底层原语用微基准测，别每次都拿整局机器时间去验一个 3 行判定）。
//
// 语义（刻意做成"没有隐式兜底"，每一步都必须显式返回）：
//   abort        段失败 → 立刻终止整局，剩余段按 NOT_RUN/abort 落盘
//   skip         段失败 → 记完整失败数据，继续下一段（整局 outcome=PARTIAL）
//   retry:N      段失败 → 同一世界、零 kit、同一段重试至多 N 次；用尽后按 abort 终止
//                （不自动降级成 skip：跳过会让"通关局"名不副实，调用方要 skip 请显式写 skip）

/**
 * @param {string} spec --on-fail 的原值：abort | skip | retry:N
 */
export function parsePolicy(spec) {
    const raw = String(spec ?? 'abort').trim() || 'abort';
    if (raw === 'abort') return { kind: 'abort', n: 0, raw };
    if (raw === 'skip') return { kind: 'skip', n: 0, raw };
    const m = /^retry:(\d+)$/.exec(raw);
    if (m) {
        const n = parseInt(m[1], 10);
        if (!(n >= 1)) throw new Error(`POLICY_BAD_RETRY: retry 次数必须 ≥1（${raw}）`);
        return { kind: 'retry', n, raw };
    }
    throw new Error(`POLICY_BAD: 无法识别的 --on-fail=${raw}（用 abort | skip | retry:N）`);
}

export function describePolicy(p) {
    return p.kind === 'retry' ? `retry:${p.n}（用尽后 abort）` : p.kind;
}

/**
 * 一段跑完之后的唯一决策点。
 * @param {{kind:string,n:number}} policy
 * @param {string} status   段终态（TaskStatus：SUCCESS / FAILURE / ABORTED / TIMEOUT …）
 * @param {number} attempt  该段是第几次尝试（1 起）
 * @returns {'continue'|'retry'|'abort'} 'retry' 仅在还有重试预算时返回
 */
export function nextAction(policy, status, attempt) {
    if (status === 'SUCCESS') return 'continue';
    switch (policy.kind) {
        case 'abort': return 'abort';
        case 'skip': return 'continue';
        case 'retry': return attempt <= policy.n ? 'retry' : 'abort';
        default: throw new Error(`POLICY_UNKNOWN_KIND: ${policy.kind}`);
    }
}

/** 终止后剩余段的占位记录（保证台账段数齐全，"失败也要落盘"） */
export function notRunStub(src, fromIndex, reason) {
    const out = [];
    for (let i = fromIndex; i < src.missions.length; i++) {
        const m = src.missions[i];
        out.push({
            index: m.index, id: m.id, raw: m.raw, resource: m.resource,
            attempt: 0, status: 'NOT_RUN', failReason: null, skipReason: reason,
            wallMs: 0, wallSec: 0, tick: null, inventory: null, position: null,
            dimension: null, deaths: 0, deathsTotal: 0, carryIn: null, metrics: null,
        });
    }
    return out;
}
