# bench/stages/fullrun — MC-FULLRUN-01 整局编排器（开发线 C）

**一个世界、一个背包、一个 bot 进程里连续跑完一串 MISSION**，并输出每段的分段数据。
现有 bench（basic-iron / basic-bootstrap）的口径是「一个 trial = 一个 fresh world + 一个 MISSION」，
所以阶段交接类问题（背包残留、人在地下还是地面、死亡后从哪续）在旧口径下**结构上测不到**。

## 文件

| 文件 | 作用 |
|---|---|
| `run_bench.mjs` | runner：**只用泳道 C**（25568/25578）。装配 C 泳道 → preflight → 逐局 fresh world → 起服 → 拉 bot → 看门狗 → 停服 → 收工 cleanup |
| `fullrun_bot.mjs` | 单进程连跑 MISSION 序列的执行机器人；写 `splits.json` / `splits.md` / `result.json` / `probe.jsonl` / `telemetry.jsonl` |
| `mission_source.mjs` | 可插拔 MISSION 源：`script:<x.json>` / `<x.json>` / `inline:a;b` / `decision`（预留接口，本单不接 LLM） |
| `policy.mjs` | 段失败策略纯状态机：`abort` / `skip` / `retry:N`（用尽后 abort） |
| `summarize.mjs` | 跨局汇总 + **连跑分段 vs 单独跑**对照，产出 `runs/<stamp>/report.md` |
| `selftest.mjs` | 离线自测（源解析 + 策略状态机），秒级，不开服不占端口 |
| `missions/seq-bucket-flint.json` | 首个序列：`obtain 1 bucket` → `obtain 1 flint_and_steel` |

## 常用命令（Node 必须用 20：`.runtime/node-v20.20.2-win-x64/node.exe`）

```powershell
$N = '.\.runtime\node-v20.20.2-win-x64\node.exe'

# 0) 离线自测 + 只看计划（都不开服）
& $N bench\stages\fullrun\run_bench.mjs --selftest
& $N bench\stages\fullrun\run_bench.mjs --plan-only --stamp PLAN --seed -8839485814800629942 --trials 3

# 1) 主种子 ×3 连跑（零 kit、peaceful、泳道 C）
& $N bench\stages\fullrun\run_bench.mjs --stamp FR1 `
  --seed -8839485814800629942 --trials 3 `
  --missions script:bench\stages\fullrun\missions\seq-bucket-flint.json --on-fail retry:1

# 2) fresh 种子各 1 次
& $N bench\stages\fullrun\run_bench.mjs --stamp FR2 --seeds <seedA>,<seedB> --trials 2 --on-fail retry:1

# 3) 单独跑对照（同一 runner / 同一泳道 / 同时段窗口，1 段序列）
& $N bench\stages\fullrun\run_bench.mjs --stamp FRC1 --seed <seed> --missions inline:"obtain 1 bucket" --on-fail retry:1
& $N bench\stages\fullrun\run_bench.mjs --stamp FRC2 --seed <seed> --missions inline:"obtain 1 flint_and_steel" --on-fail retry:1

# 4) 汇总（带对照）
& $N bench\stages\fullrun\summarize.mjs --run FR1 --control FRC1,FRC2
```

## 分段数据（`runs/<stamp>/trial_XX/splits.json`）

每段一条：`wallMs` / `tick{age 增量, TPS 估计}` / `inventory`（段末全量快照）/ `position` + `dimension` /
`deaths`（段内 + 全局）/ `handoff`（与上一段末态的差：位置、维度、背包增量）/ `metrics`（任务层计数器）/ `taskTree`。
失败段**完整落盘**；策略终止时剩余段按 `NOT_RUN` 占位，保证台账段数不丢。
人看的表在 `splits.md`，跨局汇总与对照在 `runs/<stamp>/report.md`。

## 硬约束

- **任务层只读引用**：从 `MC_MINDCRAFT_ROOT`（默认 `D:/AI斗蛐蛐/mindcraft`）加载，**不改 `mindcraft/` 下任何文件**。
- **只用泳道 C**（手册 §9）：不碰 A/B 的端口、目录和 world；内存护栏不放行就排队，不降阈值。
- 零 kit、零 LLM、零 RCON（命令一律走服务器 stdin 控制台，手册 §2）。
- `_lib/` 只读引用（§9：只能新增文件，改已有文件要先报告）——本 stage 没有改它。
