// selftest.mjs — MC-FULLRUN-01 离线自测（不开服、不占端口、不动 mindcraft/）
//
// 验两件纯逻辑的事，秒级完成：
//   1) MISSION 源解析（script / inline / 裸路径 / decision 预留 / 各种坏输入）
//   2) 段失败策略状态机（abort / skip / retry:N × 成功/失败/重试用尽），
//      以及终止后 NOT_RUN 占位（台账段数必须齐全）
//
// 用法：node bench/stages/fullrun/selftest.mjs
// 退出码 0 = 全过；非 0 = 有断言失败（run_bench --selftest 与收工核验都会用它）

import fs from 'fs';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { loadMissionSource, describeSource, MissionSourceError } from './mission_source.mjs';
import { parsePolicy, describePolicy, nextAction, notRunStub } from './policy.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));

let pass = 0, fail = 0;
const failures = [];
function check(name, cond, extra = '') {
    if (cond) { pass++; return true; }
    fail++; failures.push(`${name}${extra ? ` — ${extra}` : ''}`);
    return false;
}
async function checkRejects(name, fn, code) {
    try { await fn(); check(name, false, '本该抛错却正常返回'); }
    catch (e) {
        const got = e?.code ?? String(e).slice(0, 40);
        check(name, code ? got === code : true, `期望 code=${code} 实得 ${got}: ${String(e).slice(0, 100)}`);
    }
}

// ---------- 1) MISSION 源 ----------
const seqPath = path.join(HERE, 'missions', 'seq-bucket-flint.json');
const seq = await loadMissionSource(`script:${seqPath}`);
check('script 源读到 2 段', seq.missions.length === 2, `实得 ${seq.missions.length}`);
check('script 源 id', seq.id === 'seq-bucket-flint', seq.id);
check('段 1 资源 = bucket', seq.missions[0]?.resource === 'bucket', JSON.stringify(seq.missions[0]));
check('段 1 计数 = 1', seq.missions[0]?.count === 1);
check('段 2 资源 = flint_and_steel', seq.missions[1]?.resource === 'flint_and_steel');
check('段 2 计数 = 1', seq.missions[1]?.count === 1);
check('describeSource 非空', describeSource(seq).includes('obtain 1 bucket'));

const bare = await loadMissionSource(seqPath); // 裸 .json 路径
check('裸 .json 路径等价于 script:', bare.missions.length === seq.missions.length);
const inl = await loadMissionSource('inline:obtain 1 bucket; obtain 1 flint_and_steel');
check('inline 源 2 段', inl.missions.length === 2, `实得 ${inl.missions.length}`);
check('inline 段 id 递增', inl.missions[1]?.id === 'm2');
const n16 = await loadMissionSource('inline:obtain 16 stone');
check('显式计数透传', n16.missions[0]?.count === 16);
const noCount = await loadMissionSource('inline:obtain stone');
check('省略计数 → count=null（交任务层 DEFAULT_COUNT）', noCount.missions[0]?.count === null);
const arrDoc = path.join(os.tmpdir(), `fullrun_selftest_arr_${process.pid}.json`);
fs.writeFileSync(arrDoc, JSON.stringify(['obtain 1 bucket', 'obtain 1 flint_and_steel']));
check('数组形状 JSON 也能吃', (await loadMissionSource(arrDoc)).missions.length === 2);

await checkRejects('空 spec 拒绝', () => loadMissionSource(''), 'MISSION_SOURCE_EMPTY');
await checkRejects('decision 预留未实现', () => loadMissionSource('decision'), 'MISSION_SOURCE_NOT_IMPLEMENTED');
await checkRejects('不存在的文件', () => loadMissionSource('script:no_such_seq.json'), 'MISSION_SOURCE_NO_FILE');
await checkRejects('坏 JSON', async () => {
    const p = path.join(os.tmpdir(), `fullrun_selftest_bad_${process.pid}.json`);
    fs.writeFileSync(p, '{oops');
    try { await loadMissionSource(p); } finally { fs.rmSync(p, { force: true }); }
}, 'MISSION_SOURCE_BAD_JSON');
await checkRejects('空序列', async () => {
    const p = path.join(os.tmpdir(), `fullrun_selftest_empty_${process.pid}.json`);
    fs.writeFileSync(p, JSON.stringify({ missions: [] }));
    try { await loadMissionSource(p); } finally { fs.rmSync(p, { force: true }); }
}, 'MISSION_SOURCE_EMPTY_LIST');
await checkRejects('非 obtain 文本被挡在起服前', async () => {
    const p = path.join(os.tmpdir(), `fullrun_selftest_enter_${process.pid}.json`);
    fs.writeFileSync(p, JSON.stringify({ missions: ['obtain 1 bucket', 'enter nether'] }));
    try { await loadMissionSource(p); } finally { fs.rmSync(p, { force: true }); }
}, 'MISSION_SOURCE_BAD_TEXT');
await checkRejects('无法识别的源', () => loadMissionSource('豆包现场发挥'), 'MISSION_SOURCE_BAD_SPEC');
try { fs.rmSync(arrDoc, { force: true }); } catch { /* 忽略 */ }

// ---------- 2) 策略状态机 ----------
check('abort 解析', parsePolicy('abort').kind === 'abort');
check('skip 解析', parsePolicy('skip').kind === 'skip');
check('retry:2 解析', parsePolicy('retry:2').n === 2);
check('默认 abort', parsePolicy(undefined).kind === 'abort');
for (const bad of ['nope', 'retry:0', 'retry:x', 'RETRY:2']) {
    let threw = false;
    try { parsePolicy(bad); } catch { threw = true; }
    check(`坏策略被拒: ${bad}`, threw);
}
check('describePolicy', describePolicy(parsePolicy('retry:3')) === 'retry:3（用尽后 abort）');

const pAbort = parsePolicy('abort'), pSkip = parsePolicy('skip'), pR2 = parsePolicy('retry:2');
check('成功→继续（三种策略一致）',
    nextAction(pAbort, 'SUCCESS', 1) === 'continue' &&
    nextAction(pSkip, 'SUCCESS', 1) === 'continue' &&
    nextAction(pR2, 'SUCCESS', 1) === 'continue');
check('abort: 失败→终止', nextAction(pAbort, 'FAILURE', 1) === 'abort');
check('abort: TIMEOUT 也终止', nextAction(pAbort, 'TIMEOUT', 1) === 'abort');
check('skip: 失败→继续', nextAction(pSkip, 'FAILURE', 1) === 'continue');
check('retry: 第 1 次失败→重试', nextAction(pR2, 'FAILURE', 1) === 'retry');
check('retry: 第 2 次失败→重试（预算内）', nextAction(pR2, 'FAILURE', 2) === 'retry');
check('retry: 预算用尽→终止（不偷降级成 skip）', nextAction(pR2, 'FAILURE', 3) === 'abort');
check('retry: 重试成功→继续', nextAction(pR2, 'SUCCESS', 2) === 'continue');

const stubs = notRunStub(seq, 1, 'abort_by_policy');
check('终止后剩余段占位齐全（台账段数不丢）', stubs.length === 1 && stubs[0].id === 'm2');
check('占位段标 NOT_RUN + 原因', stubs[0].status === 'NOT_RUN' && stubs[0].skipReason === 'abort_by_policy');
check('占位段保留 MISSION 原文', stubs[0].raw === 'obtain 1 flint_and_steel');
check('从 0 开始则全部占位', notRunStub(seq, 0, 'x').length === 2);
check('越界则无占位', notRunStub(seq, 2, 'x').length === 0);

// ---------- 输出 ----------
for (const f of failures) console.log(`  ✗ ${f}`);
console.log(`[fullrun selftest] ${pass} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
