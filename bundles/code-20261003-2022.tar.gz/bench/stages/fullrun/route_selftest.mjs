// route_selftest.mjs — MC-ROUTE-02 编排器 route 模式的离线自测（不开服、不占端口）
//
// 验四组纯逻辑，秒级完成：
//   1. **草稿闸门**：frozenAt=null 默认拒；--allow-draft 才放行（SCHEMA §3：草稿只能开发局）
//   2. **冻结态 sha**：有旁挂 .sha256 时一致才放行；不一致拒
//   3. **run 中被改 → 整局作废**：开局记 sha，改 1 字节后 verify() 必须报 VOID
//      （任务单 §4 验收线："把 route 改 1 字节后，开局即判'该局作废'"）
//   4. **形态自检**：`do station <id>` 里不许出现坐标；station 区 radius<16 / center 未对齐
//      / lookFor 为空 / schema 不对，一律拒
//
// 用法：node bench/stages/fullrun/route_selftest.mjs
// 退出码 0 = 全过

import fs from 'fs';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { RouteGuard, readRouteFile, checkRouteIntegrity, sha256Of, routeSha256, assertStationOnlyMissions } from './route_guard.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const TMP = path.join(os.tmpdir(), `route_selftest_${process.pid}`);
fs.mkdirSync(TMP, { recursive: true });

let pass = 0, fail = 0;
const failures = [];
const check = (name, cond, extra = '') => { if (cond) pass++; else { fail++; failures.push(`${name}${extra ? ` — ${extra}` : ''}`); } };

const VALID = {
    schema: 'aidqq-route/1', seed: '-123', mcVersion: '1.16.1',
    frozenAt: null, sha256File: null, generatedAt: '2026-10-01T00:00:00.000Z',
    stations: [
        { id: 'S0_iron', seq: 1, kind: 'iron_source', dim: 'overworld', station: { center: [0, 0], yHint: 'underground', radius: 32, lookFor: ['iron_ore'] }, scout: { points: [{ what: 'x', xyz: [1, 2, 3] }], verify: { status: 'REAL' } }, fallback: [] },
        { id: 'S1_portal', seq: 2, kind: 'ruined_portal', dim: 'overworld', station: { center: [176, 352], yHint: 'surface', radius: 24, lookFor: ['crying_obsidian'] }, scout: { points: [], verify: { status: 'REAL' } }, fallback: ['S1b_lava_pool'] },
    ],
};
const write = (name, obj) => { const p = path.join(TMP, name); fs.writeFileSync(p, JSON.stringify(obj, null, 2)); return p; };
const draft = write('draft.json', VALID);

// ---- 1) 草稿闸门 ----
const d0 = checkRouteIntegrity(draft);
check('草稿默认被拒', d0.ok === false && /ROUTE_IS_DRAFT/.test(d0.reason ?? ''), `ok=${d0.ok} reason=${d0.reason}`);
const d1 = checkRouteIntegrity(draft, { allowDraft: true });
check('草稿 + allowDraft 放行', d1.ok === true, d1.reason ?? '');
check('草稿放行时 sha 已记录', /^[0-9a-f]{64}$/.test(d0.sha256 ?? ''), d0.sha256);
const d2 = checkRouteIntegrity(draft, { requireFrozen: true });
check('草稿 + requireFrozen 仍拒', d2.ok === false && /ROUTE_IS_DRAFT/.test(d2.reason ?? ''), d2.reason);

// ---- 2) 冻结态 sha ----
// ⚠ sidecar 必须按 **SCHEMA §4 v1.1 规范口径**生成（2026-10-02 夜定案）：用共享的 `routeSha256`，
//   不能再用 `sha256Of(文件原文)` —— 后者是原始字节哈希，对 CRLF/LF 敏感，跨机器必然对不上。
//   本单只改"造 sidecar 的方式"，判据（一致放行 / 不符拒）一个字没动。
const frozen = write('frozen.json', { ...VALID, frozenAt: '2026-10-02T00:00:00.000Z', sha256File: 'frozen.sha256' });
fs.writeFileSync(path.join(TMP, 'frozen.sha256'), `${routeSha256(fs.readFileSync(frozen, 'utf8'))}  frozen.json\n`);
const f0 = checkRouteIntegrity(frozen, { requireFrozen: true });
check('冻结态 + sha 一致 → 放行', f0.ok === true, f0.reason ?? '');
check('冻结态 frozen=true', f0.frozen === true && f0.frozenAt === '2026-10-02T00:00:00.000Z');
fs.writeFileSync(path.join(TMP, 'frozen.sha256'), `${'0'.repeat(64)}  frozen.json\n`);
const f1 = checkRouteIntegrity(frozen, { requireFrozen: true });
check('冻结态 + sha 不符 → 拒', f1.ok === false && /ROUTE_HASH_MISMATCH/.test(f1.reason ?? ''), f1.reason);

// ---- 3) run 中改 1 字节 → 作废（任务单验收线） ----
{
    const p = write('midrun.json', VALID);
    const g = new RouteGuard(p, { allowDraft: true });
    check('开局守卫通过', g.started.ok === true, g.started.reason ?? '');
    check('开局未作废', g.voided === false);
    const v0 = g.verify('before:S0_iron');
    check('未改动时复验 OK', v0.ok === true && v0.same === true, JSON.stringify(v0));
    // 改 1 字节（radius 32 → 33：只动一个字符，且仍是合法 JSON）
    const doc = JSON.parse(fs.readFileSync(p, 'utf8'));
    doc.stations[0].station.radius = 33;
    fs.writeFileSync(p, JSON.stringify(doc, null, 2));
    const v1 = g.verify('before:S1_portal');
    check('改 1 字节后复验判作废', v1.ok === false && v1.changed === true, JSON.stringify(v1));
    check('作废原因指明 sha 变化', /ROUTE_CHANGED_MID_RUN/.test(v1.reason ?? ''), v1.reason);
    check('守卫进入 voided 态', g.voided === true);
    const rep = g.report();
    check('report 记录 voided + 原因', rep.voided === true && /ROUTE_CHANGED_MID_RUN/.test(rep.voidReason ?? ''), rep.voidReason);
    check('复验次数记账', rep.checks.length === 3, `checks=${rep.checks.length}`);
}

// ---- 3b) 冻结态下改文件也必须作废 ----
{
    // 先把 sidecar 恢复成正确值（上一节故意写过 0 用来测不符）；同 §2，用规范口径
    fs.writeFileSync(path.join(TMP, 'frozen.sha256'), `${routeSha256(fs.readFileSync(path.join(TMP, 'frozen.json'), 'utf8'))}  frozen.json\n`);
    const p = path.join(TMP, 'frozen.json');
    const g = new RouteGuard(p, { requireFrozen: true });
    check('冻结态开局通过', g.started.ok === true, g.started.reason ?? '');
    const doc = JSON.parse(fs.readFileSync(p, 'utf8'));
    doc.stations[0].station.radius = 40;
    fs.writeFileSync(p, JSON.stringify(doc, null, 2));
    const v = g.verify('before:S0_iron');
    check('冻结态改文件 → 作废（sha 双失配）', v.ok === false, JSON.stringify(v));
}

// ---- 4) 形态自检 ----
check('合法站序列通过形态自检', assertStationOnlyMissions([{ raw: 'do station S1_portal' }, { raw: 'do station S0_iron' }]) === true);
for (const bad of ['obtain 1 bucket', 'do station 176 352', 'goto station 123,45,67', 'do station S1; tp 176 352 60']) {
    let threw = false;
    try { assertStationOnlyMissions([{ raw: bad }]); } catch { threw = true; }
    check(`含坐标/非法形态被拒: ${JSON.stringify(bad)}`, threw);
}
const badRadius = write('bad_radius.json', { ...VALID, stations: [{ ...VALID.stations[0], station: { ...VALID.stations[0].station, radius: 8 } }] });
check('radius<16 被拒（SCHEMA 硬下限）', checkRouteIntegrity(badRadius, { allowDraft: true }).ok === false);
const badAlign = write('bad_align.json', { ...VALID, stations: [{ ...VALID.stations[0], station: { ...VALID.stations[0].station, center: [3, 5] } }] });
check('center 未对齐 8 格被拒', checkRouteIntegrity(badAlign, { allowDraft: true }).ok === false);
const noLook = write('no_look.json', { ...VALID, stations: [{ ...VALID.stations[0], station: { ...VALID.stations[0].station, lookFor: [] } }] });
check('lookFor 为空被拒（运行时无法做到达确认）', checkRouteIntegrity(noLook, { allowDraft: true }).ok === false);
const badSchema = write('bad_schema.json', { ...VALID, schema: 'aidqq-route/2' });
check('schema 不对被拒', checkRouteIntegrity(badSchema, { allowDraft: true }).ok === false);
const dupSeq = write('dup_seq.json', { ...VALID, stations: [{ ...VALID.stations[0], seq: 1 }, { ...VALID.stations[1], seq: 1 }] });
check('seq 重复被拒', checkRouteIntegrity(dupSeq, { allowDraft: true }).ok === false);
const zeroSeq = write('zero_seq.json', { ...VALID, stations: [{ ...VALID.stations[0], seq: 0 }, { ...VALID.stations[1], seq: 1 }] });
check('seq 不从 1 起被拒', checkRouteIntegrity(zeroSeq, { allowDraft: true }).ok === false);

// ---- 5) scout 不进 station：编排器读 route 时应当只取 id/seq ----
{
    const r = readRouteFile(draft);
    const ids = r.doc.stations.map((s) => s.id);
    check('station id 可读', ids.length === 2 && ids[0] === 'S0_iron');
    const scoutLeak = JSON.stringify(r.doc.stations.map((s) => s.station)).includes('xyz');
    check('station 区不含 scout 的精确坐标', !scoutLeak);
}

// ---- 输出 ----
for (const f of failures) console.log(`  ✗ ${f}`);
console.log(`[route selftest] ${pass} passed, ${fail} failed`);
try { fs.rmSync(TMP, { recursive: true, force: true }); } catch { /* 临时目录，忽略 */ }
process.exit(fail === 0 ? 0 : 1);
