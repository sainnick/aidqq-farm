﻿// mission_source.mjs — MC-FULLRUN-01 + MC-ROUTE-02：MISSION 源（可插拔）
//
// 编排器不硬编码序列，只认「源」。本单只实现 script（JSON 列表）+ inline（冒烟用分号串），
// decision（决策层，以后接豆包）**只留接口、本单不实现**——手册 §7：豆包只下 MISSION，
// 接线是以后的事，这里保持可插拔形状即可（不引入任何 LLM/百炼调用，手册 §7 + 任务单禁区）。
//
// MC-ROUTE-02 追加 **route 驱动模式**（`route:<path.json>`）：
//   按站序生成 `do station <id>` 序列。**只读 station 的 id/seq，不读 scout**
//   （SCHEMA §1：精确坐标只给审阅与审计，任务层只能看到站级数据），
//   并且从形态上自检「序列里没有坐标」（手册 §7：坐标不得进入 MISSION）。
//   route 文件的 sha256 / 草稿闸门 / 作废判定在 route_guard.mjs（编排器侧）。
//
// 用法（--missions）：
//   script:<path.json>   或  <path.json>     读 JSON：{ id?, label?, missions: ["obtain 1 bucket", ...] }
//   inline:a;b;c                              分号分隔（冒烟/临时序列，不落盘）
//   route:<path.json>                          route 驱动：按站序展开成 do station <id>
//   decision                                    → 抛 MISSION_SOURCE_NOT_IMPLEMENTED（预留接口）
//
// 校验分两层（手册 §5：不要拿机器时间去跑一个已知会失败的配置）：
//   1) 本文件做**轻量**形状校验（missions 是非空字符串数组、文本形如 obtain N item）→ 起服前失败；
//   2) fullrun_bot / run_bench 用任务层真 parseMission 做权威校验（资源表 + 计数范围）。

import fs from 'fs';
import path from 'path';

export const RESERVED_KINDS = ['decision'];

const OBTAIN_RE = /^obtain\s+(?:(\d+)\s+)?([a-z_]+)$/i;
const ROUTE_RE = /^do station ([A-Za-z0-9_]{1,64})$/;

export class MissionSourceError extends Error {
    constructor(code, msg) { super(`${code}: ${msg}`); this.code = code; }
}

/**
 * @param {string} spec --missions 的原值
 * @param {{ cwd?: string, env?: Record<string,string|undefined> }} [opt]
 * @returns {Promise<{kind:string, id:string, label:string, origin:string, missions:Array<{index:number,id:string,raw:string,resource:string|null,count:number|null}>}>}
 */
export async function loadMissionSource(spec, opt = {}) {
    const raw = String(spec ?? '').trim();
    if (!raw) {
        throw new MissionSourceError('MISSION_SOURCE_EMPTY',
            '--missions 未给。例：--missions script:missions/seq-bucket-flint.json');
    }

    const kind = raw.startsWith('script:') ? 'script'
        : raw.startsWith('inline:') ? 'inline'
        : raw.startsWith('route:') ? 'route'
        : RESERVED_KINDS.includes(raw) ? 'decision' : null;

    if (kind === 'decision') {
        throw new MissionSourceError('MISSION_SOURCE_NOT_IMPLEMENTED',
            'decision 源是给以后豆包决策层留的接口，本单不接 LLM（手册 §7 / 任务单禁区）。先用 script: / inline: / route:。');
    }

    // ---- MC-ROUTE-02：route 驱动模式 ----
    // ⚠ 下面这组变量必须在 route 分支**之前**声明：route 分支要写 `origin`，
    //   而 `let origin` 若声明在其后就是 TDZ（实测 "Cannot access 'origin' before initialization"）。
    let list;
    let id = 'inline';
    let label = null;
    let origin = raw;
    if (kind === 'route') {
        const file = path.resolve(opt.cwd ?? process.cwd(), raw.slice('route:'.length).trim());
        origin = file;
        if (!fs.existsSync(file)) throw new MissionSourceError('MISSION_SOURCE_NO_FILE', `找不到 route 文件 ${file}`);
        let doc;
        try { doc = JSON.parse(fs.readFileSync(file, 'utf8')); }
        catch (e) { throw new MissionSourceError('MISSION_SOURCE_BAD_JSON', `${file} 解析失败: ${String(e).slice(0, 120)}`); }
        if (doc.schema !== 'aidqq-route/1') {
            throw new MissionSourceError('ROUTE_SCHEMA_UNEXPECTED', `schema=${doc.schema}（期望 aidqq-route/1）`);
        }
        const sts = Array.isArray(doc.stations) ? [...doc.stations] : [];
        if (!sts.length) throw new MissionSourceError('ROUTE_NO_STATIONS', `${file} 没有 stations`);
        sts.sort((a, b) => (a.seq ?? 0) - (b.seq ?? 0));
        // ⚠ 只取 id/seq —— scout（精确坐标）**在这里就被丢掉**，编排器不读也不往下传
        //   （SCHEMA §1：scout 只给人审阅与审计；手册 §7：坐标不进 MISSION）。
        const missions = sts.map((s, i) => {
            const id = String(s.id ?? '');
            if (!ROUTE_RE.test(`do station ${id}`)) {
                throw new MissionSourceError('ROUTE_STATION_ID_BAD', `第 ${i + 1} 站 id 不合法：${JSON.stringify(id)}`);
            }
            return { index: i, id, raw: `do station ${id}`, resource: null, count: null, dim: s.dim ?? null, kind: s.kind ?? null };
        });
        return {
            kind: 'route', id: `route:${path.basename(file)}`,
            label: `route 驱动：${doc.seed}（${missions.length} 站，frozenAt=${doc.frozenAt ?? 'null(草稿)'}）`,
            origin, missions,
            route: { seed: doc.seed, frozenAt: doc.frozenAt ?? null, mcVersion: doc.mcVersion, stations: sts.map((s) => ({ id: s.id, seq: s.seq, kind: s.kind, dim: s.dim })) },
        };
    }
    if (kind === null && !raw.toLowerCase().endsWith('.json')) {
        throw new MissionSourceError('MISSION_SOURCE_BAD_SPEC',
            `无法识别的源：${raw.slice(0, 80)}（支持 script:<x.json> / <x.json> / inline:a;b / route:<x.json> / decision）`);
    }

    if (kind === 'script') {
        const file = path.resolve(opt.cwd ?? process.cwd(), raw.slice('script:'.length).trim());
        origin = file;
        if (!fs.existsSync(file)) throw new MissionSourceError('MISSION_SOURCE_NO_FILE', `找不到序列文件 ${file}`);
        let doc;
        try { doc = JSON.parse(fs.readFileSync(file, 'utf8')); }
        catch (e) { throw new MissionSourceError('MISSION_SOURCE_BAD_JSON', `${file} 解析失败: ${String(e).slice(0, 120)}`); }
        const arr = Array.isArray(doc) ? doc : doc?.missions;
        if (!Array.isArray(arr)) {
            throw new MissionSourceError('MISSION_SOURCE_BAD_SHAPE', `${file} 需要 {missions:[...]} 或直接是数组`);
        }
        list = arr;
        id = (Array.isArray(doc) ? null : doc.id) || path.basename(file).replace(/\.json$/i, '');
        label = (Array.isArray(doc) ? null : doc.label) || null;
    } else {
        const fileish = kind === null ? raw : null;
        if (fileish) { // 裸 .json 路径
            const file = path.resolve(opt.cwd ?? process.cwd(), fileish);
            origin = file;
            if (!fs.existsSync(file)) throw new MissionSourceError('MISSION_SOURCE_NO_FILE', `找不到序列文件 ${file}`);
            let doc;
            try { doc = JSON.parse(fs.readFileSync(file, 'utf8')); }
            catch (e) { throw new MissionSourceError('MISSION_SOURCE_BAD_JSON', `${file} 解析失败: ${String(e).slice(0, 120)}`); }
            const arr = Array.isArray(doc) ? doc : doc?.missions;
            if (!Array.isArray(arr)) throw new MissionSourceError('MISSION_SOURCE_BAD_SHAPE', `${file} 需要 {missions:[...]}`);
            list = arr;
            id = (Array.isArray(doc) ? null : doc.id) || path.basename(file).replace(/\.json$/i, '');
            label = (Array.isArray(doc) ? null : doc.label) || null;
        } else {
            list = raw.slice('inline:'.length).split(';').map((s) => s.trim()).filter(Boolean);
            label = `inline: ${list.join(' → ')}`;
        }
    }

    if (!list.length) throw new MissionSourceError('MISSION_SOURCE_EMPTY_LIST', `序列为空（${origin}）`);

    const missions = list.map((m, i) => {
        const text = typeof m === 'string' ? m : String(m?.raw ?? m?.mission ?? '').trim();
        if (!text) throw new MissionSourceError('MISSION_SOURCE_BAD_ENTRY', `第 ${i + 1} 段不是文本：${JSON.stringify(m).slice(0, 80)}`);
        const hit = OBTAIN_RE.exec(text.trim());
        if (!hit) {
            // 权威解析在任务层（parseMission），这里只挡明显不合法，省一次起服
            throw new MissionSourceError('MISSION_SOURCE_BAD_TEXT',
                `第 ${i + 1} 段文本不形如 "obtain [N] <item>"：${text.slice(0, 60)}`);
        }
        return {
            index: i,
            id: `m${i + 1}`,
            raw: text.trim(),
            resource: hit[2].toLowerCase(),
            count: hit[1] ? parseInt(hit[1], 10) : null, // null = 走任务层 DEFAULT_COUNT
        };
    });

    return { kind: kind ?? 'script', id, label: label ?? id, origin, missions };
}

/** 序列的人读摘要（写进 run_meta / 报告） */
export function describeSource(src) {
    return `${src.id} [${src.kind}] ${src.missions.length} 段: ${src.missions.map((m) => m.raw).join(' → ')}`;
}

