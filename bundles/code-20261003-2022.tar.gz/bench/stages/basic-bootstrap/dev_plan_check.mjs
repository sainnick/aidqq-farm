// dev_plan_check.mjs — MC-M1-TASK-02 离线开发验证（不启服务器）
//
// 验证四件事：
//   1. RecipeResolver.plan(wooden_pickaxe ×1, 空背包) 产出正确依赖步骤链
//   2. resolveSolvableTool：stone → wooden_pickaxe；oak_log（徒手可采）→ null
//   3. TaskStack 三守卫：cycle / depth / budget 全部拦截且返回结构化终态
//   4. parseMission 文本/JSON 双格式 + wood 别名
//
// 用法：node dev_plan_check.mjs [--version 1.16.1]（默认 1.21.1 = TASK-02 原口径；
// MC-M1-TASK-03 G1 用 1.16.1 registry 验证配方形状/delta/requiresTable 同构）

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const MINDCRAFT = path.join(ROOT, 'mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const md = require('minecraft-data');
const verIdx = process.argv.indexOf('--version');
const MC_VERSION = verIdx >= 0 ? process.argv[verIdx + 1] : '1.21.1';

const EXEC = (f) => pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec', f)).href;
const { RecipeResolver } = await import(EXEC('recipe_resolver.js'));
const { resolveSolvableTool } = await import(EXEC('tool_requirement.js'));
const { TaskStack } = await import(EXEC('task_stack.js'));
const { ExecTask } = await import(EXEC('task.js'));
const { parseMission } = await import(EXEC('mission.js'));

let failures = 0;
function check(name, cond, detail = '') {
    if (cond) console.log(`  ok  ${name}`);
    else { console.error(`FAIL  ${name} ${detail}`); failures++; }
}

// ---- 1. 配方规划 ----
console.log('== 1. recipe plan ==');
console.log(`   registry version: ${MC_VERSION}`);
const reg = md(MC_VERSION);
const resolver = new RecipeResolver(reg);
const plan = resolver.plan('wooden_pickaxe', 1, {}, [], {});
console.log('  ' + plan.steps.map((s) => s.kind === 'acquire' ? `Acquire(${s.resource}×${s.count})` : `Craft(${s.item}→${s.target}${s.station ? '@table' : ''})`).join('\n  '));
check('plan no error', !plan.error, plan.error);
check('plan has acquire(log)', plan.steps.some((s) => s.kind === 'acquire' && s.resource === 'log'));
check('plan has craft table before pickaxe', plan.steps.findIndex((s) => s.item === 'crafting_table') < plan.steps.findIndex((s) => s.item === 'wooden_pickaxe'));
check('plan has planks & sticks', plan.steps.some((s) => s.item?.endsWith('_planks')) && plan.steps.some((s) => s.item === 'stick'));
// 已有工作台 + 全材料时不该再排台子
const plan2 = resolver.plan('wooden_pickaxe', 1, { oak_log: 3, crafting_table: 1 }, [], {});
check('table in inventory → no table craft', !plan2.error && !plan2.steps.some((s) => s.item === 'crafting_table'), JSON.stringify(plan2.steps));
// 空库存规划铁链总量（乐观口径）：log 需求应为 3 左右（任务书对照：log ×3）
const logTotal = plan.steps.filter((s) => s.kind === 'acquire').reduce((a, s) => a + s.count, 0);
check('log need ≈3 (got ' + logTotal + ')', logTotal >= 2 && logTotal <= 4);
// cycle guard
const plan3 = resolver.plan('oak_planks', 4, { oak_log: 0 }, ['oak_planks'], {});
check('cycle guard', plan3.error === 'DEPENDENCY_CYCLE');
// 不支持的依赖（TASK-06 起 iron 链已支持、compass 随之可解；改用真不支持物品把守卫闸门测回来）
const plan4 = resolver.plan('heart_of_the_sea', 1, {}, [], {});
check('unsupported dep rejected', !!plan4.error, plan4.error);

// ---- 2. 工具解析 ----
console.log('== 2. tool requirement ==');
const fakeBot = { registry: reg };
const t1 = resolveSolvableTool(fakeBot, 'stone');
check('stone → wooden_pickaxe', t1 === 'wooden_pickaxe', t1);
const t2 = resolveSolvableTool(fakeBot, 'oak_log');
check('oak_log（徒手可采）→ null', t2 === null, t2);
const t3 = resolveSolvableTool(fakeBot, 'diamond_ore');
check('diamond_ore → iron_pickaxe（MC-M1-TASK-06 铁链接入后解锁）', t3 === 'iron_pickaxe', t3);

// ---- 3. TaskStack 守卫 ----
console.log('== 3. task stack guards ==');
function mockTask(label, behavior) {
    const t = new ExecTask('Mock', { timeoutMs: 5000 });
    t.tick = async (ctx) => {
        if (!behavior) { t._succeed({ label }); return; }
        await behavior(ctx, t);
        if (!t.isComplete()) t._succeed({ label });
    };
    return t;
}
const events = [];
const stack = new TaskStack({ maxDepth: 3, maxFailures: 2 });
const ctx = {
    run: { counters: { childTasks: 0, maxDepth: 0 }, blacklist: new Set() },
    telemetry: (e, d) => events.push({ e, d }),
    stack,
    deathEvents: [], stuckEvents: [],
    takeDeath() { return this.deathEvents.shift() ?? null; },
    takeStuck() { return null; },
};
const main = async () => {
    // 根任务
    const root = await stack.runRoot(ctx, 'acquire:stone', 'Acquire(stone ×16)', () => mockTask('root'));
    check('root success', root.status === 'SUCCESS');

    // cycle / depth 守卫都在【嵌套】语义下生效（根在栈上时）
    let cycleHit = null, depthHit = null;
    await stack.runRoot(ctx, 'acquire:stone', 'Acquire(stone ×16)', () => mockTask('root2', async (c) => {
        // cycle：在根（同名 key 在栈上）内再跑同名 key
        const dup = await stack.run(c, 'acquire:stone', 'dup', () => mockTask('dup'));
        cycleHit = dup.failReason;
        // depth：maxDepth=3；根占 1，k1=2，k2=3，k3=4 应被拦
        await stack.run(c, 'k1', 'l1', () => mockTask('l1', async (c1) => {
            await stack.run(c1, 'k2', 'l2', () => mockTask('l2', async (c2) => {
                const deep = await stack.run(c2, 'k3', 'l3', () => mockTask('l3'));
                depthHit = deep.failReason;
            }));
        }));
    }));
    check('cycle guard → DEPENDENCY_CYCLE', cycleHit === 'DEPENDENCY_CYCLE', cycleHit);
    check('depth guard → DEPENDENCY_TOO_DEEP', depthHit === 'DEPENDENCY_TOO_DEEP', depthHit);

    // budget：同 key 连败 2 次后第 3 次直接拦（拦截时不再真正驱动）
    let realRuns = 0;
    for (let i = 0; i < 3; i++) {
        const r = await stack.run(ctx, 'flaky', 'flaky', () => mockTask('flaky', async (c, t) => {
            realRuns++;
            t._fail('NO_PROGRESS');
        }));
        if (i === 2) check('budget guard → DEPENDENCY_BUDGET', r.failReason === 'DEPENDENCY_BUDGET', r.failReason);
    }
    check('budget: real runs = 2 (3rd refused)', realRuns === 2, realRuns);

    // 死亡换纪元：预算重置
    stack.noteDeath();
    const r2 = await stack.run(ctx, 'flaky', 'flaky', () => mockTask('flaky-ok'));
    check('death resets budget → runs again', r2.status === 'SUCCESS');

    // trace 渲染
    const trace = stack.renderTrace();
    check('trace non-empty', trace.includes('Acquire(stone ×16)'), trace.split('\n')[0]);
    console.log('--- trace ---\n' + trace.split('\n').map((l) => '  ' + l).join('\n'));

    // ---- 4. mission ----
    console.log('== 4. mission parse ==');
    check('json', parseMission('{"resource":"stone","count":16}').resource === 'stone');
    check('text count', parseMission('obtain 3 log').count === 3);
    check('wood alias default count', parseMission('{"resource":"wood"}').count === 16);
    let threw = false;
    try { parseMission('obtain 16 diamond'); } catch { threw = true; }
    check('unsupported resource rejected', threw);

    console.log(failures ? `\n${failures} FAILURES` : '\nALL PASS');
    process.exit(failures ? 1 : 0);
};
main().catch((e) => { console.error(e); process.exit(1); });
