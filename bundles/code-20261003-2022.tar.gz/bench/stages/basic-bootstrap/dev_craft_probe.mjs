// dev_craft_probe.mjs — 工作台 3x3 合成通道探针（独立诊断脚本，不属于 benchmark）
//
// MC-M1-TASK-02 版：诊断 Paper 1.21.1 上 mineflayer bot.craft 的 stateId 污染丢点击
//（手工点击序列 + 每步转储窗口状态，定位服务端在哪一步开始不跟随）。
//
// MC-M1-TASK-03 版（本版）：升级为「版本参数化 + 双通道对比」——
//   - --version 1.16.1 / 1.21.1 切换栈（1.16.1 配 MC_BENCH_JAR + MC_BENCH_JAVA 指向迁移环境）
//   - 同一环境各跑 N 次（默认 20）3x3 木镐合成：
//       path=bot   mineflayer 原生 bot.craft（1.16 经典稳定路径，TASK-02 §5 预判）
//       path=table 生产版 CraftingTask._tableCraft 直发通道（1.17+ 主通道）
//   - 每次合成按背包增量验证（gained===1 才算成功，防客户端预测假阳性）
//   - 输出两通道成功率与择优结论（平手取 bot.craft：1.16 原生路径少一层自研假设）
//
// 用法：node dev_craft_probe.mjs [--version 1.16.1] [--crafts 20] [--path both]
//       （自己起服/停服；端口同 bench 25566/25576）

import { spawn, spawnSync } from 'child_process';
import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import net from 'net';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const MINDCRAFT = path.join(ROOT, 'mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}
const MC_VERSION = arg('version', process.env.MC_BENCH_VERSION || '1.21.1');
const CRAFTS = parseInt(arg('crafts', '20'), 10);
const PATHS_RAW = arg('path', 'both');
const PATHS = PATHS_RAW === 'both' ? ['bot', 'table'] : PATHS_RAW.split(',').map((s) => s.trim()).filter(Boolean);
const SERVER_DIR = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/exec-reuse-spike/server-spike');
const JAVA = process.env.MC_BENCH_JAVA || 'C:/Program Files/Eclipse Adoptium/jre-21.0.12.101-hotspot/bin/java.exe';
// jar 名随版本走默认（1.16.1 迁移环境用 MC_BENCH_JAR 覆盖亦可）
const JAR = path.join(SERVER_DIR, process.env.MC_BENCH_JAR || (MC_VERSION.startsWith('1.16') ? 'server-1.16.1.jar' : 'paper-1.21.1-133.jar'));
const SERVER_PORT = 25566, RCON_PORT = 25576;
const RCON_PASS = 'spike-rcon';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function rcon(command) {
    return new Promise((resolve, reject) => {
        const sock = net.connect(RCON_PORT, '127.0.0.1');
        let buf = Buffer.alloc(0), sentCmd = false, got = false;
        const pkt = (id, type, payload) => {
            const body = Buffer.alloc(12 + payload.length);
            body.writeInt32LE(id, 0); body.writeInt32LE(type, 4);
            body.write(payload, 8);
            const head = Buffer.alloc(4); head.writeInt32LE(body.length, 0);
            return Buffer.concat([head, body]);
        };
        sock.on('connect', () => sock.write(pkt(1, 3, RCON_PASS)));
        sock.on('data', (d) => {
            buf = Buffer.concat([buf, d]);
            while (buf.length >= 4) {
                const len = buf.readInt32LE(0);
                if (buf.length < len + 4) break;
                const id = buf.readInt32LE(4);
                const payload = buf.toString('utf8', 12, 4 + len - 2);
                buf = buf.slice(4 + len);
                if (id === 1) { if (!sentCmd) { sentCmd = true; sock.write(pkt(2, 2, command)); } }
                else { got = true; sock.end(); if (id === -1) { reject(new Error('rcon auth failed')); return; } resolve(payload); return; }
            }
        });
        sock.on('error', reject);
        setTimeout(() => { sock.destroy(); if (!got) reject(new Error('rcon timeout')); }, 8000);
    });
}

const countOf = (bot, name) => bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0);

async function bootServer(logFile) {
    for (const d of ['spike_world', 'spike_world_nether', 'spike_world_the_end']) {
        fs.rmSync(path.join(SERVER_DIR, d), { recursive: true, force: true });
    }
    const spPath = path.join(SERVER_DIR, 'server.properties');
    const lines = fs.readFileSync(spPath, 'utf8').split(/\r?\n/).filter((l) => !l.startsWith('level-seed='));
    lines.push(`level-seed=probe-${MC_VERSION}`);
    fs.writeFileSync(spPath, lines.join('\n') + '\n');
    const out = fs.openSync(logFile, 'w');
    const child = spawn(JAVA, ['-Xms512M', '-Xmx1536M', '-jar', JAR, '--nogui'], { cwd: SERVER_DIR, stdio: ['ignore', out, out] });
    const t0 = Date.now();
    while (Date.now() - t0 < 180000) {
        await sleep(2000);
        try { if (fs.readFileSync(logFile, 'utf8').includes('Done (')) return child; } catch {}
        if (child.exitCode !== null) break;
    }
    throw new Error('server boot failed');
}

// ---------- 通道 A：生产版 CraftingTask._tableCraft（直发点击序列） ----------
async function runTableCraftPath(bot, table, recipe, n) {
    const { CraftingTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/crafting_task.js')).href);
    const task = new CraftingTask({ item: 'wooden_pickaxe', count: 1 });
    const ctx = { bot, run: { counters: {} }, telemetry: (e, d) => console.log(`    [telemetry] ${e} ${JSON.stringify(d ?? {}).slice(0, 120)}`) };
    const results = [];
    for (let i = 1; i <= n; i++) {
        const before = countOf(bot, 'wooden_pickaxe');
        let ok = false, err = null;
        try {
            ok = !!(await task._tableCraft(ctx, table, recipe));
        } catch (e) { err = String(e && e.message ? e.message : e).slice(0, 100); }
        await sleep(600); // 结算窗口：防客户端预测假结果混进增量
        const gained = countOf(bot, 'wooden_pickaxe') - before;
        const success = gained >= 1;
        results.push({ i, ok, gained, success, err });
        console.log(`  [table] craft ${i}/${n}: ok=${ok} gained=${gained} ${err ? 'err=' + err : ''}`);
        await sleep(250);
    }
    return results;
}

// ---------- 通道 B：mineflayer 原生 bot.craft ----------
async function runBotCraftPath(bot, table, recipe, n) {
    const results = [];
    for (let i = 1; i <= n; i++) {
        const before = countOf(bot, 'wooden_pickaxe');
        let ok = false, err = null;
        try {
            await bot.craft(recipe, 1, table);
            ok = true;
        } catch (e) { err = String(e && e.message ? e.message : e).slice(0, 100); }
        await sleep(600);
        const gained = countOf(bot, 'wooden_pickaxe') - before;
        const success = gained >= 1;
        results.push({ i, ok, gained, success, err });
        console.log(`  [bot  ] craft ${i}/${n}: ok=${ok} gained=${gained} ${err ? 'err=' + err : ''}`);
        // bot.craft 失败可能残留窗口，下一轮前清一次
        try { if (bot.currentWindow && bot.currentWindow.id !== 0) bot.closeWindow(bot.currentWindow); } catch {}
        await sleep(250);
    }
    return results;
}

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const runStamp = `probe_${MC_VERSION}_${new Date().toISOString().slice(0, 16).replace(/[-T:]/g, '')}`;
    const probeLog = path.join(ROOT, `bench/stages/basic-bootstrap/runs/${runStamp}/probe_server.log`);
    const probeJsonl = path.join(ROOT, `bench/stages/basic-bootstrap/runs/${runStamp}/probe_result.jsonl`);
    fs.mkdirSync(path.dirname(probeLog), { recursive: true });
    console.log(`booting server (version=${MC_VERSION}, jar=${path.basename(JAR)})...`);
    const server = await bootServer(probeLog);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: SERVER_PORT, username: 'ProbeBot', version: MC_VERSION });
    bot.loadPlugin(pf.pathfinder);

    bot.on('error', (e) => console.log('bot_error:', String(e).slice(0, 200)));
    bot.once('spawn', async () => {
        try {
            await sleep(4000);
            // 备料 + 平台 + 台子 + TP。1.16.1 vanilla 与 Paper 的差异（TASK-03 差异清单）：
            // console setblock 不强制加载区块（"That position is not loaded"）→ 先 forceload
            // 再 setblock，最后才 tp（bot 落地即站在平台上；先 tp 后建台 bot 会坠落到 16 格外）。
            const cmds = [
                'give ProbeBot oak_planks 128', 'give ProbeBot stick 96',
                'forceload add 0 0 15 15',
            ];
            for (const cmd of cmds) {
                const resp = String(await rcon(cmd)).slice(0, 60);
                console.log('rcon:', cmd, '→', resp);
                if (cmd.startsWith('give') && !resp.includes('Gave')) throw new Error(`give failed: ${cmd} → ${resp}`);
            }
            await sleep(1500); // forceload 生效
            const build = [];
            for (const dx of [3, 4, 5]) for (const dz of [3, 4, 5]) build.push(`setblock ${dx} 99 ${dz} stone`);
            build.push('setblock 4 100 4 crafting_table');
            build.push('tp ProbeBot 4.5 100 5.5');
            for (const cmd of build) {
                const resp = String(await rcon(cmd)).slice(0, 60);
                if (cmd.startsWith('setblock') && !resp.includes('Changed') && !resp.includes('placed')) {
                    throw new Error(`setblock failed: ${cmd} → ${resp}`);
                }
                if (cmd.startsWith('tp') && !resp.includes('Teleported')) throw new Error(`tp failed: ${cmd} → ${resp}`);
            }
            await sleep(2000); // tp 后等区块同步

            // 找工作台并站到旁边
            const tableId = bot.registry.blocksByName['crafting_table'].id;
            let table = null;
            for (let i = 0; i < 20 && !table; i++) {
                table = bot.findBlock({ matching: [tableId], maxDistance: 16 });
                if (!table) await sleep(500);
            }
            if (!table) throw new Error('table not found');
            console.log('table at', JSON.stringify(table.position), 'bot at', JSON.stringify(bot.entity.position.floored()));
            const goal = new (require('mineflayer-pathfinder').goals.GoalNear)(table.position.x, table.position.y, table.position.z, 1);
            await bot.pathfinder.goto(goal);
            console.log('dist to table:', bot.entity.position.distanceTo(table.position).toFixed(2));
            await sleep(600);

            // 木镐配方（3x3，requiresTable）
            const pickId = bot.registry.itemsByName['wooden_pickaxe'].id;
            let recipe = null;
            for (let i = 0; i < 10 && !recipe; i++) {
                const recipes = bot.recipesFor(pickId, null, 1, table);
                if (recipes.length) recipe = recipes[0];
                else await sleep(500);
            }
            if (!recipe) throw new Error('wooden_pickaxe recipe not found (recipesFor empty)');
            console.log('recipe: requiresTable=', !!recipe.requiresTable, 'inShape rows=', recipe.inShape?.length);

            const record = { version: MC_VERSION, jar: path.basename(JAR), crafts: CRAFTS, startedAt: new Date().toISOString(), paths: {} };

            if (PATHS.includes('bot')) {
                console.log('== path: bot.craft ==');
                record.paths.bot = await runBotCraftPath(bot, table, recipe, CRAFTS);
            }
            if (PATHS.includes('table')) {
                console.log('== path: _tableCraft (production CraftingTask) ==');
                record.paths.table = await runTableCraftPath(bot, table, recipe, CRAFTS);
            }

            const verdict = {};
            for (const [k, rs] of Object.entries(record.paths)) {
                verdict[k] = { success: rs.filter((r) => r.success).length, total: rs.length, gainedSum: rs.reduce((s, r) => s + Math.max(0, r.gained), 0) };
            }
            // 择优：成功率优先；平手取 bot.craft（1.16 原生路径少一层自研假设）
            const sBot = verdict.bot?.success ?? -1, sTable = verdict.table?.success ?? -1;
            record.verdict = {
                ...verdict,
                winner: sBot > sTable ? 'bot' : sTable > sBot ? 'table' : (sBot < 0 ? 'none' : 'bot'),
                note: 'tie → bot.craft（1.16 经典路径）；仅统计背包增量 gained>=1 的合成',
            };
            console.log('PROBE VERDICT:', JSON.stringify(record.verdict));
            fs.writeFileSync(probeJsonl, JSON.stringify(record, null, 2) + '\n');
            console.log(`result → ${probeJsonl}`);
            process.exit(0);
        } catch (e) {
            console.error('probe fail:', String(e && e.stack ? e.stack : e).slice(0, 600));
            try { await rcon('stop'); } catch {}
            setTimeout(() => process.exit(1), 8000);
        }
    });

    const stopAll = async () => {
        try { await rcon('stop'); } catch {}
        setTimeout(() => { try { server.kill('SIGKILL'); } catch {} process.exit(1); }, 15000);
    };
    process.on('SIGINT', stopAll);
    // 探针整体兜底：15 分钟没结束就收摊（防挂死占端口）
    setTimeout(async () => {
        console.error('probe global timeout, stopping server');
        try { await rcon('stop'); } catch {}
        setTimeout(() => process.exit(2), 10000);
    }, 15 * 60 * 1000).unref();
}

main().catch((e) => { console.error(e); process.exit(1); });
