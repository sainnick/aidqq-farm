// exec_bot.mjs — MC-M1-TASK-02 BASIC-bootstrap benchmark 执行机器人（standalone）
//
// 与 TASK-01 basic-stone/exec_bot 的唯一协议差别：**零 RCON give**。
//   fresh world → 正常出生 → 空背包直接开跑：木头→木板→木棍→工作台→木镐→stone ×16
//   全链路由本地 Task Layer 自主完成（TOOL_MISSING → Crafting 救援 → 恢复原任务）。
// RCON 模块整个不存在于本文件——starter kit 在协议层面不可能发生。
//
// 零 LLM 是结构性保证：不加载 prompter/history/self-prompt/dm_client（同 TASK-01）。
//
// 用法：node exec_bot.mjs --trial 1 --seed <seed> --out <runDir> [--port 25566]
//       [--username TaskBot] [--target 16] [--timeout-ms 420000] [--probe-ms 10000]
//       （--probe-ms = MC-BENCH-v2 runner 级进度探针周期，语义同 basic-iron/exec_bot 头注）

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const MINDCRAFT = path.join(ROOT, 'mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}

const TRIAL = parseInt(arg('trial', '0'), 10);
const SEED = arg('seed', 'unknown');
const OUT_DIR = arg('out', path.dirname(fileURLToPath(import.meta.url)));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const TARGET = parseInt(arg('target', '16'), 10);
const TIMEOUT_MS = parseInt(arg('timeout-ms', '420000'), 10);
// MC-M1-TASK-03：版本开关（默认 1.21.1 = TASK-02 原口径，1.16.1 迁移闸门用 --mc-version 注入）
const MC_VERSION = arg('mc-version', '1.21.1');
const TELEMETRY = path.join(OUT_DIR, 'telemetry.jsonl');
const RESULT = path.join(OUT_DIR, 'result.json');
const LOG = path.join(OUT_DIR, 'bot.log');
const PROBE = path.join(OUT_DIR, 'probe.jsonl');
const PROBE_MS = parseInt(arg('probe-ms', '10000'), 10);

fs.mkdirSync(OUT_DIR, { recursive: true });
const logLine = (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(LOG, line + '\n'); } catch {}
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let finished = false;
let _spawned = false; // MC-BENCH-v2：连接期失败快速退出的判据（spawn 前的 error 才致命）

// —— MC-BENCH-v2：runner 级进度探针（只读观测，不触碰任务层；语义同 basic-iron/exec_bot）——
let _runtime = null;
let _probeTimer = null;
function probeTree(rt) {
    try {
        const trace = rt?._ctx?.stack?.renderTrace?.() ?? '';
        return trace.replace(/\[[^\]]*\]/g, '[]');
    } catch { return ''; }
}
function startProbe(bot) {
    if (!(PROBE_MS > 0)) return;
    try { fs.rmSync(PROBE, { force: true }); } catch { /* 忽略 */ }
    _probeTimer = setInterval(() => {
        try {
            const invParts = bot.inventory.items()
                .map((i) => `${i.name}:${i.count}`).sort();
            const p = bot.entity?.position;
            const w = bot.currentWindow;
            const furnace = w && String(w.type).includes('furnace')
                ? { f: Math.round(w.fuelSeconds ?? 0), p: Math.round(w.progressSeconds ?? 0) }
                : null;
            fs.appendFileSync(PROBE, JSON.stringify({
                t: Date.now(), event: 'bench_probe',
                inv: invParts.join(','),
                pos: p ? [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)] : null,
                digging: !!bot.targetDigBlock,
                furnace,
                tree: probeTree(_runtime),
            }) + '\n');
        } catch { /* 探针失败不影响试局 */ }
    }, PROBE_MS);
    _probeTimer.unref?.();
}

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const toolPlugin = require('mineflayer-tool').plugin;
    const { TaskRuntime } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/task_runner.js')).href);
    const { AcquireResourceTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/acquire_resource_task.js')).href);
    const { parseMission } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/mission.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
    bot.loadPlugin(pf.pathfinder);
    bot.loadPlugin(toolPlugin);

    // 硬看门狗：任务层自身有超时，这里是 runner 级保险（timeout + 60s）
    const hardKill = setTimeout(() => {
        logLine('HARD_TIMEOUT: runner watchdog fired, exiting without result');
        finish({ status: 'RUNNER_TIMEOUT' }, 1);
    }, TIMEOUT_MS + 60000);

    bot.on('kicked', (r) => { logLine(`kicked: ${r}`); if (!finished) finish({ status: 'KICKED', reason: String(r) }, 1); });
    // MC-BENCH-v2：连接期（spawn 之前）失败快速退出（语义同 basic-iron/exec_bot）
    bot.on('error', (e) => {
        logLine(`bot_error: ${String(e).slice(0, 200)}`);
        if (!finished && !_spawned) finish({ status: 'CONNECT_FAIL', reason: String(e).slice(0, 120) }, 1);
    });
    // 死亡 → 重生。零 rekit：背包清空是 bootstrap 的一部分，任务层通过依赖预算死亡纪元
    // 重置后重新走木器链（任务层自己的恢复机制，正是本轮要测的东西）
    bot.on('death', () => { logLine('death event: respawning in 800ms'); setTimeout(() => { try { bot.respawn(); } catch {} }, 800); });

    bot.once('spawn', async () => {
        _spawned = true;
        try {
            await sleep(4000); // 世界落定（TASK-01 同款）
            const spawnPos = bot.entity.position.floored();
            const biomeName = (() => {
                try {
                    // biome 名解析（MC-M1-TASK-03 G1 修复）：本栈的 prismarine-block 把
                    // registry.version 当 registry 传给 prismarine-biome → 后者查表恒空、
                    // 全部回退 {name:'', id:N} 空名对象（1.21.1 B2R5 空 biome 的同根因）。
                    // 但 id 字段真实可靠：取 id 后自查 registry.biomes[id].name——1.16.1
                    // 静态注册表 id 与运行时一致；再不行兜底直读 chunk column。
                    const blk = bot.blockAt(spawnPos);
                    let id = null;
                    if (typeof blk?.biome === 'number') id = blk.biome;
                    else if (blk?.biome?.id != null) id = blk.biome.id;
                    if (id == null) {
                        const col = bot.world.getColumn(spawnPos.x >> 4, spawnPos.z >> 4);
                        id = col?.getBiome?.(spawnPos);
                    }
                    if (id == null) return 'unknown';
                    return bot.registry.biomes?.[id]?.name ?? `id:${id}`;
                } catch { return 'unknown'; }
            })();
            const invSnap = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',') || '(empty)';
            logLine(`spawn: seed=${SEED} pos=[${spawnPos.x},${spawnPos.y},${spawnPos.z}] biome=${biomeName} inventory=[${invSnap}]`);
            logLine('protocol: NO KIT (bootstrap must be self-sufficient)');
            const mission = parseMission(JSON.stringify({ resource: 'stone', count: TARGET }));
            logLine(`start: mission=${JSON.stringify(mission)}`);
            const runtime = new TaskRuntime(bot, { mission, telemetryPath: TELEMETRY });
            _runtime = runtime;
            startProbe(bot);
            const root = new AcquireResourceTask({ resource: mission.resource, count: mission.count, timeoutMs: TIMEOUT_MS });
            const summary = await runtime.run(root);
            const fullInv = {};
            for (const it of bot.inventory.items()) fullInv[it.name] = (fullInv[it.name] ?? 0) + it.count;
            logLine(`end: ${summary.status} reason=${summary.failReason} dur=${(summary.durationMs / 1000).toFixed(1)}s inv=${JSON.stringify(summary.finalInventory)}`);
            if (summary.taskTree) logLine(`task tree:\n${summary.taskTree}`);
            finish({ ...summary, spawnPos: [spawnPos.x, spawnPos.y, spawnPos.z], biome: biomeName, fullInventory: fullInv }, summary.status === 'SUCCESS' ? 0 : 1);
        } catch (e) {
            logLine(`fatal: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`);
            finish({ status: 'FAILED', failReason: 'INTERNAL', error: String(e).slice(0, 300) }, 1);
        }
    });

    function finish(summary, code) {
        if (finished) return;
        finished = true;
        clearTimeout(hardKill);
        if (_probeTimer) clearInterval(_probeTimer);
        try {
            fs.writeFileSync(RESULT, JSON.stringify({ trial: TRIAL, seed: SEED, target: TARGET, kit: 'none', ...summary }, null, 2));
        } catch (e) { logLine(`result write fail: ${e.message}`); }
        setTimeout(() => {
            try { bot.quit(); } catch {}
            process.exit(code);
        }, 1200);
    }
}

main().catch((e) => { logLine(`boot fail: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`); process.exit(1); });
