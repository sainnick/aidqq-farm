// summarize.mjs — MC-M1-TASK-02 BASIC-bootstrap 结果汇总 + 验收线判定
//
// 用法：node summarize.mjs <runs目录> [--version 1.16.1]
// 输出：<runs目录>/bench_report.md + bench_summary.json + task_traces.txt（每局任务调用树）
//
// 里程碑口径（任务书 §11，从 telemetry.jsonl 事件流推导，相对 mission_start）：
//   首木   = 首条 mine_ok(block *_log)
//   工作台 = 首条 table_placed
//   木镐   = 首条 craft_ok(item wooden_pickaxe)
//   首石   = 首条 mine_ok(block stone|cobblestone)
//   stone16= mission_end

import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import { createRequire } from 'module';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const require = createRequire(path.join(ROOT, 'mindcraft', 'main.js'));
// MC-M1-TASK-03：log family 名单随版本走（默认 1.21.1 原口径；1.16.1 runs 用 --version 1.16.1）
const verIdx = process.argv.indexOf('--version');
const MC_VERSION = verIdx >= 0 ? process.argv[verIdx + 1] : '1.21.1';
const md = require('minecraft-data')(MC_VERSION);
const LOG_NAMES = new Set(Object.keys(md.blocksByName).filter((n) => n.endsWith('_log') && !n.startsWith('stripped_')));

const RUNS_DIR = process.argv.slice(2).find((a) => !a.startsWith('--')) || path.join(BENCH_DIR, 'runs');
const hasTrialsHere = (d) => fs.existsSync(d) && fs.readdirSync(d).some((e) => e.startsWith('trial_'));
let targetDir = RUNS_DIR;
if (!hasTrialsHere(RUNS_DIR)) {
    const stampDirs = fs.readdirSync(RUNS_DIR).filter((d) => hasTrialsHere(path.join(RUNS_DIR, d))).sort();
    if (!stampDirs.length) { console.error(`no trial_* dirs under ${RUNS_DIR}`); process.exit(1); }
    targetDir = path.join(RUNS_DIR, stampDirs.at(-1));
}

const readJsonl = (p) => {
    if (!fs.existsSync(p)) return [];
    return fs.readFileSync(p, 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
};

const trials = [];
const trialDirs = fs.readdirSync(targetDir).filter((d) => d.startsWith('trial_')).sort();
for (const d of trialDirs) {
    const rp = path.join(targetDir, d, 'result.json');
    if (!fs.existsSync(rp)) { trials.push({ trial: d, missing: true }); continue; }
    const result = JSON.parse(fs.readFileSync(rp, 'utf8'));
    const events = readJsonl(path.join(targetDir, d, 'telemetry.jsonl'));
    const t0 = events.find((e) => e.event === 'mission_start')?.t ?? null;

    const firstOf = (pred) => {
        if (t0 == null) return null;
        const ev = events.find((e) => pred(e));
        return ev ? +((ev.t - t0) / 1000).toFixed(1) : null;
    };
    const firstLog = events.find((e) => e.event === 'mine_ok' && LOG_NAMES.has(e.block)) ?? null;
    const firstStone = events.find((e) => e.event === 'mine_ok' && (e.block === 'stone' || e.block === 'cobblestone')) ?? null;

    let firstLogDist = null;
    if (firstLog && Array.isArray(firstLog.pos) && Array.isArray(result.spawnPos)) {
        firstLogDist = Math.round(Math.hypot(firstLog.pos[0] - result.spawnPos[0], firstLog.pos[2] - result.spawnPos[2]));
    }

    // §13 依赖自主解决：child_push=尝试，child_pop SUCCESS=补齐（含 gather 的 acquire 与 tool 救援 craft）
    const pushes = events.filter((e) => e.event === 'child_push');
    const pops = events.filter((e) => e.event === 'child_pop');
    const rescuePushes = pushes.filter((e) => String(e.key).startsWith('craft:'));
    const rescuePops = pops.filter((e) => String(e.key).startsWith('craft:'));

    trials.push({
        trial: d,
        missing: false,
        seed: result.seed,
        status: result.status,
        failReason: result.failReason ?? null,
        durationSec: result.durationMs ? +(result.durationMs / 1000).toFixed(1) : null,
        biome: result.biome ?? 'unknown',
        firstLogDist,
        milestones: {
            firstLogSec: firstLog && t0 ? +((firstLog.t - t0) / 1000).toFixed(1) : null,
            tablePlacedSec: firstOf((e) => e.event === 'table_placed'),
            pickaxeSec: firstOf((e) => e.event === 'craft_ok' && e.item === 'wooden_pickaxe'),
            firstStoneSec: firstStone && t0 ? +((firstStone.t - t0) / 1000).toFixed(1) : null,
        },
        dependencyResolutions: { attempted: pushes.length, resolved: pops.filter((e) => e.status === 'SUCCESS').length },
        toolRescues: { attempted: rescuePushes.length, resolved: rescuePops.filter((e) => e.status === 'SUCCESS').length },
        finalInventory: result.finalInventory ?? {},
        fullInventory: result.fullInventory ?? {},
        taskTree: result.taskTree ?? '',
        metrics: result.metrics ?? {},
        deaths: (result.metrics?.deaths ?? 0),
    });
}

const done = trials.filter((t) => !t.missing);
const succ = done.filter((t) => t.status === 'SUCCESS');
const durs = succ.map((t) => t.durationSec).filter((x) => x != null).sort((a, b) => a - b);
const median = (arr) => arr.length ? (arr.length % 2 ? arr[(arr.length - 1) / 2] : (arr[arr.length / 2 - 1] + arr[arr.length / 2]) / 2) : null;
const p95 = (arr) => arr.length ? arr[Math.min(arr.length - 1, Math.ceil(0.95 * arr.length) - 1)] : null;
const msOf = (k) => { const v = succ.map((t) => t.milestones[k]).filter((x) => x != null).sort((a, b) => a - b); return { median: median(v), p95: p95(v), n: v.length }; };

const sum = (f) => done.reduce((s, t) => s + ((t.metrics && f(t.metrics)) || 0), 0);
const depAtt = sum((m) => m.childTasks ?? 0);
const depRes = trials.reduce((s, t) => s + (t.dependencyResolutions?.resolved ?? 0), 0);
const depAttEv = trials.reduce((s, t) => s + (t.dependencyResolutions?.attempted ?? 0), 0);
const rescueRes = trials.reduce((s, t) => s + (t.toolRescues?.resolved ?? 0), 0);
const rescueAtt = trials.reduce((s, t) => s + (t.toolRescues?.attempted ?? 0), 0);

const failHist = {};
for (const t of done.filter((t) => t.status !== 'SUCCESS')) {
    const r = t.failReason ?? 'UNKNOWN';
    failHist[r] = (failHist[r] ?? 0) + 1;
}
const reasons = Object.entries(failHist).sort((a, b) => b[1] - a[1]).slice(0, 5);

const report = {
    stage: 'BASIC-bootstrap',
    runsDir: targetDir,
    trialsTotal: trials.length,
    trialsReported: done.length,
    success: succ.length,
    successRate: done.length ? +(100 * succ.length / done.length).toFixed(1) : null,
    completion: {
        medianSec: median(durs) === null ? null : +median(durs).toFixed(1),
        p95Sec: p95(durs) === null ? null : +p95(durs).toFixed(1),
        minSec: durs[0] === undefined ? null : +durs[0].toFixed(1),
        maxSec: durs.at(-1) === undefined ? null : +durs.at(-1).toFixed(1),
    },
    milestones: {
        firstLog: msOf('firstLogSec'),
        tablePlaced: msOf('tablePlacedSec'),
        woodenPickaxe: msOf('pickaxeSec'),
        firstStone: msOf('firstStoneSec'),
    },
    firstLogDist: { median: median(done.map((t) => t.firstLogDist).filter((x) => x != null).sort((a, b) => a - b)) },
    taskStack: {
        maxDepth: sum((m) => m.maxDepth ?? 0),
        maxDepthSeen: Math.max(0, ...done.map((t) => t.metrics?.maxDepth ?? 0)),
        childTasks: sum((m) => m.childTasks ?? 0),
        recipeResolves: sum((m) => m.recipeResolves ?? 0),
        replans: sum((m) => m.replans ?? 0),
    },
    dependency: {
        resolutions: `${depRes}/${depAttEv}`,
        ratePct: depAttEv ? +(100 * depRes / depAttEv).toFixed(1) : null,
        toolRescues: `${rescueRes}/${rescueAtt}`,
    },
    crafting: {
        attempts: sum((m) => m.craftAttempts ?? 0),
        failures: sum((m) => m.craftFailures ?? 0),
        tablePlacements: sum((m) => m.tablePlacements ?? 0),
        tablePlacementFailures: sum((m) => m.tablePlacementFailures ?? 0),
    },
    searches: sum((m) => m.searches ?? 0),
    deaths: sum((m) => m.deaths ?? 0),
    softStuck: sum((m) => m.softStuckEvents ?? 0),
    hardStuck: sum((m) => m.hardStuck ?? 0),
    recoveries: sum((m) => m.recoveries ?? 0),
    failureReasons: Object.fromEntries(reasons),
    llmCalls: 0,     // 结构性：exec_bot 无 LLM 客户端
    bailianCalls: 0,
    rconGives: 0,    // 结构性：本 stage exec_bot 无 RCON 模块
};

// 验收线（任务书 §12）+ 子系统判定（§21）
const terminal = ['SUCCESS', 'FAILED', 'TIMEOUT', 'ABORTED'];
const verdict = {
    successRate_ge90: report.successRate !== null && report.successRate >= 90,
    p95_lt300: report.completion.p95Sec !== null && report.completion.p95Sec < 300,
    zero_infiniteloop: trials.every((t) => t.missing || (t.status && terminal.includes(t.status))),
    zero_manual: true,
    zero_rcon_kit: done.every((t) => t.fullInventory !== undefined), // exec_bot 无 RCON；结果均真实产出
    zero_llm: true,
    zero_bailian: true,
};
verdict.PASS = verdict.successRate_ge90 && verdict.p95_lt300 && verdict.zero_infiniteloop
    && verdict.zero_manual && verdict.zero_rcon_kit && verdict.zero_llm && verdict.zero_bailian;

// 子系统判定
const subsystem = {
    resource_agnostic: succ.length > 0 && done.some((t) => (t.metrics?.childTasks ?? 0) > 0), // log 采集真实发生
    crafting_task: succ.length > 0 && succ.filter((t) => t.milestones.pickaxeSec != null).length >= Math.ceil(0.9 * Math.max(1, succ.length)),
    task_stack: report.taskStack.maxDepthSeen >= 2 && done.every((t) => t.metrics !== undefined),
    tool_requirement_auto: rescueAtt > 0 && rescueRes / rescueAtt >= 0.9,
    task_trace: done.filter((t) => (t.taskTree ?? '').length > 0).length === done.length,
};
report.verdict = verdict;
report.subsystem = subsystem;

fs.writeFileSync(path.join(targetDir, 'bench_summary.json'), JSON.stringify(report, null, 2));

// 每局任务树落一个文件，便于复盘
fs.writeFileSync(path.join(targetDir, 'task_traces.txt'),
    done.map((t) => `===== trial ${t.trial} seed=${t.seed} [${t.status}${t.failReason ? ' ' + t.failReason : ''}] =====\n${t.taskTree || '(no trace)'}`).join('\n\n') + '\n');

const md2 = [];
md2.push(`# BASIC-bootstrap bench report — ${path.basename(targetDir)}`);
md2.push('');
md2.push(`| 指标 | 值 |`);
md2.push(`|---|---|`);
md2.push(`| trials | ${report.trialsReported}/${report.trialsTotal} |`);
md2.push(`| 成功 | ${report.success}（${report.successRate}%） |`);
md2.push(`| completion median | ${report.completion.medianSec}s |`);
md2.push(`| completion P95 | ${report.completion.p95Sec}s |`);
md2.push(`| 首木 median | ${report.milestones.firstLog.median}s（距离 median ${report.firstLogDist.median}） |`);
md2.push(`| 工作台 median | ${report.milestones.tablePlaced.median}s |`);
md2.push(`| 木镐 median | ${report.milestones.woodenPickaxe.median}s |`);
md2.push(`| 首石 median | ${report.milestones.firstStone.median}s |`);
md2.push(`| 依赖自主解决 | ${report.dependency.resolutions}（${report.dependency.ratePct}%）；工具救援 ${report.dependency.toolRescues} |`);
md2.push(`| 合成 成功/尝试 | ${report.crafting.attempts - report.crafting.failures}/${report.crafting.attempts}；放台 ${report.crafting.tablePlacements}/${report.crafting.tablePlacements + report.crafting.tablePlacementFailures} |`);
md2.push(`| 任务栈 maxDepth（峰值）/ child tasks | ${report.taskStack.maxDepthSeen} / ${report.taskStack.childTasks} |`);
md2.push(`| 死亡 / soft stuck / hard stuck | ${report.deaths} / ${report.softStuck} / ${report.hardStuck} |`);
md2.push(`| LLM / 百炼 / RCON kit | 0 / 0 / 0（结构性） |`);
md2.push('');
md2.push(`失败原因分布: ${JSON.stringify(report.failureReasons)}`);
md2.push('');
md2.push(`验收线: ${verdict.PASS ? 'PASS' : 'FAIL'}（成功率≥90%: ${verdict.successRate_ge90}｜P95<300s: ${verdict.p95_lt300}｜终态完备: ${verdict.zero_infiniteloop}）`);
md2.push(`子系统: 资源无关=${subsystem.resource_agnostic ? 'PASS' : 'FAIL'}｜CraftingTask=${subsystem.crafting_task ? 'PASS' : 'FAIL'}｜TaskStack=${subsystem.task_stack ? 'PASS' : 'FAIL'}｜工具自动补依赖=${subsystem.tool_requirement_auto ? 'PASS' : 'FAIL'}｜TaskTrace=${subsystem.task_trace ? 'PASS' : 'FAIL'}`);
fs.writeFileSync(path.join(targetDir, 'bench_report.md'), md2.join('\n') + '\n');

console.log(JSON.stringify(report, null, 2));
console.log(`\nreport → ${path.join(targetDir, 'bench_report.md')}`);
