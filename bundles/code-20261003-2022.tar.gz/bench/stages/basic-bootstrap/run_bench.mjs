// run_bench.mjs — MC-M1-TASK-02 BASIC-bootstrap benchmark runner
//
// MC-BENCH-v2（2026-10-01）：编排层重构为泳道并行版，核心机制全部在
// bench/stages/_lib/runner_core.mjs（泳道/内存护栏/无进展硬中止/失败预算提前收手）。
// 本文件只做 CLI 解析与 stage 专属参数（无 --resource；超时默认 480s）。
// 参数说明见 basic-iron/run_bench.mjs 头注（两 stage 同一套）。

import { fileURLToPath } from 'url';
import path from 'path';
import { argOf, runMatrix, parseFailBudget, parseLanes } from '../_lib/runner_core.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const SERVER_DIR = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/exec-reuse-spike/server-spike');
const JAVA = process.env.MC_BENCH_JAVA || 'C:/Program Files/Eclipse Adoptium/jre-21.0.12.101-hotspot/bin/java.exe';
const JAR = path.join(SERVER_DIR, process.env.MC_BENCH_JAR || 'paper-1.21.1-133.jar');
const MC_VERSION = argOf(process.argv, 'mc-version', process.env.MC_BENCH_VERSION || '1.21.1');
const RCON_PASS = 'spike-rcon';

const TRIALS = parseInt(argOf(process.argv, 'trials', '20'), 10);
const START = parseInt(argOf(process.argv, 'start', '1'), 10);
const TARGET = parseInt(argOf(process.argv, 'target', '16'), 10);
const TIMEOUT_MS = parseInt(argOf(process.argv, 'timeout-ms', '480000'), 10);
const RUNSTAMP = argOf(process.argv, 'stamp', `B2R${new Date().toISOString().slice(0, 13).replace(/[-T:]/g, '')}`);
const SEED_PREFIX = argOf(process.argv, 'seed-prefix', RUNSTAMP);
const SEED_LITERAL = argOf(process.argv, 'seed', '');
const SEED_LIST = argOf(process.argv, 'seeds', '');
const LANES = parseInt(argOf(process.argv, 'lanes', '1'), 10);
// MC-M1-TASK-06d P0：--lane A,B,C 按名选泳道（手册 §9 每条线只占一条）；没给则回退 --lanes N
const LANE_NAMES = parseLanes(process.argv);
const NO_PROGRESS_S = parseInt(argOf(process.argv, 'no-progress-s', '120'), 10);
const FAIL_BUDGET = parseFailBudget(argOf(process.argv, 'fail-budget', ''));
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const SERVER_XMX = argOf(process.argv, 'server-xmx', '1G');
const PROBE_MS = parseInt(argOf(process.argv, 'probe-ms', '10000'), 10);
const RUNS_DIR = path.join(BENCH_DIR, 'runs', RUNSTAMP);

const trialNumbers = Array.from({ length: TRIALS }, (_, i) => START + i);
const seedList = SEED_LIST ? SEED_LIST.split(',').map((s) => s.trim()) : null;
const seedFor = (n) => {
    if (seedList) return seedList[n - START] ?? `${SEED_PREFIX}-${String(n).padStart(2, '0')}`;
    return SEED_LITERAL || `${SEED_PREFIX}-${String(n).padStart(2, '0')}`;
};

await runMatrix({
    runsDir: RUNS_DIR,
    summaryPath: path.join(RUNS_DIR, 'summary.jsonl'),
    execBotPath: path.join(BENCH_DIR, 'exec_bot.mjs'),
    stageLabel: `BASIC-bootstrap (stone×${TARGET})`,
    templateDir: SERVER_DIR,
    jarPath: JAR,
    java: JAVA,
    rconPass: RCON_PASS,
    trials: trialNumbers,
    seedFor,
    extraBotArgs: () => ['--target', String(TARGET)],
    lanes: LANES,
    laneNames: LANE_NAMES,
    mcVersion: MC_VERSION,
    timeoutMs: TIMEOUT_MS,
    noProgressMs: NO_PROGRESS_S * 1000,
    probeMs: PROBE_MS,
    failBudget: FAIL_BUDGET,
    minFreeBytes: MIN_FREE_MB * 1048576,
    serverXmx: SERVER_XMX,
}).then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
