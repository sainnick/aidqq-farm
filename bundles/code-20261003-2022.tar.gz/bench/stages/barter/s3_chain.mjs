﻿// s3_chain.mjs — MC-S2-06：`do station S3_bastion` 整链段（开发线 F）
//
// 派单原话：「把易物做成整链里一段 —— 从到达堡垒作业点 [331,57,238] 开始，背包按真实前置状态
//   （S1 废墟门箱子里有 golden_leggings ×1：穿上它当金甲；铁镐；圆石若干），按 exact 去挖金块
//   （10 颗珍珠约需 35 锭 ≈ 4 个金块；挖金块会激怒 16 格内猪灵，先确认穿着金甲时是否仍会被打，
//     用服务端死亡消息为准），然后 approach 模式易物到 10 颗珍珠，离开。」
//
// ── 整链优先（MC-DECISION-02 §1.2）────────────────────────────────────────
// 故意用最笨的办法把「到达 → 盖岩浆 → 挖金 → 合成锭 → 回位 → 易物 → 离开」串成一趟，哪里断修哪里。
//
// ── ⚠ 派单里「4 个金块 ≈ 35 锭」这条在 1.16.1 vanilla **不成立**，本脚本已按真值改口径 ──
// 从 `server-1.16.1-official.jar!data/minecraft/loot_tables/blocks/gold_block.json` 逐字读出：
//   `gold_block` 掉的是 **`minecraft:gold_block` 本身，不是金锭**（无 Silk Touch 区分）。
//   ⇒ 挖 4 个金块 = 背包里 4 个金块 + **0 锭**；要变成 36 锭必须再走一次
//     `gold_block → 9×gold_ingot` 的**合成**，而 3×3 配方**背包 2×2 合成不了**，要工作台。
//   ⇒ 本脚本把「挖金块」和「拿到锭」当成**两段**分别测量，并如实报告挖到的到底是块还是锭。
//   （`gilded_blackstone` 掉 2–5 个 `gold_nugget`，9 粒=1 锭 ⇒ 更差，不做主源。已从 jar 逐字核对。）
//
// ── 计时口径（派单点名）──────────────────────────────────────────────────
// `t0` 取在 **exact 第 0 个站位落脚验真通过那一瞬**（「从到达开始」）；
// 门槛读**背包真值** `ender_pearl` 首次 ≥ 10（引擎 `stats.pearls` 漏算接触自动捡起，S2-04 已证）。
// 未达标的局记**预算值**（手册 §5：时间指标按全部 trial 计算）。
//
// 用法：
//   node s3_chain.mjs --dry                  解析自检，不起服
//   node s3_chain.mjs --runs 3               正式 3 局
//   node s3_chain.mjs --runs 1 --dig-only    只跑「到达 + 挖金 + 合成」段（高信息量，先跑这个）
//   node s3_chain.mjs --runs 1 --no-mitigate 对照组：岩浆不盖
//   node s3_chain.mjs --runs 1 --mode wait   wait 模式同口径对照

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

function argOf(k, d = null) {
    const a = process.argv.find((x) => x.startsWith('--' + k + '='));
    return a ? a.split('=').slice(1).join('=') : d;
}
const argv = argOf;

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const STAMP = argv('stamp', 'S3_S6');
const RUNS = parseInt(argv('runs', '3'), 10);
const GOAL = parseInt(argv('pearls', '10'), 10);
const GOAL_SEC = parseFloat(argv('pearl-goal-sec', '180'));
const MODE = argv('mode', 'approach');
const DIG_ONLY = process.argv.includes('--dig-only');
const MITIGATE = !process.argv.includes('--no-mitigate');
const N = parseInt(argv('n', '3'), 10);
const PEARL_MIN = parseFloat(argv('pearl-min', '12'));
const AGGRO_EVERY = parseInt(argv('aggro-every-ms', '700'), 10);
// 开发期开关：走路走不到金块时，就近 	p 过去再挖（**正式局不存在这一步**，如实标注）
const TP_DIG = !process.argv.includes('--no-tp-dig');

const H = await import(`./harness.mjs`);
const { Vec3, LANE, STATION, bootWorld, openRun, closeRun, parkSafe, recallTo, kit, invCount,
    footingOk, makeStandGuard, makeDeathGuard, watchDeaths, truth, bot, botPos, dim, record,
    writeSummary, sleep, moduleUrl, countItem, cmd } = H;
const { parseArmorNbt, ARMOR_SLOT_IDS } = await import('./truth.mjs');
const P = STATION.piglinDense;

const EXACT_PATH = path.join(BENCH_DIR, '..', '..', 'route', 'exact', 's3_bastion.exact.json');
const loadExact = () => JSON.parse(fs.readFileSync(EXACT_PATH, 'utf8')).exact;

/**
 * 真实前置状态（S1 之前的环节产物，**不是测试 kit**）。
 * ⚠ `crafting_table` 的来源是**"玩家开局自带"**，不是 S1 产物 —— 这是一条**假设**，
 *   派单没给，已在报告里如实标注。若设计会话认为不该带工作台，本段就退成"只有块没有锭"。
 */
const PRIOR = [
    ['minecraft:golden_leggings', 1, 'S1 废墟门箱子的金护腿。isWearingGold 任意一件即 true（PiglinAi.java:592-601）'],
    ['minecraft:iron_pickaxe', 1, 'S0 挖铁顺手的镐；gold_block 走 requiresCorrectToolForDrops（Blocks.java:392-395）'],
    ['minecraft:cobblestone', 8, '盖作业位旁那 3 格岩浆'],
    ['minecraft:crafting_table', 1, '★ 假设：开局自带。gold_block→9 锭是 3×3 配方，背包 2×2 合成不了'],
];

const log = (...a) => console.log(...a);
const shortName = (h) => (h ? String(h).replace('minecraft:', '') : null);

// ── 判据工具（**判据的输入样本必须来自现场**，S2-05 §5.5-A 的教训）──────────
/**
 * 服务端逐格真值。
 * ⚠ `readFailed`（读不到）与"读到但不是目标"**必须分两个字段** —— 手册记忆那条：
 *   `blockAt` 在区块未加载时返回 null，读失败折算成"服务端移除了"就是静默假阴性。
 */
async function probeCell(cell, expect = []) {
    const t = truth();
    if (!t?.probeCell) return { hit: null, readFailed: true, why: 'no_probeCell' };
    try {
        const r = await t.probeCell(dim(), { x: cell[0], y: cell[1], z: cell[2] }, expect);
        return { hit: r.hit ?? null, readFailed: r.hit == null, err: r.error ?? null, expect };
    } catch (e) {
        return { hit: null, readFailed: true, err: String(e?.message ?? e).slice(0, 100) };
    }
}
const isBlock = (p, want) => !!p && shortName(p.hit) === want;

/**
 * 「给了 + 穿上」的**服务端真值**闸门。
 *
 * 🚨 S2-06 在这里连栽两次，**两次都是静默的**：
 *   ① 客户端 `invCount()` 说金护腿在、`bot.equip(leg,'torso')` **没抛**、`equipped=true`，
 *      而服务端 `data get entity … Inventory` 的装备槽与背包里**都没有** golden_leggings。
 *   ② 加了服务端闸门后重跑，第一读（16:14:33）**确实**读到 `{Slot: 0b, golden_leggings}`，
 *      紧接着 `bot.equip(leg,'torso')` 之后的所有读数里它**彻底消失**（连 100–103 都没有）。
 *      ⇒ **mineflayer 的 `equip(item,'torso')` 在 1.16.1 玩家身上把物品弄丢了**，
 *      而且服务端一句日志都不打。已对着源码确认不是"读错路径"：
 *      `Inventory.save` 把主背包写 0–35、**护甲写 100–103 进同一个 `Inventory` 列表**
 *      （`Inventory.java` 的 `save`），`Player.addAdditionalSaveData` 只写这一个 `Inventory` 标签。
 *   ⇒ 处置：equip **只试一次**，试完立刻回服务端读**两遍**（`Inventory`）确认东西还在；
 *      丢了就如实记 `equip_destroyed_item`，并**改用 kit 通道** `/replaceitem` 装上（开发期布景，
 *      与 `give` 同族；正式局不存在这一步，真人是点装备格）。**绝不**在没回读的情况下继续。
 */
async function giveAndEquip(prior) {
    const want = prior.map((p) => [String(p[0]).replace('minecraft:', ''), p[1]]);
    const invBefore = invCount();
    await kit(want.map(([n, c]) => `${n}:${c}`), { verifyMs: 15000 });
    // ⚠ **不要紧密轮询这条通道**：手册/记忆那条 FIFO 纪律 —— 同一回执类同时在途会互抢回执，
    //   5s 后整条通道判死。S2-06 第一版 400ms 一发地打，通道直接哑掉（12s 内只回 1 条）。
    await sleep(2000);
    const a1 = await serverArmorTruth();
    const invOnly = {};
    for (const w of a1.worn.filter((x) => !ARMOR_SLOT_IDS[x.slot])) invOnly[w.id] = (invOnly[w.id] ?? 0) + 1;
    const stillMissing = want.filter(([n, c]) => (invOnly[n] ?? 0) < c).map(([n, c]) => `${n}×${c}(服务端实到 ${invOnly[n] ?? 0})`);

    const b0 = bot();
    const legName = 'golden_leggings';
    const hadLegInv = (invOnly[legName] ?? 0) > 0;
    let leg = b0.inventory.items().find((i) => i.name === legName);
    const steps = [`give 后服务端背包: ${JSON.stringify(invOnly)} 缺: ${JSON.stringify(stillMissing)}`,
        `客户端持有 ${legName}: ${leg ? '有' : '无'}`];
    let equipped = false, equipPath = null, destroyed = false;

    if (hadLegInv && leg) {
        try { await b0.equip(leg, 'torso'); } catch (e) { steps.push(`equip 抛: ${String(e?.message ?? e).slice(0, 70)}`); }
        await sleep(1200);
        const a2 = await serverArmorTruth();
        const on2 = a2.worn.some((w) => ARMOR_SLOT_IDS[w.slot] && String(w.id).includes(legName));
        const inv2 = {};
        for (const w of a2.worn.filter((x) => !ARMOR_SLOT_IDS[x.slot])) inv2[w.id] = (inv2[w.id] ?? 0) + 1;
        const stillThere = on2 || (inv2[legName] ?? 0) > 0;
        steps.push(`equip 后服务端读: 装备槽有护腿=${on2} 背包里还有=${(inv2[legName] ?? 0) > 0}（raw=${String(a2.raw ?? '').slice(0, 160)}）`);
        equipped = on2;
        if (!stillThere) {
            destroyed = true;
            steps.push('🚨 equip 之后金护腿**从服务端消失了**（既不在 0–35 也不在 100–103）⇒ 记 equip_destroyed_item');
        } else if (!on2) {
            steps.push('装备没上但东西还在（客户端与服务端不一致）⇒ 继续走 kit 通道');
        }
    }

    if (!equipped) {
        // ⚠⚠ **1.16.1 的 `/replaceitem` 没有 `with` 关键字**（`with` 是 1.17+ 才加的）。
        //   语法直接对着源码核过：`ReplaceItemCommand.register` 是
        //   `literal("replaceitem") → literal("entity") → argument(targets) → argument(slot) → argument(item) → [argument(count)]`，
        //   **中间没有 literal("with")**。我第一版照 1.17+ 的记忆写了 `with` ⇒ 服务端回
        //   `Unknown item 'minecraft:with'`（`...rmor.legs with minecraft:golden_leggings 1<--[HERE]`），
        //   **装备槽依然是空的** —— 又是一次"命令跑了、什么也没发生、零报错"。
        //   （S2-04 §5.5-A 的同族第三次：这次连失败回执都在日志里，只是没人读。）
        // 先把被 equip 弄丢的那件补回去，再装。
        cmd(`give ${LANE.username} minecraft:golden_leggings 1`);
        await sleep(1200);
        cmd(`replaceitem entity ${LANE.username} armor.legs minecraft:golden_leggings 1`);
        await sleep(1500);
        const a3 = await serverArmorTruth();
        equipped = a3.worn.some((w) => ARMOR_SLOT_IDS[w.slot] && String(w.id).includes(legName));
        equipPath = 'kit:replaceitem(1.16.1 无 with)';
        steps.push(`give 补回 + replaceitem(无 with) 后：装备槽有金=${equipped} verdict=${a3.verdict}（raw=${String(a3.raw ?? '').slice(0, 300)}）`);
    } else {
        equipPath = 'client:equip(torso)';
    }
    const armor = await serverArmorTruth();
    return {
        invBefore, invTruth: { invOnly }, stillMissing, equipped, equipPath, equipDestroyedItem: destroyed,
        steps, armorTruth: { ...armor, raw: (armor.raw ?? '').slice(0, 600) },
        wearingGoldArmor: armor.wearingGoldArmor,
    };
}
/** 装备槽服务端真值（槽号 **100–103**，`Inventory.java:343-348`；不是客户端那套 5–8）。
 *  ⚠ 1.16.1 回执里**没有 `Inventory:` 标签**（数组即根值），`id:` 后面**有空格** —— 两个都踩过。 */
async function serverArmorTruth() {
    const t = truth();
    let line = null, err = null;
    try { line = await t.dataEntity('the_nether', LANE.username, LANE.username, 'Inventory', { timeoutMs: 8000, soft: true }); }
    catch (e) { err = String(e?.message ?? e).slice(0, 160); }
    const p = parseArmorNbt(line);
    return {
        ...p,
        inInventoryGold: p.worn.filter((w) => !ARMOR_SLOT_IDS[w.slot] && String(w.id).startsWith('golden_')).length,
        err, raw: line ? line.slice(0, 300) : null,
        // ⚠ isWearingGold 读**装备槽**：金护腿只在背包里 = 等于没穿
        wearingGoldArmor: p.worn.some((w) => ARMOR_SLOT_IDS[w.slot] && String(w.id).startsWith('golden_')),
    };
}

/** mineflayer-pathfinder 的 `goals` **挂在模块上（`bot.pf`），不在插件实例上**。
 *  harness.mjs:586 与 piglin.js 都用 `bot.pf.goals`；我第一版写 `bot.pathfinder.goals` ⇒ `new undefined()`
 *  ⇒ 抛错被 `catch` 吞掉 ⇒ **走路静默失败 0ms**（"没报错"≠"走到了"，手册 §5）。 */
function pfGoals() {
    const b = bot();
    return (b?.pathfinder?.goals) ?? (b?.pf?.goals) ?? (b?._pf?.goals) ?? null;
}

/**
 * 走到目标格边（≤range 格）。**不自己 aim** —— `bot.lookAt(p,true)` 不发旋转包（见 piglin.js 头注）。
 *
 * ⚠ 2026-10-03 实测：`goto` 在本工作点**立刻 reject** —— `Path was stopped before it could be completed!`
 *   （`walkNear` 上一趟结尾的 `pathfinder.stop()` 与下一趟 `goto()` 撞车）。
 *   而 12 格外那个金块与作业位**差两层**（y57 → y55），是堡垒内部多层结构，
 *   `GoalNear` 也没有路。⇒ 走路这条道在 S3 站**走不通**，开发期改用 `--tp-dig` 就近传送再挖
 *   （`recallTo` 就是 tp，harness 本来就在用；**正式局不存在这一步**，见报告的如实标注）。
 */
async function walkNear(cell, range = 2) {
    const b = bot();
    const goals = pfGoals();
    if (!goals?.GoalNear) return { ms: 0, dist: null, why: 'NO_GoalNear（pathfinder 插件没装或 bot.pf 为空）' };
    const wt0 = Date.now();
    let why = null;
    try {
        await b.pathfinder.goto(new goals.GoalNear(
            Math.floor(cell[0]) + 0.5, cell[1] + 1, Math.floor(cell[2]) + 0.5, range));
    } catch (e) { why = `goto_threw:${String(e?.message ?? e).slice(0, 70)}`; }
    try { b.pathfinder.stop?.(); b.clearControlStates?.(); } catch { /* 忽略 */ }
    const me = botPos();
    const d = me ? Math.hypot(me.x - cell[0] - 0.5, me.z - cell[2] - 0.5) : null;
    return { ms: Date.now() - wt0, dist: d != null ? +d.toFixed(2) : null, why };
}

/**
 * ★ S3 的**金源主路**：开宝藏箱。
 * 依据（2026-10-03 设计会话裁决 + 源码）：
 *   - 破坏 `guarded_by_piglins` 方块走 `Block.java:327` 传 `false` ⇒ 16 格内**全部 idle 猪灵**、
 *     **不需要视线**、直接记 `ANGRY_AT`，而这档**不看金甲** ⇒ 穿金甲照样挨打；
 *   - **开箱走 `ChestBlock.java:240` 传 `true` ⇒ 要视线**，触发面小得多，且**直接给金锭**。
 * ⚠ 宝藏箱 loot **至今未验证**（S2-04：5 个箱子的 `Items` 读不到，区块未加载）⇒
 *   逐个箱子记 `empty` / `no_gold` / `got`，**不做**「这些箱子都没金锭」这种泛化。
 */
async function openChestGold(cell) {
    const b = bot();
    const ingot0 = countItem('gold_ingot') ?? 0;
    // 先用客户端方块真值确认那格确实是箱子（没读到 ≠ 没有）
    const blk = b.blockAt(new Vec3(cell[0], cell[1], cell[2]));
    if (!blk) return { cell, ok: false, why: 'blockAt_null(区块没加载 ≠ 那儿没箱子)' };
    if (blk.name !== 'chest' && blk.name !== 'trapped_chest') {
        return { cell, ok: false, why: `客户端方块=${blk.name}（不是箱子）` };
    }
    // 走到箱边（走不到就就近 tp，开发期布景；正式局需要 exact legs）
    let approach = await walkNear(cell, 2);
    let tpUsed = false, tpCell = null;
    if ((approach.dist == null || approach.dist > 4.0) && TP_DIG) {
        const spot = findStandNear(cell, 3);
        if (spot) {
            await recallTo([spot.x, spot.y, spot.z], { label: 'chest-approach' });
            await sleep(900);
            tpUsed = true; tpCell = [spot.x, spot.y, spot.z];
            const me2 = botPos();
            approach = { ...approach, dist: me2 ? +Math.hypot(me2.x - cell[0] - 0.5, me2.z - cell[2] - 0.5).toFixed(2) : null, why: 'tp 到位' };
        }
    }
    const t0 = Date.now();
    let opened = false, items = [], why = null, win = null, title = null, isChest = false;
    // 🚨🚨 **手上拿着方块时，右键箱子是"放方块"不是"开箱"** —— 这是 S2-06K 的真凶。
    //   阶段 2 盖岩浆结束时 bot 手里是**圆石**，`bot.openBlock(chest)` 对着箱子右键 ⇒
    //   服务端把圆石**放在箱子旁边**，箱子根本没开；而 mineflayer 那边**照样 resolve**，
    //   返回的窗里列的是**玩家自己的背包**（`golden_leggings/iron_pickaxe/cobblestone/crafting_table`
    //   —— 和我发下去的 kit 一模一样）。于是我读出 5 个箱子"内容完全一样、且没有金锭"，
    //   **等于凭空写下"这些箱子里没金锭"**，而服务端 `data get block … Items` 明明白白写着
    //   `[331,69,217]` 里有 `spectral_arrow×10 / golden_boots(soul_speed) / …`。
    // ⇒ 开箱前**必须先把手里换成不是方块的物品**（铁镐对箱子是"使用"不是"放置"）。
    // ⇒ 并且**必须用服务端 NBT 交叉验**，不能只信窗口标题。
    try {
        const pick = b.inventory.items().find((i) => i.name === 'iron_pickaxe');
        if (pick) { try { await b.equip(pick, 'hand'); } catch { /* 换不了就照开，但下面有 NBT 兜底 */ } }
    } catch { /* 忽略 */ }
    try {
        win = await b.openContainer(b.blockAt(new Vec3(cell[0], cell[1], cell[2])));
        opened = true;
        title = win?.title ?? null;
        isChest = typeof title === 'string' && /chest/i.test(title);
        if (isChest) {
            for (const it of win.items()) items.push(`${it.name}×${it.count}`);
            for (const it of win.items().filter((x) => x.name === 'gold_ingot')) {
                try { await win.take(it.type, null, it.count); } catch { /* 单个拿失败不终止 */ }
            }
        }
    } catch (e) { why = `open_threw:${String(e?.message ?? e).slice(0, 90)}`; }
    finally { try { win?.close?.(); } catch { /* 忽略 */ } }
    // 服务端真值：箱子自己的 NBT（**只读一次**，软失败不 poison 通道）
    const chestNbt = await probeBlockData(cell, 'Items');
    const got = (countItem('gold_ingot') ?? 0) - ingot0;
    return {
        cell, opened, isChest, title, items, chestNbt, why, got, ms: Date.now() - t0,
        walkMs: approach.ms, walkWhy: approach.why ?? null, dist: approach.dist, tpUsed, tpCell,
        verdict: !opened ? 'not_opened'
            : !isChest ? `opened_but_NOT_a_chest(title=${JSON.stringify(title)})`
                : (items.length === 0 ? 'empty' : (got > 0 ? 'got_gold' : 'no_gold')),
    };
}

/** 服务端读**方块自己的 NBT**（软失败）。用途：读宝箱的 `Items`
 *  —— 这正是 S2-04 §6 里「5 个箱子的 Items 全部 TRUTH_POISONED」的那条通道；
 *     当时读不到是因为 bot 没站在箱子旁边（区块未加载），现在 bot 就站在箱边。 */
async function probeBlockData(cell, path = 'Items') {
    const t = truth();
    if (!t?.dataBlock) return { readFailed: true, why: 'no_dataBlock' };
    try {
        const line = await t.dataBlock(dim(), { x: cell[0], y: cell[1], z: cell[2] }, path, { timeoutMs: 8000, soft: true });
        return { readFailed: !line, raw: line ? String(line).slice(0, 500) : null };
    } catch (e) { return { readFailed: true, err: String(e?.message ?? e).slice(0, 90) }; }
}

/** 在目标格附近找一个"脚踩实心 + 身体两格空气"的落脚点（客户端判据），供就近传送用 */
function findStandNear(cell, r = 2) {
    const b = bot();
    for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) for (let dy = 0; dy <= 2; dy++) {
        const feet = new Vec3(cell[0] + dx, cell[1] + dy, cell[2] + dz);
        const fl = b.blockAt(feet.offset(0, -1, 0));
        const a1 = b.blockAt(feet);
        const a2 = b.blockAt(feet.offset(0, 1, 0));
        if (!fl || !a1 || !a2) continue;
        if (fl.name === 'air' || fl.name.endsWith('_air') || fl.boundingBox !== 'block') continue;
        if (a1.name !== 'air' || a2.name !== 'air') continue;
        if (dx === 0 && dz === 0 && dy === 0) continue;      // 别站进目标格
        return feet;
    }
    return null;
}

/** 找一个能当放置参照的邻块 + 面偏移（`placeBlock(ref, face)` 的两个参） */
function findRef(targetCell) {
    const b = bot();
    const FACES = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
    for (const f of FACES) {
        const rp = new Vec3(targetCell[0] + f[0], targetCell[1] + f[1], targetCell[2] + f[2]);
        const rb = b.blockAt(rp);
        // 参考块必须**服务端认可的实心**、且不是要放的那格；不能是液体/空气
        if (rb && rb.name !== 'air' && !rb.name.endsWith('_air') && rb.boundingBox === 'block') {
            return { ref: rb, face: { x: f[0], y: f[1], z: f[2] }, refCell: [rp.x, rp.y, rp.z], refName: rb.name };
        }
    }
    return null;
}

/** 盖掉一格岩浆。**必须回读** —— 手册：布景没报错 ≠ 生效 */
async function coverOne(cell) {
    const before = await probeCell(cell, ['minecraft:lava', 'minecraft:cobblestone']);
    if (before.readFailed) return { cell, ok: false, why: 'readFailed', before: null };
    if (!isBlock(before, 'lava')) return { cell, ok: true, skipped: true, before: before.hit, why: 'not_lava' };
    const ref = findRef(cell);
    if (!ref) return { cell, ok: false, why: 'no_ref_block', before: before.hit };
    await walkNear(cell, 2);
    const b = bot();
    const cob = b.inventory.items().find((i) => i.name === 'cobblestone');
    if (!cob) return { cell, ok: false, why: 'no_cobblestone_in_hand', before: before.hit };
    try { await b.equip(cob, 'hand'); } catch (e) { return { cell, ok: false, why: `equip_threw:${String(e).slice(0, 60)}`, before: before.hit }; }
    if (b.heldItem?.name !== 'cobblestone') return { cell, ok: false, why: `held=${b.heldItem?.name}`, before: before.hit };
    try {
        // 不 await：mineflayer 内部死等 blockUpdate 5s；我们自己轮询方块状态判成败（照 place.js:181 的做法）
        Promise.resolve(b.placeBlock(ref.ref, ref.face)).catch(() => {});
        for (let t = 0; t <= 3000; t += 100) {
            const now = await probeCell(cell, ['minecraft:cobblestone', 'minecraft:lava']);
            if (isBlock(now, 'cobblestone')) return { cell, ok: true, before: before.hit, after: now.hit, ms: t, via: ref.refName };
            await sleep(100);
        }
        const now = await probeCell(cell, ['minecraft:cobblestone', 'minecraft:lava']);
        return { cell, ok: false, why: 'place_not_confirmed', before: before.hit, after: now.hit, via: ref.refName };
    } catch (e) { return { cell, ok: false, why: `place_threw:${String(e?.message ?? e).slice(0, 80)}`, before: before.hit }; }
}

/**
 * 挖一格。**背包真值（挖到了什么）+ 客户端方块真值（那一格变成什么）两条通道**。
 * ⚠ 不用 `probeCell` 判"那一格变成什么"：它是 **fill-replace 破坏性**的（手册 §5），
 *   对**同一个格子连着查两遍不同候选**会自相矛盾（S2-06 第一版就撞上：
 *   同一格先读出 `gold_block`、再读出 `lava`、再读出 `air`）⇒ 判成败只认 `bot.blockAt` + 背包增量。
 * ⚠ `bot.dig` 吃的是 **Block 对象**不是 Vec3（照 `smelt_task.js:408` 的 `bot.dig(bot.blockAt(pos))`）；
 *   传 Vec3 会抛 `block.digTime is not a function`。
 */
async function digOne(cell, expect, approachIn = null) {
    const b = bot();
    const pick = b.inventory.items().find((i) => i.name === 'iron_pickaxe');
    if (pick) { try { await b.equip(pick, 'hand'); } catch { /* 手上不是镐也要挖，让服务端判 */ } }
    const hadTool = b.heldItem?.name === 'iron_pickaxe';
    const before = { ingot: countItem('gold_ingot') ?? 0, block: countItem('gold_block') ?? 0 };
    // ⚠ 只走一次：调用方已经走过并（可能）tp 过了；这里再走一遍会把上一趟的 `stop()` 撞成
    //   `Path was stopped before it could be completed!`（S2-06 实跑连着三次都这样）。
    const w = approachIn ?? { ms: 0, dist: null, why: '调用方已走' };
    const distAfterWalk = w.dist;
    let dug = false, phase = null;
    const blk = b.blockAt(new Vec3(cell[0], cell[1], cell[2]));
    if (!blk) phase = 'blockAt_null(区块没加载 ≠ 方块没了)';
    else {
        try {
            await b.dig(blk);
            dug = true; phase = 'ok';
        } catch (e) { phase = `dig_threw:${String(e?.message ?? e).slice(0, 100)}`; }
    }
    const after = { ingot: countItem('gold_ingot') ?? 0, block: countItem('gold_block') ?? 0 };
    const now = b.blockAt(new Vec3(cell[0], cell[1], cell[2]));
    // ⚠⚠ **「方块没了」≠「拿到东西了」**。S2-06 实跑（16:34）：射程内 2.24 格挖掉一个真 gold_block，
    //   `dug=true`、方块变 air、背包 **+0 块 +0 锭** —— 掉落物是 2 格外的 item entity，bot 没走过去捡。
    //   与 `piglin.js` 头注「借记 ≠ 成交」**同族**：这一族全是"动作成功 ≠ 收益到手"。
    // ⇒ 挖完必须**当场捡**，捡完再判成败。（`dug` 与 `ingotGain` 单独记账，不合并成一个 ok）
    let collected = null;
    if (pig?.collectDrops) {
        const pre = (pig.listDrops?.(b, { radius: 8, max: 16 }) ?? []).length;
        collected = await pig.collectDrops(b, { radius: 8, perItemMs: 1500, timeoutMs: 5000 })
            .then((r2) => ({ picks: r2.picked?.length ?? 0, names: (r2.picked ?? []).map((x) => x.name), preDrops: pre, ms: r2.ms }))
            .catch((e) => ({ error: String(e?.message ?? e).slice(0, 90) }));
    }
    const after2 = { ingot: countItem('gold_ingot') ?? 0, block: countItem('gold_block') ?? 0 };
    return {
        cell, expect, walkMs: w.ms, walkWhy: w.why ?? null, dist: distAfterWalk,
        inReach: distAfterWalk != null && distAfterWalk <= 4.5, hadTool, dug, phase,
        ingotGain: after2.ingot - before.ingot, goldBlockGain: after2.block - before.block,
        ingotGainBeforeCollect: after.ingot - before.ingot,
        goldBlockGainBeforeCollect: after.block - before.block,
        collected,
        blockBefore: blk?.name ?? null, blockAfter: now?.name ?? null,
        blockGone: now?.name === 'air', blockReadFailed: now == null,
    };
}

/** 放工作台 + 合成。3×3 配方，背包 2×2 合成不了（这是"挖块≠有锭"的直接后果） */
async function craftIngots({ want = 4, tableCell = null } = {}) {
    const b = bot();
    const r = { placed: false, crafted: 0, why: null };
    const have = () => countItem('gold_block') ?? 0;
    if (have() <= 0) { r.why = 'no_gold_block'; return r; }
    const tab = b.inventory.items().find((i) => i.name === 'crafting_table');
    if (!tab) { r.why = 'no_crafting_table'; return r; }
    // 放工作台：优先放站位旁边一格
    let tableBlock = null;
    const cells = tableCell ? [tableCell] : [
        [P.x + 1, P.y, P.z], [P.x - 1, P.y, P.z], [P.x, P.y, P.z + 1], [P.x, P.y, P.z - 1],
    ];
    for (const c of cells) {
        const cur = await probeCell(c, ['minecraft:air', 'minecraft:crafting_table']);
        if (cur.readFailed) continue;
        if (isBlock(cur, 'crafting_table')) { tableBlock = new Vec3(c[0], c[1], c[2]); r.placed = 'already_there'; break; }
        if (!isBlock(cur, 'air')) continue;
        const ref = findRef(c);
        if (!ref) continue;
        await walkNear(c, 2);
        try { await b.equip(tab, 'hand'); } catch { continue; }
        if (b.heldItem?.name !== 'crafting_table') continue;
        try {
            Promise.resolve(b.placeBlock(ref.ref, ref.face)).catch(() => {});
            for (let t = 0; t <= 2500; t += 100) {
                const now = await probeCell(c, ['minecraft:crafting_table', 'minecraft:air']);
                if (isBlock(now, 'crafting_table')) { tableBlock = new Vec3(c[0], c[1], c[2]); r.placed = true; break; }
                await sleep(100);
            }
        } catch { /* 试下一格 */ }
        if (tableBlock) break;
    }
    if (!tableBlock) { r.why = r.why ?? 'table_not_placed'; return r; }
    await walkNear([tableBlock.x, tableBlock.y, tableBlock.z], 2);
    // gold_block → 9 gold_ingot，一次一个块（recipesFor 的第三个参是每次合成产出数）
    for (let i = 0; i < want && have() > 0; i++) {
        let recipes = null;
        try { recipes = b.recipesFor('gold_ingot', null, 9, tableBlock); } catch (e) { r.why = `recipesFor_threw:${String(e?.message ?? e).slice(0, 60)}`; break; }
        const pick = (recipes ?? []).find((x) => x.ingredients?.length >= 9) ?? (recipes ?? [])[0];
        if (!pick) { r.why = `no_recipe(inv gold_block=${have()})`; break; }
        const before = countItem('gold_ingot') ?? 0;
        try { await b.craft(pick, 1, tableBlock); } catch (e) { r.why = `craft_threw:${String(e?.message ?? e).slice(0, 80)}`; break; }
        const after = countItem('gold_ingot') ?? 0;
        if (after <= before) { r.why = `craft_no_gain(before=${before} after=${after})`; break; }
        r.crafted += after - before;
    }
    r.goldBlockLeft = have();
    r.ingots = countItem('gold_ingot') ?? 0;
    return r;
}

/**
 * 猪灵观测。**三个独立信号分列，不合并成一个"有没有被攻击"**：
 *   ① `flag`  = `metadata[14]&4`（S2-04/S2-05 用的"攻击状态"位标志）
 *   ② `hurt`  = 血量 < 16 的猪灵数（piglin.js#countAggroPiglins 的口径）
 *   ③ `hp`    = bot 自己的血量（**唯一的硬线**；派单说的"服务端死亡消息"是它的终态）
 * 理由：S2-06 第一版实测出现 `flag=5/8~10 头` 而 `hp 一直是 20、零死亡` ⇒
 *   **这三个信号在本工作点会互相矛盾**，只报一个就是把"未知"折算成"否"（手册 §5）。
 */
function makeAggroProbe({ everyMs = 700, radius = 16 } = {}) {
    const rows = [];
    const sample = (tag) => {
        const b = bot();
        if (!b) return null;
        const me = botPos();
        if (!me) return null;
        let near = 0, flag = 0, hurt = 0, unread = 0;
        for (const e of Object.values(b.entities)) {
            if (e.name !== 'piglin') continue;
            if (e.position.distanceTo(me) > radius) continue;
            near++;
            const md = e.metadata;
            const mdHp = md?.[8];
            if (typeof mdHp === 'number' && mdHp < 16) hurt++;
            if (!md || md[14] == null) { unread++; continue; }
            if (md[14] & 4) flag++;
        }
        const row = {
            t: Date.now(), tag, near, flag, hurt, unread, hp: b.health,
            at: [+me.x.toFixed(1), +me.y.toFixed(1), +me.z.toFixed(1)],
        };
        rows.push(row);
        return row;
    };
    const timer = setInterval(() => { if (rows.length < 600) sample('tick'); }, everyMs);
    timer.unref?.();
    return { rows, sample, stop: () => clearInterval(timer) };
}

async function oneRun(runIdx) {
    const w = watchDeaths();
    const aggro = makeAggroProbe({ everyMs: AGGRO_EVERY });
    const ex = loadExact();
    const out = { run: runIdx, stamp: STAMP, mode: MODE, mitigate: MITIGATE, exactPath: EXACT_PATH };
    const finish = (why) => {
        aggro.stop(); w.stop();
        if (out.aggro) out.aggro = aggroSummary(aggro.rows, { sinceT0: out.t0 });
        out.tSec = out.t0 != null ? +((Date.now() - out.t0) / 1000).toFixed(1) : null;
        out.deaths = w.deaths;
        return { ...out, aborted: out.aborted ?? why };
    };

    // ── 阶段 0：进场 + 落脚验真（**t0 就取在验真通过的这一瞬**）────────────
    // ⚠ `parkSafe` 走 `truth.probeCell`（fill-replace 真值通道），实测会**偶发**返回 null
    //   ⇒ `PARK_VERIFY_FAILED: feet=null`（S2-06J 第 2/3 局连续两次）。
    //   这属于**读失败**而不是"落位点没有地板"（手册 §5）⇒ 最多重试 3 次，别直接崩掉整局。
    let park = null, parkWhy = null;
    for (let k = 0; k < 3; k++) {
        try { park = await parkSafe({ cx: P.x, cz: P.z, yLo: P.y - 8, yHi: 100, r: 4 }); parkWhy = null; break; }
        catch (e) { parkWhy = String(e?.message ?? e).slice(0, 110); log(`[进场] 第 ${k + 1} 次 parkSafe 失败：${parkWhy}（重试）`); await sleep(2500); }
    }
    if (!park) { out.aborted = `PARK_FAILED:${parkWhy}`; log(`[中止] ${out.aborted}`); return finish(); }
    await sleep(2500);
    const standCell = ex.stand[0];
    await recallTo(standCell, { label: 'S3-arrive' });
    // ⚠ 落脚验真用**客户端** `blockAt`（非破坏），服务端 `probeCell` 只做**一次**交叉验。
    //   S2-06K 第 2/3 局：`probeCell` 连着两局返回 `feet=null`（fill-replace 真值通道在
    //   同一世界连局时不稳定）⇒ 被我判成 `ARRIVAL_NOT_VERIFIED` 而白丢两局。
    //   **读失败 ≠ 落位点不对**（手册 §5）⇒ 客户端读数为主、服务端为辅。
    const bA = bot();
    const cFeet = bA.blockAt(new Vec3(standCell[0], standCell[1], standCell[2]));
    const cFloor = bA.blockAt(new Vec3(standCell[0], standCell[1] - 1, standCell[2]));
    const feet = await probeCell(standCell, ['minecraft:air']);
    const floor = await probeCell([standCell[0], standCell[1] - 1, standCell[2]],
        ['minecraft:netherrack', 'minecraft:blackstone', 'minecraft:basalt', 'minecraft:soul_soil',
            'minecraft:crimson_nylium', 'minecraft:warped_nylium', 'minecraft:blackstone_bricks',
            'minecraft:polished_blackstone_bricks', 'minecraft:cracked_polished_blackstone_bricks',
            'minecraft:blackstone', 'minecraft:magma_block']);
    const foot = footingOk(botPos());
    out.arrival = {
        standCell,
        clientFeet: cFeet?.name ?? null, clientFeetReadFailed: cFeet == null,
        clientFloor: cFloor?.name ?? null, clientFloorReadFailed: cFloor == null,
        serverFeet: feet.hit, serverFeetReadFailed: feet.readFailed,
        serverFloor: floor.hit, serverFloorReadFailed: floor.readFailed,
        footing: foot,
    };
    const clientOk = cFeet?.name === 'air' && cFloor != null && cFloor.name !== 'air'
        && !cFloor.name.endsWith('_air') && cFloor.boundingBox === 'block';
    log(`[到达] stand=${standCell} 客户端 feet=${cFeet?.name ?? 'null'} floor=${cFloor?.name ?? 'null'} `
        + `服务端 feet=${feet.hit}${feet.readFailed ? '(读失败)' : ''} floor=${floor.hit}${floor.readFailed ? '(读失败)' : ''} `
        + `四点支撑=${foot.ok ? 'OK' : foot.why}`);
    if (!clientOk) { out.aborted = 'ARRIVAL_NOT_VERIFIED(客户端方块读数不过)'; log(`[中止] ${out.aborted}`); return finish(); }
    out.t0 = Date.now();                       // ★ 计时起点
    aggro.sample('arrive');

    // ── 阶段 1：真实前置状态（不是 kit）────────────────────────────────────
    const invAtArrive = invCount();
    // ⚠ harness 的 `kit(items)` 吃的是 **`'name:count'` 字符串数组**，不是元组数组。
    //   （照 S2-04 的 `give` 教训：给完必须回读，`kit()` 自己的 verify 只看"背包非空"，等于没验。）
    const ge = await giveAndEquip(PRIOR);
    out.prereq = { invAtArrive, give: PRIOR.map((p) => `${p[0]}×${p[1]}`), ...ge };
    log(`[前置] 到站背包=${JSON.stringify(invAtArrive)} 服务端背包真值=${JSON.stringify(ge.invTruth?.invOnly ?? null)}`);
    log(`[前置] 缺=${JSON.stringify(ge.stillMissing)} 穿上金护腿=${ge.equipped} 装备槽有金=${ge.wearingGoldArmor}`);
    for (const t of ge.steps) log(`[前置]   ${t}`);
    if (!ge.wearingGoldArmor) {
        // 派单的前提是「穿着金甲」。前提不成立就跑 ⇒ 出来的是"没穿金甲"的数据，
        // 会被误读成"金甲挡不住" —— 与 S2-04 那个错误结论**同型**。所以这里**停下**。
        out.aborted = 'GOLD_ARMOR_NOT_ON_SERVER(passive-aggro 前提不成立)';
        log('[前置] ⚠⚠ 服务端装备槽没有金质护甲 ⇒ 停：本局测不了"穿金甲会不会被打"');
        return finish();
    }
    const armor = ge.armorTruth;

    // ── 阶段 2：盖岩浆（S3 exact 的规避动作）──────────────────────────────
    out.cover = [];
    if (MITIGATE) {
        // ⚠ SCHEMA §5 的 `hazards` 是**纯坐标数组** `[x,y,z]`（与 C 线 S1_portal 的写法一致），
        //   不是对象。第一版按 `{xyz}` 读，跑起来是 `undefined` —— 又是一次"读成 undefined 也不报错"。
        for (const hz of ex.hazards) {
            const cell = Array.isArray(hz) ? hz : hz?.xyz;
            if (!cell) { out.cover.push({ cell: null, ok: false, why: `hazards 项不是坐标也不是 {xyz}：${JSON.stringify(hz)}` }); continue; }
            const r = await coverOne(cell);
            out.cover.push(r);
            log(`[盖岩浆] ${cell} ${r.before} → ${r.after ?? '-'} ok=${r.ok} ${r.why ?? ''}`);
        }
    } else { out.cover = [{ skipped: true, why: '--no-mitigate 对照组' }]; log('[盖岩浆] 跳过（对照组）'); }
    out.msToCover = Date.now() - out.t0;

    // ── 阶段 3：★ 金源**主路 = 开宝藏箱**（2026-10-03 设计会话裁决）──────────
    //   理由：破坏 guarded_by_piglins 方块 = 16 格内全部 idle 猪灵 + 无视线 + ANGRY_AT 不看金甲；
    //   开箱走 ChestBlock.java:240（要视线）且直接给金锭。开够锭就**不去挖金块**。
    out.chests = [];
    aggro.sample('pre-chest');
    const INGOT_NEED = Math.ceil(GOAL / 0.2837);       // 派单口径：0.2837 颗/锭 ⇒ 10 颗要 36 锭
    for (const tg of ex.targets.filter((t) => t.what === 'chest')) {
        if ((countItem('gold_ingot') ?? 0) >= INGOT_NEED) { out.chests.push({ cell: tg.xyz, skipped: true, why: `已够锭（${countItem('gold_ingot')} ≥ ${INGOT_NEED}）` }); continue; }
        const r = await openChestGold(tg.xyz);
        out.chests.push(r);
        aggro.sample('post-chest');
        log(`[开箱] ${tg.xyz} ${r.verdict} 拿到 ${r.got} 锭 箱内=${JSON.stringify(r.items)} `
            + `走=${r.walkMs}ms(${r.dist}格${r.tpUsed ? ' tp' : ''}) 累计 ${((Date.now() - out.t0) / 1000).toFixed(1)}s`);
        if (w.deaths.length) { out.aborted = `DEATH_WHILE_CHEST:${w.deaths[0].cause}`; break; }
    }
    out.msToChestsDone = Date.now() - out.t0;
    out.ingotsFromChests = countItem('gold_ingot') ?? 0;
    log(`[开箱段小结] ${(out.msToChestsDone / 1000).toFixed(1)}s 共 ${out.ingotsFromChests} 锭（要 ${INGOT_NEED}）死亡=${w.deaths.length}`);
    if (out.aborted) return finish();

    // ── 阶段 3b：**备选**金源 = 挖金块（开箱没凑够锭时才做）────────────────
    out.dig = [];
    aggro.sample('pre-dig');
    for (const tg of ex.targets.filter((t) => t.what === 'dig')) {
        if ((countItem('gold_ingot') ?? 0) >= INGOT_NEED) { out.dig.push({ cell: tg.xyz, skipped: true, why: '开箱已够锭，跳过备选金源' }); continue; }
        if ((countItem('gold_block') ?? 0) >= 4) { out.dig.push({ cell: tg.xyz, skipped: true, why: '已有 4 个金块，够合成，跳过' }); continue; }
        if (!tg.xyz) { out.dig.push({ cell: null, skipped: true, why: 'exact 占位' }); continue; }
        // 预判用**客户端**方块真值（非破坏）；服务端 probeCell 只在**单次**确认里用
        const bNow = bot();
        const preBlk = bNow.blockAt(new Vec3(tg.xyz[0], tg.xyz[1], tg.xyz[2]));
        if (preBlk == null) {
            out.dig.push({ cell: tg.xyz, skipped: true, why: 'blockAt=null（区块未加载 ⇒ 不知道，不等于没有）' });
            log(`[挖] ${tg.xyz} 跳过：blockAt=null（区块没加载）`);
            continue;
        }
        if (preBlk.name !== shortName(tg.expect)) {
            out.dig.push({ cell: tg.xyz, skipped: true, why: `客户端方块=${preBlk.name}（期望 ${shortName(tg.expect)}）` });
            log(`[挖] ${tg.xyz} 跳过：客户端方块是 ${preBlk.name}（期望 ${shortName(tg.expect)}）`);
            continue;
        }
        const beforeHp = bot()?.health;
        // 开发期：S3 站的金块在作业位西南 12 格外、**低两层**，走路走不通（见 walkNear 注释）。
        // 先试走；走不到就**就近传送**到金块旁的可站格（开发期布景，正式局无此步）。
        let approach = await walkNear(tg.xyz, 2);
        let tpUsed = false, tpCell = null;
        const far = approach.dist == null || approach.dist > 4.5;
        if (far && TP_DIG) {
            const spot = findStandNear(tg.xyz, 3);
            if (spot) {
                await recallTo([spot.x, spot.y, spot.z], { label: 'dig-approach' });
                await sleep(900);
                tpUsed = true; tpCell = [spot.x, spot.y, spot.z];
                const me2 = botPos();
                approach = { ...approach, dist: me2 ? +Math.hypot(me2.x - tg.xyz[0] - 0.5, me2.y - tg.xyz[1], me2.z - tg.xyz[2] - 0.5).toFixed(2) : null, why: 'tp 到位' };
            }
        }
        const r = await digOne(tg.xyz, tg.expect, approach);
        r.walkMs = approach.ms; r.walkWhy = approach.why ?? null; r.distBeforeDig = approach.dist;
        r.tpUsed = tpUsed; r.tpCell = tpCell; r.inReach = r.dist != null && r.dist <= 4.5;
        r.hpBefore = beforeHp; r.hpAfter = bot()?.health;
        out.dig.push(r);
        aggro.sample('post-dig');
        log(`[挖] ${tg.xyz} 走=${r.walkMs}ms(${approach.dist}格${tpUsed ? ` **tp 到 ${tpCell}` : ''} ${approach.why ?? ''}) `
            + `挖到=${r.dug} 在射程内=${r.inReach}(挖时 ${r.dist}格) **金块+${r.goldBlockGain} 金锭+${r.ingotGain}** `
            + `${r.blockBefore}→${r.blockAfter} hp ${beforeHp}→${r.hpAfter}`);
        if (w.deaths.length) { out.aborted = `DEATH_WHILE_DIGGING:${w.deaths[0].cause}`; break; }
    }
    out.msToDigDone = Date.now() - out.t0;
    out.afterDigInv = invCount();
    out.aggro = aggroSummary(aggro.rows, { sinceT0: out.t0 });
    log(`[挖段小结] ${out.msToDigDone / 1000}s 攻击态采样 flag=${out.aggro.flagSamples}/${out.aggro.samples} 掉血拍=${out.aggro.hpDamagedSamples} 最低血量=${out.aggro.hpMin} 死亡=${w.deaths.length}`);

    // ── 阶段 4：合成金块 → 金锭（★"4 块 ≈ 35 锭"的真值在这一段）──────────
    out.craft = await craftIngots({ want: 4 });
    out.msToCraft = Date.now() - out.t0;
    log(`[合成] ${JSON.stringify(out.craft)}  累计 ${out.msToCraft / 1000}s`);
    out.ingotsForBarter = countItem('gold_ingot') ?? 0;

    if (DIG_ONLY) { return finish('DIG_ONLY_DONE'); }
    if (out.aborted) return finish();
    if (out.ingotsForBarter <= 0) {
        out.aborted = `NO_INGOTS(gold_block=${countItem('gold_block') ?? 0})`;
        log(`[中止] 背包里一锭都没有（金块 ${countItem('gold_block') ?? 0} 个）⇒ 易物段无法开跑`);
        return finish();
    }

    // ── 阶段 5：回作业位 + approach 模式易物到 GOAL 颗珍珠 ────────────────
    const standGuard = makeStandGuard(standCell, { r: 6.0, dy: 3.0 });
    await walkNear(standCell, 1);
    out.msToBackHome = Date.now() - out.t0;
    aggro.sample('pre-barter');

    const pearlsInv0 = countItem('ender_pearl') ?? 0;
    const ingots0 = countItem('gold_ingot') ?? 0;
    const ev = {};
    const engine = new pig.BarterEngine(bot(), {
        slots: N, mode: MODE, tickMs: 25, collect: true, harvestEveryRounds: 8,
        approachStandoff: 2.8, approachMoveMs: 9000, approachRetargetMs: 1000, approachRange: 2, approachLeash: 6.5,
        guard: () => makeDeathGuard(w)() ?? standGuard.guard(),
        onEvent: (e2) => { ev[e2.phase] = (ev[e2.phase] ?? 0) + 1; },
    });
    const bound = engine.bind();
    let reachedMs = null;
    const rep = await engine.run({
        windowMs: Math.round(PEARL_MIN * 60000),
        shouldStop: () => {
            const got = (countItem('ender_pearl') ?? 0) - pearlsInv0;
            if (got >= GOAL && reachedMs == null) reachedMs = Date.now() - out.t0;
            return makeDeathGuard(w)() ?? standGuard.guard();
        },
    });
    const h = await engine.harvest();
    standGuard.stop();
    aggro.sample('after-barter');

    const pearlsEnd = countItem('ender_pearl') ?? 0;
    const ingotsEnd = countItem('gold_ingot') ?? 0;
    out.barter = {
        bound, pearlsInv0, pearlsEnd, pearls: pearlsEnd - pearlsInv0,
        ingots0, ingotsEnd, ingotsSpent: Math.max(0, ingots0 - ingotsEnd),
        throws: rep.throws, throwsOk: rep.throwsOk, throwsPerMin: rep.throwsPerMin,
        approach: rep.approach, phases: ev,
        harvest: { gained: h.gained, ms: h.ms, freed: h.freed },
        cycleAvgMs: rep.cycleAvgMs, misses: rep.misses, rebind: rep.rebind,
    };
    out.reachedSec = reachedMs != null ? +(reachedMs / 1000).toFixed(1) : null;
    out.success = reachedMs != null;
    log(`[易物] ${pearlsEnd - pearlsInv0} 颗珍珠 投锭=${rep.throwsOk}(${rep.throwsPerMin}/分) `
        + `走近=${JSON.stringify(rep.approach)} 用时=${out.reachedSec ?? '未达标'}s 死亡=${w.deaths.length}`);
    return finish();
}

function aggroSummary(rows, { sinceT0 = null } = {}) {
    // ⚠ 站位漂移只统计 **t0 之后**的样本：parkSafe 是从 y=100 缓降下来的，
    //   把下降段算进漂移会得到 maxDrift=43 这种"站位守护失职"的假象（S2-06 第一版的错）。
    const r = sinceT0 ? rows.filter((x) => x.t >= sinceT0) : rows;
    return {
        samples: r.length,
        nearMax: r.length ? Math.max(...r.map((x) => x.near)) : 0,
        nearLast: r.length ? r[r.length - 1].near : null,
        flagSamples: r.filter((x) => x.flag > 0).length,
        flagMax: r.length ? Math.max(...r.map((x) => x.flag)) : 0,
        hurtSamples: r.filter((x) => x.hurt > 0).length,
        unreadSamples: r.filter((x) => x.unread > 0).length,
        hpMin: r.length ? Math.min(20, ...r.map((x) => (x.hp == null ? 20 : x.hp))) : null,
        hpDamagedSamples: r.filter((x) => x.hp != null && x.hp < 20).length,
        maxDrift: r.length ? +Math.max(...r.map((x) =>
            Math.hypot(x.at[0] - (P.x + 0.5), x.at[1] - P.y, x.at[2] - (P.z + 0.5)))).toFixed(2) : null,
        rows: r.slice(0, 250),
    };
}

/** 派单裁决 ①：两个量**分别报**（时间指标按全部 trial，未达标记预算值 —— 手册 §5） */
function summarize(runs) {
    const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
    const tAll = runs.map((r) => r.reachedSec ?? PEAL_BUDGET());
    const okSec = runs.map((r) => r.reachedSec).filter((x) => x != null);
    const sorted = tAll.slice().sort((a, b) => a - b);
    const pct = (q) => (sorted.length ? sorted[Math.min(sorted.length - 1, Math.floor(q * (sorted.length - 1)))] : null);
    const perMin = runs.map((r) => r.barter?.throwsPerMin).filter((x) => x != null);
    const ypi = runs.filter((r) => r.barter?.ingotsSpent > 0).map((r) => +(r.barter.pearls / r.barter.ingotsSpent).toFixed(3));
    return {
        n: runs.length,
        nOk: okSec.length,
        aborted: runs.filter((r) => r.aborted).map((r) => r.aborted),
        deaths: runs.reduce((a, r) => a + (r.deaths?.length ?? 0), 0),
        deathsByCause: runs.flatMap((r) => (r.deaths ?? []).map((d) => `${d.who} ${d.cause}`)),
        throughputPerMin: { mean: mean(perMin)?.toFixed(2) ?? null, all: perMin },
        yieldPerIngot: { mean: mean(ypi)?.toFixed(3) ?? null, all: ypi },
        wallSec: {
            E_all: mean(tAll)?.toFixed(1) ?? null, P50: pct(0.5), P90: pct(0.9),
            E_okOnly: mean(okSec)?.toFixed(1) ?? null,
            goalSec: GOAL_SEC, underGoal: okSec.filter((x) => x <= GOAL_SEC).length, budgetSec: PEAL_BUDGET(),
        },
        chests: runs.map((r) => (r.chests ?? []).map((c) => c?.verdict ?? null).filter(Boolean)),
        chestIngots: runs.map((r) => r.ingotsFromChests ?? null),
        chestDeaths: runs.map((r) => r.chests?.length ?? 0),
        digOk: runs.map((r) => (r.dig ?? []).filter((d) => d.dug).length),
        digGoldBlockGain: runs.map((r) => (r.dig ?? []).reduce((a, d) => a + (d.goldBlockGain ?? 0), 0)),
        digIngotGain: runs.map((r) => (r.dig ?? []).reduce((a, d) => a + (d.ingotGain ?? 0), 0)),
        craft: runs.map((r) => r.craft),
        cover: runs.map((r) => r.cover).filter((c) => c?.length),
        armor: runs.map((r) => r.prereq?.armorTruth?.wearingGoldArmor),
        approach: runs.map((r) => r.barter?.approach).filter(Boolean),
        aggro: runs.map((r) => r.aggro && { samples: r.aggro.samples, flagSamples: r.aggro.flagSamples, flagMax: r.aggro.flagMax, hpMin: r.aggro.hpMin, hpDamagedSamples: r.aggro.hpDamagedSamples, nearMax: r.aggro.nearMax, maxDrift: r.aggro.maxDrift }),
    };
}
const PEAL_BUDGET = () => PEARL_MIN * 60;

async function main() {
    await openRun(STAMP);
    try {
        pig = await import(moduleUrl('src/agent/tasks/exec/piglin.js'));
        await bootWorld({ difficulty: 'easy' });
        log(`[cfg] stand=${P.x},${P.y},${P.z} 模式=${MODE} 目标=${GOAL}颗/${GOAL_SEC}s 局数=${RUNS} 盖岩浆=${MITIGATE} digOnly=${DIG_ONLY} N=${N}`);
        log(`[cfg] 真实前置：${PRIOR.map((p) => p[0]).join(' ')}`);
        log(`[cfg] ★ 1.16.1 挖 gold_block 掉的是**金块**不是金锭（jar loot table 逐字核对）⇒ 挖金与拿锭分两段`);
        const runs = [];
        for (let i = 1; i <= RUNS; i++) {
            log(`\n──── 第 ${i}/${RUNS} 局 ────`);
            // ⚠ S2-06 第一版没包 try/catch ⇒ 第 2 局 `parkSafe` 抛 `PARK_VERIFY_FAILED`
            //   就把整个矩阵带走了，第 3 局**一次都没跑**（而日志里只看得见"崩了"，
            //   很容易读成"跑完了"）。**一局崩了不许带走后面的局。**
            let r;
            try { r = await oneRun(i); }
            catch (e) {
                r = { run: i, stamp: STAMP, aborted: `RUN_THREW:${String(e?.message ?? e).slice(0, 120)}`, tSec: null, deaths: [], chests: [], dig: [] };
                log(`[崩] 第 ${i} 局抛出：${e?.message ?? e}`);
            }
            runs.push(r);
            record('s3_run', r);
            if (r.aborted) log(`[中止] ${r.aborted}`);
            if (r.deaths?.length) log(`[死亡] ${JSON.stringify(r.deaths)}`);
        }
        const s = summarize(runs);
        record('s3_summary', s);
        console.log('\n══ S3_bastion 整链段结果 ══');
        console.log(`  跑完 ${s.n} 局，中止 ${s.aborted.length}：${JSON.stringify(s.aborted)}`);
        console.log(`  死亡 ${s.deaths} ${JSON.stringify(s.deathsByCause)}   金甲前提=${JSON.stringify(s.armor)}`);
        console.log(`  挖到金块/局=${JSON.stringify(s.digGoldBlockGain)} 金锭/局=${JSON.stringify(s.digIngotGain)} 合成=${JSON.stringify(s.craft)}`);
        console.log(`  ①每分钟成交次数 = ${s.throughputPerMin.mean}  ${JSON.stringify(s.throughputPerMin.all)}`);
        console.log(`  ②每锭产珍珠     = ${s.yieldPerIngot.mean}  ${JSON.stringify(s.yieldPerIngot.all)}`);
        console.log(`  墙钟 E=${s.wallSec.E_all}s P50=${s.wallSec.P50}s P90=${s.wallSec.P90}s（未达标记 ${s.wallSec.budgetSec}s）进 ${GOAL_SEC}s 的局=${s.wallSec.underGoal}/${s.nOk}`);
        console.log(`  走近账=${JSON.stringify(s.approach)}`);
        console.log(`  攻击态/血量=${JSON.stringify(s.aggro)}`);
        writeSummary({ stamp: STAMP, mode: MODE, mitigate: MITIGATE, goal: GOAL, goalSec: GOAL_SEC, summary: s });
    } finally {
        await closeRun();
    }
}

let pig = null;
if (process.argv.includes('--dry')) {
    const ex = loadExact();
    console.log(`[dry] 解析通过：stand=${JSON.stringify(ex.stand)} 目标=${ex.targets.length}（占位 ${ex.targets.filter((t) => !t.xyz).length}） `
        + `岩浆=${ex.hazards.length} 模式=${MODE} 局数=${RUNS} 目标=${GOAL}颗/${GOAL_SEC}s 盖岩浆=${MITIGATE}`);
    console.log(`[dry] exact=${EXACT_PATH}`);
} else {
    main().catch((e) => { console.error(`[FAIL] ${e?.stack ?? e}`); process.exitCode = 1; });
}
