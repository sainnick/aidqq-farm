// probe_b1_fiddle.mjs — MC-S2-01 · B1：把玩时长（n≥20）+ 投掷距离标定 + **ROUND5 §F 两条定案遥测**
//
// ── 本单要回答的全部问题 ──────────────────────────────────────────────
// ① **把玩时长**：理论 125 tick ≈ 6.5s（rmalde 参数，未核验）；**研究线核出 120 tick = 6.0s**。
//    实测对上哪一个（并且按实测 TPS 换算，不用"tick × 50ms"）。
// ② **槽周期**（吞吐真正的分母）：出手 → 可以再投 = 飞行/捡起延迟 + 把玩 + 重投延迟。
// ③ **投掷距离**：借记（背包减 1）≠ 成交；猪灵只捡落点够近的。量"成交率-距离"曲线。
// ④ 🚨 **ROUND5 §F 疑点一**：把玩结束时**到底有没有掉落物生成**？
//    字节码结论说"不会抛礼物"（若成立则 1.16.1 根本不能易物，与全部 1.16.1 速通事实矛盾）。
//    判据：**掉落物实体出现的 tick**（服务端 `ItemEntity.Age` 反推，精确到 tick）
//          与**猪灵手里东西清空的 tick**（`HandItems[0/1].id` 轮询，给出区间）是否同一 tick。
// ⑤ 🚨 **ROUND5 §F 疑点二**：右键喂锭**前后背包金锭数**（字节码说 `copyWithCount(1)` 不消耗 ——
//    `copyWithCount` 是 1.20+ 才有的方法名，出现在 1.16.1 分析里就说明映射混了版本）。
//    另加**扔锭对照**（Q 丢在地上）：同样看金锭数与掉落物，两条路径互证计数读数没错。
//
// 泳道只有 C。用法：node probe_b1_fiddle.mjs [--stamp S2_B1] [--trials 20] [--resistance 1]

import {
    openRun, bootWorld, closeRun, cmd, truth, bot, botPos, posStr, dim,
    kit, invCount, record, writeSummary, sleep, parkSafe, standNatural, approachPiglins, recall,
    LANE, STATION, SEED, argv, moduleUrl, Vec3,
} from './harness.mjs';
import { parseAge } from './truth.mjs';

const STAMP = argv('stamp', 'S2_B1');
const TRIALS = parseInt(argv('trials', '20'), 10);
const RESIST = argv('resistance', '0') === '1';
const S = STATION.bastion;
const HAND_POLL_MS = parseInt(argv('hand-poll', '350'), 10);

let pig = null;
const sleep2 = sleep;
async function loadPrimitives() { pig = await import(moduleUrl('src/agent/tasks/exec/piglin.js')); }

async function serverCount(sel = '@e[type=piglin]') {
    const r = await truth().countEntities('the_nether', LANE.username, sel, { quietMs: 500, minWaitMs: 6000, timeoutMs: 25000 });
    return { n: r.n, trusted: r.trusted };
}
async function resetGround({ keepPiglins = false } = {}) {
    cmd('execute in minecraft:the_nether run kill @e[type=item]');
    if (!keepPiglins) cmd('execute in minecraft:the_nether run kill @e[type=piglin]');
    await sleep2(1000);
}
async function summonAt(x, y, z) {
    const before = new Set(Object.values(bot().entities ?? {}).map((e) => e.id));
    cmd(`execute in minecraft:the_nether run summon minecraft:piglin ${x.toFixed(2)} ${y.toFixed(2)} ${z.toFixed(2)}`);
    // ⚠ 必须按**位置**认领，不能只看"新 id"：世界里在自然刷猪灵，客户端实体表里不断有
    //   新 piglin 进来（S2_B1 首版因此把一只 105 格外的自然猪灵当成 fixture 投了 too_far）。
    for (let i = 0; i < 60; i++) {
        await sleep2(100);
        const cand = Object.values(bot().entities ?? {}).find((e) => e.name === 'piglin' && !before.has(e.id)
            && Math.abs(e.position.x - x) < 2 && Math.abs(e.position.z - z) < 2
            && Math.abs(e.position.y - y) < 2.5);
        if (cand) return cand;
    }
    return null;
}

/** 往回包里补锭（B1 一共要投 20–30 块） */
async function topUpIngots() {
    if (pig.countIngots(bot()) >= 12) return pig.countIngots(bot());
    cmd(`give ${LANE.username} minecraft:gold_ingot 64`);
    await sleep2(1400);
    return pig.countIngots(bot());
}

/**
 * ⑤ 的**扔锭对照**：Q 键把金锭丢在地上，看金锭数与掉落物。
 * mineflayer 4.38 没有 bot.toss ⇒ 直接发 1.16.1 的 block_dig(status=4)。
 * 失败是**显式**的：protodef 字段不对会抛错（不会静默丢包），错了就如实记 error。
 */
async function dropItemControl() {
    const t = truth();
    const rec = { action: 'press_Q_drop', before: pig.countIngots(bot()), drops: 0, after: null, err: null };
    const beforeDrops = new Set(pig.listDrops(bot(), { radius: 12 }).map((d) => d.e.id));
    try {
        const it = bot().inventory.items().find((i) => i.name === 'gold_ingot');
        if (!it) return { ...rec, err: 'no_ingot' };
        await bot().equip(it, 'hand');
        const p = botPos();
        bot()._client.write('block_dig', {
            status: 4,                                    // 4 = drop item（1.16.1）
            location: { x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z) },
            face: 1, heldItem: 1,
        });
        await sleep2(2000);
        rec.after = pig.countIngots(bot());
        rec.drops = pig.listDrops(bot(), { radius: 12 }).filter((d) => !beforeDrops.has(d.e.id)).length;
        rec.newDropNames = pig.listDrops(bot(), { radius: 12 }).filter((d) => !beforeDrops.has(d.e.id)).map((d) => d.name);
        rec.debited = rec.before - rec.after;
    } catch (e) { rec.err = String(e).slice(0, 160); }
    console.log(`[扔锭对照] ${JSON.stringify(rec)}`);
    return rec;
}

/**
 * 一次完整时序测量（含 ROUND5 的两条定案遥测）。
 * 观测点（全部记 tick，用实测 TPS 换算，不用 tick×50ms）：
 *   t_throw    出手（借记成立）
 *   t_ingot    **投出的金锭物品实体出现**（服务端生成，客户端可见）
 *   t_pickup   **该物品实体消失** = 猪灵捡起（捡起延迟 = t_pickup − t_ingot）
 *   t_drop     **掉落物实体出现**（把玩结束）
 *   t_hand*    猪灵 HandItems[0/1] 从 gold_ingot 变回 air 的区间（服务端轮询）
 *   dropAge    掉落物 ItemEntity.Age ⇒ 掉落生成的**精确 tick**（G_read − Age）
 */
async function measureThrow(e, { tag = 't', source = 'natural', waitMs = 20000, handPollMs = HAND_POLL_MS } = {}) {
    const t = truth();
    const me = botPos();
    const dist0 = e.position.distanceTo(me);
    const tps = t.clock.tps() ?? 20;

    // ── 服务端低频对账：猪灵手里（主手 0 / 副手 1）有什么 ──────────────
    // ⚠ **1.16.1 的 `data get` 不接受带方括号的路径**（`HandItems[0].id` 回
    //   "Incorrect argument for command"，是**解析期**失败不是查不到）⇒ 读整份 `HandItems` 自己解析。
    //   （此前以为这条通道可用，是因为探针把**上一条命令的迟到回执**当成了本条的 —— 探针本身有假阳性。）
    const handLog = [];
    let handStop = false;
    const parseHands = (line) => {
        if (!line) return { main: 'no_receipt', off: 'no_receipt' };
        const ids = [...line.matchAll(/minecraft:([a-z_0-9]+)/g)].map((m) => m[1]);
        // HandItems 是 [主手, 副手]；只取前两个物品名
        return { main: ids[0] ?? 'air', off: ids[1] ?? 'air' };
    };
    const handTask = (async () => {
        while (!handStop) {
            const at = t.clock.now();
            let h = { main: 'err', off: 'err' };
            try {
                const l = await t.dataEntity('the_nether', LANE.username, '@e[type=piglin,limit=1]', 'HandItems', { timeoutMs: 6000, soft: true });
                h = parseHands(l);
            } catch { /* 保持 err */ }
            handLog.push({ ms: Date.now(), tick: at, ...h });
            await sleep2(handPollMs);
        }
    })();

    const beforeDrops = new Map(pig.listDrops(bot(), { radius: 16 }).map((d) => [d.e.id, d.name]));
    const ingots0 = pig.countIngots(bot());
    const r = await pig.throwIngot(bot(), e, { minDist: 1.0, maxDist: 4.0, debitTimeoutMs: 2500 });
    const tThrow = Date.now();
    const ingots1 = pig.countIngots(bot());
    if (!r.ok) {
        handStop = true; await handTask;
        return { tag, source, ok: false, phase: r.phase, dist0: +dist0.toFixed(2), aimMs: r.aimMs, ingots0, ingots1 };
    }

    // ── 高频采样：物品实体的出现/消失 **+ 背包增量** ─────────────────
    //  ⚠ 为什么要"背包增量"这条兜底（S2_B1 实测踩到）：礼物落在**bot 拾取半径内**时
    //    （投掷距离 ≤2.5 格 ⇒ 礼物落点离 bot 常常 <1 格），服务器同 tick 就把
    //    ItemEntity 收进玩家背包 ⇒ 客户端**根本看不到那个掉落物实体**
    //    ⇒ 实测同一批里 2.5 格"捡起了但没掉落"，3.29 格有掉落。
    //    所以"成交"判据要两条任一：① 新的掉落物实体出现；② bot 背包多出东西。
    const invSig = () => JSON.stringify(pig.listDrops ? Object.keys(bot().inventory.items().reduce((a, i) => { a[i.name] = (a[i.name] ?? 0) + i.count; return a; }, {})) : []);
    const inv0sig = invSig();
    let tInvGain = null, invGain = null;
    let tIngot = null, tPickup = null, ingotId = null;
    let tDrop = null, dropInfo = null, dropId = null;
    const t1 = Date.now();
    while (Date.now() - t1 < waitMs) {
        for (const d of pig.listDrops(bot(), { radius: 16 })) {
            if (beforeDrops.has(d.e.id)) continue;
            if (ingotId == null && (d.name === 'gold_ingot' || d.d < 3.0)) {
                ingotId = d.e.id; tIngot = Date.now();
                continue;
            }
            if (d.e.id !== ingotId && tDrop == null) {
                dropId = d.e.id; tDrop = Date.now();
                dropInfo = {
                    name: d.name, count: d.count,
                    dFromPiglin: +d.e.position.distanceTo(e.position).toFixed(2),
                    dFromBot: +d.d.toFixed(2),
                    pos: [+d.e.position.x.toFixed(2), +d.e.position.y.toFixed(2), +d.e.position.z.toFixed(2)],
                };
            }
        }
        // 投出的金锭实体消失 = 猪灵捡起来了
        if (ingotId != null && tPickup == null && !bot().entities[ingotId]) tPickup = Date.now();
        // 背包增量（礼物被 bot 瞬间收走的情形）
        if (tInvGain == null && invSig() !== inv0sig) { tInvGain = Date.now(); invGain = invSig(); }
        if (tDrop != null && (tPickup != null || Date.now() - tDrop > 1500)) break;
        if (tInvGain != null && tDrop == null && Date.now() - tInvGain > 300) break;
        await sleep2(40);
    }
    handStop = true;
    await handTask;

    // ── 掉落物生成时刻的**服务端精确 tick**（ItemEntity.Age 反推）─────
    let dropTruth = null;
    try {
        const g = await t.gametime('the_nether');
        const ra = await t.dataEntity('the_nether', LANE.username, '@e[type=item,limit=1]', 'Age', { timeoutMs: 8000, soft: true });
        const age = ra ? parseAge(ra) : null;
        dropTruth = {
            ageTicks: age, gametimeAtRead: g,
            spawnTick: age != null ? g - age : null,
            spawnSecAgo: age != null ? +(age / tps).toFixed(2) : null,
            note: 'Age = 物品实体已存在的 tick 数；spawnTick = G_read − Age（服务端反推，不依赖客户端时钟）',
        };
    } catch (e) { dropTruth = { error: String(e).slice(0, 140) }; }

    // ── 手持物区间：最后一次"拿着金锭" 与 第一次"空了" ────────────────
    const held = handLog.filter((h) => h.main === 'gold_ingot' || h.off === 'gold_ingot');
    const emptyAfter = handLog.find((h) => h.tick > (held.at(-1)?.tick ?? 0) && (h.main === 'air' || h.off === 'air'));
    const s = (x) => (x == null ? null : +((x - tThrow) / 1000).toFixed(2));
    const tickOf = (ms) => (t.clock.tickAt(ms) == null ? null : +t.clock.tickAt(ms).toFixed(1));
    // 成交时刻：掉落物实体出现 **或** 背包增量（礼物落在 bot 拾取半径内时只有后者能看到）
    const tDeal = tDrop ?? tInvGain;
    const cycleSec = s(tDeal);
    return {
        tag, source, ok: true, dist0: +dist0.toFixed(2), aimMs: r.aimMs, tries: r.tries, aims: r.aims, tps,
        // ② 金锭记账（ROUND5 疑点二）：出手前 / 出手后 / **窗口结束时**
        //    窗口末比出手后多 ⇒ bot 把**自己扔出去的那块**又捡回来了（会毁掉"成交"判据）
        ingots0, ingots1, ingotsEnd: pig.countIngots(bot()),
        botPickedOwnThrow: pig.countIngots(bot()) > ingots1,
        dealBy: tDrop != null ? 'drop_entity' : (tInvGain != null ? 'inv_delta' : 'none'),
        pickupDelaySec: (tIngot != null && tPickup != null) ? s(tPickup) - s(tIngot) : null,
        cycleSec,
        drop: dropInfo, dropTruth,
        dropClientTick: tDrop != null ? tickOf(tDrop) : null,
        hand: {
            n: handLog.length,
            heldSamples: held.length,
            lastHoldingTick: held.at(-1)?.tick ?? null,
            firstEmptyTick: emptyAfter?.tick ?? null,
            main: [...new Set(handLog.map((h) => h.main))],
            off: [...new Set(handLog.map((h) => h.off))],
        },
        sameTick: dropTruth?.spawnTick != null && emptyAfter?.tick != null
            ? (dropTruth.spawnTick >= emptyAfter.tick - 1 && dropTruth.spawnTick <= emptyAfter.tick + 25) : null,
        series: handLog.map((h) => ({ t: s(h.ms), tick: h.tick == null ? null : +h.tick.toFixed(1), main: h.main, off: h.off })),
    };
}

const pct = (a, p) => {
    if (!a.length) return null;
    const s2 = [...a].sort((x, y) => x - y);
    return +s2[Math.min(s2.length - 1, Math.max(0, Math.round((p / 100) * (s2.length - 1))))].toFixed(2);
};
const mean = (a) => (a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(2) : null);
const toTicks = (sec, tps) => (sec == null ? null : Math.round(sec * tps));

async function main() {
    await openRun(STAMP);
    try {
        await loadPrimitives();
        await bootWorld({ difficulty: 'easy', resistance: RESIST });
        const t = truth();
        const park = await parkSafe({ cx: S.x, cz: S.z, yLo: S.yLo, yHi: 100, r: 4 });
        await sleep2(5000);
        const sc = await t.selfCheck({ dim: 'the_nether', at: park.park, atEntity: LANE.username });
        record('b1_p0_selfcheck', { selfCheck: sc, park, resistance: RESIST });

        const stand = await standNatural({ cx: S.x, cz: S.z, r: 22, yLo: S.yLo, yHi: S.yHi + 8 });
        const approach = stand ? await approachPiglins({ k: 4, standoff: 2.7, maxMs: 25000 }) : null;
        const mode = stand && approach?.ok ? 'natural' : 'fixture';
        if (mode === 'fixture') { await recall(park); console.log('[mode] 自然地面不可用 ⇒ 退回「平台 + fixture」打法'); }
        record('b1_p1_setup', {
            park, stand, approach, mode, dim: dim(), botPos: posStr(botPos()),
            tps: t.clock.tps(), piglins: await serverCount(),
            clientPiglins: pig.listPiglins(bot(), { radius: 80 }).length,
        });
        console.log('[setup]', JSON.stringify({ mode, stand: stand?.stand, approach: approach?.ok, tps: t.clock.tps() }));

        const inv = await kit(['gold_ingot:64', 'golden_helmet:1', 'golden_boots:1', 'iron_sword:1', 'cooked_porkchop:8']);
        const armor = await pig.ensureGoldArmor(bot());
        record('b1_p1b_kit', { inv, armor });

        // ── 🚨 ⑤ 扔锭对照（先做，场子干净）─────────────────────────────
        const dropCtl = await dropItemControl();
        record('b1_p2_drop_control', dropCtl);

        // ── 距离标定：**固定在平台上**做（几何可控；自然地面坑洼会污染距离-成交率曲线）──
        await recall(park);
        const cell = botPos().floored();
        const distRows = [];
        for (const d of [2.0, 2.5, 2.8, 3.1, 3.4]) {
            await resetGround();
            cmd(`execute in minecraft:the_nether run tp ${LANE.username} ${cell.x + 0.5} ${cell.y} ${cell.z + 0.5}`);
            await sleep2(1500);
            await topUpIngots();
            const e = await summonAt(cell.x + 0.5 + d, cell.y, cell.z + 0.5);
            if (!e) { distRows.push({ wantDist: d, err: 'summon_timeout' }); continue; }
            await sleep2(500);
            const row = await measureThrow(e, { tag: `dist${d}`, source: 'fixture', waitMs: 16000 });
            distRows.push({ wantDist: d, ...row });
            console.log(`[dist ${d}] dist0=${row.dist0} ${row.phase ?? 'ok'} 借记=${row.ingots0 - row.ingots1} 捡起延迟=${row.pickupDelaySec} 周期=${row.cycleSec} 掉落=${row.drop?.name}`);
            await pig.collectDrops(bot(), { radius: 8, timeoutMs: 6000, perItemMs: 2000 });
        }
        record('b1_p3_distance', { distRows, cell });
        const byDist = {};
        for (const r of distRows) {
            byDist[r.wantDist] = r.ok
                ? { n: 1, ok: r.drop != null ? 1 : 0, cycleSec: r.cycleSec, pickupDelaySec: r.pickupDelaySec, drop: r.drop?.name, debit: r.ingots0 - r.ingots1 }
                : { n: 1, ok: 0, phase: r.phase };
        }
        const bestDist = Object.entries(byDist).map(([k, v]) => ({ d: +k, ...v })).filter((v) => v.ok)
            .sort((a, b) => (a.cycleSec ?? 99) - (b.cycleSec ?? 99))[0];
        console.log(`[dist] ${JSON.stringify(byDist)} → 最佳=${JSON.stringify(bestDist)}`);

        // ── B1 主体：n≥20（自然猪灵优先，fixture 补）──────────────────
        const wantD = bestDist?.d ?? 2.5;
        const trials = [];
        const t0 = Date.now();
        let made = 0;
        while (trials.length < TRIALS && Date.now() - t0 < 20 * 60 * 1000) {
            const wantNatural = made % 2 === 0;
            let e = null, source = 'fixture';
            if (wantNatural) {
                await resetGround();
                const nat = pig.findTradeable(bot(), { radius: 18, minDist: Math.max(2.0, wantD - 0.4), maxDist: wantD + 0.4, n: 1 });
                if (nat.length) { e = nat[0]; source = 'natural'; }
            }
            if (!e) { await resetGround(); e = await summonAt(botPos().x + wantD, botPos().y, botPos().z); }
            if (!e) { await sleep2(1000); continue; }
            await sleep2(400);
            await topUpIngots();
            const row = await measureThrow(e, { tag: `t${trials.length}`, source });
            trials.push(row); made++;
            console.log(`[t${trials.length}] ${source} d=${row.dist0} ${row.phase ?? 'ok'} 借记=${row.ingots0 - row.ingots1} 捡起=${row.pickupDelaySec} 周期=${row.cycleSec}(${toTicks(row.cycleSec, row.tps)}tick) 掉落=${row.drop?.name}x${row.drop?.count} 手持=[${JSON.stringify(row.hand?.main)}] 同tick=${row.sameTick}`);
            await pig.collectDrops(bot(), { radius: 8, timeoutMs: 6000, perItemMs: 2000 });
            await pig.reserveItemSpace(bot(), { freeSlotsNeeded: 8 });
        }

        const good = trials.filter((x) => x.ok && x.cycleSec != null);
        const tps = t.clock.tps() ?? 20;
        const pick = good.map((x) => x.pickupDelaySec).filter((v) => v != null);
        const cyc = good.map((x) => x.cycleSec);
        const dropsWithAge = good.filter((x) => x.dropTruth?.spawnTick != null);
        const sum = {
            n: trials.length, nOk: good.length,
            nNatural: trials.filter((x) => x.source === 'natural').length,
            nFixture: trials.filter((x) => x.source === 'fixture').length,
            mode, bestDist: bestDist?.d ?? null, distTable: byDist,
            tps,
            pickupDelay: { n: pick.length, mean: mean(pick), p10: pct(pick, 10), p90: pct(pick, 90) },
            cycle: {
                n: cyc.length, mean: mean(cyc), p10: pct(cyc, 10), p50: pct(cyc, 50), p90: pct(cyc, 90),
                meanTicks: toTicks(mean(cyc), tps),
            },
            /** 把玩时长 = 周期 − 捡起延迟（捡起延迟是客户端可见的：投出的物品实体消失那一刻） */
            fiddle: {
                n: pick.length,
                mean: pick.length && cyc.length ? +(mean(cyc) - mean(pick)).toFixed(2) : null,
                meanTicks: pick.length && cyc.length ? Math.round((mean(cyc) - mean(pick)) * tps) : null,
            },
            verdict: {
                measuredCycleSec: mean(cyc),
                measuredCycleTicks: toTicks(mean(cyc), tps),
                spreadTicks: cyc.length ? [toTicks(pct(cyc, 10), tps), toTicks(pct(cyc, 90), tps)] : null,
                theory125: '125 tick ≈ 6.5s（rmalde 旧参数，stage-02 §R2.6 整张表都基于它）',
                research120: '120 tick = 6.0s（研究线字节码）',
                // 判据：与 p10–p90 实测区间比，不与某个固定容差比
                fits120: cyc.length ? (pct(cyc, 10) <= 6.0 && pct(cyc, 90) >= 5.9) : null,
                fits125: cyc.length ? (pct(cyc, 10) <= 6.5 && pct(cyc, 90) >= 6.4) : null,
            },
            dropTruthOK: dropsWithAge.length,
            dropItems: good.reduce((a, x) => { const k = x.drop?.name ?? '?'; a[k] = (a[k] ?? 0) + 1; return a; }, {}),
            debit: {
                n: good.length,
                allDebitedOne: good.filter((x) => (x.ingots0 - x.ingots1) === 1).length,
                botPickedOwnThrow: good.filter((x) => x.botPickedOwnThrow).length,
            },
            sameTickCount: good.filter((x) => x.sameTick === true).length,
            handSeriesSample: good[0]?.series?.slice(0, 12) ?? null,
        };
        record('b1_p4_trials', { sum, trials });
        writeSummary(sum);
        console.log('[B1]', JSON.stringify(sum, null, 2));
    } catch (e) {
        console.error('[b1] 失败：', e);
        try { record('error', { message: String(e?.message ?? e), stack: String(e?.stack ?? '').slice(0, 900) }); } catch { /* 忽略 */ }
        try { writeSummary({ failed: String(e?.message ?? e) }); } catch { /* 忽略 */ }
        process.exitCode = 1;
    } finally {
        await closeRun();
    }
}

main();
