# bench/stages/barter —— 开发线 F · MC-S2-01（S2 易物原型）

**S2 能不能进时间预算的唯一开关**：同时伺候 N 头猪灵并行投锭能不能成立
（串行约 320s / 4 头并行约 80s，见 `docs/research/stage-02-barter.md` §R2.6）。

- 任务层代码：**`mindcraft-wt/s2-barter`（分支 `aidqq/s2-barter`）里的
  `src/agent/tasks/exec/piglin.js`**。本目录只写取证/微基准，不改任务层。
- 泳道：**只有 C**（25568/25578，`experiments/mc1161-gate/server-1161_laneC`）。
- 线锁：F 线锁由**独立进程**长期持有（`.line-locks/F.json`）；每个脚本自己拿/放**泳道 C 的锁**，
  一局一放 —— 派单写明「C 线只在 F 两局之间借用」。
- 主种子：`4926685115947721762`，堡垒站 `S3_bastion` 中心 (288, 240)、盒 y 32–47
  （`bench/route/4926685115947721762.json`，**仍是 `frozenAt: null` 草稿**）。

## 怎么跑

```powershell
# 单个脚本（自己排队等泳道 C 与内存；泳道被占时等，不接管）
node .\bench\stages\barter\probe_piglin_count.mjs --stamp S2_P1_PROBE

# 队列驱动器（独立进程；顺序跑、局间让道 45s）
node .\bench\stages\barter\drive.mjs --only probe_piglin_count,probe_b5_chest_gold,probe_b1_fiddle,micro_barter
```

常用开关：`--trials N`（B1 次数）、`--n 1,2,4,6`（B2 扫描）、`--window 90`（窗口秒）、
`--pearls 12 --runs 3`（验收）、`--resistance 1`（开发期抗性，报告里必须标注）、`--lock-wait 25`。

## 脚本分工

| 脚本 | 回答什么 | 局数 |
|---|---|---|
| `probe_piglin_count.mjs` | 前置问题：easy/peaceful 下堡垒站有没有猪灵；通道自检；**metadata 偏移标定**；投一次锭的时序 | 2（easy + peaceful） |
| `probe_b5_chest_gold.mjs` | B5：堡垒宝箱金锭真值（箱数/箱型/内容）+ 金块折锭 | 2（①可弃定位 ②fresh world 非破坏读） |
| `probe_b1_fiddle.mjs` | B1：把玩时长 n≥20；**投掷距离标定**（成交率-距离）；出手延迟与**真实槽周期** | 1 |
| `micro_barter.mjs` | B2：N=1/2/4/6 吞吐曲线；B4 锭珠比；验收 0→12 珍珠 n≥3 | 1 |

## 真值通道（`truth.mjs`）

1.16.1 上唯一可靠的条件回读是 **`/fill` 的回执**（**没有 `/say`**，`tellraw` 零玩家不落控制台）。
- 回执**严格 FIFO 配对**（同类内 `sent/got` 计数）：发前先消费在途回执，超时 = 流不可信 → 硬失败。
- 实体计数用 `execute as <sel> run data get entity @s …`（**逐实体一行**，多目标无歧义）。
- 时钟用 `time query gametime`（1.16.1 有），TPS = gametime 增量 ÷ 墙钟秒数（手册 §9.3）。
- **1.16.1 没有 `/forceload`** ⇒ 每局必须先把 bot tp 过去让区块自然加载，再校验回执。
- 下界/末地一律 `execute in <dim> run …`（控制台没有 `@s`）。

## 环境诚实性（报告里必须照抄）

- 开发期 kit（`give`/`difficulty`/`tp`/布景 `fill`/`/summon` 猪灵）**只在原型阶段用，正式验收不得带**。
- 猪灵不够 N 头时用 `/summon` 补，每条记录标 `fixture`，汇总里给 `natural` / `fixture` 分列。
- 坐标只出现在本目录的脚本里；任务层 `piglin.js` **不含任何坐标常量**（手册 §7）。
