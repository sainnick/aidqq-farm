// boot_selftest.mjs — `_lib/runner_core.mjs` 的 bootServer 起服判据修复的**离线**自检
// （不开服、不 spawn java、不占泳道端口；全套毫秒级跑完，靠假时钟）
//
// 被测：classifyBoot / pollBoot / tcpListening / waitPortFree / ensureLanePortFree（逻辑面）
//       + reapBootChild / bootServer / bootServerWithRetry / stopServer 的导出面
//       —— bootServer* 本身需要真 spawn，离线**不调**，只钉导出（用例 ⑮）。
//
// 这次修的三个病（用例编号 ↔ 病）：
//   病① 成功判据只认日志里的 `Done (`，没这行就空转到 300s 超时 → 用例 ①⑦ 钉"原判据逐字保留"
//   病② `exit=0` 被当成"JVM 启动即崩"（1.16.1 端口被占是打三行 WARN 后 `return false` ⇒ 退出码 0）
//        → 用例 ②⑥⑧⑩ 钉"活着 + 端口在听 = 成功"与"bind 失败要立刻判负、且不被当成崩溃"
//   病③ 失败后不收尸，重试直接再起一个 ⇒ 端口互撞 → 用例 ⑫⑬⑭ 钉起服前的端口闸（含"别人的进程只报告不处置"）
//
// 纯离线纪律（手册 §2 / §4）：
//   - 唯一允许的网络操作：在 127.0.0.1 bind 一个**临时端口**（port:0 由系统分配）做阳性对照，测完立刻关；
//     断言里另有一条"临时端口不落在泳道段 25566–25578"自检。
//   - pollBoot 的 sleepFn / nowFn **全部注入假时钟**，没有任何真睡。
//   - 用例会真调一次 `taskkill`，但只针对**已核实不存在的 pid**（走的是 mine 分支的收尸路径），
//     因此是无害 no-op；先跑 process.kill(pid,0) 核实确实不存在再用。
//
// 用法（任务链路的 Node 20，不要用系统 Node 24）：
//   D:\AI斗蛐蛐\.runtime\node-v20.20.2-win-x64\node.exe bench\stages\barter\boot_selftest.mjs

import net from 'net';
import {
    classifyBoot, pollBoot, tcpListening, waitPortFree, waitPortListening,
    ensureLanePortFree, reapBootChild, bootServer, bootServerWithRetry, stopServer,
} from '../_lib/runner_core.mjs';

let failed = 0;
let total = 0;
const ok = (cond, msg, extra = '') => {
    total++;
    if (cond) console.log(`  PASS ${msg}`);
    else { failed++; console.log(`  FAIL ${msg}${extra ? `  ${extra}` : ''}`); }
};
const G = (t) => console.log(`\n${t}`);
/** 失败时必须打出「期望 vs 实际」 */
const E = (exp, act) => `期望 ${JSON.stringify(exp)}；实际 ${JSON.stringify(act)}`;

// ---------------------------------------------------------------- 真服日志形态（手册 §5：判据格式要用真服原文做阳性对照）
// 1.16.1 源码原文（docs/research/data/src-1161/net/minecraft/server/dedicated/DedicatedServer.java:147-154）：
//     try {
//        this.ad().startTcpServerListener(☃xx, this.L());      // :148
//     } catch (IOException var10) {
//        LOGGER.warn("**** FAILED TO BIND TO PORT!");           // :150
//        LOGGER.warn("The exception was: {}", var10.toString()); // :151
//        LOGGER.warn("Perhaps a server is already running on that port?"); // :152
//        return false;                                          // :153  ← 不抛异常 ⇒ 服务端干净停机 ⇒ **退出码 0**
//     }
// ⚠ 中间那行 SLF4J 的 "{}" 展开成 BindException.toString()，端口取 25568（泳道 C，与 S2-04 现场同形）。
// ⚠ 前缀 `[…] [main/WARN]: ` 是我补的 log4j 装饰（initServer 在主线程跑）；判据只匹配消息正文。
const BIND_FAIL_LOG = [
    '[12:00:00] [main/WARN]: **** FAILED TO BIND TO PORT!',
    '[12:00:00] [main/WARN]: The exception was: java.net.BindException: Address already in use: /0.0.0.0:25568',
    '[12:00:00] [main/WARN]: Perhaps a server is already running on that port?',
].join('\n');
// 1.16.1 正常的两行（`Done (` 是原始成功判据，回归锁要逐字对齐）
const STARTING_LINE = '[12:00:00] [Server thread/INFO]: Starting minecraft server version 1.16.1';
const DONE_LINE = '[12:00:01] [Server thread/INFO]: Done (4.021s)! For help, type "help"';

// ---------------------------------------------------------------- 假时钟（毫秒级跑全套的关键）
/** pollBoot 的 sleepFn 只把假时钟往前拨，不真睡；nowFn 读它。 */
function fakeClock(start = 0) {
    let t = start;
    return { now: () => t, sleep: async (ms) => { t += ms; } };
}

// ---------------------------------------------------------------- 临时端口工具（127.0.0.1，不碰泳道段）
/** 让系统分配一个临时端口，bind 一下拿到号就关（阳性对照用） */
async function bindTempPort() {
    const s = net.createServer();
    await new Promise((res, rej) => { s.once('error', rej); s.listen(0, '127.0.0.1', res); });
    const p = s.address().port;
    return { server: s, port: p };
}
const closeServer = (s) => new Promise((r) => s.close(() => r()));
/** 拿一个当前确实没人监听的端口（最多试 5 次，避开分配后被抢走的极小概率） */
async function freePort() {
    for (let i = 0; i < 5; i++) {
        const { server, port } = await bindTempPort();
        await closeServer(server);
        if (!(await tcpListening(port))) return port;
    }
    throw new Error('拿不到空闲临时端口');
}
/** 进程是否存在。注意 EPERM 表示"存在但无权限"，只有 ESRCH 才算不存在。 */
const pidExists = (p) => {
    try { process.kill(p, 0); return true; } catch (e) { return e.code !== 'ESRCH'; }
};
/** 从高位往下找一个**已核实不存在**的 pid（会真走 taskkill 的那条用例专用） */
function verifiedDeadPid(start = 999999) {
    for (let p = start; p > start - 64; p--) if (!pidExists(p)) return p;
    throw new Error('找不到已核实不存在的 pid');
}
const LANE = (serverPort) => ({ name: 'selftest', serverPort });

const t0 = Date.now();

// ================================================================ ① 原始判据回归锁
G('① Done( + 进程存活 ⇒ 成功、via=log（回归锁：原判据一个字没改）');
{
    const r = classifyBoot({ logText: `${STARTING_LINE}\n${DONE_LINE}\n`, listening: false, alive: true, exitCode: null });
    ok(r.ok === true && r.via === 'log', '成功且 via=log', E({ ok: true, via: 'log' }, r));
    // 阳性对照的必要性：即使端口在听，Done( 也要**优先**判 log（bot 进门时机不受端口判据影响）
    const r2 = classifyBoot({ logText: DONE_LINE, listening: true, alive: true, exitCode: null });
    ok(r2.ok === true && r2.via === 'log', 'Done( 与端口在听同时成立时仍判 log（优先级不变）', E({ via: 'log' }, r2));
}

// ================================================================ ② 核心修复：活着 + 端口在听 = 成功
G('② 无 Done( + 存活 + 端口在听 + 已过 portReadyAfterMs ⇒ 成功、via=port（病②：不再把活着的服判成崩溃）');
{
    const r = classifyBoot({ logText: STARTING_LINE, listening: true, alive: true, exitCode: null });
    ok(r.ok === true && r.via === 'port', 'classifyBoot：端口兜底判据生效', E({ ok: true, via: 'port' }, r));
    ok(!r.reason, '成功时不得带 reason', E(undefined, r.reason));

    const ck = fakeClock();
    let polls = 0;
    const p = await pollBoot({
        readLog: () => { polls++; return STARTING_LINE; },        // 一直不打 Done(
        isAlive: () => true,
        isListening: async () => true,
        intervalMs: 2000, timeoutMs: 300000, portReadyAfterMs: 4000,
        sleepFn: ck.sleep, nowFn: ck.now,
    });
    ok(p.ok === true && p.via === 'port' && p.timedOut === false, 'pollBoot：过线后按成功收', E({ ok: true, via: 'port' }, p));
    ok(p.waitedMs === 4000, '恰好在 portReadyAfterMs 那一轮放行', E(4000, p.waitedMs));
    ok(polls === 2, '只空转了 2 轮（1s/轮起算 2s：第 2 轮 elapsed=4000）', E(2, polls));
}

// ================================================================ ③ 不能"一绑定就放行"
G('③ ★ 未过 portReadyAfterMs 时**不许**成功（钉住"不能一绑定就放行"：1.16.1 先绑端口再加载世界）');
{
    const ck = fakeClock();
    let listeningCalls = 0;
    const p = await pollBoot({
        readLog: () => STARTING_LINE,
        isAlive: () => true,
        isListening: async () => { listeningCalls++; return true; },   // 端口**一直在听**
        intervalMs: 2000, timeoutMs: 10000, portReadyAfterMs: 20000,   // 门槛永远到不了
        sleepFn: ck.sleep, nowFn: ck.now,
    });
    ok(p.ok === false && p.timedOut === true && p.reason === 'timeout',
        '★ 端口明明在听，但没到 20s 门槛就 10s 超时了 ⇒ 不放行', E({ ok: false, timedOut: true, reason: 'timeout' }, p));
    ok(listeningCalls === 0, '★ 端口判据在门槛前**一次都没被查询**（elapsed>=portReadyAfterMs 的短路是真在起作用）', E(0, listeningCalls));
    // 非空洞对照：把门槛降到 0，同一场景**第一次轮询就放行** ⇒ 证明上一条绿不是因为"端口压根没被判"
    const ck2 = fakeClock();
    const p2 = await pollBoot({
        readLog: () => STARTING_LINE,
        isAlive: () => true,
        isListening: async () => true,
        intervalMs: 2000, timeoutMs: 300000, portReadyAfterMs: 0,
        sleepFn: ck2.sleep, nowFn: ck2.now,
    });
    ok(p2.ok === true && p2.via === 'port' && p2.waitedMs === 2000,
        '反例对照：门槛=0 时第一次轮询就放行（门槛才是唯一的闸）', E({ ok: true, via: 'port', waitedMs: 2000 }, p2));
}

// ================================================================ ④ 不许假阳性
G('④ 存活 + 无 Done( + 端口没在听 ⇒ pending，不许假成功（没在加载就还没起好）');
{
    const r = classifyBoot({ logText: STARTING_LINE, listening: false, alive: true, exitCode: null });
    ok(r.ok === false && r.via === 'pending', 'classifyBoot：判 pending（交给调用方继续等）', E({ ok: false, via: 'pending' }, r));
    ok(!r.reason && r.exitCode === undefined, 'pending 不带 reason/exitCode（它不是一次判负）', E({}, r));
}

// ================================================================ ⑤ 死进程不打分
G('⑤ 进程已死但日志里有 Done( ⇒ **不算成功**（钉住"死进程不打分"）');
{
    const r = classifyBoot({ logText: `${DONE_LINE}\n`, listening: true, alive: false, exitCode: 0 });
    ok(r.ok === false && r.via === 'dead', 'classifyBoot：判 dead（哪怕日志有 Done( 且端口在听）', E({ ok: false, via: 'dead' }, r));
    ok(r.reason === 'exited' && r.exitCode === 0, 'reason=exited 且回填 exitCode', E({ reason: 'exited', exitCode: 0 }, r));

    const ck = fakeClock();
    const p = await pollBoot({
        readLog: () => DONE_LINE,
        isAlive: () => false,
        isListening: async () => true,
        intervalMs: 2000, timeoutMs: 300000, portReadyAfterMs: 0,
        sleepFn: ck.sleep, nowFn: ck.now,
    });
    ok(p.ok === false && p.via === 'dead' && p.timedOut === false,
        'pollBoot：同一场景也不给成功（门槛=0 也救不了死进程）', E({ ok: false, via: 'dead' }, p));
}

// ================================================================ ⑥ exit=0 的真根因：bind 失败
G('⑥ ★ 日志含 FAILED TO BIND TO PORT（源码原文三行）+ exitCode:0 ⇒ reason=bind_failed，**不许**当成 JVM 崩溃（病②）');
{
    const r = classifyBoot({ logText: BIND_FAIL_LOG, listening: false, alive: false, exitCode: 0 });
    ok(r.ok === false && r.via === 'dead' && r.reason === 'bind_failed',
        '端口被占 ⇒ 报 bind_failed（而不是"JVM 崩了"）', E({ ok: false, via: 'dead', reason: 'bind_failed' }, r));
    ok(r.exitCode === 0, '退出码原样带回 0 —— 1.16.1 是 `return false` 干净退出的（DedicatedServer.java:153）', E(0, r.exitCode));
    // 对照：同一个 exitCode=0，日志里**没有**那三行 ⇒ reason 必须是 exited（两种 0 分得开才算真判据）
    const r2 = classifyBoot({ logText: STARTING_LINE, listening: false, alive: false, exitCode: 0 });
    ok(r2.reason === 'exited', '对照：同为 exit=0 但无 bind 失败三行 ⇒ reason=exited（两种 0 不混淆）', E('exited', r2.reason));
    // 进程还没退（日志已出、退出事件还没到）时，同样立刻判 bind_failed
    const r3 = classifyBoot({ logText: BIND_FAIL_LOG, listening: false, alive: true, exitCode: null });
    ok(r3.ok === false, '进程仍标活着时也不给成功（bind 失败是判负，不是等待）', E({ ok: false }, r3));
}

// ================================================================ ⑦ pollBoot 假时钟：Done( 晚到
G('⑦ pollBoot 假时钟：第 4 次 readLog 才出现 Done( ⇒ 成功，waitedMs 等于累计假时间');
{
    const ck = fakeClock();
    let reads = 0;
    const p = await pollBoot({
        readLog: () => (++reads >= 4 ? `${STARTING_LINE}\n${DONE_LINE}\n` : STARTING_LINE),
        isAlive: () => true,
        isListening: async () => { throw new Error('命中 Done( 时不该去查端口'); },
        intervalMs: 2000, timeoutMs: 300000, portReadyAfterMs: 90000,
        sleepFn: ck.sleep, nowFn: ck.now,
    });
    ok(p.ok === true && p.via === 'log' && p.timedOut === false, '晚到的 Done( 仍判成功 via=log', E({ ok: true, via: 'log' }, p));
    ok(reads === 4, '恰好第 4 轮命中（不提前也不多等一轮）', E(4, reads));
    ok(p.waitedMs === 8000, 'waitedMs == 累计假时间 4×2000', E(8000, p.waitedMs));
}

// ================================================================ ⑧ pollBoot 假时钟：bind 失败要立刻判负
G('⑧ ★ pollBoot 假时钟：日志一上来就是 FAILED TO BIND TO PORT ⇒ 第一次轮询就判负（不等进程退、不空转 300s）');
{
    const ck = fakeClock();
    let reads = 0;
    const p = await pollBoot({
        readLog: () => { reads++; return BIND_FAIL_LOG; },
        isAlive: () => true,                                       // 1.16.1 此刻还没退
        isListening: async () => { throw new Error('bind 失败时不该去查端口'); },
        intervalMs: 2000, timeoutMs: 300000, portReadyAfterMs: 90000,
        sleepFn: ck.sleep, nowFn: ck.now,
    });
    ok(p.ok === false && p.reason === 'bind_failed' && p.via === 'dead', '第一轮就判负 + reason=bind_failed', E({ ok: false, reason: 'bind_failed' }, p));
    ok(p.timedOut === false, '★ 不是超时（旧版会一直空转到 300s 才报 timeout）', E(false, p.timedOut));
    ok(reads === 1, '★ 只读了 1 次日志（不等进程退出事件）', E(1, reads));
    ok(p.waitedMs === 2000, '只花掉一轮间隔的假时间', E(2000, p.waitedMs));
}

// ================================================================ ⑨ pollBoot 假时钟：进程死了要快速失败
G('⑨ pollBoot 假时钟：isAlive() 第 2 次变 false ⇒ reason=exited，且总耗时不超过 2 次轮询');
{
    const ck = fakeClock();
    let aliveCalls = 0, reads = 0;
    const p = await pollBoot({
        readLog: () => { reads++; return STARTING_LINE; },
        isAlive: () => (++aliveCalls >= 2 ? false : true),
        isListening: async () => false,
        intervalMs: 2000, timeoutMs: 300000, portReadyAfterMs: 90000,
        sleepFn: ck.sleep, nowFn: ck.now,
    });
    ok(p.ok === false && p.reason === 'exited' && p.via === 'dead' && p.timedOut === false,
        '判负 + reason=exited', E({ ok: false, via: 'dead', reason: 'exited' }, p));
    ok(reads === 2, '★ 进程一死就返回（总共 2 次轮询，不空转）', E(2, reads));
    ok(p.waitedMs === 4000 && p.waitedMs <= 2 * 2000, '★ 总耗时 ≤ 2 次轮询（钉住"快速失败"）', E(4000, p.waitedMs));
}

// ================================================================ ⑩ pollBoot 假时钟：超时
G('⑩ pollBoot 假时钟：一直存活、无 Done(、端口不监听 ⇒ timedOut=true + reason=timeout');
{
    const ck = fakeClock();
    let reads = 0;
    const p = await pollBoot({
        readLog: () => { reads++; return STARTING_LINE; },
        isAlive: () => true,
        isListening: async () => false,
        intervalMs: 2000, timeoutMs: 6000, portReadyAfterMs: 90000,   // 门槛 90s ⇒ 端口判据根本不参与
        sleepFn: ck.sleep, nowFn: ck.now,
    });
    ok(p.ok === false && p.timedOut === true && p.reason === 'timeout' && p.via === 'pending',
        '超时收尾（不是 bind_failed、不是 exited）', E({ ok: false, timedOut: true, reason: 'timeout', via: 'pending' }, p));
    ok(reads === 3 && p.waitedMs === 6000, '在 6000ms 超时（3 轮 × 2000）', E({ reads: 3, waitedMs: 6000 }, { reads, waitedMs: p.waitedMs }));
}

// ================================================================ ⑪ 端口探针阳性对照
G('⑪ tcpListening 阳性对照：127.0.0.1 bind 临时端口 ⇒ true；close 掉 ⇒ false（手册 §4 第 10 条：测得出"有"才准报结论）');
{
    const { server, port } = await bindTempPort();
    try {
        ok(!(port >= 25566 && port <= 25578), `临时端口 ${port} 不落在泳道段 25566–25578`, E('不落在 25566–25578', port));
        ok((await tcpListening(port)) === true, 'bind 着的端口测得 true', E(true, 'tcpListening'));
    } finally {
        await closeServer(server);
    }
    ok((await tcpListening(port)) === false, `close 之后同一端口测得 false（${port}）`, E(false, 'tcpListening'));
    ok((await tcpListening(port)) === false, '重复测仍是 false（不留假阳性）', E(false, 'tcpListening'));
}

// ================================================================ ⑫⑬⑭ 起服前的端口闸（病③：重试不再互撞）
G('⑫ ensureLanePortFree：端口空 ⇒ ok，且不做任何处置（连 pid 台账都不必读）');
{
    const p12 = await freePort();
    let registryReads = 0;
    const r = await ensureLanePortFree(LANE(p12), {
        listenersFn: () => ({}),
        registryFn: () => { registryReads++; return new Map(); },
        portFreeMs: 1000,
    });
    ok(r.ok === true && r.port === p12, 'ok 且端口回显', E({ ok: true, port: p12 }, r));
    ok(r.stopped.length === 0 && r.foreign.length === 0, '没有停任何东西、也没有外来进程', E({ stopped: [], foreign: [] }, { stopped: r.stopped, foreign: r.foreign }));
    ok(registryReads === 0, '端口空时连台账都没读（短路）', E(0, registryReads));
}

G('⑬ ★ ensureLanePortFree：端口上是"别人的"pid ⇒ 抛 LANE_PORT_FOREIGN，且绝不去结束它（手册 §9.2）');
{
    // pid 已核实不存在（process.kill(pid,0) 抛 ESRCH）⇒ 即便真调 taskkill 也是无害 no-op；
    // 断言因此只能钉"**没有任何处置动作发生**"（抛错 + 不进入 kill/等端口的阻塞路径），不能证明"某进程被杀"。
    const pid = verifiedDeadPid();
    ok(pidExists(pid) === false, `用已核实不存在的 pid ${pid}（taskkill 对它是 no-op）`, E(false, pidExists(pid)));
    // 端口**真在监听**（我自己的临时 server）：若实现错误地继续走 kill + waitPortFree，会在这里白等 portFreeMs
    const { server, port } = await bindTempPort();
    try {
        for (const [label, reg] of [
            ['台账里查无此 pid（真·别人的进程）', new Map()],
            ['台账里有但 mine=false', new Map([[pid, { mine: false, owner: 'other-line' }]])],
        ]) {
            let err = null;
            const t = Date.now();
            try {
                await ensureLanePortFree(LANE(port), {
                    listenersFn: () => ({ [String(port)]: [pid] }),
                    registryFn: () => reg,
                    portFreeMs: 1500,                 // 错误的实现会在这里阻塞满 1.5s
                });
            } catch (e) { err = e; }
            const ms = Date.now() - t;
            ok(err !== null, `${label} ⇒ 抛错（不放行起服）`, E('throw', 'no throw'));
            ok(err?.code === 'LANE_PORT_FOREIGN', `${label} ⇒ err.code=LANE_PORT_FOREIGN`, E('LANE_PORT_FOREIGN', err?.code));
            ok(Array.isArray(err?.foreignPids) && err.foreignPids.length === 1 && err.foreignPids[0] === pid,
                `${label} ⇒ foreignPids 含该 pid`, E([pid], err?.foreignPids));
            ok(ms < 1000, `${label} ⇒ 毫秒级返回（没进 kill/等端口的阻塞路径）`, E('<1000ms', `${ms}ms`));
            ok(pidExists(pid) === false, `${label} ⇒ 该 pid 未被处置（仍不存在）`, E(false, pidExists(pid)));
        }
    } finally {
        await closeServer(server);
    }
}

G('⑭ ensureLanePortFree：端口上是本 runner 的遗留服（mine:true）⇒ 结束它并返回 stopped');
{
    // 同样用已核实不存在的 pid：会真跑一次 `taskkill /PID <不存在> /T /F`（无害 no-op），随后
    // waitPortFree 在空闲端口上立刻返回 free。断言不依赖 taskkill 是否"成功"。
    const pid = verifiedDeadPid();
    const p14 = await freePort();
    ok(pidExists(pid) === false, `pid ${pid} 已核实不存在（taskkill 是无害 no-op）`, E(false, pidExists(pid)));
    const r = await ensureLanePortFree(LANE(p14), {
        listenersFn: () => ({ [String(p14)]: [pid] }),
        registryFn: () => new Map([[pid, { mine: true, lane: 'selftest' }]]),
        portFreeMs: 2000,
    });
    ok(r.ok === true && r.port === p14, '放行起服（ok）', E({ ok: true, port: p14 }, r));
    ok(Array.isArray(r.stopped) && r.stopped.length === 1 && r.stopped[0] === pid, 'stopped 回报了那个 pid', E([pid], r.stopped));
    ok(r.foreign.length === 0, '自己的遗留服不算 foreign（不会抛 LANE_PORT_FOREIGN）', E([], r.foreign));
    const free = await waitPortFree(p14, { timeoutMs: 500 });
    ok(free.free === true, '起服闸放行时端口确实是空的', E(true, free));
}

// ================================================================ ⑮ 导出面（防手滑删导出 / 防改动把 bootServer 悄悄挪走）
G('⑮ reapBootChild / bootServer / bootServerWithRetry / stopServer 四个导出存在且是函数');
{
    for (const [name, fn] of [['reapBootChild', reapBootChild], ['bootServer', bootServer], ['bootServerWithRetry', bootServerWithRetry], ['stopServer', stopServer]]) {
        ok(typeof fn === 'function', `${name} 是函数（离线只验导出面，真 spawn 的路径不开服）`, E('function', typeof fn));
    }
    // bootServer 的两个近亲：offline 也能验"是函数"，但 waitPortListening 的**行为**本自检不覆盖 ——
    // 2026-10-03 核对时它的返回值逻辑是反的（runner_core.mjs:197-202：端口没在听却报 listening:true），
    // 且全仓无调用方。修好之后请在这里补一组行为用例。
    ok(typeof waitPortFree === 'function', 'waitPortFree 是函数（本文件 ⑭ 已用它验"闸放行时端口为空"）', E('function', typeof waitPortFree));
    ok(typeof waitPortListening === 'function', 'waitPortListening 是函数（⚠ 行为不覆盖：其逻辑当前是反的，见上方注释）', E('function', typeof waitPortListening));
}

const elapsed = Date.now() - t0;
console.log('');
ok(elapsed < 10000, `整套自检 < 10s（实测 ${elapsed}ms；假时钟，不真睡）`, E('<10000ms', `${elapsed}ms`));
const passed = total - failed;
if (failed) console.log(`✗ ${failed} 条失败 / 共 ${total} 条\nFAIL ${passed}/${total}`);
else console.log(`✓ 全部通过\nPASS ${passed}/${total}`);
process.exit(failed ? 1 : 0);
