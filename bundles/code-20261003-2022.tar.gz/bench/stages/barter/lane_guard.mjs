// lane_guard.mjs — F 线（MC-S2-01）泳道 C 占用闸门（本 stage 私有，_lib 一个字没改）
//
// 为什么不直接用 B 线的 bench/stages/portal/lane_guard.mjs：跨 stage 依赖（同 truth.mjs 的理由）。
// 判据抄 B 线那一份，三条都成立才可开跑：
//   a. ownedByLiveDir(dir) 非空  → 活的 runner 拥有这条泳道（**可能是 C 线在两局之间借道**）
//   b. 25568/25578 任一 LISTENING → 端口被占
//   c. 空闲内存 < 下限            → waitFreeMem 排队（手册 §4.7）
//
// 隔离纪律：看到别的线在跑**只等待，不干预**（根 AGENTS.md §2：杀进程/删档先问用户）。

import { execSync } from 'child_process';
import { ownedByLiveDir } from '../_lib/preflight.mjs';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 端口是否 LISTENING（只读观测） */
export function portBusy(port) {
    try {
        const txt = execSync(`netstat -ano | findstr ":${port} "`, { encoding: 'utf8' });
        return txt.split(/\r?\n/).some((l) => l.includes('LISTENING'));
    } catch { return false; }
}

export function laneStatus(lane) {
    const owner = ownedByLiveDir(lane.dir);
    const ports = [lane.serverPort, lane.rconPort].map(portBusy);
    if (owner) return { usable: false, owner, ports, why: `owned_by_live_runner(${owner})` };
    if (ports.some(Boolean)) return { usable: false, owner: null, ports, why: 'port_in_use' };
    return { usable: true, owner: null, ports, why: 'free' };
}

/** 等到本线可以安全开跑。期间只观察不干预。 */
export async function waitLane(lane, opts = {}) {
    const { maxMs = 20 * 60 * 1000, pollMs = 15000, onWait = null } = opts;
    const t0 = Date.now();
    let announced = null;
    while (Date.now() - t0 < maxMs) {
        const st = laneStatus(lane);
        if (st.usable) return st;
        if (announced !== st.why) { announced = st.why; onWait?.(st); }
        await sleep(pollMs);
    }
    return laneStatus(lane);
}
