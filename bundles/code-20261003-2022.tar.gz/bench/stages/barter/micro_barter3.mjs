// micro_barter3.mjs — MC-S2-03（开发线 F）：三模式同口径对比 + 猪灵密度时间分布 + 0→12 珍珠验收
//
// 派单（S2-03）四条：
//   1. **每轮给失效投锭位补人**；**bot 死亡即中止本局**（以 server.log 死亡消息为准）；
//      实测开放场新中心 [336,256] **站位 3 格内同时有几头猪灵的时间分布**。
//   2. **三种模式开放场同口径对比**（N=4，每种 ≥10 分钟）：
//      `wait` = 等猪灵过来 ／ `ground` = 地面投锭（`bot.toss`）／`approach` = 主动走近。
//   3. **围栏组**：fill 回执**全非 0** 才开测；围栏数字**只算引擎上限**。
//   4. B5 用新中心 [336,256] 跑一次（在 probe_b5_chest_gold.mjs 里，本文件不重复）。
//
// 口径纪律（每条都是上一轮的教训）：
//   · **同口径**：三格跑在**同一站位格**、同一 N、同一 kit、同一窗口长度、同一 TP 顺序；
//     唯一的变量是 `mode`。跑完一格先 `clear` + 杀掉落物 + `replenish()`，不许继承上一格的状态。
//   · **死亡即中止**：`makeDeathGuard()` 有两条互相独立的通道（server.log 死亡消息 / 客户端维度
//     不在下界），任一命中立刻停，且 `report.reason` 如实带 `death:*`。
//   · **没原料单独记账**（`ingotStarvedMs`）：猪灵把玩完**不还锭**，所以"投得少"有两种原因
//     （打不动 / 没原料），混在一起就没法归因。
//   · **围栏硬闸**：`buildPen()` 的 `ok=false` ⇒ 不开测（上一轮的 `glassCells=[0,0,1,1]` 是
//     FIFO 错位 + 破坏性复核造出来的假数，本轮已修）。
//
// 用法：
//   node micro_barter3.mjs --stamp S2_M3 --density-min 10 --window-min 10 --pearl-runs 3
//   node micro_barter3.mjs --stamp S2_M3P --only pearls            # 只补珍珠验收
//   node micro_barter3.mjs --stamp S2_M3D --only density          # 只测密度

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
    openRun, bootWorld, closeRun, cmd, truth, bot, botPos, posStr, dim,
    invCount, record, writeSummary, sleep, recallTo, buildPen, watchDeaths, makeDeathGuard,
    parkSafe, standNatural, makeStandGuard, footingOk,
    diskFreeGB, STATION, LANE, SEED, argv, moduleUrl, Vec3,
} from './harness.mjs';
import { parseArmorNbt, ARMOR_SLOT_IDS, pearlTimeStats, parseActiveEffects, FIRE_RESIST_ID } from './truth.mjs';

const STAMP = argv('stamp', 'S2_M3');
// ★ S2-04 默认集合加了 `easy`：easy + 整套金甲复测是本单的设计会话更正项，
//   必须在**每局**之前验装备槽服务端真值（`give` 发了 ≠ 穿上了）。
const ONLY = String(argv('only', 'easy,density,modes,pen,pearls')).split(',').map((s) => s.trim()).filter(Boolean);
const WANT = (k) => ONLY.includes(k);
const DENSITY_MS = Math.round(parseFloat(argv('density-min', '10')) * 60000);
const WINDOW_MS = Math.round(parseFloat(argv('window-min', '10')) * 60000);
const PEARL_TARGET = parseInt(argv('pearls', '10'), 10);   // ★ S2-04：12 → **10**（主种子门室已有 2 颗眼）
const PEARL_GOAL_SEC = parseFloat(argv('pearl-goal-sec', '180'));   // ★ S2-04 新验收线：v1 目标 ≤180s
const PEARL_RUNS = parseInt(argv('pearl-runs', '3'), 10);
// ★ S2-04：珍珠局**专用**模式开关。`--modes` 只喂 `modes` 段，珍珠局不读它
//   （珍珠局模式来自 sweep 的最优者；没跑 modes 段时回退到这个值）。
const PEARL_MODE = argv('pearl-mode', 'wait');
const PEARL_MS = Math.round(parseFloat(argv('pearl-min', '15')) * 60000);
const MODES = String(argv('modes', 'wait,ground,approach')).split(',').map((s) => s.trim()).filter(Boolean);
const N = parseInt(argv('n', '4'), 10);
const INGOTS = parseInt(argv('ingots', '128'), 10);
/**
 * 难度（**默认 peaceful**，S2-03 的选型理由，必须写进报告）：
 *   · easy 下 **bot 在 29 秒内被猪灵连杀 5 次**（server.log `was slain by Piglin` ×5，stamp S2_M3X）
 *     —— 1.16.1 猪灵的攻击目标链里有 `NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD`，
 *     所以脱战相没做、bot 又只有 2 件金装时，站在猪群里就是活靶。
 *     那样测到的是**战斗**，不是易物，三种模式的对比会被"谁先被打死"这个无关变量污染。
 *   · peaceful 下 `EntitySelector.ATTACK_ALLOWED` 恒 false（源码）⇒ **不可能被杀**，
 *     而 S2-01 已实测 **peaceful 下堡垒站仍有 28 头猪灵**（生成不受 peaceful 抑制）。
 *   · ⚠ **诚实标注**：peaceful 下测到的是"**易物机制本身**的上限"，
 *     真实 S2 链路上易物段必须在**脱战相之后**做（stage-02 §R2.2 早就这么写了）。
 *     本单另外单独报了 easy 下的死亡事实（5 次/29s），那是 S2 的设计约束，不是本单能修的。
 */
const DIFFICULTY = argv('difficulty', 'peaceful');
const S = STATION.bastion;
const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
/** ★ 钉住作业位（`--work 320,68,241`）：两次 `standNatural` 可能因为猪灵游走而落在**不同格**，
 *  那样"密度段"和"三模式段"就不是同一站位、对比无效。分两次跑时必须钉。 */
const WORK_PIN = (() => {
    const s = argv('work', null);
    if (!s) return null;
    const p = String(s).split(',').map((x) => parseFloat(x));
    return p.length === 3 && p.every(Number.isFinite) ? { x: p[0], y: p[1], z: p[2] } : null;
})();

let pig = null;
const readJson = (...parts) => { try { return JSON.parse(fs.readFileSync(path.join(BENCH_DIR, ...parts), 'utf8')); } catch { return null; } };

// ───────────────────────────────────────────────────── 猪灵密度（3 格内同时几头）
/**
 * 站位格周围的猪灵数时间分布。**这正是 techniques-1161 §2.1 那条"喂 4 头"打法的未验证前提**。
 * 同时记三档半径：2.0 / 3.0 / 3.4（3.4 = 喂锭交互的服务端实际上限，2.8–3.4 是唯一可观测掉落的窗口）。
 * 每 `everyMs` 采一次；每 30s 用**服务端真值**数一次全图猪灵（客户端实体表会保留已离开追踪范围的实体）。
 *
 * 🚨 **每行都带 `ok` 标记**（S2-03 踩到：首轮 10 分钟里有 ~80% 的样本猪灵数是 0，
 *   根因是 bot 从那条窄台**掉下去了**——掉落/死亡会让下界区块卸载 ⇒ 猪灵数与服务端计数**双双归零**，
 *   而"归零"会被读成"这一带没有猪灵"。**不区分有效样本与失效样本，就会得出"3 格内 0 头"的假结论。**）
 * ⇒ `ok = 维度在下界 && 水平漂移 ≤ r && 下坠 ≤ dy`；死亡则整段中止并如实记 reason。
 */
async function sampleDensity({ ms, everyMs = 1000, at = null, radii = [2.0, 3.0, 3.4], serverEveryMs = 30000, work = null } = {}) {
    const rows = [];
    const srv = [];
    const t0 = Date.now();
    let lastSrv = 0;
    const me = at ?? botPos();
    const w = work ? watchDeaths() : null;
    const sg = work ? makeStandGuard(work, { r: 2.5, dy: 3.0 }) : null;
    const dg = w ? makeDeathGuard(w) : null;
    let reason = 'window';
    while (Date.now() - t0 < ms) {
        const now = Date.now();
        const live = botPos();
        const d = String(dim());
        const stop = (dg?.() ?? null) ?? (sg?.guard() ?? null);
        if (stop) { reason = stop; break; }
        const list = Object.values(bot()?.entities ?? {}).filter((e) => e && e.name === 'piglin' && e.position);
        const r = { at: now - t0, wall: now };
        for (const rad of radii) r[`n${String(rad).replace('.', '_')}`] = list.filter((e) => e.position.distanceTo(me) <= rad).length;
        r.total24 = list.length;
        const ds = list.map((e) => e.position.distanceTo(me)).sort((a, b) => a - b);
        r.nearest = ds.length ? +ds[0].toFixed(2) : null;
        r.within6 = ds.filter((dd) => dd <= 6).length;
        r.within12 = ds.filter((dd) => dd <= 12).length;
        r.holding = list.filter((e) => pig.isHolding(e) === true).length;
        r.hpBelow = list.filter((e) => { const h = pig.piglinHealth(e); return h != null && h < pig.PIGLIN_MAX_HP * 0.999; }).length;
        r.botPos = live ? posStr(live) : null;
        r.dim = d;
        r.drift = live ? +Math.hypot(live.x - me.x, live.z - me.z).toFixed(2) : null;
        r.drop = live ? +(me.y - live.y).toFixed(2) : null;
        r.ok = !!live && /nether/i.test(d) && r.drift <= 2.5 && r.drop <= 3.0;
        rows.push(r);
        if (now - lastSrv >= serverEveryMs) {
            lastSrv = now;
            try {
                const c = await truth().countEntities('the_nether', LANE.username, '@e[type=piglin]', { quietMs: 800, minWaitMs: 6000, timeoutMs: 25000 });
                srv.push({ at: now - t0, serverPiglins: c.n, trusted: c.trusted, clientTotal: list.length, botOk: r.ok });
            } catch (e) { srv.push({ at: now - t0, error: String(e?.message ?? e).slice(0, 100) }); }
        }
        await sleep(Math.max(50, everyMs - (Date.now() - now)));
    }
    sg?.stop();
    w?.stop();
    return {
        rows, server: srv, sampleMs: Date.now() - t0, at: [me.x, me.y, me.z], radii, reason,
        valid: rows.filter((x) => x.ok).length, invalid: rows.filter((x) => !x.ok).length,
        deaths: w ? w.deaths : [], stand: sg ? sg.stats() : null,
    };
}

function densityStats(rows, key) {
    const v = rows.map((r) => r[key]).filter((x) => typeof x === 'number');
    if (!v.length) return null;
    const hist = {};
    for (const x of v) hist[x] = (hist[x] ?? 0) + 1;
    const s = v.slice().sort((a, b) => a - b);
    return {
        key, n: v.length, mean: +(v.reduce((a, b) => a + b, 0) / v.length).toFixed(3),
        p05: s[Math.floor(0.05 * (s.length - 1))], p50: s[Math.floor(0.5 * (s.length - 1))],
        p90: s[Math.floor(0.9 * (s.length - 1))], max: s[s.length - 1], min: s[0],
        hist, pctGe2: +(v.filter((x) => x >= 2).length / v.length).toFixed(3),
        pctGe3: +(v.filter((x) => x >= 3).length / v.length).toFixed(3),
        pctGe4: +(v.filter((x) => x >= 4).length / v.length).toFixed(3),
    };
}

// ───────────────────────────────────────────────────── 标定（按口径重算，见报告 §4）
/**
 * 🚨 **两处口径/SQL 断点（S2-03 修；证据 `analysis/baseline_recompute.md` + `baseline_recompute.json`）**：
 *  ① `summary.json#cycle` 是**混口径**（drop_entity 与 inv_delta 两种判据混算）：落盘 headline =
 *     **124 tick / 6.20s（n=14）**；**119 tick / 5.96s 只在 drop_entity 子集（n=7）成立**。
 *     两者差 0.17%，不改变机制结论，但**对外报哪个数必须同时写清 n 和口径**（派单点名要写清这件事）。
 *  ② 上一轮 `micro_barter.mjs:44` 读的是 `b1_p2_distance.json` —— 那是**五档全部 no_los 的失败轮**
 *     （当时 `hasLos` 还是 `world.raycast` 版，见 piglin.js 注释）⇒ `bestDist` 恒 null，
 *     引擎一直用默认 1.4–3.2 窗，**而不是实测最佳档**。有成交的是 `b1_p3_distance.json`，本单读它。
 */
function loadCalibration() {
    const p4 = readJson('runs', 'S2_B1', 'b1_p4_trials.json');
    const p3 = readJson('runs', 'S2_B1', 'b1_p3_distance.json');
    const cal = readJson('runs', 'S2_P1_PROBE', 'p2b_throw_calib.json');
    const rows = p4?.trials ?? [];
    const pick = (f) => rows.filter((r) => r.ok && f(r) && typeof r.cycleSec === 'number').map((r) => r.cycleSec);
    const stat = (v) => (v.length ? {
        n: v.length, mean: +(v.reduce((a, b) => a + b, 0) / v.length).toFixed(3),
        p50: v.slice().sort((a, b) => a - b)[Math.floor(v.length / 2)],
        min: Math.min(...v), max: Math.max(...v),
    } : null);
    const dropEntity = pick((r) => r.dealBy === 'drop_entity');
    const invDelta = pick((r) => r.dealBy === 'inv_delta');
    const mixed = pick(() => true);
    const distRows = (p3?.distRows ?? []).filter((r) => r.ok && r.cycleSec != null).sort((a, b) => a.cycleSec - b.cycleSec);
    const best = distRows[0] ?? null;
    const cycleSec = dropEntity.length ? dropEntity.reduce((a, b) => a + b, 0) / dropEntity.length : 6.0;
    return {
        cycleMs: Math.round(cycleSec * 1000),
        holdingIdx: cal?.holdingIdx ?? null,
        // 投掷窗：实测有成交的档是 2.12 / 2.83 / 3.10 / 3.22 ⇒ 窗取 2.0–3.4
        minDist: 2.0, maxDist: 3.4,
        provenance: {
            cycle_dropEntity: stat(dropEntity), cycle_invDelta: stat(invDelta), cycle_mixed: stat(mixed),
            bestDistRow: best ? { dist0: best.dist0, cycleSec: best.cycleSec } : null,
            distRows: distRows.map((r) => ({ d: r.dist0, cyc: r.cycleSec, by: r.dealBy })),
            note: '对外周期口径 = drop_entity 子集（出手→猪灵脚边出现掉落物实体）；inv_delta 子集系统性晚约 0.5s（掉落物 pickupDelay 10 tick）',
        },
    };
}

// ───────────────────────────────────────────────────── 一格（同口径）跑法
function makeEngine(n, mode, { groundCount = 1, cycleMs = 6000, collect = true, calib = null } = {}) {
    return new pig.BarterEngine(bot(), {
        slots: n,
        mode,
        minDist: calib?.minDist ?? 2.0, maxDist: calib?.maxDist ?? 3.4,
        groundCount, groundRadius: 9,
        approachRadius: 12, approachStandoff: 2.8, approachMoveMs: 2500, approachLeash: 6.5,
        cycleTimeoutMs: Math.max(14000, Math.round(cycleMs * 2.5)),
        rebindEveryMs: 1200, whyEveryMs: 5000,
        collect, harvestEveryRounds: 8, harvestMaxMs: 20000,
        safeRadius: 4.5, leashRadius: 7,
    });
}

/**
 * ★ S2-04：**服务端装备槽真值**（委托给 `truth.mjs#parseArmorNbt` 那个纯函数，回归锁只维护一处）。
 *   背景与源码依据见 `research/piglin_aggro_1161.md`。
 */
async function serverArmorTruth() {
    const t = truth();
    let line = null, err = null;
    try {
        line = await t.dataEntity('the_nether', LANE.username, LANE.username, 'Inventory', { timeoutMs: 8000, soft: true });
    } catch (e) { err = String(e?.message ?? e).slice(0, 160); }
    const p = parseArmorNbt(line);
    return {
        ...p,
        // ⚠ **`give` 发了 ≠ 穿上了**：`give` 只把东西塞进背包（Slot 0–35），
        //   装备槽是 100–103。两套都记，报告里能一眼看出"东西在背包里但没穿上"。
        inInventoryGold: p.worn.filter((w) => !ARMOR_SLOT_IDS[w.slot] && w.id.startsWith('golden_')).length,
        err, raw: line ? line.slice(0, 300) : null,
        // ⚠ **判据分三层**，报告必须分开说：读不到 / 读到但没金 / 读到且全套。
        //   源码依据（`research/piglin_aggro_1161.md`，主 agent 逐行复核）：
        //   `PiglinAi.isWearingGold`（`PiglinAi.java:592-601`）遍历 `getArmorSlots()`，
        //   **任意一件金质护甲即 true**（不计数、不要 4 件全套）；它只被
        //   `PiglinSpecificSensor.java:83` 用来填 `NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD`
        //   ——**只是 4 档攻击目标的最后一档**；前 3 档（ANGRY_AT / UNIVERSAL_ANGER /
        //   NEAREST_VISIBLE_NEMESIS）**完全没有金质检查**（`PiglinAi.java:448-473`）。
        //   ⇒「穿金 ⇒ 不会被主动打」只在**没被激怒**时成立。
        //   🚨 槽位编号 **100–103**（`Inventory.java:343-348`），不是客户端那套 5–8。
        verdict: p.verdict,
    };
}


/** 记录并打印装备真值；不达标不抛（只记），由调用方决定要不要停 */
async function checkArmor(label) {
    const a = await serverArmorTruth();
    // ⚠ `parseArmorNbt` 返回的字段叫 **`armor`**（不是 `wornArmor`）——
    //   写成 `a.wornArmor.map(...)` ⇒ 读失败分支之外的路径直接 TypeError ⇒ **整局崩**。
    //   （S2-04 第二局 1.7 分钟就死于这一行；`readFailed=false` 时才走到这里。）
    const slotTxt = (a.armor ?? []).map((w) => `${w.slot}:${w.id}`).join(',') || '(空)';
    console.log(`[装备真值 ${label}] verdict=${a.verdict} 金${a.goldCount}/4 皮${a.leatherCount}`
        + ` 背包金${a.inInventoryGold ?? 0}`
        + (a.readFailed ? ` ⚠读失败=${a.err ?? ''}` : ` 装备槽=${slotTxt}`));
    return a;
}

// ───────────────────────────────────────────────────── S2-05：火源防护（抗火 + 站位火源采样）
/**
 * 🚨 S2-05 的起因：S2-04 珍珠局 3 **烧死**（`server.log` 原文 `BarterBotC burned to death`，
 *   11:17:18），归因未定 ⇒ 一局白烧 15 分钟。两条规避都落在这里。
 *
 * ① **抗火**（主手）。`/effect give … fire_resistance` 覆盖**全部火类伤害源**：
 *   `DamageSource.java:17-21` 里 `IN_FIRE` / `ON_FIRE` / `LAVA` / `HOT_FLOOR` 全部 `setIsFire()`，
 *   `DamageSource.java:195` 暴露 `isFire()`，而 `LivingEntity.java:914` 一条判据兜住所有火类：
 *   `else if (☃.isFire() && this.hasEffect(MobEffects.FIRE_RESISTANCE)) return false;`
 *   ⇒ 不管是火方块、灵魂火、岩浆、岩浆块还是恶魂火球，命中的都是同一条判据。
 *   ⚠ **按手册 §5：kit/布景命令"没报错"≠生效** ⇒ 抗火必须**读状态真值**验过（见 fireResistTruth），
 *   而且**用两条互相独立的通道**（服务端 NBT + 客户端收到的 entity_effect），别只信一条。
 * ② **站位火源采样**（旁证）：局内每几秒读一次 bot 周围 5×4×5 的方块，把 fire/lava/magma 等记进遥测。
 *   这样"烧死"发生的那一刻**附近有没有火源**就是现成的前瞻证据，而不是事后猜。
 */
const FIRE_RESIST_SEC = 3600;
const FIRE_NAMES = new Set(['fire', 'soul_fire', 'lava', 'magma_block', 'nether_portal',
    'campfire', 'soul_campfire', 'lit_blast_furnace', 'end_portal', 'end_gateway']);

/** 通道 A：服务端 NBT 真值（`data get entity <bot> ActiveEffects`）。读不到就是 readFailed，不折算成"没有"。 */
async function fireResistServer() {
    const t = truth();
    let line = null, err = null;
    try {
        line = await t.dataEntity('the_nether', LANE.username, LANE.username, 'ActiveEffects', { timeoutMs: 8000, soft: true });
    } catch (e) { err = String(e?.message ?? e).slice(0, 160); }
    const p = parseActiveEffects(line);
    return { read: !p.readFailed, on: p.fireResistance, ids: p.ids, err, raw: p.raw };
}

/** 通道 B：客户端收到的 entity_effect（服务端→客户端包解析出来的状态，与 A 互相独立）。
 *  ⚠ 1.16.1 的 `entity_effect` 包里效果 id 是**数字**，mineflayer 按数字存 ⇒ 键可能是 `'12'` 而不是
 *    `'fire_resistance'` ⇒ 名字与数字两种形态都认（数字用 `MobEffects.java:48` 的 12）。 */
function fireResistClient() {
    const fx = bot()?.player?.entity?.effects ?? null;
    if (fx == null) return { read: false, on: null, n: null, keys: null };
    const keys = Object.keys(fx);
    return {
        read: true,
        on: keys.some((k) => /fire_resistance/.test(k) || Number(k) === FIRE_RESIST_ID),
        n: keys.length, keys: keys.slice(0, 8),
    };
}

/** 两条通道一起记 + 打印。**不设硬闸**（抗火是防护不是测量前提），但两通道都"没有"时要喊出来。 */
async function checkFireResist(label) {
    const srv = await fireResistServer();
    const cli = fireResistClient();
    const ok = srv.on === true || cli.on === true;
    const both = srv.on === true && cli.on === true;
    console.log(`[抗火真值 ${label}] 服务端=${srv.on ?? 'read_failed'}（${srv.read ? `ids=${JSON.stringify(srv.ids)}` : `读失败=${(srv.err ?? '').slice(0, 60)}`}）`
        + ` 客户端=${cli.on ?? 'read_failed'}（${cli.read ? `${cli.n} 个效果 keys=${JSON.stringify(cli.keys)}` : '读不到'}）${ok ? '' : ' ⚠⚠ 抗火未生效'}${both ? ' ✅双通道一致' : ''}`);
    return { ok, both, srv, cli };
}

/** 站位周围火源（客户端读，限已加载区块）。`unread` 单列：没读到 ≠ 没有（手册 §5）。
 *  ⚠ **`bot.blockAt` 只吃 Vec3**（手册 §3 / micro 自检清单）：传裸对象会抛
 *    `pos.floored is not a function` —— S2-05 第一版就这么把整局带崩了。 */
function fireNeighborhood(center, r = 2) {
    const hits = [];
    let unread = 0, scanned = 0;
    const cx = Math.floor(center.x), cy = Math.floor(center.y), cz = Math.floor(center.z);
    for (let dx = -r; dx <= r; dx++) for (let dy = -1; dy <= 2; dy++) for (let dz = -r; dz <= r; dz++) {
        scanned++;
        let blk = null;
        try { blk = bot()?.blockAt?.(new Vec3(cx + dx, cy + dy, cz + dz)) ?? null; } catch { blk = null; }
        if (blk == null) { unread++; continue; }
        if (FIRE_NAMES.has(blk.name)) {
            hits.push({ at: [cx + dx, cy + dy, cz + dz], name: blk.name,
                d: +Math.hypot(cx + dx + 0.5 - center.x, cy + dy + 0.5 - center.y, cz + dz + 0.5 - center.z).toFixed(2) });
        }
    }
    return { hits, unread, scanned };
}

async function resetTrial(ingots = INGOTS) {
    cmd(`clear ${LANE.username}`);
    cmd('execute in minecraft:the_nether run kill @e[type=item]');
    cmd('execute in minecraft:the_nether run kill @e[type=experience_orb]');
    await sleep(900);
    cmd(`give ${LANE.username} minecraft:gold_ingot ${ingots}`);
    // ★ **整套**金甲（4 件）+ 盾牌 + 剑 + 食物。
    // 🚨🚨 **S2-04 根因：`give` 的物品名与数量必须用「空格」分隔，不能用冒号。**
    //   原写法 `give <bot> minecraft:golden_helmet:1` ⇒ 服务端回
    //   `Invalid ID` + `...minecraft:golden_helmet:1<--[HERE]`
    //   ⇒ **金甲一件都没进背包** ⇒ `ensureGoldArmor` 找不到可穿的 ⇒ 装备槽恒空
    //   ⇒ `isWearingGold` 恒 false ⇒ 猪灵把 bot 当默认攻击目标
    //   ⇒ **S2-03「easy 下 29 秒被连杀 5 次」的真正根因就在这里**（不是"只穿 2 件"）。
    //   实证：`runs/S2_S4C/server.log` 10:55:17（`Gave 128 [Gold Ingot]` 紧跟 `Invalid ID`）。
    //   ⇒ 因此**金甲必须用服务端回执验**（`serverArmor.verdict==='full_gold'`），不能信 `give` 没报错。
    for (const it of ['golden_helmet 1', 'golden_chestplate 1', 'golden_leggings 1', 'golden_boots 1', 'iron_sword 1', 'shield 1', 'cooked_porkchop 16']) {
        cmd(`give ${LANE.username} minecraft:${it}`);
        await sleep(120);
    }
    cmd(`effect give ${LANE.username} minecraft:slow_falling 20 0 true`);
    // ★ S2-05：抗火（覆盖全部火类伤害源，见上面 ① 的源码依据）。**必须验真**，S2-04 的 `give` 教训。
    cmd(`effect give ${LANE.username} minecraft:fire_resistance ${FIRE_RESIST_SEC} 0 true`);
    await sleep(1400);
    const armor = await pig.ensureGoldArmor(bot(), { full: true });
    const fireResist = await checkFireResist(`resetTrial(${ingots})`);
    // ★ S2-04：**`give` 发了 ≠ 穿上了** ⇒ 每局开跑前读一次服务端装备槽真值。
    //   这条通道是 easy 复测的全部前提：装备没穿上，"不被攻击"就无从谈起。
    const serverArmor = await checkArmor(`resetTrial(${ingots})`);
    // 🚦 **硬闸：金甲没真穿上 ⇒ 直接抛，不开测。**
    //   理由：金甲是本单所有 easy 相关结论的**前提**。带着空装备槽跑出来的数
    //   （"easy 下被打死"）会被读成"easy 不可行"，而真因是 kit 的 `give` 语法错。
    //   这正是 S2-03 那个错误的成因：**没有这道闸，坏 kit 跑出的数据看起来完全正常。**
    if (serverArmor.verdict !== 'full_gold') {
        throw new Error(`GOLD_ARMOR_NOT_EQUIPPED：装备槽服务端真值=${serverArmor.verdict}`
            + `（金 ${serverArmor.goldCount}/4，背包金 ${serverArmor.inInventoryGold}）。`
            + '开跑前必须 full_gold，否则本局数据不可用（kit 的 give 语法 / equip 失败）。');
    }
    return { inv0: invCount(), ingots0: pig.countIngots(bot()), free: diskFreeGB(), armor, serverArmor, fireResist };
}

/** 补足 N 头 fixture 猪灵（如实记数）：不够才 summon，等它真的进客户端实体表 */
async function ensureN(n, { minDist, maxDist }) {
    const me = botPos();
    const list = Object.values(bot()?.entities ?? {}).filter((e) => e && e.name === 'piglin' && e.position);
    const usable = list.filter((e) => {
        const d = e.position.distanceTo(me);
        return d >= minDist - 0.5 && d <= maxDist + 0.5 && pig.hasLos(bot(), e) && pig.isHolding(e) !== true;
    });
    let fixture = 0;
    const angles = [0, 45, 90, 135, 180, 225, 270, 315, 22, 68, 112, 158, 202, 248, 294, 336];
    for (let i = usable.length; i < n; i++) {
        const a = (angles[i % angles.length] * Math.PI) / 180;
        const d = minDist + ((i % 3) * 0.4);
        const x = me.x + Math.cos(a) * d, z = me.z + Math.sin(a) * d;
        const before = new Set(Object.values(bot()?.entities ?? {}).map((e) => e.id));
        cmd(`execute in minecraft:the_nether run summon minecraft:piglin ${x.toFixed(2)} ${me.y.toFixed(2)} ${z.toFixed(2)}`);
        let ok = false;
        for (let k = 0; k < 50; k++) {
            await sleep(120);
            const fresh = Object.values(bot()?.entities ?? {}).find((e) => e.name === 'piglin' && !before.has(String(e.id))
                && Math.abs(e.position.x - x) < 2.5 && Math.abs(e.position.z - z) < 2.5);
            if (fresh) { ok = true; break; }
        }
        if (!ok) console.log(`[ensureN] 第 ${fixture + 1} 只 fixture 6s 内没进实体表`);
        fixture++;
    }
    await sleep(1000);
    return { natural: Math.min(usable.length, n), fixture };
}

/**
 * ★ S2-04：easy + 整套金甲复测（设计会话更正项）。
 *
 * **这不是"再跑一局 easy"**，而是针对一个具体争点取证：
 *   S2-03 归因「只穿 2 件金甲 = 活靶」；设计会话更正「穿**任意**一件就不被主动攻击」，
 *   并要求查那一局 kit 到底穿没穿上。源码已确认 `isWearingGold` 任意一件即 true，
 *   **且只过滤 4 档攻击目标的最后一档**（前 3 档不看金）。
 *
 * ⇒ 三个读数**必须分开**，少一个就答不了这个问题：
 *   ① `serverArmor`：装备槽**服务端真值**（`data get entity <bot> Inventory`，槽 **100–103**）
 *   ② `aggressive`：猪灵 `metadata[14] & 4`（`Mob.java:1268 setAggressive`）⇒ 有没有被激怒
 *   ③ `deaths`：**server.log 的死亡行**（硬线，不做"背包空+满血"式推断）
 *
 * 死亡是**硬闸**：一旦出现就立刻收，不把"死了 5 次"当数据继续跑。
 */
async function easyGoldArmorTrial({ work, cycleMs, calib, mode = 'wait', windowMs = 180000 }) {
    const t = truth();
    // ⚠ **难度是本段的唯一变量**：主循环用 `DIFFICULTY`（默认 peaceful），
    //   这里**强制 easy**。ATTACK_ALLOWED 在 peaceful 下恒 false ⇒ peaceful 根本测不出这件事。
    cmd('difficulty easy');
    await sleep(1500);

    const w = watchDeaths();                 // 死亡通道（server.log + 维度两条）
    await recallTo(work, { label: 'easy' });
    const rs = await resetTrial(INGOTS);
    // 装备真值**要在 ensureN 之前查一次**：summon 猪灵不会改装备，但先查一次
    //   才能把"开跑那一刻到底穿没穿"钉死（而不是事后才知道）。
    const armorBefore = await checkArmor('easy/开跑前');

    // 补 N 头猪灵到 6 格内 —— **要有活靶才谈得上"被不被攻击"**。
    // 阳性对照纪律（手册 §4.10）：如果窗口里一头猪灵都没有，"没被攻击"是无效结论。
    const prov = await ensureN(N, { minDist: 1.2, maxDist: 6 });

    const engine = makeEngine(N, mode, { cycleMs, calib });
    const sg = makeStandGuard(work, { r: 2.5, dy: 3.0 });
    engine.opts.guard = () => makeDeathGuard(w)() ?? sg.guard();

    // 逐秒采样：攻击状态标志 + 血量 + 装备真值（每 10s 复核一次装备，防止中途被打掉）
    const samples = [];
    const iv = setInterval(() => {
        try {
            const p = botPos();
            const piglins = Object.values(bot()?.entities ?? {}).filter((e) => e && e.name === 'piglin' && e.position);
            const within6 = piglins.filter((e) => p && e.position.distanceTo(p) <= 6);
            samples.push({
                t: Date.now(), hp: bot()?.health, alive: !!bot()?.entity,
                piglinsTotal: piglins.length, piglinsWithin6: within6.length,
                // ★ 手册 §3：metadata[14] 是位标志，**4 = 攻击状态**（不是疾跑）
                aggressive: within6.filter((e) => ((e.metadata?.[14] ?? 0) & 4) !== 0).length,
                // 「有没有一头处于攻击状态」——这是"被激怒"的直接判据，
                //   用来区分「穿金失败」与「被激怒后照打（穿金也挡不住）」
                anyAggressive: within6.some((e) => ((e.metadata?.[14] ?? 0) & 4) !== 0),
            });
        } catch (e) { samples.push({ t: Date.now(), readFailed: String(e).slice(0, 120) }); }
    }, 1000);

    const t0 = Date.now();
    const rep = await engine.run({ windowMs, shouldStop: (e) => (w.deaths.length ? `death:${w.deaths.length}` : null) });
    clearInterval(iv);
    const armorAfter = await checkArmor('easy/收工');
    sg.stop();
    w.stop();

    const valid = samples.filter((s) => !s.readFailed);
    const aggressiveSamples = valid.filter((s) => s.anyAggressive);
    const easy = {
        mode, windowMs, difficulty: 'easy',
        natural: prov.natural, fixture: prov.fixture,
        // ★ 三个读数并列（少一个就答不了"为什么被打"）
        serverArmor: { before: armorBefore, after: armorAfter },
        aggressive: {
            samples: valid.length, readFailed: samples.length - valid.length,
            withAnyAggressive: aggressiveSamples.length,
            // ⚠ **"猪灵在场"是阳性对照**：没有猪灵在场 ⇒ "没被攻击"不算数
            meanPiglinsWithin6: valid.length ? +(valid.reduce((a, s) => a + (s.piglinsWithin6 ?? 0), 0) / valid.length).toFixed(2) : null,
            minHp: valid.length ? Math.min(...valid.map((s) => s.hp ?? 20)) : null,
            hpTrace: valid.filter((_, i) => i % 5 === 0).map((s) => [Math.round((s.t - t0) / 1000), s.hp]),
        },
        deaths: w.deaths,                       // ★ 硬线：server.log 的死亡行
        rep: {
            throwsOk: rep.throwsOk, throws: rep.throws, throwsPerMin: rep.throwsPerMin,
            cyclesN: rep.cyclesN, pearls: rep.pearls, reason: rep.reason,
            bound: engine.stats?.bound ?? null,
        },
        stand: sg.stats(), wallMs: Date.now() - t0, tps: truth().clock.tps(),
        samples: valid.slice(0, 200),
    };
    // ✅/❌ 判定分三层写清楚，**不合成一个布尔**（合成就会丢掉"为什么"）
    easy.verdict = {
        armorVerdict: armorBefore.verdict,                       // full_gold / partial_gold / no_gold / read_failed
        deaths: w.deaths.length,                                 // 0 = 没被打死
        attackedObserved: aggressiveSamples.length > 0,          // 猪灵进入过攻击状态
        // ⚠ **有活靶才有效**：窗口内 6 格内平均猪灵数必须 > 0
        validTest: (easy.aggressive.meanPiglinsWithin6 ?? 0) > 0 && !armorBefore.readFailed,
        conclusion: (() => {
            if (armorBefore.readFailed) return 'inconclusive：装备槽真值读不到，测不了';
            if ((easy.aggressive.meanPiglinsWithin6 ?? 0) <= 0) return 'inconclusive：窗口内没有猪灵，"没被攻击"不算数';
            if (w.deaths.length) return `被打死 ${w.deaths.length} 次；装备=${armorBefore.verdict}；攻击状态样本=${aggressiveSamples.length}`
                + (aggressiveSamples.length ? '（存在被激怒路径 ⇒ 穿金挡不住那一档）' : '（全程无攻击状态 ⇒ 查装备是否真穿上）');
            return `✅ 0 死：装备=${armorBefore.verdict}，6 格内均 ${easy.aggressive.meanPiglinsWithin6} 头，攻击状态样本 ${aggressiveSamples.length}`;
        })(),
    };
    console.log(`[easy 复测] 装备=${armorBefore.verdict} 死亡=${w.deaths.length} 攻击状态样本=${aggressiveSamples.length}/${valid.length}`
        + ` 6格内均=${easy.aggressive.meanPiglinsWithin6} 头 投锭=${easy.rep.throwsOk}(${easy.rep.throwsPerMin}/分)`);
    console.log(`[easy 复测] 结论：${easy.verdict.conclusion}`);
    return easy;
}

async function oneMode({ mode, windowMs, work, cycleMs, calib = null, groundCount = 1, label = null, shouldStop = null, pearlTarget = 0 }) {
    const w = watchDeaths();
    await recallTo(work, { label: label ?? mode });
    const rs = await resetTrial(INGOTS);
    // ★ S2-05：站位火源动态采样。**为什么必须前瞻采样**：S2-04 那局"烧死"发生在局中，
    //   事后只剩一行 `burned to death`，无从知道当时脚下/身边有没有火源（那一格既可能是
    //   世界自带的岩浆/火，也可能是战败 hoglin 现场生成的火）。局内每 4s 记一次 ⇒ 死亡时刻
    //   的最后一个样本就是现成证据。另：`unread` 单列，区块没加载 ≠ 那里没有火。
    const fireRows = [];
    const fireSnap = (tag) => {
        const p = botPos();
        if (!p) return;
        const fn = fireNeighborhood(p, 2);
        const row = { t: Date.now(), tag, at: [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)],
            dim: String(dim()), n: fn.hits.length, unread: fn.unread, scanned: fn.scanned,
            nearest: fn.hits.length ? Math.min(...fn.hits.map((h) => h.d)) : null, hits: fn.hits.slice(0, 6) };
        fireRows.push(row);
        if (fn.hits.length) console.log(`[火源采样] ${tag} 附近有火源：${fn.hits.slice(0, 3).map((h) => `${h.name}@${h.at.join(',')}(${h.d}格)`).join(' ')}`);
    };
    fireSnap('before');
    const fs = setInterval(() => { if (fireRows.length < 90) fireSnap('tick'); }, 4000);
    fs.unref?.();
    const me = botPos();
    // ★ 同口径的关键：三种模式**共用同一个可选池**（都补到 N 头、半径都取 approach 的 11 格），
    //   唯一的变量是**策略**（等它进 3.4 格 / 丢地上让它来 / 主动走过去）。
    //   ⚠ 上一轮三种模式用**不同半径**各补各的 ⇒ 猪群组成都不同，对比无效。
    const prov = await ensureN(N, { minDist: 1.2, maxDist: 11 });
    const engine = makeEngine(N, mode, { groundCount, cycleMs, calib });
    // ★ 中止闸 = 死亡（server.log + 维度两条独立通道） **AND** 站位守护（漂/下坠就拉回）
    const sg = makeStandGuard(work, { r: mode === 'approach' ? 7 : 2.5, dy: 3.0 });
    engine.opts.guard = () => makeDeathGuard(w)() ?? sg.guard();
    // ★ S2-04：**背包珍珠真值**逐拍采样。引擎 `stats.pearls` 漏算"走过掉落物被接触自动捡起"
    //   （S2-03 实测引擎 14/11/4/0 vs 背包 32/36/25/23）⇒ 达标判据与计时**只能读这条通道**。
    //   `pearlsInv0` 取在 `resetTrial`（已 `clear`）之后、开跑之前，**必须是 0**；
    //   若非 0 则"0→10"不是从 0 起跑（如实记在返回里，不静默沿用）。
    const pearlsInv0 = invCount().ender_pearl ?? 0;
    let pearlsReachedAtMs = null;
    let t0 = Date.now();
    if (pearlTarget > 0) {
        const wrapped = shouldStop;
        shouldStop = (e) => {
            const got = (invCount().ender_pearl ?? 0) - pearlsInv0;
            if (got >= pearlTarget && pearlsReachedAtMs == null) pearlsReachedAtMs = Date.now() - t0;
            return wrapped ? wrapped({ ...e, pearlsInv: got }) : null;
        };
    }

    const bound = engine.bind();
    t0 = Date.now();
    const rep = await engine.run({ windowMs, shouldStop });
    const h = await engine.harvest();
    const pearlsInvEnd = invCount().ender_pearl ?? 0;
    clearInterval(fs);
    fireSnap('after');            // ★ 死亡/中止后再补一枪，落在最后一拍之后
    sg.stop();
    w.stop();
    const after = Date.now();
    return {
        mode, N, bound, work: [me.x, me.y, me.z], windowMs, rep,
        natural: prov.natural, fixture: prov.fixture,
        // ★ S2-04：达标墙钟（背包真值首次达标那一瞬）；未达标 = null
        pearlsInv0, pearlsInvEnd, pearlsInv: pearlsInvEnd - pearlsInv0,
        timeToTargetMs: pearlsReachedAtMs,
        timeToTargetSec: pearlsReachedAtMs != null ? +(pearlsReachedAtMs / 1000).toFixed(1) : null,
        serverArmor: rs.serverArmor,                    // ★ 装备槽服务端真值（每局都记）
        fireResist: rs.fireResist,                      // ★ S2-05 抗火真值（两通道）
        // ★ S2-05 火源证据：samples=采样拍数，withHits=其中"身边有火"的拍数，
        //   nearest=全程最近一次火源距离，rows=逐拍（≤90）。last=死亡/收工那一刻的快照。
        fire: {
            samples: fireRows.length,
            withHits: fireRows.filter((r) => r.n > 0).length,
            nearest: fireRows.reduce((m, r) => (r.nearest != null ? Math.min(m, r.nearest) : m), Infinity),
            unreadSamples: fireRows.filter((r) => r.unread > 0).length,
            last: fireRows[fireRows.length - 1] ?? null,
            rows: fireRows,
        },
        harvest: { gained: h.gained, ms: h.ms, skippedOutside: h.skippedOutside, abortedByLeash: h.abortedByLeash, freed: h.freed },
        ingots0: rs.ingots0, ingotsEnd: pig.countIngots(bot()), invEnd: invCount(),
        wallMs: after - t0, hp: bot()?.health, alive: !!bot()?.entity, dim: dim(),
        deaths: w.deaths, stand: sg.stats(), diskFreeGB: diskFreeGB(),
        whySamples: engine.stats.whySamples.slice(0, 12),
    };
}

async function main() {
    await openRun(STAMP);
    try {
        pig = await import(moduleUrl('src/agent/tasks/exec/piglin.js'));
        const C = loadCalibration();
        if (C.holdingIdx != null) pig.applyCalibration({ holdingIdx: C.holdingIdx, healthIdx: 9, babyIdx: 12, evidence: 'S2_P1_PROBE/p2b_throw_calib.json' });
        console.log(`[cfg] 标定holdingIdx=${JSON.stringify(C.holdingIdx)} 周期(drop_entity口径)=${C.cycleMs}ms 投掷窗=${C.minDist}~${C.maxDist} 模式=${MODES} N=${N} 窗口=${WINDOW_MS / 60000}min`);
        console.log(`[cfg] 周期三口径 ${JSON.stringify(C.provenance)}`);

        await bootWorld({ difficulty: DIFFICULTY });
        const t = truth();
        const park = await parkAndStand();
        const work = park.stand;
        // ★ 站位**四点支撑**校验：bot 碰撞箱 0.6 宽，只查站位格正下方一格会漏掉"半个身子悬空"
        //   （S2-03 实测：钉住 (320,68,241) 后 bot 立刻掉一格并漂 1.2 格 ⇒ 四角必须有实心）。
        const footing = footingOk(botPos());
        const sc = await t.selfCheck?.({ dim: 'the_nether', at: park.park, atEntity: LANE.username });
        record('m3_p0_setup', { park, work, footing, standRec: park.standRec, selfCheck: sc ?? null, calibration: C, modes: MODES, N, ingots: INGOTS, diskFreeGB: diskFreeGB(), seed: SEED, center: S });
        console.log(`[setup] 作业位=${work} 四点支撑=${JSON.stringify(footing)} 猪灵(服务端)=${JSON.stringify(await serverCount())} TPS=${t.clock.tps()}`);
        if (!footing.ok) console.log(`[setup] ⚠ 四点支撑不全（${footing.why} / ${JSON.stringify(footing.names)}）⇒ 站位守护会把 bot 反复拉回`);

        // ── ①b ★ S2-04：**easy + 整套金甲复测**（设计会话要求的更正项）─────
        // 争点：S2-03 §4.1 记「easy 下 29 秒被猪灵连杀 5 次」，归因成"只穿 2 件金装"，
        //   并据此把难度改成 peaceful。设计会话更正：「1.16.1 只要穿**任意**一件金甲
        //   猪灵就不会主动攻击」⇒ 要求查**那一局 kit 是不是真穿上了**（装备槽服务端真值），
        //   **不要据此下「easy 不可行」的结论**。
        // 源码已钉死（`research/piglin_aggro_1161.md`，主 agent 逐行复核）：
        //   `PiglinAi.isWearingGold` 任意一件即 true；它只过滤 4 档攻击目标的**最后一档**，
        //   前 3 档（ANGRY_AT / UNIVERSAL_ANGER / NEAREST_VISIBLE_NEMESIS）不看金。
        // ⇒ 本段要同时量三件事，**分开记**（分不清就等于没测）：
        //   ① 装备槽**服务端真值**（穿没穿上：槽 100–103）
        //   ② 猪灵**攻击状态** `metadata[14]&4`（有没有被激怒 ⇒ 走的是哪一档）
        //   ③ `server.log` 的 `was slain by Piglin`（**死亡硬线**，不靠推断）
        let easyRun = null;
        if (WANT('easy')) {
            easyRun = await easyGoldArmorTrial({ work, cycleMs: C.cycleMs, calib: C });
            record('m3_p1c_easy_gold', easyRun);
        }

        // ── ① 密度时间分布（开放场，站定不动，不投锭）────────────────
        if (WANT('density')) {
            await recallTo(work, { label: 'density' });
            const d = await sampleDensity({ ms: DENSITY_MS, at: botPos(), work });
            const stats = {};
            // ★ **只用有效样本**算分布：失效样本（掉下台/离开下界/区块卸载）会把"没读到"读成"没有猪灵"
            const vrows = d.rows.filter((r) => r.ok);
            for (const rad of d.radii) {
                const k = `n${String(rad).replace('.', '_')}`;
                stats[k] = densityStats(vrows, k);
            }
            stats.total24 = densityStats(vrows, 'total24');
            stats.nearest = densityStats(vrows, 'nearest');
            stats.within6 = densityStats(vrows, 'within6');
            stats.within12 = densityStats(vrows, 'within12');
            stats.samples = { total: d.rows.length, valid: d.valid, invalid: d.invalid, reason: d.reason, deaths: d.deaths, stand: d.stand };
            record('m3_p1_density', { ...d, stats, note: '3 格内同时几头猪灵的时间分布 = techniques-1161 §2.1「喂 4 头」那条打法的未验证前提' });
            console.log('[密度]', JSON.stringify(stats, null, 1).slice(0, 2200));
        }

        // ── ② 三模式同口径（开放场）──────────────────────────────────
        const sweep = [];
        if (WANT('modes')) {
            for (const mode of MODES) {
                const r = await oneMode({ mode, windowMs: WINDOW_MS, work, cycleMs: C.cycleMs, calib: C, groundCount: 1 });
                sweep.push(r);
                record(`m3_p2_mode_${mode}`, r);
                console.log(`[N=${N} ${mode}] 绑=${r.bound}(自然${r.natural}/fixture${r.fixture}) 投锭=${r.rep.throwsOk}/${r.rep.throws} = ${r.rep.throwsPerMin}/分`
                    + ` 周期p50=${r.rep.cycleP50Ms}ms 珍珠=${r.rep.pearls} 补人=${r.rep.rebind.ok}/${r.rep.rebind.attempt} 空转=${Math.round((r.rep.ingotStarvedMs ?? 0) / 1000)}s`
                    + ` reason=${r.rep.reason} 死亡=${JSON.stringify(r.deaths)}`);
            }
            const curve = sweep.map((r) => ({
                mode: r.mode, N: r.N, bound: r.bound, natural: r.natural, fixture: r.fixture,
                windowMin: +(r.rep.windowMs / 60000).toFixed(2),
                throwsOk: r.rep.throwsOk, throwsPerMin: r.rep.throwsPerMin,
                cyclesN: r.rep.cyclesN, cycleP50Ms: r.rep.cycleP50Ms, cycleP10Ms: r.rep.cycleP10Ms, cycleP90Ms: r.rep.cycleP90Ms,
                pearls: r.rep.pearls, pearlsPerMin: r.rep.windowMs ? +(r.rep.pearls / (r.rep.windowMs / 60000)).toFixed(2) : 0,
                ingotsUsed: r.ingots0 - r.ingotsEnd, ingotStarvedSec: Math.round((r.rep.ingotStarvedMs ?? 0) / 1000),
                rebind: r.rep.rebind, slotKilled: r.rep.slotKilled, moves: r.rep.moves, moveSec: +(r.rep.moveMs / 1000).toFixed(1),
                ownDropsSeen: r.rep.ownDropsSeen, tooClose: r.rep.tooClose,
                reason: r.rep.reason, deaths: r.deaths, phases: r.rep.phases, tps: t.clock.tps(),
            }));
            const rank = curve.slice().sort((a, b) => b.throwsPerMin - a.throwsPerMin);
            record('m3_p2_curve', { curve, best: rank[0] ?? null, gate27: rank.filter((c) => c.throwsPerMin >= 27).map((c) => c.mode) });
            console.log('[三模式]', JSON.stringify(curve.map((c) => ({ m: c.mode, tpm: c.throwsPerMin, bound: c.bound, cyc: c.cycleP50Ms, pearls: c.pearls }))));
        }

        // ── ③ 围栏组（**只算引擎上限**；fill 回执全非 0 才开测）────────
        let pen = null;
        if (WANT('pen')) {
            await recallTo(work, { label: 'pen' });
            pen = await buildPen({ r: 4, wallH: 2, at: work });
            record('m3_p3_pen', pen);
            if (!pen.ok) {
                console.log(`[pen] ★ 硬闸未通过（回执 ${JSON.stringify(pen.fillReceipts)}／客户端玻璃 ${pen.clientCheck.glass}/${pen.clientCheck.total}）⇒ **不开测**`);
                record('m3_p3_pen_skipped', { why: 'pen_hard_gate', pen });
            } else {
                const r = await oneMode({ mode: 'wait', windowMs: Math.min(WINDOW_MS, 6 * 60000), work, cycleMs: C.cycleMs, calib: C, label: 'pen/wait' });
                record('m3_p3_pen_run', { ...r, note: '围栏组只读引擎上限（可行性按开放场判）', pen: { ok: pen.ok, fillReceipts: pen.fillReceipts, glassRatio: pen.clientCheck.glassRatio } });
                console.log(`[pen 组] 引擎上限 ${r.rep.throwsPerMin}/分（绑${r.bound} 周期${r.rep.cycleP50Ms}ms）——**不代表可行**`);
            }
        }

        // ── ④ 验收 **0→10 珍珠用时**（S2-04 新验收线，n≥3，报 E 与 P90）────
        // ★ **口径三处修正**（每一条都有前轮实证）：
        //   ① 目标 12 → **10**（设计会话裁决：主种子门室已有 2 颗眼，只需 10 颗）。
        //   ② 计时**必须用背包真值**，不能用引擎的 `stats.pearls`：S2-03 实测引擎记 14/11/4/**0**，
        //      背包真值 32/36/25/23 ⇒ **引擎计数器漏算 3 倍**（`harvest()` 用背包差值，
        //      而**走过掉落物被接触自动捡起**不进 harvest 账）。用引擎数计时会把达标时间读长。
        //      ⇒ 每 tick 采样一次 `invCount().ender_pearl`，首次 ≥ 目标的墙钟就是用时。
        //   ③ 达标**不 break**：验收线是 n≥3（派单 §F）。只有死亡才提前收。
        const pearlRuns = [];
        if (WANT('pearls')) {
            // ★ 珍珠局用哪个模式：**有同口径 sweep 就用最好的那个**；
            //   没有（本轮没跑 `modes` 段）就用 `--pearl-mode` 显式指定的，默认 `wait`。
            // 🚨 S2-04 踩过：`--modes approach` **只影响 modes 段**，对珍珠局毫无作用 ——
            //   珍珠局模式来自 `sweep`，而我只跑了 `--only easy,pearls` ⇒ `sweep` 为空
            //   ⇒ 静默回退成 `wait`，**跑完才发现测的不是 approach**。
            //   ⇒ 现在把实际用的模式**显式打印并落盘**，不再无声回退。
            let best = { mode: PEARL_MODE, throwsPerMin: -1, src: 'explicit' };
            if (WANT('modes') && sweep.length) {
                const top = sweep.slice().sort((a, b) => b.rep.throwsPerMin - a.rep.throwsPerMin)[0];
                best = { mode: top.mode, throwsPerMin: top.rep.throwsPerMin, src: 'sweep_best' };
            }
            console.log(`[珍珠段] 模式=${best.mode}（来源=${best.src}`
                + `${best.src === 'explicit' ? `，即 --pearl-mode=${PEARL_MODE}；⚠--modes 只作用于 modes 段` : ''}）`);
            for (let i = 1; i <= PEARL_RUNS; i++) {
                const r = await oneMode({
                    mode: best.mode, windowMs: PEARL_MS, work, cycleMs: C.cycleMs, calib: C, label: `pearl${i}`,
                    pearlTarget: PEARL_TARGET,
                    // ★ 达标判据读**背包真值**（`pearlsInv`，由 oneMode 逐拍注入）
                    shouldStop: (e) => ((e.pearlsInv ?? 0) >= PEARL_TARGET ? `target_${PEARL_TARGET}` : null),
                });
                const row = { run: i, mode: best.mode, ...r };
                pearlRuns.push(row);
                record(`m3_p4_pearls_run${i}`, row);
                console.log(`[珍珠局 ${i}] 模式=${best.mode} 珍珠(背包)=${r.pearlsInvEnd}/${PEARL_TARGET}`
                    + ` 引擎数=${r.rep.pearls} 投锭=${r.rep.throwsOk}(${r.rep.throwsPerMin}/分)`
                    + ` 锭耗=${r.ingots0 - r.ingotsEnd} 用时=${(r.rep.windowMs / 1000).toFixed(0)}s`
                    + ` reason=${r.rep.reason} 死亡=${JSON.stringify(r.deaths)}`);
                if (r.rep.reason?.startsWith('death')) break;
            }
        }

        // ★ **用时口径**：达标局取「达到目标那一瞬的墙钟」；未达标局记预算值（跑满窗口），
        //   按手册 §5「时间指标按全部 trial 计算（失败局记为预算值）」。
        const pearlTimes = pearlRuns.map((r) => {
            // ★ 达标用时取 `timeToTargetSec`（**背包真值首次达标那一瞬**的墙钟），
            //   不用 `rep.windowMs` —— 后者是引擎 stop 到收工的墙钟，包含 stop 之后
            //   的 harvest（捡拾要最多 20s），会把用时系统性读长。
            const inv = r.pearlsInvEnd ?? 0;
            const sec = r.timeToTargetSec ?? null;
            return {
                run: r.run, mode: r.mode,
                pearlsInv: inv, pearlsInv0: r.pearlsInv0, pearlsEngine: r.rep.pearls,
                reached: inv >= PEARL_TARGET && sec != null,
                sec,                                   // null = 未达标（不参与 E/P90，另行报未达标率）
                secAsBudget: +(r.rep.windowMs / 1000).toFixed(1),   // 未达标局的预算值
                throwsOk: r.rep.throwsOk, throwsPerMin: r.rep.throwsPerMin,
                ingotsUsed: r.ingots0 - r.ingotsEnd, deaths: r.deaths, reason: r.rep.reason,
                armor: r.serverArmor?.verdict ?? null,
                // ⚠ 「0→10」必须是真从 0 起跑：pearlsInv0 非 0 说明上一局有残留
                startedFromZero: (r.pearlsInv0 ?? 0) === 0,
            };
        });
        const reached = pearlTimes.filter((r) => r.reached);
        // ★ 统计走 `truth.mjs#pearlTimeStats` 那个**共用纯函数** ——
        //   这样离线自检测的就是线上真跑的那段（手抄两份必然漂）。
        const tstat = pearlTimeStats(pearlTimes, { goalSec: PEARL_GOAL_SEC });

        const curve = sweep.map((r) => ({ mode: r.mode, throwsPerMin: r.rep.throwsPerMin, bound: r.bound, cycleP50Ms: r.rep.cycleP50Ms, pearls: r.rep.pearls }));
        const n4 = curve.find((c) => c.N === N) ?? curve[0];
        const verdict = {
            seed: SEED, center: S, N, modes: MODES, windowMin: WINDOW_MS / 60000,
            easyGoldArmor: easyRun ? { verdict: easyRun.verdict, deaths: easyRun.deaths?.length ?? 0, serverArmor: easyRun.serverArmor?.before?.verdict ?? null } : null,
            curve, pen: pen ? { ok: pen.ok, fillReceipts: pen.fillReceipts, glassRatio: pen.clientCheck.glassRatio } : null,
            // ★ S2-04 新验收线：`timeTo10Pearls`（秒），达标线 ≤180s（v1）
            timeTo10Pearls: {
                ...tstat,
                rows: pearlTimes,
                note: '计时口径=背包真值 invCount().ender_pearl 首次达标那一瞬；'
                    + '引擎 stats.pearls 漏算"走过掉落物被接触自动捡起"（S2-03：引擎 14/11/4/0 vs 背包 32/36/25/23）',
            },
            pearls: {
                target: PEARL_TARGET, runs: pearlRuns.length, achieved: reached.length,
                rows: pearlTimes,
            },
            gate: {
                n_throwsPerMin: n4?.throwsPerMin ?? null,
                gate27: (n4?.throwsPerMin ?? 0) >= 27,           // ⚠ S2-04 已作废（N=4 ≥27 在自然站不可达）
                target37: (n4?.throwsPerMin ?? 0) >= 37,
                pearls_n_ge_3: reached.length >= PEARL_RUNS,
                // ★ S2-04 新门：n≥3 局全部达标 且 E ≤180s
                timeTo10_le_180: tstat.gate,
            },
            tps: t.clock.tps(), diskFreeGB: diskFreeGB(),
        };
        record('m3_p5_verdict', verdict);
        writeSummary(verdict);
        console.log('[验收]', JSON.stringify(verdict.gate));
    } catch (e) {
        console.error('[m3] 失败：', e);
        try { record('error', { message: String(e?.message ?? e), stack: String(e?.stack ?? '').slice(0, 900) }); } catch { /* 忽略 */ }
        try { writeSummary({ failed: String(e?.message ?? e) }); } catch { /* 忽略 */ }
        process.exitCode = 1;
    } finally {
        await closeRun();
    }
}

async function serverCount(sel = '@e[type=piglin]') {
    try {
        const r = await truth().countEntities('the_nether', LANE.username, sel, { quietMs: 800, minWaitMs: 6000, timeoutMs: 25000 });
        return { n: r.n, trusted: r.trusted };
    } catch (e) { return { n: null, error: String(e?.message ?? e).slice(0, 80) }; }
}

/** 安全进场：先 parkSafe（高空缓降 + 真值竖扫），再 standNatural 落到**地面**格（猪灵只在地面） */
async function parkAndStand() {
    const park = await parkSafe({ cx: S.x, cz: S.z, yLo: S.yLo, yHi: 100, r: 4 });
    await sleep(4000);
    if (WORK_PIN) {
        // 钉住作业位：仍然走真值复核（feet=air + 脚下实心非液体），不许盲信 --work
        await recallTo([WORK_PIN.x, WORK_PIN.y, WORK_PIN.z], { label: 'work-pin' });
        const t = truth();
        const feet = await t.probeCell('the_nether', { x: WORK_PIN.x, y: WORK_PIN.y, z: WORK_PIN.z }, ['minecraft:air']);
        const floor = await t.probeCell('the_nether', { x: WORK_PIN.x, y: WORK_PIN.y - 1, z: WORK_PIN.z },
            ['minecraft:netherrack', 'minecraft:blackstone', 'minecraft:basalt', 'minecraft:crimson_nylium', 'minecraft:warped_nylium', 'minecraft:soul_soil']);
        if (feet.hit !== 'minecraft:air' || !floor.hit) throw new Error(`WORK_PIN_INVALID：${JSON.stringify(WORK_PIN)} feet=${feet.hit} floor=${floor.hit}`);
        return { park, stand: [WORK_PIN.x, WORK_PIN.y, WORK_PIN.z], standRec: { pinned: true, cell: [WORK_PIN.x, WORK_PIN.y, WORK_PIN.z], verified: { feet: feet.hit, floor: floor.hit } } };
    }
    const stand = await standNatural({ cx: S.x, cz: S.z, r: 22, yLo: S.yLo, yHi: S.yHi + 30 });
    if (!stand) throw new Error('STAND_NATURAL_FAILED：新中心 [336,256] 找不到可站自然地面（作业位必须是地面格）');
    return { park, stand: stand.stand, standRec: stand };
}

// `--dry`：**不起服**的解析自检（import 图 + 语法），收工前先跑一遍，省得白等一次排队。
if (process.argv.includes('--dry')) {
    console.log(`[dry] 解析通过：模式=${MODES} N=${N} 窗口=${WINDOW_MS / 60000}min 密度=${DENSITY_MS / 60000}min `
        + `珍珠局=${PEARL_RUNS}×${PEARL_TARGET} 只跑=${ONLY.join(',')} 盘=${STATION.bastion.x},${STATION.bastion.z} 种子=${SEED}`);
} else {
    main();
}

