// mode3_selftest.mjs — S2-03 的**离线**自检（假 bot，不开服、不占泳道）
//
// 覆盖的全是本轮真刀真枪改掉的东西，一条条对着"上一轮踩的坑"设计：
//   ① 三模式路由（wait 等猪灵过来 / ground 地面投锭 / approach 主动走近）
//   ② 补人（DEAD 槽重新拉人 + 节流 + "为什么拉不上"的逐候选证据）
//   ③ 死亡即中止（guard 在每轮 step **之前**生效，不许死后再投一次）
//   ④ **自己丢出去的金锭不算礼物**（ground 模式的头号误判源）
//   ⑤ 重复绑定（4 个槽绑同一头猪灵 ⇒ N 槽静默退化成 1 槽）
//   ⑥ 太近不杀槽 / 出窗才杀槽（approach 不杀）
//
// 用法：node mode3_selftest.mjs
//
// 验收线的反直觉点：大部分断言是**反的**——"必须**不**发生某事"（不把 own drop 当礼物、
// 不死后再投、不重复绑定）比"发生了某事"更难被真局发现，因为真局只会给出一个难看的总数。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(DIR, '../../..');
const WT = path.join(ROOT, 'mindcraft-wt', 's2-barter');
const SRC = path.join(WT, 'src', 'agent', 'tasks', 'exec', 'piglin.js');
const require = createRequire(path.join(WT, 'main.js'));
const { Vec3 } = require('vec3');

let failed = 0;
let group = '';
const ok = (cond, msg, extra = '') => {
    if (cond) console.log(`  PASS ${msg}`);
    else { failed++; console.log(`  FAIL ${msg} ${extra}`); }
};
const G = (t) => { group = t; console.log(`${t}`); };

// ---------------------------------------------------------------- 假 bot / 假实体
/** 按 1.16.1 实测布局造猪灵（8=血量16、13=装备表空时为 null、无 age） */
function mkPiglin(id, pos, { hp = 16, holding = false } = {}) {
    const md = [0, 300, null, false, false, false, 0, 0, hp, 0, false, 0, 0, null, 0, false, false, false, false];
    if (holding) md[13] = [{ name: 'gold_ingot', count: 1 }, null];
    return { id, name: 'piglin', position: pos, width: 0.9, height: 1.9, metadata: md };
}
/** 掉落物：itemOf() 认 metadata[5] 的 {name,count} 形态 */
function mkDrop(id, pos, { name = 'ender_pearl', count = 1 } = {}) {
    return { id, name: 'item', position: pos, metadata: [0, 0, 0, 0, 0, { name, count }] };
}
function mkBot({
    pos = new Vec3(0, 40, 0), ingots = 64, piglins = [], drops = [], los = true,
    floorName = 'netherrack', tossApi = 'toss', wallAt = null,
} = {}) {
    const bot = {
        entity: { id: 1, position: pos, eyeHeight: 1.62, yaw: 0, pitch: 0, onGround: true },
        entities: {},
        health: 20,
        _inv: [{ name: 'gold_ingot', count: ingots }],
        _ingot: () => bot._inv.find((x) => x.name === 'gold_ingot'),
        _dropSeq: 0,
        inventory: { items: () => bot._inv.slice(), slots: [null, null, null, null, null, null, null, null, null] },
        blockAt: (p) => {
            if (wallAt && Math.abs(p.x - wallAt.x) < 0.6 && Math.abs(p.z - wallAt.z) < 0.6 && p.y > pos.y && p.y < pos.y + 2.4) {
                return { name: 'stone', boundingBox: 'block' };
            }
            if (!los && p.x > pos.x + 0.6 && p.y >= pos.y && p.y <= pos.y + 2.2) return { name: 'stone', boundingBox: 'block' };
            return { name: p.y < pos.y ? floorName : 'air', boundingBox: 'block' };
        },
        equip: async (it) => { bot.heldItem = it; return it; },
        activateEntity: async (e) => {
            bot.activated = (bot.activated ?? []).concat([e.id]);
            const g = bot._ingot(); if (g) g.count -= 1;
        },
        pathfinder: {
            goals: { GoalNear: class { constructor(x, y, z, r) { Object.assign(this, { x, y, z, r }); } } },
            goto: (goal) => {
                bot.gotos = (bot.gotos ?? []); bot.gotos.push({ x: goal.x, y: goal.y, z: goal.z });
                // 假导航：立刻把 bot 挪到目标点（够用来测"会不会走过去"）
                bot.entity.position = new Vec3(goal.x + 0.5, goal.y, goal.z + 0.5);
                return Promise.resolve();
            },
            stop: () => {},
        },
        _client: {
            write: (name, pkt) => {
                bot.packets = bot.packets ?? []; bot.packets.push(name);
                if (name === 'block_dig' && pkt?.status === 4) {
                    const g = bot._ingot(); if (g) g.count -= 1;
                    bot._spawnDropNear(bot.entity.position, 0.9);      // Q 丢的锭就在脚边
                }
            },
        },
        clearControlStates: () => {},
        tossStack: async (it) => { bot._inv.splice(bot._inv.indexOf(it), 1); },
    };
    if (tossApi === 'toss') {
        // 真实 bot.toss 语义：transfer 的 destStart=-999 会把**整摞**丢出去
        bot.toss = async (itemType, metadata, count) => {
            const it = bot._inv.find((x) => x.name === itemType);
            if (!it) throw new Error('no such item');
            const n = Math.min(it.count, count ?? it.count);
            it.count -= n;
            bot._spawnDropNear(bot.entity.position, 0.9);
            return n;
        };
    }
    bot._spawnDropNear = (p, r = 0.9) => {
        bot._dropSeq += 1;
        const id = 9000 + bot._dropSeq;
        bot.entities[String(id)] = mkDrop(id, p.offset(0.4, 0, 0.3), { name: 'gold_ingot', count: 64 });
        return id;
    };
    bot.addPiglin = (e) => { bot.entities[String(e.id)] = e; return e; };
    for (const p of piglins) bot.addPiglin(p);
    for (const d of drops) bot.entities[String(d.id)] = d;
    return bot;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const pig = await import(`file:///${SRC.replace(/\\/g, '/')}`);

// ================================================================ ⓪ hasLos 回归锁
G('⓪ hasLos 回归锁：vec3 的 normalize()/scale() 原地改会毁掉采样点（S2-03 逮到的真 bug）');
{
    // 记录 blockAt 被问到哪些点，用来判"采样是否沿直线单调前进"
    const seen = [];
    const pos = new Vec3(0, 40, 0);
    const mkLosBot = (floorY = 40) => ({
        entity: { id: 1, position: pos, eyeHeight: 1.62 },
        blockAt: (p) => {
            seen.push([+p.x.toFixed(2), +p.y.toFixed(2), +p.z.toFixed(2)]);
            return { name: Math.floor(p.y) < floorY ? 'netherrack' : 'air', boundingBox: 'block' };
        },
    });
    const e = mkPiglin(1, new Vec3(10, 40, 0));
    seen.length = 0;
    const r = pig.hasLos(mkLosBot(), e, { maxDist: 20 });
    ok(r === true, '★ 10 格外的**通视**目标判为有视线（回归锁：旧版这里返回 false）', String(r));
    const xs = seen.map((s) => s[0]);
    let mono = true;
    for (let i = 1; i < xs.length; i++) if (xs[i] <= xs[i - 1]) mono = false;
    ok(mono, '采样点沿视线**单调前进**（不再指数爆走）', `xs=${JSON.stringify(xs)}`);
    ok(Math.max(...xs) < 10, '采样点不越过目标（旧版会跑到 28.55 格）', `maxX=${Math.max(...xs)}`);
    ok(seen.length >= 20, '长距离真的做了逐格采样（不是只查眼前）', `n=${seen.length}`);
    // 反例：真有一堵墙在中间 ⇒ 必须判 no_los（阳性对照，防"修完变成永远 true"）
    const wallBot = {
        entity: { id: 1, position: pos, eyeHeight: 1.62 },
        blockAt: (p) => (p.x > 4 && p.x < 5.5 && p.y > 40 && p.y < 43 ? { name: 'stone', boundingBox: 'block' } : { name: p.y < 40 ? 'netherrack' : 'air', boundingBox: 'block' }),
    };
    ok(pig.hasLos(wallBot, e, { maxDist: 20 }) === false, '中间有实心 ⇒ no_los（阳性对照）');
    // 短距离仍然通视（不把 S2-01 那些 2.0–3.4 格的成交判据弄坏）
    const near = mkPiglin(2, new Vec3(2.8, 40, 0));
    ok(pig.hasLos(mkLosBot(), near) === true, '2.8 格通视仍然 true（不回归 S2-01 的成交距离）', String(pig.hasLos(mkLosBot(), near)));
}

// ================================================================ ① 模式归一
G('① 模式名与路由常量');
{
    ok(pig.THROW_MODES.join(',') === 'wait,ground,approach', '三种打法固定为 wait/ground/approach', pig.THROW_MODES.join(','));
    ok(pig.normalizeMode('feed') === 'wait', '旧名 feed → wait', pig.normalizeMode('feed'));
    ok(pig.normalizeMode('GROUND') === 'ground' && pig.normalizeMode(null) === 'wait', '大小写与空值兜底');
}

// ================================================================ ② 补人
G('② 补人：DEAD 槽重新拉人 + 节流 + 失败留证据');
{
    const b = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0)), mkPiglin(2, new Vec3(2.0, 40, 2.0))] });
    const e = new pig.BarterEngine(b, { slots: 2, mode: 'wait' });
    const n = e.bind();
    ok(n === 2, '两个槽都绑上（阳性对照）', String(n));

    // 实体从 bot.entities 消失 ⇒ 该槽 DEAD
    const slot = e.slots[0];
    const deadId = slot.e.id;
    delete b.entities[String(deadId)];
    await e.stepSlot(slot);
    ok(slot.state === 'DEAD' && slot.e === null && slot.killWhy === 'entity_gone', '实体消失 ⇒ 槽 DEAD 且记原因', `${slot.state}/${slot.killWhy}`);

    // ★★ 走**完整 step 路径**（不是直接调 tryRebind）：S2-03 实跑踩到过"DEAD 分支排在
    //    实体消失检查之后 ⇒ 每 tick 重复 killSlot、tryRebind 永远走不到"（rebind.attempt=0）。
    const eB = mkBot({ piglins: [mkPiglin(11, new Vec3(2.8, 40, 0))] });
    const eE = new pig.BarterEngine(eB, { slots: 1, mode: 'wait', rebindEveryMs: 0, collect: false });
    eE.bind();
    delete eB.entities['11'];
    await eE.step();                                   // 第 1 步：IDLE → DEAD（此刻还不补人）
    await eE.step();                                   // 第 2 步起：DEAD 分支必须去补人
    ok(eE.stats.rebindAttempt >= 1, '★ 走 step() 时 DEAD 槽会真的去补人（不是每 tick 重复打死）', `attempt=${eE.stats.rebindAttempt}`);
    ok(eE.slots[0].killWhy === 'entity_gone', '失效原因仍是 entity_gone', String(eE.slots[0].killWhy));
    // 幂等：连续判死不许把计数刷成几万条
    const before2 = eE.stats.slotKilled.entity_gone ?? 0;
    await eE.step(); await eE.step();
    ok((eE.stats.slotKilled.entity_gone ?? 0) === before2, '★ 重复判死是幂等的（slotKilled 不刷屏）', `${before2}→${eE.stats.slotKilled.entity_gone ?? 0}`);

    // 节流：连着两次 tryRebind 只应产生一次 attempt
    e.tryRebind(slot, Date.now());
    const before = e.stats.rebindAttempt;
    e.tryRebind(slot, Date.now());
    ok(e.stats.rebindAttempt === before, '补人有节流（rebindEveryMs 内不重复扫）', `attempt ${before}→${e.stats.rebindAttempt}`);

    // 换人：把新猪灵放进来，force 补人应当成功
    b.addPiglin(mkPiglin(3, new Vec3(2.0, 40, -2.0)));
    const r = e.tryRebind(slot, Date.now(), { force: true });
    ok(r.ok === 1 && slot.state === 'IDLE' && slot.e?.id === 3, '补人成功并切到新猪灵', JSON.stringify(r));
    ok(e.stats.rebindOk >= 1, 'rebindOk 有账', String(e.stats.rebindOk));

    // 补不上人：必须留下"为什么"的逐候选 tally
    const b2 = mkBot({ piglins: [mkPiglin(9, new Vec3(2.8, 40, 0))] });
    const e2 = new pig.BarterEngine(b2, { slots: 2, mode: 'wait', rebindEveryMs: 0 });
    e2.bind();
    e2.slots[1].state = 'DEAD'; e2.slots[1].e = null;
    const far = e2.tryRebind(e2.slots[1], Date.now(), { force: true });
    ok(far.ok === 0, '窗口内没第二头 ⇒ 补不上（如实）', JSON.stringify(far));
    ok(e2.stats.whySamples.length >= 1, '补不上时留下 whySamples（诊断证据）', String(e2.stats.whySamples.length));
    const tally = e2.stats.whySamples[0]?.tally ?? {};
    ok(Object.keys(tally).length > 0, 'tally 有内容（知道是被哪一条筛掉的）', JSON.stringify(tally));
    ok(e2.stats.rebindFail >= 1, 'rebindFail 有账', String(e2.stats.rebindFail));
    // replenish() 主动补人接口
    b2.addPiglin(mkPiglin(10, new Vec3(2.0, 40, 2.0)));
    const got = e2.replenish();
    ok(got >= 1, 'replenish() 能主动补上', String(got));
}

// ================================================================ ③ 死亡即中止
G('③ 死亡即中止（guard 在每轮 step 之前生效）');
{
    const b = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0)), mkPiglin(2, new Vec3(2.8, 40, 2))] });
    let dead = false;
    const e = new pig.BarterEngine(b, {
        slots: 2, mode: 'wait', cycleTimeoutMs: 800, harvestEveryRounds: 999,
        guard: () => (dead ? 'death:was slain by Piglin' : null),
    });
    e.bind();
    e.bind();
    const t0 = Date.now();
    // 第一次：跑到有投锭为止，然后把"死亡"打开
    const p = e.run({ windowMs: 600 });
    await sleep(180);
    const throwsBeforeDeath = e.stats.throwsOk;
    dead = true;
    const rep = await p;
    ok(/^death/.test(rep.reason), '死亡后 run() 以 death 原因收尾（不再跑满窗口）', rep.reason);
    ok(rep.guardHits.length >= 1 && rep.guardHits[0].why.includes('was slain'), 'guard 命中原因进遥测', JSON.stringify(rep.guardHits[0] ?? null));
    ok(Date.now() - t0 < 3000, '中止是**立刻**的（不是等窗口跑完）', `${Date.now() - t0}ms`);
    ok(e.running === false && e.stopReason?.startsWith('death'), 'running=false 且 stopReason 落账', String(e.stopReason));
    // ★ 关键：死亡之后**一次都不许再投**（guard 在 step 前）
    const after = e.stats.throwsOk;
    await sleep(150);
    ok(e.stats.throwsOk === after, '死亡后不再发生投锭', `throwsOk ${after}→${e.stats.throwsOk}`);

    // guard 自己抛异常也不能把状态机带崩
    const b2 = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0))] });
    const e2 = new pig.BarterEngine(b2, { slots: 1, guard: () => { throw new Error('boom'); } });
    e2.bind();
    const rep2 = await e2.run({ windowMs: 300 });
    ok(/^guard_threw/.test(rep2.reason), 'guard 抛异常被兜住并记成 guard_threw（不静默卡死）', rep2.reason);
}

// ================================================================ ④ 自己丢的不算礼物
G('④ ★ ground 模式：自己丢出去的那摞锭**不能**被当成礼物');
{
    // 4-1 默认开启排除 ⇒ 自己的锭不记成 cycle_done，礼物才记
    // ⚠ 用 groundCount:1（逐个丢）而不是 'stack'：整摞丢完背包就空了，
    //   引擎的 `countIngots<=0` 早退会让后面所有断言变成"空跑"（本轮真的踩到过一次）。
    const b = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0))] });
    const e = new pig.BarterEngine(b, { slots: 1, mode: 'ground', groundCount: 1, cycleTimeoutMs: 900, collect: false });
    e.bind();
    await e.step();                       // 投出去
    ok(e.stats.throwsOk === 1, 'ground 投出去了', JSON.stringify(e.stats.throwsOk));
    ok(e.ownDrops.size >= 1, '自己丢的物品实体被登记进 ownDrops', String(e.ownDrops.size));
    await e.step();                       // ★ 必须再走一轮才进 WAIT_DROP 的判据（否则这条断言是空跑）
    ok(e.stats.cycles.length === 0, '★ 自己的锭**没有**被记成一次成交（周期仍为 0）', JSON.stringify(e.stats.cycles));
    ok(e.slots[0].state === 'WAIT_DROP', '槽正等着礼物（状态机在正确的态上）', e.slots[0].state);

    // 礼物出现（猪灵脚边、不是 ownDrops）⇒ 这一刻才记周期
    b.entities['7777'] = mkDrop(7777, new Vec3(3.4, 40, 0.2), { name: 'ender_pearl', count: 1 });
    await sleep(60);
    await e.step();
    ok(e.stats.cycles.length === 1, '礼物掉落物出现才记一次周期', JSON.stringify(e.stats.cycles));
    ok(e.stats.cycles[0] > 100, '周期是"投出→礼物"的真实时长（不是投出瞬间）', String(e.stats.cycles[0]));

    // 4-2 反向对照：关掉排除 ⇒ 自己的锭立刻被误判成礼物（证明这条排除是**起作用的**）
    const b2 = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0))] });
    const e2 = new pig.BarterEngine(b2, { slots: 1, mode: 'ground', groundCount: 1, ownDropExclude: false, cycleTimeoutMs: 900, collect: false });
    e2.bind();
    await e2.step();
    await e2.step();
    ok(e2.stats.cycles.length === 1 && e2.stats.cycles[0] < 400,
        '★ 反例：关掉排除就会把"我丢的锭"读成 0.x 秒的假周期', JSON.stringify(e2.stats.cycles));
    ok(e2.ownDrops.size >= 1, '（登记照做，只是 findDropNear 不再排除 ⇒ 对照成立）', String(e2.ownDrops.size));

    // 4-3 'stack' 语义：bot.toss 丢的是**整摞**（transfer 的 movedItems=min(stackSize,count)），
    //     并且丢完背包见底 ⇒ 引擎要如实记"没原料空转"，不能装作还在打。
    const b3 = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0))], ingots: 64 });
    const e3 = new pig.BarterEngine(b3, { slots: 1, mode: 'ground', groundCount: 'stack', collect: false });
    e3.bind();
    await e3.step();
    ok(b3._ingot().count === 0 && e3.stats.throwsOk === 1, '整摞丢：一次 64 块全出手', `${b3._ingot().count}/${e3.stats.throwsOk}`);
    const beforeR = e3.stats.starvedRounds;
    await e3.step(); await e3.step();
    ok(e3.stats.starvedRounds > beforeR, '没金锭时记 starved 空转（区分"打不动"与"没原料"）', `${beforeR}→${e3.stats.starvedRounds}`);
}

// ================================================================ ⑤ 重复绑定
G('⑤ 4 个槽不许绑同一头猪灵（否则 N 槽静默退化成 1 槽）');
{
    const b = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0)), mkPiglin(2, new Vec3(2.8, 40, 1.5))] });
    const e = new pig.BarterEngine(b, { slots: 4, mode: 'wait' });
    const n = e.bind();
    const ids = e.slots.filter((s) => s.e).map((s) => s.e.id);
    ok(n === 2, '只有 2 头猪灵 ⇒ 只绑 2 槽（如实报，不硬凑 4）', String(n));
    ok(new Set(ids).size === ids.length, '★ 绑上的槽互不重复', JSON.stringify(ids));
    ok(e.slots.filter((s) => !s.e).every((s) => s.killWhy === 'never_bound'), '绑不上的槽记 never_bound', JSON.stringify(e.slots.map((s) => s.killWhy)));
}

// ================================================================ ⑥ 三模式路由
G('⑥ 三种打法在同一场景下的路由差异（唯一变量 = 模式）');
{
    // 10 格外的猪灵：wait 绑不到（窗口外）；approach 能绑（这正是"主动走近"的前提）
    const mkFar = () => mkPiglin(1, new Vec3(10, 40, 0));
    const bW = mkBot({ piglins: [mkFar()] });
    const eW = new pig.BarterEngine(bW, { slots: 1, mode: 'wait' });
    ok(eW.bind() === 0, 'wait 模式：10 格外的猪灵绑不上（等它过来）', 'bound=0');
    const bA = mkBot({ piglins: [mkFar()] });
    const eA = new pig.BarterEngine(bA, { slots: 1, mode: 'approach', approachRadius: 12, approachStandoff: 2.8 });
    ok(eA.bind() === 1, 'approach 模式：10 格外的猪灵绑得上（主动走过去）', `bound=${eA.slots[0]?.e?.id}`);
    await eA.step();
    ok(eA.stats.moves >= 1, 'approach 模式真的发出了移动', `moves=${eA.stats.moves}`);
    ok(eA.slots[0].state !== 'DEAD', '★ approach 出窗不杀槽（换角度再走近）', eA.slots[0].state);

    // wait 模式出窗要杀槽（对照组：这条行为不能被 approach 的改动带跑）
    const bW2 = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0))] });
    const eW2 = new pig.BarterEngine(bW2, { slots: 1, mode: 'wait' });
    eW2.bind();
    bW2.entities['1'].position = new Vec3(20, 40, 0);          // 猪灵走远了
    await eW2.stepSlot(eW2.slots[0]);
    ok(eW2.slots[0].state === 'DEAD' && eW2.slots[0].killWhy === 'out_of_range', 'wait 模式出窗 ⇒ 杀槽换人', eW2.slots[0].killWhy);

    // ground 模式不需要视线（丢在地上让它自己来）
    // ⚠ 猪灵必须落在**两种模式都够得着**的距离上（3.0 格：wait 窗口内、ground 窗口内），
    //   否则分不清"绑不上"是模式差异还是距离差异。
    const bG = mkBot({ piglins: [mkPiglin(1, new Vec3(3.0, 40, 0))], wallAt: { x: 1.5, z: 0 } });
    const eG = new pig.BarterEngine(bG, { slots: 1, mode: 'ground', groundRadius: 9 });
    ok(eG.bind() === 1, 'ground 模式：视线被挡也能绑（不依赖交互）', `bound=${eG.slots[0]?.e?.id}`);
    const bW3 = mkBot({ piglins: [mkPiglin(1, new Vec3(3.0, 40, 0))], wallAt: { x: 1.5, z: 0 } });
    const eW3 = new pig.BarterEngine(bW3, { slots: 1, mode: 'wait' });
    ok(eW3.bind() === 0, 'wait 模式：同样的被挡场景绑不上（证明是模式差异不是场景问题）', 'bound=0');
    ok(JSON.stringify(eW3.stats.bindWhy ?? []).includes('no_los'), '原因记的是 no_los（不是别的）', JSON.stringify(eW3.stats.bindWhy ?? []).slice(0, 140));
    // 阳性对照：同一场景去掉墙 ⇒ wait 也能绑（防"永远绑不上"的假通过）
    const bW4 = mkBot({ piglins: [mkPiglin(1, new Vec3(3.0, 40, 0))] });
    const eW4 = new pig.BarterEngine(bW4, { slots: 1, mode: 'wait' });
    ok(eW4.bind() === 1, '阳性对照：没有墙时 wait 模式绑得上（墙才是变量）', `bound=${eW4.slots[0]?.e?.id}`);

    // ground 模式不 equip：走 bot.toss 一路（断言真的用了 bot.toss 而不是兜底的 block_dig）
    const bG2 = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0))] });
    const eG2 = new pig.BarterEngine(bG2, { slots: 1, mode: 'ground', groundCount: 'stack', collect: false });
    eG2.bind();
    await eG2.stepSlot(eG2.slots[0]);
    const ev = eG2.events.find((x) => x.tossApi);
    ok(ev?.tossApi === 'bot.toss', '★ ground 走的是 bot.toss（mineflayer 4.38 确实有）', JSON.stringify(ev ?? null));

    // 没有 bot.toss 的老 bot ⇒ 必须自动兜底到 block_dig 而不是静默失败
    const bG3 = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0))], tossApi: 'none' });
    const eG3 = new pig.BarterEngine(bG3, { slots: 1, mode: 'ground', groundCount: 3, collect: false });
    eG3.bind();
    await eG3.stepSlot(eG3.slots[0]);
    const ev3 = eG3.events.find((x) => x.tossApi);
    ok(ev3?.tossApi === 'block_dig' && eG3.stats.throwsOk === 1, '没有 bot.toss 时兜底 block_dig 仍能出手', JSON.stringify(ev3 ?? null));
    ok(bG3._ingot().count === 61, '兜底路径扣了 3 块（64→61）', String(bG3._ingot().count));
}

// ================================================================ ⑦ 太近不杀槽
G('⑦ 猪灵凑太近不许把槽打死（上一轮 d<minDist 直接丢槽）');
{
    const b = mkBot({ piglins: [mkPiglin(1, new Vec3(0.5, 40, 0))] });
    const e = new pig.BarterEngine(b, { slots: 1, mode: 'wait', minDist: 1.3, maxDist: 3.4, collect: false });
    e.slots = [{ idx: 0, e: b.entities['1'], state: 'IDLE', throws: 0, ok: 0, miss: 0, tThrow: 0, cycleMs: null, lastDrop: null, cycleArmed: false, lastRebindAt: 0, lastMoveAt: 0, lastCloseAt: 0, deadSince: 0, killWhy: null }];
    e.home = b.entity.position;
    await e.stepSlot(e.slots[0]);
    ok(e.slots[0].state === 'IDLE', '太近时槽保持 IDLE（不判失效）', e.slots[0].state);
    ok(e.stats.tooClose === 1 && e.stats.throws === 0, '记一次 too_close 且**没有**投锭', JSON.stringify({ close: e.stats.tooClose, throws: e.stats.throws }));
    // 再 step 一次：too_close 有 2s 节流，不会刷屏
    await e.stepSlot(e.slots[0]);
    ok(e.stats.tooClose === 1, 'too_close 有节流（不刷屏）', String(e.stats.tooClose));
}

// ================================================================ ⑧ report 字段
G('⑧ report 带齐 S2-03 的账（补人/移动/ownDrops/guard）');
{
    const b = mkBot({ piglins: [mkPiglin(1, new Vec3(2.8, 40, 0))] });
    const e = new pig.BarterEngine(b, { slots: 1, mode: 'ground', groundCount: 'stack', collect: false, guard: () => null });
    e.bind();
    await e.run({ windowMs: 250 });
    const r = e.report(250, 'window');
    for (const k of ['mode', 'rebind', 'slotKilled', 'moves', 'moveMs', 'ownDropsSeen', 'guardHits', 'cycleP50Ms']) {
        ok(Object.prototype.hasOwnProperty.call(r, k), `report 字段 ${k}`, JSON.stringify(r[k]));
    }
    ok(r.mode === 'ground', 'report 回显模式名', r.mode);
    ok(r.rebind.attempt >= 0 && typeof r.slotKilled === 'object', 'rebind/slotKilled 是结构化字段', JSON.stringify(r.rebind));
}

// ================================================================ ⑨ watchDeaths（死亡通道）
G('⑨ watchDeaths：死亡中止那条通道不许是死代码（S2-01 踩过：局部 path 遮蔽 ⇒ TDZ 抛）');
{
    // ⚠ 这里动态 import harness.mjs：它只在 import 期读路径/常量，不起服、不连池。
    const H = await import(`file:///${path.join(DIR, 'harness.mjs').replace(/\\/g, '/')}`);
    const tmp = path.join(DIR, 'runs', '_selftest_death.log');
    fs.mkdirSync(path.dirname(tmp), { recursive: true });
    fs.writeFileSync(tmp, '[00:00:00] BarterBotC joined the game\n');
    let w = null, threw = null;
    try { w = H.watchDeaths(tmp); } catch (e) { threw = e; }
    ok(!threw, '★ watchDeaths() 调用不抛（上一版因局部 `path` 遮蔽直接 TDZ 死掉）', String(threw));
    ok(!!w && Array.isArray(w.deaths), '返回 deaths 数组', String(!!w));
    // 往假日志追加一条死亡消息，等轮询抓到
    fs.appendFileSync(tmp, '[00:00:05] BarterBotC was slain by Piglin\n');
    let hit = null;
    for (let i = 0; i < 20 && !hit; i++) { await sleep(150); hit = w.deaths[0] ?? null; }
    w.stop();
    ok(!!hit && /was slain by Piglin/.test(hit.cause), '能抓到 server.log 里的死亡消息（自维护文件偏移）', JSON.stringify(hit));
    // 阴性对照：非死亡行不许被算成死亡
    fs.writeFileSync(tmp, '[00:00:00] BarterBotC joined the game\n[00:00:01] BarterBotC has the following entity data: [1.0d, 2.0d, 3.0d]\n');
    let w2 = null;
    try { w2 = H.watchDeaths(tmp); } catch { /* 上面已证不抛，这里只是兜住 */ }
    fs.appendFileSync(tmp, '[00:00:02] Preparing spawn area: 12%\n');
    await sleep(2600);
    const n2 = w2 ? w2.deaths.length : -1;
    w2?.stop();
    ok(n2 === 0, '非死亡行（data get 回执/刷怪进度）不误报死亡', `deaths=${n2}`);
}

// ================================================================ ⑩ 捡拾：名字读不出也要捡
G('⑩ 掉落物名字读不出（1.16.1 `itemOf` → `?`）时**必须照捡**，否则珍珠永远是 0');
{
    // 造一个"名字读不出"的掉落物（metadata 里没有可识别的 {name,count} 形态）
    const b = mkBot({ pos: new Vec3(0, 40, 0), items: [], piglins: [] });
    b.entities['500'] = { id: 500, name: 'item', position: new Vec3(1.2, 40, 0), metadata: [0, 0, 0, 0, 0, null] };
    const { listDrops, itemOf } = await import(`file:///${SRC.replace(/\\/g, '/')}`);
    ok(itemOf(b.entities['500']) === null, 'itemOf 对 1.16.1 掉落物返回 null（名字读不出，已知限制）');
    const seen = listDrops(b, { radius: 8 });
    ok(seen.length === 1 && seen[0].name === '?', 'listDrops 把它记成 ? 而不是编一个名字', JSON.stringify(seen[0] ?? null));
    // 关键：collectDrops 必须捡它
    let goalRan = 0;
    b.pathfinder = {
        goals: { GoalFollow: class { constructor(e) { this.e = e; } } },
        goto: () => { goalRan++; return Promise.resolve(); },
        stop: () => {},
    };
    const r = await pig.collectDrops(b, { radius: 8, perItemMs: 300, timeoutMs: 2000, home: new Vec3(0, 40, 0), safeRadius: 4.5 });
    ok(goalRan >= 1 && r.picked.length === 1, '★ 名字读不出的掉落物也被捡走（珍珠通道）', JSON.stringify({ goalRan, picked: r.picked }));
    // 反例：显式关掉 acceptUnknown ⇒ 必须不捡（证明这条开关是起作用的）
    const b2 = mkBot({ pos: new Vec3(0, 40, 0), items: [], piglins: [] });
    b2.entities['501'] = { id: 501, name: 'item', position: new Vec3(1.2, 40, 0), metadata: [0, 0, 0, 0, 0, null] };
    let goal2 = 0;
    b2.pathfinder = { goals: { GoalFollow: class { constructor(e) { this.e = e; } } }, goto: () => { goal2++; return Promise.resolve(); }, stop: () => {} };
    const r2 = await pig.collectDrops(b2, { radius: 8, perItemMs: 300, timeoutMs: 1500, acceptUnknown: false });
    ok(goal2 === 0 && r2.picked.length === 0, '反例：关掉 acceptUnknown 就不捡（对照成立）', JSON.stringify({ goal2, picked: r2.picked }));
}

// ================================================================ ⑪ 装备槽真值 + 珍珠用时（S2-04）
//
// ⑪-a **服务端护甲槽编号是 100–103，不是 5–8**（`Inventory.java:343-348`：`putByte("Slot", (byte)(i+100))`）。
//      5–8 是 mineflayer 客户端的显示编号，两套不同。按 5–8 解析服务端 NBT ⇒ 永远数出 0 件金甲
//      ⇒ **在"确实穿了 4 件"的局里报"没穿金"**，而局照跑、指标照好看 —— 纯静默假阴性。
//      （S2-04 第一版就写成了 5–8，这条就是它的回归锁。）
// ⑪-b `readFailed` 必须**独立于**"读到但没金"：读不到 ≠ 没穿（手册 §5）。
// ⑪-c 珍珠用时统计：E 用**全部 trial**（未达标记预算值），P90 用最近秩法。
G('⑪ 装备槽服务端真值 + 珍珠用时统计');
const { parseArmorNbt, ARMOR_SLOT_IDS, pearlTimeStats } = await import('./truth.mjs');

// —— 构造服务端回执：4 件金甲**穿在装备槽**（100–103），另有一顶金头盔只在背包（Slot 5）——
const nbtFull = 'BarterBotC has the following entity data: Inventory: [{Slot: 0b, id: "minecraft:gold_ingot", Count: 128b},'
    + '{Slot: 5b, id: "minecraft:golden_helmet", Count: 1b},'
    + '{Slot: 100b, id: "minecraft:golden_boots", Count: 1b},'
    + '{Slot: 101b, id: "minecraft:golden_leggings", Count: 1b},'
    + '{Slot: 102b, id: "minecraft:golden_chestplate", Count: 1b},'
    + '{Slot: 103b, id: "minecraft:golden_helmet", Count: 1b}]}';
const aFull = parseArmorNbt(nbtFull);
ok(aFull.goldCount === 4 && aFull.full === true, '★ 4 件金甲在装备槽(100-103) ⇒ full_gold（阳性对照）', JSON.stringify(aFull.armor));
ok(aFull.verdict === 'full_gold', 'verdict=full_gold', aFull.verdict);

// 🚨 **反例（就是 S2-04 第一版的 bug）**：把 100–103 当成 5–8 来数会得 0，
//    于是"穿了全套"被读成"一件没穿"。显式验证两套编号没有交集。
const clientSlots = [5, 6, 7, 8];
const armorSlotIds = Object.keys(ARMOR_SLOT_IDS).map(Number).sort((x, y) => x - y);
ok(JSON.stringify(armorSlotIds) === JSON.stringify([100, 101, 102, 103]), '装备槽集合就是 100-103', JSON.stringify(armorSlotIds));
ok(!armorSlotIds.some((s) => clientSlots.includes(s)), '★ 与客户端 5-8 **没有交集**（两套编号不同，混用必错）');
ok(aFull.armor.every((w) => !clientSlots.includes(w.slot)), '解析出的 4 件都不在客户端 5-8 上');
ok(aFull.worn.length === 6 && aFull.armor.length === 4, '背包那顶金头盔（Slot 5）不算装备（只数 4 件）', JSON.stringify({ worn: aFull.worn.length, armor: aFull.armor.length }));

// —— 只穿 2 件（就是 S2-03 那一局的 kit 形态）⇒ partial_gold，**不是 no_gold** ——
const nbtTwo = 'BarterBotC has the following entity data: Inventory: [{Slot: 100b, id: "minecraft:golden_boots", Count: 1b},'
    + '{Slot: 103b, id: "minecraft:golden_helmet", Count: 1b}]}';
const aTwo = parseArmorNbt(nbtTwo);
ok(aTwo.goldCount === 2 && aTwo.verdict === 'partial_gold', '只穿 2 件 ⇒ partial_gold', JSON.stringify(aTwo.armor));
ok(aTwo.anyGold === true, '★ 2 件金甲 anyGold=true ⇒ 源码 isWearingGold 会返回 true（S2-03「2 件=活靶」不成立）');

// —— 皮革全套 ⇒ no_gold（1.16.1 只认金，不认皮革）——
const nbtLeather = 'BarterBotC has the following entity data: Inventory: [{Slot: 100b, id: "minecraft:leather_boots", Count: 1b},'
    + '{Slot: 101b, id: "minecraft:leather_leggings", Count: 1b},'
    + '{Slot: 102b, id: "minecraft:leather_chestplate", Count: 1b},'
    + '{Slot: 103b, id: "minecraft:leather_helmet", Count: 1b}]}';
const aLeather = parseArmorNbt(nbtLeather);
ok(aLeather.goldCount === 0 && aLeather.leatherCount === 4 && aLeather.verdict === 'no_gold', '皮革全套 ⇒ no_gold（1.16.1 只认金）');

// —— 🚨 **readFailed 必须独立**：回执读不到 ⇒ read_failed，**不能**报 no_gold ——
const aNull = parseArmorNbt(null);
ok(aNull.readFailed === true && aNull.verdict === 'read_failed', '回执 null ⇒ read_failed（≠ no_gold）', JSON.stringify(aNull));
const aNoInv = parseArmorNbt('BarterBotC has no data available.');
ok(aNoInv.readFailed === true, '回执里没有 Inventory 段 ⇒ 仍算 read_failed');
ok(aFull.readFailed === false, '读到完整回执 ⇒ readFailed=false（反证上面两条不是恒 true）');

// —— ⑪-c 珍珠用时统计 ——
const rows = [
    { run: 1, reached: true, sec: 150.2, secAsBudget: 150.2 },
    { run: 2, reached: true, sec: 171.4, secAsBudget: 171.4 },
    { run: 3, reached: true, sec: 165.0, secAsBudget: 165.0 },
];
const st = pearlTimeStats(rows, { goalSec: 180 });
ok(st.runs === 3 && st.reached === 3, '统计：3 局 3 达标', JSON.stringify(st));
ok(st.E === 162.2, '★ E = 三局均值 162.2s', String(st.E));
ok(st.P90_reached === 171.4, '★ P90（最近秩，n=3 时取最大）= 171.4s', String(st.P90_reached));
ok(st.gate === true, 'E ≤180s 且 n≥3 ⇒ gate 通过', String(st.gate));

// 🚨 **反例：一局没达标**。E 必须用预算值把它算进去（手册 §5：全部 trial 口径），
//    否则"跑满窗口"的失败局被悄悄丢掉、E 会被读得比真实更漂亮。
const rows2 = [...rows, { run: 4, reached: false, sec: null, secAsBudget: 600 }];
const st2 = pearlTimeStats(rows2, { goalSec: 180 });
ok(st2.reached === 3 && st2.runs === 4, '反例：3/4 达标', JSON.stringify({ runs: st2.runs, reached: st2.reached }));
ok(st2.E === +((150.2 + 171.4 + 165.0 + 600) / 4).toFixed(1), '★ E 用全部 trial（失败局记预算 600s）', String(st2.E));
ok(st2.E > st.E, '★ 加进失败局后 E 变大（证明失败局没被丢掉）', `${st2.E} > ${st.E}`);
ok(st2.gate === false, '有未达标局 ⇒ gate 不通过（即使 E 口径正确也不放过 n<3）');
ok(st2.P90_allTrials === 600, 'P90_allTrials 被最长的那一局支配（n=4 时 ceil(0.9*4)=4）', String(st2.P90_allTrials));

// —— 反例：`sec=null` 但背包到了目标 —— 不许算"达标用时" ——
const st3 = pearlTimeStats([{ run: 1, reached: true, sec: null, secAsBudget: 300 }], { goalSec: 180 });
ok(st3.reached === 0, '★ sec=null ⇒ 达标局数算 0（不把"没记到达标那一瞬"算达标）', String(st3.reached));
ok(st3.E_reachedOnly === null, 'sec=null ⇒ E_reachedOnly=null（不编达标用时）', JSON.stringify(st3));
ok(st3.E === 300, '但 E 仍按预算值 300s 计入全部 trial', String(st3.E));

// —— 反例：`id:` 后面**没有**空格的另一种回执形态也必须能解析 ——
// （S2-04 第一版写 `/id:"minecraft:…"/`，1.16.1 实发是 `id: "minecraft:…"` ⇒ 一件都读不出）
const nbtNoSpace = 'BarterBotC has the following entity data: Inventory: [{Slot:100b,id:"minecraft:golden_boots",Count:1b}]}';
const aNoSpace = parseArmorNbt(nbtNoSpace);
ok(aNoSpace.goldCount === 1 && aNoSpace.verdict === 'partial_gold', '无空格形态 `id:"…"` 也能解析（两种格式都收）', JSON.stringify(aNoSpace.armor));
const nbtSpaced = 'BarterBotC has the following entity data: Inventory: [{Slot:100b, id: "minecraft:golden_boots", Count:1b}]}';
const aSpaced = parseArmorNbt(nbtSpaced);
ok(aSpaced.goldCount === 1, '★ 有空格形态 `id: "…"` 也能解析（1.16.1 实发形态）', JSON.stringify(aSpaced.armor));
ok(aNoSpace.goldCount === aSpaced.goldCount, '两种形态结果一致（格式不该改变读数）');

// 🚨🚨 **实服抓到的真回执（不是构造的）** —— 1.16.1 对 `data get entity <玩家> Inventory`
//   回执里**没有 `Inventory:` 标签**，数组就是根值、且是 `}, {Slot:` 分隔（逗号+空格）。
//   写成 `/Inventory:\s*…/` ⇒ 永远不匹配 ⇒ 装备真值恒 read_failed，**局照跑、指标照好看**。
//   原文取自 `runs/S2_S4A/server.log`（S2-04 实跑，10:43:12）。
const REAL_LINE = 'BarterBotC has the following entity data: [{Slot: 0b, id: "minecraft:gold_ingot", Count: 64b}, {Slot: 1b, id: "minecraft:gold_ingot", Count: 64b}]';
const aReal = parseArmorNbt(REAL_LINE);
ok(aReal.readFailed === false, '★ 实服真回执（裸数组、无 Inventory: 标签）必须能读', JSON.stringify(aReal));
ok(aReal.worn.length === 2 && aReal.goldCount === 0, '实服那行只有背包 2 摞锭 ⇒ worn=2、gold=0', JSON.stringify(aReal.worn));
ok(aReal.verdict === 'no_gold', '实服那行（还没穿上）⇒ no_gold —— 读数**不是**恒 read_failed', aReal.verdict);

// 同样形态 + 四件金甲在装备槽 ⇒ full_gold（证明裸数组形态也能数出护甲）
const REAL_ARMORED = 'BarterBotC has the following entity data: [{Slot: 100b, id: "minecraft:golden_boots", Count: 1b}, {Slot: 101b, id: "minecraft:golden_leggings", Count: 1b}, {Slot: 102b, id: "minecraft:golden_chestplate", Count: 1b}, {Slot: 103b, id: "minecraft:golden_helmet", Count: 1b}]';
const aRealArm = parseArmorNbt(REAL_ARMORED);
ok(aRealArm.goldCount === 4 && aRealArm.verdict === 'full_gold', '★ 裸数组形态 + 装备槽 100-103 ⇒ full_gold（这是 easy 复测要的正向判据）', JSON.stringify(aRealArm.armor));
// 反证：同一条只把槽号改回 5-8（客户端那套）⇒ 读成 no_gold，正是 S2-04 第一版的错法
const REAL_WRONGSLOT = REAL_ARMORED.replace(/Slot: 100b/g, 'Slot: 5b').replace(/Slot: 101b/g, 'Slot: 6b')
    .replace(/Slot: 102b/g, 'Slot: 7b').replace(/Slot: 103b/g, 'Slot: 8b');
const aWrongSlot = parseArmorNbt(REAL_WRONGSLOT);
ok(aWrongSlot.goldCount === 0 && aWrongSlot.verdict === 'no_gold',
    '★ 反例：同内容换成客户端 5-8 槽号 ⇒ 读成 no_gold（证明槽号判据真的在起作用，不是恒 full）', aWrongSlot.verdict);

// 🚨 **读数通道不许崩**（S2-04 第二局教训）：`micro_barter3.mjs#checkArmor` 里把
//   `parseArmorNbt` 的字段名写成 `wornArmor`（真名是 `armor`）⇒ 只在 `readFailed=false`
//   时才走到那一行 ⇒ **离线全绿、实跑 1.7 分钟整局 TypeError 崩掉**。
//   ⇒ 这里断言"返回对象里 `armor` 存在且是数组"，让字段名漂移在离线就暴露。
ok(Array.isArray(aFull.armor), '★ parseArmorNbt 返回的字段名是 `armor`（不是 `wornArmor`）', Object.keys(aFull).join(','));
ok(!('wornArmor' in aFull), '反证：没有 `wornArmor` 这个键（写错它就是第二局那个 TypeError）');
ok(Array.isArray(aFull.worn) && Array.isArray(aNull.armor) && Array.isArray(aNull.worn),
    '★ 读不到时（read_failed）两个数组字段**仍然是数组** ⇒ 调用方 .map() 不会崩', JSON.stringify({ worn: aNull.worn, armor: aNull.armor }));
// 正向：把 checkArmor 的那行拼装逻辑原样跑一遍（4 件金甲 ⇒ 不抛）
const slotTxt = (aFull.armor ?? []).map((w) => `${w.slot}:${w.id}`).join(',') || '(空)';
ok(slotTxt.includes('103:golden_helmet'), 'checkArmor 的拼装逻辑在 full_gold 下可用', slotTxt);
const slotTxt2 = (aNull.armor ?? []).map((w) => `${w.slot}:${w.id}`).join(',') || '(空)';
ok(slotTxt2 === '(空)', '同一条逻辑在 read_failed 下也不崩（返回空串）', slotTxt2);

console.log(failed ? `\n✗ ${failed} 条失败` : '\n✓ 全部通过');
process.exit(failed ? 1 : 0);
