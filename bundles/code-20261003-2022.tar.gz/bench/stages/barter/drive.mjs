// drive.mjs — F 线队列驱动器：**独立进程**顺序跑本 stage 的脚本，一局一放泳道 C
//
// 为什么用独立进程而不是会话的后台任务（手册 §9.2 同一条纪律的另一种应用）：
//   会话的后台任务有 3600s 硬上限，到点被中止 ⇒ 跑到一半的泳道/线锁变成"陈旧但没人告警"。
//   本驱动器用 Start-Process 拉起，与会话解绑；日志写 runs/DRIVER.log，随时可读。
//
// 排队判据（三条全满足才开下一局）：
//   a. 泳道 C 端口 25568/25578 空闲；
//   b. `.line-locks/C.json` 不存在或已陈旧（**不接管活锁**）；
//   c. 空闲内存 ≥ --min-free-mb（默认 2560，手册 §4.7）。
// 每局之间让 45s，给 C 线「两局之间借道」的机会（派单 §0）。
//
// 用法：node drive.mjs --only probe_piglin_count,probe_b5_chest_gold [--gap 45] [--min-free-mb 2560]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn, execSync } from 'child_process';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(DIR, '../../..');
const LOCK_C = path.join(ROOT, 'experiments', 'mc1161-gate', '.line-locks', 'C.json');
const LOG = path.join(DIR, 'runs', 'DRIVER.log');
const STALE_MS = 45000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : d; };

const MIN_FREE = parseInt(arg('min-free-mb', '2560'), 10);
const GAP = (parseInt(arg('gap', '45'), 10)) * 1000;
const DEADLINE = Date.now() + (parseInt(arg('max-min', '240'), 10) * 60 * 1000);
const STAMPS = {
    probe_channel_variants: 'S2_CHAN',
    probe_piglin_count: 'S2_P1_PROBE',
    probe_b5_chest_gold: 'S2_B5',
    probe_b1_fiddle: 'S2_B1',
    micro_barter: 'S2_B2',
};
// 通道形态要先钉死（1.16.1 的回执文本和 @s 可用性与别的版本不同），所以排在最前
const ORDER = ['probe_channel_variants', 'probe_piglin_count', 'probe_b5_chest_gold', 'probe_b1_fiddle', 'micro_barter'];
const only = String(arg('only', ORDER.join(','))).split(',').map((s) => s.trim()).filter(Boolean);
const extra = process.argv.filter((a, i) => a.startsWith('--') && !['only', 'gap', 'min-free-mb', 'max-min'].includes(a.slice(2)));

fs.mkdirSync(path.dirname(LOG), { recursive: true });
function say(m) {
    const line = `[drive ${new Date().toISOString().slice(11, 19)}] ${m}`;
    console.log(line);
    fs.appendFileSync(LOG, line + '\n');
}

const portBusy = (p) => {
    try {
        return execSync(`netstat -ano | findstr ":${p} "`, { encoding: 'utf8' })
            .split(/\r?\n/).some((l) => l.includes('LISTENING'));
    } catch { return false; }
};
const freeMB = () => {
    try {
        return Math.round(execSync('powershell -NoProfile -Command "[math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1024)"', { encoding: 'utf8' }).trim() * 1);
    } catch { return 99999; }
};
/** C 锁是否被「活」的会话持有（陈旧的可以等它自己被清掉，但本驱动器不接管） */
function lockCState() {
    try {
        const j = JSON.parse(fs.readFileSync(LOCK_C, 'utf8'));
        const age = Date.now() - fs.statSync(LOCK_C).mtimeMs;
        return { exists: true, live: age <= STALE_MS, who: j.who, pid: j.pid, ageSec: Math.round(age / 1000) };
    } catch { return { exists: false, live: false }; }
}

async function waitReady(label) {
    let said = '';
    for (;;) {
        if (Date.now() > DEADLINE) { say(`✗ 超过总时限，放弃等待 ${label}`); return false; }
        const lock = lockCState();
        const ports = [25568, 25578].filter(portBusy);
        const mem = freeMB();
        const why = lock.live ? `line_lock C 活锁(${lock.who} pid=${lock.pid} 心跳${lock.ageSec}s前)`
            : ports.length ? `端口 ${ports.join('/')} 被占`
                : mem < MIN_FREE ? `内存 ${mem}MB < ${MIN_FREE}MB`
                    : '';
        if (!why) { if (said) say(`  ✓ ${label} 可以开跑（内存 ${mem}MB）`); return true; }
        if (why !== said) { said = why; say(`… 等 ${label}：${why}`); }
        await sleep(10000);
    }
}

function runScript(name, stamp) {
    return new Promise((resolve) => {
        const args = [path.join(DIR, `${name}.mjs`), '--stamp', stamp, ...extra];
        say(`▶ 启动 ${name}（--stamp ${stamp}${extra.length ? ' ' + extra.join(' ') : ''}）`);
        const out = fs.createWriteStream(path.join(DIR, 'runs', `${stamp}.log`), { flags: 'a' });
        const child = spawn(process.execPath, args, { cwd: DIR, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
        const tee = (buf) => {
            const s = buf.toString();
            fs.appendFileSync(LOG, s);
            out.write(s);
            for (const line of s.split(/\r?\n/)) {
                if (/^\[(drive|selfcheck|setup|easy|peaceful|calib|health calib|dist|B1|B4|验收|珍珠局|N=|locate|chest|coarse|kit|error)/.test(line.trim())) say(`  │ ${line.trim()}`);
            }
        };
        child.stdout.on('data', tee);
        child.stderr.on('data', tee);
        child.on('exit', (code) => { out.end(); say(`■ ${name} 退出 code=${code}`); resolve(code); });
    });
}

async function main() {
    say(`=== F 线队列启动：${only.join(' → ')}｜minFree=${MIN_FREE}MB gap=${GAP / 1000}s max=${arg('max-min', '240')}min extra=${JSON.stringify(extra)}`);
    const results = [];
    for (const name of only) {
        if (!ORDER.includes(name)) { say(`跳过未知脚本 ${name}`); continue; }
        const stamp = arg(`stamp-${name}`, STAMPS[name]);
        if (!(await waitReady(name))) { results.push({ name, skipped: 'deadline' }); break; }
        const t0 = Date.now();
        const code = await runScript(name, stamp);
        results.push({ name, stamp, code, min: +((Date.now() - t0) / 60000).toFixed(1) });
        const sumPath = path.join(DIR, 'runs', stamp, 'summary.json');
        say(`  数据：${fs.existsSync(sumPath) ? sumPath : '（无 summary）'}`);
        if (name !== only[only.length - 1]) { say(`  让道 ${GAP / 1000}s（C 线可借道）`); await sleep(GAP); }
    }
    say(`=== F 线队列结束：${JSON.stringify(results)}`);
}

main();
