// primitives_selftest.mjs — 任务层 `piglin.js` 的**离线**自检（假 bot，不开服、不占泳道）
//
// 为什么要有它：N 槽状态机是本单最贵的部分（一次真局 10+ 分钟），
// 而它的分支（借记失败 / 猪灵没接 / 掉出距离窗 / 背包满）全都能用假 bot 覆盖。
// B 线 r6 的教训：删私有函数时把 import 一起删了，模块能加载、自检全绿，
// 一直跑到真调用那行才炸 ReferenceError —— 所以自检要**真的调用**每个导出。
//
// 还带一条静态纪律检查：piglin.js **不得含任何坐标常量**（手册 §7：
// 精确坐标只能进 route 的 scout 区 / experiments / 报告，任务层只读站级数据）。
//
// 用法：node primitives_selftest.mjs

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(DIR, '../../..');
const WT = path.join(ROOT, 'mindcraft-wt', 's2-barter');
const SRC = path.join(WT, 'src', 'agent', 'tasks', 'exec', 'piglin.js');
// bench/ 目录下没有 node_modules ⇒ 依赖要从本线 worktree 的 main.js 解析（同 harness.mjs 的做法）
const require = createRequire(path.join(WT, 'main.js'));
const { Vec3 } = require('vec3');

let failed = 0;
const ok = (cond, msg, extra = '') => {
    if (cond) console.log(`  PASS ${msg}`);
    else { failed++; console.log(`  FAIL ${msg} ${extra}`); }
};

// ---------------------------------------------------------------- 假 bot
function mkItem(name, count) { return { name, count }; }
/**
 * 假猪灵：**按 1.16.1 实测布局**造（S2_CHAN 的 client_view.json#oneMeta）——
 *   [0,300,null,false,false,false,0,0,16,0,false,0,0,null,0,false,false,false,false]
 *    8=血量(16)、13=装备表(空时为 null，**不是空数组**)、**没有 age 字段**（1.16.1 猪灵非 Ageable）
 * metadata 必须是**数组**（真实 mineflayer 就是数组，越界索引要能读出 undefined）。
 */
function mkPiglin(id, pos, { hp = 16, holding = false } = {}) {
    const md = [0, 300, null, false, false, false, 0, 0, hp, 0, false, 0, 0, null, 0, false, false, false, false];
    if (holding) md[13] = [{ name: 'gold_ingot', count: 1 }, null];
    return { id, name: 'piglin', position: pos, width: 0.9, height: 1.9, metadata: md };
}
function mkBot({ pos = new Vec3(0, 40, 0), items = [], piglins = [], los = true, floorName = 'netherrack' } = {}) {
    const inv = items.map(([name, count]) => ({ name, count, ...{} }));
    const blocker = pos.offset(1.2, 0, 0);              // 假想挡在眼前的墙
    const bot = {
        entity: { id: 1, position: pos, eyeHeight: 1.62, yaw: 0, pitch: 0, onGround: true },
        heldItem: inv[0] ?? null,
        entities: Object.fromEntries(piglins.map((p) => [String(p.id), p])),
        health: 20,
        _inv: inv,
        inventory: { items: () => bot._inv.slice(), slots: [null, null, null, null, null, null, null, null, null] },
        world: { raycast: () => (los ? null : { position: blocker }) },
        blockAt: (p) => {
            // los=false ⇒ 假装 bot 正前方有一堵墙（hasLos 是逐格采样，所以按"前方 + 视线高度"判）
            if (!los && p.x > pos.x + 0.6 && p.y >= pos.y && p.y <= pos.y + 2.2) return { name: 'stone', boundingBox: 'block' };
            return { name: p.y < pos.y ? floorName : 'air', boundingBox: 'block' };
        },
        equip: async (it) => { bot.heldItem = it; return it; },
        activateEntity: async (e) => { bot.activated = (bot.activated ?? []).concat([e.id]); bot._ingotDebit(); },
        _ingotDebit: () => {
            const i = bot._inv.find((x) => x.name === 'gold_ingot');
            if (i) i.count -= 1;
        },
        pathfinder: { goto: () => Promise.resolve(), stop: () => {} },
        _client: { write: (name, pkt) => { bot.drops = bot.drops ?? []; if (name === 'block_dig' && pkt?.status === 4) { const g = bot._inv.find((x) => x.name === 'gold_ingot'); if (g) g.count -= 1; } } },
        tossStack: async (it) => { bot._inv.splice(bot._inv.indexOf(it), 1); },
    };
    return bot;
}

const pig = await import(`file:///${SRC.replace(/\\/g, '/')}`);
console.log('① 导出齐全（逐个真的调一次，r6 的教训：删 import 自检抓不到）');
for (const fn of ['throwIngot', 'collectDrops', 'reserveItemSpace', 'findTradeable', 'listPiglins', 'hasLos',
    'standOk', 'isHolding', 'piglinHealth', 'isBaby', 'snapshotMeta', 'diffMeta', 'countItem', 'countIngots',
    'ensureGoldArmor', 'countAggroPiglins', 'applyCalibration']) {
    ok(typeof pig[fn] === 'function', `导出 ${fn}() 是函数`, typeof pig[fn]);
}
ok(typeof pig.BarterEngine === 'function' && typeof pig.SlotState === 'object', '导出 BarterEngine / SlotState');
ok(pig.JUNK instanceof Set && pig.KEEP instanceof Set, '导出 KEEP / JUNK 白名单');
ok(pig.KEEP.has('ender_pearl') && pig.KEEP.has('gold_ingot'), 'KEEP 含珍珠与金锭（易物段命根子）');
ok(pig.JUNK.has('string') && pig.JUNK.has('quartz'), 'JUNK 含典型易物垃圾');

console.log('② 索引越界/未标定 ⇒ 状态读数返回 null（不是 false：别把"读不到"当"没拿"）');
{
    ok(pig.META_IDX.holdingIdx === 13 && pig.META_IDX.healthIdx === 8, '出厂偏移表 = 实测值（13 手持 / 8 血量）', JSON.stringify({ h: pig.META_IDX.holdingIdx, hp: pig.META_IDX.healthIdx }));
    ok(pig.META_IDX.babyIdx === null, '1.16.1 猪灵不是 Ageable ⇒ babyIdx=null（不过滤幼体）', String(pig.META_IDX.babyIdx));
    // 1.16.1 实测：装备表**空时该字段不发送** ⇒ 读回 null
    const empty = mkPiglin(1, new Vec3(2, 40, 0), { holding: false });
    empty.metadata[13] = null;                    // ← 关键：不是空数组，是 null
    ok(pig.isHolding(empty) === false, '装备表 null（=空）⇒ false', String(pig.isHolding(empty)));
    ok(pig.isHolding({ metadata: [] }) === null, '索引越界 ⇒ null（未知）', String(pig.isHolding({ metadata: [] })));
    ok(pig.isHolding(mkPiglin(1, new Vec3(2, 40, 0), { hp: 12 }), 999) === null, '错误索引 ⇒ null（不会误报"没拿"）');
    // 未标定（holdingIdx=null）时必须走"未知"而不是"没拿"
    const cal = pig.applyCalibration({ holdingIdx: null, healthIdx: null, babyIdx: null, evidence: 'selftest-uncalibrated' });
    ok(cal.holdingIdx === null && pig.isHolding(empty) === null, '未标定 ⇒ null', String(pig.isHolding(empty)));
    pig.applyCalibration({ holdingIdx: 13, healthIdx: 8, babyIdx: null, evidence: 'selftest' });
}

console.log('③ 标定后读数正确（13=手持 8=血量）');
{
    const hold = mkPiglin(1, new Vec3(2, 40, 0), { holding: true });
    const idle = mkPiglin(2, new Vec3(2.5, 40, 0), { holding: false });
    const hurt = mkPiglin(3, new Vec3(3, 40, 0), { hp: 12 });
    ok(pig.isHolding(hold) === true, '手持中 → true');
    ok(pig.isHolding(idle) === false, '空手（空数组）→ false', String(pig.isHolding(idle)));
    ok(pig.piglinHealth(hurt) === 12, '掉血读到 12');
    ok(pig.countAggroPiglins(mkBot({ piglins: [hurt, idle] })) === 1, '敌意猪灵计数只算掉血的');
}

console.log('④ 视线 / 站位判据');
{
    const e = mkPiglin(1, new Vec3(3, 40, 0));
    ok(pig.hasLos(mkBot({ los: true }), e) === true, '通视 → true');
    ok(pig.hasLos(mkBot({ los: false }), e) === false, '被挡 → false（投锭会静默失败）');
    ok(pig.standOk(mkBot({}), e.position.floored()) === true, '脚下实心头顶空 → 可站');
    ok(pig.standOk(mkBot({ floorName: 'lava' }), e.position.floored()) === false, '脚下岩浆 → 不可站');
}

console.log('⑤ findTradeable 的过滤链（1.16.1 猪灵无幼体，不过滤 baby）');
{
    const bot = mkBot({
        items: [['gold_ingot', 10]],
        piglins: [
            mkPiglin(1, new Vec3(2.0, 40, 0)),                              // 合格
            mkPiglin(2, new Vec3(2.2, 40, 0), { holding: true }),           // 正在把玩
            mkPiglin(3, new Vec3(2.4, 40, 0), { hp: 8 }),                  // 掉过血（疑似敌对）
            mkPiglin(5, new Vec3(8.0, 40, 0)),                              // 太远
            mkPiglin(6, new Vec3(1.0, 40, 0)),                              // 太近（贴脸投不出去）
        ],
    });
    const got = pig.findTradeable(bot, { radius: 24, minDist: 1.3, maxDist: 3.4, n: 10 }).map((e) => e.id);
    ok(JSON.stringify(got) === '[1]', '只留下 1 号（把玩/掉血/超距/过近全被滤掉）', JSON.stringify(got));
}

console.log('⑥ throwIngot：借记快筛 + 失败分类');
{
    const bot = mkBot({ items: [['gold_ingot', 3]], piglins: [mkPiglin(1, new Vec3(2.5, 40, 0))] });
    const e = bot.entities['1'];
    const r = await pig.throwIngot(bot, e, { minDist: 1.0, maxDist: 4.0 });
    ok(r.ok === true && r.phase === 'ok', '投出并借记成立', JSON.stringify(r));
    ok(pig.countIngots(bot) === 2, '背包真的少 1（借记判据不是空话）', String(pig.countIngots(bot)));
    ok(bot.activated?.includes(1) === true, '确实发了 use_entity');

    const bot2 = mkBot({ items: [], piglins: [mkPiglin(1, new Vec3(2.5, 40, 0))] });
    const r2 = await pig.throwIngot(bot2, bot2.entities['1'], {});
    ok(r2.ok === false && r2.phase === 'no_ingot', '没锭 → no_ingot', r2.phase);

    const bot3 = mkBot({ items: [['gold_ingot', 3]], piglins: [mkPiglin(1, new Vec3(9, 40, 0))] });
    const r3 = await pig.throwIngot(bot3, bot3.entities['1'], { maxDist: 3.4 });
    ok(r3.phase === 'too_far', '超距 → too_far（不发包）', r3.phase);

    const bot4 = mkBot({ items: [['gold_ingot', 3]], piglins: [mkPiglin(1, new Vec3(2.5, 40, 0))], los: false });
    const r4 = await pig.throwIngot(bot4, bot4.entities['1'], {});
    ok(r4.phase === 'no_los', '无视线 → no_los（不发包）', r4.phase);

    const bot5 = mkBot({ items: [['gold_ingot', 3]], piglins: [mkPiglin(1, new Vec3(2.5, 40, 0))] });
    bot5.activateEntity = async () => { /* 模拟服务端静默拒收：东西没出手 */ };
    const t0 = Date.now();
    const r5 = await pig.throwIngot(bot5, bot5.entities['1'], { debitTimeoutMs: 300 });
    ok(r5.phase === 'no_debit' && r5.tries === 3, '出手没生效 → 重试 3 次后判 no_debit', JSON.stringify({ phase: r5.phase, tries: r5.tries }));
    ok(r5.aims.length === 3, '每次重试都留瞄准证据（距离/yaw/pitch/目标速度）', JSON.stringify(r5.aims[0]));
}

console.log('⑦ 库存管家：先丢垃圾、绝不丢命根子');
{
    const bot = mkBot({
        items: [
            ['gold_ingot', 64], ['ender_pearl', 3], ['iron_pickaxe', 1], ['cooked_porkchop', 5],
            ['string', 12], ['quartz', 7], ['bone', 4], ['leather', 2], ['flint', 3], ['gunpowder', 1],
        ],
    });
    // 塞满到 30 格，逼出腾格
    for (let i = 0; i < 20; i++) bot._inv.push(mkItem(`filler_${i}`, 1));
    const before = bot._inv.length;
    const r = await pig.reserveItemSpace(bot, { freeSlotsNeeded: 8 });
    const names = bot._inv.map((i) => i.name);
    ok(before - bot._inv.length >= 8 - (36 - before), `腾出了需要的格数（${before}→${bot._inv.length}）`);
    ok(names.includes('ender_pearl') && names.includes('gold_ingot'), '珍珠/金锭没被丢');
    ok(names.includes('iron_pickaxe') && names.includes('cooked_porkchop'), '工具/食物没被丢');
    // 腾格只够丢 2 个，**必须是白名单里最靠前的垃圾**（顺序即优先级）
    const droppedNames = r.dropped.map((d) => d.name);
    ok(droppedNames.length >= 2 && droppedNames.every((n) => pig.JUNK.has(n)), `先丢 JUNK（${droppedNames.join(',')}）`, JSON.stringify(droppedNames));
    ok(!droppedNames.some((n) => pig.KEEP.has(n) || n.startsWith('filler_')), '没在腾格时误丢非白名单（保 KEEP 优先）');
    ok(r.dropped.length > 0, '丢弃有记账', JSON.stringify(r.dropped.slice(0, 3)));
}

console.log('⑧ BarterEngine：绑定 / 状态迁移 / 计量（周期按"掉落物出现"判，ROUND5 §F 实测口径）');
{
    const piglins = [1, 2, 3, 4].map((i) => mkPiglin(i, new Vec3(1.6 + i * 0.3, 40, 0)));
    const bot = mkBot({ items: [['gold_ingot', 40]], piglins });
    const ev = [];
    const eng = new pig.BarterEngine(bot, { slots: 4, minDist: 1.0, maxDist: 3.4, onEvent: (e) => ev.push(e) });
    const n = eng.bind();
    ok(n === 4, '4 个槽都绑到猪灵', String(n));
    ok(eng.slots.every((s) => s.state === 'IDLE'), '绑定后全是 IDLE', JSON.stringify(eng.slots.map((s) => s.state)));

    await eng.step();
    const after = eng.slots.map((s) => s.state);
    ok(after.every((s) => s === 'WAIT_DROP'), '一次 step 后 4 槽全部进入 WAIT_DROP（真并行了，不是循环等待）', JSON.stringify(after));
    ok(eng.stats.throws === 4 && eng.stats.throwsOk === 4, '4 次投锭全部借记成立', JSON.stringify(eng.stats));
    ok(pig.countIngots(bot) === 36, '4 次投锭后少了 4 锭（= 喂锭确实扣金锭，ROUND5 疑点二）', String(pig.countIngots(bot)));

    // 掉落物出现 ⇒ 周期记一次（模拟：给每个槽的猪灵脚下放一个掉落物实体）
    const mkDrop = (near, name = 'ender_pearl') => ({
        id: 900 + near.id, name: 'item', position: near.position.offset(0, 0.2, 0),
        metadata: [0, 0, 0, 0, 0, { name, count: 3 }, 0, 0, 0],
    });
    for (const p of piglins) bot.entities[String(mkDrop(p).id)] = mkDrop(p);
    await eng.step();
    ok(eng.slots.every((s) => s.state === 'IDLE'), '掉落物出现后回到 IDLE（可立即重投）', JSON.stringify(eng.slots.map((s) => s.state)));
    ok(eng.stats.cycles.length === 4, '4 个槽各记了一次周期', JSON.stringify(eng.stats.cycles));
    ok(JSON.stringify(eng.stats.drops) === '{"ender_pearl":4}', '掉落物按名字记账（B4 锭珠比要用）', JSON.stringify(eng.stats.drops));

    // 掉落物读名字：mineflayer 4.38 **没有 entity.item** ⇒ 必须从 metadata 槽位读
    ok(pig.itemOf(mkDrop(piglins[0])).name === 'ender_pearl', 'itemOf() 能从 metadata 读出掉落物名字');
    ok(pig.listDrops(bot, { radius: 8 }).length === 4, 'listDrops 读到 4 个掉落物', String(pig.listDrops(bot, { radius: 8 }).length));

    // 超时未成交 → 记 miss 并回 IDLE（不无限等）
    const eng2 = new pig.BarterEngine(bot, { slots: 1, minDist: 1.0, maxDist: 3.4, cycleTimeoutMs: 1 });
    eng2.bind();
    await eng2.step();
    eng2.stepSlot = eng2.stepSlot;             // 保持原型
    await eng2.step();
    ok(eng2.stats.misses >= 1 || eng2.stats.cycles.length >= 1, '无掉落物时按超时记 miss（不静默卡死）', JSON.stringify({ m: eng2.stats.misses, c: eng2.stats.cycles.length }));

    // 猪灵走出距离窗 ⇒ 槽转 DEAD
    for (const p of piglins) p.position = new Vec3(30, 40, 0);
    await eng.step();
    const rep = eng.report(60000, 'selftest');
    ok(rep.throwsPerMin === 4, '计量口径：4 次 / 1 分钟 = 4 次/分', JSON.stringify(rep.throwsPerMin));
    ok(rep.slotsRequested === 4, '报告带槽数', JSON.stringify(rep.slotsRequested));
    ok(ev.some((e) => (e.phase ?? e.type) === 'bind'), 'bind 事件有对外播报');
    ok(ev.some((e) => e.phase === 'cycle_done'), '周期完成有对外播报（带 cycleMs 与掉落物名）', JSON.stringify(ev.filter((e) => e.phase === 'cycle_done')[0]));
}

console.log('⑨ 静态纪律：任务层不得含坐标常量（手册 §7）');
{
    const src = fs.readFileSync(SRC, 'utf8');
    const lines = src.split(/\r?\n/);
    const bad = [];
    lines.forEach((l, i) => {
        if (/^\s*(\/\/|\*)/.test(l)) return;                       // 注释里讨论坐标不算
        // 三元坐标（如 288, 240, 47）/ Vec3 里的 3 位数 / 硬编码世界坐标赋值
        if (/(?:^|[^\d.-])-?\d{2,5}\s*,\s*-?\d{2,5}\s*,\s*-?\d{2,5}(?![\d.])/.test(l)) bad.push([i + 1, '坐标三元组', l.trim()]);
        if (/new Vec3\(\s*-?\d{2,}/.test(l)) bad.push([i + 1, 'Vec3 硬编码', l.trim()]);
        if (/(seed|Seed)\s*[:=]\s*-?\d{5,}/.test(l)) bad.push([i + 1, '硬编码种子', l.trim()]);
    });
    ok(bad.length === 0, 'piglin.js 无坐标常量/硬编码种子', JSON.stringify(bad.slice(0, 5)));
}

console.log('⑩ ground 模式：地面投锭（丢出去让它自己捡）+ 捡拾安全圈/墙钟上限');
{
    const bot = mkBot({ items: [['gold_ingot', 8]], piglins: [mkPiglin(1, new Vec3(2.0, 40, 0))] });
    const g = await pig.groundThrow(bot, { count: 3 });
    ok(g.ok && g.count === 3, '地面投锭：一次丢 3 块都出手', JSON.stringify(g));
    ok(pig.countIngots(bot) === 5, '地面投锭也扣背包（和喂锭一样是真消耗）', String(pig.countIngots(bot)));
    const g2 = await pig.groundThrow(bot, { count: 9 });   // 剩 5 块，要 9 ⇒ 必须拒发
    ok(g2.ok === false && g2.phase === 'not_enough', '不够时拒发（不发空气投掷）', JSON.stringify(g2));

    // 捡拾安全圈：圈外的掉落物不追
    const b2 = mkBot({ items: [['ender_pearl', 1]], piglins: [] });
    const mkDrop = (id, x, z) => ({ id, name: 'item', position: new Vec3(x, 40, z), metadata: [0, 0, 0, 0, 0, { name: 'ender_pearl', count: 1 }, 0, 0, 0] });
    b2.entities['11'] = mkDrop(11, 2.0, 0);      // 圈内
    b2.entities['22'] = mkDrop(22, 6.0, 0);       // 圈外（在扫描半径内、但在安全圈外）
    const r = await pig.collectDrops(b2, {
        home: new Vec3(0, 40, 0), safeRadius: 4.5, leashRadius: 7, timeoutMs: 1500, perItemMs: 200,
    });
    ok(r.skippedOutside === 1, '安全圈外的掉落物被跳过（不许把 bot 带出站位）', JSON.stringify({ skipped: r.skippedOutside, picked: r.picked.length }));
    ok(r.picked.length === 1, '圈内的正常捡', JSON.stringify(r.picked));

    // 引擎的收尾墙钟上限必须真的传下去
    const eng = new pig.BarterEngine(b2, { slots: 0, harvestMaxMs: 20000, safeRadius: 4.5, leashRadius: 7 });
    eng.home = new Vec3(0, 40, 0);
    const h = await eng.harvest();
    ok(typeof h.ms === 'number' && h.ms <= 25000, 'harvest 有墙钟上限（本轮 ≤ 25s）', `${h.ms}ms`);
    // ★ S2-03：模式名规范化。旧名 `feed` 必须归一成 `wait`（等猪灵过来），
    //   否则上一轮传进来的 `throwMode:'feed'` 会静默走成第三种打法。
    ok(eng.mode === 'wait' && eng.opts.mode === 'wait', '默认模式是 wait（等猪灵过来）', `mode=${eng.mode}`);
    ok(pig.normalizeMode('feed') === 'wait' && pig.normalizeMode('GROUND') === 'ground' && pig.normalizeMode('walk') === 'approach',
        '旧名/大小写归一（feed→wait, toss→ground, walk→approach）', JSON.stringify([pig.normalizeMode('feed'), pig.normalizeMode('GROUND'), pig.normalizeMode('walk')]));
    ok(pig.THROW_MODES.length === 3 && pig.THROW_MODES.join(',') === 'wait,ground,approach', '三种打法名字固定', pig.THROW_MODES.join(','));
    const eng2 = new pig.BarterEngine(b2, { slots: 0, mode: 'ground', groundCount: 3, groundRadius: 9 });
    ok(eng2.mode === 'ground' && eng2.opts.groundCount === 3 && eng2.opts.groundRadius === 9, 'ground 模式参数可配');
    const eng2b = new pig.BarterEngine(b2, { slots: 0, throwMode: 'feed' });
    ok(eng2b.mode === 'wait', '旧调用方传 throwMode=feed 仍走 wait（向后兼容）', eng2b.mode);
}

console.log(failed ? `\n✗ ${failed} 条失败` : '\n✓ 全部通过');
process.exit(failed ? 1 : 0);
