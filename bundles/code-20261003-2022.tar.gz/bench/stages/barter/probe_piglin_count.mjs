// probe_piglin_count.mjs — MC-S2-01 阶段 1：① 通道自检 ② easy/peaceful 猪灵计数 ③ metadata 标定
//
// 派单要求的前置问题：「1.16.1 在 peaceful 下堡垒里有没有猪灵」（主种子堡垒站，easy/peaceful 各一局）。
// 顺带（本脚本的真正价值）：**先证伪测量通道再采数**（手册 §5），并把 1.16.1 猪灵的 metadata 偏移
// 用「服务端 NBT ↔ 客户端 metadata」对账标定出来——这张表是 B2 状态机的地基，读错索引 = 状态机在读空气。
//
// 计数口径（两条互相独立的通道，数字必须一致，不一致就当不可信）：
//   A. `execute in <dim> at <bot> as @e[type=piglin] run time query day` → **逐实体一行**，数行数
//   B. `kill @e[type=piglin]` 的回执文本自带数字（"Killed 52 piglins"）——**破坏性，只能放最后**
//   C. 客户端 entityScan（不是真值，但对账用：服务端数 vs 客户端可见数应当同量级）
//
// 泳道只有 C；一局一放。用法：node probe_piglin_count.mjs [--stamp S2_P1_PROBE] [--calib 1] [--summon 1]

import {
    openRun, bootWorld, stopWorld, closeRun, cmd, truth, bot, botPos, posStr, dim,
    tpNether, kit, invCount, record, writeSummary, sleep, parkSafe, standNatural,
    LANE, STATION, SEED, argv, moduleUrl,
} from './harness.mjs';
import { parsePos, parseAge } from './truth.mjs';

const STAMP = argv('stamp', 'S2_P1_PROBE');
const DO_CALIB = argv('calib', '1') !== '0';
const ALLOW_SUMMON = argv('summon', '1') !== '0';
const S = STATION.bastion;

let pig = null;
async function loadPrimitives() { pig = await import(moduleUrl('src/agent/tasks/exec/piglin.js')); }

/**
 * 服务端真值猪灵计数。
 * ⚠ **不用"数回执行数"那条路**：`execute … as <sel> run time query day` 在 1.16.1
 *   **解析时好时坏**（同一条命令：15:50:54 回 71 行、17:00:14 回 "Incorrect argument"，
 *   两次的客户端/服务端环境完全一样）⇒ 不可作为权威口径。
 *   改用 **`kill @e[type=piglin]` 的回执自带数字**（`Killed 9 entities` / `Killed 12 piglins`）——
 *   一条命令、一个数字、零解析歧义。**破坏性**（会把猪灵都杀掉），所以每个阶段**最后**才做。
 * @returns {{n:number|null, raw:string, clientBefore:number}}
 */
async function countServerPiglinsByKill(clientBefore) {
    truth().pump();
    const before = truth().queue.length;
    cmd('execute in minecraft:the_nether run kill @e[type=piglin]');
    for (let i = 0; i < 20; i++) {
        await sleep(600);
        truth().pump();
        const lines = truth().queue.splice(before);
        const m = /Killed (\d+) (?:entities|piglins)/i.exec(lines.join(' | '));
        if (m) return { n: parseInt(m[1], 10), raw: m[0], clientBefore };
    }
    return { n: null, raw: '(no kill receipt)', clientBefore };
}
/** 存在性（≥1）判定：`data get entity <选择器>` 不带路径在 1.16.1 可用（回 "No entity was found"） */
async function existsPiglin() {
    const l = await truth().dataEntity('the_nether', LANE.username, '@e[type=piglin,limit=1]', '', { timeoutMs: 8000, soft: true });
    return l ? 'found' : (truth().peek(/No entity was found/) ? 'none' : 'unknown');
}
function clientPiglins(radius = 80) {
    return pig.listPiglins(bot(), { radius, max: 400 }).map(({ e, d }) => ({
        d: +d.toFixed(2), pos: [+e.position.x.toFixed(1), +e.position.y.toFixed(1), +e.position.z.toFixed(1)],
        metaIdx: Object.keys(e.metadata ?? {}).map(Number).sort((a, b) => a - b),
    }));
}

/** 找一头能投的猪灵：有视线、在距离窗内、脚下站得住。找不到可选造 fixture */
async function pickTarget({ minDist = 1.6, maxDist = 3.2, timeoutMs = 20000 } = {}) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
        const c = pig.findTradeable(bot(), { radius: 24, minDist, maxDist, n: 1 });
        if (c.length) return { e: c[0], fixture: false };
        await sleep(600);
    }
    return { e: null, fixture: false };
}
async function summonFixture(d) {
    const me = botPos();
    const x = me.x + d, z = me.z;
    const before = new Set(Object.values(bot().entities ?? {}).map((e) => e.id));
    cmd(`execute in minecraft:the_nether run summon minecraft:piglin ${x.toFixed(2)} ${me.y.toFixed(2)} ${z.toFixed(2)}`);
    for (let i = 0; i < 50; i++) {
        await sleep(100);
        const fresh = Object.values(bot().entities ?? {}).find((e) => e.name === 'piglin' && !before.has(e.id));
        if (fresh) return { e: fresh, fixture: true, at: [+x.toFixed(1), +me.y.toFixed(1), +z.toFixed(1)] };
    }
    return { e: null, fixture: true, at: null };
}

/**
 * 标定 healthIdx：让 **bot 自己**摔一跤（血 20 → 19）。
 * 不用打猪灵（打一下就敌对，原型局会被围）；LivingEntity 的 metadata 布局各实体一致。
 * 上一版直接 tp 高 6 格 → bot 落进堡垒墙体里窒息（日志 "suffocated in a wall"），
 * 这版先 `fill` 挖出空气柱再 tp。
 */
async function calibHealth() {
    const t = truth();
    const p = botPos().floored();
    const before = { hp: bot().health, meta: { ...(bot().entity.metadata ?? {}) } };
    t.raw(`execute in minecraft:the_nether run fill ${p.x} ${p.y + 1} ${p.z} ${p.x} ${p.y + 6} ${p.z} minecraft:air`);
    await sleep(1200);
    cmd(`execute in minecraft:the_nether run tp ${LANE.username} ${p.x + 0.5} ${p.y + 4} ${p.z + 0.5}`);
    await sleep(3500);
    const srv = await t.dataEntity('the_nether', LANE.username, LANE.username, 'Health', { timeoutMs: 8000, soft: true });
    const d = pig.diffMeta(before.meta, { ...(bot().entity.metadata ?? {}) });
    const cands = Object.entries(d)
        .filter(([, v]) => typeof v.before === 'number' && typeof v.after === 'number')
        .map(([k, v]) => ({ idx: Number(k), before: v.before, after: v.after }));
    return {
        hpBefore: before.hp, hpAfter: bot().health,
        serverHealth: srv ? (/([\d.]+)f/.exec(srv)?.[1] ?? srv.slice(-60)) : null,
        numericDiffs: cands, allDiffs: Object.keys(d),
    };
}

/**
 * 投一次锭，测三个时刻（每个都有服务端对账）：
 *   t_throw（出手）→ t_hold（猪灵捡起：metadata 出现手持物）→ t_drop（掉落物出现）
 */
async function calibThrow(e, { fixture = false, waitMs = 16000, handPollMs = 700 } = {}) {
    const t = truth();
    const me = botPos();
    const dist0 = e.position.distanceTo(me);
    const g0 = t.clock.now();

    // 服务端低频对账：最近那头猪灵手里有没有东西
    const handLog = [];
    let handStop = false;
    const handTask = (async () => {
        while (!handStop) {
            const l = await t.dataEntity('the_nether', LANE.username, '@e[type=piglin,limit=1]', 'HandItems[0].id', { timeoutMs: 6000, soft: true });
            handLog.push({ at: Date.now(), hand: l ? (/minecraft:([a-z_]+)/.exec(l)?.[1] ?? '?') : 'none' });
            await sleep(handPollMs);
        }
    })();

    const beforeMeta = pig.snapshotMeta(e);
    const beforeDrops = new Set(pig.listDrops(bot(), { radius: 14 }).map((d) => d.e.id));
    const ingots0 = pig.countIngots(bot());
    const r = await pig.throwIngot(bot(), e, { minDist: 1.0, maxDist: 4.2, debitTimeoutMs: 2500 });
    const tThrow = Date.now();
    if (!r.ok) { handStop = true; await handTask; return { ok: false, phase: r.phase, dist0: +dist0.toFixed(2), fixture }; }

    let holdingIdx = null, tHold = null, tClear = null, tDrop = null, dropInfo = null;
    const t1 = Date.now();
    while (Date.now() - t1 < waitMs) {
        const d = pig.diffMeta(beforeMeta, pig.snapshotMeta(e));
        for (const [k, v] of Object.entries(d)) {
            const has = (x) => Array.isArray(x) && x.some((s) => s && s.name && s.name !== 'air' && s.count > 0);
            if (!has(v.before) && has(v.after) && holdingIdx == null) { holdingIdx = Number(k); tHold = Date.now(); }
            if (tHold != null && has(v.before) && !has(v.after) && tClear == null) tClear = Date.now();
        }
        for (const dd of pig.listDrops(bot(), { radius: 14 })) {
            if (beforeDrops.has(dd.e.id)) continue;
            if (tDrop == null) { tDrop = Date.now(); dropInfo = { name: dd.name, count: dd.count, pos: [+dd.e.position.x.toFixed(2), +dd.e.position.y.toFixed(2), +dd.e.position.z.toFixed(2)] }; }
        }
        if (tDrop != null && (tClear != null || Date.now() - tDrop > 1500)) break;
        await sleep(40);
    }
    handStop = true;
    await handTask;

    // 掉落物服务端真值：Pos + Age（Age = 距生成的 tick 数）⇒ 生成时刻可反推
    let itemTruth = null;
    try {
        const g = await t.gametime('the_nether');
        const rp = await t.countEntities('the_nether', LANE.username, '@e[type=item]', { quietMs: 500, timeoutMs: 12000 });
        const rows = rp.lines.map(parsePos).filter(Boolean);
        const ra = await t.dataEntity('the_nether', LANE.username, '@e[type=item,limit=1]', 'Age', { timeoutMs: 8000, soft: true });
        itemTruth = { itemCount: rp.n, nearest: rows[0] ?? null, age: ra ? (/Age:\s*(-?\d+)/.exec(ra)?.[1] ?? ra.slice(-40)) : null, gametimeAtRead: g };
    } catch (e) { itemTruth = { error: String(e).slice(0, 140) }; }

    const s = (x) => (x == null ? null : +((x - tThrow) / 1000).toFixed(2));
    return {
        ok: true, fixture, dist0: +dist0.toFixed(2), aimMs: r.aimMs,
        ingotsBefore: ingots0, ingotsAfter: pig.countIngots(bot()),
        holdingIdx,
        pickupDelaySec: s(tHold),
        fiddleSec: (tHold != null && tClear != null) ? +((tClear - tHold) / 1000).toFixed(2) : null,
        cycleSec: s(tDrop),
        drop: dropInfo, itemTruth, tps: t.clock.tps(),
        handSeries: handLog.map((h) => ({ t: s(h.at), hand: h.hand })),
        handSawIngot: handLog.some((h) => h.hand === 'gold_ingot'),
    };
}

async function phaseEasy() {
    await bootWorld({ difficulty: 'easy' });
    const t = truth();
    // ① 安全落位（空平台；不塞墙里）
    const park = await parkSafe({ cx: S.x, cz: S.z, yLo: S.yLo, yHi: 100, r: 4 });
    await sleep(4000);                    // 等区块自然加载（1.16.1 无 /forceload 依赖）
    record('p0_park', park);

    // ② 通道自检
    const sc = await t.selfCheck({ dim: 'the_nether', at: park.park, atEntity: LANE.username });
    record('p0_channel_selfcheck', { selfCheck: sc, park, difficulty: 'easy' });
    console.log('[selfcheck]', JSON.stringify(sc, null, 2));

    // ③ 猪灵存在性（服务端、非破坏）+ 客户端视图（**权威计数放阶段最后**，kill 是破坏性的）
    const exists = await existsPiglin();
    const cli = clientPiglins(80);
    record('p1_piglin_count_easy', {
        difficulty: 'easy', dim: dim(), botPos: posStr(botPos()), park,
        exists, clientCount: cli.length, client: cli.slice(0, 20),
        tps: t.clock.tps(),
    });
    console.log(`[easy] 服务端存在性=${exists}／客户端可见 ${cli.length} 头／TPS=${t.clock.tps()}`);

    // ④ 落到自然地面（易物必须在地面做：猪灵不会爬到空中平台）
    const stand = await standNatural({ cx: S.x, cz: S.z, r: 20, yLo: S.yLo, yHi: S.yHi + 8 });
    record('p1b_stand', { stand, note: stand ? '自然地面' : '没找到自然地面 ⇒ 下面用平台 + fixture' });
    console.log('[stand]', JSON.stringify(stand));

    // ⑤ 标定：healthIdx（bot 自己摔一跤）
    let health = null;
    if (DO_CALIB) {
        health = await calibHealth();
        record('p2a_health_calib', health);
        console.log('[health calib]', JSON.stringify(health));
    }

    // ⑥ 标定：holdingIdx（投一次锭，逐索引 diff + 服务端 HandItems 对账）
    let calib = null;
    if (DO_CALIB) {
        const inv = await kit(['gold_ingot:64', 'golden_helmet:1', 'golden_boots:1', 'iron_sword:1', 'cooked_porkchop:8']);
        await sleep(1500);
        const armor = await pig.ensureGoldArmor(bot());
        let pick = await pickTarget();
        let at = null;
        if (!pick.e && ALLOW_SUMMON) { pick = await summonFixture(2.5); at = pick.at; console.log(`[calib] 无自然猪灵 ⇒ fixture @ ${JSON.stringify(at)}`); }
        if (pick.e) {
            calib = await calibThrow(pick.e, { fixture: pick.fixture });
            calib.kit = inv; calib.armor = armor; calib.targetAt = [+pick.e.position.x.toFixed(1), +pick.e.position.y.toFixed(1), +pick.e.position.z.toFixed(1)];
        } else calib = { ok: false, why: 'no_target' };
        record('p2b_throw_calib', calib ?? { skipped: true });
        console.log('[calib]', JSON.stringify(calib, null, 2));
    }

    // ⑦ 权威计数：kill 回执的数字（破坏性，所以放最后）
    const cntB = await countServerPiglinsByKill(cli.length);
    record('p3_piglin_count_authoritative', {
        serverCount: cntB, clientCount: cli.length,
        ratioClientOverServer: cntB.n ? +(cli.length / cntB.n).toFixed(2) : null,
        note: '权威口径 = kill 回执的数字；客户端实体表保留已离开追踪范围的实体（比值明显 >1）',
    });
    console.log(`[计数] 服务端=${cntB.n} 头（${cntB.raw}）／客户端表=${cli.length} 头`);

    return { park, stand, exists, cntB, cli: cli.length, health, calib };
}

async function phasePeaceful() {
    await stopWorld();
    await bootWorld({ difficulty: 'peaceful' });
    const park = await parkSafe({ cx: S.x, cz: S.z, yLo: S.yLo, yHi: 100, r: 4 });
    await sleep(6000);
    const exists = await existsPiglin();
    const cli = clientPiglins(80);
    const cnt = await countServerPiglinsByKill(cli.length);
    record('p4_piglin_count_peaceful', {
        difficulty: 'peaceful', park, exists, serverCount: cnt, clientCount: cli.length,
        clientVsServer: cnt.n ? { client: cli.length, server: cnt.n } : null,
        conclusion: cnt.n === 0
            ? 'peaceful 下主种子堡垒站无猪灵（生成被难度抑制）'
            : `peaceful 下仍有 ${cnt.n} 头（与 easy 同量级 ⇒ 猪灵生成不受 peaceful 抑制）`,
    });
    console.log(`[peaceful] 服务端 ${cnt.n} 头（${cnt.raw}）／客户端 ${cli.length} 头`);
    return { serverCount: cnt, clientCount: cli.length, exists };
}

async function main() {
    await openRun(STAMP);
    try {
        await loadPrimitives();
        const easy = await phaseEasy();
        const peaceful = await phasePeaceful();
        writeSummary({ easy, peaceful });
    } catch (e) {
        console.error('[probe] 失败：', e);
        try { record('error', { message: String(e?.message ?? e), stack: String(e?.stack ?? '').slice(0, 900) }); } catch { /* 忽略 */ }
        try { writeSummary({ failed: String(e?.message ?? e) }); } catch { /* 忽略 */ }
        process.exitCode = 1;
    } finally {
        await closeRun();
    }
}

main();
