// truth_selftest.mjs — 真值通道的**离线**自检（不开服、不占泳道，几百毫秒跑完）
//
// 为什么值得单立一个自检：这条通道一坏，产出的是"看起来正常但坐标/计数是错的"数据，
// 而不是报错——C 线 MC-FRAME-BATCH-01 的三个 bug 全是这一族。改 truth.mjs 之后先跑它。
//
// 覆盖：① 三类回执（fill / data / gametime）**交错到达**仍各自 FIFO 配对成功；
//      ② 队列里不匹配的行不会被别的类吞掉（v1 的真 bug）；
//      ③ 缺回执 ⇒ 判死通道（不产出错数据）；
//      ④ 多字节（中文）日志行不会让偏移漂移。
//
// 用法：node truth_selftest.mjs

import fs from 'fs';
import os from 'os';
import path from 'path';
import { Truth, parseActiveEffects, FIRE_RESIST_ID } from './truth.mjs';

const TMP = path.join(os.tmpdir(), `barter_truth_selftest_${Date.now()}.log`);
let failed = 0;
const ok = (cond, msg, extra = '') => {
    if (cond) console.log(`  PASS ${msg}`);
    else { failed++; console.log(`  FAIL ${msg} ${extra}`); }
};

/** 假 server：把命令按类型异步回一条回执（故意交错），并统计 time query 的最大并发在途数 */
function fakeServer(recipe, stat = { inflightTimeq: 0, maxTimeq: 0 }) {
    const child = { exitCode: null, sent: [], stdin: null, stat };
    child.stdin = {
        write: (s) => {
            const cmd = String(s).trim();
            child.sent.push(cmd);
            const line = recipe(cmd);
            if (line != null) {
                const isTimeq = /time query/.test(cmd);
                if (isTimeq) { stat.inflightTimeq++; stat.maxTimeq = Math.max(stat.maxTimeq, stat.inflightTimeq); }
                setTimeout(() => {
                    if (isTimeq) stat.inflightTimeq--;
                    fs.appendFileSync(TMP, line);
                }, 3);
            }
            return true;
        },
    };
    return child;
}

const RECIPE = (cmd) => {
    if (/time query gametime/.test(cmd)) return '[12:00:00]: [Server thread/INFO]: The time is 1000\n';
    if (/data get entity/.test(cmd)) return '[12:00:01]: [Server thread/INFO]: abc-123 has the following entity data: Pos: [1.5d, 40.0d, -3.0d]\n';
    // ⚠ fill 有**两种**回执；只等一种的写法会让"未命中"等满超时并把通道判死（S2_CHAN 实测）
    if (/replace minecraft:air$/.test(cmd)) return '[12:00:02]: [Server thread/INFO]: No blocks were filled\n';
    if (/fill /.test(cmd)) return '[12:00:02]: [Server thread/INFO]: Successfully filled 7 blocks\n';
    return null;
};

async function test1_interleaved() {
    console.log('① 三类回执交错到达，各自 FIFO 配对（时钟与 fill/data 互不干扰）');
    fs.writeFileSync(TMP, '');
    const child = fakeServer(RECIPE);
    const t = new Truth({ child, logPath: TMP });
    // 三条**同时**在途（时钟轮询 + data 查询 + fill）
    const pTime = t.gametime('the_nether');
    const pData = t.dataEntity('the_nether', 'TaskBotC', '@e[type=piglin,limit=1]', 'Pos');
    const pFill = t.fillCount('the_nether', { x1: 0, y1: 40, z1: 0, x2: 0, y2: 40, z2: 0 }, 'minecraft:air');
    const [g, d, f] = await Promise.all([pTime, pData, pFill]);
    ok(g === 1000, 'gametime 读到 1000', `got=${g}`);
    ok(/Pos: \[1\.5d, 40\.0d, -3\.0d\]/.test(d ?? ''), 'data get 配到自己的行', `got=${d}`);
    ok(f === 0, 'fill 的「No blocks were filled」也必须算回执（返回 0，不等超时）', `got=${f}`);
    ok(!t.poisoned, '通道未被误判中毒', JSON.stringify(t.stats()));
    const st = t.stats();
    ok(st.chans.timeq.sent === 1 && st.chans.timeq.got === 1, 'timeq 类 sent==got', JSON.stringify(st.chans.timeq));
    ok(st.chans.fill.sent === 1 && st.chans.fill.got === 1, 'fill 类 sent==got', JSON.stringify(st.chans.fill));
    ok(st.queue === 0, '队列已清空（无不匹配残留）', `queue=${st.queue}`);
}

async function test6_timeq_mutex() {
    console.log('⑥ timeq 互斥：时钟与「逐实体计数」回执文本相同，绝不能同时在途（否则互抢）');
    fs.writeFileSync(TMP, '');
    const stat = { inflightTimeq: 0, maxTimeq: 0 };
    const child = fakeServer((cmd) => (/time query/.test(cmd)
        ? `[12:00:00]: [Server thread/INFO]: The time is ${1000 + child.sent.length}\n` : null), stat);
    const t = new Truth({ child, logPath: TMP });
    const [g, c3, c0] = await Promise.all([
        t.gametime('the_nether'),
        t.countEntities('the_nether', 'TaskBotC', '@e[type=piglin,limit=3]'),
        t.countEntities('the_nether', 'TaskBotC', '@e[type=piglin,limit=0]'),
    ]);
    ok(g != null, '时钟仍能读数', String(g));
    ok(stat.maxTimeq === 1, `time query 最大并发在途 = 1（实测 ${stat.maxTimeq}）`, JSON.stringify(stat));
    const st = t.stats();
    ok(st.chans.timeq.sent === st.chans.timeq.got, 'timeq 类 sent==got（没有互抢）', JSON.stringify(st.chans.timeq));
    ok(st.chans.timeq.late === 0, '没有"迟到的回执被当成本条答案"', JSON.stringify(st.chans.timeq));
    ok(!t.poisoned, '未中毒', JSON.stringify(t.poisoned));
    ok(c3.trusted && c0.trusted, '两条计数都收尾可信', JSON.stringify({ c3: c3.trusted, c0: c0.trusted }));
}

async function test2_no_reply_kills() {
    console.log('② 缺回执 ⇒ 判死通道（拒绝产出错数据）；但时钟默认走软失败（单次超时不拖垮整轮）');
    fs.writeFileSync(TMP, '');
    const child = fakeServer(() => null);          // 一条回执都不给
    const t = new Truth({ child, logPath: TMP });
    // 默认（soft）：只丢这一次读数，通道不死 —— 时钟轮询必须这样，否则一次服务端卡顿就废掉整轮
    const soft = await t.gametime('the_nether');
    ok(soft === null && !t.poisoned, '默认软失败：读数为 null、通道不判死', JSON.stringify({ soft, poisoned: t.poisoned }));
    // 显式要严格：缺回执就判死（测量数据宁可失败也不产出错值）
    const t2 = new Truth({ child, logPath: TMP });
    let err = null;
    try { await t2.gametime('the_nether', { soft: false }); } catch (e) { err = e; }
    ok(/TRUTH_POISONED/.test(String(err)), 'soft=false 时缺回执抛 TRUTH_POISONED', String(err));
    const t3 = new Truth({ child, logPath: TMP });
    t3.poisoned = 'x';
    let err2 = null;
    try { await t3.fillCount('the_nether', { x1: 0, y1: 0, z1: 0, x2: 0, y2: 0, z2: 0 }, 'air'); } catch (e) { err2 = e; }
    ok(/TRUTH_POISONED/.test(String(err2)), '已中毒的通道不再发命令', String(err2));
}

async function test3_utf8_offset() {
    console.log('③ 中文日志行不导致偏移漂移');
    fs.writeFileSync(TMP, '');
    const child = fakeServer((cmd) => {
        if (/fill /.test(cmd)) return '[12:00:00]: [Server thread/INFO]: 猪灵宝拉泰 属性 名字 猪灵宝拉泰0\n[12:00:00]: [Server thread/INFO]: Successfully filled 1 blocks\n';
        return null;
    });
    const t = new Truth({ child, logPath: TMP });
    // 分多次 drain（模拟"一行还没写完就被读"）
    const n = await t.fillCount('the_nether', { x1: 0, y1: 40, z1: 0, x2: 0, y2: 40, z2: 0 }, 'minecraft:air');
    ok(n === 1, '中文行后仍取到 fill 回执', `got=${n}`);
    const again = await t.fillCount('the_nether', { x1: 0, y1: 40, z1: 0, x2: 0, y2: 40, z2: 0 }, 'minecraft:air');
    ok(again === 1, '第二次读数仍是 1（偏移没漂）', `got=${again}`);
    // 不匹配的 join 行留在队列里是**预期**的（队列要留着给别的类）；只要没超上限丢行即可
    const st = t.stats();
    ok(st.chans.fill.sent === 2 && st.chans.fill.got === 2, 'fill 类 sent==got', JSON.stringify(st.chans.fill));
    ok(st.queue <= 8 && st.dropped === 0, '噪声行留在队列但没触发上限丢行', JSON.stringify(st));
}

async function test5_queue_cap() {
    console.log('⑤ 噪声行堆积时队列封顶（防无关行碰巧命中正则造成错配）');
    fs.writeFileSync(TMP, '');
    const child = fakeServer((cmd) => (/fill /.test(cmd) ? '[12:00:00]: [Server thread/INFO]: Successfully filled 1 blocks\n' : null));
    const t = new Truth({ child, logPath: TMP });
    fs.appendFileSync(TMP, Array.from({ length: 6000 }, (_, i) => `[12:00:00]: [Server thread/INFO]: noise line ${i}`).join('\n') + '\n');
    t.pump();
    const st = t.stats();
    ok(st.queue <= 5000 && st.dropped > 0, '队列被封顶并记录丢行数', JSON.stringify({ q: st.queue, d: st.dropped }));
    const n = await t.fillCount('the_nether', { x1: 0, y1: 40, z1: 0, x2: 0, y2: 40, z2: 0 }, 'minecraft:air');
    ok(n === 1, '封顶后仍能取到回执', `got=${n}`);
}

async function test4_partial_line() {
    console.log('④ 半行留在缓冲里，不被当成回执');
    fs.writeFileSync(TMP, '[12:00:00]: [Server thread/INFO]: Successfully filled 3 blocks');   // 故意没换行
    const child = fakeServer(() => null);
    const t = new Truth({ child, logPath: TMP });
    t.pump();
    ok(t.queue.length === 0, '无换行的半行不入队', `queue=${t.queue.length}`);
    fs.appendFileSync(TMP, '\n');
    t.pump();
    ok(t.queue.length === 1, '补上换行后才入队', `queue=${t.queue.length}`);
}


async function test7_probeCell_walks_candidates() {
    console.log('⑦ probeCell：候选未命中要能往下试（fill 回执 No blocks ⇒ 返回 0，不是超时）');
    fs.writeFileSync(TMP, '');
    // 只有「候选 netherrack」命中：探测 `… barrier replace netherrack` 与复原 `… netherrack replace barrier` 都回 1
    const child = fakeServer((cmd) => {
        if (!/fill /.test(cmd)) return null;
        const hit = /replace minecraft:netherrack/.test(cmd) || /replace minecraft:barrier/.test(cmd);
        return hit
            ? '[12:00:00]: [Server thread/INFO]: Successfully filled 1 blocks\n'
            : '[12:00:00]: [Server thread/INFO]: No blocks were filled\n';
    });
    const t = new Truth({ child, logPath: TMP });
    const r = await t.probeCell('the_nether', { x: 1, y: 2, z: 3 }, ['minecraft:basalt', 'minecraft:netherrack', 'minecraft:air']);
    ok(r.hit === 'minecraft:netherrack' && r.restoreOk === true, '逐个候选试到命中并复原', JSON.stringify(r));
    ok(!t.poisoned, '未因未命中而判死通道', JSON.stringify(t.poisoned));
    ok(t.stats().chans.fill.sent === 3, '发了 3 条 fill（basalt 未命中 + netherrack 命中 + 复原）', JSON.stringify(t.stats().chans.fill));
}
/**
 * ⑧ S2-05：实体效果列表解析（`parseActiveEffects`）。
 *
 * ★ 本组存在的唯一理由：钉住"**判据格式必须用真服原文**"（手册 §5；S2-04 §5.5-B/C 同族的第三次复发）。
 *   我第一版写 `/"Id":\s*12\b/`（引号 + `\b`），而 1.16.1 真实形态是 **`Id: 12b`（无引号、带 b 后缀）**
 *   ⇒ 服务端明明 `Applied effect Fire Resistance`、NBT 里明明有 `Id: 12b`，判据却读成 `false`。
 *   测试数据**逐字取自真服** `runs/S2_S5A/server.log:567`（`effect give fire_resistance 3600 0 true` 之后 1 秒），
 *   **不是自己编的**——自己编的形态正是上一版栽跟头的原因。
 */
function test8_activeEffects() {
    console.log('⑧ 实体效果解析：用真服原文当阳性对照（S2-05 的判据格式坑）');
    // ↑ 真服原文逐字：Id 12=fire_resistance(71971 tick≈60min，与 --pearl 段的 3600s 对得上)、
    //   Id 11 amplifier 4=resistance IV(harness.mjs:469 的 60s 那条)、Id 28=slow_falling。
    const REAL = '[14:03:28] [Server thread/INFO]: BarterBotC has the following entity data: '
        + '[{Ambient: 0b, ShowIcon: 0b, ShowParticles: 0b, Duration: 71971, Id: 12b, Amplifier: 0b}, '
        + '{Ambient: 0b, ShowIcon: 0b, ShowParticles: 0b, Duration: 446, Id: 11b, Amplifier: 4b}, '
        + '{Ambient: 0b, ShowIcon: 0b, ShowParticles: 0b, Duration: 446, Id: 28b, Amplifier: 0b}]';
    const r = parseActiveEffects(REAL);
    ok(r.readFailed === false, '真服原文读得到（不是 readFailed）', JSON.stringify(r.readFailed));
    ok(r.fireResistance === true, '★ 阳性对照：真服原文里 Id: 12b 必须判成有抗火', JSON.stringify(r));
    ok(r.ids.join(',') === '12,11,28', '三个效果 id 全部解析出来（顺序不错）', JSON.stringify(r.ids));
    ok(r.effects[0].duration === 71971 && r.effects[1].duration === 446, 'Duration 也对得上', JSON.stringify(r.effects));
    ok(FIRE_RESIST_ID === 12, 'FIRE_RESIST_ID=12（源码依据 MobEffects.java:48）', String(FIRE_RESIST_ID));

    // 阴性对照：同一形态但只有 resistance IV（Id 11）⇒ 不得判成有抗火（防"恒真"）
    const noFire = REAL.replace('Duration: 71971, Id: 12b, Amplifier: 0b', 'Duration: 71971, Id: 11b, Amplifier: 4b');
    ok(parseActiveEffects(noFire).fireResistance === false, '★ 阴性对照：只有 Id: 11b ⇒ 无抗火', JSON.stringify(parseActiveEffects(noFire)));

    // "没读到" ≠ "没有"：读不到必须是 readFailed + fireResistance===null，不能折算成 false
    const nul = parseActiveEffects(null);
    ok(nul.readFailed === true && nul.fireResistance === null, 'null 输入 ⇒ readFailed + null（不是 false）', JSON.stringify(nul));

    // ★ 回归锁：我第一版那个错正则对**真服原文**不匹配 —— 这条钉住它，别有人再写回去
    const oldBuggy = /"Id":\s*12\b/;
    ok(oldBuggy.test(REAL) === false, '★ 我第一版的正则（带引号）对真服原文确实不匹配（这就是那次假阴性的成因）');
    ok(/\bId:\s*12b?\b/.test(REAL) === true, '★ 正确的正则（无引号 + b? 后缀）对真服原文匹配');

    // 名字形态也收（将来版本 NBT 改成字符串 id 时不至于整条判据哑掉）
    const named = '[Server thread/INFO]: BarterBotC has the following entity data: [{Id: "minecraft:fire_resistance", Duration: 600}]';
    ok(parseActiveEffects(named).fireResistance === true, '名字形态 Id:"minecraft:fire_resistance" 也收', JSON.stringify(parseActiveEffects(named).effects));
}

(async () => {
    try {
        await test1_interleaved();
        await test2_no_reply_kills();
        await test3_utf8_offset();
        await test4_partial_line();
        await test5_queue_cap();
        await test6_timeq_mutex();
        await test7_probeCell_walks_candidates();
        test8_activeEffects();
    } finally {
        try { fs.rmSync(TMP, { force: true }); } catch { /* 忽略 */ }
    }
    console.log(failed ? `\n✗ ${failed} 条失败` : '\n✓ 全部通过');
    process.exit(failed ? 1 : 0);
})();
