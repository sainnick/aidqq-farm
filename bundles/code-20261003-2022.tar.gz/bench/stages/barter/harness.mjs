// harness.mjs — F 线（MC-S2-01）共用台架：泳道 C 的拿锁/起服/连 bot/tp/kit/收工
//
// 纪律（手册 §9.2 + §9.3）：
//   1. **F 线锁由独立进程长期持有**（会话开工时用 Start-Process 拿的，pid 记在 .line-locks/F.json）。
//      本文件**只拿泳道 C 的锁**（`holdLocks(['C'])`），并在每局结束时释放 ——
//      派单写明「C 线只在 F 两局之间借用」，所以本线必须**一局一放**。
//   2. 只用服务器 stdin 控制台发命令（RCON 会毒化服务进程，手册 §2）。控制台**没有 @s**。
//   3. **1.16.1 是有 `/forceload` 的**（回执 `Marked chunk [0,0] … to be force loaded`，
//      `forceload query` 查得回来），**但单次上限 256 区块**，且**多区块 add 的回执坐标与请求不符**
//      ⇒ 本台架**不依赖它**，改用"先把 bot tp 过去让区块随玩家自然加载"（S2-01 §2.2 实测）。
//      ⚠ 早期版本本文件顶部写的是"1.16.1 没有 /forceload"，**已作废**，别再照抄。
//   4. 跨维度/远距 tp 之后**必须校验客户端坐标**（E 线 E2A3 实测 "moved too quickly" 会让
//      客户端坐标停在旧位置，代码读到幻影位置却不报错）。

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log } from '../_lib/runner_core.mjs';
import { holdLocks } from '../_lib/line_lock.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';
import { Truth } from './truth.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(BENCH_DIR, '../../..');
// 任务层代码只从**本线 worktree** 读（§9 禁令：不碰主目录 mindcraft/ 与别人的 worktree）
export const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's2-barter');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
export const { Vec3 } = require('vec3');
export const mineflayer = require('mineflayer');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = 'server-1.16.1.jar';
export const MC_VERSION = '1.16.1';
export const SEED = argOf(process.argv, 'seed', '4926685115947721762');
export const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

/** 泳道 C（派单 §0：F 线用本地 C） */
export const LANE = {
    idx: 2, name: 'C', dir: `${SERVER_TEMPLATE}_laneC`,
    serverPort: 25568, rconPort: 25578, username: 'BarterBotC', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneC`, JAR_NAME), java: JAVA,
};

/**
 * 主种子的堡垒站。**2026-10-02 夜按 C 线 `MC-ROUND5 §C` 的结论换成新中心 [336,256]**
 * （旧中心 [288,240] 来自 `/locate`，离锚点 150 格、不是要塞对应点那片）。
 * 旧中心上已测的 B1 数据：把玩周期/捡起延迟是**机制属性**（与站位无关，仍有效）；
 * 猪灵密度是**站级属性**，报告里已标注为旧中心口径。
 */
export const STATION = {
    bastion: { x: 336, z: 256, yLo: 32, yHi: 47, radius: 32, legacyCenter: [288, 240] },
    // ★ S2-04 新增：**猪灵密集的作业位**（离线存档解析实测，见 `analysis/s3_fortress_map/verify_standoff.mjs`）
    //   上一轮用的 (319,68,242) 在存档里 **3.4 格内 0 头**（两份存档都是）—— 这就是
    //   S2-03「窗口里最多 2 头」的直接原因，**不是站位选得不好就是猪灵稀疏**。
    //   (331,57,238) 存档实测 3.4 格内 **4 头**（world_A）/ 2 头（world_B），6 格内 7 头，
    //   脚下 `cracked_polished_blackstone_bricks`、本格与头顶都是 air ⇒ 可站。
    //   ⚠ 距 hoglin (333,67,242) **10.95 格** ⇒ 真实链路必须先清场（stage-02 §R2.2 脱战相）。
    piglinDense: { x: 331, y: 57, z: 238, hoglin: { x: 333, y: 67, z: 242, dist: 10.95 } },
    // 主种子废弃传送门（B 线正在用；F 线只在需要时引用，不进生产代码）
    overworldPortal: { x: 187, z: 308, yLo: 40, yHi: 43 },
};

/**
 * 回到**指定**的已复核格子（不一定是 parkSafe 的空中平台）。
 * 为什么需要（S2_B2R2 实测）：新中心 [336,256] 的**猪灵在地面**
 * （`standNatural` 找到 (328,36,268)、最近猪灵 **0.5 格**），而空中平台在 **y=72**；
 * 用平台当作业位就一头猪灵都够不着（`bind` 0 槽、0 投锭）。
 * ⇒ 作业位必须是**地面格**，平台只用来"安全进场"。
 */
export async function recallTo(cell, { settleMs = 1200, label = 'cell' } = {}) {
    if (!cell) return null;
    const [x, y, z] = Array.isArray(cell) ? cell : [cell.x, cell.y, cell.z];
    cmd(`effect give ${LANE.username} minecraft:slow_falling 20 0 true`);
    await tpNether(x + 0.5, y, z + 0.5);
    await sleep(settleMs);
    const at = botPos();
    const ok = at && Math.abs(at.x - (x + 0.5)) < 1.5 && Math.abs(at.z - (z + 0.5)) < 1.5 && Math.abs(at.y - y) < 2;
    log(`[recall:${label}] → ${posStr(at)} ${ok ? 'OK' : '⚠ 偏了'}`);
    return { cell: [x, y, z], ok, at: at ? [+at.x.toFixed(1), +at.y.toFixed(1), +at.z.toFixed(1)] : null };
}
/**
 * 玻璃围栏（**只用来测引擎上限**；派单点名可行性仍按开放场判）。
 * 用玻璃不用屏障：玻璃**挡移动不挡视线**，而 1.16.1 的喂锭交互要求"射线穿过猪灵
 * inflate(1.0) 的 AABB"——屏障会把射线挡死，玻璃不会。
 *
 * 🚨🚨 **S2-03 修掉两个让上一轮围栏"只成 2 边"的真 bug**（`runs/S2_B2R3/b2_p1b_pen.json`
 *   的 `glassCells=[0,0,1,1]` 就是它们的产物，回执数是**错的**，不是围栏真的没建成）：
 *   ① **FIFO 错位**：上一版用 `t.raw(fill)` 裸发围栏（**没有登记 sent**），
 *      紧接着 `fillCount` 调 `ask('fill')` 会把队列里**上一条围栏的回执**当成自己的答案
 *      （`truth.mjs` 头部的纪律①：只认本条命令之后的回执）。⇒ 四条边的回执整体错位一位。
 *   ② **复核本身是破坏性的**：`truth.fillCount` 发的是 `fill <盒> barrier replace <目标块>`
 *      —— 它**把刚建好的玻璃换成 barrier** 才数出来的。⇒ 每条边"数完就没了"，
 *      下一轮再看自然读成 0。上一版不但读错，还把围栏自己拆了。
 *   现在：**建造走 `t.ask('fill')`（登记 sent ⇒ 严格 FIFO 配对）+ 客户端 `blockAt` 非破坏复核**，
 *   并给出 `ok` 硬闸（四条边回执全 > 0 且客户端抽样玻璃占比达标才算建成）。
 */
export async function buildPen({ r = 4, wallH = 2, at = null, maxFillMs = 25000 } = {}) {
    const t = truth();
    const p = at ?? state.park;
    if (!p) throw new Error('buildPen 需要先 parkSafe（state.park）或显式给 at');
    if (!t) throw new Error('buildPen 需要先 bootWorld（真值通道未起）');
    const [x, y, z] = p;
    const walls = [
        { x1: x - r, z1: z - r, x2: x + r, z2: z - r },
        { x1: x - r, z1: z + r, x2: x + r, z2: z + r },
        { x1: x - r, z1: z - r, x2: x - r, z2: z + r },
        { x1: x + r, z1: z - r, x2: x + r, z2: z + r },
    ];
    const RE_FILL_ANY = /Successfully filled (\d+) blocks|No blocks were filled/;
    const got = [];
    const expect = [];
    for (const w of walls) {
        for (let dy = 0; dy < wallH; dy++) expect.push((w.x2 - w.x1 + 1) * (w.z2 - w.z1 + 1));
        // ★ 登记 sent：ask() 内部会 c.sent++ 并只取本条之后的回执 ⇒ 不再错位
        const line = await t.ask('fill', `execute in minecraft:the_nether run fill ${w.x1} ${y} ${w.z1} ${w.x2} ${y + wallH - 1} ${w.z2} minecraft:glass`, RE_FILL_ANY, { timeoutMs: maxFillMs });
        const m = /Successfully filled (\d+) blocks/.exec(line ?? '');
        got.push(m ? parseInt(m[1], 10) : 0);
        log(`[pen] 边 fill 回执 = ${got[got.length - 1]}（期望 ${expect[expect.length - 1] ?? 0}）`);
    }
    // 非破坏复核：客户端方块表（bot 就在围栏中心，区块必然已加载）
    const cells = [];
    let glass = 0, solidOther = 0;
    for (const w of walls) {
        for (let dx = Math.min(w.x1, w.x2); dx <= Math.max(w.x1, w.x2); dx++) {
            for (let dz = Math.min(w.z1, w.z2); dz <= Math.max(w.z1, w.z2); dz++) {
                for (let dy = 0; dy < wallH; dy++) {
                    const q = new Vec3(dx, y + dy, dz);
                    let name = 'null';
                    try { name = bot()?.blockAt(q)?.name ?? 'null'; } catch { name = 'null'; }
                    cells.push([dx, y + dy, dz, name]);
                    if (name === 'glass') glass++; else if (name !== 'air') solidOther++;
                }
            }
        }
    }
    const total = cells.length;
    const rec = {
        pen: [x, y, z], r, wallH, fillReceipts: got, expect: expect.slice(0, got.length),
        clientCheck: { total, glass, solidOther, glassRatio: total ? +(glass / total).toFixed(3) : 0, cells },
        // 硬闸：**四条边回执全非 0** 才算布景成功（派单 S2-03 点名）
        ok: got.length === 4 && got.every((n) => n > 0) && total > 0 && glass / total >= 0.9,
        note: '玻璃围栏（挡移动不挡视线）；**只用于测引擎上限**，可行性按开放场判',
    };
    log(`[pen] 回执 ${JSON.stringify(got)}｜客户端玻璃 ${glass}/${total}（${(rec.clientCheck.glassRatio * 100).toFixed(1)}%）｜ok=${rec.ok}`);
    return rec;
}

/**
 * 🚦 **站位守护（S2-03）**：开放场实验要求 bot **站在那一格**不动，但堡垒地形是窄台，
 *   实测钉住 `(320,68,241)` 后 bot **立刻掉一格并漂 1.2 格**（`recall → 321.6,67.0,240.7`），
 *   掉下去就可能摔死/掉进岩浆 ⇒ 后面每一拍的采样都变成"在另一个地方数猪灵"。
 *   ⇒ 每 `everyMs` 检查一次：① 不在下界 ⇒ 返回死亡原因（交给中止闸）；
 *   ② 水平漂出 `r` 或**下坠超过 `dy`** ⇒ 重新 tp 回作业位（缓降），并记账。
 *   ⚠ **横向半径按模式给**：approach 模式本来就要走动（用大 r），wait/ground 必须站定（小 r）。
 * @returns {{guard:()=>string|null, stats:()=>object}}
 */
export function makeStandGuard(cell, { r = 2.5, dy = 3.0, everyMs = 1500, tp = true } = {}) {
    const [cx, cy, cz] = Array.isArray(cell) ? cell : [cell.x, cell.y, cell.z];
    const st = { checks: 0, retps: 0, lastRetpAt: 0, fell: 0, maxDrift: 0, maxDrop: 0 };
    const check = () => {
        st.checks++;
        const me = botPos();
        const d = String(dim());
        if (!me || !/nether/i.test(d)) return `death:not_in_nether(${d || 'unknown'})`;
        const dh = Math.hypot(me.x - (cx + 0.5), me.z - (cz + 0.5));
        const drop = cy - me.y;
        st.maxDrift = Math.max(st.maxDrift, dh);
        st.maxDrop = Math.max(st.maxDrop, drop);
        if (dh <= r && drop <= dy) return null;
        if (drop > dy) st.fell++;
        st.retps++;
        st.lastRetpAt = Date.now();
        log(`[stand] 漂 ${dh.toFixed(2)} 格 / 下坠 ${drop.toFixed(2)} 格 ⇒ 拉回作业位 ${cx},${cy},${cz}（第 ${st.retps} 次）`);
        if (tp) {
            try {
                cmd(`effect give ${LANE.username} minecraft:slow_falling 20 0 true`);
                cmd(`execute in minecraft:the_nether run tp ${LANE.username} ${cx + 0.5} ${cy} ${cz + 0.5}`);
            } catch { /* 发不出去就等下一轮 */ }
        }
        return null;                      // 拉回本身不算中止理由（只有死/离开下界才中止）
    };
    const timer = setInterval(() => { try { check(); } catch { /* 忽略 */ } }, everyMs);
    if (timer.unref) timer.unref();
    return { guard: check, stop: () => clearInterval(timer), stats: () => ({ ...st, r, dy }) };
}

/** 站位**四点支撑**校验：bot 碰撞箱 0.6 宽，站位格四角下方都必须是实心非液体 */
export function footingOk(p, { inset = 0.3 } = {}) {
    const corners = [[-inset, -inset], [inset, -inset], [-inset, inset], [inset, inset]];
    const names = [];
    for (const [dx, dz] of corners) {
        const b = bot()?.blockAt(new Vec3(p.x + dx, p.y - 1, p.z + dz));
        if (!b) return { ok: false, why: 'blockNull', names };
        names.push(b.name);
        if (b.boundingBox !== 'block' || b.name.includes('lava')) return { ok: false, why: `corner_${dx}_${dz}=${b.name}`, names };
    }
    return { ok: true, why: null, names };
}

/**
 * 死亡中止闸（S2-03 派单第一条）：**以 server.log 的死亡消息为准**。
 * 两条**互相独立**的通道，任一命中就中止：
 *   ① server.log 出现 `BarterBotC was slain by …` / `drowned` / `fell from a high place` …
 *   ② 客户端维度变成主世界（死了会在主世界重生）——**阳性对照式冗余**：
 *      日志通道坏了（编码/缓冲）时这条仍然生效，反之亦然。
 * ⚠ 与 `truth()` 的日志增量读取**互不干扰**：watchDeaths 自己维护文件偏移（见其注释）。
 */
export function makeDeathGuard(w, { alsoDim = true } = {}) {
    return () => {
        w?.check?.();                     // ★ 同步扫一次（短局里 2s 轮询来不及）
        if (w?.deaths?.length) return `death:${w.deaths[0].who} ${w.deaths[0].cause}`;
        if (alsoDim) {
            const d = String(dim());
            if (d && !/nether/i.test(d)) return `death:respawned_in_${d}`;
        }
        return null;
    };
}

/**
 * 死亡归因：**server.log 里有死亡消息**（设计会话 10-02 夜纠正了我"零玩家不落日志"的错误推断）。
 * `BarterBotC was slain by Piglin` / `drowned` / `was slain by Zombie` 都是实测拿到的。
 *
 * ⚠⚠ **必须自己维护文件偏移，不能调 `truth().drain()`**（我第一版就这么写错了）：
 *   `drain()` 推进的是**共享的**读取偏移，一调就把真值通道要等的回执抢走了
 *   ⇒ 通道被判死、死亡消息也只剩一半。两边都只看到一半，两边都错。
 */
export function watchDeaths(logPath = null, onDeath = null) {
    const re = /(BarterBotC|\b[A-Za-z]+\b) (was slain by [\w ]+|drowned|fell from a high place|burned|blew up|hit the ground too hard|went off with a bang|suffocated in a wall|tried to swim in lava|starved to death|was killed|died)/;
    // ⚠⚠ **局部变量名不能叫 `path`**（S2-03 逮到）：`const path = logPath ?? path.join(...)` 里
    //   右边那个 `path` 解析到**自己这个还没初始化的 const**（TDZ）⇒ 抛
    //   `ReferenceError: Cannot access 'path' before initialization`。
    //   ⇒ **`watchDeaths()` 从 S2-01 第二轮"修好"之后就一直是死代码**（一调用就抛），
    //   这就是 S2-01 报告里"这轮 `deaths: []` 没抓到"的真因（当时归因成"我调了 drain() 抢通道"）。
    const logFile = logPath ?? path.join(state.runDir ?? '.', 'server.log');
    const deaths = [];
    let offset = (() => { try { return fs.statSync(logFile).size; } catch { return 0; } })();
    /**
     * ★ S2-03：**同步扫一次**（上一版只有 2s 轮询 ⇒ 一个"起跑 0.2 秒就死"的局永远抓不到，
     *   表现是 `deaths: []` 而 `report.reason` 是 `death:respawned_in_overworld`——
     *   两条通道不一致还以为日志通道坏了）。中止闸每轮都会调它 ⇒ 死亡即刻可见。
     */
    const check = () => {
        let size = 0;
        try { size = fs.statSync(logFile).size; } catch { return deaths; }
        if (size <= offset) return deaths;
        let buf;
        try { buf = fs.readFileSync(logFile); } catch { return deaths; }
        const slice = buf.subarray(offset, size);
        const nl = slice.lastIndexOf(0x0a);
        if (nl < 0) return deaths;
        offset += nl + 1;
        for (const line of slice.subarray(0, nl + 1).toString('utf8').split(/\r?\n/)) {
            if (!line) continue;
            if (line.includes('has the following') || line.includes('following entity data')) continue;
            const m = re.exec(line);
            if (m) {
                const rec = { at: new Date().toISOString(), who: m[1], cause: m[2], line: line.slice(-120) };
                deaths.push(rec);
                log(`[death] ${rec.who} ${rec.cause}`);
                onDeath?.(rec);
            }
        }
        return deaths;
    };
    const timer = setInterval(() => { try { check(); } catch { /* 忽略 */ } }, 2000);
    if (timer.unref) timer.unref();
    return { stop: () => clearInterval(timer), deaths, logPath: logFile, check };
}

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 🚦 盘符（跑盘 = workspace 所在盘；S2-03 夜间纪律：空闲 <15GB 不开新局） */
export const DRIVE = path.parse(ROOT).root.replace(/[\\\/]+$/, '');
/**
 * 该盘空闲 GB。
 * ⚠ **不要用 `powershell "(Get-PSDrive D).Free"`**：外层 shell 会先展开 `$( )`/括号，
 *   实测拿到的是被截断的字符串 ⇒ `parseInt` 得 NaN ⇒ **闸门静默失效**（读成"检查通过"）。
 *   改用 Node 自带 `fs.statfsSync`（Node ≥18.15，无子进程、无转义坑）。
 */
export function diskFreeGB() {
    try {
        const s = fs.statfsSync(path.parse(ROOT).root);
        const free = Number(s.bavail ?? s.bfree) * Number(s.bsize);
        return Number.isFinite(free) ? free / 1073741824 : null;
    } catch { return null; }
}

const state = {
    stamp: null, runDir: null, server: null, bot: null, truth: null, clock: null,
    locks: null, startedAt: Date.now(), phases: [],
};
export const S = () => state;

/** 本线任务层模块的绝对路径（只能落在 s2-barter worktree 里） */
export function moduleUrl(rel) {
    const abs = path.join(MINDCRAFT, rel);
    if (!abs.startsWith(path.join(ROOT, 'mindcraft-wt', 's2-barter'))) {
        throw new Error(`MODULE_OUT_OF_WORKTREE: ${rel} 不在本线 worktree 内（§9 禁令）`);
    }
    return pathToFileURL(abs).href;
}

// ---------------------------------------------------------------- 局生命周期

/** 开一局：拿泳道锁 → 等泳道 → 等内存。closeRun 会释放。
 *  泳道 C 被别的会话（C 线借道）占着时**排队等，不接管、不抢占**（手册 §9.2）。 */
export async function openRun(stamp) {
    state.stamp = stamp;
    state.runDir = path.join(BENCH_DIR, 'runs', stamp);
    fs.mkdirSync(state.runDir, { recursive: true });
    installRunnerHooks(() => stamp, () => { try { state.locks?.releaseAll?.(); } catch { /* 忽略 */ } });
    const waitMin = parseInt(argOf(process.argv, 'lock-wait', '25'), 10);
    const t0 = Date.now();
    for (;;) {
        try {
            state.locks = await holdLocks(['C'], { who: 'F', label: `MC-S2-01 ${stamp}`, logFn: log });
            break;
        } catch (e) {
            if (!/LINE_LOCKED/.test(String(e?.message ?? e)) || Date.now() - t0 > waitMin * 60000) throw e;
            log(`泳道 C 线锁被占（${e.lockReason ?? e}）→ 排队等（最多 ${waitMin}min）`);
            await sleep(20000);
        }
    }
    const st = await waitLane(LANE, {
        maxMs: parseInt(argOf(process.argv, 'lane-wait-min', '45'), 10) * 60 * 1000,
        pollMs: 15000,
        onWait: (s) => log(`泳道 C 不可用（${s.why}）→ 等 C 线让路（只等不接管，手册 §9.2）`),
    });
    if (!st.usable) throw new Error(`等不到泳道 C（${st.why}）`);
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE).usable) throw new Error('泳道 C 在等内存期间被占');
    log(`局 ${stamp} 就绪：runDir=${state.runDir}`);
    return state;
}

/**
 * 起一局世界（**每次都 freshWorld**：同种子重开世界地形确定、只清掉上一局的残留）。
 * @param {object} o { difficulty, effect? }
 *
 * 🚦 **D 盘余量硬闸（S2-03，夜间纪律）**：空闲 < `minDiskFreeGB`（默认 15GB）**不起新局**。
 *   每局都 freshWorld，世界是整块重新生成的，磁盘见底时失败在**世界生成中途**，
 *   表现是"server crashed on boot"而不是一个能读懂的错误（手册 §2 已有同类事故）。
 */
export async function bootWorld({ difficulty = 'easy', resistance = false, minDiskFreeGB = 15 } = {}) {
    const free = diskFreeGB();
    if (free != null && free < minDiskFreeGB) {
        throw new Error(`DISK_LOW：${DRIVE} 盘空闲 ${free.toFixed(1)}GB < ${minDiskFreeGB}GB ⇒ 不开新局（夜间纪律）`);
    }
    log(`[disk] ${DRIVE} 空闲 ${free?.toFixed?.(1) ?? '?'}GB（闸门 ${minDiskFreeGB}GB）`);
    freshWorld(LANE, SEED);
    state.server = await bootServerWithRetry(LANE, state.runDir, '1G', log);
    LANE.serverChild = state.server.child;
    log(`server up in ${(state.server.bootMs / 1000).toFixed(0)}s`);
    state.truth = new Truth({ child: state.server.child, logPath: path.join(state.runDir, 'server.log'), log });
    state.clock = state.truth.startClock({ hz: 4, dim: 'the_nether' });

    state.bot = mineflayer.createBot({
        host: '127.0.0.1', port: LANE.serverPort, username: LANE.username, version: MC_VERSION,
    });
    await new Promise((res, rej) => {
        state.bot.once('spawn', res);
        state.bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    const pf = require('mineflayer-pathfinder');
    state.bot.loadPlugin(pf.pathfinder);
    state.bot.pf = pf;
    await sleep(3500);
    cmd(`gamemode survival ${LANE.username}`);
    cmd(`difficulty ${difficulty}`);
    if (resistance) cmd(`effect give ${LANE.username} minecraft:resistance 9999 4 true`);
    await sleep(800);
    log(`bot 已进服：dim=${state.bot.game?.dimension} pos=${posStr(botPos())}`);
    return state;
}

/** 停这一局世界（不释放泳道锁：同一局里可能连起好几局） */
export async function stopWorld() {
    try { state.bot?.quit?.('done'); } catch { /* 忽略 */ }
    try { state.clock?.stop?.(); } catch { /* 忽略 */ }
    if (state.server) { await stopServer(LANE, state.server); state.server = null; }
    state.bot = null; state.truth = null; state.clock = null;
    log('本局世界已停');
}

/** 收工：停服 + 释放泳道锁（C 线可以在两局之间借道） */
export async function closeRun() {
    try { await stopWorld(); } catch (e) { log(`stopWorld 失败：${e}`); }
    if (state.locks) { try { await state.locks.releaseAll(); } catch { /* 忽略 */ } state.locks = null; }
}

// ---------------------------------------------------------------- 命令 / 观测

export function cmd(c) { return state.truth ? state.truth.raw(c) : false; }
export const truth = () => state.truth;
export const bot = () => state.bot;
export const botPos = () => state.bot?.entity?.position ?? null;
export function posStr(p) { return p ? `${p.x.toFixed(1)},${p.y.toFixed(1)},${p.z.toFixed(1)}` : '?'; }
export const dim = () => state.bot?.game?.dimension ?? '?';

/** 等 server.log 出现某个模式 */
export async function waitLog(pat, ms = 30000) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
        for (const l of state.truth.drain()) if (pat.test(l)) return l;
        if (state.server?.child?.exitCode != null) throw new Error('server died');
        await sleep(100);
    }
    throw new Error(`waitLog 超时 ${ms}ms：${pat}`);
}

/** 下界里 tp（1.16.1 支持 `execute in minecraft:the_nether run tp`），并**校验客户端坐标** */
export async function tpNether(x, y, z, { verify = true, tries = 6 } = {}) {
    for (let i = 1; i <= tries; i++) {
        cmd(`execute in minecraft:the_nether run tp ${LANE.username} ${x} ${y} ${z}`);
        await sleep(1500);
        const p = botPos();
        if (!verify) return true;
        const ok = p && Math.abs(p.x - x) < 1.5 && Math.abs(p.z - z) < 1.5;
        if (ok && (dim() === 'nether' || String(dim()).includes('nether'))) return true;
        log(`tp 第 ${i} 次未生效（dim=${dim()} pos=${posStr(p)}），重发`);
        await sleep(1200);
    }
    throw new Error(`tpNether 失败：目标 ${x},${y},${z}，现在 dim=${dim()} pos=${posStr(botPos())}`);
}

/** 开发期 kit（派单 §4 允许；正式验收不得带）。给完回读背包做确认，不靠"命令发出去了" */
export async function kit(items, { verifyMs = 12000 } = {}) {
    for (const it of items) {
        const [name, n = '1'] = it.split(':');
        cmd(`give ${LANE.username} minecraft:${name} ${n}`);
        await sleep(150);
    }
    const t0 = Date.now();
    while (Date.now() - t0 < verifyMs) {
        const inv = invCount();
        if (Object.keys(inv).length) return inv;
        await sleep(300);
    }
    return invCount();
}

/**
 * 安全进下界并落位（布景）。
 *
 * 踩坑史（四次失败换来的，**别简化回去**；全部证据在 runs/S2_CHAN 与 runs/S2_CHAN2 的 server.log）：
 *  ① 硬坐标 `tp <x> <y> <z>` → 堡垒比 route 记的 y32–47 更高，bot 落进方块里，
 *     server.log 一行 "suffocated in a wall"，**客户端坐标却"正常"**。
 *  ② 改用客户端 `blockAt` 找空气格 → bot 还在主世界时客户端给的是**主世界**的方块，
 *     "找到"了一个下界并不存在的空气格 ⇒ nether `fill` 落在未加载区块上，**静默无回执**。
 *  ③ 改用 `/forceload add`（1.16.1 确实有这个命令，回执是
 *     "Marked 2 chunks in minecraft:the_nether from [1, 0] to [1, 1] to be force loaded"，
 *     **坐标与请求的 5×5 完全不符**），紧接着 fill 仍然回 "That position is not loaded"
 *     ⇒ **本 jar 的 forceload 不能当"保证区块已加载"用**（机制存疑，见报告 §1）。
 *  ④ 现在：**先把 bot tp 到下界高空**（区块随 bot 自然加载，且给 slow_falling 防摔死），
 *     再用真值通道竖向扫描找空气格 → 布平台 → 复核 → tp 落位。
 *
 * ⚠ 平台 + 缓降效果都是**开发期 kit**，不参与任何测量；坐标来自 route 站级中心（§7）。
 */
export async function parkSafe({ cx, cz, yLo = 30, yHi = 100, r = 5, dropMs = 900, lip = true, tryHeights = [100, 90, 110, 80, 70] } = {}) {
    const t = truth();
    // ① 防摔：下界高空落下来会死（100 格坠落必死）。开发期 kit，报告里标注。
    cmd(`effect give ${LANE.username} minecraft:slow_falling 60 0 true`);
    cmd(`effect give ${LANE.username} minecraft:resistance 60 4 true`);

    // ② 先把 bot 送进下界：区块随玩家自然加载，之后真值通道才有真值
    //   （forceload 只作为 best-effort 顺手记一下回执，不作为依赖）
    let entered = false;
    for (const y of tryHeights) {
        cmd(`execute in minecraft:the_nether run tp ${LANE.username} ${cx + 0.5} ${y} ${cz + 0.5}`);
        await sleep(3000);
        const p = botPos();
        if (p && String(dim()).includes('nether') && Math.abs(p.x - cx) < 2 && Math.abs(p.z - cz) < 2 && p.y > 0) { entered = true; break; }
        log(`[park] y=${y} 未进下界（dim=${dim()} pos=${posStr(p)}），换高度重试`);
    }
    if (!entered) throw new Error(`PARK_ENTER_FAILED：tp 到下界 ${cx},?,${cz} 失败（dim=${dim()}）`);
    t.pump();
    const forceloadReceipt = t.queue.find((l) => /force loaded/i.test(l)) ?? null;   // 顺手留证据

    // ③ 真值竖向扫描（现在区块已加载）：从上往下找第一格"空气"
    let spot = null;
    const ys = [];
    for (let y = yHi; y >= yLo; y--) ys.push(y);
    for (const y of ys) {
        const cell = await t.probeCell('the_nether', { x: cx, y, z: cz }, ['minecraft:air']);
        if (cell.hit === 'minecraft:air' && cell.restoreOk) { spot = { x: cx, y, z: cz }; break; }
    }
    if (!spot) {
        for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [3, 0], [-3, 0], [0, 3], [0, -3], [6, 6], [-6, -6]]) {
            for (const y of ys) {
                const cell = await t.probeCell('the_nether', { x: cx + dx, y, z: cz + dz }, ['minecraft:air']);
                if (cell.hit === 'minecraft:air' && cell.restoreOk) { spot = { x: cx + dx, y, z: cz + dz }; break; }
            }
            if (spot) break;
        }
    }
    if (!spot) throw new Error(`PARK_FAILED：站心 (${cx},${cz}) 竖向 y${yLo}..${yHi} 找不到空气格（真值扫描）`);
    const { x, y, z } = spot;

    // ④ 布景：脚下 (2r+1)² 平台 + 头顶两格空气 + ★ 接落地板唇边（barrier 1 格：bot 走不出去，猪灵也进不来）
    t.raw(`execute in minecraft:the_nether run fill ${x - r} ${y - 1} ${z - r} ${x + r} ${y - 1} ${z + r} minecraft:netherrack`);
    await sleep(dropMs);
    t.raw(`execute in minecraft:the_nether run fill ${x - r} ${y} ${z - r} ${x + r} ${y + 1} ${z + r} minecraft:air`);
    await sleep(dropMs);

    // ★ 接落地板的**唇边**：四周 1 格 barrier。bot 的捡拾导航撞到它就会停下，
    //   不会再"走出平台 → 摔死/被围殴 → 背包全丢"（S2_B2 珍珠局就是这么丢的）。
    const lipCells = [];
    if (lip) {
        for (const w of [[x - r, z - r, x + r, z - r], [x - r, z + r, x + r, z + r], [x - r, z - r, x - r, z + r], [x + r, z - r, x + r, z + r]]) {
            t.raw(`execute in minecraft:the_nether run fill ${w[0]} ${y} ${w[1]} ${w[2]} ${y} ${w[3]} minecraft:barrier`);
            await sleep(500);
            lipCells.push(w);
        }
    }

    // ⑤ 真值复核（平台铺好了，但必须确认 bot 的脚格是空气、脚下一格是 netherrack）
    const feet = await t.probeCell('the_nether', { x, y, z }, ['minecraft:air']);
    const floor = await t.probeCell('the_nether', { x, y: y - 1, z }, ['minecraft:netherrack']);
    if (feet.hit !== 'minecraft:air' || floor.hit !== 'minecraft:netherrack') {
        throw new Error(`PARK_VERIFY_FAILED：feet=${feet.hit} floor=${floor.hit}`);
    }

    // ⑥ tp + 盯 4s 血量（掉血 = 掉进岩浆/窒息 ⇒ 判失败）
    await tpNether(x + 0.5, y, z + 0.5);
    const hp0 = bot()?.health;
    await sleep(4000);
    const hp1 = bot()?.health;
    if (hp0 != null && hp1 != null && hp1 < hp0) {
        throw new Error(`PARK_UNSAFE：落位后掉血 ${hp0}→${hp1}（岩浆/窒息）`);
    }
    const rec = {
        park: [x, y, z], forceloadReceipt, devKit: ['slow_falling', 'resistance IV'],
        verified: { feet: feet.hit, floor: floor.hit, restoreOk: feet.restoreOk && floor.restoreOk },
        lip, lipCells, r, hp0, hp1, dim: dim(),
    };
    state.park = rec;            // recall() 要用
    log(`[park] 落位 ${x},${y},${z}（真值 feet=${feet.hit} floor=${floor.hit}；血量 ${hp0}→${hp1}）`);
    return rec;
}

export function invCount() {
    const o = {};
    for (const it of state.bot?.inventory?.items?.() ?? []) o[it.name] = (o[it.name] ?? 0) + it.count;
    return o;
}
export const countItem = (name) => (state.bot?.inventory?.items?.() ?? []).filter((i) => i.name === name).reduce((a, b) => a + b.count, 0);

/**
 * 回到平台中心（S2_B1 首轮实测踩到：standNatural 一连试 60 个候选，每次 tp + 3.5s，
 * 失败返回 null 时 bot 已经被留在半空/平台外 —— 后面所有投掷的 no_los 都是这么来的）。
 * 每个阶段开始前先 recall()，保证场子是可预期的。
 */
export async function recall(park) {
    const p = park?.park ?? state.park;
    if (!p) return null;
    cmd(`effect give ${LANE.username} minecraft:slow_falling 20 0 true`);
    await tpNether(p[0] + 0.5, p[1], p[2] + 0.5);
    await sleep(1200);
    const at = botPos();
    const ok = at && Math.abs(at.x - (p[0] + 0.5)) < 1.5 && Math.abs(at.z - (p[2] + 0.5)) < 1.5;
    log(`[recall] 回到平台 ${p.join(',')} → ${posStr(at)} ${ok ? 'OK' : '⚠ 偏了'}`);
    return { ok, at: at ? [+at.x.toFixed(1), +at.y.toFixed(1), +at.z.toFixed(1)] : null };
}

/**
 * 走到猪灵群旁边（易物必须在 1.3–3.4 格内，够不到就没法投）。
 * 做法：取最近 K 头猪灵的**质心**，从质心朝远离 bot 的方向退 ~2.6 格当作站位目标，
 * 再用 GoalNear 走过去。⚠ 站位是**当前观测**算出来的，不写死坐标（手册 §7）。
 */
export async function approachPiglins({ k = 3, standoff = 2.6, maxMs = 20000, radius = 24 } = {}) {
    const list = piglist().slice(0, k);
    if (!list.length) return { ok: false, why: 'no_piglin_in_view' };
    const c = list.reduce((a, e) => ({ x: a.x + e.position.x / list.length, y: a.y + e.position.y / list.length, z: a.z + e.position.z / list.length }), { x: 0, y: 0, z: 0 });
    const me = botPos();
    const dx = me.x - c.x, dz = me.z - c.z;
    const len = Math.hypot(dx, dz) || 1;
    const target = { x: Math.round(c.x + (dx / len) * standoff), y: Math.round(c.y), z: Math.round(c.z + (dz / len) * standoff) };
    const pf = bot().pf;
    try {
        const p = bot().pathfinder.goto(new pf.goals.GoalNear(target.x, target.y, target.z, 1));
        p.catch(() => {});
        const r = await Promise.race([p.then(() => 'ok'), sleep(maxMs).then(() => 'timeout')]);
        try { bot().pathfinder.stop(); bot().clearControlStates?.(); } catch { /* 忽略 */ }
        const at = botPos();
        const nearest = Math.min(...list.map((e) => e.position.distanceTo(at)));
        const rec = { ok: r === 'ok', target, at: at ? [+at.x.toFixed(1), +at.y.toFixed(1), +at.z.toFixed(1)] : null, nearest: +nearest.toFixed(2), cluster: [+c.x.toFixed(1), +c.y.toFixed(1), +c.z.toFixed(1)], k: list.length };
        log(`[approach] ${JSON.stringify(rec)}`);
        return rec;
    } catch (e) {
        return { ok: false, why: String(e).slice(0, 80) };
    }
}
let _pigmod = null;
function piglist() {
    return Object.values(bot()?.entities ?? {}).filter((e) => e.name === 'piglin' && e.position);
}

/**
 * 落到**自然地面**（不铺平台）：找"脚头空、脚下本来就有实心非液体"的格子，
 * 优先猪灵所在的高度与附近。**猪灵交易必须在地面做**——它们不会爬到空中平台上。
 * 同样三步校验：客户端提候选 → 真值通道复核（feet=air + floor∈实心名单）→ tp → 盯血量。
 * @param {object} o { cx, cz, r, yLo, yHi, nearPiglins }
 */
export async function standNatural({ cx, cz, r = 18, yLo = 30, yHi = 60, nearPiglins = true, tries = 60 } = {}) {
    const t = truth();
    const SOLID = ['minecraft:netherrack', 'minecraft:blackstone', 'minecraft:basalt', 'minecraft:soul_soil',
        'minecraft:magma_block', 'minecraft:gilded_blackstone', 'minecraft:gold_block',
        'minecraft:polished_blackstone_bricks', 'minecraft:nether_bricks', 'minecraft:quartz_block',
        'minecraft:crimson_nylium', 'minecraft:warped_nylium'];
    const pigs = Object.values(bot()?.entities ?? {}).filter((e) => e.name === 'piglin' && e.position);
    const cands = [];
    for (let x = cx - r; x <= cx + r; x++) {
        for (let z = cz - r; z <= cz + r; z++) {
            for (let y = yLo; y <= yHi; y++) {
                const p = new Vec3(x, y, z);
                const f = bot().blockAt(p), h = bot().blockAt(p.offset(0, 1, 0)), b = bot().blockAt(p.offset(0, -1, 0));
                if (!f || !h || !b) continue;
                if (f.name !== 'air' || h.name !== 'air') continue;
                if (b.boundingBox !== 'block' || b.name.includes('lava')) continue;
                let d = Math.hypot(x - cx, z - cz);
                if (nearPiglins && pigs.length) {
                    const near = Math.min(...pigs.map((e) => e.position.distanceTo(p)));
                    if (near > 12) continue;                 // 离最近猪灵太远就没意义
                    d = near;
                }
                cands.push({ x, y, z, score: +d.toFixed(1) });
            }
        }
    }
    cands.sort((a, b2) => a.score - b2.score);
    for (const c of cands.slice(0, tries)) {
        const feet = await t.probeCell('the_nether', { x: c.x, y: c.y, z: c.z }, ['minecraft:air']);
        if (feet.hit !== 'minecraft:air') continue;
        const floor = await t.probeCell('the_nether', { x: c.x, y: c.y - 1, z: c.z }, SOLID);
        if (!floor.hit) continue;
        try { await tpNether(c.x + 0.5, c.y, c.z + 0.5); } catch { continue; }
        const hp0 = bot()?.health;
        await sleep(3500);
        const hp1 = bot()?.health;
        if (hp0 != null && hp1 != null && hp1 < hp0) continue;
        const rec = {
            stand: [c.x, c.y, c.z], nearPiglin: c.score, verified: { feet: feet.hit, floor: floor.hit, restoreOk: feet.restoreOk && floor.restoreOk },
            hp0, hp1, piglinsInView: pigs.length, cands: cands.length,
        };
        log(`[stand] 自然地面落位 ${c.x},${c.y},${c.z}（真值 feet=${feet.hit} floor=${floor.hit}，最近猪灵 ${c.score} 格，血量 ${hp0}→${hp1}）`);
        return rec;
    }
    return null;   // 交由调用方决定是否退到"平台 + fixture"打法
}
export async function resetForTrial(ingots = 96) {
    cmd('clear ' + LANE.username);
    cmd('execute in minecraft:the_nether run kill @e[type=item]');
    cmd('execute in minecraft:the_nether run kill @e[type=experience_orb]');
    await sleep(800);
    cmd(`give ${LANE.username} minecraft:gold_ingot ${ingots}`);
    await sleep(1200);
    return invCount();
}

// ---------------------------------------------------------------- 落盘

/** 每个阶段独立落盘：跑砸了也要保住已经拿到的数据 */
export function record(phase, data) {
    const rec = { phase, at: new Date().toISOString(), ...data };
    state.phases.push(rec);
    const p = path.join(state.runDir, `${phase}.json`);
    fs.writeFileSync(p, JSON.stringify(rec, null, 2));
    fs.appendFileSync(path.join(state.runDir, 'phases.jsonl'), JSON.stringify(rec) + '\n');
    log(`阶段 ${phase} 落盘（${path.basename(p)}）`);
    return rec;
}

export function summary(extra = {}) {
    return {
        stamp: state.stamp, seed: SEED, lane: LANE.name, mcVersion: MC_VERSION,
        station: STATION, startedAt: new Date().toISOString(state.startedAt),
        wallMs: Date.now() - state.startedAt,
        tps: state.clock?.tps?.() ?? null,
        phases: state.phases, ...extra,
    };
}
export function writeSummary(extra = {}) {
    const s = summary(extra);
    fs.writeFileSync(path.join(state.runDir, 'summary.json'), JSON.stringify(s, null, 2));
    log(`summary 落盘（wall ${(s.wallMs / 60000).toFixed(1)}min, TPS=${s.tps ? s.tps.toFixed(2) : '?'}）`);
    return s;
}

export const argv = (n, d = null) => argOf(process.argv, n, d);
