# 1.16.1 地面投锭机制取证（S2 易物 · 开发线 F · MC-S2-03）

> 取证方式：`docs/research/data/src-1161/`（研究线 R6-1 反编译源码，官方名）逐行读，**不手读混淆字节码**（手册 §3）。
> 本文件由只读子 agent 出具原始取证，**主 agent 亲自复核了 3 条承重出处**（下面标 ✅ 的行号已逐字核对过）。
> 纪律：未映射短名（`a`/`b`/`c`/`☃`）按 `src-1161-README.md` §4 标注，**不硬猜类型**；查不到就写查不到。

## 一句话结论（派单第 3 条）

**误判窗口存在，但只属于「地面投锭」通道，不属于「右键喂锭」通道。**

右键喂锭在 1.16.1 源码里**全程不生成任何物品实体**（`PiglinAi:486-497` 直接把金锭 `split(1)` 塞进猪灵副手），
所以"猪灵附近出现新掉落物"不可能把我们自己投的锭当成礼物 ⇒ **119 tick 的测量口径是干净的**。
而 Q 丢锭会在**玩家自己脚下**生成一个 `pickupDelay=40`（2.0s 内谁都捡不走、但客户端立刻可见）的物品实体，
只要玩家距猪灵 < 3.6 格就会被状态机当成礼物，**周期被读成 ~0.3s 而不是 ~6s**（低估约 20×）。

## 1. 猪灵怎么捡地上的物品

拾取是**两条独立机制**：

1. **传感器**（`NearestItemSensor.java:20-26`）每 tick 把「**3.0 格内 + 有视线**的最近物品实体」写进 `NEAREST_VISIBLE_WANTED_ITEM`
   —— `Entity.closerThan(e, 9.0)`（`Entity.java:291-296`）里的 9.0 是**距离平方**，即 **3.0 格 3D 距离**。
2. **真正捡走**在 `Mob.aiStep` 的 looting 段（`Mob.java:480-492`）：条件是
   `!hasPickUpDelay()` **且** 物品在 `cb().inflate(1.0, 0.0, 1.0)` 内。
   猪灵 `sized(0.6F, 1.95F)`（`EntityType.java:309`）⇒ 自身 AABB 半宽 0.3 ⇒ **实际拾取盒 = 水平 ±1.30 格、垂直不膨胀**。

★ **`pickupDelay` 对 mob 同样生效**（和玩家共用一个计数器，`ItemEntity.java:67-74` 每 tick 减 1）——
这是"自我投的锭静静躺在旁边"能持续 2 秒的直接原因。

物品谓词**不是只认金锭**：`Piglin.canTakeItem`（`Piglin.java:446-449`）→ `PiglinAi.a(Piglin, ItemStack)`
（`PiglinAi.java:401-423`）对 `ItemTags.piglin_loved` 全部有反应。
★ **前置条件：`mobGriefing` gamerule 必须为 true**（`GameRules.java:32` 默认 true）——
拉黑它会让猪灵**完全不捡地上的东西**，S2 泳道别关。

拾取 goal 挂在 ADMIRE_ITEM activity 上（`PiglinAi.java:174-181`：`GoToWantedItem(speed 1.0, maxDist 3)` +
`StopAdmiringIfItemTooFarAway(3)`），而**把 `ADMIRING_ITEM` 点着**的是 CORE 里的 `StartAdmiringItemIfSeen(120)`
（`PiglinAi.java:113`）——触发源就是传感器写的那个记忆。⇒ **地面投锭的完整链路成立**。

## 2. 右键喂锭投出去的金锭，会不会作为地面掉落物存在

**不会。** ✅ 已复核 `PiglinAi.java:486-497`：

```java
public static InteractionResult a(Piglin var0, Player var1, InteractionHand var2) {
   ItemStack ☃ = ☃.b(☃);
   if (b(☃, ☃)) {                       // canAdmire
      ItemStack ☃x = ☃.split(1);        // ★ 扣 1 锭，直接进副手
      c(☃, ☃x);                        // holdInOffhand
      admireGoldItem(☃);
      stopWalking(☃);
      return InteractionResult.CONSUME;
   } else { return InteractionResult.PASS; }
}
```

整条链路里**没有 `new ItemEntity`、没有 `addFreshEntity`**。
入口是 `ServerGamePacketListenerImpl.handleInteract:1099-1131` → `Piglin.b(Player, InteractionHand):256-267` → 上面那段。
⚠ 1.16.1 的**实体交互根本不走 `ServerPlayerGameMode#useItemOn`**（那个重载只接方块 `BlockHitResult`），
所以"从 useItemOn 追到 dropItem"这条推理路径在 1.16.1 不存在。

★ **唯一例外**：`holdInOffhand`（`PiglinAi.java:303-309`）在猪灵**副手本来非空**时，
把**旧的**一块锭 `spawnAtLocation` 在**猪灵自己脚下**（`pickupDelay=10`）。
正常节拍下 `stopHoldingOffHandItem` 会先清空副手再丢礼物，所以这个分支是**窄竞态**，不构成系统性污染。

**对照：Q 丢锭**（`Player.java:602-612`，✅ 已复核 612 行 `setPickUpDelay(40)`）：
生成在**玩家脚下**，`pickupDelay=40`（2.0s）⇒ 掉在猪灵 3.6 格判据半径内时**与礼物无法区分**。

## 3. ★ 投出去的东西会不会在礼物之前被当成"礼物"

**会，但只有地面投锭会，窗口 ≥ 40 tick = 2.0s。** 三条决定性依据：

1. **落点重叠**：Q 丢在**玩家脚下**；礼物由 `BehaviorUtils.throwItem:70-79` 生成在**猪灵自己 XZ**、
   初速 0.3 朝最近可见玩家方向飘。两者在 `dropNearPiglin=3.6` 判据内**完全重叠**。
   （礼物实测漂移 1.44 格；按 0.3 初速 + 物品重力 0.04 反解 ≈1.4 格，与实测吻合——**这是算出来的，不是源码常量**。）
2. **`pickupDelay` 谁生效**：`Mob.aiStep:485` 的 `!hasPickUpDelay()` **对 mob 生效** ⇒ 自我 Q 丢的锭 **2.0s 内谁都捡不走**，
   于是它"静静躺在猪灵旁边"，形态与礼物无法区分。礼物自己是 `setDefaultPickUpDelay()=10`。
   ⇒ **单靠 pickupDelay 区分两者是不够的**（只差 30 tick），可靠区分只能靠"这个实体 id 是不是我丢的"。
3. **拾取半径**：传感器 latch 3.0 格、实际拾取盒 ±1.30 格 ⇒ 猪灵迟迟走不到就持续更久。

⇒ **这就是本轮 `ownDrops` 排除的机制依据**（`piglin.js#markOwnDrops` + `findDropNear` 跳过自己的实体 id）。
**独立佐证**：子 agent 重算 S2-01 落盘数据时发现上一轮 `pen/ground` 格的 `cycleAvgMs=549ms`，
与 B1 实测 5960ms 差 **10.8×** —— 那个数**就是**这个误判的产物（我修的正是同一处）。

**另一条同族风险（本轮未修，报告里记为已知）**：礼物朝玩家漂 ⇒ N 槽并行时两个猪灵的礼物可能都落在
同一片区域，`findDropNear` 只按"最近的未认领掉落物"取，**可能把 B 槽的礼物记成 A 槽的成交**。
所以**每槽周期的归属是近似的**，吞吐（总数）不受影响。

## 4. 把玩到期丢礼物的确切条件与时刻

✅ 已复核 `PiglinAi.java:745-747`：

```java
private static void admireGoldItem(LivingEntity var0) {
   ☃.cI().a(MemoryModuleType.ADMIRING_ITEM, true, 120L);      // ★ TTL = 120 tick，硬编码
}
```

- 到期语义：`ExpirableValue.tick()` 每 tick 减 1、`hasExpired()` 是 `<= 0`（`ExpirableValue.java:16-36`），
  `Brain.forgetOutdatedMemories:359-369` 到点擦除记忆 ⇒ 礼物时刻 = 喂锭 tick + **120** + 0~2 tick 的 behavior 评估延迟
  ⇒ **实测区间 120–122 tick**。
- 礼物谓词：`StopHoldingItemIfNoLongerAdmiring`（`PiglinAi.java:112`）要求**副手非空且 `!= Items.SHIELD`**；
  `stopHoldingOffHandItem:323-335` **先清空副手再** `throwItems(getBarterResponseItems())`（`PIGLIN_BARTERING` 战利品表）。
- ★ **1.16.1 确认存在"被玩家打伤后 20 秒禁止易物"**：`wasHurtBy:503-515` → `ADMIRING_DISABLED = 400L`（20s），
  消费点在 `canAdmire:500` 与 `PiglinAi:405`。**注意它同时会把正在把玩的锭直接丢地上**（`wasHurtBy:506`）
  ⇒ **调试时打猪灵一下会额外造出一个"假的新掉落物"，别把它记成礼物。**

## 5. 敌对 / 攻击状态的实存触发点

1.16.1 **没有** `startPanicking`（全树 grep 无匹配）。对我们威胁最大的**不是被打，是开箱和拆守卫方块**：

- **开箱/开桶/开潜影盒/末影箱**（`ChestBlock.java:237-241` 等四处同调）→ `PiglinAi.a(player, true)`
  ⇒ **16 格内所有 IDLE 猪灵开战**（需看得见）。`isIdle` = 当前 activity 是 IDLE（正在把玩的不会被激怒）。
- **拆 `guarded_by_piglins` 方块**（`Block.java:324-328` + `BlockTags.java:85`）→ `PiglinAi.a(player, false)`
  ⇒ **16 格内全部空闲猪灵，无视线要求**。
- 仇恨记忆 `ANGRY_AT = 600L`（30s，`PiglinAi:631-643`）；`UNIVERSAL_ANGER` 需要 gamerule，**1.16.1 默认 false**（`GameRules.java:77`）。
- ★ **难度**：`EntitySelector.ATTACK_ALLOWED`（`EntitySelector.java:17-19`）在 `Difficulty.PEACEFUL` 下恒 false
  ⇒ peaceful 下**不可能被杀**；本轮用 easy（要与真实 S2 一致：搜刮必然开箱 ⇒ 必然踩这条）。

⇒ **给 S2 生产实现的规避清单只有一条：先投锭、后开箱**（等价于"别在猪群中间开箱"）。

## 6. 对 119 tick 判据的影响（本轮最关心的）

**上一轮怎么量的**：`activateEntity` 成功那刻记 `s.tThrow`，之后每 tick 找"猪灵 3.6 格内、尚未被认领的新掉落物"，
命中即 `cycleMs = now - s.tThrow`（`piglin.js` 的 `BarterEngine.stepSlot` / `findDropNear`）。

**会不会被污染**：
- **喂锭通道：不会**（第 2 条：链路上零 ItemEntity）。旁证：实测 p10–p90 = 5.93–5.99s 的**单峰窄分布**——
  若混进 0.3s 的假信号，均值会被拉低、p10 会出现第二簇，实测没有。
- **地面投锭通道：会**（第 3 条，窗口 ≥2.0s）。

**口径固化（本轮采用）**：
- 对外报 **120 tick**（源码 TTL 常量），**119 tick 作为实测校验值**（方向上偏小 1 tick，属客户端时间戳偏差，与源码自洽）。
- ⚠ **119 tick 只在 `drop_entity` 口径、n=7 的子集上成立**；落盘 `summary.json#cycle` 是**混口径**（drop_entity + inv_delta），
  那个 headline 是 **124 tick / 6.20s（n=14）**。两者差 0.17%，机制结论不变，但**报数必须带 n 和口径**。
- ⚠ **不要用 119 tick 去推地面投锭的节拍**：地面投锭 = 120 tick + 走近时间，**必然 >120**，
  它的价值是解除"玩家必须停在 3.2 格内"的约束，不是更快。

## 7. Astra 设计要点（只借设计，不抄代码）

`nether-supplies.mjs:39 barter_group` + `covered-barter.mjs approachBarter` 的编排思路：
站位用 **standoff 距离**沿"目标—bot"连线取主轴（默认 3.15 格，失败退到 2.4 重试）；
喂锭**逐头串行**（每头前等 1 tick 查威胁 → 换锭 → `activateEntity` → 用**金锭数减少**判成交，不信任交互返回值）；
等待**合并**（最多 4 头全部喂完后只等一次）；整轮没成交就抛错并标 `barterNeedsCloser` 以缩短 standoff。

⇒ 本轮 `approach` 模式**只借"站位算在连线的 standoff 处"这一条**，参数全用我们自己的
（standoff 2.8、窗口 2.0–3.4、120 tick），并且**不采用它"猪灵会待在原地"的前提**（上一轮已实测该前提不成立）。

## 8. 没查到 / 存疑（不猜）

1. `Piglin.java:126` 的 `this.p(true)` 身份未定：全树搜不到 `p(boolean` 定义；形态上只能是 `setCanPickUpLoot(true)`，
   但源码不可直读 ⇒ 按高置信推断处理。**若它不成立，地面投锭模式直接死**（`Mob.aiStep` 的 `canPickUpLoot()` 门不过）。
2. `Mob.java:485` 的 `!☃.y` 应为 `!item.hasNoGravity()`，`Entity`/`ItemEntity` 都无 `y` 字段。**不影响结论**。
3. `Mob.b(ItemEntity)`（`Mob:494`）与 `Piglin.pickUpItem`（`Piglin:474`）的覆写关系是**推断**（映射表缺 Mob 那条）。
4. Q 丢锭的 `addFreshEntity` 调用点没定位到（`Player.drop(boolean)` 被反编译器折叠成单行 return）——
   落点与 `setPickUpDelay(40)` 两个参数是**从 `Player:610-612` 直读的**，不受影响。
5. `1.44 格`是算出来的不是源码常量（`BehaviorUtils:73` 的 0.3F 速度 + 物品重力 0.04 反解）。
