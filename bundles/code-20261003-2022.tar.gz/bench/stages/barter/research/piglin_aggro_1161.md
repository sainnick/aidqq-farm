# 1.16.1 猪灵攻击判据取证（MC-S2-04 · 开发线 F）

> **为什么做这一份**：S2-03 §4.1 记「easy 下 bot 29 秒被猪灵连杀 5 次」，归因成
> 「kit 只穿 2 件金甲 ⇒ 只穿 2 件就是活靶」，并据此把对比难度改成了 peaceful。
> **设计会话提出更正**：「1.16.1 只要穿**任意**一件金质护甲猪灵就不会主动攻击」，
> 要求 F 线去查那一局 kit 是不是**真的穿上了**金甲，不要据此下「easy 不可行」的结论。
>
> **本文件的每条结论都带 `文件:行号`**（相对 `docs/research/data/src-1161/`）。
> 取证由只读子 agent 完成，**结论由 F 线主 agent 对着源码逐行复核**（手册 §9.1：
> 子 agent 的结论必须由主 agent 对着原始数据核实后才能写进报告）。
> 复核方式：直接 `read` 下列行号，原文与结论一致。

## 1. 结论先行

**设计会话的更正在源码层面成立，但只对 4 档攻击目标里的最后一档成立。**

- `isWearingGold()` 遍历装备槽，**命中任意一件金质护甲就返回 `true`** —— 不计数、不要求 4 件全套。
  ⇒ **「2 件金甲 = 活靶」这个 S2-03 结论在源码上不成立。**
- 但「穿了金」**不等于免疫**：`findNearestValidAttackTarget()` 共 4 档，
  **前 3 档完全没有金质检查**。金只过滤「未被激怒」的那一档。
- 筛选读的是**装备槽**（`getArmorSlots()` = 4 格 armor 数组），**背包里的金头盔不计入**
  ⇒ **「`give` 发了」≠「穿上了」**，这正是设计会话要求查的点。
- 那 5 次连杀更可能是**金没穿上**，或**猪灵已被激怒**（`ANGRY_AT` 档）。**本单不去断言是哪一种**
  —— 判定方法见 §5（服务端装备槽真值 + `metadata[14]&4` 攻击状态标志，手册 §3 已有该判据）。

## 2. 「是否穿金」的源码判据：任意一件，不是全套

`net/minecraft/world/entity/monster/piglin/PiglinAi.java:592-601`

```java
public static boolean isWearingGold(LivingEntity var0) {
   for (ItemStack ☃ : ☃.getArmorSlots()) {
      Item ☃x = ☃.getItem();
      if (☃x instanceof ArmorItem && ((ArmorItem)☃x).ad_() == ArmorMaterials.GOLD) {
         return true;          // ← 任意一件即 return，不计数
      }
   }
   return false;
}
```

**装备槽 ≠ 背包**（这一条决定了 `give` 之后必须验"穿上没有"）：

| 环节 | 位置 | 事实 |
|---|---|---|
| `Player.getArmorSlots()` | `net/minecraft/world/entity/player/Player.java:1656-1658` | `return this.inventory.armor;` |
| 底层容器 | `net/minecraft/world/entity/player/Inventory.java:29` | `public final NonNullList<ItemStack> armor = NonNullList.withSize(4, ItemStack.EMPTY);` |
| 序列化槽号 | `net/minecraft/world/entity/player/Inventory.java:343-348` | `☃xx.putByte("Slot", (byt)(☃x + 100));` |

🚨 **`Slot` 是 `x + 100`（100=靴/101=护腿/102=胸甲/103=头盔）**，
**不是** mineflayer 客户端 `bot.inventory.slots[5..8]` 用的 5–8。
按 5–8 去解析服务端 NBT 会得到 `gold=0` ⇒ **把"穿了 4 件金甲"读成"一件没穿"**，
而且报告照样跑完、指标照样好看 —— 典型的静默假阴性。
（F 线 `micro_barter3.mjs#serverArmorTruth` 第一版就写成了 5–8，已改；见 §6。）

## 3. 攻击目标选择的 4 档（只有第 4 档看金）

`PiglinAi.java:448-473`

```java
private static Optional<? extends LivingEntity> findNearestValidAttackTarget(Piglin var0) {
   Brain<Piglin> ☃ = ☃.getBrain();
   if (isNearZombified(☃)) {
      return Optional.empty();
   } else {
      Optional<LivingEntity> ☃x = BehaviorUtils.a(☃, MemoryModuleType.ANGRY_AT);   // ①
      if (☃x.isPresent() && isAttackAllowed(☃x.get())) {
         return ☃x;
      } else {
         if (☃.a(MemoryModuleType.UNIVERSAL_ANGER)) {                              // ②
            Optional<Player> ☃xx = ☃.c(MemoryModuleType.NEAREST_VISIBLE_TARGETABLE_PLAYER);
            if (☃xx.isPresent()) { return ☃xx; }
         }
         Optional<Mob> ☃xx = ☃.c(MemoryModuleType.NEAREST_VISIBLE_NEMESIS);         // ③
         if (☃xx.isPresent()) {
            return ☃xx;
         } else {
            Optional<Player> ☃xxx = ☃.c(MemoryModuleType.NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD);  // ④
            return ☃xxx.isPresent() && isAttackAllowed(☃xxx.get()) ? ☃xxx : Optional.empty();
         }
      }
   }
}
```

| 档 | 记忆模块（行号） | 有金质检查？ | 触发条件 |
|---|---|---|---|
| ① | `ANGRY_AT`（`:453-455`） | **无** | 猪灵**已被激怒**（被打 / 有仇敌）⇒ **穿金也照打** |
| ② | `UNIVERSAL_ANGER`（`:457-462`） | **无** | `universalAnger` gamerule 为 true ⇒ 全部猪灵暴怒 |
| ③ | `NEAREST_VISIBLE_NEMESIS`（`:464-466`） | **无** | 僵尸猪灵化等 |
| ④ | `NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD`（`:468-469`） | ✅ **有** | 「**最近的可攻击且没穿金的玩家**」⇒ **这就是被动攻击的唯一一档** |

**④ 的记忆是谁写的**：`net/minecraft/world/entity/ai/sensing/PiglinSpecificSensor.java:83`

```java
if (!☃xxxxxx.isPresent() && EntitySelector.ATTACK_ALLOWED.test(☃xxxxxxxxxxx)
        && !PiglinAi.isWearingGold(☃xxxxxxxxxxxx)) {
   ☃xxxxxx = Optional.of(☃xxxxxxxxxxxx);
}
```

⇒ **金质判据只出现在这一处**，且它筛的是"装备槽里有金"。

## 4. 两条影响 S2 实跑口径的附带事实

1. **`setAngerTarget()` 会连带置 `UNIVERSAL_ANGER` 600 tick（30s）**（`PiglinAi.java:631-643`）：
   ```java
   if (☃.U() == EntityType.PLAYER && ☃.l.getGameRules().b(GameRules.G)) {
      ☃.getBrain().a(MemoryModuleType.UNIVERSAL_ANGER, true, 600L);
   }
   ```
   `GameRules.G` = `universalAnger`，**默认 false**。
   ⇒ **默认世界不会触发 ② 档**；S2-03 那一局的 5 连杀**若**发生在 30 秒窗内，
   值得比对是否设过该 gamerule。**本单未验证该局的 gamerule 设置**，不据此下结论。
2. **`ATTACK_ALLOWED`**（`EntitySelector`）在 peaceful 下恒 false ⇒ 第 ④ 档的记忆永远不填
   ⇒ **peaceful 下猪灵不可能成为主动攻击目标**（这解释了 S2-03 为什么在 peaceful 下拿到 0 死亡，
   但也意味着 peaceful **测不出**本单这个问题）。

## 5. 怎么判定「那一局到底为什么被打」——**本单已经用实服数据答了**

### 5.1 ✅ 答案：**金甲从来没进过背包**（`give` 语法错，与"只穿 2 件"无关）

**实证**（`bench/stages/barter/runs/S2_S4C/server.log`，10:55:17 原文）：

```
[10:55:17] [Server thread/INFO]: Gave 128 [Gold Ingot] to BarterBotC
[10:55:17] [Server thread/INFO]: Invalid ID
[10:55:17] [Server thread/INFO]: ...arterBotC minecraft:golden_helmet:1<--[HERE]
```

- `gold_ingot` 那条写的是 `give <bot> minecraft:gold_ingot 128`（**空格**）⇒ ✅ 成功，背包里有 128 锭。
- 金甲那批写的是 `give <bot> minecraft:golden_helmet:1`（**冒号**）⇒ ❌ `Invalid ID`，
  服务端**根本没执行** ⇒ **4 件金甲一件都没进背包**。

**服务端装备槽真值（同一时刻，`data get entity BarterBotC Inventory`）**：

```
BarterBotC has the following entity data: [{Slot: 0b, id: "minecraft:gold_ingot", Count: 64b}, {Slot: 1b, id: "minecraft:gold_ingot", Count: 64b}]
```

⇒ 装备槽（`Slot 100–103`）**空的**，`goldCount=0`、`verdict='no_gold'`。

### 5.2 ⇒ 三条结论

1. **S2-03 §4.1「easy 下 29 秒被猪灵连杀 5 次」的归因是错的。**
   当时的 kit（`S2-01` 的 `kit()` / S2-03 的 `resetTrial()`）**金甲一直是 `give` 语法错**，
   所以那一局 bot **一件金甲都没有**，**不是"只穿 2 件"**。
   ⇒ 「只穿 2 件就是活靶」这个说法**从来没被测过**。
2. **设计会话的更正成立**：`isWearingGold` 任意一件即 true（`PiglinAi.java:592-601`），
   **「2 件不够、要 4 件全套」是错的**。S2-03 照着这个错归因把 kit 改成"整套 4 件"，
   但**光改件数没用** —— 得先让 `give` 真的把东西发出去。
3. **「easy 不可行」这个结论不成立**（待 S2_S4D 复跑给出最终数据）：
   修好 `give` 语法后 bot 才第一次真正穿上金甲，第一次测 easy。

### 5.3 修法（本单已落）

- `give` 的物品名与数量**用空格分隔**：`give <bot> minecraft:golden_helmet 1`。
- 加**服务端装备槽硬闸**：`serverArmor.verdict !== 'full_gold'` ⇒ **直接抛 `GOLD_ARMOR_NOT_EQUIPPED`，不开测**。
  ⇒ 没有这道闸，坏 kit 跑出的数据（"easy 下被打死"）看起来完全正常，
  **会被读成"easy 不可行"** —— 这正是 S2-03 那个错误结论的成因。
- 加**回归锁**（`mode3_selftest.mjs` ⑪）：用**实服抓到的真回执原文**做阳性对照
  （`REAL_LINE` 直接抄 `S2_S4A/server.log` 10:43:12 那一行），
  外加**反例**：同内容换成客户端 5–8 槽号 ⇒ 读成 `no_gold`，证明槽号判据真在起作用。

### 5.4 ⚠ 顺带记录：`data get entity <玩家> Inventory` 的两个格式坑

1. **回执里没有 `Inventory:` 标签** —— 1.16.1 直接回**数组本体**：
   `… has the following entity data: [{Slot: 0b, id: "minecraft:gold_ingot", …}]`。
   写成 `/Inventory:\s*(…)/` ⇒ 永远不匹配 ⇒ 装备真值通道**静默判死**（本单踩过）。
2. **`id:` 后面有空格**：`id: "minecraft:…"`。手册里 `parseItems` 用的 `id:"minecraft:…"`（无空格）
   ⇒ **解析出 0 件**。⚠ **`probe_b5_chest_gold.mjs#parseItems` 目前仍是无空格写法，本单未修**（B5 未重跑，见报告 §6 待办）。

### 5.5 方法学教训（本单最贵的一条）

> **「`give` 没报错」不等于「`give` 生效了」。** 服务端对 `Invalid ID` 只打一行
> `...<cmd><--[HERE]`，**runner 的 `raw()` 不等回执、也不扫这类行** ⇒ 命令失败完全静默。
> ⇒ **凡是 kit 布景类命令（`give` / `summon` / `effect` / `tp`），都必须在开跑前
> 用一条**独立的服务端真值通道**验"东西真的到位了"**（本单用 `data get entity … Inventory`）。
> 这与手册 §3「`/fill` 失败时不会打出成功日志，所以要检查返回文本」同族，
> 但更隐蔽：`fill` 至少有回执通道，`give` 连回执都不走。

## 6. 本条取证直接改掉的一个 bug

`bench/stages/barter/micro_barter3.mjs#serverArmorTruth` 第一版按 **Slot 5–8** 解析服务端 NBT
（照抄了 mineflayer 客户端的编号）⇒ 永远 `goldCount=0` ⇒ 会在**金甲确实穿上了**的局里
报 `verdict='no_gold'`，并据此给出"easy 仍不可行"的错误结论。
已按 `Inventory.java:346` 改成 **100–103**，并保留 `wornArmor` 原文便于复核。

## 7. 未验证 / 开放问题（如实标注）

| # | 事项 | 状态 |
|---|---|---|
| 1 | S2-03 `S2_M3X` 那一局 kit 是否真穿上了金甲 | **本单用服务端装备槽真值重跑 easy 来答**（不翻旧局推断） |
| 2 | 那一局是否被 `ANGRY_AT`（被打）牵连 | 未查（那一局已停）；要看 telemetry 有无攻击事件 |
| 3 | 那一局是否设过 `/gamerule universalAnger true` | 未查（run 的 setup 不一定留痕） |
| 4 | `GameRules.G` 的全部调用点 | 只确认了定义与 `setAngerTarget` 这一处调用 |
| 5 | `getNearestVisibleTargetablePlayer` 是否过滤金 | 读到它走 `NEAREST_VISIBLE_TARGETABLE_PLAYER`（② 档），
**该路径无金质 predicate**；但本单未逐行读完该方法体，标 **UNVERIFIED** |

## 8. 建议进手册（供设计会话裁决）

> **「被动攻击」和「被激怒后攻击」在源码里是两条独立路径，任何"穿 X 就不被 Y 打"的结论，
> 都要先确认那条路径上到底有没有这个判据、且是唯一路径。**
> 1.16.1 猪灵：`isWearingGold` 只过滤 `NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD` 一档
> （`PiglinAi.java:448-473` + `PiglinSpecificSensor.java:83`），
> `ANGRY_AT` / `UNIVERSAL_ANGER` / `NEAREST_VISIBLE_NEMESIS` 三档不看金。
> 证据：`bench/stages/barter/research/piglin_aggro_1161.md`。
