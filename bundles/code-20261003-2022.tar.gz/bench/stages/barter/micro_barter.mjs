// micro_barter.mjs — MC-S2-01 · B2 并行吞吐 / B4 锭珠比 / 验收（0→12 珍珠）
//
// 验收判据（派单 §F）：
//   · 每分钟投锭次数：N=4 时 ≥27（目标 37），并给出 N–吞吐曲线
//   · 珍珠产出：一次原型局从 0 到 12 颗珍珠的用时与金锭消耗，n≥3
//   · 结论二选一：「可行：N=? 时 12 颗珍珠预计 X 秒、Y 锭」/「不可行：卡在哪」
//
// 两个口径必须分开报（stage-02 §R2.6 只给了其中一个）：
//   · **投锭次数/分** = 借记成立的次数 ÷ 窗口分钟（状态机节拍，不含捡拾）
//   · **珍珠/分、锭珠比**（真实产出）—— 面板上写着 ≥27 次/分，但如果每个槽的**真实周期**
//     比"把玩期"长，纸面吞吐是拿不到的。
//
// 打法（两种，报告里分列）：
//   · natural：bot 落到自然地面 + 走近猪灵群 ⇒ 用**自然生成**的猪灵
//   · fixture：bot 站在布好的平台上 ⇒ 猪灵不够 N 头时 `/summon` 补
//     （**不能用于正式验收**，每条记录标 fixture 数量）
//
// 用法：node micro_barter.mjs [--stamp S2_B2] [--n 1,2,4,6] [--window 90] [--pearls 12] [--runs 3]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
    openRun, bootWorld, closeRun, cmd, truth, bot, botPos, posStr, dim,
    kit, invCount, record, writeSummary, sleep, parkSafe, standNatural, approachPiglins, recall, recallTo, buildPen, watchDeaths,
    LANE, STATION, SEED, argv, moduleUrl, Vec3,
} from './harness.mjs';

const STAMP = argv('stamp', 'S2_B2');
const NS = String(argv('n', '1,2,4,6')).split(',').map((s) => parseInt(s, 10)).filter((n) => n > 0);
const PEARL_TARGET = parseInt(argv('pearls', '12'), 10);
const PEARL_RUNS = parseInt(argv('runs', '3'), 10);
const WINDOW_MS = parseInt(argv('window', '90'), 10) * 1000;
const S = STATION.bastion;
const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));

let pig = null;

/** 从阶段 1/2 的落盘结果里取标定值（holding 索引 / 最佳投掷距离 / 真实周期） */
async function loadPrimitives() {
    pig = await import(moduleUrl('src/agent/tasks/exec/piglin.js'));
    const cal = readJson('runs', 'S2_P1_PROBE', 'p2b_throw_calib.json');
    const b1 = readJson('runs', 'S2_B1', 'b1_p4_trials.json');
    const dist = readJson('runs', 'S2_B1', 'b1_p2_distance.json');
    const cfg = { holdingIdx: cal?.holdingIdx ?? null, pickupDelayMs: null, minDist: 1.4, maxDist: 3.2, cycleMs: null, bestDist: null, healthIdx: cal?.healthIdx ?? null };
    if (cfg.holdingIdx != null) {
        pig.applyCalibration({ holdingIdx: cfg.holdingIdx, healthIdx: 9, babyIdx: 12, evidence: 'S2_P1_PROBE/p2b_throw_calib.json' });
    }
    if (b1?.sum?.pickupDelay?.mean) cfg.pickupDelayMs = Math.round(b1.sum.pickupDelay.mean * 1000) + 400;
    if (b1?.sum?.cycle?.mean) cfg.cycleMs = Math.round(b1.sum.cycle.mean * 1000);   // ⚠ 单位：JSON 里是**秒**
    const best = (dist?.distRows ?? []).filter((r) => r.ok && r.cycleSec != null).sort((a, b2) => a.cycleSec - b2.cycleSec)[0];
    if (best) { cfg.bestDist = best.dist0; cfg.minDist = Math.max(1.2, best.dist0 - 0.8); cfg.maxDist = best.dist0 + 0.8; }
    return { cfg, sources: { cal: !!cal, b1: !!b1, dist: !!dist } };
}
function readJson(...parts) {
    try { return JSON.parse(fs.readFileSync(path.join(BENCH_DIR, ...parts), 'utf8')); } catch { return null; }
}

async function serverCount(sel = '@e[type=piglin]') {
    const r = await truth().countEntities('the_nether', LANE.username, sel, { quietMs: 600, timeoutMs: 20000 });
    return { n: r.n, trusted: r.trusted };
}

/** 补足 N 头猪灵：够用自然的就不造；不够才 summon（如实记 fixture 数） */
async function ensureN(n, minDist, maxDist) {
    const list = Object.values(bot()?.entities ?? {}).filter((e) => e.name === 'piglin' && e.position);
    const usable = list
        .filter((e) => { const d = e.position.distanceTo(botPos()); return d >= minDist - 0.5 && d <= maxDist + 0.5 && pig.hasLos(bot(), e) && pig.isHolding(e) !== true; })
        .map((e) => e.id);
    let fixture = 0;
    const me = botPos();
    const angles = [0, 45, 90, 135, 180, 225, 270, 315, 22, 68, 112, 158];
    for (let i = usable.length; i < n; i++) {
        const a = (angles[i % angles.length] * Math.PI) / 180;
        const d = minDist + ((i % 3) * 0.45);
        const x = me.x + Math.cos(a) * d, z = me.z + Math.sin(a) * d;
        // ⚠ 必须**等实体真的进客户端实体表**再返回：只发命令不等 ⇒ bind() 时一个都看不见
        //   ⇒ 槽全绑不上，N 扫描会整轮 0 投锭（S2_B2 首轮就是这样白跑的）。
        const before = new Set(Object.values(bot()?.entities ?? {}).map((e) => e.id));
        cmd(`execute in minecraft:the_nether run summon minecraft:piglin ${x.toFixed(2)} ${me.y.toFixed(2)} ${z.toFixed(2)}`);
        let ok = false;
        for (let k = 0; k < 50; k++) {
            await sleep(120);
            const fresh = Object.values(bot()?.entities ?? {}).find((e) => e.name === 'piglin' && !before.has(String(e.id))
                && Math.abs(e.position.x - x) < 2.5 && Math.abs(e.position.z - z) < 2.5);
            if (fresh) { ok = true; break; }
        }
        if (!ok) console.log(`[ensureN] 第 ${fixture + 1} 只 fixture 6s 内没进实体表`);
        fixture++;
    }
    await sleep(1200);
    return { natural: Math.min(usable.length, n), fixture, total: n };
}

async function resetTrial(ingots) {
    cmd(`clear ${LANE.username}`);
    cmd('execute in minecraft:the_nether run kill @e[type=item]');
    cmd('execute in minecraft:the_nether run kill @e[type=experience_orb]');
    await sleep(1000);
    cmd(`give ${LANE.username} minecraft:gold_ingot ${ingots}`);
    await sleep(1500);
    return pig.countIngots(bot());
}

function makeEngine(n, cfg, { throwMode = 'feed', groundCount = 1 } = {}) {
    return new pig.BarterEngine(bot(), {
        slots: n,
        minDist: cfg.minDist, maxDist: cfg.maxDist,
        throwMode, groundCount, groundRadius: cfg.groundRadius ?? 9,
        cycleTimeoutMs: Math.max(14000, (cfg.cycleMs ?? 6000) * 2.5),
        collect: true, harvestEveryRounds: 8,
        harvestMaxMs: 20000,            // ★ 派单点名：收尾捡拾墙钟上限
        safeRadius: 4.5, leashRadius: 7, // ★ 捡拾安全圈（不许把 bot 带出接落地板）
    });
}

async function oneSweepRun(n, cfg, { windowMs, throwMode = 'feed', scene = 'open', groundCount = 1 }) {
    const w = watchDeaths();            // ★ 死亡归因（server.log 有死亡消息）
    const inv0 = await resetTrial(160);
    const ground = throwMode === 'ground';
    const prov = await ensureN(n, ground ? 1.5 : cfg.minDist, ground ? (cfg.groundRadius ?? 9) : cfg.maxDist);
    const engine = makeEngine(n, cfg, { throwMode, groundCount });
    const events = [];
    engine.opts.onEvent = (ev) => { if (ev.phase && ev.phase !== 'cycle_done' && ev.phase !== 'cycle_fallback') events.push(ev); };
    const bound = engine.bind();
    const t0 = Date.now();
    const rep = await engine.run({ windowMs });
    const h = await engine.harvest();
    w.stop();
    return {
        n, scene, throwMode, groundCount, windowMs, bound, fixture: prov.fixture, natural: prov.natural,
        rep, harvestGained: h.gained, harvestMs: h.ms, skippedOutside: h.skippedOutside, abortedByLeash: h.abortedByLeash,
        inv0, ingotsLeft: pig.countIngots(bot()), ingotsUsed: inv0 - pig.countIngots(bot()),
            pearlsInInv: pig.countItem(bot(), 'ender_pearl'),
        events: events.slice(0, 80), bindWhy: engine.stats.bindWhy ?? null, wallMs: Date.now() - t0, hp: bot().health, alive: !!bot().entity,
        dim: bot().game?.dimension ?? null, deaths: w.deaths,
    };
}

/** Wilson 区间：锭珠比是小计数比，n 不大时正态近似会给出 <0 的下界 */
function wilson(k, n, z = 1.96) {
    if (!n) return null;
    const p = k / n;
    const d = 1 + (z * z) / n;
    const c = p + (z * z) / (2 * n);
    const s = z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n));
    return { p: +p.toFixed(4), lo: +((c - s) / d).toFixed(4), hi: +((c + s) / d).toFixed(4) };
}

async function main() {
    await openRun(STAMP);
    try {
        const { cfg, sources } = await loadPrimitives();
        console.log(`[cfg] 标定源=${JSON.stringify(sources)} holdingIdx=${cfg.holdingIdx} 距离窗口=${cfg.minDist}~${cfg.maxDist} 兜底周期=${cfg.cycleMs}ms`);

        await bootWorld({ difficulty: 'easy' });
        const t = truth();
        const park = await parkSafe({ cx: S.x, cz: S.z, yLo: S.yLo, yHi: 100, r: 4 });
        await sleep(5000);
        const sc = await t.selfCheck({ dim: 'the_nether', at: park.park, atEntity: LANE.username });
        record('b2_p0_selfcheck', { selfCheck: sc, cfg, sources, park });

        const stand = await standNatural({ cx: S.x, cz: S.z, r: 22, yLo: S.yLo, yHi: S.yHi + 30 });
        const approach = stand ? await approachPiglins({ k: 4, standoff: 2.8, maxMs: 25000 }) : null;
        // ★ 作业位 = **stand 那个地面格**（S2_B2R2 实测：空中平台在 y=72、猪灵在地面 y≈36 ⇒ 用平台 0 槽可绑）
        //   approach 失败**不再**降级：stand 已经真值复核过、且记着最近猪灵距离。
        const work = stand?.stand ?? park.park;
        const mode = stand ? 'natural_ground' : 'fixture';
        const cnt = await serverCount();
        const inv = await kit(['gold_ingot:64', 'golden_helmet:1', 'golden_boots:1', 'iron_sword:1', 'shield:1', 'cooked_porkchop:16']);
        const armor = await pig.ensureGoldArmor(bot());
        record('b2_p1_setup', {
            park, stand, approach, mode, work, cfg, sources, piglins: cnt, kit: inv, armor,
            dim: dim(), botPos: posStr(botPos()), tps: t.clock.tps(),
        });
        console.log(`[setup] 打法=${mode} 猪灵=${JSON.stringify(cnt)} pos=${posStr(botPos())} TPS=${t.clock.tps()}`);

        // ── B2：模式对照矩阵（N=4）────────────────────────────────────
        //   场地：open=开放场（可行性按这个判）｜pen=玻璃围栏（**只测引擎上限**）
        //   投锭：feed=右键喂锭（猪灵要在 3.2 格内）｜ground=丢在它附近让它自己捡
        const MATRIX = (argv('matrix', 'open:feed,open:ground,pen:feed,pen:ground')).split(',')
            .map((s) => { const [scene, mode] = s.split(':'); return { scene, mode: mode || 'feed' }; });
        const sweep = [];
        let pen = null;
        for (const cellCfg of MATRIX) {
            await recallTo(work, { label: cellCfg.scene + '/' + cellCfg.mode });
            if (cellCfg.scene === 'pen' && !pen) { pen = await buildPen({ r: 4, wallH: 2, at: work }); record('b2_p1b_pen', pen); }
            const r = await oneSweepRun(4, cfg, {
                windowMs: WINDOW_MS, throwMode: cellCfg.mode, scene: cellCfg.scene,
                groundCount: cellCfg.mode === 'ground' ? 3 : 1,
            });
            sweep.push(r);
            console.log(`[N=4 ${cellCfg.scene}/${cellCfg.mode}] 槽实到=${r.rep.slotsLive}(自然${r.natural}/fixture${r.fixture}) 投锭=${r.rep.throwsOk}/${r.rep.throws} = ${r.rep.throwsPerMin}/分 周期=${r.rep.cycleAvgMs}ms 珍珠=${r.rep.pearls} 相位=${JSON.stringify(r.rep.phases)}`);
            record(`b2_p2_${cellCfg.scene}_${cellCfg.mode}`, r);
        }
        const curve = sweep.map((r) => ({
            scene: r.scene, mode: r.throwMode, n: 4, slotsLive: r.rep.slotsLive, natural: r.natural, fixture: r.fixture,
            throwsPerMin: r.rep.throwsPerMin, cycleAvgMs: r.rep.cycleAvgMs, pearls: r.rep.pears ?? r.rep.pearls,
            ingotsUsed: r.ingotsUsed, phases: r.rep.phases, deaths: r.deaths ?? null,
        }));
        record('b2_p2_curve', { curve, pen, note: 'open 场是可行性口径；pen 只看引擎上限；两个投锭模式都跑' });

        // ── B4：实测锭/珍珠比 ────────────────────────────────────────
        const totThrows = sweep.reduce((a, r) => a + r.rep.throwsOk, 0);
        const totIngots = sweep.reduce((a, r) => a + r.ingotsUsed, 0);
        const totPearls = sweep.reduce((a, r) => a + r.rep.pearls, 0);
        const b4 = {
            throws: totThrows, ingotsUsed: totIngots, pearls: totPearls,
            pearlsPerIngot: totIngots ? +(totPearls / totIngots).toFixed(4) : null,
            theory: 0.2837,
            ratioVsTheory: totIngots ? +((totPearls / totIngots) / 0.2837).toFixed(3) : null,
            ci95: wilson(totPearls, totIngots),
            note: '理论 0.2837 珍珠/锭（4.73%/锭 × 4-8 颗/次）；低于理论 50% 要查投空/捡漏',
        };
        record('b2_p3_b4', b4);
        console.log('[B4]', JSON.stringify(b4));

        // ── 验收：0 → 12 珍珠，n≥3 ──────────────────────────────────
        // 可行性按**开放场**判（派单），围栏那组只用来读引擎上限
        const openRuns = sweep.filter((r) => r.scene === 'open');
        const ranked = (openRuns.length ? openRuns : sweep).slice().sort((a, b2) => b2.rep.throwsPerMin - a.rep.throwsPerMin);
        const bestCfg = ranked[0] ?? { throwMode: 'feed', scene: 'open' };
        const bestN = 4;
        const perSlot = (openRuns.length ? openRuns : sweep).map((r) => ({ scene: r.scene, mode: r.throwMode, per: +(r.rep.throwsPerMin / Math.max(1, r.n)).toFixed(2) }));
        const pearlRuns = [];
        for (let i = 1; i <= PEARL_RUNS; i++) {
            await recallTo(work, { label: 'pearl' + i });
            const inv0 = await resetTrial(192);
            const prov = await ensureN(bestN, cfg.minDist, cfg.maxDist);
            const engine = makeEngine(bestN, cfg, { throwMode: bestCfg.throwMode, groundCount: bestCfg.throwMode === 'ground' ? 3 : 1 });
            engine.opts.harvestEveryRounds = 4;
            const bound = engine.bind();
            const t0 = Date.now();
            const rep = await engine.run({
                windowMs: 8 * 60 * 1000,
                shouldStop: (e) => (e.stats.pearls >= PEARL_TARGET ? `target_${PEARL_TARGET}` : null),
            });
            const h = await engine.harvest();
            const wallMs = Date.now() - t0;
            const pearls = engine.stats.pearls;
            const row = {
                run: i, N: bestN, bound, fixture: prov.fixture, natural: prov.natural, mode,
                rep, harvestGained: h.gained, wallSec: +(wallMs / 1000).toFixed(1),
                pearls, ingotsUsed: inv0 - pig.countIngots(bot()),
                ingotsPerPearl: pearls ? +((inv0 - pig.countIngots(bot())) / pearls).toFixed(1) : null,
                pearlsInInv: pig.countItem(bot(), 'ender_pearl'),
                invEnd: invCount(), hp: bot().health, alive: !!bot().entity,
            };
            pearlRuns.push(row);
            console.log(`[珍珠局 ${i}] N=${bestN} 达成=${pearls}/${PEARL_TARGET} 用时=${row.wallSec}s 投锭=${rep.throwsOk}(${rep.throwsPerMin}/分) 锭耗=${row.ingotsUsed} 锭/珠=${row.ingotsPerPearl} reason=${rep.reason}`);
            record(`b2_p4_pearls_run${i}`, row);
        }
        const okRuns = pearlRuns.filter((r) => r.pearls >= PEARL_TARGET);
        const n4 = curve.find((c) => c.n === 4);
        const verdict = {
            mode, N: bestN,
            achieved: `${okRuns.length}/${PEARL_RUNS}`,
            wallSec: okRuns.map((r) => r.wallSec),
            wallSecMean: okRuns.length ? +(okRuns.reduce((a, r) => a + r.wallSec, 0) / okRuns.length).toFixed(1) : null,
            ingotsMean: okRuns.length ? +(okRuns.reduce((a, r) => a + r.ingotsUsed, 0) / okRuns.length).toFixed(1) : null,
            perSlotThroughput: perSlot,
            curve, b4,
            gate: {
                n4_throwsPerMin: n4?.throwsPerMin ?? null,
                n4_gate27: (n4?.throwsPerMin ?? 0) >= 27,
                n4_target37: (n4?.throwsPerMin ?? 0) >= 37,
            },
            cfg, sources,
        };
        record('b2_p5_verdict', verdict);
        writeSummary(verdict);
        console.log('[验收]', JSON.stringify(verdict, null, 2));
    } catch (e) {
        console.error('[b2] 失败：', e);
        try { record('error', { message: String(e?.message ?? e), stack: String(e?.stack ?? '').slice(0, 900) }); } catch { /* 忽略 */ }
        try { writeSummary({ failed: String(e?.message ?? e) }); } catch { /* 忽略 */ }
        process.exitCode = 1;
    } finally {
        await closeRun();
    }
}

main();
