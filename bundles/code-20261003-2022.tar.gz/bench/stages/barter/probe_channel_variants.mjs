// probe_channel_variants.mjs — 1.16.1 控制台回执通道的**命令形态穷举 v2**（一次起服，全钉死）
//
// v1 的实测结论（证据 runs/S2_CHAN.log 与 docs/MC-S2-01.md §1）：
//   ① `time query gametime` 回执是 **"The time is N"**（不是 1.17+ 的 "The game time is N"）；
//      ⚠ `gametime` / `day` / `daytime` 三者回执**文本完全一样** ⇒ 同一回执类必须互斥串行。
//   ② **`execute at <x> <y> <z>`（坐标形式）不被支持** → "Incorrect argument for command"。
//      之前我以为根因是 `@s`；v1 里 `execute in … run data get entity @e[…] Pos`（无 at、无 @s）
//      是能解析的（回 "No entity was found"）⇒ 坐标形式的 at 才是被拒的那个。
//      可用的是 `at <实体>`（本项目一直用 `at <用户名>` 替换 `@s`）。
//   ③ `/forceload` **在 1.16.1 存在且可用**（"Marked chunk [0, 0] … to be force loaded" +
//      `forceload query` 能查回来）⇒ C 线"1.16.1 无 /forceload"的结论对这个 jar 不成立，
//      需要复核他们的 3150 条 setblock 静默失败是不是撞在 **单次 256 区块上限**上。
//   ④ `data get entity <玩家> <path>` 可用（`Health` → 20.0f）；不带 path 会打印整份 NBT。
//
// v2 要钉死的：计数通道（`as <多目标> run time query day` 逐实体一行？）、`at <实体>` 版本的数据查询、
//   多目标 `data get` 的行为、forceload 的上限与跨维度、**猪灵整份 NBT 的字段**（标定要用）。
//
// 用法：node probe_channel_variants.mjs [--stamp S2_CHAN2]

import {
    openRun, bootWorld, closeRun, cmd, truth, bot, botPos, posStr, LANE, STATION, SEED, argv,
    record, writeSummary, sleep, parkSafe,
} from './harness.mjs';

const STAMP = argv('stamp', 'S2_CHAN2');
const S = STATION.bastion;

/** 发一条命令，把之后的日志增量全部收走（成功/失败都算证据） */
async function probe(label, command, { waitMs = 2500 } = {}) {
    const t = truth();
    t.pump();
    const before = t.queue.length;
    t.raw(command);
    await sleep(waitMs);
    t.pump();
    const lines = t.queue.splice(before);
    const good = lines.some((l) => /has the following|The time is|Successfully filled|No blocks were filled|Marked chunk|force loaded|queries/i.test(l));
    const verdict = good ? 'OK' : (lines.length ? 'ERR' : 'SILENT');
    console.log(`[${verdict}] ${label}\n        > ${command}`);
    for (const l of lines) console.log(`        | ${l.slice(0, 200)}`);
    return { label, command, verdict, n: lines.length, lines: lines.map((l) => l.slice(0, 220)) };
}

async function main() {
    await openRun(STAMP);
    const out = [];
    try {
        await bootWorld({ difficulty: 'easy' });
        const t = truth();
        // 安全落位（不塞墙里）
        const park = await parkSafe({ cx: S.x, cz: S.z, yLo: S.yLo, yHi: 100, r: 4 });
        record('park', park);
        console.log('[park]', JSON.stringify(park));
        const B = LANE.username;

        // ── ① 计数通道：`as <多目标> run <不引用实体的打印命令>` ─────────
        out.push(await probe('计数：as @e[piglin] run time query day（每头一行）',
            `execute in minecraft:the_nether at ${B} as @e[type=piglin] run time query day`, { waitMs: 9000 }));
        out.push(await probe('计数对照：limit=1（应 1 行）',
            `execute in minecraft:the_nether at ${B} as @e[type=piglin,limit=1] run time query day`, { waitMs: 3000 }));
        out.push(await probe('计数对照：limit=3（应 3 行）',
            `execute in minecraft:the_nether at ${B} as @e[type=piglin,limit=3] run time query day`, { waitMs: 4000 }));
        out.push(await probe('计数对照：limit=0（应 0 行）',
            `execute in minecraft:the_nether at ${B} as @e[type=piglin,limit=0] run time query day`, { waitMs: 3000 }));
        out.push(await probe('计数对照：radius=8（应少于全量）',
            `execute in minecraft:the_nether at ${B} as @e[type=piglin,r=8] run time query day`, { waitMs: 5000 }));

        // ── ② at <实体> 版数据查询 + 多目标 data get 行为 ───────────────
        out.push(await probe('data get at<实体> 选择器 Pos',
            `execute in minecraft:the_nether at ${B} run data get entity @e[type=piglin,limit=1] Pos`));
        out.push(await probe('data get 无 at（选择器落在控制台主世界上下文，应 "No entity was found"）',
            'execute in minecraft:the_nether run data get entity @e[type=piglin,limit=1] Pos'));
        out.push(await probe('data get 多目标 limit=3（1 行？3 行？还是报错）',
            `execute in minecraft:the_nether at ${B} run data get entity @e[type=piglin,limit=3] Pos`, { waitMs: 4000 }));
        out.push(await probe('data get HandItems[0].id（把玩期服务端真值要用）',
            `execute in minecraft:the_nether at ${B} run data get entity @e[type=piglin,limit=1] HandItems[0].id`));
        out.push(await probe('data get 猪灵 Health',
            `execute in minecraft:the_nether at ${B} run data get entity @e[type=piglin,limit=1] Health`));
        out.push(await probe('data get 猪灵整份 NBT（标定要看有哪些字段）',
            `execute in minecraft:the_nether at ${B} run data get entity @e[type=piglin,limit=1]`, { waitMs: 4000 }));
        out.push(await probe('阴性对照：at <坐标> 形式（应 ERR）',
            `execute in minecraft:the_nether at ${S.x} ${S.y} ${S.z} run data get entity @e[type=piglin,limit=1] Pos`));
        out.push(await probe('阴性对照：@s 形式（应 ERR）',
            `execute in minecraft:the_nether at ${B} as @e[type=piglin,limit=1] run data get entity @s Pos`));

        // ── ③ forceload：存在性、跨维度、上限 ─────────────────────────
        out.push(await probe('forceload add 下界 0 0 1 1', 'execute in minecraft:the_nether run forceload add 0 0 1 1'));
        out.push(await probe('forceload query 下界（能查回吗）', 'execute in minecraft:the_nether run forceload query'));
        out.push(await probe('forceload remove 下界', 'execute in minecraft:the_nether run forceload remove 0 0 1 1'));
        out.push(await probe('forceload add 大范围（试 256 区块上限：-256..256 共 34×34=1156）',
            'execute in minecraft:the_nether run forceload add -256 -256 256 256', { waitMs: 4000 }));
        out.push(await probe('forceload query（大范围后）', 'execute in minecraft:the_nether run forceload query', { waitMs: 3000 }));
        out.push(await probe('forceload remove 全部', 'execute in minecraft:the_nether run forceload remove all'));

        // ── ④ fill 回执回归 + data get block（B5 靠它）───────────────
        // ⚠ v1 的教训：裸写 `execute in <dim> <cmd>` **漏了 run 关键字** ⇒ 一律回
        //    "Incorrect argument"，看起来像"版本不支持"，其实是我自己的错。
        //    凡是 execute 链，run 必须有（truth.mjs 的 dimPre() 已经带了 run）。
        out.push(await probe('fill 单格 air→command_block（execute in + run + 坐标）',
            `execute in minecraft:the_nether run fill ${park.park[0]} ${park.park[1]} ${park.park[2]} ${park.park[0]} ${park.park[1]} ${park.park[2]} minecraft:command_block replace minecraft:air`));
        out.push(await probe('data get block command_block（布的探针格，B5 同款）',
            `execute in minecraft:the_nether run data get block ${park.park[0]} ${park.park[1]} ${park.park[2]} Items`));
        out.push(await probe('data get block 普通方块（阴性对照：非 block entity）',
            `execute in minecraft:the_nether run data get block ${park.park[0]} ${park.park[1] - 1} ${park.park[2]} Items`));
        out.push(await probe('漏 run 的写法（阴性对照，确认会报错——别再犯）',
            `execute in minecraft:the_nether data get block ${park.park[0]} ${park.park[1]} ${park.park[2]} Items`));
        out.push(await probe('at <坐标> 单独用（不带 in）：at 288 55 240 run time query day',
            `execute at ${S.x} ${S.y} ${S.z} run time query day`));
        out.push(await probe('at <实体> 单独用（不带 in）：at BarterBotC run time query day',
            `execute at ${B} run time query day`));
        out.push(await probe('at <坐标> + in + run data get（v1 里 ERR 的那条，原样复现）',
            `execute in minecraft:the_nether at ${S.x} ${S.y} ${S.z} run data get entity @e[type=piglin,limit=1] Pos`));
        out.push(await probe('fill 复原',
            `execute in minecraft:the_nether run fill ${park.park[0]} ${park.park[1]} ${park.park[2]} ${park.park[0]} ${park.park[1]} ${park.park[2]} minecraft:air replace minecraft:command_block`));

        // ── ⑤ 客户端侧对照：bot 现在看得见几头猪灵、metadata 有哪些索引 ──
        const pigs = Object.values(bot()?.entities ?? {}).filter((e) => e.name === 'piglin');
        const metaIdx = [...new Set(pigs.flatMap((e) => Object.keys(e.metadata ?? {}).map(Number)))].sort((a, b2) => a - b2);
        const client = {
            dim: bot()?.game?.dimension, pos: posStr(botPos()), hp: bot()?.health,
            piglins: pigs.length,
            nearest: pigs.map((e) => +e.position.distanceTo(botPos()).toFixed(2)).sort((a, b2) => a - b2).slice(0, 8),
            metaIdx,
            oneMeta: pigs[0] ? JSON.stringify(pigs[0].metadata).slice(0, 600) : null,
        };
        record('client_view', client);
        console.log('[client]', JSON.stringify(client, null, 2));

        // ── ⑥ 定向对照：1.16.1 的 `/data get entity` 到底哪些 target 形态可用 ──
        //   背景：`data get entity <选择器> <路径>` 与 `… as <选择器> run data get entity @s <路径>`
        //   **全都**回 "Incorrect argument for command"（S2_B1 三轮、每次 100% 无回执）。
        //   而 `data get entity <玩家名> Health` 可用（v2 拿到过 20.0f）。
        //   ⇒ 要分清是「选择器 target 不行」还是「HandItems 这个路径本身在 1.16.1 不合法」。
        const B2 = LANE.username;
        out.push(await probe('对照A：玩家名 + 路径（已知可用形态）', `execute in minecraft:the_nether run data get entity ${B2} Health`));
        out.push(await probe('对照B：玩家名 + HandItems 路径（玩家也该有这个字段）', `execute in minecraft:the_nether run data get entity ${B2} HandItems`));
        out.push(await probe('对照C：选择器 + 无路径（打整份 NBT）', `execute in minecraft:the_nether at ${B2} run data get entity @e[type=item,limit=1]`));
        out.push(await probe('对照D：as + @s + 无路径', `execute in minecraft:the_nether at ${B2} as @e[type=item,limit=1] run data get entity @s`));
        out.push(await probe('对照E：as + @s + 路径（第二轮再试一次）', `execute in minecraft:the_nether at ${B2} as @e[type=item,limit=1] run data get entity @s Age`));
        out.push(await probe('对照F：选择器 + 路径（复现失败）', `execute in minecraft:the_nether at ${B2} run data get entity @e[type=item,limit=1] Age`));
        out.push(await probe('对照G：tp 取证（把物品实体瞬移一下看它存不存在，破坏性但可回收）', `execute in minecraft:the_nether at ${B2} run tp @e[type=item,limit=1] ~ ~1 ~`, { waitMs: 3000 }));
        out.push(await probe('对照H：kill 计数（最皮实的实体计数形态）', `execute in minecraft:the_nether run kill @e[type=item]`, { waitMs: 3000 }));

        record('channel_variants_v2', { park, probes: out, client });
        writeSummary({ probes: out.map((o) => ({ label: o.label, verdict: o.verdict, n: o.n })), client });
    } catch (e) {
        console.error('[chan2] 失败：', e);
        try { record('error', { message: String(e?.message ?? e), stack: String(e?.stack ?? '').slice(0, 700) }); } catch { /* 忽略 */ }
        try { writeSummary({ failed: String(e?.message ?? e) }); } catch { /* 忽略 */ }
        process.exitCode = 1;
    } finally {
        await closeRun();
    }
}

main();
