// S2-04：主 agent **亲自复核** 子 agent 报的候选作业点。
// 目的：独立验证 (331,57,238) 的「3.4 格内 5 头猪灵」与站立面，
//   并与上一轮用的 (319,68,242) 做同口径对照。
// 用法：node verify_standoff.mjs <worldDir>
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld, bare } from '../../../../route/tools/region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const worldDir = process.argv[2] ?? 'D:/AI斗蛐蛐/bench/route/probe/_world_A';
const D = 'the_nether';

const w = openWorld(worldDir);
console.log(`[reader] ${worldDir} stats=${JSON.stringify(w.stats)}`);

const CANDIDATES = [
    // ★ S2-04：C 线猪灵图（`route/probe/s3_bastion_gold_piglins.peaceful.json`，10:14 出）首推点。
    //   它的口径：`stand=[x,y,z]`，距离从 **(x+0.5, y, z+0.5)** 量（格心），
    //   本脚本从格心量 ⇒ **同一口径**，可直接比。
    { id: 'cline-1', pos: { x: 328, y: 57, z: 240 } },
    { id: 'cline-2', pos: { x: 326, y: 73, z: 265 } },
    { id: 'cline-3', pos: { x: 326, y: 80, z: 251 } },
    { id: 'mine-new', pos: { x: 331, y: 57, z: 238 } },   // 我自己从存档扫出来的
    { id: 'old', pos: { x: 319, y: 68, z: 242 } },        // S2-03 用的作业位（对照）
];

// S3 scout 金源坐标（bastion.round4c.json）
const S3 = JSON.parse((await import('fs')).readFileSync(
    path.resolve(HERE, '..', '..', '..', '..', 'route', 'probe', 'bastion.round4c.json'), 'utf8'));
const gold = S3.goldBlockPoints ?? [];
const chest = S3.chestPoints ?? [];
// ⚠ 实体 `pos` 是**数组** `[x,y,z]`（不是 {x,y,z}）—— 两种形态都收，
//   否则距离会算成 NaN 并被 `+NaN.toFixed(2)` 变成 `null`，**看起来像"没有距离"**。
const xyz = (p) => (Array.isArray(p) ? { x: p[0], y: p[1], z: p[2] } : p);
const d3 = (a, b) => { const A = xyz(a), B = xyz(b); return Math.hypot(A.x - B.x, A.y - B.y, A.z - B.z); };
const d3h = (a, b) => { const A = xyz(a), B = xyz(b); return Math.hypot(A.x - B.x, A.z - B.z); };   // 水平距离（作业位关心脚下平面）

// ⚠ **阳性对照必须先证伪工具**：确认这一带区块真的保存过（不是"没生成"读成"没有猪灵"）
const chunks = [];
for (let cx = 18; cx <= 22; cx++) for (let cz = 13; cz <= 17; cz++) {
    const c = w.chunkInfo?.(cx, cz, D);
    chunks.push({ cx, cz, info: c ?? null });
}
const savedChunks = chunks.filter((c) => c.info && (c.info.entities > 0 || c.info.sections > 0));
console.log(`[阳性对照] 采样 ${chunks.length} 个 chunk，其中已保存(sections>0)的 ${savedChunks.length} 个`);
console.log(`  ⇒ ${savedChunks.length > 0 ? '该区域确实生成并保存过，"读到 0 头"不能当成"没生成"' : '⚠ 该区域未保存，计数不可信'}`);

const out = [];
for (const cand of CANDIDATES) {
    const { x, y, z } = cand.pos;
    // ★ **格心口径**（与 C 线一致）：猪灵距离从 **(x+0.5, y, z+0.5)** 量。
    //   C 线 `criteria.piglinNear34` 写明"站位中心 (x+0.5, y, z+0.5) 到猪灵 Pos 的 3D 距离"；
    //   不同口径差半格 ⇒ 两边的"3.4 格内几头"**不能直接比**。
    const c = { x: x + 0.5, y, z: z + 0.5 };
    // ★ 站立面判据对齐 C 线 `criteria.standable`：脚下实心（非空气集）+ **身体 2 格空气**
    const below = w.blockAt(x, y - 1, z, D);
    const at = w.blockAt(x, y, z, D);
    const above = w.blockAt(x, y + 1, z, D);
    const AIR = new Set(['air', 'cave_air', 'void_air']);
    const SOLID = (b) => b != null && !AIR.has(b);
    // 猪灵：存档实体，球形 3D 距离，从格心量
    const near = (r) => w.entitiesNear(c.x, c.y, c.z, r, ['piglin'], D);
    const p34 = near(3.4), p6 = near(6), p12 = near(12);
    const hoglins = w.entitiesNear(c.x, c.y, c.z, 16, ['hoglin'], D);
    const nearGold = gold.reduce((a, g) => (d3(g, c) < d3(a, c) ? g : a));
    const row = {
        id: cand.id, pos: cand.pos,
        footing: { below, at, above, standable: SOLID(below) && AIR.has(at) && AIR.has(above) },
        piglins: { r3_4: p34.length, r6: p6.length, r12: p12.length,
            // ⚠ `e.pos` 是**数组** `[x,y,z]`（不是 Vec3）⇒ 没有 `distanceTo`
            dist3_4: p34.map((e) => +d3(e.pos, c).toFixed(2)).sort((a, b) => a - b) },
        hoglinsWithin16: hoglins.map((e) => ({ pos: e.pos, dist: +d3(e.pos, c).toFixed(2) })),
        nearestGold: { dist: +d3(nearGold, c).toFixed(2), at: nearGold },
        nearestChest: +Math.min(...chest.map((g) => d3(g, c))).toFixed(2),
    };
    out.push(row);
    console.log(`\n[${cand.id}] (${x},${y},${z})  ← 格心口径 (${c.x},${c.y},${c.z})`);
    console.log(`  脚下=${below} 本格=${at} 头顶=${above} 可站=${row.footing.standable}`);
    console.log(`  猪灵 3.4格内=${p34.length} 6格内=${p6.length} 12格内=${p12.length}  距离=${JSON.stringify(row.piglins.dist3_4)}`);
    console.log(`  最近金块 ${row.nearestGold.dist} 格 @(${row.nearestGold.at.x},${row.nearestGold.at.y},${row.nearestGold.at.z})`);
    console.log(`  最近宝箱 ${row.nearestChest} 格`);
    if (row.hoglinsWithin16.length) console.log(`  ⚠ hoglin：${JSON.stringify(row.hoglinsWithin16)}`);}
console.log(`\n[stats] ${JSON.stringify(w.stats)}`);
