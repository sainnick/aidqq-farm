#!/usr/bin/env node
// recompute_baseline.mjs — MC-S2-01 头条数字的**离线重算子**（开发线 F · S2 易物）
//
// 用途：从 bench/stages/barter/runs/ 下**已经落盘**的 JSON / jsonl / server.log 重新算一遍
//       MC-S2-01.md 里的头条数字，确认口径，并给下一轮留一个可对比的基准。
//
// 纪律（本脚本自带，不是注释摆设）：
//   · **零外部依赖**：只用 node 内置 fs / path。
//   · **不连任何东西**：只 readSync 落盘文件，不起服、不起进程、不占端口。
//   · **容错**：任何 run 目录 / 字段缺失都跳过并记进 `missing`，**绝不抛异常崩掉**。
//   · **不编数**：数据里读不到的量一律 null + 一句原因。
//
// 用法：
//   node recompute_baseline.mjs            # 人读摘要（stdout）
//   node recompute_baseline.mjs --json     # 机器可读结果（stdout）
//   node recompute_baseline.mjs --no-write # 不写 baseline_recompute.json
//   node recompute_baseline.mjs --root <bench/stages/barter 目录>

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argvRaw = process.argv.slice(2);
const hasFlag = (f) => argvRaw.includes(f);
const argvVal = (k, dft) => {
    const i = argvRaw.indexOf(k);
    return i >= 0 && argvRaw[i + 1] != null && !argvRaw[i + 1].startsWith('--') ? argvRaw[i + 1] : dft;
};

const ROOT = path.resolve(argvVal('--root', path.join(HERE, '..')));
const RUNS = path.join(ROOT, 'runs');
const OUT_JSON = path.join(HERE, 'baseline_recompute.json');

/** 固定的三个吞吐局 + B1 + P1 探针 */
const RUN_DIRS = ['S2_B1', 'S2_B2', 'S2_B2R3', 'S2_DIAG'];
const EXTRA_DIRS = ['S2_B2R2', 'S2_P1_PROBE'];

/** 全局 missing 账本：任何"要不到的东西"都往这里记一条 */
const missing = [];
const noteMissing = (where, what, why) => missing.push({ where, what, why });

// ───────────────────────────── 基础工具 ─────────────────────────────

function readJson(rel) {
    // rel 形如 'S2_B1/b1_p4_trials.json'
    const p = path.join(RUNS, rel);
    try {
        if (!fs.existsSync(p)) { noteMissing(rel, '文件', '路径不存在'); return null; }
        return JSON.parse(fs.readFileSync(p, 'utf8'));
    } catch (e) {
        noteMissing(rel, '文件', 'JSON 解析失败：' + String(e.message).slice(0, 120));
        return null;
    }
}

function readText(rel) {
    const p = path.join(RUNS, rel);
    try {
        if (!fs.existsSync(p)) { noteMissing(rel, '文件', '路径不存在'); return null; }
        return fs.readFileSync(p, 'utf8');
    } catch (e) { noteMissing(rel, '文件', String(e.message).slice(0, 120)); return null; }
}

/** 逐行读 jsonl，每行独立 try —— 坏行不拖垮整体 */
function readJsonl(rel) {
    const txt = readText(rel);
    if (txt == null) return [];
    const out = [];
    let bad = 0;
    for (const line of txt.split(/\r?\n/)) {
        const s = line.trim();
        if (!s) continue;
        try { out.push(JSON.parse(s)); } catch { bad++; }
    }
    if (bad) noteMissing(rel, 'jsonl 行', `${bad} 行解析失败，已跳过`);
    return out;
}

/**
 * 分位数：**刻意复刻 probe_b1_fiddle.mjs:234-238 的 pct()**（排序后取
 * index = clamp(round(p/100*(n-1)))，保留 2 位），这样重算出来的数
 * 可以和落盘 summary.json 里的同名字段逐位对照，而不是换一套算法制造假差异。
 */
function pct(arr, p) {
    const a = arr.filter((x) => typeof x === 'number' && Number.isFinite(x)).slice().sort((x, y) => x - y);
    if (!a.length) return null;
    const i = Math.min(a.length - 1, Math.max(0, Math.round((p / 100) * (a.length - 1))));
    return +a[i].toFixed(2);
}
const mean = (arr) => {
    const a = arr.filter((x) => typeof x === 'number' && Number.isFinite(x));
    return a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(3) : null;
};
const r2 = (x) => (x == null ? null : +x.toFixed(2));
const num = (x) => (typeof x === 'number' && Number.isFinite(x) ? x : null);
const pctStr = (x) => (x == null ? 'null' : (x * 100).toFixed(0) + '%');

// ───────────────────────── 1. 把玩周期 / 捡起延迟 / 纯把玩 ─────────────────────────
//
// 口径来源：probe_b1_fiddle.mjs:106-232 `measureThrow()`
//   tThrow = Date.now()            ← 出手时刻（**throwIngot() 借记成立返回之后**，不含瞄准耗时）
//   tIngot = 投出的金锭**物品实体**首次出现在客户端实体表（probe_b1_fiddle.mjs:162-164）
//   tPickup= 那个物品实体从 bot.entities 消失（= 猪灵捡起）（:177）
//   tDrop  = 一个**新的**掉落物实体出现（≠ ingotId）（:166-173）
//   tInvGain = 背包签名变化（礼物落在 bot 拾取半径内、服务器同 tick 收走，客户端看不到实体）（:153,179）
//   cycleSec = (tDeal − tThrow)/1000，tDeal = tDrop ?? tInvGain   ← :207-208
//   pickupDelaySec = tPickup − tIngot                            ← :216
// 原始字段：runs/S2_B1/b1_p4_trials.json → trials[].{cycleSec,pickupDelaySec,dealBy,dist0,tps,ok,phase}
//   （b1_p3_trials.json 是更早一轮、20/20 全 no_los、cycle n=0，见 §4）

function cycleSection() {
    const src = 'S2_B1/b1_p4_trials.json#trials[]';
    const j = readJson('S2_B1/b1_p4_trials.json');
    if (!j || !Array.isArray(j.trials)) { noteMissing(src, 'trials[]', '文件或数组缺失'); return null; }
    const trials = j.trials;

    const okRows = trials.filter((t) => t.ok === true);
    const cycAll = okRows.map((t) => num(t.cycleSec)).filter((x) => x != null);
    const byDeal = (k) => okRows.filter((t) => t.dealBy === k).map((t) => num(t.cycleSec)).filter((x) => x != null);
    const cycDrop = byDeal('drop_entity');
    const cycInv = byDeal('inv_delta');

    // 捡起延迟：**两套 n** —— 落盘 summary 只在"有周期的行"里取（n=7），
    // 全部有读数的行是 12（还包括 5 条 dealBy=none 的行）。
    const pickAll = okRows.map((t) => num(t.pickupDelaySec)).filter((x) => x != null);
    const good = okRows.filter((t) => num(t.cycleSec) != null);   // == 源码的 good
    const pickGood = good.map((t) => num(t.pickupDelaySec)).filter((x) => x != null);

    // 纯把玩 = 周期 − 捡起延迟。三种算法，口径完全不同，全部列出：
    const mAll = mean(cycAll), mInv = mean(cycInv), mDrop = mean(cycDrop);
    const pAll = mean(pickAll), pGood = mean(pickGood);
    // 逐样本配对（同一行既有 cycleSec 又有 pickupDelaySec）
    const paired = okRows
        .filter((t) => num(t.cycleSec) != null && num(t.pickupDelaySec) != null)
        .map((t) => +(num(t.cycleSec) - num(t.pickupDelaySec)).toFixed(3));
    const pairedDealBy = [...new Set(okRows
        .filter((t) => num(t.cycleSec) != null && num(t.pickupDelaySec) != null)
        .map((t) => t.dealBy))];

    const tps = num(trials.find((t) => t.tps === 20)?.tps) ?? num(j.sum?.tps) ?? 20;
    const tpsNote = 'TPS 取 trials[].tps（同一批里混着 20 与 0.09，后者是通道互抢的坏读数，见 b1_p3）';
    const tick = (sec) => (sec == null ? null : Math.round(sec * tps));

    const perSample = okRows.map((t, i) => ({
        tag: t.tag ?? null, ok: t.ok ?? null, phase: t.phase ?? null,
        source: t.source ?? null, dist0: num(t.dist0), dealBy: t.dealBy ?? null,
        cycleSec: num(t.cycleSec),
        cycleSec_ticks: t.cycleSec == null ? null : tick(num(t.cycleSec)),
        pickupDelaySec: r2(num(t.pickupDelaySec)),
        drop_name: t.drop?.name ?? null, drop_count: t.drop?.count ?? null,
        drop_dFromPiglin: num(t.drop?.dFromPiglin), drop_dFromBot: num(t.drop?.dFromBot),
        ingots0: num(t.ingots0), ingots1: num(t.ingots1), ingotsEnd: num(t.ingotsEnd),
        debited: num(t.ingots0) != null && num(t.ingots1) != null ? num(t.ingots0) - num(t.ingots1) : null,
        tps: num(t.tps),
    }));

    return {
        source: src,
        formula: {
            cycleSec: '(tDeal − tThrow)/1000，tDeal = tDrop ?? tInvGain（probe_b1_fiddle.mjs:204-208）',
            tThrow: 'throwIngot() 借记成立**返回之后**的 Date.now()（:140）——不含瞄准耗时',
            tDrop: '新掉落物实体首次出现在客户端实体表（:166-173）',
            tInvGain: '背包签名 JSON 变化（:153,179）——礼物被 bot 瞬收时只有这条路',
            pickupDelaySec: 'tPickup − tIngot（:216）；tIngot=投出金锭实体出现，tPickup=该实体从 bot.entities 消失（:162,177）',
            fiddle: '周期 − 捡起延迟（probe_b1_fiddle.mjs:340-345）',
            percentiles: '排序后取 index=clamp(round(p/100*(n-1)))（复刻 :234-238，与落盘 summary 同算法）',
        },
        unitCaveat: tpsNote,
        tps,
        nTrials: trials.length,
        nThrowOk: okRows.length,
        nWithCycle: cycAll.length,
        nFail: trials.length - okRows.length,
        okNotCycle: okRows.filter((t) => num(t.cycleSec) == null).map((t) => ({ tag: t.tag, dist0: num(t.dist0), dealBy: t.dealBy ?? null })),
        failPhases: trials.filter((t) => t.ok !== true).map((t) => ({ tag: t.tag, phase: t.phase, dist0: num(t.dist0) })),
        nNatural: trials.filter((t) => t.source === 'natural').length,
        nFixture: trials.filter((t) => t.source === 'fixture').length,
        cycle_all: stats(cycAll, tps),
        cycle_dropEntity_only: stats(cycDrop, tps),
        cycle_invDelta_only: stats(cycInv, tps),
        pickupDelay: {
            n_allRows: pickAll.length, mean_allRows: r2(pAll), p10: pct(pickAll, 10), p50: pct(pickAll, 50), p90: pct(pickAll, 90),
            n_rowsWithCycle: pickGood.length, mean_rowsWithCycle: r2(pGood),
            note: '落盘 summary.pickupDelay.n=7 用的是"有周期的行"；这里另外给出全部有读数的行（n=12）',
        },
        fiddle: {
            '落盘口径_mean(cyc_all)-mean(pick_good)': r2(mAll != null && pGood != null ? mAll - pGood : null),
            'drop_entity口径_mean(cyc_drop)-mean(pick)': r2(mDrop != null && pAll != null ? mDrop - pAll : null),
            '逐样本配对(cycle-pickup)': { n: paired.length, dealBy: pairedDealBy, mean: r2(mean(paired)), p10: pct(paired, 10), p50: pct(paired, 50), p90: pct(paired, 90) },
            ticks: {
                落盘口径: tick(mAll != null && pGood != null ? mAll - pGood : null),
                drop_entity口径: tick(mDrop != null && pAll != null ? mDrop - pAll : null),
                逐样本配对: tick(mean(paired)),
            },
            warning: '只有 dealBy=inv_delta 的行同时有 cycleSec 与 pickupDelaySec ⇒「配对」那 7 条的周期本身就含捡起延迟，'
                + '再减一次等于重复扣。三种口径互不相等，不能混用。',
        },
        drops: {
            names: trials.reduce((a, t) => { if (t.drop) { const k = t.drop.name ?? 'null'; a[k] = (a[k] ?? 0) + 1; } return a; }, {}),
            counts: trials.filter((t) => t.drop).map((t) => t.drop.count),
            dFromPiglin: trials.filter((t) => num(t.drop?.dFromPiglin) != null).map((t) => num(t.drop.dFromPiglin)),
            dFromBot: trials.filter((t) => num(t.drop?.dFromBot) != null).map((t) => num(t.drop.dFromBot)),
        },
        debit: {
            nThrowOk: okRows.length,
            allDebitedOne_overThrowOk: okRows.filter((t) => num(t.ingots0) - num(t.ingots1) === 1).length,
            allDebitedOne_overRowsWithCycle: cycAll.length,
            botPickedOwnThrow: okRows.filter((t) => t.botPickedOwnThrow === true).length,
            note: '借记口径的分母有两条：全部出手成功行（本批 19）与"有周期可测"的行（落盘 summary 用的 14）。'
                + 'MC-S2-01.md §4.1 写的 14/14 用的是后者。',
        },
        perSample,
    };
}
function stats(arr, tps) {
    return {
        n: arr.length, mean: r2(mean(arr)), p10: pct(arr, 10), p50: pct(arr, 50), p90: pct(arr, 90),
        min: arr.length ? +Math.min(...arr).toFixed(2) : null,
        max: arr.length ? +Math.max(...arr).toFixed(2) : null,
        mean_ticks: arr.length ? Math.round(mean(arr) * tps) : null,
    };
}

// ───────────────────────── 2. N=4 吞吐拆解 ─────────────────────────

/** 一格（一个 scene/mode 组合）的所有可算量 */
function cellStats(rel, j) {
    if (!j) { noteMissing(rel, '整格', '文件缺失或解析失败'); return null; }
    const rep = j.rep ?? null;
    const windowMs = num(rep?.windowMs) ?? num(j.windowMs);
    const windowMin = windowMs == null ? null : +(windowMs / 60000).toFixed(4);
    const throws = num(rep?.throws);
    const throwsOk = num(rep?.throwsOk);
    const throwsFail = num(rep?.throwsFail);
    const perMinReported = num(rep?.throwsPerMin);
    const perMinRecomputed = throwsOk != null && windowMin ? +(throwsOk / windowMin).toFixed(3) : null;

    // phases 逐项计数（字段以落盘为准）
    const phases = rep?.phases ?? null;
    // events[] 里的 phase 名（phases 之外的另一条证据线）
    const evPhases = (j.events ?? []).reduce((a, e) => { if (e?.phase) a[e.phase] = (a[e.phase] ?? 0) + 1; return a; }, {});

    return {
        file: rel,
        at: j.at ?? null,
        n_requested: num(rep?.slotsRequested) ?? num(j.n),
        scene: j.scene ?? null,
        throwMode: j.throwMode ?? null,
        groundCount: num(j.groundCount),
        windowMs, windowMin,
        bound: num(j.bound),
        natural: num(j.natural), fixture: num(j.fixture),
        slotsLive_atEnd: num(rep?.slotsLive),
        throws, throwsOk, throwsFail,
        throwFailRate: throws ? r2(throwsFail / throws) : null,
        throwsPerMin_reported: perMinReported,
        throwsPerMin_recomputed: perMinRecomputed,
        cyclesN: num(rep?.cyclesN), misses: num(rep?.misses),
        cycleAvgMs: num(rep?.cycleAvgMs), cycleMinMs: num(rep?.cycleMinMs), cycleMaxMs: num(rep?.cycleMaxMs),
        blacklisted: num(rep?.blacklisted),
        pearls: num(rep?.pearls),
        drops: rep?.drops ?? null,
        phases, eventPhaseCounts: evPhases, nEvents: (j.events ?? []).length,
        inv0: num(j.inv0), ingotsLeft: num(j.ingotsLeft), ingotsUsed: num(j.ingotsUsed),
        pearlsInInv: num(j.pearlsInInv),
        hp: num(j.hp), alive: j.alive ?? null, dim: j.dim ?? null,
        deaths: j.deaths ?? null,
        reason: rep?.reason ?? null,
        bindWhy: j.bindWhy ?? null,
    };
}

function throughputSection(cycleRefSec) {
    const out = { cycleRefSec, runs: {}, decomposition: {} };

    // ---- S2_B2（首轮 N 扫描）----
    {
        const cells = {};
        for (const f of ['b2_p2_n1.json', 'b2_p2_n2.json', 'b2_p2_n4.json', 'b2_p4_pearls_run1.json']) {
            const c = cellStats('S2_B2/' + f, readJson('S2_B2/' + f));
            if (c) cells[f.replace(/\.json$/, '')] = c;
        }
        out.runs.S2_B2 = { note: '首轮 N 扫描（b2_p2_n{1,2,4}）+ 珍珠局 1', cells };
    }
    // ---- S2_B2R3（第二轮 2×2 矩阵）----
    {
        const cells = {};
        for (const f of ['b2_p2_open_feed.json', 'b2_p2_open_ground.json', 'b2_p2_pen_feed.json', 'b2_p2_pen_ground.json']) {
            const c = cellStats('S2_B2R3/' + f, readJson('S2_B2R3/' + f));
            if (c) cells[f.replace(/\.json$/, '')] = c;
        }
        const setup = readJson('S2_B2R3/b2_p1_setup.json');
        out.runs.S2_B2R3 = {
            note: '第二轮：作业位改地面格 / 投锭模式对照 / 玻璃围栏 / 收尾 20s 上限',
            cells,
            cfgFromB1: setup?.cfg ?? null,
            stand: setup?.stand ?? null,
            approach: setup?.approach ?? null,
            pen: readJson('S2_B2R3/b2_p1b_pen.json') ?? null,
        };
    }
    // ---- S2_DIAG（诊断短跑，45s）----
    {
        const c = cellStats('S2_DIAG/b2_p2_open_feed.json', readJson('S2_DIAG/b2_p2_open_feed.json'));
        const setup = readJson('S2_DIAG/b2_p1_setup.json');
        out.runs.S2_DIAG = {
            note: '诊断短跑（open/feed 45s）——报告里 1.33 次/分 就是这一格',
            cells: c ? { b2_p2_open_feed: c } : {},
            cfgFromB1: setup?.cfg ?? null,
            stand: setup?.stand ?? null,
            verdictGate: readJson('S2_DIAG/b2_p5_verdict.json')?.gate ?? null,
        };
    }

    // ---- 定量拆解：把损失摊到"绑定 / 周期 / 投掷失败"三个因子上 ----
    // 公式（全用落盘字段，不引入假设）：
    //   请求槽分钟   = slotsRequested × windowMin
    //   绑定槽分钟   = bound × windowMin                     （bound = bind() 那一刻的绑定数）
    //   理论投锭数   = 绑定槽分钟 ÷ cycleRefSec              （cycleRefSec = B1 drop_entity 周期均值）
    //   绑定损失%    = 1 − bound/slotsRequested
    //   节拍可达数   = 理论投锭数
    //   实际成交数   = throwsOk
    //   周期/存活损失= 1 − throwsOk/理论投锭数
    //   投掷失败率   = throwsFail/throws
    // ⚠ 占空比（每槽绑定分钟数）**不可还原**：events[] 里没有时间戳，详见下方 unknown 段。
    const decomp = [];
    for (const [runId, r] of Object.entries(out.runs)) {
        for (const [cellId, c] of Object.entries(r.cells)) {
            if (!c || c.n_requested == null || c.windowMin == null) continue;
            const reqSlotsMin = +(c.n_requested * c.windowMin).toFixed(3);
            const boundSlotsMin = c.bound == null ? null : +(c.bound * c.windowMin).toFixed(3);
            const theoryThrows = boundSlotsMin != null && cycleRefSec ? +(boundSlotsMin / cycleRefSec).toFixed(2) : null;
            // 三个损失是**串行闸门**（先有槽 → 槽里在成交 → 出手不失败），不是可相加的份额。
            const Lbind = c.bound == null ? null : r2(1 - c.bound / c.n_requested);
            const over = theoryThrows ? c.throwsOk > theoryThrows : false;
            const Lidle = (!theoryThrows || over) ? null : r2(Math.max(0, 1 - Math.min(1, c.throwsOk / theoryThrows)));
            const Lthrow = c.throwFailRate;
            const util = boundSlotsMin && c.throwsOk ? +((c.throwsOk * cycleRefSec) / (boundSlotsMin * 60)).toFixed(3) : null;
            let expl;
            if (!theoryThrows) expl = 'bound=0 ⇒ 一个槽都没绑上，理论投锭数 0；本格的损失 100% 在"绑定"，与周期、投掷都无关';
            else if (over && c.cyclesN === 0) expl = `成交 ${c.throwsOk} 次 ≥ 理论 ${theoryThrows} 次，但 cycle_done=0 ⇒ 样本 n=${c.throwsOk} 太小、比值不可解释；这一格只能读"零次 cycle_done"`;
            else if (over) {
                const inBand = c.cycleAvgMs != null && cycleRefSec && Math.abs(c.cycleAvgMs / 1000 - cycleRefSec) / cycleRefSec <= 0.2;
                expl = `节拍不是瓶颈：${c.throwsOk} 次成交只用掉 ${(util * 100).toFixed(0)}% 的槽时（理论节拍可达 ${theoryThrows} 次）`
                    + (inBand
                        ? `，而 engine 自报周期 ${c.cycleAvgMs}ms 与 B1 实测同量级 ⇒ **绑上的槽在 ${(100 - util * 100).toFixed(0)}% 的绑定时间里是死的**（猪灵走出投掷窗后没补人）`
                        : `；engine 自报周期 ${c.cycleAvgMs}ms 与 B1 实测 ${Math.round(cycleRefSec * 1000)}ms 差 >20% ⇒ 这一格的"成交"根本不是一次把玩周期`);
            }
            else expl = `周期/存活损失 ${(Lidle * 100).toFixed(1)}%（槽时空转 ${(100 - util * 100).toFixed(1)}%）`;
            decomp.push({
                run: runId, cell: cellId, scene: c.scene, mode: c.throwMode,
                windowMin: c.windowMin, slotsRequested: c.n_requested, bound: c.bound,
                boundSlotsMin, cycleRefSec, theoryThrows,
                actualThrowsOk: c.throwsOk,
                loss_bind_pct: Lbind,
                loss_idle_pct: Lidle,
                loss_throw_pct: Lthrow,
                actual_over_theory: theoryThrows ? +(c.throwsOk / theoryThrows).toFixed(2) : null,
                slotTimeUtilisation: util,
                slotMinutes_per_deal: c.throwsOk ? +((c.bound * c.windowMin) / c.throwsOk).toFixed(3) : null,
                cadenceExplanation: expl,
                cyclesN: c.cyclesN, cycleAvgMs: c.cycleAvgMs,
                throwsPerMin: c.throwsPerMin_recomputed,
                additivity: '三个损失是串行闸门，不可相加',
                verdict: c.cyclesN === 0
                    ? '零次 cycle_done ⇒ 瓶颈不在周期节拍，在"绑定/存活"或"投掷失败"'
                    : (c.cycleAvgMs != null && cycleRefSec && Math.abs(c.cycleAvgMs / 1000 - cycleRefSec) / cycleRefSec > 0.2
                        ? `有 cycle_done，但 engine 自报周期 ${c.cycleAvgMs}ms 与 B1 实测 ${Math.round(cycleRefSec * 1000)}ms 差 >20% ⇒ 该格的"成交"不是把玩周期`
                        : '有 cycle_done 且周期与 B1 同量级'),
            });
        }
    }
    out.decomposition = decomp;
    out.unknown = [
        {
            quantity: '每槽占空比（cycle_done 次数 ÷ 该槽被绑定的分钟数）',
            value: null,
            reason: '落盘里槽的绑定时刻只有 bind() 那一刻的聚合值 bound（b2_p2_*.json#bound），'
                + 'events[] 只有 {slot, phase} 没有时间戳，engine 也没逐槽记 bindAt/lastLiveAt ⇒ 单槽存活时长不可还原。'
                + '可给的上界是：单槽存活分钟 ∈ [0, windowMin]（bound 是 t=0 的快照，窗口末 slotsLive=0）。',
        },
        {
            quantity: '猪灵走出投掷距离窗的**时刻**（out_of_range / rebind 的时间）',
            value: null,
            reason: '同上一条：events[] 无时间戳。只能拿到**次数**（phases 里的 out_of_range / rebind 计数）。',
        },
        {
            quantity: 'cycleTimeoutMs 实际取值',
            value: null,
            reason: '落盘只存了输入 cfg.cycleMs（S2_B2R3/DIAG = 6200）与窗口结果，没存引擎算出的 timeout。'
                + '按 micro_barter.mjs:110 的公式可推为 max(14000, 6200×2.5)=15500ms，但这是**推算**不是落盘值。',
        },
    ];
    // 逐格核对 bindWhy 是否落盘（只有 S2_DIAG 那一格有）
    for (const [runId, r] of Object.entries(out.runs)) {
        for (const [cellId, c] of Object.entries(r.cells)) {
            if (c && c.bindWhy == null) {
                noteMissing(c.file, 'bindWhy[]', '这一格没落盘 bindWhy ⇒ 逐候选 reason 证据只有 S2_DIAG 有');
            }
        }
    }
    noteMissing('S2_B2R3/*.json, S2_DIAG/*.json', '逐槽时间线（bindAt / lastLiveAt）',
        'events[] 只有 {slot, phase} 无时间戳 ⇒ 占空比与"槽位何时失效"不可还原');
    return out;
}

// ───────────────────────── 3. bindWhy 逐候选 reason ─────────────────────────

function bindWhySection() {
    const rel = 'S2_DIAG/b2_p2_open_feed.json';
    const j = readJson(rel);
    if (!j || !Array.isArray(j.bindWhy)) { noteMissing(rel, 'bindWhy[]', '字段缺失——只有 S2_DIAG 这一格落盘了 bindWhy'); return null; }
    const rows = j.bindWhy;
    const byReason = rows.reduce((a, r) => { a[r.reason] = (a[r.reason] ?? 0) + 1; return a; }, {});
    const byId = rows.reduce((a, r) => {
        const k = String(r.id);
        if (!a[k]) a[k] = { id: r.id, n: 0, reasons: {}, d: r.d };
        a[k].n++; a[k].reasons[r.reason] = (a[k].reasons[r.reason] ?? 0) + 1;
        return a;
    }, {});
    // 逐轮（按 only_0_passed_need_1 或首条分组不严谨，改按"id 425 重新出现"切轮）
    const rounds = [];
    let cur = null;
    for (const r of rows) {
        if (!cur || (r.id === 425 && cur.some((x) => x.id === 425))) { cur = []; rounds.push(cur); }
        cur.push(r);
    }
    return {
        file: rel,
        formula: 'bindWhy = findTradeable() 每次 bind 尝试时对**每个候选**给一条 {id, d, reason}（micro_barter.mjs:135 落 engine.stats.bindWhy）',
        n: rows.length,
        byReason,
        byCandidateId: Object.values(byId),
        perRound: rounds.map((r, i) => ({ round: i, n: r.length, byReason: r.reduce((a, x) => { a[x.reason] = (a[x.reason] ?? 0) + 1; return a; }, {}) })),
        verbatim: rows,
        note: 'reason=only_0_passed_need_1 是**引擎自己放弃绑定**的那一条（0 个合格但要 1 个），'
            + 'MC-S2-01.md §5.1 的 bindWhy 清单里没有列它——它比 distance 更是"槽位活不下来"的直接证据。',
    };
}

// ───────────────────────── 4. 客户端 vs 服务端口径差 ─────────────────────────
//
// 两条**互不相同**的服务端通道，必须分开标：
//   通道A（truth.mjs:271-311 countEntities）：`as <sel> run time query day`，n = 收到几行回执。
//         ⚠ 这条通道在 S2_B1 / S2_B2 返回 0，是报告 §8.1 第 3 轮记的那个 bug ⇒ **不能当猪灵数用**。
//   通道B（probe_piglin_count.mjs:41-49）：`kill @e[type=piglin]` 的回执自带数字（破坏性）。
//   另有 resetGround() 里的 `kill @e[type=piglin]`（probe_b1_fiddle.mjs:41）也会产生
//   `Killed N entities` 行 —— server.log **不回显命令原文**，所以单看一行无法判断它是 item 杀还是 piglin 杀。
function clientServerSection() {
    const pairs = [];
    const scanDirs = [...RUN_DIRS, ...EXTRA_DIRS];
    for (const d of scanDirs) {
        const dir = path.join(RUNS, d);
        let files = [];
        try { files = fs.readdirSync(dir).filter((f) => f.endsWith('.json')); } catch { noteMissing(d, '目录', '不存在'); continue; }
        for (const f of files) {
            let j = null;
            try { j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); } catch { continue; }
            const client = num(j.clientPiglins) ?? num(j.clientCount) ?? num(j.clientBefore) ?? num(j.stand?.piglinsInView) ?? null;
            const clientField = j.clientPiglins != null ? 'clientPiglins' : j.clientCount != null ? 'clientCount'
                : j.clientBefore != null ? 'clientBefore' : j.stand?.piglinsInView != null ? 'stand.piglinsInView' : null;
            const chA = num(j.piglins?.n) ?? num(j.selfCheck?.countEntities?.n) ?? num(j.channelA?.n) ?? null;
            const chAField = j.piglins?.n != null ? 'piglins.n' : j.selfCheck?.countEntities?.n != null ? 'selfCheck.countEntities.n'
                : j.channelA?.n != null ? 'channelA.n' : null;
            const chB = num(j.serverCount?.n) ?? num(j.channelB?.n) ?? null;
            const chBField = j.serverCount?.n != null ? 'serverCount.n' : j.channelB?.n != null ? 'channelB.n' : null;
            if (client == null && chA == null && chB == null) continue;
            pairs.push({
                run: d, file: f, at: j.at ?? j.startedAt ?? null,
                client, clientField,
                server_chA_lineCount: chA, server_chA_field: chAField,
                server_chB_killReceipt: chB, server_chB_field: chBField,
                ratio_client_over_chA: client != null && chA ? +(client / chA).toFixed(2) : null,
                chA_usable: chA === 0 ? 'NO —— 通道A 在这一局返回 0 行（§8.1 第 3 轮的已知 bug），不是"真的 0 头"' : null,
            });
        }
    }

    // server.log 里的 `Killed N entities` 分布（不区分 item / piglin 杀）
    const killRows = {};
    for (const d of scanDirs) {
        const txt = readText(d + '/server.log');
        if (txt == null) continue;
        const ns = [...txt.matchAll(/Killed (\d+) entit(?:y|ies)/g)].map((m) => +m[1]);
        const deaths = [...txt.matchAll(/BarterBot\w+ (was slain by [^\n\]]+|drowned|fell from [^\n\]]+|burned up|blew up|was squashed)/g)]
            .map((m) => m[1].trim());
        killRows[d] = {
            nKillReceipts: ns.length,
            values: ns,
            min: ns.length ? Math.min(...ns) : null,
            max: ns.length ? Math.max(...ns) : null,
            deaths,
        };
    }

    return {
        clientFieldLegend: '客户端 = bot.entities 里 name==="piglin" 的实体数（mineflayer 保留已离开追踪范围的实体，直到收到 destroy 包）',
        serverChannelLegend: {
            A: 'truth.mjs:271-311 countEntities —— `as <sel> run time query day`，n=回执行数。⚠ 报告 §8.1 第 3 轮记的 bug 使它在 S2_B1/S2_B2 返回 0',
            B: 'probe_piglin_count.mjs:41-49 —— `kill @e[type=piglin]` 回执自带数字（破坏性，只能放最后）',
        },
        pairs,
        killReceiptsInServerLog: killRows,
    };
}

// ───────────────────────── 5. B4 锭珠比为什么算不出来 ─────────────────────────

function b4Section() {
    const ev = [];
    // B1：sum.dropItems / dropTruth
    const b1 = readJson('S2_B1/b1_p4_trials.json');
    if (b1) {
        ev.push({
            file: 'S2_B1/b1_p4_trials.json',
            field: 'sum.dropItems',
            value: b1.sum?.dropItems ?? null,
            reading: '全部 14 条成交的掉落物名字都归到 "?" ⇒ 名字维度全灭',
        });
        ev.push({
            file: 'S2_B1/b1_p4_trials.json',
            field: 'trials[].drop.name / .count',
            value: {
                names: [...new Set(b1.trials.filter((t) => t.drop).map((t) => t.drop.name))],
                counts: [...new Set(b1.trials.filter((t) => t.drop).map((t) => t.drop.count))],
            },
            reading: 'name 恒 "?"、count 恒 0 —— 读到了"有一个掉落物实体"，读不出"是什么、几个"',
        });
        ev.push({
            file: 'S2_B1/b1_p4_trials.json',
            field: 'sum.dropTruthOK / trials[].dropTruth.ageTicks',
            value: { dropTruthOK: b1.sum?.dropTruthOK ?? null, sample: b1.trials.find((t) => t.dropTruth)?.dropTruth ?? null },
            reading: '服务端 ItemEntity.Age 也一条没读到（ageTicks=null, gametimeAtRead 有值）⇒ 服务端真值这条路也没通',
        });
        ev.push({
            file: 'S2_B1/b1_p4_trials.json',
            field: 'sum.sameTickCount / trials[].hand.main',
            value: { sameTickCount: b1.sum?.sameTickCount ?? null, main: [...new Set(b1.trials.flatMap((t) => t.hand?.main ?? []))] },
            reading: '手held轮询全是 no_receipt ⇒ HandItems 通道没通（真因见报告 §8.4 的 run at 拼接 bug）',
        });
    }
    // B2 系列：rep.drops
    for (const [d, f] of [['S2_B2', 'b2_p2_n4.json'], ['S2_B2R3', 'b2_p2_pen_ground.json']]) {
        const j = readJson(d + '/' + f);
        if (j) ev.push({ file: `${d}/${f}`, field: 'rep.drops', value: j.rep?.drops ?? null, reading: '引擎侧 stats.drops 同样只有 "?" 键' });
    }
    // 扔锭对照：连 bot 自己 Q 丢的锭都读成 "?"
    const dc = readJson('S2_B1/b1_p2_drop_control.json');
    if (dc) ev.push({ file: 'S2_B1/b1_p2_drop_control.json', field: 'newDropNames', value: dc.newDropNames, reading: 'bot 自己按 Q 丢的金锭（已知是 gold_ingot）也读成 "?" ⇒ 与猪灵无关，是读数通道本身的问题' });
    // B4 汇总本身
    const b4s = {};
    for (const d of ['S2_B2', 'S2_B2R3', 'S2_DIAG']) {
        const j = readJson(d + '/b2_p3_b4.json');
        if (j) b4s[d] = { throws: j.throws, ingotsUsed: j.ingotsUsed, pearls: j.pearls, pearlsPerIngot: j.pearlsPerIngot, ci95: j.ci95 };
    }
    return {
        conclusion: 'B4 算不出来的直接原因是掉落物**身份**读不出：所有落盘里掉落物名字恒为 "?"、堆数恒为 0；'
            + '而 pearls=0 是另一个独立原因（三个局合计 0 颗珍珠，样本本身没有分母分子比）。两者叠加 ⇒ 理论 0.2837 无从对比。',
        pearlsAreZeroEverywhere: Object.keys(b4s).length ? Object.values(b4s).every((x) => x.pearls === 0) : null,
        b4Summaries: b4s,
        evidence: ev,
        unknown: [{
            quantity: '掉落物真实名字 / 堆数',
            value: null,
            reason: '落盘只有 "?" 与 0。根因（metadata 槽位索引 / 1.16 的 Slot 容器形态）需要读 piglin.js 的 itemOf，'
                + '而 piglin.js 在 mindcraft-wt/s2-barter（本单禁读）⇒ 本单 UNKNOWN。',
        }],
    };
}

// ───────────────────────── 5b. 标定链：B1 → B2 引擎参数是怎么来的 ─────────────────────────
//
// micro_barter.mjs:40-54 loadPrimitives() 读的三个文件，与落盘实际内容逐个核对：
//   runs/S2_P1_PROBE/p2b_throw_calib.json   → cfg.holdingIdx
//   runs/S2_B1/b1_p4_trials.json#sum         → cfg.pickupDelayMs / cfg.cycleMs
//   runs/S2_B1/b1_p2_distance.json#distRows  → cfg.bestDist / minDist / maxDist
function calibrationChain() {
    const out = { reads: [], resultingCfg: null, breaks: [] };
    const cal = readJson('S2_P1_PROBE/p2b_throw_calib.json');
    out.reads.push({
        read: 'runs/S2_P1_PROBE/p2b_throw_calib.json#holdingIdx',
        actual: { holdingIdx: cal?.holdingIdx ?? null, wholeFile: cal ?? null },
        feeds: 'cfg.holdingIdx → pig.applyCalibration()（有值才调）',
    });
    if (cal && cal.holdingIdx == null) out.breaks.push('holdingIdx 落盘为 null ⇒ applyCalibration() 根本没被调用；'
        + '但 S2_B2R3/DIAG 的 rep.calibrated 仍写 true —— 那是引擎的另一个标志位，不代表标定生效');

    const b1 = readJson('S2_B1/b1_p4_trials.json');
    const meanSec = b1?.sum?.cycle?.mean ?? null;
    const pickMean = b1?.sum?.pickupDelay?.mean ?? null;
    out.reads.push({
        read: 'runs/S2_B1/b1_p4_trials.json#sum.cycle.mean',
        actual: { mean: meanSec, meanTicks: b1?.sum?.cycle?.meanTicks ?? null },
        feeds: `cfg.cycleMs = round(mean×1000) = ${meanSec != null ? Math.round(meanSec * 1000) : null} ms（落盘值）`,
    });
    out.reads.push({
        read: 'runs/S2_B1/b1_p4_trials.json#sum.pickupDelay.mean',
        actual: { mean: pickMean, n: b1?.sum?.pickupDelay?.n ?? null },
        feeds: `cfg.pickupDelayMs = round(mean×1000)+400 = ${pickMean != null ? Math.round(pickMean * 1000) + 400 : null} ms（落盘值）`,
    });
    if (meanSec != null) out.breaks.push(`cfg.cycleMs 吃的是**混口径** ${meanSec}s（含 inv_delta 那批的 +0.5s pickupDelay），`
        + `不是 drop_entity 口径的 5.96s ⇒ 引擎的兜底周期系统性偏大 ${Math.round((meanSec / 5.96 - 1) * 100)}%`);
    else out.breaks.push('b1_p4_trials.json#sum.cycle.mean 读不到 ⇒ cfg.cycleMs 无法从 B1 推出（引擎回退默认）');

    const p2 = readJson('S2_B1/b1_p2_distance.json');
    const p3 = readJson('S2_B1/b1_p3_distance.json');
    const p2rows = Array.isArray(p2?.distRows) ? p2.distRows : [];
    const p3rows = Array.isArray(p3?.distRows) ? p3.distRows : [];
    out.reads.push({
        read: 'runs/S2_B1/b1_p2_distance.json#distRows（micro_barter.mjs:44 实际读的文件）',
        actual: {
            nRows: p2rows.length,
            nOk: p2rows.filter((r) => r.ok).length,
            byPhase: p2rows.reduce((a, r) => { const k = r.ok ? 'ok' : r.phase; a[k] = (a[k] ?? 0) + 1; return a; }, {}),
            at: p2?.at ?? null,
        },
        feeds: 'bestDist = ok && cycleSec!=null 里 cycleSec 最小的那条的 dist0；本文件 0 条 ok ⇒ bestDist 保持 null',
    });
    out.reads.push({
        read: 'runs/S2_B1/b1_p3_distance.json#distRows（真正有成交距离标定数据的文件，micro_barter.mjs 没读它）',
        actual: {
            nRows: p3rows.length,
            nOk: p3rows.filter((r) => r.ok).length,
            byPhase: p3rows.reduce((a, r) => { const k = r.ok ? 'ok' : r.phase; a[k] = (a[k] ?? 0) + 1; return a; }, {}),
            best: p3rows.filter((r) => r.ok && r.cycleSec != null).sort((a, b) => a.cycleSec - b.cycleSec)[0] ?? null,
            at: p3?.at ?? null,
        },
        feeds: '（无人读）',
    });
    out.breaks.push('⚠ 落盘文件名与源码对不上：micro_barter.mjs:44 读 b1_p2_distance.json 取 distRows，'
        + '但那一份是更早一轮的失败数据（5/5 全 no_los/too_far）；有成交的那份叫 b1_p3_distance.json。'
        + '⇒ bestDist 恒 null，引擎一直用默认距离窗 1.4–3.2 格，而不是实测最佳档 2.8–3.4 格');

    const r3 = readJson('S2_B2R3/b2_p1_setup.json');
    out.resultingCfg = { S2_B2R3: r3?.cfg ?? null, S2_DIAG: readJson('S2_DIAG/b2_p1_setup.json')?.cfg ?? null, S2_B2: readJson('S2_B2/b2_p1_setup.json')?.cfg ?? null };
    return out;
}

// ───────────────────────── 6. 与 MC-S2-01.md 的逐条对照 ─────────────────────────
//
// 报告里的数一律**硬编码成常量并标注出处行号**，不当作数据源；本节只做"报告说 X / 落盘算出 Y"的并排。
const REPORT_CLAIMS = [
    { id: 'cycle-119tick', report: '周期 5.95s = 119 tick（n=14，drop_entity 口径）', where: 'MC-S2-01.md §0 / §1 / §4.3' },
    { id: 'cycle-5.99', report: '出手→掉落物出现 mean 5.99s，p10 5.93 / p50 5.96 / p90 5.98（n=14）', where: 'MC-S2-01.md §4.1' },
    { id: 'cycle-40throws', report: '投出后掉落物实体出现 14/14 次（dealBy: drop_entity）', where: 'MC-S2-01.md §4.1' },
    { id: 'fiddle-107tick', report: '纯把玩 = 周期 − 捡起延迟 = 5.33–5.39s / 107–108 tick（n=7）', where: 'MC-S2-01.md §4.3' },
    { id: 'fiddle-5.60', report: '「汇总里把两种口径混在一起算的均值」5.60 / 112 tick / n=7', where: 'MC-S2-01.md §4.3' },
    { id: 'b1-40plus', report: '三轮 B1 合计 40+ 次成交', where: 'MC-S2-01.md §4.3' },
    { id: 'b1-drop-dist', report: '掉落物落点距 bot 3.15–3.39 格', where: 'MC-S2-01.md §4.1' },
    { id: 'b1-piglin-easy', report: 'easy：同一位置 B1 局 kill 回执 Killed 16 / Killed 59；客户端 57–64', where: 'MC-S2-01.md §4.5' },
    { id: 'client-62-server-8-11', report: '客户端 62 头 vs 服务端选择器 8–11 头（同一时刻同一坐标）', where: 'MC-S2-01.md §2.3 / §10.3' },
    { id: 'evidence-60', report: '证据：runs/S2_B1/summary.json#clientPiglins=60', where: 'MC-S2-01.md §10.3' },
    { id: 'b2-133', report: 'N=4 并行 1.33 次/分（out_of_range 3 + 反复 rebind）', where: 'MC-S2-01.md §5.1 第一轮' },
    { id: 'b2-matrix', report: 'R3 矩阵：open/feed 0.67、open/ground 0.67、pen/feed 0、DIAG 1.33；无 pen/ground 行', where: 'MC-S2-01.md §5.1 第二轮表' },
    { id: 'piglin-62-77', report: '新中心 [336,256] 服务端实测 62–77 头（b2_p0_selfcheck.json）', where: 'MC-S2-01.md §5.1' },
    { id: 'bindWhy', report: 'bindWhy: x15 distance / x3 no_los / x3 excluded / x1 OK（无 only_0_passed_need_1）', where: 'MC-S2-01.md §5.1' },
    { id: 'calib-chain', report: '（报告未提）micro_barter.mjs:44 读 b1_p2_distance.json 取 distRows → bestDist；B1 落盘里 b1_p2_distance.json 是失败轮、有成交的是 b1_p3_distance.json', where: '源码 micro_barter.mjs:40-54 vs runs/S2_B1/' },
];

/** 把重算结果与报告断言并排。recomputed 字段里放重算值，null 表示落盘拿不到。 */
function discrepancySection(b1, thr, bw, cs) {
    const find = (runId, id) => thr.runs[runId]?.cells?.[id] ?? null;
    const rows = [];

    const push = (id, recomputed, trust) => rows.push({ claimId: id, recomputed, trust });

    // 周期
    const drop = b1?.cycle_dropEntity_only;
    push('cycle-119tick', {
        recomputed_drop_entity: { n: drop?.n, mean: drop?.mean, mean_ticks: drop?.mean_ticks, p10: drop?.p10, p50: drop?.p50, p90: drop?.p90 },
        recomputed_allCalibers: { n: b1?.cycle_all?.n, mean: b1?.cycle_all?.mean, mean_ticks: b1?.cycle_all?.mean_ticks },
        note: '落盘 summary.json#cycle 记的是**混口径**的 6.2s / 124 tick；119 tick 只在 drop_entity 子集（n=7）上成立',
    }, '落盘（子集重算）');
    push('cycle-5.99', {
        recomputed_drop_entity: { mean: drop?.mean, p10: drop?.p10, p50: drop?.p50, p90: drop?.p90, n: drop?.n },
        delta_mean_sec: drop ? +(drop.mean - 5.99).toFixed(3) : null,
        delta_mean_pct: drop ? +(100 * (drop.mean - 5.99) / 5.99).toFixed(2) : null,
    }, '落盘（子集重算）');
    push('cycle-40throws', {
        drop_entity: b1?.cycle_dropEntity_only?.n,
        inv_delta: b1?.cycle_invDelta_only?.n,
        none: b1 ? b1.nOk - b1.cycle_dropEntity_only.n - b1.cycle_invDelta_only.n : null,
        nOk: b1?.nOk, nTrials: b1?.nTrials,
        dropNames: b1?.drops?.names,
    }, '落盘');
    push('fiddle-107tick', {
        落盘口径: b1?.fiddle?.['落盘口径_mean(cyc_all)-mean(pick_good)'],
        drop_entity口径: b1?.fiddle?.['drop_entity口径_mean(cyc_drop)-mean(pick)'],
        逐样本配对: b1?.fiddle?.['逐样本配对(cycle-pickup)'],
        ticks: b1?.fiddle?.ticks,
    }, '落盘');
    push('fiddle-5.60', { recomputed: b1?.fiddle?.['落盘口径_mean(cyc_all)-mean(pick_good)'], ticks: b1?.fiddle?.ticks?.['落盘口径'] }, '落盘（与报告一致）');
    push('b1-40plus', { recomputed_nOk_total: b1?.nOk, files: ['S2_B1/b1_p3_trials.json(nOk=0)', 'S2_B1/b1_p4_trials.json(nOk=14)'] }, '落盘');
    push('b1-drop-dist', { dFromBot: b1?.drops?.dFromBot, dFromPiglin: b1?.drops?.dFromPiglin }, '落盘');

    // 猪灵数
    const b1Setup = readJson('S2_B1/b1_p1_setup.json');
    const b1Kill = cs.killReceiptsInServerLog?.S2_B1;
    push('b1-piglin-easy', {
        clientPiglins_b1_p1_setup: num(b1Setup?.clientPiglins),
        server_chA_piglins_n: num(b1Setup?.piglins?.n),
        server_chA_trusted: b1Setup?.piglins?.trusted ?? null,
        serverKillReceipts_in_S2_B1_serverlog: b1Kill ? { min: b1Kill.min, max: b1Kill.max, n: b1Kill.nKillReceipts, values: b1Kill.values } : null,
        note: 'b1_p1_setup 的服务端数走通道A 且返回 0（已知坏读数）；S2_B1/server.log 的 "Killed N entities" 里 59/17/10/9… '
            + '混着 resetGround 的 item 杀与 piglin 杀，log 不回显命令 ⇒ 无法逐行归因',
    }, '落盘');
    const r2setup = readJson('S2_B2R2/b2_p1_setup.json');
    push('client-62-server-8-11', {
        client62_source: r2setup?.stand?.piglinsInView ?? null,
        client62_file: 'S2_B2R2/b2_p1_setup.json#stand.piglinsInView',
        server_paired_with_62: num(r2setup?.piglins?.n),
        server_channel_of_that_number: '通道A（行数）',
        server_8_11_source: 'S2_B1/server.log 的 Killed N entities（resetGround 的 kill 通道，与 62 不是同一局、不是同一坐标）',
        sameRunSamePlace_pair_exists: false,
    }, '落盘（两侧数字来自不同 run ⇒ 报告把它们并成"同一时刻同一坐标"站不住）');
    push('evidence-60', {
        top_level_clientPiglins_in_summary: readJson('S2_B1/summary.json')?.clientPiglins ?? null,
        nested_in_summary_phases: (readJson('S2_B1/summary.json')?.phases ?? [])
            .filter((ph) => ph?.clientPiglins != null).map((ph) => ({ phase: ph.phase, clientPiglins: ph.clientPiglins })),
        actual_value_in_b1_p1_setup: num(b1Setup?.clientPiglins),
    }, '落盘');

    push('calib-chain', calibrationChain().breaks, '落盘 + 源码');

    // 吞吐
    const n4 = find('S2_B2', 'b2_p2_n4');
    push('b2-133', {
        file: n4?.file, throwsOk: n4?.throwsOk, throws: n4?.throws, throwsPerMin_reported: n4?.throwsPerMin_reported,
        throwsPerMin_recomputed: n4?.throwsPerMin_recomputed, windowMin: n4?.windowMin, bound: n4?.bound,
        slotsLive: n4?.slotsLive_atEnd, cyclesN: n4?.cyclesN, cycleAvgMs: n4?.cycleAvgMs, phases: n4?.phases,
    }, '落盘');
    push('b2-matrix', {
        open_feed: pick(find('S2_B2R3', 'b2_p2_open_feed')),
        open_ground: pick(find('S2_B2R3', 'b2_p2_open_ground')),
        pen_feed: pick(find('S2_B2R3', 'b2_p2_pen_feed')),
        pen_ground: pick(find('S2_B2R3', 'b2_p2_pen_ground')),
        report_has_pen_ground_row: false,
    }, '落盘');
    push('piglin-62-77', {
        b2_p0_selfcheck_n: num(readJson('S2_B2R3/b2_p0_selfcheck.json')?.selfCheck?.countEntities?.n),
        b2_p1_setup_piglins_n: num(readJson('S2_B2R3/b2_p1_setup.json')?.piglins?.n),
        diag_p0_selfcheck_n: num(readJson('S2_DIAG/b2_p0_selfcheck.json')?.selfCheck?.countEntities?.n),
        diag_p1_setup_piglins_n: num(readJson('S2_DIAG/b2_p1_setup.json')?.piglins?.n),
    }, '落盘');
    push('bindWhy', {
        byReason: bw?.byReason ?? null,
        report_listed: { distance: 15, no_los: 3, excluded: 3, OK: 1 },
        omitted_by_report: bw ? Object.fromEntries(Object.entries(bw.byReason).filter(([k]) => !['distance', 'no_los', 'excluded', 'OK'].includes(k))) : null,
    }, '落盘（报告那四个数对得上，但漏了 only_0_passed_need_1）');
    return rows;
    function pick(c) {
        if (!c) return null;
        return {
            file: c.file, throws: c.throws, throwsOk: c.throwsOk, throwsFail: c.throwsFail,
            throwsPerMin_reported: c.throwsPerMin_reported, throwsPerMin_recomputed: c.throwsPerMin_recomputed,
            bound: c.bound, slotsLive_atEnd: c.slotsLive_atEnd, cyclesN: c.cyclesN, cycleAvgMs: c.cycleAvgMs,
            ingotsUsed: c.ingotsUsed, dim: c.dim, phases: c.phases,
        };
    }
}

// ───────────────────────── 主流程 ─────────────────────────

function main() {    const b1 = cycleSection();
    const cycleRefSec = b1?.cycle_dropEntity_only?.mean ?? b1?.cycle_all?.mean ?? null;
    const thr = throughputSection(cycleRefSec);
    const bw = bindWhySection();
    const cs = clientServerSection();
    const b4 = b4Section();
    const calib = calibrationChain();
    const disc = discrepancySection(b1, thr, bw, cs);

    const result = {
        tool: 'recompute_baseline.mjs',
        generatedAt: new Date().toISOString(),
        root: ROOT,
        note: '全部数字来自 runs/** 的落盘文件；本脚本不连服、不改盘。读不到的量一律 null + 原因。',
        b1_cycle: b1,
        b2_throughput: thr,
        bindWhy: bw,
        client_vs_server: cs,
        b4_itemof: b4,
        calibration_chain: calib,
        reportClaims: REPORT_CLAIMS,
        discrepancies: disc,
        missing,
    };

    if (hasFlag('--no-write') === false) {
        try { fs.writeFileSync(OUT_JSON, JSON.stringify(result, null, 2) + '\n', 'utf8'); }
        catch (e) { console.error('[warn] 写 ' + OUT_JSON + ' 失败：' + e.message); }
    }
    if (hasFlag('--json')) { console.log(JSON.stringify(result, null, 2)); return; }
    human(result);
}

function human(r) {
    const L = [];
    const p = (...a) => L.push(a.join(' '));
    p('════ 离线重算：MC-S2-01 头条数字 ════');
    p('root =', r.root);
    p('generatedAt =', r.generatedAt);
    p('');
    const c = r.b1_cycle;
    p('【1】把玩周期（S2_B1/b1_p4_trials.json#trials[]）');
    p(`  trials n=${c?.nTrials}  出手成功 n=${c?.nThrowOk}  有周期可测 n=${c?.nWithCycle}  出手失败 ${JSON.stringify(c?.failPhases)}`);
    p(`  natural=${c?.nNatural} fixture=${c?.nFixture}  出手成功但测不到周期：${JSON.stringify(c?.okNotCycle)}`);
    p(`  周期 混口径  n=${c?.cycle_all?.n} mean=${c?.cycle_all?.mean}s(${c?.cycle_all?.mean_ticks}tick) p10=${c?.cycle_all?.p10} p50=${c?.cycle_all?.p50} p90=${c?.cycle_all?.p90}`);
    p(`  周期 drop_entity n=${c?.cycle_dropEntity_only?.n} mean=${c?.cycle_dropEntity_only?.mean}s(${c?.cycle_dropEntity_only?.mean_ticks}tick) p10=${c?.cycle_dropEntity_only?.p10} p50=${c?.cycle_dropEntity_only?.p50} p90=${c?.cycle_dropEntity_only?.p90}`);
    p(`  周期 inv_delta   n=${c?.cycle_invDelta_only?.n} mean=${c?.cycle_invDelta_only?.mean}s(${c?.cycle_invDelta_only?.mean_ticks}tick) p10=${c?.cycle_invDelta_only?.p10} p50=${c?.cycle_invDelta_only?.p50} p90=${c?.cycle_invDelta_only?.p90}`);
    p(`  捡起延迟 全行 n=${c?.pickupDelay?.n_allRows} mean=${c?.pickupDelay?.mean_allRows} ｜ 有周期行 n=${c?.pickupDelay?.n_rowsWithCycle} mean=${c?.pickupDelay?.mean_rowsWithCycle}`);
    p(`  纯把玩 ${JSON.stringify(c?.fiddle?.ticks)} tick ｜ ${c?.fiddle?.warning}`);
    p(`  掉落物 ${JSON.stringify(c?.drops)}`);
    p('');
    p('【2】N=4 吞吐拆解');
    for (const d of r.b2_throughput.decomposition) {
        p(`  ${d.run}/${d.cell}  ${d.windowMin}min  请求槽${d.slotsRequested} 绑定${d.bound}  `
            + `绑定损失=${pctStr(d.loss_bind_pct)} 槽时空转损失=${pctStr(d.loss_idle_pct)} 出手失败率=${pctStr(d.loss_throw_pct)}  cycle_done=${d.cyclesN}`);
        p(`      → ${d.cadenceExplanation}`);
    }
    p('');
    p('【3】bindWhy 逐候选 reason（S2_DIAG）  n=' + (r.bindWhy?.n ?? 'null'));
    p('  ' + JSON.stringify(r.bindWhy?.byReason ?? null));
    p('');
    p('【4】客户端 vs 服务端');
    for (const q of r.client_vs_server.pairs) {
        if (q.client != null || q.server_chB_killReceipt != null) {
            p(`  ${q.run}/${q.file}  client(${q.clientField})=${q.client}  chA(${q.server_chA_field})=${q.server_chA_lineCount}  chB(${q.server_chB_field})=${q.server_chB_killReceipt}${q.chA_usable ? '  ⚠' + q.chA_usable : ''}`);
        }
    }
    p('');
    p('【5】B4 锭珠比：pearls 全 0 =', r.b4_itemof.pearlsAreZeroEverywhere, '｜证据', r.b4_itemof.evidence.length, '条');
    p('');
    p('【5b】标定链断点（B1 → B2 引擎参数）');
    for (const b of r.calibration_chain.breaks) p('  ! ' + b);
    p('  resulting cfg: ' + JSON.stringify(r.calibration_chain.resultingCfg));
    p('');
    p('【6】与 MC-S2-01.md 的并排（recomputed 见 JSON）');
    for (const d of r.discrepancies) p(`  · ${d.claimId}：trust=${d.trust}`);
    p('');
    p('【missing】' + r.missing.length + ' 条');
    for (const m of r.missing) p(`  - ${m.where} :: ${m.what} :: ${m.why}`);
    console.log(L.join('\n'));
}

main();
