# baseline_recompute.md — MC-S2-01 头条数字的离线重算（开发线 F · S2 易物）

> 本单**不开服、不连任何服务器**，只读 `bench/stages/barter/runs/**` 的落盘文件。
> 重算脚本：`analysis/recompute_baseline.mjs`（零外部依赖，只用 node 内置 `fs`/`path`）
> 机器可读结果：`analysis/baseline_recompute.json`（下面每个数都是它跑出来的）
> 对照对象：`docs/MC-S2-01.md`
>
> ```powershell
> node bench\stages\barter\analysis\recompute_baseline.mjs            # 人读摘要
> node bench\stages\barter\analysis\recompute_baseline.mjs --json     # 机器可读
> node bench\stages\barter\analysis\recompute_baseline.mjs --no-write # 不落盘
> ```
>
> **本单不写 MC-S2-01.md，也不改任何 bench 源码。** 下面 §6 只把不一致列出来，处置留给下一轮/裁决会话。

---

## 0. 三行结论

1. **把玩周期 119 tick 站得住，但它是 `drop_entity` 子集（n=7）的数**；落盘 `summary.json#cycle` 自己写的是
   **6.20s / 124 tick（n=14，混口径）**。同一个文件里两个数，报告只引用了前者并把 n 写成 14。
2. **N=4 吞吐的瓶颈可以定量说死了：不是节拍。** 9 个格子里 **7 个 `cycle_done=0`**，
   节拍这一项的贡献是 0；3 个格子 `bound=0`（损失 100% 在绑定），其余 `bound=2/4`（绑定损失 50%）。
   唯一能算出节拍损失的格子（`S2_B2/b2_p2_n4`）里，2 次成交只占用了绑上槽的 **7% 槽时** ⇒ **93% 的绑定时间是死的**。
3. **报告 §5.1 的第二轮矩阵漏了一整格**：`S2_B2R3/b2_p2_pen_ground.json` 落了盘，
   `throwsOk=21 / 14.0 次每分`，是全部数据里最高的吞吐格，报告表格里没有这一行。

---

## 1. 把玩周期 / 捡起延迟 / 纯把玩

### 1.1 口径（从源码钉死，不靠猜）

字段来源：`runs/S2_B1/b1_p4_trials.json` → `trials[]`（20 条）
写这些字段的是 `probe_b1_fiddle.mjs` 的 `measureThrow()`：

| 量 | 公式 / 判定 | 源码位置 |
|---|---|---|
| `tThrow` | `throwIngot()` **借记成立返回之后**的 `Date.now()` —— **不含瞄准耗时** | `probe_b1_fiddle.mjs:140` |
| `tIngot` | 投出的金锭**物品实体**首次出现在 `bot.entities`（`d.name==='gold_ingot' \|\| d.d<3.0`） | `:162-164` |
| `tPickup` | 那个实体从 `bot.entities` 消失 | `:177` |
| `tDrop` | 一个**新 id** 的掉落物实体出现（`d.e.id !== ingotId`） | `:166-173` |
| `tInvGain` | 背包签名 `JSON.stringify` 变化 | `:153, :179` |
| `cycleSec` | `(tDeal − tThrow)/1000`，**`tDeal = tDrop ?? tInvGain`** | `:204-208` |
| `pickupDelaySec` | `tPickup − tIngot` | `:216` |

**「掉落物出现」判的是客户端实体表，不是服务端真值**：`sum.dropTruthOK = 0`，
`trials[].dropTruth.ageTicks` 全为 `null`（`gametimeAtRead` 有值）⇒ 服务端 `ItemEntity.Age` 那条精确 tick 的路**一条没通**。
所以这是"出手时刻 → **客户端**看到掉落物实体"的周期。

分位数算法**刻意复刻** `probe_b1_fiddle.mjs:234-238`（排序后 `index = clamp(round(p/100·(n−1)))`），
这样重算值可以和落盘 `summary.json` 的同名字段逐位对照。

### 1.2 逐样本（20 条全列，含没成交的）

`d` = `trials[].dist0`；`周期` = `trials[].cycleSec`；`tick` = `round(周期×20)`（TPS=20，`trials[].tps`）

| tag | ok | phase | d | dealBy | 周期 s | tick | 捡起延迟 s | 掉落物名 | 堆 | 距猪灵 | 距 bot | 借记 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| t0 | ✓ | — | 2.79 | drop_entity | 5.95 | 119 | — | `?` | 0 | 1.44 | 3.25 | −1 |
| t1 | ✓ | — | 2.50 | **none** | — | — | 0.61 | — | — | — | — | −1 |
| t2 | ✓ | — | 2.79 | drop_entity | 5.96 | 119 | — | `?` | 0 | 1.44 | 3.25 | −1 |
| t3 | ✓ | — | 2.50 | inv_delta | 6.42 | 128 | 0.55 | — | — | — | — | −1 |
| t4 | ✓ | — | 2.50 | inv_delta | 6.47 | 129 | 0.59 | — | — | — | — | −1 |
| t5 | ✓ | — | 2.36 | **none** | — | — | 0.60 | — | — | — | — | −1 |
| t6 | ✓ | — | 2.50 | inv_delta | 6.45 | 129 | 0.61 | — | — | — | — | −1 |
| t7 | ✓ | — | 2.75 | drop_entity | 5.95 | 119 | — | `?` | 0 | 1.44 | 3.25 | −1 |
| t8 | ✓ | — | 2.79 | drop_entity | 5.95 | 119 | — | `?` | 0 | 1.44 | 3.25 | −1 |
| **t9** | ✗ | `no_debit` | 2.50 | — | — | — | — | — | — | — | — | 0 |
| t10 | ✓ | — | 2.50 | **none** | — | — | 0.61 | — | — | — | — | −1 |
| t11 | ✓ | — | 2.50 | **none** | — | — | 0.59 | — | — | — | — | −1 |
| t12 | ✓ | — | 2.50 | inv_delta | 6.45 | 129 | 0.63 | — | — | — | — | −1 |
| t13 | ✓ | — | 2.50 | inv_delta | 6.45 | 129 | 0.61 | — | — | — | — | −1 |
| t14 | ✓ | — | 2.50 | inv_delta | 6.47 | 129 | 0.61 | — | — | — | — | −1 |
| t15 | ✓ | — | 2.31 | inv_delta | 6.45 | 129 | 0.60 | — | — | — | — | −1 |
| t16 | ✓ | — | 2.71 | drop_entity | 5.99 | 120 | — | `?` | 0 | 1.44 | 3.18 | −1 |
| t17 | ✓ | — | 2.31 | **none** | — | — | 0.56 | — | — | — | — | −1 |
| t18 | ✓ | — | 2.75 | drop_entity | 5.95 | 119 | — | `?` | 0 | 1.44 | 3.29 | −1 |
| t19 | ✓ | — | 2.75 | drop_entity | 5.95 | 119 | — | `?` | 0 | 1.44 | 3.21 | −1 |

- **20 次出手，19 次借记成立，每次恰好 −1**（`ingots0 − ingots1 == 1`，19/19）；`botPickedOwnThrow = 0/19`。
- **19 次里只有 14 次测到周期**：7 条 `drop_entity`、7 条 `inv_delta`、**5 条 `dealBy:"none"`**
  （t1/t5/t10/t11/t17：出手成功、捡起延迟测到了，但 20s 窗口内既没看到新掉落物、也没看到背包变化）。
  报告把这 5 条从叙述里省掉了，它们是"成交判据漏检"的直接证据。

### 1.3 三种口径的周期（这是本单最要紧的一张表）

| 口径 | n | mean | p10 | p50 | p90 | min–max | mean×TPS20 |
|---|---|---|---|---|---|---|---|
| **混口径**（落盘 `summary.json#cycle`，drop_entity + inv_delta 一起算） | 14 | **6.20 s** | 5.95 | 6.42 | 6.47 | 5.95–6.47 | **124 tick** |
| `drop_entity`（客户端看到掉落物实体） | **7** | **5.96 s** | 5.95 | 5.95 | 5.96 | 5.95–5.99 | **119 tick** |
| `inv_delta`（礼物被 bot 瞬收，只能看背包增量） | 7 | 6.45 s | 6.45 | 6.45 | 6.47 | 6.42–6.47 | 129 tick |

**混口径那一行与落盘 `summary.json#cycle` 逐位相同**（6.2 / 5.95 / 6.42 / 6.47 / 124）
⇒ 分位数算法复刻正确，重算本身可信。

**119 tick 只在 `drop_entity` 子集上成立，n=7，不是 14。**

### 1.4 捡起延迟

| 口径 | n | mean | p10 | p50 | p90 |
|---|---|---|---|---|---|
| 全部有读数的行（t1,3,4,5,6,10,11,12,13,14,15,17） | **12** | 0.60 | 0.56 | 0.61 | 0.61 |
| 落盘 `summary.pickupDelay` 用的"同时有周期"的行 | 7 | 0.60 | 0.59 | — | 0.61 |

两条 mean 完全相同（0.60），**n 差 5**。`trials[].drop_entity` 那 7 条的 `pickupDelaySec` 是 `null`
（`tIngot` 分支 `continue` 掉了，`:163`），所以**掉落物口径下捡起延迟根本没测到**。

### 1.5 纯把玩 = 周期 − 捡起延迟：三个口径互不相等

| 口径 | 算式 | 结果 | tick |
|---|---|---|---|
| 落盘口径 | `mean(混口径周期) − mean(捡起延迟n=7)` = 6.20 − 0.60 | 5.60 s | **112** |
| `drop_entity` 口径 | `mean(drop_entity周期) − mean(捡起延迟n=12)` = 5.96 − 0.60 | 5.36 s | **107** |
| 逐样本配对 | 同一行里 `cycleSec − pickupDelaySec`，n=7，p10/p50/p90 = 5.84/5.85/5.87 | 5.85 s | **117** |

**🚨 配对那 7 条全是 `inv_delta` 行。** 而 `inv_delta` 周期本身就含捡起延迟
（周期 = 出手 → 背包多出东西 = 飞 + 捡 + 把玩 + 0.5s pickupDelay），
**再减一次捡起延迟是重复扣**。所以 117 tick 不是"更准的纯把玩"，是错得更少的减法。
真正的纯把玩只能从 `drop_entity` 那 7 条估，而它们**没有捡起延迟读数**——
只能跨口径借一个 0.60s 减，得到 5.36s / 107 tick（= 报告 §4.3 的数）。

---

## 2. N=4 吞吐拆解

### 2.1 逐格原始数（全部来自 `rep` + 顶层字段）

窗口分钟 = `rep.windowMs / 60000`；`throwsPerMin` 落盘值与重算值都列（两者应当一致，用于验证）

| run / 格 | 窗口 min | 槽 请求/绑定/末活 | throws / ok / fail | 次每分(落盘→重算) | cycle_done | cycleAvgMs | 结束维度 | 锭 初始→已用 |
|---|---|---|---|---|---|---|---|---|
| `S2_B2` / n1 | 1.5006 | 1 / **0** / 0 | 0/0/0 | 0 → 0 | 0 | null | null | 128 → 0 |
| `S2_B2` / n2 | 1.5001 | 2 / **0** / 0 | 0/0/0 | 0 → 0 | 0 | null | null | 128 → **128** |
| `S2_B2` / n4 | 1.5004 | 4 / 2 / 2 | 2/2/0 | 1.33 → **1.333** | 2 | 6649 | null | 128 → 2 |
| `S2_B2` / 珍珠局1 | 8.0001 | 4 / 3 / 0 | 3/2/1 | 0.25 → 0.25 | 2 | 7057 | null | — → **192** |
| `S2_B2R3` / open·feed | 1.5004 | 4 / 2 / 0 | 2/1/1 | 0.67 → 0.666 | **0** | null | **overworld** | 160 → **160** |
| `S2_B2R3` / open·ground | 1.5002 | 4 / 2 / 0 | 1/1/0 | 0.67 → 0.667 | **0** | null | **overworld** | 160 → **160** |
| `S2_B2R3` / pen·feed | 1.5003 | 4 / **0** / 0 | 0/0/0 | 0 → 0 | **0** | null | **overworld** | 160 → **160** |
| `S2_B2R3` / **pen·ground** | 1.5005 | 4 / 2 / 0 | **900/21/879** | **14 → 13.995** | 21 | **549** | **overworld** | 160 → 160 |
| `S2_DIAG` / open·feed | 0.7504 | 4 / 1 / 0 | 1/1/0 | 1.33 → 1.333 | **0** | null | **overworld** | 160 → **160** |

落盘 `throwsPerMin` 与重算值在两格（1.33→1.333、0.67→0.666/0.667）是**四舍五入差**，不是口径差。
`S2_DIAG` 那个 1.33 次/分 = 1 ÷ 0.7504 min。

### 2.2 phases 逐项计数（字段以落盘为准）

| run / 格 | `phases`（引擎累计） | `events[].phase`（截到 80 条） |
|---|---|---|
| B2 / n1 | `bind:1` | （0 条） |
| B2 / n2 | `bind:1` | （0 条） |
| B2 / n4 | `bind:1, ok:2, out_of_range:3, rebind:1, cycle_done:2` | `ok:2, out_of_range:3, rebind:1`（6 条） |
| B2 / 珍珠局1 | `bind:1, ok:2, out_of_range:4, rebind:1, throw_retry:2, no_debit:1, throw_no_debit:1, cycle_done:2` | **无 `events` 字段**（该版本没记） |
| R3 / open·feed | `bind:1, ok:1, throw_retry:1, no_debit:1, throw_no_debit:1` | `ok:1, no_debit:1, throw_no_debit:1`（3 条） |
| R3 / open·ground | `bind:1, out_of_range:8, rebind:8, ok:1` | `out_of_range:8, rebind:8, ok:1`（17 条） |
| R3 / pen·feed | `bind:1` | （0 条） |
| **R3 / pen·ground** | `bind:1, out_of_range:33, ok:21, cycle_done:21, rebind:33, throw_not_enough:879` | `out_of_range:2, ok:21, rebind:2, throw_not_enough:55`（截断在 80 条） |
| DIAG / open·feed | `bind:1, bind_why:1, ok:1` | `ok:1`（1 条） |

出现过的 phase 名全集：`bind` `bind_why` `ok` `cycle_done` `out_of_range` `rebind`
`throw_retry` `no_debit` `throw_no_debit` `throw_not_enough`。
**没有** `cycle_miss`（引擎在落盘里没产生过；`rep.misses` 全部为 0）。

### 2.3 三个因子的定量拆解

公式（全部只用落盘字段，不引入假设）：

```
请求槽分钟 = slotsRequested × windowMin
绑定槽分钟 = bound × windowMin                      ← bound 是 bind() 那一刻的快照
理论投锭数 = 绑定槽分钟 ÷ 5.96s                     ← 5.96 = §1.3 的 drop_entity 周期
损失_绑定  = 1 − bound / slotsRequested
损失_槽时空转 = 1 − min(1, throwsOk / 理论投锭数)
损失_出手  = throwsFail / throws
```

**三个损失是串行闸门，不可相加。**

| run / 格 | 损失_绑定 | 损失_槽时空转 | 损失_出手 | 判读 |
|---|---|---|---|---|
| B2 / n1 | **100%** | n/a | n/a | 一个槽都没绑上，理论投锭数 0 |
| B2 / n2 | **100%** | n/a | n/a | 同上 |
| **B2 / n4** | 50% | **0%（实为超出）** | 0% | 2 次成交只占用绑上槽的 **6.6% 槽时**（2×5.96 = 11.9 / 180.1 槽·秒），`cycleAvgMs=6649ms` 与 B1 同量级 ⇒ **绑上的槽在 93% 的绑定时间里是死的** |
| B2 / 珍珠局1 | 25% | 50% | 33% | 8 分钟只成交 2 次，槽时利用率 **0.8%** |
| R3 / open·feed | 50% | — | 50% | `cycle_done=0`，n=1 太小 |
| R3 / open·ground | 50% | — | 0% | `cycle_done=0`，n=1 太小；`out_of_range:8 + rebind:8` |
| R3 / pen·feed | **100%** | n/a | n/a | 一个槽都没绑上 |
| **R3 / pen·ground** | 50% | **0%（超出）** | **98%**（`throw_not_enough:879`） | 21 次成交只用掉 70% 槽时；但 `cycleAvgMs=549ms` 与 B1 实测 5960ms 差 10.8× ⇒ **这一格的"成交"根本不是一次把玩周期** |
| DIAG / open·feed | **75%** | — | 0% | `cycle_done=0`；请求 4 槽只绑上 1 |

### 2.4 回答"节拍慢 / 槽位存活低 / 投锭失败多"各占多少

| 因子 | 定量结论 |
|---|---|
| **节拍** | **贡献 0。** 9 个格子里 **7 个 `cycle_done=0`**——引擎一次"把玩完成"都没记上，周期分母根本没用上。剩下 2 个有 `cycle_done` 的格子：`S2_B2/n4` 的 `cycleAvgMs=6649ms`（≈B1 的 5960ms，**节拍正常**），`S2_B2R3/pen·ground` 的 549ms（**不是把玩周期**）。 |
| **槽位存活** | **主因。** 绑定率 0/4、0/4、2/4、3/4、2/4、2/4、0/4、2/4、1/4 ⇒ **4 个格子绑定率 ≤50%，3 个格子一个槽都没绑上**。唯一能算出槽时利用率的 `S2_B2/n4`：**93% 的绑定时间是死的**。`S2_B2R3` 四格的 `out_of_range` 与 `rebind` **各 41 次**（`open·ground` 8+8、`pen·ground` 33+33，其余两格 0）。 |
| **投锭失败** | **局部主因，不是全局主因。** 只有两格有实质失败：`pen·ground` 的 98%（`throw_not_enough`，**背包空了**，不是投掷几何问题）、`open·feed` 的 50%（1 次 `no_debit`，那条事件里 `dist=125.6` 格——猪灵早走出 125 格）。其余 7 格失败率 0。 |
| **第四个因子（报告没列）** | **死亡清包。** R3 四格 + DIAG 全部记录 `dim:"overworld"`、`ingotsLeft:0`、`ingotsUsed:160`、`hp:20`，而 `throwsOk` 只有 0–1。`S2_B2R3/server.log` 记到 **5 次 `BarterBotC was slain by Piglin`**，`S2_DIAG/server.log` 1 次，`S2_B2/server.log` 3 次（`was slain by Piglin` / `drowned` / `was slain by Zombie`）⇒ **bot 死后在主世界重生继续空跑**，`rep.deaths` 全为 `[]` 是因为那版 `watchDeaths()` 写错（报告 §8.7 已自述）。**所有 90s/45s 窗口的真实"活着的下界"小于标称窗口。** |

### 2.5 占空比：算不出（UNKNOWN）

`cycle_done 次数 ÷ 该槽绑定分钟数` **不可还原**。原因：落盘里槽的绑定时刻只有 `bind()` 那一刻的聚合值
`bound`（`b2_p2_*.json#bound`），`events[]` 只有 `{slot, phase}` **没有时间戳**，引擎也没逐槽记
`bindAt` / `lastLiveAt`。
能给的上界：单槽存活分钟 ∈ `[0, windowMin]`（`bound` 是 t=0 快照，窗口末 `slotsLive` 全为 0）。
`sections 2.3` 的"损失_槽时空转"是**用聚合量算的替代指标**，不是真正的占空比。

---

## 3. bindWhy 逐候选 reason

只有 `S2_DIAG/b2_p2_open_feed.json` 落了 `bindWhy`（其余 8 格该字段不存在，已记进 `missing`）。

- 公式：`bindWhy = findTradeable()` 每次绑定尝试时对**每个候选**给一条 `{id, d, reason}`（`micro_barter.mjs:135`）
- **n = 24**，按 id 425 重新出现切成 4 轮：

| 轮 | 条数 | distance | excluded | no_los | OK | only_0_passed_need_1 |
|---|---|---|---|---|---|---|
| 0 | 3 | 2 | 0 | 0 | **1** | 0 |
| 1 | 8 | 5 | 1 | 1 | 0 | **1** |
| 2 | 8 | 5 | 1 | 1 | 0 | **1** |
| 3 | 5 | 3 | 1 | 1 | 0 | 0 |
| **合计** | **24** | **15** | **3** | **3** | **1** | **2** |

逐候选（按 id）：

| id | 出现次数 | 距离 d | reason 分布 |
|---|---|---|---|
| 425 | 4 | 0.67 | distance ×4 |
| 637 | 4 | 1.40 | distance ×4 |
| **638** | 4 | **1.85** | **OK ×1, excluded ×3** |
| 640 | 3 | 3.09 | no_los ×3 |
| 639 | 3 | 4.29 | distance ×3 |
| 427 | 2 | 9.86 | distance ×2 |
| 499 | 2 | 11.04 | distance ×2 |
| −1 | 2 | null | only_0_passed_need_1 ×2 |

**报告 §5.1 的 `x15 distance / x3 no_los / x3 excluded / x1 OK` 四个数与落盘逐个对得上。**
但它**漏了 `only_0_passed_need_1 ×2`**——而这一条恰恰是"引擎自己判定绑不上、直接放弃"的那一条
（0 个合格但需要 1 个），比 `distance` 更直接地证明"槽位活不下来"。

---

## 4. 客户端 vs 服务端口径差

两条**互不相同**的服务端通道，必须分开标：

- **通道A**（`truth.mjs:271-311 countEntities`）：`as <sel> run time query day`，`n` = 收到几行回执。
  ⚠ 报告 §8.1 第 3 轮记的那个 bug 使它在 `S2_B1` / `S2_B2` / `S2_P1_PROBE` 返回 **0**。
- **通道B**（`probe_piglin_count.mjs:41-49`）：`kill @e[type=piglin]` 的回执自带数字（破坏性，只能放最后）。
- 另外 `resetGround()` 里也有 `kill @e[type=piglin]`（`probe_b1_fiddle.mjs:41`），
  也产生 `Killed N entities` 行；**server.log 不回显命令原文**，所以单看一行无法判断它是 item 杀还是 piglin 杀。

| run | 文件 | 客户端 | 通道A（行数） | 通道B（kill 回执） | 客户端/A |
|---|---|---|---|---|---|
| `S2_B2R2` | `b2_p1_setup.json` | **62**（`stand.piglinsInView`） | **63**（`piglins.n`） | — | 0.98 |
| `S2_B2R2` | `b2_p0_selfcheck.json` | — | 62 | — | — |
| `S2_B2R3` | `b2_p1_setup.json` | 72 | 77 | — | 0.94 |
| `S2_B2R3` | `b2_p0_selfcheck.json` | — | 73 | — | — |
| `S2_DIAG` | `b2_p1_setup.json` | 78 | 76 | — | 1.03 |
| `S2_DIAG` | `b2_p0_selfcheck.json` | — | 78 | — | — |
| `S2_P1_PROBE` | `p4_piglin_count_peaceful.json` | 28 | — | **28**（`Killed 28 entities`） | 1.00 |
| `S2_P1_PROBE` | `p1_piglin_count_easy.json` | 57 | — | — | — |
| `S2_P1_PROBE` | `p3_piglin_count_authoritative.json` | 57 | — | `null`（`(no kill receipt)`） | — |
| `S2_P1_PROBE` | `p3_piglin_count_crosscheck.json` | 59 | **0**（坏读数） | `null`（`No entity was found`） | — |
| `S2_P1_PROBE` | `p1b_stand.json` | 64 | — | — | — |
| `S2_B1` | `b1_p1_setup.json` | **47** | **0**（坏读数） | — | — |

**同 run、同坐标、同时刻的配对，全部比值都在 0.94–1.03**（62/63、72/77、78/76、28/28）。
**没有落盘证据支持"客户端 62 / 服务端 8–11"**：62 在 `S2_B2R2`，与它同文件的服务端数是 **63**；
8–11 那批 `Killed N entities` 来自 `S2_B1`（**旧中心 288,240**）的 `resetGround`，是另一个 run、另一个坐标。

`server.log` 里的 `Killed N entities` 分布（不区分 item 杀 / piglin 杀）：

| run | 条数 | min–max | 死亡行（`server.log`） |
|---|---|---|---|
| `S2_B1` | 30 | 2 – 59 | 无 |
| `S2_B2` | 3 | 3 – 16 | `was slain by Piglin` / `drowned` / `was slain by Zombie` |
| `S2_B2R2` | 2 | 5 – 16 | `was slain by Hoglin` |
| `S2_B2R3` | 5 | 3 – 19 | `was slain by Piglin` ×5 |
| `S2_DIAG` | 1 | 17 | `was slain by Piglin` |
| `S2_P1_PROBE` | 1 | 28 | 无 |

---

## 5. B4 锭珠比为什么算不出来

**两个互相独立的原因叠加**：

1. **掉落物身份读不出**（"是什么、几个"）
2. **珍珠本身全是 0**（没有分子）

证据字段（全部落盘）：

| 文件 | 字段 | 落盘值 | 说明 |
|---|---|---|---|
| `S2_B1/b1_p4_trials.json` | `sum.dropItems` | `{"?": 14}` | 落盘按"全部 14 条有周期的成交"计数；其中**只有 7 条真的有 `drop` 对象**，另 7 条 `drop` 为 `null`（被 `?? '?'` 归到同一个键）⇒ 两边都是"?" |
| 同上 | `trials[].drop.name` / `.count` | 7 条有 `drop` 的行：name 恒 `"?"`、count 恒 `0` | 读到了"有一个掉落物实体"，读不出是什么 |
| 同上 | `sum.dropTruthOK` | **0** | 服务端 `ItemEntity.Age` 一条没读到 |
| 同上 | `trials[].dropTruth` | `ageTicks:null, gametimeAtRead:1240/1840/…` | 服务端真值这条路也没通 |
| 同上 | `sum.sameTickCount` / `trials[].hand.main` | **0** / 恒 `"no_receipt"` | `HandItems` 通道没通（真因见报告 §8.4 的 `run at` 拼接 bug） |
| `S2_B1/b1_p2_drop_control.json` | `newDropNames` | `["?"]` | 🚨 **bot 自己按 Q 丢的金锭（已知是 `gold_ingot`）也读成 `"?"`** ⇒ 与猪灵无关，是读数通道本身的问题 |
| `S2_B2/b2_p2_n4.json` | `rep.drops` | `{"?": 2}` | 引擎侧 `stats.drops` 同样只有 `"?"` 键 |
| `S2_B2R3/b2_p2_pen_ground.json` | `rep.drops` | `{"?": 21}` | 21 次成交的掉落物同样全部 `"?"` |

B4 汇总本身（三个局 `b2_p3_b4.json`）：

| run | throws | ingotsUsed | pearls | pearlsPerIngot | ci95 hi |
|---|---|---|---|---|---|
| `S2_B2` | 2 | 2 | **0** | 0 | 0.6576 |
| `S2_B2R3` | 23 | 640 | **0** | 0 | 0.0060 |
| `S2_DIAG` | 1 | 160 | **0** | 0 | 0.0234 |

理论 0.2837 珍珠/锭**无从对比**：即便掉落物名字读得出来，这三局的分子也是 0。

---

## 6. 与 MC-S2-01.md 不一致（逐条并排）

**我把落盘信的写左边，报告信的写右边。** 每条都注明"我更信哪个、为什么"。

### 6.1 周期：119 tick / 5.95s 的 n 写错了，且不是落盘 headline

| | 报告 | 落盘重算 | 我信谁 |
|---|---|---|---|
| headline 周期 | **5.95 s = 119 tick**，标注 n=14（§0/§1/§4.3） | `summary.json#cycle` = **6.20 s = 124 tick**，n=14 | **落盘**（这是脚本自己写的汇总字段，可复现） |
| 子集 | — | `drop_entity` 子集 n=**7**、mean **5.96 s = 119 tick**、p10/p50/p90 = 5.95/5.95/5.96 | 落盘子集 |
| p10/p50/p90 | 5.93 / 5.96 / 5.98（§4.1，n=14） | drop_entity(7)：5.95 / 5.95 / 5.96；混口径(14)：5.95 / 6.42 / 6.47 | 落盘 |

**差 0.01 s（0.17%），量级一致**，所以不是数据错，是**口径标注错**：119 tick 只在 n=7 的
`drop_entity` 子集上成立，报告把它标成了 n=14。
⇒ **对外引用请写"119 tick = 5.96s（n=7，掉落物实体口径）"，落盘汇总口径是 124 tick。**

### 6.2 纯把玩：三个口径 107 / 112 / 117 tick，报告同时用了其中两个

| | 报告 | 落盘重算 | 我信谁 |
|---|---|---|---|
| 纯把玩 | **5.33–5.39 s / 107–108 tick，n=7**（§4.3） | `drop_entity` 口径 5.36 s / **107 tick** | 落盘（这条对得上） |
| "混口径参考" | **5.60 s / 112 tick / n=7**（§4.3，标为"汇总里混在一起算的"） | `summary.json#fiddle` = 5.60 / **112 tick** / n=7 | 落盘（这条也对得上） |
| 逐样本配对 | 报告没给 | 5.85 s / **117 tick** / n=7，**7 条全是 `inv_delta`** | 只有这个不能当"纯把玩" |

问题不在数，在 **`n=7` 这个标注被两个不同口径共用**：112 tick 那条的 n=7 是"捡起延迟的样本数"，
107 tick 那条的 n=7 是"掉落物周期的样本数"，两者是**不同的 7 条**。
⇒ 下一轮必须把"纯把玩"的 n 和 dealBy 写清楚，否则两个数会被当成互相印证。

### 6.3 "掉落物 14/14 次都出现" 与落盘不符

| | 报告 | 落盘重算 | 我信谁 |
|---|---|---|---|
| 掉落物出现 | **14/14 次（`dealBy: drop_entity`）**（§4.1/§1） | 14 条有周期的成交里：`drop_entity` **7** 条、`inv_delta` **7** 条；另有 **5 条 `dealBy:"none"`** | 落盘 |
| 借记 | 14/14 | 出手成功 **19** 条全部 −1（19/19） | 落盘（报告的分母偏保守） |

⇒ "14/14" 实际是"14 条测到周期的成交里 7 条看到了掉落物实体"。
报告 §4.1 脚注承认了"其中 4 次是近距离档靠背包增量判的"，但表格和摘要仍写 14/14，
而落盘是 **7/7 对 7/7**。这两条要统一。

### 6.4 "三轮 B1 合计 40+ 次成交" 落盘不支持

| | 报告 | 落盘重算 | 我信谁 |
|---|---|---|---|
| B1 成交总量 | **40+ 次**（§4.3，"三轮 B1"） | 落盘只有两份 trials 文件：`b1_p3_trials.json`（`nOk=0`，20/20 全 `no_los`/`too_far`）+ `b1_p4_trials.json`（`nOk=19`、`有周期 14`）⇒ **合计 19 次出手成功** | 落盘 |

⇒ "40+" 在 `runs/S2_B1/` 里**找不到支撑**。可能另有轮次的文件没落盘，但按现有落盘只能说 19。

### 6.5 掉落物距 bot 的区间

| | 报告 | 落盘重算（7 条 `drop_entity`） | 我信谁 |
|---|---|---|---|
| 距 bot | 3.15 – 3.39 格 | **3.18 / 3.21 / 3.25 / 3.25 / 3.25 / 3.25 / 3.29** ⇒ 区间 3.18–3.29 | 落盘（区间两端都窄于报告） |
| 距猪灵 | 1.44 格 | 1.44 ×7 | 一致 |

差 0.1 格（≤3%），**不构成矛盾**，但报告的区间比落盘宽。

### 6.6 🚨 "客户端 62 / 服务端 8–11，同一时刻同一坐标" 站不住

| | 报告（§2.3 / §10.3） | 落盘重算 | 我信谁 |
|---|---|---|---|
| 客户端 62 | 与服务端 8–11 配对 | 62 来自 `S2_B2R2/b2_p1_setup.json#stand.piglinsInView`；**同一文件里服务端数是 63** | 落盘 |
| 服务端 8–11 | 同一时刻同一坐标 | 8–11 那批 `Killed N entities` 来自 `S2_B1/server.log`（**旧中心 288,240**），且 `S2_B1` 的 `b1_p1_setup.piglins.n`（通道A）是 **0**（坏读数） | 落盘 |
| §10.3 证据 | `runs/S2_B1/summary.json#clientPiglins=60` | `S2_B1/summary.json` **顶层没有 `clientPiglins`**；该值只嵌在 `summary.json#phases[].clientPiglins = **47**` | 落盘 |

⇒ 这不是"差几个数"，是**把两个不同 run、不同坐标、不同通道的数并成了一组**。
落盘里所有**真正同 run 同坐标**的配对比值都在 **0.94–1.03**。
⇒ 手册 §5 那条"密度计数一律走服务端"的方向没错，但**用它给出的 62 vs 8–11 这个例子要撤回**。

### 6.7 猪灵数 "62–77" 与 "B1 easy 57–64"

| | 报告 | 落盘重算 | 我信谁 |
|---|---|---|---|
| 新中心 [336,256] 服务端 | **62–77 头**（§5.1，引 `b2_p0_selfcheck.json`） | `S2_B2R3/b2_p0_selfcheck.json` = **73**；`b2_p1_setup` = 77；`S2_DIAG` = 78 / 76 | 落盘（该区间下界 62 在 `b2_p0_selfcheck` 里不存在） |
| B1 easy 客户端 | **57–64**（§4.5） | 57/59/64 在 **`S2_P1_PROBE`**；`S2_B1` 自己的 `clientPiglins` = **47** | 落盘（47 未被报告列出） |
| B1 easy 服务端 | `Killed 16 / Killed 59` | `S2_B1/server.log` 里 16 与 59 确实都在，但那是 30 条 `Killed N entities`（2–59）里的两条，**无法逐行归因到 item 杀还是 piglin 杀** | 落盘（数值存在，归因 UNKNOWN） |

### 6.8 🚨🚨 第二轮矩阵漏了 `pen/ground` 一整格

| | 报告（§5.1 表格） | 落盘重算 | 我信谁 |
|---|---|---|---|
| open/feed | 0.67 | 0.666（`throwsOk=1/2`） | 一致 |
| open/ground | 0.67 | 0.667（`throwsOk=1/1`，`out_of_range:8 rebind:8`） | 一致 |
| pen/feed | 0（0/0 投锭） | 0（`bound=0`） | 一致 |
| **pen/ground** | **表格里没有这一行** | **`throwsOk=21/900`，`throwsPerMin=14.0`，`cycle_done=21`，`cycleAvgMs=549ms`，`throw_not_enough=879`，`drops={"?":21}`** | 落盘 |
| DIAG | 1.33 | 1.333 | 一致 |

⇒ **14.0 次/分是全部落盘数据里最高的吞吐格，报告的矩阵没有它。**
同时必须打上两条限定（否则会误读）：
① 它的 `cycleAvgMs=549ms` 与 B1 实测 5960ms 差 10.8× ⇒ **这 21 次"成交"不是 21 次把玩**，
   不能拿来当易物机制成立的证据；
② 它 `throwsFail/throws = 98%`，全是被 `throw_not_enough` 挡掉的——**不是投掷几何失败，是背包空了**。
⇒ 下一轮要么把它从报告里补上并加限定，要么说明它为什么被排除（报告未给理由）。

### 6.9 bindWhy：四个数对得上，漏了一条

| | 报告 | 落盘重算 | 我信谁 |
|---|---|---|---|
| distance / no_los / excluded / OK | 15 / 3 / 3 / 1 | 15 / 3 / 3 / 1 | 一致 |
| `only_0_passed_need_1` | 未列 | **2** | 落盘（应补） |

### 6.10 标定链断点（报告未提，但影响所有吞吐数的可比性）

`micro_barter.mjs:40-54 loadPrimitives()` 读三个文件，落盘核对结果：

| 读的文件 | 落盘实际 | 后果 |
|---|---|---|
| `S2_P1_PROBE/p2b_throw_calib.json#holdingIdx` | `null`（整个文件是 `{"ok":false,"why":"no_target"}`） | `applyCalibration()` **根本没被调用**；而 `rep.calibrated` 仍写 `true`（那是引擎的另一个标志位，不代表标定生效） |
| `S2_B1/b1_p4_trials.json#sum.cycle.mean` | `6.2`（混口径） | `cfg.cycleMs = 6200ms`（落盘值），比 `drop_entity` 口径的 5960ms **系统性偏大 4%** |
| `S2_B1/b1_p2_distance.json#distRows` | 5 条，**0 条 ok**（4×`no_los` + 1×`too_far`），是**更早一轮的失败数据** | 🚨 **落盘文件名与源码对不上**：`micro_barter.mjs:44` 读的是 `b1_p2_distance.json`，而有成交距离标定的那份叫 **`b1_p3_distance.json`**（5 条 4 ok，最佳 `dist0=2.83` / `cycleSec=5.92`） |
| ⇒ | `cfg.bestDist = null` | 引擎一直用**默认距离窗 1.4–3.2 格**，不是实测最佳档 2.8–3.4 格 |

`resultingCfg`（落盘 `b2_p1_setup.json#cfg`）：
`S2_B2R3` 与 `S2_DIAG` 完全相同 = `{holdingIdx:null, pickupDelayMs:1000, minDist:1.4, maxDist:3.2, cycleMs:6200, bestDist:null}`；
`S2_B2`（首轮）= `{…, pickupDelayMs:null, cycleMs:null}` ⇒ **首轮根本没吃到 B1 标定**。

---

## 7. 数据里拿不到、只能报 UNKNOWN 的量

| 量 | 值 | 原因 |
|---|---|---|
| **每槽占空比**（`cycle_done ÷ 该槽绑定分钟数`） | `null` | `bound` 只是 t=0 快照；`events[]` 无时间戳；无逐槽 `bindAt`/`lastLiveAt` |
| **猪灵走出投掷窗的时刻** | `null` | 同上，只有 `out_of_range`/`rebind` 的**次数** |
| **槽位绑定的绝对时刻 / 存活时长** | `null` | 引擎未落盘 |
| **`cycleTimeoutMs` 实际取值** | `null` | 落盘只有输入 `cfg.cycleMs=6200`；`max(14000, 6200×2.5)=15500ms` 是**按 `micro_barter.mjs:110` 推算**，不是落盘值 |
| **掉落物真实名字 / 堆数** | `null` | 落盘只有 `"?"` 与 `0`；根因需读 `piglin.js` 的 `itemOf`，而该文件在 `mindcraft-wt/s2-barter`（**本单禁读**） |
| **服务端 `ItemEntity.Age` 精确 tick** | `null` | `dropTruthOK=0`，全部 `ageTicks:null` |
| **猪灵 `HandItems` 持有区间 / 副手清空 tick** | `null` | 全部 `no_receipt`（`run at` 拼接 bug，报告 §8.4） |
| **`Killed N entities` 每行是 item 杀还是 piglin 杀** | `null` | `server.log` **不回显命令原文** |
| **`rep.deaths` 的真实死亡** | 全 `[]` | 那版 `watchDeaths()` 与真值通道抢日志偏移（报告 §8.7）；本单改用 `server.log` 正则补齐 |
| **B2 全部格子的 bindWhy** | 只有 DIAG 一格有 | 其余 8 格该字段不存在（已进 `missing`） |
| **`S2_B2R3` / `S2_DIAG` 的结束维度** | 记录为 `overworld` | 这是**死亡后主世界重生的读数**，不是"作业维度"；`S2_B2` 首轮该字段为 `null`（当时还没记） |
| **各格"bot 活着的时间"** | `null` | 窗口分钟是标称值；死亡时刻只能从 `server.log` 的时间戳与 `record` 的 `at` 粗对齐，**不做精确插值** |

---

## 8. 给下一轮的对比基准（5 条）

下一轮跑完，直接拿这 5 条跟今天这批比。**每条都写清"比什么、判据、今天的数"。**

### ① 周期：分口径报，n 必须写清

| 口径 | 今天（`S2_B1/b1_p4_trials.json`） | 下一轮判据 |
|---|---|---|
| `drop_entity` 周期 | **n=7，mean 5.96 s = 119 tick，p10/p50/p90 = 5.95/5.95/5.96** | 落进 **5.90–6.05 s（118–121 tick）** 即算复现；`n ≥ 7` |
| `inv_delta` 周期 | n=7，mean 6.45 s = 129 tick | 与 `drop_entity` 的差应稳定在 **+0.45–0.55 s**（= 掉落物 `pickupDelay` 10 tick）；差值变大就要查 `pickupDelay` |
| 混口径 | n=14，mean 6.20 s = 124 tick | **不要**再拿混口径数当"周期"对外引用 |
| 纯把玩 | `drop_entity` 口径 5.36 s / **107 tick** | 只能这样报（`drop_entity` 行没有 `pickupDelay` 读数）；若下一轮能同时测到两者，改报逐样本配对 |

### ② 绑定率与槽时利用率（比 `throwsPerMin` 更早失败）

今天：`S2_DIAG` 绑定率 **1/4 = 25%**；`S2_B2/n4` 2 次成交只占 **7% 槽时**（⇒ 93% 死槽）。
下一轮判据：**`bound/slotsRequested ≥ 0.75`** 且 **槽时利用率 ≥ 50%**。
⚠ 下一轮落盘必须记**逐槽 `bindAt` / 丢槽时刻**，否则占空比还是 UNKNOWN（今天就是）。

### ③ `cycle_done` 必须出现，且自报周期要对上 B1

今天：**9 个格子里 7 个 `cycle_done = 0`**；有 `cycle_done` 的两格是 6649ms（≈5960ms ✓）与 **549ms（✗ 差 10.8×）**。
下一轮判据：每一格 `cyclesN > 0` **且** `cycleAvgMs ∈ [5960×0.8, 5960×1.2] = [4.8s, 7.2s]`。
**`cycleAvgMs` 远小于 6 s 的格子 = 成交判据坏了，不能算吞吐**（今天的 `pen/ground` 就是这样）。

### ④ 死亡：每格单独看 `server.log`，别看 `rep.deaths`

今天：`S2_B2R3` **5 次** `was slain by Piglin`、`S2_DIAG` 1 次、`S2_B2` 3 次（含 `drowned` / `Zombie`）；
4 个 R3 格子 + DIAG **全部** `dim:"overworld"` + `ingotsUsed:160` + `throwsOk ≤ 1`。
下一轮判据：**任一格出现 `was slain by` 即判该格作废**；同时要求 `dim == "the_nether"` 贯穿整个窗口。
配套：`throw_not_enough` 占比（今天 `pen/ground` 98%）必须 **< 5%**，否则是背包空了而不是机制问题。

### ⑤ 标定链与猪灵数：先修三处，再谈吞吐对比

下一轮开跑前必须先确认（今天三条都断了）：
1. `micro_barter.mjs:44` 读 `b1_p2_distance.json` → 改成读有成交的那份（今天 `bestDist=null`，引擎一直用 1.4–3.2 默认窗，不是实测最佳 2.8–3.4）；
2. `cfg.cycleMs` 从**混口径 6.2 s** 改成 **`drop_entity` 口径 5.96 s**（今天偏大 4%）；
3. `holdingIdx` 为 null 时 `rep.calibrated` **不许写 `true`**（今天标定没生效却报 true）。
猪灵数对照：今天**同 run 同坐标**的客户端/服务端比值 **0.94–1.03**（62/63、72/77、78/76、28/28）——
下一轮若比值 > 1.5 或 < 0.67，才说明"客户端实体表 ≠ 服务端真值"这条经验在 S2 站位上仍成立；
**不要**再拿不同 run 的数配对。
