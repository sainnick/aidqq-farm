// probe_b5_chest_gold.mjs — MC-S2-01 · B5：主种子堡垒的金锭来源（服务端真值，不让 bot 透视）
//
// 问题（RESEARCH-03 B5 / stage-02 §0）：「堡垒 treasure 箱 12.85 锭/箱，需 ~4 箱达 46 锭」是
// **loot table 期望**，含方差。route 只记了区域内 `chest:5` 这个**计数**，没有位置、没有内容。
//
// 口径（派单 §F「不要让 bot 透视」）：
//   **全程不读 bot 的方块/容器视图**。定位与读数都走 fill 回执 + data get，两局分工：
//   · 世界①（可弃）：`fill <盒> <marker> replace chest` 是**破坏性**的，只能用它二分定位；
//   · 世界②（同种子 fresh world，地形确定）：在①记下的坐标上 `data get block … Items`
//     **非破坏性**读战利品 + `LootTable` 读箱型（treasure / bridge / hoglin_stable…）。
//   ⚠ 1.16.1 无 /forceload ⇒ 两局都必须先把 bot tp 过去让区块自然加载。
//   ⚠ 顺带数清 gold_block / gilded_blackstone：route 的 22 块金块 = 198 锭，
//     比"4 箱开 46 锭"大一个量级 —— 但挖金块会激怒猪灵（stage-02 §0 风险表），要一起报。
//
// 泳道只有 C。用法：node probe_b5_chest_gold.mjs [--stamp S2_B5] [--margin 8]
//
// ★ S2-04：盒**以 S3 scout 的金块/宝箱包围盒为中心、比它大一圈**（默认 margin ±8），
//   不再从站中心往 +x/+z 铺。理由见下面 BOX 定义处的注释。
//   S3 坐标来源（**只读引用**，不修改 C 线文件）：
//   `bench/route/probe/bastion.round4c.json`（C 线 MC-ROUND4-C「堡垒类型/金块/宝箱」，交给 F 线 B5）

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
    openRun, bootWorld, stopWorld, closeRun, cmd, truth, bot, botPos, posStr,
    tpNether, record, writeSummary, sleep, STATION, SEED, argv, LANE,
} from './harness.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const S3_PATH = path.resolve(HERE, '..', '..', 'route', 'probe', 'bastion.round4c.json');

const STAMP = argv('stamp', 'S2_B5');
const S = STATION.bastion;
const vol = (b) => (b.x2 - b.x1 + 1) * (b.y2 - b.y1 + 1) * (b.z2 - b.z1 + 1);

/**
 * 🚨 **S2-04 更正（S2-03 §3.4 的 B5 结论作废在此）**：S2-03 的盒
 *   `{x:336..368, y:32..47, z:256..288}` 是**从站中心往 +x/+z 铺**的，
 *   只擦到堡垒一角 ⇒ 那个盒里 chest 0 / gold_block 0 **不能推出"新中心没有堡垒"**。
 *   C 线 scout（`bench/route/probe/bastion.round4c.json`，主种子 4926685115947721762）
 *   用存档解析器给出的真实金源坐标是 **x322–361 / y33–80 / z217–265**
 *   （gold_block 22 处、chest 5 处）——**与本盒几乎不重叠**。
 *
 * 本单按设计会话要求：**盒以目标（S3 scout 金块/宝箱坐标的包围盒）为中心、比目标大一圈**。
 * 包围盒由 S3 坐标现算（不硬编码），margin 默认 ±8 格（手册 §5「扫描范围要比目标大一圈，
 * 并检查边界上有没有命中」）。TP 落在**金源重心正上方**，让区块自然加载。
 */
const S3 = JSON.parse(fs.readFileSync(S3_PATH, 'utf8'));
const s3Pts = [
    ...(S3.goldBlockPoints ?? []).map((p) => ({ ...p, kind: 'gold_block' })),
    ...(S3.chestPoints ?? []).map((p) => ({ ...p, kind: 'chest' })),
];
function bboxOf(pts) {
    const xs = pts.map((p) => p.x), ys = pts.map((p) => p.y), zs = pts.map((p) => p.z);
    return {
        x1: Math.min(...xs), y1: Math.min(...ys), z1: Math.min(...zs),
        x2: Math.max(...xs), y2: Math.max(...ys), z2: Math.max(...zs),
    };
}
const MARGIN = parseInt(argv('margin', '8'), 10);
const S3_BBOX = bboxOf(s3Pts);
const BOX = {
    x1: S3_BBOX.x1 - MARGIN, y1: S3_BBOX.y1 - MARGIN, z1: S3_BBOX.z1 - MARGIN,
    x2: S3_BBOX.x2 + MARGIN, y2: S3_BBOX.y2 + MARGIN, z2: S3_BBOX.z2 + MARGIN,
};
// TP 落在金源包围盒的**水平中心**、盒顶上方 6 格（保缓降后落进已加载的列柱）
const TP = {
    x: Math.round((S3_BBOX.x1 + S3_BBOX.x2) / 2),
    y: BOX.y2 + 6,
    z: Math.round((S3_BBOX.z1 + S3_BBOX.z2) / 2),
};

function splitBox(b) {
    const mx = Math.floor((b.x1 + b.x2) / 2), my = Math.floor((b.y1 + b.y2) / 2), mz = Math.floor((b.z1 + b.z2) / 2);
    const out = [];
    for (const [x1, x2] of [[b.x1, mx], [mx + 1, b.x2]]) {
        for (const [y1, y2] of [[b.y1, my], [my + 1, b.y2]]) {
            for (const [z1, z2] of [[b.z1, mz], [mz + 1, b.z2]]) {
                if (x1 > x2 || y1 > y2 || z1 > z2) continue;
                out.push({ x1, y1, z1, x2, y2, z2 });
            }
        }
    }
    return out;
}

/** 破坏性二分定位：把目标方块换成 marker，按回执计数递归细分到 1×1×1。返回坐标列表。 */
async function locateBlocks(dim, box, blockName, { budget = 900, marker = 'minecraft:barrier' } = {}) {
    const t = truth();
    const found = [];
    let fills = 0, boxes = 0;
    const stack = [box];
    while (stack.length) {
        if (fills >= budget) { console.log(`[locate] 预算耗尽，剩 ${stack.length} 个待查盒`); break; }
        const b = stack.pop();
        boxes++;
        const n = await t.fillCount(dim, b, blockName, { marker, timeoutMs: 30000 });
        fills++;
        if (n === 0) continue;
        if (vol(b) === 1) { found.push({ x: b.x1, y: b.y1, z: b.z1 }); continue; }
        for (const s of splitBox(b)) stack.push(s);
    }
    return { found, fills, boxes, budgetHit: fills >= budget };
}

/** 解析 `Items: [{Count:6b, Slot:0b, id:"minecraft:gold_ingot"}, …]`
 *
 * ⚠ **S2-04 修：`id:` 后面有空格**。1.16.1 实发形态是 `{Slot: 0b, id: "minecraft:gold_ingot", Count: 64b}`
 * （见 `truth.mjs#parseArmorNbt` 踩过的同一个坑，实服日志 `S2_S4A/server.log` 10:43:12）。
 * 原写法 `/id:"minecraft:…"/`（无空格）⇒ **解析出 0 件**，而回执明明在手上 ⇒
 * "宝箱是空的"这个结论会是**假的**。
 * ⇒ 两种形态都收（`\s*`），并保留 `raw` 原文供复核。
 */
function parseItems(line) {
    const out = [];
    if (!line) return out;
    const body = /Items:\s*(\[[\s\S]*?\])(?:,|\s*$)/.exec(line)
        // 1.16.1 实发：`data get block <pos> Items` 的回执可能**没有 `Items:` 标签**（数组即根值）
        ?? /(?:block data:\s*)?(\[\{[\s\S]*\}\])/.exec(line);
    const src = body ? body[1] : null;
    if (!src) return out;
    for (const grp of src.split(/\},\s*\{/)) {
        const id = /id:\s*"minecraft:([a-z_0-9]+)"/.exec(grp)?.[1];
        const count = /Count:\s*(\d+)[bsl]?/.exec(grp)?.[1];
        if (id) out.push({ name: id, count: count ? parseInt(count, 10) : 1 });
    }
    return out;
}

async function bootAndPark(difficulty) {
    await bootWorld({ difficulty });
    // ★ S2-03：**必须先给缓降/抗性再 tp**。B5 首次跑就是**没给** ⇒ bot 从 y=53 自由落体，
    //   等 `selfCheck` 发 fill 时人已经不在那根列柱上 ⇒ 服务端回 `That position is not loaded`
    //   ⇒ **`fill` 类 6s 等不到回执 → 整条真值通道判死（TRUTH_POISONED）** ⇒ 0.9 分钟整局结束。
    //   （parkSafe 一直有这两条，B5 这条路径漏了。）
    cmd(`effect give ${LANE.username} minecraft:slow_falling 120 0 true`);
    cmd(`effect give ${LANE.username} minecraft:resistance 120 4 true`);
    await sleep(700);
    await tpNether(TP.x, TP.y, TP.z);
    await sleep(6000);
    // 落位复核：还在那根列柱上吗？不在就再 tp 一次（区块没加载 = 后面所有 fill 都白跑）
    let p = botPos();
    if (!p || Math.abs(p.x - TP.x) > 2 || Math.abs(p.z - TP.z) > 2) {
        console.log(`[boot ${difficulty}] 落位偏了（${posStr(p)}）⇒ 重 tp`);
        cmd(`effect give ${LANE.username} minecraft:slow_falling 120 0 true`);
        await tpNether(TP.x, TP.y, TP.z);
        await sleep(4000);
        p = botPos();
    }
    console.log(`[boot ${difficulty}] dim=${bot()?.game?.dimension} pos=${posStr(p)}（落位列柱 ${TP.x},${TP.z} 已加载）`);
    return p;
}

async function main() {
    await openRun(STAMP);
    let summary = {};
    try {
        // ── 世界①：破坏性定位 ─────────────────────────────────────────────
        await bootAndPark('easy');
        const t = truth();

        // 通道自检（先证伪工具，再采数）
        // ★ 传 `atEntity`（B5 首次跑没传 ⇒ `countEntities` 报 NEED_AT_ENTITY，白丢一个通道自检）
    const sc = await t.selfCheck({ dim: 'the_nether', at: botPos(), atEntity: LANE.username });
        record('b5_p0_selfcheck', { selfCheck: sc });
        console.log('[selfcheck]', JSON.stringify(sc));

        // 区域粗计（route 记的是 chest:5 / gold_block:22 / gilded_blackstone:227）
        // 🚨 **必须按 y 切片**（S2-04 踩过）：新盒 56×64×65 = **232,960 格**，
        //   一次 `fill` 扫这么大，服务端 40 秒**回不出回执** ⇒ `TRUTH_POISONED` 整条通道判死
        //   （`runs/S2_S4B5/error.json`）。旧盒只有 17,424 格所以没暴露。
        //   ⇒ 按 y 每 `SLICE_H` 层一片，**片内体积控制在 8 万格以内**，
        //   逐片求和。单片失败**软失败**（soft）并如实记 `partial`，
        //   **不让一片超时把整条真值通道打死**（那会丢掉后面所有读数）。
        const SLICE_H = 8;
        const ySlices = [];
        for (let y = BOX.y1; y <= BOX.y2; y += SLICE_H) ySlices.push({ y1: y, y2: Math.min(y + SLICE_H - 1, BOX.y2) });
        const coarse = {};
        const coarseDetail = {};
        for (const b of ['minecraft:chest', 'minecraft:trapped_chest', 'minecraft:gold_block', 'minecraft:gilded_blackstone', 'minecraft:basalt', 'minecraft:blackstone']) {
            let sum = 0; const per = []; let failedSlices = 0;
            for (const s of ySlices) {
                const sub = { x1: BOX.x1, y1: s.y1, z1: BOX.z1, x2: BOX.x2, y2: s.y2, z2: BOX.z2 };
                // ⚠ soft=true：单片读不到只记 0 + 计数，**不 poison**
                const n = await t.fillCount('the_nether', sub, b, { marker: 'minecraft:barrier', timeoutMs: 25000, soft: true });
                if (n == null) { failedSlices++; per.push({ ...s, n: null }); }
                else { sum += n; per.push({ ...s, n }); }
                await sleep(120);
            }
            coarse[b] = sum;
            coarseDetail[b] = { total: sum, slices: per, failedSlices, partial: failedSlices > 0 };
            console.log(`[coarse] ${b} = ${sum}（${ySlices.length} 片，失败 ${failedSlices}）`);
        }
        record('b5_p1_coarse', {
            box: BOX, s3BBox: S3_BBOX, margin: MARGIN, coarse, coarseDetail, ySlices,
            note: '破坏性计数（世界①可弃）；marker 留在原地不影响世界②。'
                + '★ S2-04：BOX 现以 S3 scout 金源包围盒为中心、四周大一圈（margin），'
                + '不再从站中心往 +x/+z 铺。★ 盒体积 232,960 格 ⇒ 必须按 y 切片（单片 ≤8 万格），'
                + '整盒一次 fill 会 40s 无回执 → 通道判死。'
                + '⚠ partial=true 的方块计数是**下界**（有片没读到），报告要标注。',
        });

        // ── ★ S2-04 新增：S3 存档坐标 × 服务端真值 **逐格双通道对账** ──────
        // 为什么加这条：设计会话指出 S2-03 的 B5 盒"只擦到堡垒一角" ⇒ chest 0 / gold_block 0
        //   **不能**推出"新中心没有堡垒"。本单不再只信盒内计数，而是**拿 C 线存档解析器给出的
        //   27 个精确坐标**去服务端逐格验：存档说有，服务端是不是真说有？
        // 手册 §5「扫描或核验工具读出"全零"时，先证伪工具，再证伪世界」+ B 线 r13 的教训
        //   （单通道读数只能当线索）。
        // 探法用 `probeCell`（`fill <单格> marker replace <块>` 然后换回来）：**非破坏**，
        //   1×1×1 盒不递归，便宜且精确；`restoreOk` 记换回是否成功。
        const s3Verify = { checked: 0, agree: 0, missing: [], restoreFail: [] };
        for (const p of s3Pts) {
            const want = p.kind === 'chest' ? 'minecraft:chest' : 'minecraft:gold_block';
            const r = await t.probeCell('the_nether', p, [want, 'minecraft:trapped_chest']);
            s3Verify.checked++;
            if (!r) { s3Verify.missing.push({ ...p, want, why: '服务端这两格都不是' }); }
            else {
                s3Verify.agree++;
                if (r.restoreOk === false) s3Verify.restoreFail.push({ ...p, hit: r.hit });
            }
            await sleep(80);
        }
        record('b5_p1b_s3_verify', {
            s3Source: path.relative(path.resolve(HERE, '..', '..'), S3_PATH),
            s3Expected: { gold_block: (S3.goldBlockPoints ?? []).length, chest: (S3.chestPoints ?? []).length },
            ...s3Verify,
            note: '存档解析器坐标 vs 服务端 fill 单格探针；agree 应等于 checked，missing>0 才是真差异',
        });
        console.log(`[S3 对账] checked=${s3Verify.checked} agree=${s3Verify.agree} missing=${s3Verify.missing.length} restoreFail=${s3Verify.restoreFail.length}`);
        if (s3Verify.missing.length) {
            console.log('[S3 对账] 服务端没找到的：', JSON.stringify(s3Verify.missing.slice(0, 10)));
        }

        // 递归二分只对**盒内但不在 S3 坐标里**的方块有意义 ⇒ 默认关（`--locate` 才开）。
        // 理由：新盒体积 = 232,960 格（旧的 13 倍），递归二分要几百次 fill，且**它只能证明
        //   "盒里有"，不能回答"存档坐标对不对"** —— 后者才是本单要的东西。
        const loc = {};
        if (argv('locate', '') !== '') {
            for (const b of ['minecraft:chest', 'minecraft:gold_block']) {
                const r = await locateBlocks('the_nether', BOX, b);
                loc[b] = r;
                console.log(`[locate] ${b}: ${r.found.length} 处, ${r.fills} 次 fill`);
                record(`b5_p2_locate_${b.replace('minecraft:', '')}`, r);
            }
        } else {
            console.log('[locate] 跳过（新盒太大且不能回答本单问题；需要时加 --locate）');
        }

        // ── 世界②：同种子 fresh world，非破坏读战利品 ─────────────────────
        await stopWorld();
        await bootAndPark('easy');
        const t2 = truth();

        // ★ S2-04：读战利品的坐标来自 **S3 存档解析器**（不是破坏性二分）——
        //   世界① 的 marker 还在，但 fresh world 地形确定 ⇒ 世界② 就是 S3-03 原始状态。
        const chestPts = (S3.chestPoints ?? []).map((p) => ({ x: p.x, y: p.y, z: p.z }));
        const goldPts = (S3.goldBlockPoints ?? []).map((p) => ({ x: p.x, y: p.y, z: p.z }));
        console.log(`[世界②] 读 ${chestPts.length} 个宝箱 + ${goldPts.length} 个金块（S3 坐标）`);

        const chests = [];
        for (const c of chestPts) {
            const rec = { pos: c, src: 'S3_scout' };
            try {
                const lItems = await t2.dataBlock('the_nether', c, 'Items', { timeoutMs: 10000 });
                rec.items = parseItems(lItems);
                rec.goldIngots = rec.items.filter((i) => i.name === 'gold_ingot').reduce((a, b) => a + b.count, 0);
                rec.goldNuggets = rec.items.filter((i) => i.name === 'gold_nugget').reduce((a, b) => a + b.count, 0);
                rec.goldBlocks = rec.items.filter((i) => i.name === 'gold_block').reduce((a, b) => a + b.count, 0);
                rec.itemCount = rec.items.reduce((a, b) => a + b.count, 0);
                rec.raw = (lItems ?? '').slice(0, 400);
                // ⚠ `data get block <pos> Items` 读不到 / 空 ⇒ **分不清"空箱"和"这格不是箱子"**
                //   （手册 §5 同族：没读到 ≠ 没有）。所以另走 `LootTable`：箱型能读到 ⇒ 这格确实是箱子。
                rec.itemsReadFailed = rec.itemCount === 0;
            } catch (e) { rec.error = String(e?.message ?? e).slice(0, 160); rec.itemsReadFailed = true; }
            try {
                const lTbl = await t2.dataBlock('the_nether', c, 'LootTable', { timeoutMs: 8000 });
                rec.lootTable = lTbl ? (/chests\/([a-z_]+)\.json/.exec(lTbl)?.[1] ?? lTbl.slice(-80)) : null;
                rec.isChest = rec.lootTable != null;
            } catch (e) { rec.lootTableErr = String(e).slice(0, 120); rec.isChest = null; }
            chests.push(rec);
            console.log(`[chest] ${c.x},${c.y},${c.z} 是箱=${rec.isChest} loot=${rec.lootTable} 金锭=${rec.goldIngots} 物品${rec.itemCount}件`);
        }
        const totalIngots = chests.reduce((a, c) => a + (c.goldIngots ?? 0), 0);
        const goldBlockCount = (loc['minecraft:gold_block']?.found ?? []).length || goldPts.length;
        // ★ S2-04：新验收线是「0→**10** 颗珍珠」（主种子门室已有 2 颗眼）
        //   ⇒ 需要的锭数 = E[投锭次数] / 0.2837。10 颗眼对应 35 次投锭（沿用 S2-03 对 jar 的
        //   0.286 实测 +0.8% 的吻合），但**这是外推**，`ingotsNeeded` 两个数都给（12 颗的 46 是 S2-01 的）。
        const b5 = {
            box: BOX, s3BBox: S3_BBOX, margin: MARGIN, s3Verify,
            chests, totalIngots,
            chestPositions: chestPts,
            goldBlockPositions: goldPts,
            goldBlockIngotValue: goldBlockCount * 9,
            s3ExpectedCounts: { gold_block: goldPts.length, chest: chestPts.length },
            verdict: {
                chestsChecked: chests.length,
                chestsConfirmed: chests.filter((c) => c.isChest === true).length,
                chestsUnreadable: chests.filter((c) => c.isChest == null).length,
                treasureChests: chests.filter((c) => c.lootTable === 'treasure').length,
                ingotsFromChests: totalIngots,
                ingotsFromGoldBlocks: goldBlockCount * 9,
                ingotsNeededFor12Pearls: 46,     // stage-02 R2.5（保留，S2-01 口径）
                ingotsNeededFor10Pearls: 35,     // ★ S2-04 新验收线（E[投锭]=10/0.2837≈35.3）
                enoughFromChests: totalIngots >= 35,
                enoughTotal: totalIngots + goldBlockCount * 9 >= 35,
            },
        };
        record('b5_p3_chest_truth', b5);
        writeSummary(b5);
        summary = b5;
    } catch (e) {
        console.error('[b5] 失败：', e);
        try { record('error', { message: String(e?.message ?? e), stack: String(e?.stack ?? '').slice(0, 900) }); } catch { /* 忽略 */ }
        try { writeSummary({ failed: String(e?.message ?? e) }); } catch { /* 忽略 */ }
        process.exitCode = 1;
    } finally {
        await closeRun();
    }
    return summary;
}

main();
