// approach_selftest.mjs — S2-06「走近控制器」的**离线**自检（假 bot + 假时钟，不开服、不占泳道）
//
// 为什么这一份必须存在（手册 §4 第 11 条 + S2-05 §4.4 的教训）：
//   S2-05 实测 `move_ok=5 / move_fail=6703`（成功率 0.075%），而那一局**跑完了、遥测齐、
//   指标甚至更好** —— 纯客户端观测看不出"主动走近根本没生效"。
//   旧病根是两条**静默**行为：① 单发 goto 用 2.5s 墙钟 race（走 12 格物理上就到不了）；
//   ② 每次超时都 `pathfinder.stop()`。**两条都不抛异常、不打日志**，只有离线断言能钉住。
//
// 核心断言的形态刻意是**反的**：钉「必须**不**停」「单次 goto 结束**不**算失败」
// 「**走位途中一次 stop 都不得有**」。这些正是真局只会给出一个难看的总数的东西。
//
// 用法：node approach_selftest.mjs

import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(DIR, '../../..');
const WT = path.join(ROOT, 'mindcraft-wt', 's2-barter');
const SRC = path.join(WT, 'src', 'agent', 'tasks', 'exec', 'piglin.js');
const require = createRequire(path.join(WT, 'main.js'));
const { Vec3 } = require('vec3');

let failed = 0;
let group = '';
const ok = (cond, msg, extra = '') => {
    if (cond) console.log(`  PASS ${msg}`);
    else { failed++; console.log(`  FAIL ${msg} ${extra}`); }
};
const G = (t) => { group = t; console.log(`${t}`); };

// ------------------------------------------------------------------ 假时钟
// 控制器用 `Date.now()` 取时。**必须注入假时钟**：真睡会把自检拖到分钟级，
// 而且"每 1s 重设"这条在真时钟下会变成随机 flaky（手册 §5：慢变量也别拿真时钟测）。
let CLOCK = 0;
const realNow = Date.now;
Date.now = () => CLOCK;
const advance = (ms) => { CLOCK += ms; };
function restoreClock() { Date.now = realNow; }

// ------------------------------------------------------------------ 假 bot
/** 假 pathfinder：`goto` 记录并返回可控的 promise（可立即 resolve / reject / 永不 settle） */
function mkBot({ pos = new Vec3(0, 57, 0) } = {}) {
    const bot = {
        entity: { id: 1, position: pos, eyeHeight: 1.62, yaw: 0, pitch: 0, onGround: true },
        entities: {},
        health: 20,
        inventory: { items: () => [{ name: 'gold_ingot', count: 64 }], slots: [] },
        _gotos: [], _stops: 0, _cleared: 0,
        pathfinder: {
            goals: { GoalNear: class { constructor(x, y, z, r) { Object.assign(this, { x, y, z, r }); } } },
            goto: (g) => { bot._gotos.push({ x: g.x, y: g.y, z: g.z, r: g.r, at: CLOCK }); return bot._gotoMode(g); },
            _gotoMode: () => new Promise(() => {}),      // 默认**永不 settle**（模拟"走到一半"）
            stop: () => { bot._stops++; },
        },
        clearControlStates: () => { bot._cleared++; },
        blockAt: () => ({ name: 'air', boundingBox: 'block' }),
    };
    return bot;
}
function mkPiglin(id, pos) {
    const md = [0, 300, null, false, false, false, 0, 0, 16, 0, false, 0, 0, null, 0, false, false, false, false];
    return { id, name: 'piglin', position: pos, width: 0.9, height: 1.9, metadata: md };
}
function mkEngine(bot, opts = {}) {
    const e = new pig.BarterEngine(bot, {
        mode: 'approach', slots: 3, tickMs: 5, harvestEveryRounds: 1000, ...opts,
        onEvent: (ev) => { e._events.push(ev); },
    });
    e._events = [];
    // ⚠ 返回**槽对象**且 `e` 就是**猪灵实体本身**。
    //   第一版这里写成 `{ e: s.e, ... }` + `return e.slots.push(...)`：
    //   `s.e` 是 undefined（`s` 本身就是实体），于是 `approachSlot` 第一行 `if (!e) return false`
    //   就把每条用例**全部短路**了 —— 而"走位途中没有 stop""没有 move_fail"这些
    //   **否定式断言照样 PASS**。**假绿的教科书案例。**
    //   ⇒ 所以下面 ① 的 `ok(!!e.approachCtl)` 是钉这条的**反例锁**：
    //   断言必须先证明"事情真的发生了"，再谈"不该发生什么"。
    e._push = (piglinEntity) => {
        const slot = {
            idx: e.slots.length, e: piglinEntity, state: pig.SlotState.IDLE, lastMoveAt: 0,
            throws: 0, ok: 0, miss: 0, lastDrop: null, cycleArmed: false,
        };
        e.slots.push(slot);
        if (!slot.e) throw new Error('_push 造出了没有实体的槽（自检自身的错，不是被测代码的错）');
        return slot;
    };
    return e;
}
const phases = (e, p) => e._events.filter((x) => x.phase === p);

const pig = await import(`file:///${SRC.replace(/\\/g, '/')}`);

try {
    // ================================================================ ① 核心病根
    G('① 走位途中**一次 stop 都不许有**，且单次 goto 不许判失败（S2-05 的 0.075% 回归锁）');
    {
        const bot = mkBot();
        const e = mkEngine(bot);
        const pl = mkPiglin(7, new Vec3(9.5, 57, 0.5));
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);

        CLOCK = 1000;
        e.approachSlot(s, CLOCK);
        ok(!!e.approachCtl, '走位意图起来了（控制器建起来）');
        ok(bot._stops === 0, '起意时**没有**立刻 stop', `stops=${bot._stops}`);

        // 走 9 格，每 500ms 一拍：共 5s，全程 10 次 goto 重设
        let stopsDuringWalk = 0;
        for (let i = 0; i < 10; i++) {
            advance(500);
            if (e.approachCtl) stopsDuringWalk += bot._stops - stopsDuringWalk, e.tickApproach(CLOCK);
        }
        ok(bot._gotos.length >= 3, `走位途中重设了 GoalNear 多次（${bot._gotos.length} 次）`, JSON.stringify(bot._gotos.map((g) => g.at)));
        ok(stopsDuringWalk === 0 && bot._stops === 0,
            '★ 走位全程 `pathfinder.stop()` **一次都没调**（旧实现每次 2.5s 超时就 stop）', `stops=${bot._stops}`);
        ok(phases(e, 'move_fail').length === 0 && phases(e, 'move_ok').length === 0,
            '★ 走位途中**没有**任何一次 move_fail/move_ok 记���（单次 goto 不算成败）',
            JSON.stringify(e._events.map((x) => x.phase)));
    }

    // ================================================================ ② 到达
    G('② 到达 = 一次 move_ok + 恰好一次 stop');
    {
        const bot = mkBot();
        const e = mkEngine(bot);
        const pl = mkPiglin(7, new Vec3(4.5, 57, 0.5));
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 2000;
        e.approachSlot(s, CLOCK);
        // bot 一路走到距猪灵 2.8（standoff 点）以内
        bot.entity.position = new Vec3(2.4, 57, 0.5);
        advance(200);
        e.tickApproach(CLOCK);
        ok(!e.approachCtl, '到达后控制器已清空');
        ok(phases(e, 'move_ok').length === 1, '恰好一条 move_ok', JSON.stringify(phases(e, 'move_ok')));
        ok(bot._stops === 1, '恰好一次 stop（收尾）', `stops=${bot._stops}`);
        ok(e.stats.moveArrived === 1 && e.stats.moveGaveUp === 0, '账：arrived=1 gaveUp=0', JSON.stringify({ a: e.stats.moveArrived, g: e.stats.moveGaveUp }));
        const r = e.report(3000, 'test');
        ok(r.approach.arrived === 1 && r.approach.gaveUp === 0, 'report() 里 approach 账可读', JSON.stringify(r.approach));
    }

    // ================================================================ ③ 目标会走：每拍重算
    G('③ 目标猪灵**每拍重算**（不许冻住一个已经不在这儿的点）');
    {
        const bot = mkBot();
        const e = mkEngine(bot);
        const pl = mkPiglin(7, new Vec3(6.5, 57, 0.5));
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 3000;
        e.approachSlot(s, CLOCK);
        advance(1100);
        e.tickApproach(CLOCK);                      // 第一次重设：猪灵在 x=6.5
        const g1 = bot._gotos.at(-1);
        // 猪灵**跑掉了**：x 从 6.5 → 9.5
        pl.position = new Vec3(9.5, 57, 0.5);
        advance(1100);
        e.tickApproach(CLOCK);                      // 第二次重设：必须跟到新位置
        const g2 = bot._gotos.at(-1);
        ok(g1 && g2 && g2.x > g1.x,
            '★ 猪灵移动后 GoalNear 跟到了**新**位置', JSON.stringify({ g1, g2 }));
        ok(g1 && g1.r === 2 && g2 && g2.r === 2, 'GoalNear 的半径就是 approachRange(=2)', JSON.stringify({ r1: g1?.r, r2: g2?.r }));
    }

    // ================================================================ ④ 单次 goto reject 不放弃
    G('④ 单次 goto **被 reject** 不等于这趟失败（路径暂时不通就下一拍再来）');
    {
        const bot = mkBot();
        const e = mkEngine(bot);
        bot.pathfinder._gotoMode = () => Promise.reject(new Error('no_path'));
        const pl = mkPiglin(7, new Vec3(8.5, 57, 0.5));
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 4000;
        e.approachSlot(s, CLOCK);
        for (let i = 0; i < 4; i++) { advance(1100); e.tickApproach(CLOCK); }
        ok(!!e.approachCtl, '★ 连续 reject 4 次后**仍在走**（没有被一次 reject 掐掉）');
        ok(phases(e, 'move_fail').length === 0, '期间没有 move_fail', JSON.stringify(phases(e, 'move_fail')));
        ok(bot._stops === 0, '期间没有 stop', `stops=${bot._stops}`);
        ok(e.stats.moveReissue >= 2, `重设次数记账（${e.stats.moveReissue}）`);
    }

    // ================================================================ ⑤ 总预算
    G('⑤ 总预算耗尽才放弃，且**只 stop 一次**');
    {
        const bot = mkBot();
        const e = mkEngine(bot, { approachMoveMs: 3000 });
        const pl = mkPiglin(7, new Vec3(40.5, 57, 0.5));      // 远到永远走不到
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 5000;
        e.approachSlot(s, CLOCK);
        for (let i = 0; i < 12 && e.approachCtl; i++) { advance(500); e.tickApproach(CLOCK); }
        ok(!e.approachCtl, '预算耗尽后控制器清空');
        ok(phases(e, 'move_fail').length === 1, '恰好一条 move_fail', JSON.stringify(phases(e, 'move_fail')));
        ok(phases(e, 'move_fail')[0]?.why === 'budget', '失败原因= budget', JSON.stringify(phases(e, 'move_fail')[0]));
        ok(bot._stops === 1, `恰好一次 stop（不是 6 次）`, `stops=${bot._stops}`);
        ok(e.stats.moveGaveUp === 1 && e.stats.moveWhy.budget === 1, '账：gaveUp=1 / why.budget=1', JSON.stringify(e.stats.moveWhy));
    }

    // ================================================================ ⑥ 槽死
    G('⑥ 槽死了立刻收（bot 只有一个身体，不能对着空气走）');
    {
        const bot = mkBot();
        const e = mkEngine(bot);
        const pl = mkPiglin(7, new Vec3(8.5, 57, 0.5));
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 6000;
        e.approachSlot(s, CLOCK);
        s.state = pig.SlotState.DEAD;
        advance(200);
        e.tickApproach(CLOCK);
        ok(!e.approachCtl && phases(e, 'move_fail')[0]?.why === 'slot_dead', '槽死 → move_fail(slot_dead)', JSON.stringify(phases(e, 'move_fail')));
        ok(bot._stops === 1, '收尾 stop 一次', `stops=${bot._stops}`);

        // 变体：实体从 entities 里消失（`e` 还在，state 还活着）
        const b2 = mkBot();
        const e2 = mkEngine(b2);
        const p2 = mkPiglin(8, new Vec3(8.5, 57, 0.5));
        b2.entities['8'] = p2;
        const s2 = e2._push(p2);
        e2.running = true;
        e2.home = new Vec3(0, 57, 0);
        CLOCK = 7000;
        e2.approachSlot(s2, CLOCK);
        delete b2.entities['8'];
        advance(200);
        e2.tickApproach(CLOCK);
        ok(phases(e2, 'move_fail')[0]?.why === 'slot_dead', '实体消失也收（没读到 ≠ 还在走）', JSON.stringify(phases(e2, 'move_fail')));
    }

    // ================================================================ ⑦ superseded 不算失败
    G('⑦ `superseded`（成交后回位插队）**不是失败** —— 记进失败账就是"账不可信"');
    {
        const bot = mkBot();
        const e = mkEngine(bot);
        const pl = mkPiglin(7, new Vec3(8.5, 57, 0.5));
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 8000;
        e.approachSlot(s, CLOCK);
        const before = e.stats.moveGaveUp;
        e.walkTo(s, { x: 0, y: 57, z: 0 }, 1200, 'retreat');
        const failEv = phases(e, 'move_fail').at(-1);
        ok(failEv?.why === 'superseded', '旧意图以 superseded 收尾', JSON.stringify(failEv));
        ok(failEv?.failed === false, '★ 事件上标 failed=false（不判失败）', JSON.stringify(failEv));
        ok(e.stats.moveGaveUp === before, '★ gaveUp 计数**没有**被回位污染', `before=${before} now=${e.stats.moveGaveUp}`);
        ok(e.approachCtl?.why === 'retreat', '新意图（retreat）已接管', JSON.stringify({ why: e.approachCtl?.why }));
    }

    // ================================================================ ⑧ leash 回位
    G('⑧ 走出 leash → 目标换成作业位（不是另起一趟把移动掐断）');
    {
        const bot = mkBot({ pos: new Vec3(20, 57, 0) });      // 已经离 home 20 格（leash=6.5）
        const e = mkEngine(bot, { approachLeash: 6.5 });
        const pl = mkPiglin(7, new Vec3(26.5, 57, 0.5));
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 9000;
        e.approachSlot(s, CLOCK);
        advance(200);
        e.tickApproach(CLOCK);
        const c = e.approachCtl;
        ok(c?.why === 'leash_back', '意图切到 leash_back', JSON.stringify({ why: c?.why }));
        ok(c?.retargets >= 1, 'retargets 记账', JSON.stringify({ retargets: c?.retargets }));
        // 回到 home 附近 → 以 leash_back 收（ok=true）
        bot.entity.position = new Vec3(0.5, 57, 0);
        advance(200);
        e.tickApproach(CLOCK);
        ok(phases(e, 'move_ok').at(-1)?.why === 'leash_back', '回到作业位算一次到达', JSON.stringify(phases(e, 'move_ok').at(-1)));
    }

    // ================================================================ ⑨ 同时只有一条走位
    G('⑨ 同时只有**一条**走位意图（bot 只有一个身体）');
    {
        const bot = mkBot();
        const e = mkEngine(bot);
        const a = mkPiglin(7, new Vec3(8.5, 57, 0.5));
        const b = mkPiglin(8, new Vec3(-8.5, 57, 0.5));
        bot.entities['7'] = a; bot.entities['8'] = b;
        const sa = e._push(a), sb = e._push(b);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 10000;
        e.approachSlot(sa, CLOCK);
        const first = e.approachCtl;
        advance(800);
        const started2 = e.approachSlot(sb, CLOCK);       // 另一个槽也想走
        ok(started2 === true && e.approachCtl !== first, '第二个槽**接管**（旧的先收尾），不是并行两个身体');
        ok(phases(e, 'move_fail').at(-1)?.why === 'superseded', '被接管的记 superseded', JSON.stringify(phases(e, 'move_fail').at(-1)));
        ok(e.stats.moveAsk === 2, '起意数=2', `ask=${e.stats.moveAsk}`);
    }

    // ================================================================ ⑩ 收工不许漏走
    G('⑩ `stop()` / `run_end` 收工时必须把走位收掉（否则 bot 会继续朝岩浆走）');
    {
        const bot = mkBot();
        const e = mkEngine(bot);
        const pl = mkPiglin(7, new Vec3(8.5, 57, 0.5));
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 11000;
        e.approachSlot(s, CLOCK);
        advance(200);
        e.stop('test');
        ok(!e.approachCtl, 'stop() 后控制器清空');
        ok(bot._stops === 1, 'stop() 触发一次收尾', `stops=${bot._stops}`);
        ok(phases(e, 'move_fail').at(-1)?.why === 'stopped', '记为 stopped（不判失败）', JSON.stringify(phases(e, 'move_fail').at(-1)));
        ok(e.stats.moveGaveUp === 0, '★ 收工不污染失败账', `gaveUp=${e.stats.moveGaveUp}`);
    }

    // ================================================================ ⑪ 走位优先语义没变
    G('⑪ 走位期间本轮**不投锭**（语义与 S2-03/S2-05 一致，只是现在真的走得到）');
    {
        const bot = mkBot();
        const e = mkEngine(bot);
        const pl = mkPiglin(7, new Vec3(8.5, 57, 0.5));
        bot.entities['7'] = pl;
        const s = e._push(pl);
        e.running = true;
        e.home = new Vec3(0, 57, 0);
        CLOCK = 12000;
        e.approachSlot(s, CLOCK);
        const r0 = e.rounds;
        await e.step();
        ok(e.rounds === r0 + 1, 'step() 被调用了');
        ok(phases(e, 'throw_ok').length === 0 && e.stats.throwsOk === 0, '走近期间一锭没投', `throwsOk=${e.stats.throwsOk}`);
    }
} finally {
    restoreClock();
}

console.log(`\n${failed === 0 ? '全部通过' : `✗ ${failed} 条失败`}`);
process.exit(failed === 0 ? 0 : 1);
