// s1_waypoint_audit.mjs — S1 route 路点/站位**离线逐格校验**（纯存档解析，不开服、不连客户端）
//
// 【干什么】拿 route 的 `legs[*].waypoints` 与 `stations[*].exact.stand`，逐格在 .mca 真值里核对：
//   ① 站得住  = 身体格是空气族 ∧ 脚下是实心非危险
//   ② 6 邻无危险 = 水平 4 邻 + 上下 2 格，共 6 格里 `{lava, flowing_lava, magma_block}` 计数 = 0
//      （比"只查脚下"严得多，是本单要的硬要求）
//   ③ 头格可容身 = `y+1` 是空气族 —— **只统计、不算硬失败**（1.16.1 玩家高 1.8，头格被占会卡）
//
// 【硬线：危险优先于一切】身体格本身是危险族 ⇒ `body_hazard`，**必须 FAIL**；
//   绝不允许被"空气族检查通过"之类掩盖过去。
//
// 【头号反模式：读不到 ≠ 是空气（手册 §5）】
//   `region_reader.blockAt` 在「区块未保存 / 该 y 段没有 section」时返回 **`'unknown'` 字符串**
//   （不是 null）。本文件 `normalizeName` 把 `null / undefined / '' / 'unknown' / 'null' / 'undefined'`
//   **全部**收成 `null`，于是"读不到"在下游只有一个表示（`unreadable_body` / `unreadable_foot`），
//   永远不会被折算成"这格是空气 ⇒ 没问题"。自检 T5 专门钉这一条。
//
// 【为什么要独立一个文件、而不是复用 s1_exact_survey.mjs 的常量】
//   那些常量在那条链上正被改；校验工具要能独立钉住判据。口径写在下面，改这里比改那边安全。
//   判据只认 `get(x,y,z) => name|null` 回调，逻辑里不出现 World ⇒ 自检能用假 oracle 离线钉。
//
// 【退出码】0 = 校验跑完了（**不代表没有不合格路点**，不合格看汇总与清单）；
//   1 = 参数/文件/存档错误；2 = 参数错。FAIL 不改变退出码（避免父 agent 的流水线被误判为崩）。
//
// 用法（Node 20，见手册 §2）：
//   cd D:\AI斗蛐蛐\bench\stages\portal
//   node s1_waypoint_audit.mjs [--route=<path>] [--world=<dir>]
//   （不给参数就用 DEFAULTS：bench/route 下的 route v2 + probe/_s1_main_fresh 那份存档）

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from '../../route/tools/region_reader.mjs';

// ⚠ 绝对路径一律从 `fileURLToPath(import.meta.url)` 推：`new URL(...).pathname` 在 Windows 上
//   会给出 `/D:/…` 这种非法路径（手册记过），中文路径下更容易踩。
const HERE = path.dirname(fileURLToPath(import.meta.url));

export const DEFAULTS = Object.freeze({
    route: path.resolve(HERE, '../../route/4926685115947721762.v2.json'),
    world: path.resolve(HERE, '../../route/probe/_s1_main_fresh/4926685115947721762'),
    dim: 'overworld',
});

export const EXIT = Object.freeze({ OK: 0, ERROR: 1, USAGE: 2 });

// ================================================================== 判据常量
/** 空气族（身体格 / 头格要的就是这个）。1.16.1 三个空气方块都在。 */
export const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);

/** 危险族：岩浆源块与流动岩浆、岩浆块。致命，且邻接也算不合格。 */
export const HAZARD = new Set(['lava', 'flowing_lava', 'magma_block']);

/** 液体族：脚下是水/岩浆都不算作业面（"实心"的反面）。 */
export const LIQUID = new Set(['water', 'lava', 'flowing_water', 'flowing_lava']);

/**
 * 不可承重族（deny-list）。**未列出的方块一律按实心处理** —— 方向是宁可把不可站的判成可站，
 * 也不会把可站的判死；但危险族已在上游先判掉，不会走到这里。
 * ⚠ 口径边界：半砖/楼梯**按可站处理**（作业面经常是半砖），与 s1_exact_survey 同口径。
 */
export const NON_FULL = new Set([
    'air', 'cave_air', 'void_air', 'water', 'lava', 'flowing_water', 'flowing_lava', 'magma_block',
    'short_grass', 'grass', 'fern', 'large_fern', 'dead_bush', 'dead_plant', 'seagrass', 'tall_seagrass',
    'vine', 'torch', 'wall_torch', 'soul_torch', 'redstone_torch', 'lever', 'tripwire_hook', 'tripwire',
    'rail', 'powered_rail', 'detector_rail', 'activator_rail', 'golden_rail',
    'ladder', 'scaffolding', 'cobweb', 'string', 'painting', 'item_frame', 'flower_pot',
    'snow', 'snow_layer', 'carpet', 'stone_button', 'polished_blackstone_button', 'pressure_plate',
    'light_weighted_pressure_plate', 'heavy_weighted_pressure_plate', 'fire', 'soul_fire', 'lava_rail',
]);

/** 脚下是否算"实心承重面"。液体/空气/植物都算不可站。 */
export const isFullSolid = (name) => name !== null && !NON_FULL.has(name);

// ================================================================== 原因码
export const REASON = Object.freeze({
    BODY_HAZARD: 'body_hazard',
    BODY_NOT_AIR: 'body_not_air',
    FOOT_NOT_SOLID: 'foot_not_solid',
    FOOT_IS_HAZARD: 'foot_is_hazard',
    ADJACENT_HAZARD: 'adjacent_hazard',
    UNREADABLE_BODY: 'unreadable_body',
    UNREADABLE_FOOT: 'unreadable_foot',
});

export const REASON_CN = Object.freeze({
    body_hazard: '身体格是危险格（致命）',
    body_not_air: '身体格不是空气',
    foot_not_solid: '脚下不是实心',
    foot_is_hazard: '脚下是危险格',
    adjacent_hazard: '6 邻内与岩浆/岩浆块相邻',
    unreadable_body: '身体格读不到',
    unreadable_foot: '脚下读不到',
});

/** 硬失败码：命中任一 ⇒ FAIL（不合格）。 */
export const HARD_REASONS = new Set([
    REASON.BODY_HAZARD, REASON.BODY_NOT_AIR, REASON.FOOT_NOT_SOLID, REASON.FOOT_IS_HAZARD, REASON.ADJACENT_HAZARD,
]);
/** 读不到：不是 FAIL，但也**绝不算 OK**，单独一类列出来（手册 §5）。 */
export const UNREADABLE_REASONS = new Set([REASON.UNREADABLE_BODY, REASON.UNREADABLE_FOOT]);

/** 邻接取格：**水平 4 邻 + 上下 2 格 = 6 格**（含脚下那一格，所以脚下是岩浆会同时命中 foot_is_hazard 与 adjacent_hazard）。 */
export const NEIGHBORS6 = Object.freeze([[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0], [0, -1, 0]]);

// ================================================================== oracle
/**
 * 归一名：`minecraft:obsidian` → `obsidian`；**读不到的一律归 `null`（= unknown）**。
 * ⚠ 收口在这里是为了"读不到"全流程只有**一个**表示，不会某一处把它当空气（手册 §5 头号反模式）。
 * @param {string|{name:string}|null|undefined} raw
 */
export function normalizeName(raw) {
    if (raw === null || raw === undefined) return null;
    const v = (typeof raw === 'object' && raw !== null) ? raw.name : raw;
    if (v === null || v === undefined) return null;
    let s = String(v).trim().toLowerCase();
    if (s.startsWith('minecraft:')) s = s.slice('minecraft:'.length);
    if (s === '' || s === 'unknown' || s === 'null' || s === 'undefined') return null;
    return s;
}

/**
 * 造 oracle：包一层缓存 + 归一。**判据只认 `get`**，逻辑里不出现 World ⇒ 自检能用假 oracle 离线钉。
 * @param {(x:number,y:number,z:number)=>string|null} get
 */
export function makeOracle(get) {
    if (typeof get !== 'function') throw new Error('makeOracle：get 必须是 (x,y,z) => name|null');
    const cache = new Map();
    const key = (x, y, z) => `${x},${y},${z}`;
    return {
        get(x, y, z) {
            const k = key(x, y, z);
            if (!cache.has(k)) cache.set(k, normalizeName(get(x, y, z)));
            return cache.get(k);
        },
        reads: () => cache.size,
    };
}

/** 真存档 → oracle。`blockAt` 的 'unknown' 在 makeOracle 里已经被收成 null。 */
export function oracleFromWorld(worldDir, opt = {}) {
    const w = openWorld(worldDir, { dims: [opt.dim ?? 'overworld'] });
    return { oracle: makeOracle((x, y, z) => w.blockAt(x, y, z)), world: w };
}

// ================================================================== 逐格判据
/**
 * 判一格 P=(x,y,z)（body cell = 脚所在那格）。
 * @returns {{
 *   cell:number[], body:string|null, foot:string|null, head:string|null,
 *   hazards:{cell:number[],name:string}[], hazardCount:number,
 *   unreadableNeighbors:number, reasons:string[], verdict:'OK'|'FAIL'|'UNREADABLE',
 *   headBlocked:boolean, headUnreadable:boolean
 * }}
 */
export function auditCell(oracle, cell) {
    const [x, y, z] = cell;
    const body = oracle.get(x, y, z);
    const foot = oracle.get(x, y - 1, z);
    const head = oracle.get(x, y + 1, z);

    const reasons = [];

    // —— ① 可站住
    if (body === null) reasons.push(REASON.UNREADABLE_BODY);
    else if (HAZARD.has(body)) reasons.push(REASON.BODY_HAZARD);      // 硬线：危险优先，单独归类
    else if (!AIRLIKE.has(body)) reasons.push(REASON.BODY_NOT_AIR);

    if (foot === null) reasons.push(REASON.UNREADABLE_FOOT);
    else if (HAZARD.has(foot)) reasons.push(REASON.FOOT_IS_HAZARD);
    else if (!isFullSolid(foot)) reasons.push(REASON.FOOT_NOT_SOLID);

    // —— ② 6 邻无危险
    const hazards = [];
    let unreadableNeighbors = 0;
    for (const [dx, dy, dz] of NEIGHBORS6) {
        const nx = x + dx, ny = y + dy, nz = z + dz;
        const n = oracle.get(nx, ny, nz);
        if (n === null) { unreadableNeighbors++; continue; }             // 读不到 ≠ 不是危险，单列计数
        if (HAZARD.has(n)) hazards.push({ cell: [nx, ny, nz], name: n });
    }
    if (hazards.length) reasons.push(REASON.ADJACENT_HAZARD);

    // —— ③ 头格：只统计，不进 reasons
    const headUnreadable = head === null;
    const headBlocked = !headUnreadable && !AIRLIKE.has(head);

    const hard = reasons.filter((r) => HARD_REASONS.has(r));
    const unread = reasons.filter((r) => UNREADABLE_REASONS.has(r));
    const verdict = hard.length ? 'FAIL' : (unread.length ? 'UNREADABLE' : 'OK');

    return {
        cell: [x, y, z], body, foot, head,
        hazards, hazardCount: hazards.length, unreadableNeighbors,
        reasons, verdict, headBlocked, headUnreadable,
    };
}

/** 判一串格子（顺序即输出顺序）。 */
export function auditCells(oracle, cells) { return cells.map((c) => auditCell(oracle, c)); }

/** 一段结果的统计：OK / FAIL / UNREADABLE 计数、原因码计数、headBlocked、unreadableNeighbors。 */
export function summarize(rows) {
    const s = {
        total: rows.length, ok: 0, fail: 0, unreadable: 0,
        headBlocked: 0, headUnreadable: 0, unreadableNeighbors: 0,
        reasonCounts: new Map(), fails: [], unreadables: [], headBlockedCells: [],
    };
    for (const r of rows) {
        if (r.verdict === 'OK') s.ok++;
        else if (r.verdict === 'FAIL') { s.fail++; s.fails.push(r); }
        else { s.unreadable++; s.unreadables.push(r); }
        if (r.headBlocked) { s.headBlocked++; s.headBlockedCells.push(r); }
        if (r.headUnreadable) s.headUnreadable++;
        s.unreadableNeighbors += r.unreadableNeighbors;
        for (const code of r.reasons) s.reasonCounts.set(code, (s.reasonCounts.get(code) ?? 0) + 1);
    }
    return s;
}

// ================================================================== 输出
const cellStr = (c) => `${c[0]},${c[1]},${c[2]}`;
const show = (n) => (n === null ? 'UNREADABLE' : n);
/** 单元格固定宽度，避免列错位。 */
const W = (s, n) => String(s).padEnd(n);

export function formatRow(idx, r) {
    return [
        String(idx).padStart(3, ' '),
        `[${cellStr(r.cell)}]`.padEnd(16, ' '),
        W(show(r.body), 14),
        W(show(r.foot), 14),
        W(show(r.head), 14),
        W(String(r.hazardCount), 3),
        W(r.verdict, 11),
        r.reasons.length ? r.reasons.join(',') : '-',
    ].join(' ');
}

export function formatTable(title, rows) {
    const out = [];
    out.push('');
    out.push(`=== ${title} ===`);
    out.push(`  ${'#'.padStart(3)} ${'[x,y,z]'.padEnd(16)} ${W('身体格', 14)} ${W('脚下', 14)} ${W('头格', 14)} ${W('危邻', 3)} ${W('判定', 11)} 原因码`);
    rows.forEach((r, i) => out.push('  ' + formatRow(i + 1, r)));
    return out.join('\n');
}

export function formatSummary(title, s) {
    const out = [];
    out.push('');
    out.push(`--- 汇总：${title} ---`);
    out.push(`  总数=${s.total}  OK=${s.ok}  FAIL=${s.fail}  UNREADABLE=${s.unreadable}`);
    out.push(`  头部被占(headBlocked，只统计)=${s.headBlocked}   头格读不到=${s.headUnreadable}   6 邻里读不到的格=${s.unreadableNeighbors}`);
    const codes = [...s.reasonCounts.entries()].sort((a, b) => b[1] - a[1]);
    out.push('  原因码计数: ' + (codes.length ? codes.map(([k, v]) => `${k}=${v}`).join('  ') : '（无）'));
    out.push('  原因码释义:');
    for (const [k, v] of codes) out.push(`    ${k.padEnd(16)} ${String(v).padStart(4)}  ${REASON_CN[k] ?? ''}`);
    out.push('');
    if (s.fails.length) {
        out.push(`  ▌不合格清单（${s.fails.length} 条，主 agent 按这个改 route）:`);
        for (const r of s.fails) {
            const extra = r.hazards.length ? `  危险邻=${r.hazards.map((h) => `${cellStr(h.cell)}=${h.name}`).join(' ')}` : '';
            out.push(`  FAIL: [${cellStr(r.cell)}] reason=${r.reasons.join(',')}  body=${show(r.body)} foot=${show(r.foot)} head=${show(r.head)}${extra}`);
        }
    } else out.push('  ▌不合格清单: （空）');
    out.push('');
    if (s.unreadables.length) {
        out.push(`  ▌读不到清单（${s.unreadables.length} 条，**不算合格**，需换种子/加载区块后重判）:`);
        for (const r of s.unreadables) out.push(`  UNREADABLE: [${cellStr(r.cell)}] reason=${r.reasons.join(',')}  6邻读不到=${r.unreadableNeighbors}`);
    } else out.push('  ▌读不到清单: （空）');
    if (s.headBlockedCells.length) {
        out.push('');
        out.push(`  ▌头格被占清单（${s.headBlockedCells.length} 条，**软失败**，不算进 FAIL）:`);
        for (const r of s.headBlockedCells) out.push(`  headBlocked: [${cellStr(r.cell)}] head=${r.head}`);
    }
    return out.join('\n');
}

// ================================================================== CLI
/** 支持 `--k=v` 与 `--k v` 两种写法。 */
export function parseArgs(argv) {
    const out = { route: DEFAULTS.route, world: DEFAULTS.world, dim: DEFAULTS.dim, help: false };
    for (let i = 0; i < argv.length; i++) {
        const a = argv[i];
        if (a === '--help' || a === '-h') { out.help = true; continue; }
        const m = /^--([a-z]+)(?:=(.*))?$/i.exec(a);
        if (!m) throw new Error(`无法识别的参数：${a}`);
        const key = m[1].toLowerCase();
        if (!['route', 'world', 'dim'].includes(key)) throw new Error(`未知参数 --${key}`);
        let val = m[2];
        if (val === undefined) { val = argv[++i]; if (val === undefined) throw new Error(`--${key} 缺值`); }
        out[key] = val;
    }
    out.route = path.resolve(out.route);
    out.world = path.resolve(out.world);
    return out;
}

const USAGE = `用法: node s1_waypoint_audit.mjs [--route=<path>] [--world=<dir>] [--dim=overworld]
默认 route: ${DEFAULTS.route}
默认 world: ${DEFAULTS.world}`;

export function main(argv, log = console.log) {
    let opt;
    try { opt = parseArgs(argv); } catch (e) { log(`参数错：${e.message}\n${USAGE}`); return EXIT.USAGE; }
    if (opt.help) { log(USAGE); return EXIT.OK; }

    for (const [what, p] of [['route', opt.route], ['world', opt.world]]) {
        if (!fs.existsSync(p)) { log(`文件不存在（${what}）：${p}`); return EXIT.ERROR; }
    }
    let route;
    try { route = JSON.parse(fs.readFileSync(opt.route, 'utf8')); } catch (e) { log(`route 解析失败：${e.message}`); return EXIT.ERROR; }

    let oracle;
    try { oracle = oracleFromWorld(opt.world, { dim: opt.dim }).oracle; } catch (e) { log(`存档打开失败：${e.message}`); return EXIT.ERROR; }

    log(`route: ${opt.route}`);
    log(`world: ${opt.world}  (dim=${opt.dim})`);

    // —— 路点：逐 leg 全部查（当前 route 只有 1 条 leg）
    const legBlocks = [], standBlocks = [];
    let legAll = [];
    (route.legs ?? []).forEach((leg, li) => {
        const rows = auditCells(oracle, leg.waypoints ?? []);
        legAll = legAll.concat(rows);
        legBlocks.push(formatTable(`leg[${li}] ${leg.from} -> ${leg.to}　路点 ${rows.length} 格`, rows));
        legBlocks.push(formatSummary(`leg[${li}] ${leg.from} -> ${leg.to}`, summarize(rows)));
    });
    log(legBlocks.join('\n'));

    // —— stand：同三条判据
    let standAll = [];
    const stBlocks = [];
    for (const st of route.stations ?? []) {
        const cells = (st.exact && st.exact.stand) ?? [];
        const rows = auditCells(oracle, cells);
        standAll = standAll.concat(rows);
        stBlocks.push(formatTable(`station ${st.id}　exact.stand ${rows.length} 格`, rows));
        stBlocks.push(formatSummary(`station ${st.id} exact.stand`, summarize(rows)));
    }
    if (stBlocks.length) log(stBlocks.join('\n'));

    log(formatSummary('全部 leg 路点合计', summarize(legAll)));
    return EXIT.OK;
}

// 直接跑才执行（被 import 时不跑）
const invokedDirectly = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url));
if (invokedDirectly) process.exit(main(process.argv.slice(2)));
