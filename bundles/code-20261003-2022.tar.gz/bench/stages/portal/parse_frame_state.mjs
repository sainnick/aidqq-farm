// parse_frame_state.mjs — 用 **C 线的 region_reader** 离线解析真框存档快照
//
// 设计会话要求：只读取证走 `bench/route/tools/region_reader.mjs`（手册 §5），
// 控制台只用于布景。本脚本**不开服**，只读 `runs/P8R12_STATE/worldA`（挖之前的快照）。
//
// 回答三件事：
//   ① 框内那 2 格岩浆到底是不是源块（名字层面；1.16.1 源块/流动块的 Name 都是 `lava`，
//      区别在 Properties.level —— 那部分由客户端方块状态给出，见 client_boxes.json）
//   ② 哭泣黑曜石那一格 (187,42,310) 在服务端**是不是 air**（R11 报 32.3s 挖完，比理论 41.7s 短）
//   ③ 框体各格在存档里的真值（含 unknown —— 手册 §5「没读到 ≠ 没有」）
//
// 用法：node parse_frame_state.mjs [stamp]
//   默认解析 P8R12_STATE2 的 worldA（挖之前）/ worldB（挖掉底行缺格后）/ worldC（再挖哭泣黑曜石后）
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from '../../route/tools/region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const STAMP = process.argv[2] || 'P8R12_STATE2';
const RUNS = path.join(HERE, 'runs', STAMP);
const OUT = path.join(RUNS, 'parsed_frame.json');

const FRAME = { x: 187, y: 39, z: 307, axis: 'z' };
const R = 8;
const CRYING = [187, 42, 310];
const MISSING = [187, 39, 307];
const LAVA_IN = [[187, 40, 308], [187, 40, 309]];

// 框体 14 格（生产几何：4×5 沿 z，1.16.1 顶行两角可选）
const CORNERS_OPTIONAL = true;
const cells = [];
for (let u = 0; u < 4; u++) {
    cells.push({ at: [187, 39, 307 + u], kind: 'bottom', u });
    cells.push({ at: [187, 43, 307 + u], kind: 'top', u, optional: CORNERS_OPTIONAL && (u === 0 || u === 3) });
}
for (let dy = 1; dy <= 3; dy++) {
    cells.push({ at: [187, 39 + dy, 307], kind: 'side', dy });
    cells.push({ at: [187, 39 + dy, 310], kind: 'side', dy });
}
const interior = [];
for (let dy = 1; dy <= 3; dy++) for (let u = 1; u <= 2; u++) interior.push({ at: [187, 39 + dy, 307 + u] });

const out = { stamp: STAMP, frame: FRAME, radius: R, snapshots: {} };

for (const snap of ['worldA', 'worldB', 'worldC']) {
    const dir = path.join(RUNS, snap);
    if (!fs.existsSync(path.join(dir, 'region'))) { out.snapshots[snap] = { missing: true }; continue; }
    const w = openWorld(dir, { dims: ['overworld'] });
    const box = { x1: FRAME.x - R, y1: FRAME.y - R, z1: FRAME.z - R, x2: FRAME.x + R, y2: FRAME.y + R, z2: FRAME.z + R };
    const cnt = w.countInBox(box, null, 'overworld');
    out.snapshots[snap] = {
        stats: w.stats,
        boxCounts: cnt.counts,
        boxUnknownCells: cnt.unknownCells,
        boxCells: cnt.cells,
        frameCells: cells.map((c) => ({ ...c, got: w.blockAt(c.at[0], c.at[1], c.at[2], 'overworld') })),
        interior: interior.map((c) => ({ ...c, got: w.blockAt(c.at[0], c.at[1], c.at[2], 'overworld') })),
        cryingCell: w.blockAt(...CRYING, 'overworld'),
        missingCell: w.blockAt(...MISSING, 'overworld'),
        interiorLava: LAVA_IN.map((p) => ({ at: p, got: w.blockAt(p[0], p[1], p[2], 'overworld') })),
    };
    const s = out.snapshots[snap];
    console.log(`\n===== ${snap} （${snap === 'worldA' ? '挖之前' : snap === 'worldB' ? '挖掉底行缺格后' : '再挖哭泣黑曜石后'}）=====`);
    console.log(`解析: chunksRead=${s.stats.chunksRead} chunkMiss=${s.stats.chunkMiss} 盒内 unknown=${s.boxUnknownCells}/${s.boxCells}`);
    console.log(`★ 哭泣黑曜石格 (${CRYING.join(',')}) = ${s.cryingCell}`);
    console.log(`★ 底行缺格   (${MISSING.join(',')}) = ${s.missingCell}`);
    console.log('★ 框内岩浆：' + s.interiorLava.map((l) => `(${l.at.join(',')})=${l.got}`).join('  '));
    const req = s.frameCells.filter((c) => !c.optional);
    const missingReq = req.filter((c) => c.got !== 'obsidian');
    console.log(`★ 必需格缺 ${missingReq.length} 个：` + missingReq.map((c) => `(${c.at.join(',')})=${c.got}`).join(' '));
    const opt = s.frameCells.filter((c) => c.optional);
    console.log(`  可选角：` + opt.map((c) => `(${c.at.join(',')})=${c.got}`).join(' '));
    const lavaHist = Object.entries(s.boxCounts).filter(([k]) => k === 'lava' || k === 'flowing_lava');
    console.log(`  盒内 lava=${JSON.stringify(Object.fromEntries(lavaHist))}`);
}

fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
console.log(`\n已写出 ${OUT}`);
