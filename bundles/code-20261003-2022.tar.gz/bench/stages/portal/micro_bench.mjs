// micro_bench.mjs — MC-M1-TASK-08 新原语微基准（倒水 / 捞岩浆 / 浇一格黑曜石）
//
// 验收线（任务单 §1.3）：三个原语各批量 30 次，成功率 ≥95% 才准接进状态机。
// 协议全抄 micro-place（06c P1 交付、竖井微基准 120/120）踩过的坑，一个不落：
//   ① 摆地形时 bot 站在 fill 体积外，别把自己埋了；
//   ② tp 只在同区块内做，跨区块 tp 触发 update_light 空列（place.js sectionTrusted 拦的幻影）；
//   ③ 每次开测前用**服务端真值**（execute if block → 读 server.log 里的唯一标记）确认地形到位；
//   ④ 标记必须每次唯一（@@Y{n} 用单调 seq），否则上一条的回包会被当成本条结果 → 假通过；
//   ⑤ bot.blockAt 只吃 Vec3；
//   ⑥ 等回包落定再开测，不在 fill 还在处理时测。
//
// 场景固定在远离出生的一个平台上（避免被真实地形干扰），三种原语各测 N 次。

import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import { spawn, execSync } from 'child_process';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { cleanup, installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';
import { makeRpc, serveRpc, tailFile } from './srv_rpc.mjs';
import { SCENE, sceneChecks } from './scene.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const NODE20 = path.join(ROOT, '.runtime', 'node-v20.20.2-win-x64', 'node.exe');
// ★ ROOT 已经是工作区根（D:\AI斗蛐蛐），再拼 '..' 会退到 D:\ → 找不到 node_modules。
//   之前必须靠外部设 MC_MINDCRAFT_ROOT 才能跑对，这里把默认值修掉。
const MINDCRAFT_ROOT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
process.env.MC_MINDCRAFT_ROOT = MINDCRAFT_ROOT;

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = argOf(process.argv, 'mc-version', '1.16.1');
const N = parseInt(argOf(process.argv, 'n', '30'), 10);
const STAMP = argOf(process.argv, 'stamp', `P8_MICRO_${new Date().toISOString().slice(0, 13).replace(/[-T:]/g, '')}`);
const SEED = argOf(process.argv, 'seed', `${STAMP}-S`);
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const THRESHOLD = parseFloat(argOf(process.argv, 'threshold', '95'));
// 别的线白天会开 2 条泳道长时间占住 B → 排队窗口要够长，否则排队本身变成反复重跑
const LANE_WAIT_MS = parseInt(argOf(process.argv, 'lane-wait-ms', String(120 * 60 * 1000)), 10);
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'TaskBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

const ROWS = path.join(RUNS_DIR, 'micro_results.jsonl');
const DONE = path.join(RUNS_DIR, 'done.json');
const RPC_DIR = path.join(RUNS_DIR, 'rpc');

/**
 * 摆场景 + 服务端真值闸门（全部经 server.stdin，不走聊天）。
 * 真值查询用 `execute if block … run say @@Ynnn` → 标记出现在 server.log 即为服务端真答。
 * 06c 教训：标记必须每次唯一，否则上一条的回包会被当成本条结果 → 假通过。
 */
async function setupSceneAndVerify({ rpc, logPath, log }) {
    const S = SCENE;
    const P = S.platform;
    const box = (b) => `fill ${b.x0} ${b.y0} ${b.z0} ${b.x1} ${b.y1} ${b.z1}`;

    // ★ 第一步必须先把 bot 传送到场景附近让区块真的加载。
    //   P8_MICRO1 教训：bot 落在真实出生点（-190,63,201），(200,200) 那个区块压根没加载，
    //   7 条 fill 全部回「That position is not loaded」。而 /fill **失败时不打成功日志**，
    //   只打那一行 —— 从日志上看「有报错」和「什么都没发生」极易混淆。
    const tWarm = Date.now();
    await rpc.call(rpc, rpc.nextId('tp'), `tp ${LANE_B.username} ${S.stand.x} ${S.stand.y} ${S.stand.z}`, { timeoutMs: 30000, logFn: log });
    // 跨区块 tp 后不要立刻开测（update_light 空列，place.js sectionTrusted 拦的幻影）
    await sleep(6000);
    log(`场景预热：已 tp 到 ${S.stand.x},${S.stand.y},${S.stand.z}，等待 ${((Date.now() - tWarm) / 1000).toFixed(1)}s`);

    const CMDS = [
        // ① 先把整个区域清空，免得自然地形（河/海/洞穴）掺进来
        `${box({ x0: 190, y0: 60, z0: 195, x1: 210, y1: 72, z1: 205 })} minecraft:air`,
        // ② 平台（bot 踩着它，脚底有实地 → groundSafe 通过）
        `${box(P)} minecraft:stone`,
        // ③ 岩浆池的坑（保证源块不扩散、也不被平台压住）
        `${box(S.lavaPit)} minecraft:air`,
        ...S.lavaCells.map((c) => `fill ${c.x} ${c.y} ${c.z} ${c.x} ${c.y} ${c.z} minecraft:lava`),
        // ④ 水池的坑 + 单格水源
        `${box(S.waterPit)} minecraft:air`,
        `fill ${S.waterCell.x} ${S.waterCell.y} ${S.waterCell.z} ${S.waterCell.x} ${S.waterCell.y} ${S.waterCell.z} minecraft:water`,
        // ⑤ 倒水目标格（平台上，清空；底下 y=69 是平台 stone 当支撑面）
        `fill ${S.pourCell.x} ${S.pourCell.y} ${S.pourCell.z} ${S.pourCell.x} ${S.pourCell.y} ${S.pourCell.z} minecraft:air`,
        // ⑥ 浇筑目标格：放岩浆源，浇完变黑曜石；旁边的石台是倒水时的支撑面
        `fill ${S.castCell.x} ${S.castCell.y} ${S.castCell.z} ${S.castCell.x} ${S.castCell.y} ${S.castCell.z} minecraft:lava`,
        `fill ${S.castShelf.x} ${S.castShelf.y} ${S.castShelf.z} ${S.castShelf.x} ${S.castShelf.y} ${S.castShelf.z} minecraft:stone`,
    ];
    // 跑两轮：日志里还有 "not loaded" 说明区块没热起来，补一轮
    for (let round = 1; round <= 2; round++) {
        const mark = tailFile(logPath, 65536).length;
        for (const c of CMDS) {
            const id = rpc.nextId('scene');
            const ack = await rpc.call(rpc, id, c, { timeoutMs: 60000, logFn: log });
            if (ack == null) log(`⚠ 场景命令超时: ${c}`);
            await sleep(350);
        }
        await sleep(2500);
        const slice = tailFile(logPath, 65536).slice(mark);
        const notLoaded = (slice.match(/not loaded/g) ?? []).length;
        const filled = (slice.match(/Successfully filled/g) ?? []).length;
        log(`场景第 ${round} 轮：命令 ${CMDS.length} 条，fill 成功 ${filled}，not loaded ${notLoaded}`);
        if (!notLoaded && filled >= CMDS.length - 1) break;   // air 那条可能报 0 blocks
        if (round < 2) await sleep(4000);
    }

    // 真值闸门：坐标与判据全部取自 scene.mjs（单一真源，P8_MICRO3 就是两份坐标不一致翻的车）
    const CHECKS = sceneChecks();
    const t0 = Date.now();
    let pending = CHECKS;
    while (Date.now() - t0 < 60000) {
        pending = [];
        for (const c of CHECKS) {
            const mark = `@@Y${Date.now().toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`;
            const id = rpc.nextId('chk');
            await rpc.call(rpc, id, `execute if block ${c.x} ${c.y} ${c.z} minecraft:${c.b} run say ${mark}`, { timeoutMs: 20000, logFn: log });
            // 标记要真的出现在 server.log 里才算服务端答了
            const deadline = Date.now() + 4000;
            let ok = false;
            while (Date.now() < deadline) {
                if (tailFile(logPath, 65536).includes(mark)) { ok = true; break; }
                await sleep(120);
            }
            if (!ok) pending.push(`${c.what}@${c.x},${c.y},${c.z} 期望 ${c.b}`);
        }
        if (!pending.length) break;
        await sleep(800);
    }
    const okAll = pending.length === 0;
    log(okAll
        ? `场景就位（服务端真值 ${CHECKS.length}/${CHECKS.length} 通过，${((Date.now() - t0) / 1000).toFixed(1)}s）`
        : `⚠ 场景真值未通过：${JSON.stringify(pending)}（${((Date.now() - t0) / 1000).toFixed(1)}s）`);
    return { ok: okAll, failed: pending };
}

function portBusy(port) {
    try {
        const txt = execSync('netstat -ano', { encoding: 'utf8' });
        return txt.split(/\r?\n/).some((l) => l.includes(`:${port}`) && l.includes('LISTENING'));
    } catch { return false; }
}

installRunnerHooks(LANE_B);

/** 等泳道 B 腾出来。别的线白天会开 2 条泳道、时不时占住 B（手册 §9 的 CPU 护栏口径），
 *  本线又不能抢它们的进程，所以这里排队等待而不是直接失败。
 *  ★ 判据不能只看端口：主线两批之间 25567 会短暂空闲，但那个目录正被别人循环起停服，
 *    抢进去删世界目录会报 ENOTEMPTY（P8_PROBE 实测踩过）。所以用 lane_guard 的
 *    「活的 runner 是否拥有这个目录」为准（_lib 06c P0 的泳道归属心跳）。 */
async function waitForLane(maxMs = LANE_WAIT_MS) {
    return waitLane(LANE_B, { maxMs, pollMs: 20000, onWait: (st) => log(`泳道 B 不可用（${st.why}），排队等待（最长 ${Math.round(maxMs / 60000)} 分钟）`) });
}

async function main() {
    const st1 = await waitForLane();
    if (!st1.usable) {
        console.error(`[portal-micro] 等不到泳道 B（${st1.why}），放弃（不干预别的线，请协调后再跑）`);
        process.exit(1);
    }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    // 内存排队期间别人可能抢走 B → 开机前复查（用归属心跳，不只看端口）
    const st2 = await waitForLane();
    if (!st2.usable) {
        console.error(`[portal-micro] 内存排队期间泳道 B 持续不可用（${st2.why}），放弃`);
        process.exit(1);
    }
    // 删世界目录前最后一次确认：活着别人的目录绝不碰
    const st3 = laneStatus(LANE_B);
    if (!st3.usable) {
        console.error(`[portal-micro] freshWorld 前发现泳道 B 已被占用（${st3.why}），放弃（不碰别人的世界）`);
        process.exit(1);
    }
    freshWorld(LANE_B, SEED);
    const server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    log(`micro: server up in ${(server.bootMs / 1000).toFixed(0)}s seed=${SEED} n=${N}`);
    LANE_B.serverChild = server.child;

    // ★ 服控 RPC 通道：bot 要的所有控制台命令都经这里进 server.stdin（手册 §2）
    //   不用游戏内聊天：P8_PROBE2 实测短时间连发的聊天命令被服务端静默丢弃，
    //   而且 /setblock 成功不打日志 → 「命令丢了」和「命令成了」在日志上无法区分。
    const rpc = makeRpc(RPC_DIR);
    const rpcSrv = serveRpc({ reqDir: rpc.reqDir, doneDir: rpc.doneDir, serverChild: server.child, log });

    // op：微基准要 setblock/fill/tp/give
    try { server.child.stdin.write(`op ${LANE_B.username}\n`); } catch { /* 忽略 */ }
    await sleep(1500);

    // ★ 顺序很重要：先起 bot（它会等 setup.json），再摆场景，最后放行。
    //   反过来（先等 bot 进服再 spawn）会死锁——P8_PROBE3 就这么卡了 180s。
    const botLog = fs.openSync(path.join(RUNS_DIR, 'bot_console.log'), 'w');
    const bot = spawn(NODE20, [path.join(BENCH_DIR, 'micro_bot.mjs'), '--out', RUNS_DIR,
        '--port', String(LANE_B.serverPort), '--username', LANE_B.username,
        '--mc-version', MC_VERSION, '--n', String(N), '--seed', SEED,
        '--rpc', RPC_DIR,
        ...(process.argv.includes('--probe-only') ? ['--probe-only'] : [])],
        { stdio: ['ignore', botLog, botLog] });

    // 等 bot 进服
    const logPath = path.join(RUNS_DIR, 'server.log');
    const tJoin = Date.now();
    let joined = false;
    while (Date.now() - tJoin < 180000) {
        try { if (tailFile(logPath, 65536).includes('joined the game')) { joined = true; break; } } catch { /* 忽略 */ }
        await sleep(1000);
    }
    if (!joined) {
        log('micro: bot 180s 未进服，停服收工');
        try { rpcSrv.stop(); } catch { /* 忽略 */ }
        try { killTree(bot.pid); } catch { /* 忽略 */ }
        await stopServer(LANE_B, server);
        process.exit(1);
    }
    // op 必须在 bot 进服后补一次（ops.json 已有 TaskBotB，这里兜底）
    try { server.child.stdin.write(`op ${LANE_B.username}\n`); } catch { /* 忽略 */ }
    await sleep(1000);

    // ★ 服务端真值闸门：场景没真的摆好就不开测
    //   （06c 教训：摆地形时量到的是「地形还没摆好」的假数字。P8_PROBE2 正是栽在这。）
    const sceneOk = await setupSceneAndVerify({ rpc, logPath, log });
    fs.writeFileSync(path.join(RUNS_DIR, 'setup.json'), JSON.stringify({ op: LANE_B.username, sceneOk, at: new Date().toISOString() }, null, 2));
    if (!sceneOk.ok) {
        log(`⚠ 场景未按预期就位：${JSON.stringify(sceneOk.failed)} —— 仍然开跑，但结果一律标记 sceneBad=true（不计入达标判定）`);
    }

    await new Promise((resolve) => {
        const t0 = Date.now();
        const iv = setInterval(() => {
            if (fs.existsSync(DONE) || bot.exitCode !== null || Date.now() - t0 > 30 * 60 * 1000) {
                clearInterval(iv); resolve();
            }
        }, 2000);
    });

    await stopServer(LANE_B, server);

    // 汇总
    const rows = [];
    try { for (const l of fs.readFileSync(ROWS, 'utf8').split(/\r?\n/).filter(Boolean)) rows.push(JSON.parse(l)); } catch { /* 无数据 */ }
    const byOp = {};
    for (const r of rows) {
        byOp[r.op] = byOp[r.op] ?? { n: 0, ok: 0, ms: [] };
        byOp[r.op].n++;
        if (r.ok) { byOp[r.op].ok++; byOp[r.op].ms.push(r.ms ?? 0); }
    }
    const median = (a) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
    const acceptance = Object.entries(byOp).map(([op, v]) => {
        const rate = v.n ? (v.ok / v.n) * 100 : 0;
        return { op, n: v.n, ok: v.ok, rate: +rate.toFixed(1), medianMs: median(v.ms), pass: rate >= THRESHOLD };
    });
    const agg = { stamp: STAMP, seed: SEED, n: N, threshold: THRESHOLD, acceptance, byOp, allPass: acceptance.every((a) => a.pass) };
    fs.writeFileSync(path.join(RUNS_DIR, 'aggregate.json'), JSON.stringify(agg, null, 2));

    const md = [
        `# MC-M1-TASK-08 新原语微基准（${STAMP}）`, '',
        `- 种子：\`${SEED}\`（fresh）`, `- 每项批量：${N} 次`, `- 验收线：成功率 ≥ ${THRESHOLD}%`, '',
        '| 原语 | 次数 | 成功 | 成功率 | 中位耗时(ms) | 判定 |', '|---|---|---|---|---|---|',
        ...acceptance.map((a) => `| ${a.op} | ${a.n} | ${a.ok} | ${a.rate}% | ${a.medianMs ?? '-'} | ${a.pass ? '✅' : '❌'} |`),
        '', `**结论：${agg.allPass ? '全部达标，可接进状态机' : '有未达标项，不得接入状态机'}**`, '',
    ].join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'micro_report.md'), md);
    console.log(md);
    process.exit(agg.allPass ? 0 : 2);
}

main().catch((e) => { console.error(e); process.exit(1); });
