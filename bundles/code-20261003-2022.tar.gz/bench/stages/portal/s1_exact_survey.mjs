// s1_exact_survey.mjs — S1 门框**精确预勘**（离线存档解析 → SCHEMA §5 的 v2 `exact` / `legs`）
//
// 【为什么做这个】`docs/MC-DECISION-02-背作业路线与整链优先.md` 把策略从"运行时反推作业位"
//   改成**背作业**：预勘这一步离线读 .mca，直接吐出精确到格的门框、站位、补格顺序和路点，
//   任务层照着走。输出形状由 `bench/route/SCHEMA.md` §5 钉死（`stations[].exact` + 顶层 `legs`）。
//   手册 §5「只读预勘一律走存档解析器」⇒ 本文件**不连客户端、不开服、不占端口**，只 import region_reader。
//
// 【为什么"不合法就大声失败"比"多覆盖"重要】门框几何一旦认错，后面算出来的站位、补格顺序、路点
//   **全都长得像正确答案**（它们只是"错框的正确答案"）。r18 §1.3 就是这一类：只按水平距离排序，
//   把"水平 0 格、垂直 6 格"的门框顶排成了第一优站位 —— 形式上最优、实际上最差。
//   ⇒ 几何不满足合法 4×5 环时，本工具**退出码 3 且不写 --out 文件**（宁可什么也不产出）。
//
// 【两条通道永不合并】r18 §1.1：`precheckTargetLava` 把"站位安不安全""施工安不安全""邻域有没有岩浆"
//   混成一个判据，导致刚判干净的 20 个站位被逐个拒掉，同一行遥测里 `threat.lava=[]` 与
//   `pre=target_lava_adjacent` 并排打脸。⇒ 本文件把
//   · 通道 A `hazards` = 扫描盒内**全部**危险格（导航护栏用）
//   · 通道 B `hazardsNearStand` / `standHazards` = **站位 2 格内**（"我站这儿会不会死"用）
//   分成两个字段、两个打印小节，任何时候不合成一个判据。
//
// 【排序主键为什么是 3-D 上升量】r18 §1.3 的原话："reach 只量水平"这件事就写在注释里，
//   排序时忘了它有个孪生维度。⇒ 站位排序**主键 = 最大 |Δy|**（3-D 上升量），
//   水平距离只当第 3 键；两个距离**都**输出（`reachH` 水平 / `reach3` 三维）。
//
// 用法（Node 必须是 20.x，见手册 §2：mindcraft 链在 Node 24 上会坏）：
//   cd D:\AI斗蛐蛐\bench\stages\portal
//   & 'D:\AI斗蛐蛐\.runtime\node-v20.20.2-win-x64\node.exe' s1_exact_survey.mjs `
//     --world <worldDir> --out <jsonPath> [--frame-x 187] [--frame-y0 39] [--frame-z0 307] `
//     [--entry 206,64,242] [--max-leg 32]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from '../../route/tools/region_reader.mjs';

// ================================================================== 默认参数
/**
 * 扫描盒的默认偏移：**由提示点推出给定默认盒**，不是拍脑袋的。
 * 任务层给的默认盒是 x183..192 / y36..46 / z303..313，提示点 (187,39,307)，
 * 相对偏移正是 x[-4,+5] / y[-3,+7] / z[-4,+6] ⇒ 钉成常量，换种子换提示点时盒子自动跟着平移。
 * 盒子比 4×5 的框大一大圈是手册 §5 的硬要求（"扫描范围要比目标大一圈"）。
 */
export const BOX_OFFSET = Object.freeze({ x1: -4, x2: +5, y1: -3, y2: +7, z1: -4, z2: +6 });

export const DEFAULTS = Object.freeze({
    frameX: 187, frameY0: 39, frameZ0: 307,      // 提示点（只用来推盒子，不参与几何判定）
    entry: Object.freeze([206, 64, 242]),        // 地表出发点（主种子）
    maxLeg: 32,                                  // SCHEMA §5：相邻路点 ≤ 32 格
    standPad: 3, standYPad: 3,                   // 站位枚举盒 = 框盒外扩
    maxHoriz: 4, maxRise: 2,                     // 任务层的够得到预算（r18 §2.1 同口径）
    minFrame: 4,                                 // 环里至少 4 格黑曜石族，否则那不是门框、是个洞
    maxResidual: 2,                              // 框外紧贴的黑曜石族 ≥2 ⇒ 框多半不是 4×5
    navPad: 4,                                   // 导航盒 = (entry ∪ 框盒 ∪ 站位) 外扩
    hazardNearRadius: 2,                         // 通道 B 的半径（2 格）
    maxNavCells: 400000,                         // 导航盒格子上限，超了**大声失败**而不是硬跑
    maxNodes: 200000,                            // BFS 展开上限，同上
    stationId: 'S1_portal',
    dim: 'overworld',
});

// ================================================================== 判据常量
/** 1.13+ 的三个空气方块（与 `route/tools/visibility_audit.mjs` 的 AIRLIKE 同口径；cave/void air 在 1.16.1 存在）。 */
export const AIRLIKE = new Set(['air', 'cave_air', 'void_air']);

/** 危险族：岩浆（源块与流动）、岩浆块。1.16.1 没有 `flowing_lava` 这个方块 id（见 `lavaKind`）。 */
export const HAZARD = new Set(['lava', 'flowing_lava', 'magma_block']);

/** 液体（站位判据里"实心"的反面；水不致命但脚下是水同样不能算作业面）。 */
export const LIQUID = new Set(['water', 'lava', 'flowing_water', 'flowing_lava']);

/**
 * 不可破坏族：这些格"不是缺格"，是**这个门框修不了**（基岩 / 已点燃的门框 / 屏障）。
 * 撞上它们要**大声失败**，不能塞进 needs_dig 假装能挖。
 */
export const UNBREAKABLE = new Set(['bedrock', 'barrier', 'structure_void', 'portal', 'end_portal', 'nether_portal', 'end_portal_frame', 'end_gateway']);

/**
 * "非实心"名单（deny-list）：未列出的方块一律按实心处理。
 * ⚠ **口径边界写在这里**（r18 §1.3 的教训：度量的维度要写出来，别让下一个人以为是白名单）：
 *   · 半砖/楼梯**按可站处理**（速通里作业面经常是半砖，把它们判成不可站会砍掉全部站位）；
 *   · 1.16 的植物、液体、细方块已列全；本表漏了新方块时表现是"把不可站的当可站"，
 *     不会表现为"把可站的判死"——这是我们**故意选的方向**（宁可多列候选，不可漏列站位）。
 */
export const NON_FULL = new Set([
    'air', 'cave_air', 'void_air', 'water', 'lava', 'flowing_water', 'flowing_lava', 'magma_block',
    'short_grass', 'grass', 'fern', 'large_fern', 'dead_bush', 'dead_plant', 'seagrass', 'tall_seagrass',
    'vine', 'glow_lichen', 'sculk_veins' /* 1.16 还没有，但占位免得以后加 */,
    'torch', 'wall_torch', 'soul_torch', 'redstone_torch', 'lever', 'tripwire_hook', 'tripwire',
    'rail', 'powered_rail', 'detector_rail', 'activator_rail', 'golden_rail',
    'ladder', 'scaffolding', 'cobweb', 'string', 'painting', 'item_frame', 'flower_pot',
    'poppy', 'dandelion', 'blue_orchid', 'allium', 'azure_bluet', 'red_tulip', 'orange_tulip',
    'white_tulip', 'pink_tulip', 'oxeye_daisy', 'cornflower', 'lily_of_the_valley', 'wither_rose',
    'brown_mushroom', 'red_mushroom', 'crimson_fungus', 'warped_fungus', 'crimson_roots', 'warped_roots',
    'nether_sprouts', 'sugar_cane', 'bamboo', 'wheat', 'carrots', 'potatoes', 'beetroots', 'cocoa',
    'snow', 'snow_layer', 'carpet', 'stone_button', 'polished_blackstone_button', 'pressure_plate',
    'light_weighted_pressure_plate', 'heavy_weighted_pressure_plate', 'fire', 'soul_fire', 'lava_rail' ,
]);

/** 工具名只作**信息**输出（r18 明确不需要按硬度分级，工具由任务层决定）。岩浆/水只能舀。 */
const TOOL_OF = new Map([
    ['obsidian', 'diamond_pickaxe'], ['crying_obsidian', 'iron_pickaxe'],
    ['dirt', 'iron_shovel'], ['grass_block', 'iron_shovel'], ['coarse_dirt', 'iron_shovel'],
    ['sand', 'iron_shovel'], ['gravel', 'iron_shovel'], ['podzol', 'iron_shovel'],
]);

const DIRS6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
/**
 * 4 邻接，**两项** `[dx, dz]`。
 * ⚠ 这里刻意是两项而不是跟 DIRS6 一样的三项：初版写成 `[[0,0,1],[0,0,-1]]` 却按
 *   `for (const [dx,dz] of DIRS4)` 解构 ⇒ z 方向的位移恒为 0，BFS 退化成一条直线，
 *   遇到任何"需要拐个弯"的路线都报 `no_safe_path` —— 而那看起来**完全像一个正常的失败结论**。
 *   形状不匹配是纯静默的：没有异常、没有一个字提到它（T6 抓到）。
 */
const DIRS4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];

export const CLS = Object.freeze({
    OBSIDIAN: 'obsidian', CRYING: 'crying_obsidian', DIG: 'needs_dig', FILL: 'needs_fill', OTHER: 'other',
});

/** 退出码（父 agent/脚本按这个分流，别只看 stdout 文本） */
export const EXIT = Object.freeze({ OK: 0, USAGE: 2, GEOMETRY_REJECTED: 3, ERROR: 1 });

// ================================================================== 方块读取（oracle 侧）
/**
 * 归一名：`minecraft:obsidian` → `obsidian`；**读不到的一律归 `null`（= unknown）**。
 * ⚠ `region_reader.blockAt` 在**区块未保存 / 该 y 段没有 section** 时返回 `'unknown'`
 *   （HANDOVER 2026-10-03 跨线通告：运行时 `blockAt` 对未加载区块返 null）。
 *   本函数把 null / '' / 'unknown' **全部**收成 `null`，这样下游"读不到"只有一个表示，
 *   不会再出现"某一处把 unknown 当成空气"的分叉（手册 §5：没读到 ≠ 没有）。
 */
export function normalizeName(raw) {
    if (raw === null || raw === undefined) return null;
    let s = String(raw).trim().toLowerCase();
    if (s.startsWith('minecraft:')) s = s.slice('minecraft:'.length);
    if (s === '' || s === 'unknown' || s === 'null' || s === 'undefined') return null;
    return s;
}

/**
 * 造 oracle：包一层读写缓存 + 归一。**所有判据函数只认 `get` / `getState` 两个回调**，
 * 逻辑里不出现 `World` 实例（自检要用合成世界驱动同一套判据，逻辑里塞 World 就没法离线钉）。
 * @param {(x:number,y:number,z:number)=>string|null} get
 * @param {(x:number,y:number,z:number)=>{name:string,props:object|null}|null} [getState]
 */
export function makeOracle(get, getState = null) {
    if (typeof get !== 'function') throw new Error('makeOracle：get 必须是 (x,y,z) => name|null');
    const cName = new Map(), cState = new Map();
    const key = (x, y, z) => `${x},${y},${z}`;
    // ⚠ 用闭包计数器而不是 `this.reads`：判据函数里 `get` 是被解构出来单独调用的，
    //   方法里的 `this` 那是 undefined（第一次自检就撞上了）。
    let reads = 0;
    return {
        get reads() { return reads; },
        get(x, y, z) {
            const k = key(x, y, z);
            if (cName.has(k)) return cName.get(k);
            reads++;
            const v = normalizeName(get(x, y, z));
            cName.set(k, v);
            return v;
        },
        /** 状态读（液体 level 等）。**只在确实需要时调**——没有 getState 时按"分不出来"处理，不猜。 */
        getState(x, y, z) {
            if (!getState) return null;
            const k = key(x, y, z);
            if (cState.has(k)) return cState.get(k);
            reads++;
            const raw = getState(x, y, z);
            const v = raw ? { name: normalizeName(raw.name), props: raw.props ?? null } : null;
            cState.set(k, v);
            return v;
        },
    };
}

/** 单格读取结果。`known=false` 就是"读不到"，**任何分支都不得把它当空气**。 */
export function readCell(get, x, y, z) {
    const name = get(x, y, z);
    return { xyz: [x, y, z], name, known: name !== null };
}

/**
 * 岩浆**种类**。
 * ⚠ 1.16.1 **没有** `flowing_lava` 这个方块 id：源块与流动岩浆同名 `lava`，靠 `Properties.level` 区分
 *   （level=0 是源，1..7 是流动；见 region_reader `normalizeProps` 的 v1.1 注释，它已经把字符串转成 number）。
 *   只拿到名字时**分不出来就如实报 `lava`**，不猜成源块（手册 §5）。
 */
export function lavaKind(name, props) {
    if (name !== 'lava' && name !== 'flowing_lava') return null;
    if (name === 'flowing_lava') return 'flowing_lava';
    const lv = props && props.level !== undefined && props.level !== null ? Number(props.level) : NaN;
    if (!Number.isFinite(lv)) return 'lava';                 // 没有状态 ⇒ 如实说"就是 lava"
    return lv === 0 ? 'lava_source' : 'flowing_lava';
}

/** 危险判据：岩浆（任意形态）与岩浆块。`name=null`（读不到）**不算**危险，但也不算安全 —— 见 `standOk`。 */
export function isHazardName(name) { return name !== null && HAZARD.has(name); }

export function isAirLike(name) { return name !== null && AIRLIKE.has(name); }

/** 实心（能站上去）：非空气、非液体、非细方块。半砖/楼梯**算**实心（见 NON_FULL 的口径说明）。 */
export function isFullSolid(name) { return name !== null && !NON_FULL.has(name); }

/** 环内一格的分类。`null`（读不到）⇒ `other`，**绝不**归 needs_fill（那是"读到了是空气"）。 */
export function classifyRingCell(name) {
    if (name === null) return CLS.OTHER;
    if (name === 'obsidian') return CLS.OBSIDIAN;
    if (name === 'crying_obsidian') return CLS.CRYING;
    if (AIRLIKE.has(name)) return CLS.FILL;
    if (UNBREAKABLE.has(name)) return CLS.OTHER;
    return CLS.DIG;
}

/** 挖格用的工具（信息字段）。液体只能舀；其余按镐。 */
export function toolForCell(name) {
    if (name === null) return null;
    if (LIQUID.has(name)) return 'bucket';
    return TOOL_OF.get(name) ?? 'iron_pickaxe';
}

// ================================================================== 盒工具
const inBox = (b, x, y, z) => x >= b.x1 && x <= b.x2 && y >= b.y1 && y <= b.y2 && z >= b.z1 && z <= b.z2;
const cheb3 = (a, b) => Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1]), Math.abs(a[2] - b[2]));
const cheb2 = (a, b) => Math.max(Math.abs(a[0] - b[0]), Math.abs(a[2] - b[2]));
const key3 = (a) => `${a[0]},${a[1]},${a[2]}`;

export function makeBox(x1, y1, z1, x2, y2, z2) {
    return {
        x1: Math.min(x1, x2), y1: Math.min(y1, y2), z1: Math.min(z1, z2),
        x2: Math.max(x1, x2), y2: Math.max(y1, y2), z2: Math.max(z1, z2),
    };
}

export function expandBox(b, pad, ypad = pad) { return makeBox(b.x1 - pad, b.y1 - ypad, b.z1 - pad, b.x2 + pad, b.y2 + ypad, b.z2 + pad); }

export function boxContains(b, xyz) { return inBox(b, xyz[0], xyz[1], xyz[2]); }

export function boxCells(b) {
    const out = [];
    for (let y = b.y1; y <= b.y2; y++) for (let z = b.z1; z <= b.z2; z++) for (let x = b.x1; x <= b.x2; x++) out.push([x, y, z]);
    return out;
}

export const boxSize = (b) => (b.x2 - b.x1 + 1) * (b.y2 - b.y1 + 1) * (b.z2 - b.z1 + 1);

export function boxLabel(b) { return `x${b.x1}..${b.x2}/y${b.y1}..${b.y2}/z${b.z1}..${b.z2}`; }

/** 由提示点 + BOX_OFFSET 推扫描盒（复现任务层给的默认盒，见 BOX_OFFSET 注释）。 */
export function boxFromHint(fx, fy, fz) {
    return makeBox(fx + BOX_OFFSET.x1, fy + BOX_OFFSET.y1, fz + BOX_OFFSET.z1, fx + BOX_OFFSET.x2, fy + BOX_OFFSET.y2, fz + BOX_OFFSET.z2);
}

/** 盒内直方图 + 读不到的格 + 危险格 —— **一趟扫完**三个通道，别扫三遍（顺带保证三通道口径一致）。 */
export function scanBox(get, getState, box) {
    const unknown = [], hazards = [], counts = {};
    for (const c of boxCells(box)) {
        const name = get(c[0], c[1], c[2]);
        if (name === null) { unknown.push(c); continue; }         // ⚠ 不进 counts：不读 ≠ 空气
        counts[name] = (counts[name] ?? 0) + 1;
        if (HAZARD.has(name)) {
            const st = getState ? getState(c[0], c[1], c[2]) : null;
            hazards.push({ xyz: c, name, kind: lavaKind(name, st?.props) ?? name, stateKnown: !!st });
        }
    }
    return { box, cells: boxSize(box), counts, unknown, hazards };
}

// ================================================================== A. 门框几何
/**
 * 4×5 矩形的 20 格：环 14 格（`j==0 || j==4 || i==0 || i==3`）+ 内部 2×3 = 6 格。
 * 1.16.1 的下界传送门框：**外框 4 宽 × 5 高、内开口 2×3、框本身 1 格厚**。
 * @param {'z'|'x'} orient 'z' = 框躺在 z 恒定的一面（沿 x/y 展开）；'x' = 反过来。
 */
export function rectCells(origin, orient) {
    const all = [], ring = [], interior = [];
    for (let j = 0; j < 5; j++) for (let i = 0; i < 4; i++) {
        const c = orient === 'z' ? [origin[0] + i, origin[1] + j, origin[2]] : [origin[0], origin[1] + j, origin[2] + i];
        all.push(c);
        if (j === 0 || j === 4 || i === 0 || i === 3) ring.push(c); else interior.push(c);
    }
    return { all, ring, interior, orient, origin: [...origin] };
}

/**
 * 在盒内枚举所有 4×5 候选矩形，**按可审计的评分排序**返回（不裁决，只给料）。
 *
 * 排序键（手册 §5：并列必须显式打破）：
 *   1. 环里黑曜石族格数 ↓（真门框几乎必有大部分环格）
 *   2. 环里 needs_dig 格数 ↑（挖的越少越好）
 *   3. 环里 needs_fill 格数 ↑
 *   4. 环里 other 格数 ↑
 *   5. 环里读不到格数 ↑
 *   6. 到提示点的 3-D 距离 ↑（只当**末位**的平手裁决，绝不当主要判据）
 *   7. 原点 [x,y,z] 升序
 */
export function findFrameCandidates(get, box, opt = {}) {
    const out = [];
    for (const orient of ['z', 'x']) {
        // 'z' 平面：z 恒定 ⇒ 横向沿 x 展开、层数沿 y；'x' 平面反过来。
        const aLo = orient === 'z' ? box.x1 : box.z1, aHi = orient === 'z' ? box.x2 : box.z2;
        const pLo = orient === 'z' ? box.z1 : box.x1, pHi = orient === 'z' ? box.z2 : box.x2;
        for (let p = pLo; p <= pHi; p++) {
            for (let y0 = box.y1; y0 + 4 <= box.y2; y0++) {
                for (let a0 = aLo; a0 + 3 <= aHi; a0++) {
                    const origin = orient === 'z' ? [a0, y0, p] : [p, y0, a0];
                    const rect = rectCells(origin, orient);
                    const s = { obsidian: 0, crying: 0, dig: 0, fill: 0, other: 0, unknown: 0 };
                    for (const c of rect.ring) {
                        const n = get(c[0], c[1], c[2]);
                        if (n === null) { s.unknown++; continue; }
                        switch (classifyRingCell(n)) {
                            case CLS.OBSIDIAN: s.obsidian++; break;
                            case CLS.CRYING: s.crying++; break;
                            case CLS.FILL: s.fill++; break;
                            case CLS.DIG: s.dig++; break;
                            default: s.other++; break;
                        }
                    }
                    out.push({
                        origin, orient, rect,
                        score: { frame: s.obsidian + s.crying, dig: s.dig, fill: s.fill, other: s.other, unknown: s.unknown },
                        blocks: s,
                    });
                }
            }
        }
    }
    const hint = opt.hint ?? null;
    out.sort((a, b) =>
        b.score.frame - a.score.frame || a.score.dig - b.score.dig || a.score.fill - b.score.fill ||
        a.score.other - b.score.other || a.score.unknown - b.score.unknown ||
        (hint ? cheb3(a.origin, hint) - cheb3(b.origin, hint) : 0) ||
        a.origin[0] - b.origin[0] || a.origin[1] - b.origin[1] || a.origin[2] - b.origin[2]);
    return out;
}

/**
 * 几何裁决：**不合法就大声失败**。
 *
 * 合法 4×5 环的判据（全部满足才 ok）：
 *   ① 盒里存在 4×5 候选；
 *   ② 环里**读不到**的格 = 0（读不到 ⇒ 几何判不定 ⇒ 不能给坐标）；
 *   ③ 环里 `other`（不可破坏族）= 0；
 *   ④ 环里黑曜石族 ≥ `--min-frame`（默认 4；一个洞不算门框）；
 *   ⑤ **残差检查**：框外与框紧贴（3-D Chebyshev ≤1）的黑曜石族格 < `--max-residual`（默认 2）。
 *      ⑤ 是关键：4×6 的框同样能切出两个"14 格全中"的 4×5，
 *      只有残差检查能把"切出来的"和"本来的"分开（否则会输出一份很像样的错坐标）。
 */
export function resolveFrame(get, box, opt = {}) {
    const minFrame = opt.minFrame ?? DEFAULTS.minFrame;
    const maxResidual = opt.maxResidual ?? DEFAULTS.maxResidual;
    const cands = findFrameCandidates(get, box, opt);
    const detail = { candidates: cands.slice(0, 5).map((c) => ({ origin: c.origin, orient: c.orient, score: c.score })) };
    if (!cands.length) return { ok: false, why: 'no_4x5_candidate_in_box', box, detail };

    const best = cands[0];
    const fail = (why, extra = {}) => ({ ok: false, why, box, best, detail, ...extra });

    if (best.score.unknown > 0) {
        const cells = best.rect.ring.filter((c) => get(c[0], c[1], c[2]) === null);
        return fail('ring_cells_unreadable', { cells });   // 手册 §5：没读到 ≠ 没有，不许猜
    }
    if (best.score.other > 0) {
        const cells = best.rect.ring.filter((c) => UNBREAKABLE.has(get(c[0], c[1], c[2]) ?? ''))
            .map((c) => ({ xyz: c, block: get(c[0], c[1], c[2]) }));
        // 已点燃的门框要单独说：它不是"缺格"，是这一站的前提就不成立。
        const lit = cells.some((c) => ['portal', 'nether_portal'].includes(c.block));
        return fail(lit ? 'ring_already_lit' : 'ring_has_unbreakable', { cells });
    }
    if (best.score.frame < minFrame) {
        return fail('too_little_frame_material', { frame: best.score.frame, minFrame, cells: [] });
    }

    // ⑤ 残差：框外、且紧贴框的黑曜石族格
    const inRect = new Set(best.rect.all.map(key3));
    const residual = [];
    for (const c of boxCells(box)) {
        if (inRect.has(key3(c))) continue;
        const n = get(c[0], c[1], c[2]);
        if (n !== 'obsidian' && n !== 'crying_obsidian') continue;
        if (best.rect.all.some((r) => cheb3(r, c) <= 1)) residual.push({ xyz: c, block: n });
    }
    if (residual.length >= maxResidual) {
        return fail('ring_not_4x5_residual', { residual, hint: `框外紧贴的黑曜石族 ${residual.length} 格 ≥ ${maxResidual} ⇒ 这个框不是 4×5` });
    }

    // ---- 逐格分类（几何过了才做，避免在错框上做功）
    const ring = best.rect.ring.map((c) => {
        const name = get(c[0], c[1], c[2]);
        const cls = classifyRingCell(name);
        return { xyz: c, cls, block: name, tool: cls === CLS.DIG ? toolForCell(name) : undefined };
    });
    const interior = best.rect.interior.map((c) => {
        const name = get(c[0], c[1], c[2]);
        const st = opt.getState ? opt.getState(c[0], c[1], c[2]) : null;
        return { xyz: c, block: name, known: name !== null, kind: name === null ? 'unknown' : (lavaKind(name, st?.props) ?? (isAirLike(name) ? 'air' : name)) };
    });
    const bbox = makeBox(
        Math.min(...best.rect.all.map((c) => c[0])), Math.min(...best.rect.all.map((c) => c[1])), Math.min(...best.rect.all.map((c) => c[2])),
        Math.max(...best.rect.all.map((c) => c[0])), Math.max(...best.rect.all.map((c) => c[1])), Math.max(...best.rect.all.map((c) => c[2])),
    );
    return {
        ok: true, why: null, box,
        plane: best.orient === 'z' ? 'z_const' : 'x_const',
        origin: best.origin, orient: best.orient, rect: best.rect,
        ring, interior, bbox, residual, detail,
        counts: {
            obsidian: ring.filter((r) => r.cls === CLS.OBSIDIAN).length,
            crying_obsidian: ring.filter((r) => r.cls === CLS.CRYING).length,
            needs_dig: ring.filter((r) => r.cls === CLS.DIG).length,
            needs_fill: ring.filter((r) => r.cls === CLS.FILL).length,
            other: ring.filter((r) => r.cls === CLS.OTHER).length,
            unreadable: ring.filter((r) => r.block === null).length,
            ringTotal: ring.length, interiorTotal: interior.length,
        },
    };
}

// ================================================================== B. 站位
/**
 * 站位合法判据（**四个独立分支，每个分支只回答一个问题**——r18 §1.1：
 *  混成一个判据就会出现"同一格两套结论并排出现"的现场）。
 *  ① 脚下那格：实心、非危险、**读到了**  ② 脚格：空气类、非危险、读到了
 *  ③ 头格：空气类、非危险、读到了
 * @returns {{ok:boolean, why:string}} `why` 永远具体到分支，**不给"不合格"这种笼统话**
 */
export function standOk(get, x, y, z) {
    const below = get(x, y - 1, z);
    if (below === null) return { ok: false, why: 'below_unreadable' };      // ⚠ 读不到 = 不许当实心
    if (HAZARD.has(below)) return { ok: false, why: 'below_is_hazard' };     // ★ 自检 5 钉的就是这一支
    if (!isFullSolid(below)) return { ok: false, why: 'below_not_full_solid' };
    const feet = get(x, y, z);
    if (feet === null) return { ok: false, why: 'feet_unreadable' };
    if (HAZARD.has(feet)) return { ok: false, why: 'feet_is_hazard' };
    if (!AIRLIKE.has(feet)) return { ok: false, why: 'feet_not_air' };
    const head = get(x, y + 1, z);
    if (head === null) return { ok: false, why: 'head_unreadable' };
    if (HAZARD.has(head)) return { ok: false, why: 'head_is_hazard' };
    if (!AIRLIKE.has(head)) return { ok: false, why: 'head_not_air' };
    return { ok: true, why: null };
}

/**
 * 站位 → 目标的够得到度量。**两个维度都算、都输出**（r18 §1.3 的原话：
 * "reach 只量水平"这件事就写在注释里，排序时忘了它有个孪生维度）。
 * @param {[number,number,number]} s  站位脚格
 * @param {Array<{xyz:number[]}>} targets
 */
export function reachMetrics(s, targets, opt = {}) {
    const maxHoriz = opt.maxHoriz ?? DEFAULTS.maxHoriz;
    const maxRise = opt.maxRise ?? DEFAULTS.maxRise;
    const m = {
        reachH: 0, sumH: 0,          // 水平（Chebyshev XZ）
        rise: 0, meanRise: 0,        // 垂直：rise = 最大 |Δy|（**主排序键**），meanRise = 平均 |Δy|
        riseUp: -Infinity,           // 目标最高比脚格高多少（**可以为负**：站位在目标之上就是负的）
        reach3: 0, sum3: 0,          // 三维（Chebyshev XYZ）
        broken: [],                  // 够不到的目标（**要说清是哪些**，r18 §5：拒了 0 个 vs 没看，长得一模一样）
    };
    let sumAbs = 0;
    for (const t of targets) {
        const h = cheb2(s, t.xyz), dy = t.xyz[1] - s[1], a = Math.abs(dy), d3 = Math.max(h, a);
        if (h > m.reachH) m.reachH = h;
        if (a > m.rise) m.rise = a;
        if (dy > m.riseUp) m.riseUp = dy;
        if (d3 > m.reach3) m.reach3 = d3;
        m.sumH += h; m.sum3 += d3; sumAbs += a;
    }
    // ⚠ riseUp 必须允许负数（站位在目标之上时全是负的）。初版把它初始化成 0，
    //   于是"站在框顶上"永远报 riseUp=0 而不是 -6 —— 正是 r18 §1.3 那一类"度量少了一个维度还装作量到了"。
    //   同时 -Infinity 不能进 JSON，所以无目标时显式归 0。
    if (!targets.length) m.riseUp = 0;
    const n = Math.max(1, targets.length);
    m.sumH = targets.length ? m.sumH : 0;
    m.sum3 = targets.length ? m.sum3 : 0;
    m.meanRise = Math.round((sumAbs / n) * 1000) / 1000;
    for (const t of targets) {
        const h = cheb2(s, t.xyz), a = Math.abs(t.xyz[1] - s[1]);
        if (h > maxHoriz || a > maxRise) m.broken.push({ xyz: t.xyz, horiz: h, dy: a });
    }
    m.ok = m.broken.length === 0;
    m.budget = { maxHoriz, maxRise };
    return m;
}

/**
 * 站位排序规则（**主键 = 3-D 上升量**，第 1 条即 r18 §1.3 的修法）：
 *   0. `insideFrame` 是否站在门框开口里    ↓   ← **新增的分类前置键**，理由见 deriveStands 里的注释
 *   1. `rise`   最大 |Δy|（目标相对脚格）      ↑   ← 主键：3-D 上升量
 *   2. `meanRise` 平均 |Δy|                    ↑
 *   3. `reachH` 最大水平 Chebyshev             ↑   ← r18 里唯一那个 `reach`，只能排第 3
 *   4. `sumH`   水平距离之和                  ↑
 *   5. `reach3` 最大三维 Chebyshev             ↑
 *   6. `hazardsNear` 站位 2 格内危险格数       ↑   ← 通道 B：会不会死
 *   7. `centroid3` 到目标质心的三维**欧氏**距离 ↑  ← 并列站位里挑"正对作业面"的那个
 *   8. `[x, y, z]` 升序                        ← **收尾必须显式打破**（手册 §5：并列不打破 == 随机选）
 * 1↔3 的次序就是 r18 §1.3 的全部内容：把 1 和 3 换位，"水平 0 格、垂直 6 格"的门框顶就会排到第一。
 */
export const STAND_SORT_RULE =
    'insideFrame(人在门洞里吗)↓ → rise(最大|Δy|)↑ → meanRise↑ → reachH(水平Chebyshev)↑ → sumH↑ → reach3(三维Chebyshev)↑ → hazardsNear↑ → centroid3↑ → [x,y,z]↑（末位显式打破）';

/** 补格顺序规则：`riskAdjacent` 升序（0 先做）→ `openFaces` **降**序（外侧/好瞄准的先做）→ `y` 升序（自下而上）→ `reach3` 升序 → `[x,z]` 升序（显式收尾）。 */
export const PATCH_SORT_RULE =
    'riskAdjacent(邻接危险或读不到的格数)↑ → openFaces(框外空气面数)↓ → y(自下而上)↑ → reach3↑ → [x,z]↑（末位显式打破）';

/** 枚举站位：先判站得住吗（standOk），再判够得着吗（reachMetrics），两个问题两个函数。 */
export function deriveStands(get, geom, targets, opt = {}) {
    const pad = opt.standPad ?? DEFAULTS.standPad, ypad = opt.standYPad ?? DEFAULTS.standYPad;
    const nearR = opt.hazardNearRadius ?? DEFAULTS.hazardNearRadius;
    const cap = opt.standCap ?? 64;
    const standBox = expandBox(geom.bbox, pad, ypad);
    // 站位 2 格内的危险格（通道 B）：扫描范围 = 站位盒 **再外扩半径**，否则站位在盒边缘时
    // 2 格外的岩浆会落在扫描盒外 —— 那样"没扫到"会被读成"没有"，正是本项目最贵的一类静默失败（r18 §1.1）。
    const nearR2 = nearR + 1;   // 多扫 1 格冗余，避免边界差一格
    const nearBox = expandBox(standBox, nearR2, nearR2);
    const nearHazards = scanBox(get, opt.getState ?? null, nearBox).hazards;
    const centroid = targets.length
        ? [0, 1, 2].map((i) => targets.reduce((a, t) => a + t.xyz[i], 0) / targets.length)
        : [geom.origin[0] + 1.5, geom.origin[1] + 2, geom.origin[2]];
    const stands = [], excluded = [];
    const rectSet = new Set(((geom.rect?.all) ?? []).map(key3));
    const reasons = {};
    const put = (xyz, why, extra) => { reasons[why] = (reasons[why] ?? 0) + 1; if (excluded.length < cap) excluded.push({ xyz, why, ...extra }); };
    for (const c of boxCells(standBox)) {
        const s = standOk(get, c[0], c[1], c[2]);
        if (!s.ok) { put(c, s.why); continue; }                       // 分支①：站不站得住
        const m = reachMetrics(c, targets, opt);
        if (!m.ok) { put(c, 'target_out_of_reach', { broken: m.broken }); continue; }   // 分支②：够不够得着
        const near = nearHazards.filter((h) => cheb3(h.xyz, c) <= nearR).map((h) => h.xyz);
        // centroid3：到目标质心的**三维欧氏**距离（取整到 3 位小数）。
        // 为什么不用 Chebyshev：4 宽的框在质心方向上会整片打平成同一个值，末位只能退回 [x,y,z] 硬选，
        // 会选出"离作业面 3 格"的那种站位。欧氏 + 取整仍是完全确定的（手册 §5 只要求**显式**打破并列）。
        const centroid3 = Math.round(Math.hypot(c[0] - centroid[0], c[1] - centroid[1], c[2] - centroid[2]) * 1000) / 1000;
        // insideFrame：脚格落在 4×5 矩形内部（门洞里）⇒ 排在所有框外站位之后。
        // 【为什么不直接判它不合法】任务书给的合法判据是三条（脚下实心非危险 / 身体两格空气非危险），
        //   门洞里那格确实满足 —— 所以它**留在表里**（不隐藏），只是不排第一。
        // 【为什么仍要压后】门洞只有 2×3、内部常常就是岩浆（1.16 的废弃门框里堆岩浆是常态），
        //   站在里面补格 = 人被自己要点燃的门框围着；这不是"距离问题"，是"位置类别问题"，
        //   当成距离的第 N 键就会被"rise 很小"盖过去（自检 T7 抓到：rise=1 把它顶到第一）。
        const insideFrame = rectSet.has(key3(c));
        stands.push({ xyz: c, ...m, hazardsNear: near.length, nearList: near, centroid3, insideFrame });
    }
    stands.sort((a, b) =>
        Number(a.insideFrame) - Number(b.insideFrame) ||
        a.rise - b.rise || a.meanRise - b.meanRise || a.reachH - b.reachH || a.sumH - b.sumH ||
        a.reach3 - b.reach3 || a.hazardsNear - b.hazardsNear || a.centroid3 - b.centroid3 ||
        a.xyz[0] - b.xyz[0] || a.xyz[1] - b.xyz[1] || a.xyz[2] - b.xyz[2]);
    const excludedTotal = Object.values(reasons).reduce((a, b) => a + b, 0);
    return { stands, excluded, excludedTotal, truncated: Math.max(0, excludedTotal - excluded.length), standBox, reasons, targetCount: targets.length, centroid };
}

// ================================================================== C/D. 挖格与补格顺序
export function digCells(geom) {
    return geom.ring.filter((r) => r.cls === CLS.DIG)
        .map((r) => ({ what: 'dig', xyz: r.xyz, block: r.block, tool: r.tool ?? toolForCell(r.block) }));
}

/**
 * 补格顺序。`riskAdjacent` 把**读不到的邻格也算进去**（当挨着岩浆处理）——
 * 手册 §5「没读到 ≠ 没有」在排序里的落地：宁可把不确定的排后面，也不要先做它再发现旁边是岩浆。
 */
export function patchOrder(get, geom, stand) {
    const fills = geom.ring.filter((r) => r.cls === CLS.FILL);
    const inRect = new Set(geom.rect.all.map(key3));
    const items = fills.map((r) => {
        let risk = 0, open = 0;
        for (const [dx, dy, dz] of DIRS6) {
            const n = [r.xyz[0] + dx, r.xyz[1] + dy, r.xyz[2] + dz];
            const b = get(n[0], n[1], n[2]);
            if (b === null) { risk++; continue; }                    // ⚠ 读不到 = 当危险
            if (HAZARD.has(b)) { risk++; continue; }
            if (AIRLIKE.has(b) && !inRect.has(key3(n))) open++;      // 框外的空气面 = 好瞄准
        }
        return { cell: r, riskAdjacent: risk, openFaces: open, reach3: stand ? cheb3(stand, r.xyz) : 0 };
    });
    items.sort((a, b) =>
        a.riskAdjacent - b.riskAdjacent || b.openFaces - a.openFaces || a.cell.xyz[1] - b.cell.xyz[1] ||
        a.reach3 - b.reach3 || a.cell.xyz[0] - b.cell.xyz[0] || a.cell.xyz[2] - b.cell.xyz[2]);
    return items.map((it, i) => ({
        what: 'fill_cell', xyz: it.cell.xyz, order: i + 1, how: 'two_bucket',
        block: it.cell.block, riskAdjacent: it.riskAdjacent, openFaces: it.openFaces, reach3: it.reach3,
    }));
}

// ================================================================== E. 危险（两通道）
/** 通道 A：盒内全部危险格（导航护栏直接用）。 */
export function hazardsInBox(scan) { return scan.hazards.map((h) => h.xyz); }

/** 通道 B：站位 2 格内的危险格，**按站位分组**。与通道 A 不合并、不互相替代（r18 §1.1）。 */
export function hazardsNearStands(hazards, stands, radius = DEFAULTS.hazardNearRadius) {
    return stands.map((s) => ({ stand: s.xyz, n: hazards.filter((h) => cheb3(h.xyz, s.xyz) <= radius).length, near: hazards.filter((h) => cheb3(h.xyz, s.xyz) <= radius).map((h) => h.xyz) }));
}

// ================================================================== F. 路点
/**
 * 从 entry 到作业站位规划路点。**宁可说走不通，也不给一条"看起来安全"的链**。
 *
 * 模型：4 连通的"可走"格（`standOk` 的三条全过 = 脚下实心非危险 + 身体两格空气非危险）。
 * · 这个模型里 y 的相邻步长**只能是 -1/0/+1**（可走格的脚下就是实心）⇒ 链里不可能有摔死，
 *   剩下唯一的致命物是岩浆，已被排除。
 * ⚠ **代价（要知道）**：真实地形里 2 格以上的落差（崖、矿洞竖井口）在这个模型里走不通，
 *   而真人会跳下去。宁可报 `no_safe_path`，也不出一条可能摔死的链 —— 但这确实**低估可达性**，
 *   真出现 no_safe_path 时先怀疑这里，再怀疑地形（notes 里写了走得到多少格，可据此分辨
 *   "完全走不动"和"走到了半路"）。
 * · 站位 2 格内有岩浆**不影响**可走性：作业面旁边有岩浆带是常态（r18 §1.1 记录 y=40 整层就是岩浆带），
 *   判"站上去会不会死"是通道 B 的事，不是导航过不去的理由 —— 两者混起来会砍掉全部站位。
 */
export function planLeg(get, entry, stand, opt = {}) {
    const maxLeg = opt.maxLeg ?? DEFAULTS.maxLeg;
    const navPad = opt.navPad ?? DEFAULTS.navPad;
    const maxNodes = opt.maxNodes ?? DEFAULTS.maxNodes;
    const maxNavCells = opt.maxNavCells ?? DEFAULTS.maxNavCells;
    const frameBox = opt.frameBox ?? null;
    const boxes = [makeBox(entry[0], entry[1], entry[2], entry[0], entry[1], entry[2]), makeBox(stand[0], stand[1], stand[2], stand[0], stand[1], stand[2])];
    if (frameBox) boxes.push(frameBox);
    let box = boxes[0];
    for (const b of boxes.slice(1)) box = makeBox(Math.min(box.x1, b.x1), Math.min(box.y1, b.y1), Math.min(box.z1, b.z1), Math.max(box.x2, b.x2), Math.max(box.y2, b.y2), Math.max(box.z2, b.z2));
    box = expandBox(box, navPad);
    box = makeBox(box.x1, Math.max(0, box.y1), box.z1, box.x2, Math.min(255, box.y2), box.z2);   // 主世界 1.16.1 高度 0..255
    if (boxSize(box) > maxNavCells) {
        return { ok: false, why: 'nav_box_too_big', box, cells: boxSize(box), maxNavCells, waypoints: [], notes: `导航盒 ${boxLabel(box)} 有 ${boxSize(box)} 格 > ${maxNavCells} ⇒ 调小 --nav-pad 或把 --entry 挪近` };
    }
    if (!boxContains(box, entry)) return { ok: false, why: 'entry_outside_nav_box', box, waypoints: [], notes: 'entry 不在导航盒内' };
    if (!boxContains(box, stand)) return { ok: false, why: 'stand_outside_nav_box', box, waypoints: [], notes: '站位不在导航盒内' };

    const walk = (c) => standOk(get, c[0], c[1], c[2]).ok;
    // r18 §5：循环不执行必须是独立返回分支 —— "起点不可走"和"走了没到"输出上不能长得一样
    if (!walk(entry)) return { ok: false, why: 'entry_not_walkable', box, waypoints: [], notes: `entry ${key3(entry)} 站不住（${standOk(get, entry[0], entry[1], entry[2]).why}）` };
    if (!walk(stand)) return { ok: false, why: 'stand_not_walkable', box, waypoints: [], notes: `站位 ${key3(stand)} 站不住（${standOk(get, stand[0], stand[1], stand[2]).why}）` };

    const goal = key3(stand);
    const prev = new Map([[key3(entry), null]]);
    const q = [entry];
    let head = 0, expanded = 0, found = false;
    while (head < q.length) {
        const cur = q[head++]; expanded++;
        if (expanded > maxNodes) return { ok: false, why: 'search_budget_exhausted', box, expanded, reachable: q.length, waypoints: [], notes: `BFS 展开 ${expanded} > ${maxNodes} ⇒ 报失败而不是给一条没走完的链` };
        const ck = key3(cur);
        if (ck === goal) { found = true; break; }
        for (const [dx, dz] of DIRS4) {
            const n = [cur[0] + dx, cur[1], cur[2] + dz];
            for (let dy = 1; dy >= -1; dy--) {                       // 顺序固定 ⇒ 结果可复现
                const m = [n[0], n[1] + dy, n[2]];
                const mk = key3(m);
                if (prev.has(mk) || !boxContains(box, m) || !walk(m)) continue;
                prev.set(mk, cur);
                q.push(m);
            }
        }
    }
    if (!found) {
        return {
            ok: false, why: 'no_safe_path', box, expanded, reachable: q.length,
            waypoints: [],
            notes: `从 entry 出发走得到 ${q.length} 个可走格，够不到站位（导航盒 ${boxLabel(box)}，全是 ${DEFAULTS.navPad} 外扩 + 逐格判可走；岩浆格永不可走）`,
        };
    }
    const path = [];
    for (let k = goal; k; k = key3(prev.get(k))) { path.push(k.split(',').map(Number)); if (prev.get(k) === null) break; }
    path.reverse();

    // 压缩成路点：贪心取"离上一个路点 ≤maxLeg 的最远一个"。子路径就是 BFS 路径本身 ⇒ 相邻路点之间**必然**有非危险的通路。
    const wps = [path[0]];
    let i = 0;
    while (i < path.length - 1) {
        let j = i + 1;
        while (j + 1 < path.length && cheb3(path[i], path[j + 1]) <= maxLeg) j++;
        wps.push(path[j]); i = j;
    }
    // 自检：压缩结果必须仍然满足"逐点可走 + 相邻 ≤maxLeg"，否则**报错**而不是发出去
    for (let k = 0; k < wps.length; k++) {
        if (!walk(wps[k])) return { ok: false, why: 'waypoint_not_walkable', box, waypoints: [], notes: `压缩出的路点 ${key3(wps[k])} 不可走（内部自检失败）` };
        if (k > 0 && cheb3(wps[k - 1], wps[k]) > maxLeg) return { ok: false, why: 'leg_too_long', box, waypoints: [], notes: `相邻路点 ${key3(wps[k - 1])}→${key3(wps[k])} 超过 ${maxLeg}（内部自检失败）` };
    }
    const nearHazard = scanBox(get, opt.getState ?? null, box).hazards.filter((h) => path.some((p) => cheb3(h.xyz, p) <= 1)).length;
    let maxUp = 0, maxDrop = 0;
    for (let k = 1; k < path.length; k++) { const d = path[k][1] - path[k - 1][1]; if (d > maxUp) maxUp = d; if (-d > maxDrop) maxDrop = -d; }
    return {
        ok: true, why: null, box, waypoints: wps, pathCells: path.length, path,
        notes: `BFS ${path.length} 格 / 展开 ${expanded} 展开格；压缩成 ${wps.length} 个路点（相邻 ≤${maxLeg}）；`
            + `单步最大上坡 ${maxUp}、最大下落 ${maxDrop}（4 连通模型里每步 y 只能是 -1/0/+1 ⇒ 不会摔死）；`
            + `路径 1 格内有 ${nearHazard} 个危险格（不经过，只并排）`,
    };
}

// ================================================================== 编排
/**
 * 顶层编排：给一个 oracle（`makeOracle` 的产物）+ 选项，出 SCHEMA §5 的一个 station 切片。
 * 几何不合法 ⇒ 返回 `{ok:false, why}` 且**不含任何坐标**（CLI 据此退出 3 且不写文件）。
 */
export function runSurvey(oracle, opt = {}) {
    const get = oracle.get, getState = oracle.getState ?? null;
    const o = { ...DEFAULTS, ...opt, getState };
    const hint = [o.frameX, o.frameY0, o.frameZ0];
    const box = o.box ?? boxFromHint(...hint);
    const scan = scanBox(get, getState, box);
    const geom = resolveFrame(get, box, { ...o, hint, getState });
    if (!geom.ok) {
        return {
            ok: false, why: geom.why, box, boxLabel: boxLabel(box), hint,
            geometry: { ok: false, why: geom.why, plane: null, detail: geom.detail, residual: geom.residual ?? null, cells: geom.cells ?? null },
            unreadable: { boxTotal: scan.unknown.length, box: scan.unknown.slice(0, 200), truncated: Math.max(0, scan.unknown.length - 200) },
        };
    }
    const warnings = [];
    if (scan.unknown.length) warnings.push(`扫描盒内有 ${scan.unknown.length} 格读不到（未加载区块或该 y 段无 section）：**没有当成空气**`);
    if (geom.residual.length) warnings.push(`框外紧贴但不在框里的黑曜石族 ${geom.residual.length} 格（低于 ${o.maxResidual} 阈值，容忍）：${geom.residual.map((r) => key3(r.xyz)).join(' ')}`);
    if (scan.unknown.length) warnings.push(`读到的格数只按"读到了的"计（cells=${Object.values(scan.counts).reduce((a, b) => a + b, 0)} / 盒内 ${scan.cells}）`);

    const digs = digCells(geom);
    const fills = patchOrder(get, geom, null);
    // 目标集 = needs_fill ∪ needs_dig（**不是**全部 14 格）：任务层只为这两类花站位。
    // 一个都没有时（框是全的）退化为"对框本身够得着"，否则站位排序会失去全部依据。
    const targets = [
        ...fills.map((f) => ({ what: f.what, xyz: f.xyz })),
        ...digs.map((d) => ({ what: d.what, xyz: d.xyz })),
    ];
    const reachTargets = targets.length ? targets : geom.ring.map((r) => ({ what: 'frame_cell', xyz: r.xyz }));
    if (!targets.length) warnings.push('环上没有缺格也没有待挖格：站位按"对整个框够得着"排序（L0 只是来点火的）');

    // 补格顺序要用**最终选定的站位**算 reach3 ⇒ 先选站位再排序
    const pre = deriveStands(get, geom, reachTargets, o);
    const stand = pre.stands[0]?.xyz ?? null;
    const fillsOrdered = patchOrder(get, geom, stand);
    const legs = [];
    if (!stand) {
        warnings.push(`⚠⚠ 没有任何合法站位（枚举 ${boxSize(pre.standBox)} 格，排除 ${pre.excludedTotal}）`);
        legs.push({ from: 'entry', to: o.stationId, dim: o.dim, ok: false, why: 'no_legal_stand', waypoints: [], notes: '没有合法站位 ⇒ 无法给路点（不给"最近的那个"凑数）' });
    } else {
        const leg = planLeg(get, o.entry, stand, { ...o, frameBox: geom.bbox });
        legs.push({ from: 'entry', to: o.stationId, dim: o.dim, ok: leg.ok, why: leg.why ?? null, waypoints: leg.waypoints ?? [], notes: leg.notes ?? '' });
        if (!leg.ok) warnings.push(`⚠⚠ entry→站位没有安全链：${leg.why}`);
    }
    if (!pre.stands.length) warnings.push(`站位枚举盒 ${boxLabel(pre.standBox)} 内 0 个合法站位（按 why 计数：${JSON.stringify(pre.reasons)}）`);
    if (stand && pre.stands[0].insideFrame) {
        warnings.push(`⚠⚠ 唯一排第一的作业位 ${key3(stand)} **在门框开口里**（框外一个可站的地方都没有）——补格时人会站在自己要点的门洞中，先人工看一眼`);
    }

    const standsOut = pre.stands.map((s) => ({ xyz: s.xyz, insideFrame: s.insideFrame, rise: s.rise, riseUp: s.riseUp, meanRise: s.meanRise, reachH: s.reachH, reach3: s.reach3, sumH: s.sumH, centroid3: s.centroid3, hazardsNear: s.hazardsNear }));
    // 通道 B 的危险源单独立一份：它来自**站位盒 + 半径**那个盒，与通道 A 的扫描盒**不是同一个盒**。
    // 两个通道口径不同是事实，必须写在输出里，否则下一个人会拿"通道 A 没这一格"去质疑通道 B（手册 §5：口径统一）。
    const nearBox = expandBox(pre.standBox, (o.hazardNearRadius + 1), (o.hazardNearRadius + 1));
    const nearStand = hazardsNearStands(scanBox(get, getState, nearBox).hazards, pre.stands, o.hazardNearRadius);

    const slice = {
        schema: 'aidqq-route/2',
        slice: true,
        note: '这是 `stations[1 个]` + `legs` 的**切片**，不是完整 route：sha256 / frozenAt / 其余站由父 agent 合并时补（SCHEMA.md §4 口径）。',
        mcVersion: '1.16.1',
        seed: null,
        stations: [{
            id: o.stationId, kind: 'ruined_portal', dim: o.dim,
            station: { center: [geom.bbox.x1 + 2, geom.bbox.z1], yHint: 'surface', radius: 24, lookFor: ['crying_obsidian', 'obsidian'] },
            exact: {
                stand: pre.stands.map((s) => s.xyz),
                standDetail: standsOut,
                standSortRule: STAND_SORT_RULE,
                standBox: pre.standBox,
                standExcluded: pre.excluded.slice(0, 24),
                standExcludedTotal: pre.excludedTotal,
                standExcludedReasons: pre.reasons,
                targets: [...fillsOrdered, ...digs],
                patchOrderRule: PATCH_SORT_RULE,
                hazards: hazardsInBox(scan),
                hazardsDetail: scan.hazards,
                hazardsNearStand: nearStand,
                hazardsNearStandRadius: o.hazardNearRadius,
                hazardsNearStandBox: nearBox,
                geometry: {
                    ok: true, plane: geom.plane, origin: geom.origin, box, frameW: 4, frameH: 5, ringCells: 14, interiorCells: 6,
                    counts: geom.counts, ring: geom.ring, interior: geom.interior, residualObsidian: geom.residual, candidates: geom.detail.candidates,
                },
                unreadable: {
                    boxTotal: scan.unknown.length, box: scan.unknown.slice(0, 200), truncated: Math.max(0, scan.unknown.length - 200),
                    standScanExcluded: pre.excludedTotal,
                },
                verify: {
                    status: 'OFFLINE',
                    evidence: `${o.world ?? '<world>'} + s1_exact_survey.mjs + 盒 ${boxLabel(box)}`,
                    method: 'region_reader.mjs 离线解析 .mca（未连客户端、未开服）',
                },
            },
        }],
        legs,
        warnings,
    };
    return { ok: true, why: null, slice, box, boxLabel: boxLabel(box), hint, geom, scan, stands: pre.stands, standsOut, leg: legs[0], warnings, reads: oracle.reads };
}

// ================================================================== 人读摘要
export function formatReport(r) {
    const L = [];
    const say = (s = '') => L.push(s);
    if (!r.ok) {
        say('════ S1 精确预勘 · **几何不合法 ⇒ 不产出任何坐标** ════');
        say(`世界/盒: ${r.boxLabel}   候选点数: ${(r.geometry?.detail?.candidates ?? []).length}（只列前 5）`);
        say(`❌ why = ${r.why}`);
        if (r.geometry?.detail?.candidates?.length) for (const c of r.geometry.detail.candidates) say(`   候选 ${JSON.stringify(c.origin)} 面=${c.orient}  ${JSON.stringify(c.score)}`);
        if (r.geometry?.cells) say(`   涉及格: ${r.geometry.cells.map(key3).join(' ')}`);
        if (r.geometry?.residual) say(`   框外紧贴的黑曜石族: ${r.geometry.residual.map((x) => `${key3(x.xyz)}=${x.block}`).join(' ')}`);
        if (r.unreadable) say(`   盒内读不到: ${r.unreadable.boxTotal} 格（**没有当成空气**）`);
        say('   ⇒ 框架认错 ⇒ 后面所有坐标都只是"错框的正确答案"。退出码 3，**不写 out 文件**。');
        return L.join('\n');
    }
    const g = r.geom, s = r.slice.stations[0].exact;
    say('════ S1 精确预勘（离线存档解析，未连客户端、未开服）════');
    say(`扫描盒: ${r.boxLabel}   提示点: ${JSON.stringify(r.hint)}   读到方块格数: ${r.reads}`);
    say(`门框: 面=${g.plane} 原点=${JSON.stringify(g.origin)} 外框 4×5 / 环 14 格 / 内 2×3`);
    say(`环分类: obsidian=${g.counts.obsidian} crying_obsidian=${g.counts.crying_obsidian} needs_dig=${g.counts.needs_dig} needs_fill=${g.counts.needs_fill} other=${g.counts.other} 读不到=${g.counts.unreadable}`);
    say(`框外紧贴的黑曜石族: ${g.residual.length} 格${g.residual.length ? '（' + g.residual.map((x) => key3(x.xyz) + '=' + x.block).join(' ') + '）' : ''}`);
    say('\n--- 环 14 格 ---');
    for (const c of g.ring.slice().sort((a, b) => a.xyz[1] - b.xyz[1] || a.xyz[0] - b.xyz[0] || a.xyz[2] - b.xyz[2])) {
        say(`  ${key3(c.xyz).padEnd(12)} ${c.cls.padEnd(16)} ${String(c.block ?? 'unknown').padEnd(16)}${c.tool ? ' tool=' + c.tool : ''}`);
    }
    say('--- 内 6 格 ---');
    for (const c of g.interior) say(`  ${key3(c.xyz).padEnd(12)} ${String(c.kind).padEnd(16)} ${String(c.block ?? 'unknown')}`);
    say(`\n站位排序规则: ${STAND_SORT_RULE}`);
    say(`  （主键是 3-D 上升量 —— r18 §1.3：只按水平距离排会把"水平 0 格、垂直 6 格"的门框顶排成第一）`);
    say(`站位枚举盒 ${boxLabel(s.standBox)}：合法 ${r.stands.length} / 排除 ${s.standExcludedTotal}  排除原因计数 ${JSON.stringify(s.standExcludedReasons)}`);
    for (const d of r.standsOut.slice(0, 12)) {
        say(`  #${r.standsOut.indexOf(d) + 1} ${key3(d.xyz).padEnd(12)} ${d.insideFrame ? '门洞内' : '框外  '} rise=${d.rise}(上${d.riseUp}) mean=${d.meanRise} reachH=${d.reachH} reach3=${d.reach3} 2格内危险=${d.hazardsNear} 质心=${d.centroid3}`);
    }
    if (!r.stands.length) say('  ⚠⚠ 0 个合法站位');
    say(`\n待挖格（needs_dig）: ${s.targets.filter((t) => t.what === 'dig').length}`);
    for (const t of s.targets.filter((t) => t.what === 'dig')) say(`  ${key3(t.xyz).padEnd(12)} ${t.block}  tool=${t.tool}`);
    say(`补格顺序规则: ${PATCH_SORT_RULE}`);
    say(`待补格（needs_fill）: ${s.targets.filter((t) => t.what === 'fill_cell').length}`);
    for (const t of s.targets.filter((t) => t.what === 'fill_cell')) say(`  #${t.order} ${key3(t.xyz).padEnd(12)} riskAdjacent=${t.riskAdjacent} openFaces=${t.openFaces} reach3=${t.reach3} how=${t.how}`);
    say(`\n【通道 A · 导航护栏用】盒内全部危险格 ${s.hazards.length} 个${s.hazards.length ? '：' + s.hazards.map(key3).join(' ') : ''}`);
    say(`【通道 B · 我站这儿会不会死】站位 2 格内（半径 ${s.hazardsNearStandRadius}）:`);
    if (!s.hazardsNearStand.length) say('  （没有合法站位，无从判起）');
    for (const h of s.hazardsNearStand.slice(0, 12)) say(`  ${key3(h.stand).padEnd(12)} n=${h.n} ${h.near.map(key3).join(' ')}`);
    say('  ⚠ 两个通道**不可合并**（r18 §1.1：把"站位安不安全""施工安不安全""邻域有没有岩浆"混成一个判据，20 个干净站位会被逐个拒掉）');
    const leg = r.leg;
    say(`\n--- legs ---`);
    say(`${leg.from} → ${leg.to}  ok=${leg.ok}${leg.why ? '  why=' + leg.why : ''}`);
    if (leg.ok) for (const w of leg.waypoints) say(`  wp ${key3(w)}`);
    say(`  ${leg.notes}`);
    say(`\nunreadable（读不到，**没当空气**）: 盒内 ${s.unreadable.boxTotal} 格${s.unreadable.boxTotal ? '：' + s.unreadable.box.slice(0, 20).map(key3).join(' ') + (s.unreadable.truncated ? ` …(+${s.unreadable.truncated})` : '') : ''}`);
    say(`verify: ${s.verify.status} / ${s.verify.evidence}`);
    if (r.warnings.length) { say('\n⚠ 警告:'); for (const w of r.warnings) say(`  - ${w}`); }
    return L.join('\n');
}

// ================================================================== CLI
function argOf(argv, name, dflt) {
    const i = argv.indexOf(`--${name}`);
    return (i >= 0 && argv[i + 1] !== undefined && !argv[i + 1].startsWith('--')) ? argv[i + 1] : dflt;
}
function numArg(argv, name, dflt) {
    const v = argOf(argv, name, null);
    if (v === null) return dflt;
    const n = Number(v);
    if (!Number.isFinite(n)) throw new Error(`--${name} 需要数字，收到 "${v}"`);
    return n;
}
function xyzArg(argv, name, dflt) {
    const v = argOf(argv, name, null);
    if (v === null) return dflt;
    const a = v.split(',').map((s) => Number(s.trim()));
    if (a.length !== 3 || a.some((n) => !Number.isFinite(n))) throw new Error(`--${name} 需要 x,y,z 三个整数，收到 "${v}"`);
    return a;
}
function boxArg(argv) {
    const v = argOf(argv, 'box', null);
    if (!v) return null;
    const a = v.split(',').map((s) => Number(s.trim()));
    if (a.length !== 6 || a.some((n) => !Number.isFinite(n))) throw new Error(`--box 需要 x1,y1,z1,x2,y2,z2，收到 "${v}"`);
    return makeBox(a[0], a[1], a[2], a[3], a[4], a[5]);
}

export function parseArgs(argv) {
    return {
        world: argOf(argv, 'world', null),
        out: argOf(argv, 'out', null),
        frameX: numArg(argv, 'frame-x', DEFAULTS.frameX),
        frameY0: numArg(argv, 'frame-y0', DEFAULTS.frameY0),
        frameZ0: numArg(argv, 'frame-z0', DEFAULTS.frameZ0),
        box: boxArg(argv),
        entry: xyzArg(argv, 'entry', [...DEFAULTS.entry]),
        maxLeg: numArg(argv, 'max-leg', DEFAULTS.maxLeg),
        maxHoriz: numArg(argv, 'max-horiz', DEFAULTS.maxHoriz),
        maxRise: numArg(argv, 'max-rise', DEFAULTS.maxRise),
        standPad: numArg(argv, 'stand-pad', DEFAULTS.standPad),
        standYPad: numArg(argv, 'stand-ypad', DEFAULTS.standYPad),
        minFrame: numArg(argv, 'min-frame', DEFAULTS.minFrame),
        maxResidual: numArg(argv, 'max-residual', DEFAULTS.maxResidual),
        navPad: numArg(argv, 'nav-pad', DEFAULTS.navPad),
        stationId: argOf(argv, 'station-id', DEFAULTS.stationId),
    };
}

export const USAGE = `用法:
  node s1_exact_survey.mjs --world <worldDir> --out <jsonPath>
        [--frame-x 187] [--frame-y0 39] [--frame-z0 307] [--box x1,y1,z1,x2,y2,z2]
        [--entry 206,64,242] [--max-leg 32] [--max-horiz 4] [--max-rise 2]
        [--stand-pad 3] [--stand-ypad 3] [--min-frame 4] [--max-residual 2] [--nav-pad 4]
        [--station-id S1_portal]
退出码: 0 成功 / 1 内部错误 / 2 用法错 / 3 几何不是合法 4×5 环（**不写 out**）`;

export function cli(argv) {
    let opt;
    try { opt = parseArgs(argv); } catch (e) { console.error(`❌ 参数错: ${e.message}\n${USAGE}`); return EXIT.USAGE; }
    if (!opt.world || !opt.out) { console.error(`❌ 必填: --world <worldDir> --out <jsonPath>\n${USAGE}`); return EXIT.USAGE; }
    if (!fs.existsSync(opt.world)) { console.error(`❌ 世界目录不存在: ${opt.world}`); return EXIT.USAGE; }
    const outAbs = path.resolve(opt.out);
    try {
        const world = openWorld(opt.world, { dims: ['overworld'] });
        const oracle = makeOracle(
            (x, y, z) => world.blockAt(x, y, z, 'overworld'),
            (x, y, z) => world.blockState(x, y, z, 'overworld'),
        );
        const r = runSurvey(oracle, { ...opt, world: opt.world, dim: 'overworld' });
        console.log(formatReport(r));
        if (!r.ok) {
            if (fs.existsSync(outAbs)) console.error(`⚠ 已有旧文件在 ${outAbs}（本次**没有**覆盖它 —— 别拿旧文件当本次结果）`);
            console.error(`\n❌ 几何不合法（${r.why}）⇒ 不产出坐标。退出码 ${EXIT.GEOMETRY_REJECTED}`);
            return EXIT.GEOMETRY_REJECTED;
        }
        // 写入：2 空格缩进 + 末尾换行，**与 SCHEMA §4 的哈希口径一致**（父 agent 冻结时可直接算）
        fs.mkdirSync(path.dirname(outAbs), { recursive: true });
        fs.writeFileSync(outAbs, JSON.stringify(r.slice, null, 2) + '\n', 'utf8');
        // ★ 写完必须自己核一遍落盘（手册 §5：动作要证据紧贴它要证明的时刻）
        if (!fs.existsSync(outAbs)) { console.error(`❌ 写完却找不到 ${outAbs}`); return EXIT.ERROR; }
        const st = fs.statSync(outAbs);
        const back = JSON.parse(fs.readFileSync(outAbs, 'utf8'));
        if (!st.size || !back.stations?.[0]?.exact) { console.error(`❌ 落盘文件不可用（size=${st.size}）`); return EXIT.ERROR; }
        console.log(`\n✔ 已写出 ${outAbs}（${st.size} 字节，回读校验通过）`);
        return EXIT.OK;
    } catch (e) {
        console.error(`❌ 内部错误: ${e?.stack ?? e}`);
        return EXIT.ERROR;
    }
}

const SELF = fileURLToPath(import.meta.url);
if (process.argv[1] && path.resolve(process.argv[1]).toLowerCase() === SELF.toLowerCase()) {
    // 用 exitCode 而不是 process.exit()：Windows 上 stdout 走管道时 process.exit 会截断输出
    process.exitCode = cli(process.argv.slice(2));
}
