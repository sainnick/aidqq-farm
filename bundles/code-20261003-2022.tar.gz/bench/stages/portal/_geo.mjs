﻿// 临时：dump 主种子存档门框一带几何（用完删）
import { openWorld } from '../../route/tools/region_reader.mjs';
const W = 'D:/AI斗蛐蛐/bench/route/probe/_bedhunt';
const w = openWorld(W, { dims: ['overworld'] });
const [X0, X1, Y0, Y1, Z0, Z1] = [183, 192, 36, 46, 303, 313];
function s(n) {
  if (n == null) return '?';
  if (n === 'air' || n === 'cave_air' || n === 'void_air') return '.';
  if (n === 'lava' || n === 'flowing_lava') return 'L';
  if (n === 'water' || n === 'flowing_water') return 'W';
  if (n === 'magma_block') return 'M';
  if (n === 'obsidian') return 'O';
  if (n === 'crying_obsidian') return 'C';
  if (n === 'netherrack') return 'n';
  if (n === 'bedrock') return 'B';
  if (n === 'stone') return 's';
  if (n === 'dirt' || n === 'coarse_dirt' || n === 'podzol') return 'd';
  if (n === 'grass_block') return 'g';
  if (n === 'sand' || n === 'sandstone' || n === 'gravel') return 'v';
  return '?';
}
console.log('x:  ' + Array.from({ length: X1 - X0 + 1 }, (_, i) => (X0 + i) % 10).join(''));
for (let y = Y1; y >= Y0; y--) {
  const rows = [];
  for (let z = Z0; z <= Z1; z++) {
    let row = '';
    for (let x = X0; x <= X1; x++) row += s(w.blockAt(x, y, z));
    rows.push(String(z).padStart(4) + ' ' + row);
  }
  console.log('y=' + String(y).padStart(3) + ' |' + rows.join('\n      |'));
}
