// micro_bot.mjs — MC-M1-TASK-08 新原语微基准机器人（倒水 / 捞岩浆 / 浇一格黑曜石）
//
// 被测原语（全部来自 worktree 的新文件，MC_MINDCRAFT_ROOT 指向它）：
//   scoop  捞岩浆        liquid.js scoopLiquidAt
//   pour   倒水          liquid.js placeLiquidAt
//   cast   浇一格黑曜石   liquid.js castObsidianAt
//
// ★ 架构决定（来自 P8_PROBE2 的实测教训，不是偏好）：
//   本 bot **不发任何游戏内聊天**。所有控制台命令（tp/fill/setblock/give/clear/数据查询）
//   都经 srv_rpc.mjs 的文件队列交给编排器，再由编排器灌进 server.stdin。
//   原因：P8_PROBE2 里 3 个 fill 落了日志，紧随其后的 3 个 setblock、2 个 data get、
//   1 个 execute **一条日志都没有**——短时间连发的聊天命令被服务端静默丢弃；而且
//   /setblock 成功时服务端不打日志，于是「命令丢了」和「命令成了」在日志上完全无法区分。
//   手册 §2 本就要求「一律用服务器 stdin 控制台发命令」。走 stdin 之后没有节流、没有
//   1.16.1 聊天签名问题、且 fill 的成功日志可查。
//
// 场景由**编排器**在 bot 起来之前摆好并通过服务端真值闸门（4/4 才开测）；
// bot 只负责：等场景就绪 → 探针 → 逐项批量 → 逐项结果落盘。
//
// 每次测量的成功判据（client 侧 bot.blockAt，只吃 Vec3）：
//   scoop → 该格不再是岩浆源 且 手上是 lava_bucket
//   pour  → 该格是水源（level 8）
//   cast  → 该格是 obsidian

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import { makeRpc } from './srv_rpc.mjs';
import { SCENE, sceneChecks } from './scene.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}
const hasFlag = (name) => process.argv.includes(`--${name}`);

const OUT_DIR = arg('out', BENCH_DIR);
const PORT = parseInt(arg('port', '25567'), 10);
const USERNAME = arg('username', 'TaskBotB');
const MC_VERSION = arg('mc-version', '1.16.1');
const N = parseInt(arg('n', '30'), 10);
const SEED = arg('seed', 'unknown');
const RPC_DIR = arg('rpc', path.join(OUT_DIR, 'rpc'));
const SETUP = path.join(OUT_DIR, 'setup.json');
const ROWS = path.join(OUT_DIR, 'micro_results.jsonl');
const DONE = path.join(OUT_DIR, 'done.json');
const LOG = path.join(OUT_DIR, 'bot.log');

fs.mkdirSync(OUT_DIR, { recursive: true });
const logLine = (m) => { const l = `[${new Date().toISOString()}] ${m}`; console.log(l); try { fs.appendFileSync(LOG, l + '\n'); } catch { /* 忽略 */ } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 场景坐标统一取自 scene.mjs（与编排器共用同一份真源——P8_MICRO3 栽在两份坐标不一致上）
const SC = SCENE;
const LAVA_CELLS = SC.lavaCells;

let seq = 0;
let msgQueue = [];
let bot = null;
let rpc = null;
let sceneOk = false;
const resultRows = [];

function writeRow(r) {
    resultRows.push(r);
    try { fs.appendFileSync(ROWS, JSON.stringify(r) + '\n'); } catch { /* 忽略 */ }
}

/** 发一条服务端控制台命令（经 RPC → server.stdin），不返回回包 */
async function srv(cmd, timeoutMs = 60000) {
    const id = rpc.nextId('b');
    return rpc.call(rpc, id, cmd, { timeoutMs, logFn: logLine });
}

async function waitForSetup() {
    const t0 = Date.now();
    while (!fs.existsSync(SETUP) && Date.now() - t0 < 180000) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('编排器未写 setup.json（场景没就绪）');
    try {
        const j = JSON.parse(fs.readFileSync(SETUP, 'utf8'));
        sceneOk = !!j.sceneOk;
    } catch { sceneOk = false; }
    logLine(`setup.json 到达，sceneOk=${sceneOk}`);
}

async function connect() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    for (let a = 1; a <= 4; a++) {
        try {
            const b = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
            b.loadPlugin(pf.pathfinder);
            b.loadPlugin(require('mineflayer-tool').plugin);
            await new Promise((res, rej) => {
                b.once('spawn', res);
                b.once('error', rej);
                setTimeout(() => rej(new Error('spawn timeout 60s')), 60000);
            });
            return b;
        } catch (e) {
            logLine(`connect 失败（${a}/4）: ${String(e).slice(0, 120)}`);
            await sleep(8000);
            if (a === 4) throw e;
        }
    }
    throw new Error('connect 失败');
}

/** 传送到指定站位（走服务端 stdin，不走聊天） */
async function tpTo(x, y, z) {
    await srv(`tp ${USERNAME} ${x} ${y} ${z}`, 30000);
    for (let i = 0; i < 30; i++) {
        await sleep(200);
        const p = bot?.entity?.position;
        if (p && Math.abs(p.x - x) < 0.7 && Math.abs(p.z - z) < 0.7 && Math.abs(p.y - y) < 1.5) return true;
    }
    return false;
}

/** 等到背包里真的有空桶（give 的服务端回包先到、客户端 inventory 更新后到） */
async function waitBucket(maxMs = 6000) {
    const t0 = Date.now();
    while (Date.now() - t0 < maxMs) {
        const items = bot?.inventory?.items?.() ?? [];
        if (items.some((i) => i.name === 'bucket')) {
            // 再等一小会儿，确保 clear 的效果也同步了
            await sleep(150);
            return true;
        }
        await sleep(150);
    }
    return false;
}

async function main() {
    logLine(`micro_bot: port=${PORT} n=${N} seed=${SEED} root=${MINDCRAFT} rpc=${RPC_DIR}`);
    rpc = makeRpc(RPC_DIR);
    bot = await connect();
    bot.on('message', (m) => { const s = String(m); if (s.includes('@@')) msgQueue.push(s); });

    await sleep(3500);
    await waitForSetup();

    // 场景真值没过就不开测（06c 教训：量到「地形还没摆好」的假数字）
    if (!sceneOk) {
        logLine('⚠ 场景真值未通过，跳过测量（避免产出假数字）');
        writeRow({ op: 'scene', ok: false, sceneBad: true, n: 1, ms: 0 });
        fs.writeFileSync(DONE, JSON.stringify({ sceneBad: true }, null, 2));
        setTimeout(() => { try { bot.quit(); } catch { /* 忽略 */ } process.exit(3); }, 800);
        return;
    }

    // 站到平台上（tp 走 stdin）
    const at = await tpTo(SC.stand.x, SC.stand.y, SC.stand.z);
    const bp = bot.entity.position;
    logLine(`站位 bot=[${bp.x.toFixed(1)},${bp.y.toFixed(1)},${bp.z.toFixed(1)}] 期望=[${SC.stand.x},${SC.stand.y},${SC.stand.z}] ok=${at}`);

    const liq = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/liquid.js')).href);

    // ★★ 探针：源块的字段结构（定 liquidSourceInfo 的判据地基）★★
    // 流动块的对照**离线**做更可靠（bench/stages/portal/verify_load.mjs 用本仓装的 1.16.1 数据
    // 直接造出 level=3 的岩浆块）——实测里 setblock 造出来的 lava 本身就是源块，
    // 现场造不出稳定的「流动块」样本（P8_MICRO3 的教训）。
    const { Vec3 } = require('vec3');
    const dump = (p) => {
        const b = bot.blockAt(new Vec3(p.x, p.y, p.z));
        if (!b) return null;
        return {
            pos: [p.x, p.y, p.z], name: b.name, type: b.type, stateId: b.stateId,
            metadata: b.metadata, hasStates: 'states' in b, states: b.states ?? null,
            computedStates: b.computedStates ?? null,
            getProperties: typeof b.getProperties === 'function' ? b.getProperties() : '(none)',
        };
    };
    const lavaCell = LAVA_CELLS[0];
    const srcRaw = dump(lavaCell);
    const srcInfo = liq.liquidSourceInfo(bot, lavaCell);
    const wRaw = dump(SC.waterCell);
    const wInfo = liq.liquidSourceInfo(bot, SC.waterCell);
    const castRaw = dump(SC.castCell);
    const castInfo = liq.liquidSourceInfo(bot, SC.castCell);
    logLine(`PROBE 岩浆源 raw=${JSON.stringify(srcRaw)}`);
    logLine(`PROBE 岩浆源 liquid.js=${JSON.stringify({ level: srcInfo?.level, isSource: srcInfo?.isSource })}`);
    logLine(`PROBE 水源   raw=${JSON.stringify(wRaw)}`);
    logLine(`PROBE 水源   liquid.js=${JSON.stringify({ level: wInfo?.level, isSource: wInfo?.isSource })}`);
    logLine(`PROBE 浇筑格 liquid.js=${JSON.stringify({ level: castInfo?.level, isSource: castInfo?.isSource })}`);
    writeRow({
        op: 'probe', ok: !!srcInfo, n: 1, ms: 0,
        lava: srcRaw, water: wRaw, castCell: castRaw,
        liquidLava: srcInfo, liquidWater: wInfo, liquidCast: castInfo,
    });
    if (hasFlag('--probe-only')) {
        fs.writeFileSync(DONE, JSON.stringify({ probeOnly: true }, null, 2));
        logLine('probe-only 结束');
        setTimeout(() => { try { bot.quit(); } catch { /* 忽略 */ } process.exit(0); }, 800);
        return;
    }

    // —— 三个原语各 N 次 ——
    // 每轮用 RPC 重置：给桶、清掉满桶、把目标格复位。全部走 stdin，零聊天。
    for (const op of ['scoop', 'pour', 'cast']) {
        for (let i = 0; i < N; i++) {
            // 复位：★ 先把整个背包清空，再给 4 只空桶。
            //   只 clear 满桶是不够的：每轮 give 4 只、30 轮下来 36 格全被桶塞满，
            //   而 1.16 的 `BucketItem.use` 舀到液体后是 `if (!inventory.add(满桶)) drop(满桶)`
            //   —— **背包满就把满桶丢在地上**：水消失、桶没有 → 原语判 scoop_fail。
            //   实测证据 P8_MICRO30（n=10 全过、n=30 cast 0/30，peek 里 waterCell=air、
            //   背包 35 摞桶）vs P8_DIAG4（reset 先 clear 整个背包 → 3/3 全过）。
            await srv(`clear ${USERNAME}`);
            await srv(`give ${USERNAME} minecraft:bucket 4`);
            // ★ 等背包同步：give 的回包先到，客户端 inventory 更新后到。
            //   P8_MICRO2 不等 → 相邻两次迭代就报 hold_fail（桶明明给了，bot 手上还没）。
            if (!await waitBucket(6000)) {
                writeRow({ op, i, ok: false, ms: 0, why: 'bucket_sync_timeout' });
                continue;
            }

            let t0 = Date.now(), r = null, target = null, setupNote = null;
            const one = (c, blk) => `fill ${c.x} ${c.y} ${c.z} ${c.x} ${c.y} ${c.z} minecraft:${blk}`;
            // ★ 每轮先清平台层（scene.sweep）：源块在 1.16 水平能铺 7 格，
            //   上一轮倒出来的水/岩浆会漫过整层平台污染后面的几何（n=3 全过、n=30 全灭）。
            await srv(`fill ${SC.sweep.x0} ${SC.sweep.y0} ${SC.sweep.z0} ${SC.sweep.x1} ${SC.sweep.y1} ${SC.sweep.z1} minecraft:air`);
            try {
                if (op === 'scoop') {
                    // 三个岩浆源轮着用（每次舀掉一个，复位后换下一个）
                    target = { ...LAVA_CELLS[i % LAVA_CELLS.length] };
                    await srv(one(target, 'lava'));          // 复位岩浆源（上一轮舀走了）
                    await sleep(400);
                    await tpTo(SC.standLava.x, SC.standLava.y, SC.standLava.z);
                    r = await liq.scoopLiquidAt(bot, target, { telemetry: null, label: 'micro_scoop' });
                } else if (op === 'pour') {
                    // 先舀水，再倒进空格子
                    await srv(one(SC.waterCell, 'water'));     // 复位水源
                    await srv(one(SC.pourCell, 'air'));       // 复位倒水目标格
                    await sleep(400);
                    await tpTo(SC.standWater.x, SC.standWater.y, SC.standWater.z);
                    const s = await liq.scoopLiquidAt(bot, SC.waterCell, { telemetry: null, label: 'micro_pour_fill' });
                    if (!s.ok) { setupNote = `fill_scoop_fail:${s.reason}`; r = { ok: false, reason: setupNote }; }
                    else {
                        await tpTo(SC.standPour.x, SC.standPour.y, SC.standPour.z);
                        r = await liq.placeLiquidAt(bot, SC.pourCell, 'water', { telemetry: null, label: 'micro_pour' });
                    }
                } else {
                    // 浇筑：目标格放岩浆源，再舀一桶水浇上去 → 黑曜石
                    target = { ...SC.castCell };
                    const above = { x: target.x, y: target.y + 1, z: target.z };
                    // ★ 复位要连**正上方那格**一起清：上一轮倒上去的水会往下流，
                    //   把岩浆冲成圆石（P8_MICRO10 第 2/3 次就是这么挂的）。
                    await srv(one(above, 'air'));
                    await srv(one(SC.waterCell, 'water'));
                    await srv(one(target, 'lava'));           // 复位浇筑格为岩浆源
                    await sleep(400);
                    await tpTo(SC.standWater.x, SC.standWater.y, SC.standWater.z);
                    const s = await liq.scoopLiquidAt(bot, SC.waterCell, { telemetry: null, label: 'micro_cast_fill' });
                    if (!s.ok) { r = { ok: false, reason: `fill_scoop_fail:${s.reason}` }; }
                    else {
                        await tpTo(SC.standCast.x, SC.standCast.y, SC.standCast.z);
                        r = await liq.castObsidianAt(bot, target, { telemetry: null, label: 'micro_cast' });
                    }
                }
            } catch (e) {
                r = { ok: false, reason: 'threw', err: String(e).slice(0, 160) };
            }
            const ms = Date.now() - t0;
            // 现场取证：失败时把关键格与服务端无关的客户端视图一起落盘（手册 §5 禁止无证据归因）
            const peek = () => {
                const cells = {
                    waterCell: SC.waterCell, castCell: SC.castCell, pourCell: SC.pourCell,
                    castAbove: { x: SC.castCell.x, y: SC.castCell.y + 1, z: SC.castCell.z },
                    standWater: { x: Math.floor(SC.standWater.x), y: SC.standWater.y, z: Math.floor(SC.standWater.z) },
                };
                const out = {};
                for (const [k, c] of Object.entries(cells)) {
                    const b = bot.blockAt(new (require('vec3'))(c.x, c.y, c.z));
                    out[k] = b ? b.name : null;
                }
                out.bot = [+bot.entity.position.x.toFixed(1), +bot.entity.position.y.toFixed(1), +bot.entity.position.z.toFixed(1)];
                out.inv = bot.inventory.items().map((i2) => `${i2.name}x${i2.count}`).join(',');
                return out;
            };
            writeRow({ op, i, ok: !!r?.ok, ms, why: r?.reason ?? r?.why ?? null, detail: r?.detail ?? null, peek: peek() });
            if (i % 5 === 0) logLine(`${op} 进度 ${i}/${N}`);
            await sleep(120);
        }
    }

    const byOp = {};
    for (const r of resultRows) {
        if (r.op === 'probe' || r.op === 'scene') continue;
        byOp[r.op] = byOp[r.op] ?? { n: 0, ok: 0 };
        byOp[r.op].n++; if (r.ok) byOp[r.op].ok++;
    }
    fs.writeFileSync(DONE, JSON.stringify({ total: resultRows.length, byOp }, null, 2));
    logLine(`micro_bot done: ${JSON.stringify(byOp)}`);
    setTimeout(() => { try { bot.quit(); } catch { /* 忽略 */ } process.exit(0); }, 800);
}

main().catch((e) => {
    logLine(`fatal: ${String(e && e.stack ? e.stack : e).slice(0, 800)}`);
    try { fs.writeFileSync(DONE, JSON.stringify({ fatal: String(e).slice(0, 300) }, null, 2)); } catch { /* 忽略 */ }
    process.exit(1);
});
