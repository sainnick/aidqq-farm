// 临时：unpackMode 对拍（用完删）
import { openWorld } from '../../route/tools/region_reader.mjs';
const A = 'D:/AI斗蛐蛐/bench/route/probe/_bedhunt';
const B = 'D:/AI斗蛐蛐/bench/route/probe/_s1_main_fresh/4926685115947721762';
const probes = [
    [187, 42, 310], [187, 43, 308], [187, 39, 307], [187, 40, 309], [186, 40, 309],
    [174, 30, 293], [174, 29, 293], [187, 39, 309], [190, 40, 309], [190, 36, 303],
    [187, 41, 307], [187, 40, 307], [187, 41, 310], [187, 40, 310], [184, 40, 310], [189, 40, 306],
];
for (const mode of [undefined, 'packed', 'linear']) {
    console.log(`\n===== unpackMode=${mode ?? '(默认)'} =====`);
    const wa = openWorld(A, mode ? { dims: ['overworld'], unpackMode: mode } : { dims: ['overworld'] });
    const wb = openWorld(B, mode ? { dims: ['overworld'], unpackMode: mode } : { dims: ['overworld'] });
    for (const [x, y, z] of probes) {
        console.log(`${x},${y},${z}`.padEnd(16), 'bedhunt=' + String(wa.blockAt(x, y, z)).padEnd(20), 'fresh=' + String(wb.blockAt(x, y, z)));
    }
    // 扫一遍门框区统计名字
    const names = new Map();
    for (let y = 36; y <= 46; y++) for (let z = 303; z <= 313; z++) for (let x = 183; x <= 192; x++) {
        const n = wb.blockAt(x, y, z);
        if (!n || n === 'air' || n === 'cave_air' || n === 'void_air') continue;
        names.set(n, (names.get(n) ?? 0) + 1);
    }
    console.log('  fresh 门框区名字统计: ' + [...names.entries()].sort((a, b) => b[1] - a[1]).map(([n, c]) => `${n}:${c}`).join(' '));
}
