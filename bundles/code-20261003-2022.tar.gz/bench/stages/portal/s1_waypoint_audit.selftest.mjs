// s1_waypoint_audit.selftest.mjs — 判据的**离线自检**（假 world oracle 驱动同一套判据，不碰 .mca、不开服）
//
// 【为什么必须自己造】本工具的错误全是**静默**的：把读不到的格当空气、危险格被空气检查掩盖、
//   邻接只查脚下 —— 任何一条都不抛异常，只会安静输出一份"看起来很像对的"合格清单。
//   真存档只有一个种子几个坐标，穷举不出这些组合；假 oracle 能。
//   （world reader 那条线的教训：漏了 sec.Y 偏移，整块 chunk 读成同一个方块，自检却全绿。）
//
// 覆盖：
//   T1 正例：全部通过 ⇒ OK，reasons 空
//   T2 身体格是 lava ⇒ FAIL 且 reason=body_hazard（**不能**被"不是空气族"顶替）
//   T3 脚下是 magma_block ⇒ FAIL 且 reason=foot_is_hazard
//   T4 旁边 1 格 lava（脚下实心）⇒ FAIL 且 reason=**只有** adjacent_hazard
//   T5 readBlock 返 null ⇒ unreadable（**不是** OK，也**不是** body_not_air）
//   T5b 真实 region_reader 的 'unknown' 字符串 ⇒ 同样收成 unreadable（真存档就是这么返的）
//   T6 stand 三条判据的同族用例（正例 / 身体危险 / 脚下不实心 / 邻接危险）
//   T7 头格被占 ⇒ 仍是 OK、headBlocked=true、reasons 空（软/硬必须分开）
//   T8 优先级：读不到 + 邻接危险 ⇒ FAIL（硬判据优先），但 reasons 里仍要留 unreadable 痕迹
//
// 用法：cd D:\AI斗蛐蛐\bench\stages\portal
//   & 'D:\AI斗蛐蛐\.runtime\node-v20.20.2-win-x64\node.exe' s1_waypoint_audit.selftest.mjs
// 全部通过 ⇒ 打印 `PASS n` / `FAIL 0` 且 exit 0；否则 exit 1。

import path from 'path';
import { fileURLToPath } from 'url';
import {
    normalizeName, makeOracle, auditCell, auditCells, summarize, parseArgs, DEFAULTS, EXIT, REASON,
} from './s1_waypoint_audit.mjs';

let pass = 0, fail = 0;
const j = (v) => JSON.stringify(v);
const A = (n, c, x = '') => { if (c) { pass++; console.log(`  ✔ ${n}`); } else { fail++; console.log(`  ✘ ${n}${x ? ` — ${x}` : ''}`); } };
const eq = (n, got, want) => A(n, j(got) === j(want), `got=${j(got)} want=${j(want)}`);
const ok = (n, c, x = '') => A(n, !!c, x);
const K = (c) => `${c[0]},${c[1]},${c[2]}`;

// ---------------------------------------------------------------- 假 world oracle
/**
 * 造 oracle。`cells` 是 Map："x,y,z" → 方块名 或 null（**读不到**）；未列出的格一律 air。
 * ⚠ 与真 region_reader 同形：真存档读不到时返回 `'unknown'` 字符串，T5b 单独钉那个口径。
 */
function worldFrom(cells) {
    const raw = (x, y, z) => (cells.has(K([x, y, z])) ? cells.get(K([x, y, z])) : 'air');
    return makeOracle((x, y, z) => raw(x, y, z));
}
/** 一格默认世界：y-1 实心 stone，上下左右空，身体 air。 */
function flat(map) {
    const m = new Map(map ?? []);
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) m.set(`${10 + dx},9,20${'' + dz}`, 'stone');
    m.set('10,9,20', 'stone');
    return worldFrom(m);
}
const P = [10, 10, 20];          // 被审的 body cell
const codes = (r) => r.reasons;

console.log('s1_waypoint_audit.selftest — 判据离线自检\n');

// ---------------------------------------------------------------- T0 归一
console.log('T0 归一：读不到只有一个表示');
eq("normalizeName('unknown') → null", normalizeName('unknown'), null);
eq("normalizeName(null) → null", normalizeName(null), null);
eq("normalizeName(undefined) → null", normalizeName(undefined), null);
eq("normalizeName('') → null", normalizeName(''), null);
eq("normalizeName('minecraft:obsidian') → 'obsidian'", normalizeName('minecraft:obsidian'), 'obsidian');
eq("normalizeName({name:'lava'}) → 'lava'", normalizeName({ name: 'lava' }), 'lava');

// ---------------------------------------------------------------- T1 正例
console.log('\nT1 正例：站得住 + 6 邻无危险 ⇒ OK');
{
    const r = auditCell(flat(), P);
    eq('verdict=OK', r.verdict, 'OK');
    eq('reasons 空', codes(r), []);
    eq('hazardCount=0', r.hazardCount, 0);
    eq('body/foot/head', [r.body, r.foot, r.head], ['air', 'stone', 'air']);
    ok('headBlocked=false', r.headBlocked === false);
}

// ---------------------------------------------------------------- T2 身体格是 lava
console.log('\nT2 身体格本身是 lava ⇒ FAIL body_hazard（硬线：危险优先于一切）');
{
    const r = auditCell(worldFrom(new Map([['10,10,20', 'lava'], ['10,9,20', 'stone']])), P);
    eq('verdict=FAIL', r.verdict, 'FAIL');
    eq('reasons **只有** body_hazard', codes(r), [REASON.BODY_HAZARD]);
    ok('**不得**出现 body_not_air', !codes(r).includes(REASON.BODY_NOT_AIR), j(codes(r)));
    ok('**不得**出现 unreadable_body', !codes(r).includes(REASON.UNREADABLE_BODY), j(codes(r)));
    // ⚠ 身体格**不在自己的 6 邻里** ⇒ body_hazard 与 adjacent_hazard 是两条独立的判据，别混成一条
    eq('adjacent_hazard 不应被身体危险顺带触发', r.hazardCount, 0);
}
{
    // flowing_lava / magma_block 身体格同样归 body_hazard
    for (const name of ['flowing_lava', 'magma_block']) {
        const r = auditCell(worldFrom(new Map([['10,10,20', name], ['10,9,20', 'stone']])), P);
        eq(`身体格=${name} ⇒ FAIL body_hazard`, [r.verdict, codes(r).includes(REASON.BODY_HAZARD)], ['FAIL', true]);
    }
}

// ---------------------------------------------------------------- T3 脚下是 magma_block
console.log('\nT3 脚下是 magma_block ⇒ FAIL foot_is_hazard');
{
    const r = auditCell(worldFrom(new Map([['10,9,20', 'magma_block']])), P);
    eq('verdict=FAIL', r.verdict, 'FAIL');
    ok('reason 含 foot_is_hazard', codes(r).includes(REASON.FOOT_IS_HAZARD), j(codes(r)));
    ok('**不得**出现 foot_not_solid（危险先判）', !codes(r).includes(REASON.FOOT_NOT_SOLID), j(codes(r)));
    ok('同时相邻危险命中（脚下也在 6 邻内）', codes(r).includes(REASON.ADJACENT_HAZARD), j(codes(r)));
    eq('head 仍是 air（不影响硬判据）', r.head, 'air');
}
{
    // 脚下是 lava
    const r = auditCell(worldFrom(new Map([['10,9,20', 'lava']])), P);
    ok('脚下=lava ⇒ foot_is_hazard', [r.verdict, codes(r).includes(REASON.FOOT_IS_HAZARD)], ['FAIL', true]);
}

// ---------------------------------------------------------------- T4 旁边 1 格 lava，脚下实心
console.log('\nT4 脚下实心、旁边 1 格 lava ⇒ FAIL adjacent_hazard（比"只查脚下"严的那条）');
{
    const r = auditCell(worldFrom(new Map([['11,10,20', 'lava'], ['10,9,20', 'stone']])), P);
    eq('verdict=FAIL', r.verdict, 'FAIL');
    eq('reasons **只有** adjacent_hazard', codes(r), [REASON.ADJACENT_HAZARD]);
    eq('hazardCount=1', r.hazardCount, 1);
    eq('命中的危险邻', r.hazards, [{ cell: [11, 10, 20], name: 'lava' }]);
    eq('body/foot/head 都正常（说明不是前两条判据在红）', [r.body, r.foot, r.head], ['air', 'stone', 'air']);
}
// 6 邻 6 个方向都要覆盖（每个方向各钉一次）
{
    const dirs = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0], [0, -1, 0]];
    const got = dirs.map(([dx, dy, dz]) => {
        const c = [P[0] + dx, P[1] + dy, P[2] + dz];
        // ⚠ 下方那格**就是脚下**：同一格不能又写 stone 又写 magma_block（Map 后者覆盖前者，夹具会骗人）
        const m = new Map();
        if (K(c) !== '10,9,20') m.set('10,9,20', 'stone');
        m.set(K(c), 'magma_block');
        return auditCell(worldFrom(m), P).hazardCount;
    });
    eq('6 个方向的危险都数到', got, [1, 1, 1, 1, 1, 1]);
}

// ---------------------------------------------------------------- T5 readBlock 返 null
console.log('\nT5 读不到(null) ⇒ unreadable，**绝不是 OK、也绝不是 body_not_air**');
{
    // ⚠ 夹具必须**同时**给一个实心脚下，否则"脚读不到"会把默认 air 变成 foot_not_solid，测的就不是 unreadable 了
    const r = auditCell(worldFrom(new Map([['10,10,20', null], ['10,9,20', 'stone']])), P);
    eq('verdict=UNREADABLE', r.verdict, 'UNREADABLE');
    ok('reason 含 unreadable_body', codes(r).includes(REASON.UNREADABLE_BODY), j(codes(r)));
    ok('**不得**判 OK', r.verdict !== 'OK');
    ok('**不得**折算成 body_not_air', !codes(r).includes(REASON.BODY_NOT_AIR), j(codes(r)));
    eq('body 保留为 null（没被换成 air）', r.body, null);
    const s = summarize([r]);
    eq('汇总里 unreadable=1 / ok=0 / fail=0', [s.ok, s.fail, s.unreadable], [0, 0, 1]);
    eq('unreadables 清单里有这一格', s.unreadables.map((x) => x.cell), [P]);
}
{
    // 脚下读不到
    const r = auditCell(worldFrom(new Map([['10,9,20', null]])), P);
    eq('脚下 null ⇒ UNREADABLE', r.verdict, 'UNREADABLE');
    ok('reason 含 unreadable_foot', codes(r).includes(REASON.UNREADABLE_FOOT), j(codes(r)));
    ok('**不得**折算成 foot_not_solid', !codes(r).includes(REASON.FOOT_NOT_SOLID), j(codes(r)));
}
// T5b 真 region_reader 的口径：读不到返回 'unknown' **字符串**
{
    const r = auditCell(worldFrom(new Map([['10,10,20', 'unknown'], ['10,9,20', 'stone']])), P);
    eq("'unknown' 字符串 ⇒ UNREADABLE", r.verdict, 'UNREADABLE');
    eq("'unknown' 归一后 body=null", r.body, null);
    ok("'unknown' 不算 OK", r.verdict !== 'OK');
}

// ---------------------------------------------------------------- T6 stand 同族用例
console.log('\nT6 stand：同三条判据，同一批用例');
{
    const cases = [
        ['stand 正例（空气身 + 实心脚 + 邻无危险）', new Map([['10,9,20', 'stone']]), 'OK', []],
        ['stand 身体危险', new Map([['10,10,20', 'lava'], ['10,9,20', 'stone']]), 'FAIL', [REASON.BODY_HAZARD]],
        ['stand 脚下危险', new Map([['10,9,20', 'magma_block']]), 'FAIL', [REASON.FOOT_IS_HAZARD, REASON.ADJACENT_HAZARD]],
        ['stand 脚下不实心（空气）', new Map([['10,9,20', 'air']]), 'FAIL', [REASON.FOOT_NOT_SOLID]],
        ['stand 脚下不实心（水）', new Map([['10,9,20', 'water']]), 'FAIL', [REASON.FOOT_NOT_SOLID]],
        ['stand 脚下是草（可替换）', new Map([['10,9,20', 'short_grass']]), 'FAIL', [REASON.FOOT_NOT_SOLID]],
        ['stand 身体非空气（石头）', new Map([['10,10,20', 'stone'], ['10,9,20', 'stone']]), 'FAIL', [REASON.BODY_NOT_AIR]],
        ['stand 邻接危险（脚下实心）', new Map([['10,10,21', 'lava'], ['10,9,20', 'stone']]), 'FAIL', [REASON.ADJACENT_HAZARD]],
        ['stand 读不到', new Map([['10,10,20', null], ['10,9,20', 'stone']]), 'UNREADABLE', [REASON.UNREADABLE_BODY]],
    ];
    for (const [name, m, wantV, wantR] of cases) {
        const r = auditCell(worldFrom(m), P);
        eq(name, [r.verdict, codes(r)], [wantV, wantR]);
    }
    // 批量 + 汇总（模拟一条 stand 列表）
    const rows = auditCells(worldFrom(new Map([['10,9,20', 'stone'], ['11,9,20', 'stone'], ['12,9,20', 'lava']])),
        [[10, 10, 20], [11, 10, 20], [12, 10, 20]]);
    const s = summarize(rows);
    eq('批量汇总 ok/fail/unreadable', [s.ok, s.fail, s.unreadable], [2, 1, 0]);
    eq('批量清单坐标', s.fails.map((r) => r.cell), [[12, 10, 20]]);
    eq('原因码计数', [...s.reasonCounts.entries()].sort(), [[REASON.ADJACENT_HAZARD, 1], [REASON.FOOT_IS_HAZARD, 1]]);
}

// ---------------------------------------------------------------- T7 头格被占 = 软失败
console.log('\nT7 头格被占 ⇒ 仍是 OK，只进 headBlocked 统计（软/硬必须分开）');
{
    const r = auditCell(worldFrom(new Map([['10,9,20', 'stone'], ['10,11,20', 'stone']])), P);
    eq('verdict 仍=OK', r.verdict, 'OK');
    eq('reasons 空（不进硬失败）', codes(r), []);
    ok('headBlocked=true', r.headBlocked === true);
    const s = summarize([r]);
    eq('headBlocked 计数=1', s.headBlocked, 1);
    eq('FAIL 计数仍=0', s.fail, 0);
}
{
    // 头格读不到也只统计，不改判定
    const r = auditCell(worldFrom(new Map([['10,9,20', 'stone'], ['10,11,20', 'unknown']])), P);
    eq('头格 unknown ⇒ verdict 仍 OK', r.verdict, 'OK');
    ok('headUnreadable=true', r.headUnreadable === true);
}

// ---------------------------------------------------------------- T8 优先级
console.log('\nT8 混合：硬判据优先于读不到，但读不到必须留痕');
{
    const r = auditCell(worldFrom(new Map([['10,9,20', null], ['11,10,20', 'lava']])), P);
    eq('脚读不到 + 邻接危险 ⇒ FAIL', r.verdict, 'FAIL');
    ok('命中 adjacent_hazard', codes(r).includes(REASON.ADJACENT_HAZARD), j(codes(r)));
    ok('同时留 unreadable_foot 痕迹', codes(r).includes(REASON.UNREADABLE_FOOT), j(codes(r)));
    eq('6 邻里读不到的格被单独计数', r.unreadableNeighbors, 1);
}

// ---------------------------------------------------------------- T9 参数默认值
console.log('\nT9 CLI 默认路径必须指向任务书给的两个真实文件');
{
    const o = parseArgs([]);
    eq('默认 route', o.route, path.normalize(DEFAULTS.route));
    ok('默认 route 以 4926685115947721762.v2.json 结尾', o.route.endsWith(path.join('route', '4926685115947721762.v2.json')), o.route);
    ok('默认 world 以 _s1_main_fresh\\4926685115947721762 结尾', o.world.endsWith(path.join('route', 'probe', '_s1_main_fresh', '4926685115947721762')), o.world);
    const o2 = parseArgs(['--route=D:/x/r.json', '--world', 'D:/y/w']);
    eq('--k=v 与 --k v 都认', [o2.route, o2.world], [path.resolve('D:/x/r.json'), path.resolve('D:/y/w')]);
    ok('未知参数报错', (() => { try { parseArgs(['--nope=1']); return false; } catch { return true; } })());
}

// ---------------------------------------------------------------- 汇总
console.log(`\nPASS ${pass} / FAIL ${fail}`);
process.exit(fail === 0 ? EXIT.OK : 1);
