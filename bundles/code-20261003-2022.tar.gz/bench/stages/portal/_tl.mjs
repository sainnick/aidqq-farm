#!/usr/bin/env node
// _tl.mjs — 把 telemetry.jsonl 打成一行一条（自用小工具，r16 加）
// 跑法：node _tl.mjs runs/P8R16_PANEL/trial_01 [过滤子串] [--full]
import fs from 'fs';

const [dir, filter, ...rest] = process.argv.slice(2);
const full = rest.includes('--full');
const KEEP = new Set([
    'station_nav_hop', 'station_nav_descend', 'station_nav_done', 'descend_found_strong', 'descend_step',
    'station_confirmed', 'station_scan', 'station_not_confirmed', 'portal_station_confirmed', 'portal_station_nav_failed',
    'portal_station_fallback', 'portal_frame_located', 'portal_frame_not_found', 'portal_work_layer_descend',
    'portal_work_layer_landed', 'portal_work_layer_skip', 'portal_dig_ok', 'portal_dig_fail', 'portal_dig_abort_hazard',
    'portal_dig_skip', 'portal_chest_looted', 'portal_chest_none', 'patch_approach_fail', 'patch_back_fail',
    'patch_scoop_ok', 'patch_scoop_fail', 'patch_pour_ok', 'patch_pour_fail', 'patch_cast_ok', 'patch_cast_fail',
    'nav_lava_guard', 'nav_lava_retreat', 'nav_fail', 'walk_near_ok', 'walk_near_navfail', 'walk_near_reposition',
    'walk_near_reposition_ok', 'task_on_death', 'task_internal_error', 'portal_ignited', 'portal_ignite_fail',
    'portal_cast_at_station', 'portal_patch_fail', 'portal_frame_refix', 'portal_lava_step_off', 'portal_lava_nospot',
    'soft_stuck', 'hard_stuck', 'mission_end', 'descend_dig_ok', 'descend_dig_fail', 'portal_frame_cells',
]);
const lines = fs.readFileSync(`${dir}/telemetry.jsonl`, 'utf8').trim().split('\n');
const t0 = Number(JSON.parse(lines[0]).t);
for (const ln of lines) {
    let o; try { o = JSON.parse(ln); } catch { continue; }
    if (filter && !o.event.includes(filter) && !JSON.stringify(o).includes(filter)) continue;
    if (!filter && !full && !KEEP.has(o.event) && o.event !== 'nav_end') continue;
    const { t, event, ...rest2 } = o;
    let s = JSON.stringify(rest2);
    if (!full) {
        for (const k of ['label', 'at', 'pos', 'to', 'from', 'target', 'wanted', 'src', 'lavaAt', 'origin', 'axis', 'feetY', 'anchorY', 'strongY', 'bot', 'underHere']) {
            s = s.replace(new RegExp(`"${k}":(\\[[^\\]]*\\]|null|true|false|[-0-9.]+|"[^"]*")`, 'g'), `"${k}":$1`);
        }
    }
    console.log(`${((t - t0) / 1000).toFixed(1).padStart(7)}s ${event.padEnd(26)} ${s.length > 460 ? s.slice(0, 460) + '…' : s}`);
}
