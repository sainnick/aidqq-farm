﻿import fs from 'node:fs';
const src=fs.readFileSync('D:/AI斗蛐蛐/bench/route/tools/region_reader.mjs','utf8');
const lines=src.split(/\r?\n/);
lines.forEach((l,i)=>{ if(/^export |^ \* @|^\/\*\*|^function |^const .*=.*=>|^class /.test(l)) console.log((i+1)+': '+l.slice(0,150)); });
