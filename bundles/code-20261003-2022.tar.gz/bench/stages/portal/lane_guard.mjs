// lane_guard.mjs — MC-M1-TASK-08 泳道 B 占用闸门（本 stage 私有，_lib 一个字没改）
//
// 为什么需要它（06c P0 血的教训 + 本单实测的一次真事故）：
//   1. **端口判据不够**。P8_PROBE 实测：主线 A 的两泳道跑批之间，25567 会**短暂空闲**，
//      此时端口查不到监听就以为泳道空着 → 于是开跑 → freshWorld 去删
//      server-1161_laneB/spike_world → 报 `ENOTEMPTY: directory not empty`。
//      根因：端口是「服务进程在不在」，不是「这条泳道归不归我」。别的 runner 正在用这个
//      目录循环起停服，目录随时被重写。
//   2. **权威判据是 _lib 的泳道归属心跳**（06c P0 交付）：起服方每 3s 刷新
//      experiments/mc1161-gate/.lane-owners/<dir>.json，preflight 的
//      `ownedByLiveDir()` 据此判定「这条泳道是不是某个**活着的** runner 的」。
//      这正是 06c §P0 造出来替换掉旧的恒真判据（「日志活跃=有人在跑」）的东西。
//   3. 隔离纪律：发现别的线在跑**只等待，不干预**（根 AGENTS.md §2：杀进程/删档先问用户）。
//
// 判据（任一成立即「不可用」）：
//   a. ownedByLiveDir(dir) 非空      → 活的 runner 拥有这条泳道（本线是它的并行开发线，不是它）
//   b. 25567/25577 任一 LISTENING    → 端口被占（可能是残留，也可能对方正在起服）
//   c. 空闲内存 < 下限               → waitFreeMem 排队（手册 §4.7）

import { execSync } from 'child_process';
import { ownedByLiveDir } from '../_lib/preflight.mjs';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 端口是否 LISTENING（只读观测） */
export function portBusy(port) {
    try {
        const txt = execSync(`netstat -ano | findstr ":${port} "`, { encoding: 'utf8' });
        return txt.split(/\r?\n/).some((l) => l.includes('LISTENING'));
    } catch { return false; }
}

/**
 * 泳道占用全景。
 * @returns {{usable:boolean, owner:string|null, ports:boolean[], why:string}}
 */
export function laneStatus(lane) {
    const owner = ownedByLiveDir(lane.dir);
    const ports = [lane.serverPort, lane.rconPort].map(portBusy);
    if (owner) return { usable: false, owner, ports, why: `owned_by_live_runner(${owner})` };
    if (ports.some(Boolean)) return { usable: false, owner: null, ports, why: 'port_in_use' };
    return { usable: true, owner: null, ports, why: 'free' };
}

/**
 * 等到本线可以安全开跑。期间只观察不干预。
 * 端口空闲**不等于**可以跑——必须同时满足「没有活的 runner 拥有这个目录」。
 * @param {object} lane
 * @param {{maxMs?:number, pollMs?:number, onWait?:Function}} [opts]
 */
export async function waitLane(lane, opts = {}) {
    const { maxMs = 30 * 60 * 1000, pollMs = 20000, onWait = null } = opts;
    const t0 = Date.now();
    let announced = null;
    while (Date.now() - t0 < maxMs) {
        const st = laneStatus(lane);
        if (st.usable) return st;
        if (announced !== st.why) {
            announced = st.why;
            onWait?.(st);
        }
        await sleep(pollMs);
    }
    return laneStatus(lane);
}

/** 别的线在用的端口（只记录，不干预）——写进 run_meta 便于事后归因 */
export function foreignPorts(ports) {
    return ports.filter((p) => portBusy(p));
}
