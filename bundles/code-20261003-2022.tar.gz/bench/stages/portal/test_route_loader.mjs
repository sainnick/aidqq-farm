// test_route_loader.mjs — route_loader / station_nav 的离线单测（不开服、不占泳道）
//
// 补充单 §2 的验收项：
//   `route_loader` 单测 | 改 1 字节 → 拒绝加载；scout 字段不可见；精确中心被对齐到 8 格网格
//   禁区（补充单 §3）  | 任务层代码里禁止出现读取 route 文件 scout 字段的路径，也禁止硬编码坐标；
//                      单测要覆盖这一点
//
// 跑法：node bench/stages/portal/test_route_loader.mjs   （退出码 0 = 全过）

import { createRequire } from 'module';
import { pathToFileURL, fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import os from 'os';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const ROUTE_DIR = path.join(ROOT, 'bench', 'route');
// ⚠ 这里原本指向 `-8839485814800629942.draft.json`，**该文件已被 bench 提交 89c0305 删除**
//   （`git log --diff-filter=D -- route/-8839485814800629942.draft.json`），本单开工前
//   这个测试在第 55 行就 ENOENT 崩掉、一条用例也跑不到。同种子的 `<seed>.json` 仍在
//   仓库里且 `frozenAt=null`（按 SCHEMA 判定就是草稿），站级数据与下面各条断言完全吻合，
//   所以改指它；不新建文件（授权范围只有本测试与 route_loader.js）。
const DRAFT = path.join(ROUTE_DIR, '-8839485814800629942.json');

const L = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/route_loader.js')).href);
const N = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/station_nav.js')).href);
// 权威哈希口径（编排器侧，bench commit ce56269 统一过）：**动态 import**，不复制粘贴实现，
// 这样下面的用例是真的在跨仓库比对，而不是把同一份算法抄了两遍自己跟自己比。
const G = await import(pathToFileURL(path.join(BENCH_DIR, '..', 'fullrun', 'route_guard.mjs')).href);

let pass = 0, fail = 0;
const fails = [];
function t(name, fn) {
    try {
        fn();
        pass++;
        console.log(`  ✅ ${name}`);
    } catch (e) {
        fail++;
        fails.push({ name, err: String(e && e.message ? e.message : e) });
        console.log(`  ❌ ${name} —— ${e && e.message ? e.message : e}`);
    }
}
function eq(a, b, msg = '') {
    const sa = JSON.stringify(a), sb = JSON.stringify(b);
    if (sa !== sb) throw new Error(`${msg} 期望 ${sb}，实际 ${sa}`);
}
function ok(v, msg = '') { if (!v) throw new Error(msg || '断言失败'); }
function throwsCode(fn, code) {
    try {
        fn();
    } catch (e) {
        if (e?.code === code) return e;
        throw new Error(`期望 code=${code}，实际 code=${e?.code} msg=${e?.message}`);
    }
    throw new Error(`期望抛错 code=${code}，但没抛`);
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'p8-route-'));
const draftRaw = JSON.parse(fs.readFileSync(DRAFT, 'utf8'));

console.log('# route_loader / station_nav 离线单测\n');

// ---------- 1. 规范化与哈希 ----------
console.log('## 1. 规范化与哈希（SCHEMA §4 v1.1：对整文件算，含 frozenAt）');
t('改 frozenAt 一定改哈希（草稿态与冻结态是两份不同的文件）', () => {
    const a = { schema: 'aidqq-route/1', frozenAt: null, seed: '1', stations: [] };
    const b = { schema: 'aidqq-route/1', frozenAt: '2026-10-01T00:00:00Z', seed: '1', stations: [] };
    ok(L.computeCanonicalSha256(a) !== L.computeCanonicalSha256(b),
        'SCHEMA §4 v1.1 对整个文件算、含 frozenAt ⇒ 冻结动作改这一个字段就会改哈希');
});
t('改 sha256File 一定改哈希（它也在整文件里）', () => {
    const a = { schema: 'aidqq-route/1', frozenAt: null, sha256File: null, seed: '1', stations: [] };
    const b = { schema: 'aidqq-route/1', frozenAt: null, sha256File: '1.sha256', seed: '1', stations: [] };
    ok(L.computeCanonicalSha256(a) !== L.computeCanonicalSha256(b),
        'sha256File 是整文件的一部分 ⇒ 改它就该改哈希（不构成循环依赖：值只是旁挂文件名）');
});
t('键序会改变哈希（规范化只管缩进与末尾换行，不排序键）', () => {
    const a = { schema: 'aidqq-route/1', seed: '1', stations: [{ id: 'x', seq: 1 }] };
    const b = { stations: [{ seq: 1, id: 'x' }], seed: '1', schema: 'aidqq-route/1' };
    // 结论（按事实记录，不是 bug）：JSON.parse 保序、route_guard 的口径不排序键 ⇒ 键序会改哈希。
    // 因此**生成工具必须写出稳定键序**（同一条生成路径必然同序），换工具链就要重算冻结值。
    ok(L.computeCanonicalSha256(a) !== L.computeCanonicalSha256(b),
        '键序不同的两份文档，哈希应不同');
});
t('对象与等价原文喂进去结果相同（口径是"规范化 JSON 文本的哈希"）', () => {
    const doc = { schema: 'aidqq-route/1', seed: '1', stations: [{ id: 'x', seq: 1 }] };
    const text = JSON.stringify(doc, null, 2) + '\n';
    eq(L.computeCanonicalSha256(text), L.computeCanonicalSha256(doc), '对象 vs 2 空格缩进原文：');
    eq(L.computeCanonicalSha256(text), G.routeSha256(text), 'loader vs route_guard：');
});
t('内容变一个字节哈希就变', () => {
    const a = { schema: 'aidqq-route/1', seed: '1', stations: [{ id: 'x', radius: 24 }] };
    const b = { schema: 'aidqq-route/1', seed: '1', stations: [{ id: 'x', radius: 25 }] };
    ok(L.computeCanonicalSha256(a) !== L.computeCanonicalSha256(b), 'radius 24/25 的哈希不应相同');
});

// ---------- 1.4 跨仓库一致性（本单核心验收） ----------
console.log('\n## 1.4 跨仓库一致性：同一份 route 文件，loader 哈希必须 == route_guard 哈希');
// 真实主种子（只读；不往 bench/route 写任何东西）
const REAL = path.join(ROUTE_DIR, '4926685115947721762.json');
const realRaw = fs.readFileSync(REAL, 'utf8');
const lfText = realRaw.replace(/\r\n/g, '\n');
const crlfText = lfText.replace(/\n/g, '\r\n');
const lfFile = path.join(tmp, 'seed-lf.json');
const crlfFile = path.join(tmp, 'seed-crlf.json');
fs.writeFileSync(lfFile, lfText, 'utf8');
fs.writeFileSync(crlfFile, crlfText, 'utf8');

const guardSeed = G.readRouteFile(REAL).sha256;
const loaderSeed = L.computeCanonicalSha256(realRaw);
console.log(`     主种子 ${path.basename(REAL)}`);
console.log(`       route_guard.routeSha256 = ${guardSeed}`);
console.log(`       loader.computeCanonical = ${loaderSeed}`);

t('真实主种子本身 0 violations、且仍是草稿（我只读没动它）', () => {
    const r = G.readRouteFile(REAL);
    eq(r.violations, [], '主种子不该有 SCHEMA 违规：');
    eq(r.doc.frozenAt, null, '主种子应仍是草稿：');
});
t('LF 与 CRLF 两版：loader 哈希相同（换行风格无关 = 规范化口径的全部理由）', () => {
    ok(lfText !== crlfText && crlfText.includes('\r\n'), '两版内容必须真的不同，否则这条是空转');
    eq(L.computeCanonicalSha256(lfText), L.computeCanonicalSha256(crlfText), 'LF/CRLF 两版 loader 哈希应相同：');
});
t('LF 与 CRLF 两版：route_guard 哈希相同，且与 loader 逐字相同', () => {
    eq(G.routeSha256(crlfText), G.routeSha256(lfText), 'LF/CRLF 两版 route_guard 哈希应相同：');
    eq(L.computeCanonicalSha256(lfText), G.routeSha256(lfText), 'loader vs route_guard（LF）：');
    eq(L.computeCanonicalSha256(crlfText), G.routeSha256(crlfText), 'loader vs route_guard（CRLF）：');
});
t('loader 哈希 == route_guard 对该真实文件的 sha256（三份输入同一答案）', () => {
    eq(loaderSeed, guardSeed, 'loader(原文) vs route_guard(真实文件)：');
    eq(L.computeCanonicalSha256(lfText), guardSeed, 'loader(LF 临时文件) vs route_guard(真实文件)：');
    eq(L.computeCanonicalSha256(crlfText), guardSeed, 'loader(CRLF 临时文件) vs route_guard(真实文件)：');
});
t('运行期真路径 loadRoute().sha256 也等于 route_guard（LF/CRLF 都放行）', () => {
    const ev = [];
    const rLf = L.loadRoute(lfFile, { allowDraft: true, telemetry: (e) => ev.push(e) });
    const rCrlf = L.loadRoute(crlfFile, { allowDraft: true, telemetry: (e) => ev.push(e) });
    eq(rLf.sha256, guardSeed, 'loadRoute(LF 临时文件)：');
    eq(rCrlf.sha256, guardSeed, 'loadRoute(CRLF 临时文件)：');
    eq(rLf.stations.length, 10, '主种子 10 站应全部通过投影：');
    eq(ev.filter((e) => e === 'route_loaded').length, 2, '两次加载都该记 route_loaded');
});
t('改一个字段 ⇒ 两边哈希同时变化（两边不会一起静默漂移）', () => {
    const before = { loader: L.computeCanonicalSha256(lfText), guard: G.routeSha256(lfText) };
    eq(before.loader, before.guard, '基准态两边就应相同：');
    const doc = JSON.parse(lfText);
    doc.stations[0].station.radius += 1;                 // 32 → 33，只动一个字段
    const afterText = JSON.stringify(doc, null, 2) + '\n';
    const after = { loader: L.computeCanonicalSha256(afterText), guard: G.routeSha256(afterText) };
    ok(after.loader !== before.loader, 'loader 哈希必须变：');
    ok(after.guard !== before.guard, 'route_guard 哈希必须变：');
    eq(after.loader, after.guard, '改动后两边仍必须相同：');
    console.log(`     改 radius 32→33：loader ${after.loader.slice(0, 16)}… / route_guard ${after.guard.slice(0, 16)}…`);
});

// ---------- 2. 草稿加载 ----------
console.log('\n## 2. 草稿 route 加载与投影');
t('草稿 + allowDraft:true 能加载', () => {
    const r = L.loadRoute(DRAFT, { allowDraft: true });
    ok(r.draft === true, 'draft 标志');
    // 原断言写死 `站数应为 2` —— 那是已被 bench 提交 89c0305 删除的两站草稿的形状。
    // 改成与文件里实际站数**严格相等**：比写死数字更强（多一站/少一站/有站被拒都会红）。
    ok(r.stations.length > 0, '不该加载出 0 站');
    eq(r.stations.length, draftRaw.stations.length, `站数应与 ${path.basename(DRAFT)} 的站数一致（无站被拒）：`);
});
t('草稿在正式局（allowDraft 默认 false）被拒绝', () => {
    const events = [];
    throwsCode(() => L.loadRoute(DRAFT, { telemetry: (e) => events.push(e) }), 'route_is_draft');
    ok(events.includes('route_is_draft'), '应记 route_is_draft 遥测');
});
t('scout 字段在返回值里任何层级都不可见', () => {
    const r = L.loadRoute(DRAFT, { allowDraft: true });
    const seen = [];
    (function walk(o, p = '$') {
        if (!o || typeof o !== 'object') return;
        for (const k of Object.keys(o)) {
            if (k === 'scout') seen.push(`${p}.${k}`);
            walk(o[k], `${p}.${k}`);
        }
    })(r);
    eq(seen, [], '返回值里出现 scout：');
    eq(Object.keys(r.station('S1_portal')).sort(),
        ['center', 'dim', 'fallback', 'id', 'kind', 'lookFor', 'radius', 'seq', 'yHint'].sort(),
        '站级字段集合：');
});
t('assertNoScout 能抓住泄漏（防以后有人手滑 ...raw）', () => {
    throwsCode(() => L.assertNoScout({ stations: [{ id: 'a', scout: { points: [1, 2, 3] } }] }), 'scout_leaked');
});
t('主种子站 S1_portal 的站级数据正确且已对齐 8 格网格', () => {
    const s = L.loadRoute(DRAFT, { allowDraft: true }).station('S1_portal');
    eq(s.center, { x: 176, z: 352 });
    ok(s.center.x % 8 === 0 && s.center.z % 8 === 0, '中心必须落在 8 格网格上');
    eq(s.radius, 24);
    eq(s.lookFor.slice(), ['crying_obsidian', 'obsidian']);
    eq(s.fallback.slice(), ['S1b_lava_pool']);
    eq(s.dim, 'overworld');
    eq(s.yHint, 'surface');
});
t('精确中心被对齐到 8 格网格（181,357 → 184,360）', () => {
    const f = path.join(tmp, 'align.json');
    const raw = {
        schema: 'aidqq-route/1', seed: 'x', mcVersion: '1.16.1', frozenAt: null,
        stations: [{ id: 'A', seq: 1, kind: 'lava_pool', dim: 'overworld', station: { center: [181, 357], yHint: 'surface', radius: 24, lookFor: ['lava'] }, fallback: [] }],
    };
    fs.writeFileSync(f, JSON.stringify(raw, null, 2));
    const s = L.loadRoute(f, { allowDraft: true }).station('A');
    eq(s.center, { x: 184, z: 360 });
});
t('radius < 16 → 拒绝这一站（不 clamp、不掩盖写错）', () => {
    const f = path.join(tmp, 'small.json');
    fs.writeFileSync(f, JSON.stringify({
        schema: 'aidqq-route/1', seed: 'x', frozenAt: null,
        stations: [
            { id: 'small', seq: 1, kind: 'lava_pool', dim: 'overworld', station: { center: [0, 0], radius: 8, lookFor: ['lava'] } },
            { id: 'ok', seq: 2, kind: 'lava_pool', dim: 'overworld', station: { center: [8, 8], radius: 16, lookFor: ['lava'] } },
        ],
    }, null, 2));
    const ev = [];
    const r = L.loadRoute(f, { allowDraft: true, telemetry: (e, d) => ev.push([e, d]) });
    eq(r.stations.map((s) => s.id), ['ok'], 'radius=8 的站必须被拒，radius=16 的留下：');
    eq(r.rejected.map((x) => x.code), ['station_radius_too_small']);
    ok(ev.some(([e]) => e === 'route_station_rejected'), '应记 route_station_rejected');
    throwsCode(() => r.station('small'), 'station_radius_too_small');
});
t('scout 里写精确坐标也救不回来（投影只看 station）', () => {
    const f = path.join(tmp, 'leak.json');
    fs.writeFileSync(f, JSON.stringify({
        schema: 'aidqq-route/1', seed: 'x', frozenAt: null,
        stations: [{
            id: 'A', seq: 1, kind: 'ruined_portal', dim: 'overworld',
            station: { center: [176, 352], radius: 24, lookFor: ['obsidian'] },
            scout: { points: [{ what: 'frame_corner', xyz: [180, 64, 349] }] },
        }],
    }, null, 2));
    const r = L.loadRoute(f, { allowDraft: true });
    const s = r.station('A');
    eq(JSON.stringify(s).includes('frame_corner'), false, '精确坐标不该出现在站级数据里：');
    eq(JSON.stringify(s).includes('349'), false);
});

// ---------- 3. 冻结版与哈希闸门 ----------
console.log('\n## 3. 冻结版与哈希闸门');
function writeFrozen(dir, mutate) {
    const raw = JSON.parse(fs.readFileSync(DRAFT, 'utf8'));
    raw.frozenAt = '2026-10-01T00:00:00Z';
    if (mutate) mutate(raw);
    const file = path.join(dir, `${raw.seed}.json`);
    fs.writeFileSync(file, JSON.stringify(raw, null, 2));
    const hex = L.computeCanonicalSha256(raw);
    fs.writeFileSync(path.join(dir, `${raw.seed}.sha256`), `${hex}\n`);
    return { file, hex };
}
t('冻结版哈希对得上就能加载，并记 route_loaded 遥测（含 sha256）', () => {
    const d = path.join(tmp, 'frozen1'); fs.mkdirSync(d, { recursive: true });
    const { file, hex } = writeFrozen(d);
    const ev = [];
    const r = L.loadRoute(file, { telemetry: (e, data) => ev.push([e, data]) });
    ok(r.frozen === true, 'frozen 标志');
    eq(r.sha256, hex);
    const loaded = ev.find(([e]) => e === 'route_loaded');
    ok(loaded && loaded[1].sha256 === hex, '遥测里必须带 route 的 sha256（SCHEMA §3）');
});
t('改 1 字节 → 拒绝加载（route_hash_mismatch）', () => {
    const d = path.join(tmp, 'frozen2'); fs.mkdirSync(d, { recursive: true });
    const { file } = writeFrozen(d);
    // 只改一个字节：radius 24 → 25（文件里其它内容与 sha 文件都不动）
    const txt = fs.readFileSync(file, 'utf8').replace('"radius": 24', '"radius": 25');
    fs.writeFileSync(file, txt);
    const ev = [];
    throwsCode(() => L.loadRoute(file, { telemetry: (e) => ev.push(e) }), 'route_hash_mismatch');
    ok(ev.includes('route_hash_mismatch'), '必须记 route_hash_mismatch');
});
t('冻结版缺 .sha256 文件 → 拒绝加载（route_hash_missing）', () => {
    const d = path.join(tmp, 'frozen3'); fs.mkdirSync(d, { recursive: true });
    const { file } = writeFrozen(d);
    fs.rmSync(path.join(d, '-8839485814800629942.sha256'));
    throwsCode(() => L.loadRoute(file), 'route_hash_missing');
});
t('草稿不需要 .sha256（开发局不冻结）', () => {
    const r = L.loadRoute(DRAFT, { allowDraft: true });
    ok(r.draft && !fs.existsSync(path.join(ROUTE_DIR, '-8839485814800629942.sha256')),
        '草稿没有冻结哈希文件也能加载');
});

// ---------- 4. 到达确认闸门的纯逻辑 ----------
console.log('\n## 4. 到达确认闸门（纯逻辑部分）');
t('planTurns：方向不重复、步长小（真人换方向的样子）', () => {
    const turns = N.planTurns(6);
    eq(turns.length, 6);
    eq(new Set(turns.map((x) => x.yawDeg)).size, 6, '6 次转身的朝向不该重复');
    for (const x of turns) {
        ok(Math.hypot(x.step[0], x.step[1]) <= 6, `步长过大 ${JSON.stringify(x.step)}`);
        ok(Math.abs(x.pitchDeg) <= 18, '俯仰不该太夸张');
    }
});
t('STATION_NOT_CONFIRMED 是导出常量（编排器按它判失败）', () => {
    eq(N.STATION_NOT_CONFIRMED, 'STATION_NOT_CONFIRMED');
});

// ---------- 5. 禁区守卫（补充单 §3） ----------
console.log('\n## 5. 禁区守卫：任务层不许读 scout、不许硬编码坐标');
const EXEC_DIR = path.join(MINDCRAFT, 'src', 'agent', 'tasks', 'exec');
const TASK_FILES = fs.readdirSync(EXEC_DIR).filter((f) => f.endsWith('.js'));

t('只有 route_loader.js 允许出现 scout 这个键名', () => {
    const bad = [];
    for (const f of TASK_FILES) {
        if (f === 'route_loader.js') continue;
        const src = fs.readFileSync(path.join(EXEC_DIR, f), 'utf8');
        // 只看代码形态的引用（.scout / ['scout'] / "scout":），注释里的中文说明不算
        const hits = src.match(/\.scout\b|\[\s*['"]scout['"]\s*\]|['"]scout['"]\s*:/g);
        if (hits) bad.push(`${f}: ${hits.join(',')}`);
    }
    eq(bad, [], '这些文件在代码里引用了 scout：');
});
t('只有 route_loader.js 允许读 route 文件（fs 读 + 路径字面量）', () => {
    const bad = [];
    for (const f of TASK_FILES) {
        if (f === 'route_loader.js') continue;
        const src = fs.readFileSync(path.join(EXEC_DIR, f), 'utf8');
        if (/readFileSync|readFile\s*\(|JSON\.parse\s*\(\s*fs/.test(src) && /route/i.test(src)) bad.push(f);
        if (/['"`][^'"`]*route\/[^'"`]*\.json['"`]/.test(src)) bad.push(`${f}(路径字面量)`);
    }
    eq(bad, [], '这些文件疑似自己读 route：');
});
t('站级模块里没有硬编码世界坐标', () => {
    const bad = [];
    for (const f of TASK_FILES) {
        if (f !== 'route_loader.js' && f !== 'station_nav.js') continue;
        const src = fs.readFileSync(path.join(EXEC_DIR, f), 'utf8')
            .replace(/\/\*[\s\S]*?\*\//g, '')      // 去块注释
            .replace(/^\s*\/\/.*$/gm, '');        // 去行注释
        for (const m of src.matchAll(/\[\s*(-?\d+)\s*,\s*(-?\d+)\s*(?:,\s*(-?\d+)\s*)?\]/g)) {
            const nums = [m[1], m[2], m[3]].filter((x) => x !== undefined).map(Number);
            if (nums.some((v) => Math.abs(v) >= 64)) bad.push(`${f}: ${m[0]}`);
        }
    }
    eq(bad, [], '站级模块里出现疑似世界坐标的字面量：');
});
t('真实的草稿 route 站级数据不含精确 y（yHint 只是提示）', () => {
    const r = L.loadRoute(DRAFT, { allowDraft: true });
    for (const s of r.stations) {
        eq(Object.keys(s).includes('y'), false, `${s.id} 不该有精确 y`);
        ok(['surface', 'underground', 'nether_mid', 'any'].includes(s.yHint), `yHint 越界：${s.yHint}`);
    }
});

// ---------- 6. SCHEMA §5 v2：L0 背作业路线 ----------
// 依据：bench/route/SCHEMA.md §5（设计会话定稿 2026-10-03）+ docs/MC-DECISION-02-背作业路线与整链优先.md。
// 验收重点三条：① v1 行为一字不变；② 带 exact 的 v2 站**不再粗化**、exact 逐字返回；
//   ③ exact 写错必须落到**可区分**的机器码上（手册 §9.2 静默失败头号事故）。
console.log('\n## 6. SCHEMA §5 v2（L0 背作业）：exact 逐字返回 / 不粗化 / legs 可查');

const EV = path.join(tmp, 'ev');        // 存档解析器给出的证据路径（占位，形态与 §5 一致）
let v2Seq = 0;

/** 一份形状良好的 v2 草稿：正常流程 A→B，fallback-only 站 C（B 的备选） */
function v2Doc(mutate) {
    const doc = {
        schema: 'aidqq-route/2',
        seed: 'v2-seed',
        mcVersion: '1.16.1',
        frozenAt: null,
        normalFlowStations: ['A', 'B'],
        fallbackOnlyStations: [{ id: 'C', seq: 3, fallbackOf: ['B'] }],
        legs: [
            { from: 'A', to: 'B', dim: 'overworld', waypoints: [[180, 64, 356], [200, 64, 356]], notes: '穿草地' },
            { from: 'B', to: 'C', dim: 'overworld', waypoints: [[200, 64, 356], [220, 62, 340]] },
        ],
        stations: [
            {
                // ⚠ center 故意**不在 8 格网格上**（181/357）、radius 故意 **< 16**（9）：
                //   这两条同时成立才证明"不再粗化"，是 §5 那句"不再做 8 格粗化"的可测形态。
                id: 'A', seq: 1, kind: 'ruined_portal', dim: 'overworld',
                station: { center: [181, 357], yHint: 'surface', radius: 9, lookFor: ['crying_obsidian'] },
                exact: {
                    stand: [[181, 64, 357], [182, 64, 357]],
                    targets: [
                        { what: 'fill_cell', xyz: [180, 64, 349], order: 1, how: 'two_bucket' },
                        { what: 'dig', xyz: [181, 64, 348], tool: 'iron_pickaxe' },
                    ],
                    hazards: [[183, 63, 357]],
                    verify: { status: 'REAL', evidence: EV },
                },
                scout: { points: [{ what: 'frame_corner', xyz: [180, 64, 349] }], notes: '预勘原始数据，任务层看不见' },
            },
            {
                // B 故意**不写** targets / hazards：这两个字段在 §5 里是可选的，
                //   逐字返回要求"缺省就保持缺省"，不能被补成 [] 或 null（那就不是原文了）。
                id: 'B', seq: 2, kind: 'lava_pool', dim: 'overworld',
                station: { center: [205, 401], yHint: 'underground', radius: 12, lookFor: [] },
                exact: { stand: [[205, 40, 401]], verify: { status: 'REAL', evidence: EV } },
                fallback: ['C'],
            },
            {
                // C 是 fallback-only 站，**没有 exact**（§5 没要求 fallback-only 站有 L0 作业坐标，
                //   bench 侧 route_guard.mjs 的 checkRouteV2 同一判据）⇒ 仍走 v1 兜底粗化路径。
                id: 'C', seq: 3, kind: 'gravel', dim: 'overworld', routeRole: 'fallback-only',
                station: { center: [9, 9], yHint: 'surface', radius: 24, lookFor: ['gravel'] },
                scout: { points: [{ what: 'gravel_pile', xyz: [11, 70, 13] }] },
            },
        ],
    };
    if (mutate) mutate(doc);
    return doc;
}
function writeV2(dir, mutate) {
    const doc = v2Doc(mutate);
    const file = path.join(dir, `v2-${v2Seq++}.json`);
    fs.writeFileSync(file, JSON.stringify(doc, null, 2));
    return { file, doc };
}
fs.mkdirSync(EV, { recursive: true });

t('v1 行为一字不变：站字段集合不含 exact，legs 为空表、legsBetween 返 null', () => {
    const r = L.loadRoute(DRAFT, { allowDraft: true });
    eq(r.schema, 'aidqq-route/1', 'v1 文件的 schema：');
    eq(Object.keys(r.station('S1_portal')).includes('exact'), false, 'v1 站不该出现 exact：');
    eq(r.legs, [], 'v1 文件没有 legs 字段 ⇒ 空表：');
    eq(r.legsBetween('S1_portal', 'S1b_lava_pool'), null, 'v1 没有腿可查：');
});
t('v2 加载：schema 标志 + 带 exact 的站 center 未对齐 8 格、radius<16 原样保留', () => {
    const { file } = writeV2(EV);
    const r = L.loadRoute(file, { allowDraft: true });
    eq(r.schema, 'aidqq-route/2');
    const a = r.station('A');
    eq(a.center, { x: 181, z: 357 }, 'center 必须原样，不得对齐到 8 格网格：');
    ok(a.center.x % 8 !== 0 && a.center.z % 8 !== 0, '这条 fixture 本身就不在 8 格网格上（否则断言空转）');
    eq(a.radius, 9, 'radius=9 < 16 在 v2 下必须放行（v1 下这一站会被拒）：');
    eq(r.rejected, [], 'v2 fixture 不该有站被拒：');
});
t('L0 分叉是真的：同一份 raw 走 v1 分支会被粗化+拒，走 v2 分支原样放行', () => {
    // 这一条是"防以后有人把 v1 分支忘了改"的钉子：两个分支对**同一份输入**给出不同结果。
    const raw = v2Doc().stations[0];
    const v1r = L.projectStation(raw);              // 不传 v2 ⇒ 旧路径
    const v2r = L.projectStation(raw, { v2: true }); // 新路径
    eq(v1r.ok, false, 'v1 路径下 radius=9 必须被拒：');
    eq(v1r.code, 'station_radius_too_small');
    eq(v2r.ok, true, 'v2 路径下同一站必须放行：');
    eq(v2r.station.center, { x: 181, z: 357 });
    // 再单独钉 center 粗化这一半（radius 放宽后仍不能被对齐）
    const raw2 = { ...raw, station: { ...raw.station, radius: 24 } };
    eq(L.projectStation(raw2).station.center, { x: 184, z: 360 }, 'v1 路径仍对齐 8 格：');
    eq(L.projectStation(raw2, { v2: true }).station.center, { x: 181, z: 357 }, 'v2 路径不对齐：');
});
t('exact 逐字返回：不裁字段、不补默认、键序不变、不重排 targets', () => {
    const { file, doc } = writeV2(EV);
    const r = L.loadRoute(file, { allowDraft: true });
    const a = r.station('A');
    eq(JSON.stringify(a.exact), JSON.stringify(doc.stations[0].exact), 'exact 必须与文件里逐字一致：');
    eq(Object.keys(a.exact).sort(), ['hazards', 'stand', 'targets', 'verify'], 'exact 顶层键：');
    eq(a.exact.targets[0], doc.stations[0].exact.targets[0], 'target 对象逐字一致（含 order/how）：');
    const b = r.station('B');
    eq(Object.keys(b.exact).sort(), ['stand', 'verify'], 'B 没写 targets/hazards ⇒ 保持缺省，不补 []：');
    eq(Object.keys(b.exact).includes('targets'), false);
    eq(Object.keys(b.exact).includes('hazards'), false);
});
t('v2 里没有 exact 的站仍走 v1 兜底粗化（DECISION-02 §3：粗化留着作兜底）', () => {
    const { file } = writeV2(EV);
    const c = L.loadRoute(file, { allowDraft: true }).station('C');
    eq(c.center, { x: 8, z: 8 }, 'center 9,9 → 9/8=1.125 四舍五入到 1 格 ×8 = 8：');
    eq(Object.keys(c).includes('exact'), false, '没有 exact 就不会有 exact 键（字段不存在 ≠ 空对象）：');
});
t('legs 按文件顺序返回；legsBetween 找得到、对方向敏感、未知 pair 返 null', () => {
    const { file, doc } = writeV2(EV);
    const r = L.loadRoute(file, { allowDraft: true });
    eq(r.legs.map((l) => `${l.from}->${l.to}`), ['A->B', 'B->C'], 'legs 顺序必须等于文件顺序（走法顺序）：');
    eq(r.legs[0].waypoints, doc.legs[0].waypoints, 'waypoints 逐字返回：');
    eq(r.legs[0].notes, '穿草地', 'notes 保留：');
    eq(r.legs[1].notes, '', '没写 notes ⇒ 空串（腿级自由文本，不参与坐标校验）：');
    eq(r.legsBetween('A', 'B').from, 'A', 'legsBetween(A,B) 应命中：');
    eq(r.legsBetween('B', 'A'), null, '腿有方向，反向查不到（返 null，不抛错）：');
    eq(r.legsBetween('A', 'Z'), null, '未知 pair 返 null：');
    eq(r.legsBetween('C', 'A'), null, '首站没有入腿，返 null：');
});
t('legs 端点未知 ⇒ 整份拒绝（不静默吞掉一段，DECISION-02 §1 整链优先）', () => {
    throwsCode(() => L.loadRoute(writeV2(EV, (d) => { d.legs[0].to = 'NOPE'; }).file, { allowDraft: true }), 'leg_endpoint_unknown');
});
t('相邻路点正好 32 格放行，33 格拒绝（§5 的 ≤32 边界）', () => {
    const okR = L.loadRoute(writeV2(EV, (d) => {
        d.legs[0].waypoints = [[0, 64, 0], [32, 64, 0]];
    }).file, { allowDraft: true });
    eq(okR.legsBetween('A', 'B').waypoints.length, 2, '正好 32 格必须放行：');
    throwsCode(() => L.loadRoute(writeV2(EV, (d) => {
        d.legs[0].waypoints = [[0, 64, 0], [33, 64, 0]];
    }).file, { allowDraft: true }), 'leg_waypoint_too_far');
    // 3D 欧氏（§5 没说只量水平）：Δ=(28,16,0) ⇒ √1040 ≈ 32.25 > 32
    throwsCode(() => L.loadRoute(writeV2(EV, (d) => {
        d.legs[0].waypoints = [[0, 64, 0], [28, 80, 0]];
    }).file, { allowDraft: true }), 'leg_waypoint_too_far');
    // Δ=(28,4,0) ⇒ √800 ≈ 28.28，放行（证明上面那条不是"y 一变就拒"）
    const y4 = L.loadRoute(writeV2(EV, (d) => {
        d.legs[0].waypoints = [[0, 64, 0], [28, 68, 0]];
    }).file, { allowDraft: true });
    eq(y4.legsBetween('A', 'B').waypoints.length, 2, 'y 参与度量但没超 32 就该放行：');
});
t('waypoints 形态错 ⇒ 独立码（leg_waypoint_*，不与 exact 的码混）', () => {
    throwsCode(() => L.loadRoute(writeV2(EV, (d) => { d.legs[0].waypoints = [[0, 64, 0], [10, 64]]; }).file, { allowDraft: true }), 'leg_waypoint_coord_arity');
    throwsCode(() => L.loadRoute(writeV2(EV, (d) => { d.legs[0].waypoints = [[0, 64, 0], [10.5, 64, 0]]; }).file, { allowDraft: true }), 'leg_waypoint_coord_value');
    throwsCode(() => L.loadRoute(writeV2(EV, (d) => { d.legs[0].waypoints = [[0, 64, 0]]; }).file, { allowDraft: true }), 'leg_waypoints_too_few');
    // 缺 waypoints 的腿（维度跳转腿）合法
    const r = L.loadRoute(writeV2(EV, (d) => { delete d.legs[1].waypoints; }).file, { allowDraft: true });
    eq(r.legsBetween('B', 'C').waypoints, [], '没有 waypoints ⇒ 空数组，不是错误：');
    // 顶层 legs 字段不存在 ⇒ 空表（退回站级导航）；存在但不是数组 ⇒ 拒（区分"没有"与"坏了"）
    const r2 = L.loadRoute(writeV2(EV, (d) => { delete d.legs; }).file, { allowDraft: true });
    eq(r2.legs, [], 'legs 字段不存在 ⇒ 空表：');
    throwsCode(() => L.loadRoute(writeV2(EV, (d) => { d.legs = 'A->B'; }).file, { allowDraft: true }), 'legs_not_array');
});

// 6.1 exact 写错：每种错一个**独立**的机器码，且不得抛出未捕获异常（手册 §9.2）
console.log('\n### 6.1 exact 校验：形态/值/证据三类错各一个独立码');
const EXACT_BAD = [
    ['exact 不是对象', 'exact_not_object', (s) => { s.exact = []; }],
    ['stand 缺失', 'exact_no_stand', (s) => { delete s.exact.stand; }],
    ['stand 为空数组', 'exact_no_stand', (s) => { s.exact.stand = []; }],
    ['stand 坐标非整数（64.5）', 'exact_coord_value', (s) => { s.exact.stand = [[181, 64.5, 357]]; }],
    ['stand 坐标 arity 错（只有 x,z）', 'exact_coord_arity', (s) => { s.exact.stand = [[181, 357]]; }],
    ['targets[].xyz arity 错（写成对象）', 'exact_coord_arity', (s) => { s.exact.targets[0].xyz = { x: 1, y: 2, z: 3 }; }],
    ['targets[].xyz 坐标非整数（字符串）', 'exact_coord_value', (s) => { s.exact.targets[0].xyz = ['181', '64', '349']; }],
    ['hazards 不是数组', 'exact_bad_hazards', (s) => { s.exact.hazards = 'lava'; }],
    ['hazards 坐标 arity 错', 'exact_coord_arity', (s) => { s.exact.hazards = [[1, 2]]; }],
    ['targets[0] 缺 what', 'exact_bad_targets', (s) => { delete s.exact.targets[0].what; }],
    ['verify 整块缺失（忘了写核验）', 'exact_no_verify', (s) => { delete s.exact.verify; }],
    ['verify.evidence 为空串', 'exact_no_evidence', (s) => { s.exact.verify.evidence = '   '; }],
    ['verify.evidence 缺失', 'exact_no_evidence', (s) => { delete s.exact.verify.evidence; }],
];
for (const [label, code, mutateStation] of EXACT_BAD) {
    t(`exact 写错：${label} ⇒ ${code}`, () => {
        const { file } = writeV2(EV, (d) => mutateStation(d.stations[0]));
        const r = L.loadRoute(file, { allowDraft: true });   // 不抛未捕获异常 = 逐站拒，不是整份崩
        eq(r.stationIds().includes('A'), false, 'A 必须被拒：');
        eq(r.rejected.map((x) => x.code), [code], '被拒原因码：');
        eq(r.stationIds().sort(), ['B', 'C'], '只拒这一站，其余站照常加载：');
        throwsCode(() => r.station('A'), code);              // 下游按 code 决定走不走 fallback
    });
}
t('上面 13 个 exact 错误用例落在 8 个互不相同的码上（缺字段 vs 字段在但坏必须分得开）', () => {
    const codes = EXACT_BAD.map(([, c]) => c);
    // 13 个用例里有几组是**同一条规则的两种写法**（stand 缺失 vs stand=[]），它们理应同码；
    //   不同规则之间必须不同码，否则改了哪条判据在统计里根本看不出来（手册 §9.2）。
    eq([...new Set(codes)].sort(), [
        'exact_bad_hazards', 'exact_bad_targets', 'exact_coord_arity', 'exact_coord_value',
        'exact_no_evidence', 'exact_no_stand', 'exact_no_verify', 'exact_not_object',
    ], 'exact 错误码集合：');
    // 显式点名"缺失"与"存在但坏"的配对（§9.2 的要求，逐字写出来防以后被合并）
    ok(codes.includes('exact_no_verify') && codes.includes('exact_no_evidence'), 'verify 缺失 vs evidence 空：两码');
    ok(codes.includes('exact_coord_arity') && codes.includes('exact_coord_value'), 'arity 错 vs 值错：两码');
});
t('v2 草稿在正式局（allowDraft 默认 false）仍被拒绝 route_is_draft', () => {
    const { file } = writeV2(EV);
    const ev = [];
    throwsCode(() => L.loadRoute(file, { telemetry: (e) => ev.push(e) }), 'route_is_draft');
    ok(ev.includes('route_is_draft'), '应记 route_is_draft 遥测');
});
t('v2 冻结版：哈希对得上能加载（含 exact/legs），改 legs 一个字节 ⇒ route_hash_mismatch', () => {
    // 证明 v2 与 v1 走**同一个**冻结闸门（§4 v1.1 口径一字未动）
    const d = path.join(tmp, 'frozen-v2'); fs.mkdirSync(d, { recursive: true });
    const doc = v2Doc(); doc.frozenAt = '2026-10-03T00:00:00Z';
    const file = path.join(d, `${doc.seed}.json`);
    fs.writeFileSync(file, JSON.stringify(doc, null, 2));
    const hex = L.computeCanonicalSha256(doc);
    fs.writeFileSync(path.join(d, `${doc.seed}.sha256`), `${hex}\n`);
    const r = L.loadRoute(file);
    eq(r.frozen, true, 'v2 冻结版应能加载：');
    eq(r.sha256, hex);
    eq(r.legs.length, 2);
    eq(r.station('A').exact.stand.length, 2, '冻结版的 exact 照样返回：');
    // 改 legs 里的一个路点（整份文件变了 ⇒ 哈希变 ⇒ 拒）
    const tampered = JSON.parse(fs.readFileSync(file, 'utf8'));
    tampered.legs[0].waypoints[1][0] += 1;
    fs.writeFileSync(file, JSON.stringify(tampered, null, 2));
    throwsCode(() => L.loadRoute(file), 'route_hash_mismatch');
});
t('v2 加了 exact/legs 之后，哈希口径仍是 §4 v1.1（与 route_guard 逐字相同）', () => {
    // 拿**真实的**主种子当底稿（只读），在内存里升到 v2 加 exact/legs：
    //   loader 与 route_guard 必须给出同一个 sha256，且 v2 载荷确实参与哈希。
    const doc = JSON.parse(realRaw);
    doc.schema = 'aidqq-route/2';
    doc.legs = [{ from: 'S0_iron', to: 'S1_portal', dim: 'overworld', waypoints: [[10, 64, 20], [40, 64, 20]], notes: '走大路' }];
    doc.stations[0].exact = { stand: [[12, 64, 20]], verify: { status: 'REAL', evidence: EV } };
    const text = JSON.stringify(doc, null, 2) + '\n';
    const lh = L.computeCanonicalSha256(text), gh = G.routeSha256(text);
    eq(lh, gh, 'v2 文档：loader vs route_guard：');
    ok(lh !== guardSeed, '加了 legs/exact 后哈希必须变（说明它们确实在整文件里）：');
    // 只读证明：真实文件一个字节都没动
    eq(G.sha256Of(fs.readFileSync(REAL, 'utf8')), G.sha256Of(realRaw), '真实主种子文件内容未变（只读）：');
});
t('v2 里 scout 仍然被丢弃（v2 加 exact ≠ 解锁 scout）', () => {
    const { file } = writeV2(EV);
    const r = L.loadRoute(file, { allowDraft: true });
    const seen = [];
    (function walk(o, p = '$') {
        if (!o || typeof o !== 'object') return;
        for (const k of Object.keys(o)) {
            if (k === 'scout') seen.push(`${p}.${k}`);
            walk(o[k], `${p}.${k}`);
        }
    })(r);
    eq(seen, [], 'v2 返回值里出现 scout：');
    eq(JSON.stringify(r).includes('frame_corner'), false, '预勘坐标不该被带回来：');
    ok(r.station('A').exact.stand.length === 2, '（顺带证明这次检查不是空转：exact 确实在返回值里）');
});
// 6.2 跨仓库形状：bench 侧 route_guard.mjs 也认 v2（它的 checkRouteV2 已在 2026-10-03 落地）。
// ⚠ **这里发现一处两侧口径分歧，本单不擅自裁决**（route_guard.mjs 不在本单授权范围内）：
//   上面那个 fixture 故意让 center 不在 8 格网格上、radius<16（那正是"不再粗化"的可测形态），
//   但 route_guard.readRouteFile 对 **v2 文件仍然套用 §1.3 的文件级判据**（center 必须在 8 格网格上、
//   radius≥16、lookFor 非空），并要求每条腿的两端站都有非空 exact.stand。
//   ⇒ loader 放行的形状 ⊋ guard 放行的形状。下面这条用例只钉**交集**（guard 放行 ⇒ loader 必放行），
//   分歧部分用 console.log 打印出来交给设计会话裁决，**不写成断言**（断言会把别人文件的行为钉死在我单里）。
console.log('\n### 6.2 跨仓库：loader 与 route_guard 的 v2 形状');
t('guard 放行的 v2 文件 loader 必放行（交集方向，跨仓库口径不打架）', () => {
    // 造一份**两边都该放行**的 v2 文件：center 对齐 8 格、radius≥16、lookFor 非空、每条腿两端都有站位
    const { file } = writeV2(EV, (d) => {
        d.stations[0].station.center = [184, 360];
        d.stations[0].station.radius = 24;
        d.stations[1].station.center = [208, 400];
        d.stations[1].station.lookFor = ['lava'];
        d.stations[1].station.radius = 24;
        d.stations[2].station.center = [8, 8];
        d.stations[2].exact = { stand: [[8, 70, 8]], verify: { status: 'REAL', evidence: EV } };
    });
    const res = G.readRouteFile(file);
    eq(res.violations, [], 'route_guard 对这份 v2 文件的判据：');
    eq(res.schema, 'aidqq-route/2');
    const r = L.loadRoute(file, { allowDraft: true });
    eq(r.rejected, [], 'loader 侧无站被拒：');
    eq(r.legs.length, 2, 'legs 照收：');
    eq(r.station('C').exact.stand, [[8, 70, 8]], 'C 的 exact 也返回：');
});
console.log('     ℹ 分歧（未断言，交设计会话裁决）：guard 对"故意不粗化"的那份 fixture 会报');
{
    const { file } = writeV2(EV);
    for (const v of G.readRouteFile(file).violations) console.log(`       - ${v}`);
    console.log('       loader 侧同一份文件：0 violations（本单按 SCHEMA §5 + DECISION-02 §3 放行）');
}


try { fs.rmSync(tmp, { recursive: true, force: true }); } catch { /* 忽略 */ }
console.log(`\n## 结果：${pass} 通过 / ${fail} 失败`);
if (fail) {
    console.log('失败项：');
    for (const f of fails) console.log(`  - ${f.name}: ${f.err}`);
}
process.exit(fail ? 1 : 0);
