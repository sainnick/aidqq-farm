// s1_exact_survey.selftest.mjs — 精确预勘工具的**离线自检**（造合成世界，不碰服务器、不占端口）
//
// 【为什么必须自己造世界】本工具的错误全是**静默**的：几何认错框、排序挑了高台、
//   读不到的格被当空气 —— 任何一条都不会抛异常，只会安静地输出一份"看起来很像对的"坐标。
//   而真存档只有一个种子、几个坐标，穷举不出这些组合。合成世界能。
//   （world reader 那条线的教训：漏了 sec.Y 偏移，整块 chunk 读成同一个方块，自检却全绿。）
//
// 覆盖：
//   T1 合法 4×5 环 + 2 缺格：分类 / 站位 / 补格顺序 / SCHEMA §5 形状
//   T2 **不是**合法环：4×6（残差检查）、含基岩、全空、已点燃 ⇒ 一律大声失败且不产出坐标
//   T3 oracle 返 null：进 unreadable、按不安全处理，且**与"当成空气"的结果不同**（r18 §5 / HANDOVER 2026-10-03）
//   T4 r18 §1.3 回归：水平更近但高 6 格的高台**不得排第一**
//   T5 唯一站位脚下是岩浆：被排除，且排除原因**报出来**
//   T6 岩浆筑墙：有缺口就绕、没缺口就 ok:false，**绝不给穿岩浆的链**
//   T7 端到端：造真 .mca 跑 cli()，退出码 0 + 落盘回读；非法几何退出码 3 且**不写文件**
//   T8 参数与默认盒：默认盒必须复现任务层给的 x183..192/y36..46/z303..313
//
// 用法：& 'D:\AI斗蛐蛐\.runtime\node-v20.20.2-win-x64\node.exe' s1_exact_survey.selftest.mjs

import fs from 'fs';
import os from 'os';
import path from 'path';
import zlib from 'zlib';
import { fileURLToPath } from 'url';
import { writeNbt, packBits, bitsForPalette } from '../../route/tools/region_reader.mjs';
import {
    makeOracle, readCell, normalizeName, classifyRingCell, lavaKind, isHazardName, isFullSolid,
    makeBox, boxFromHint, boxLabel, boxSize, scanBox, rectCells, findFrameCandidates, resolveFrame,
    standOk, reachMetrics, deriveStands, digCells, patchOrder, hazardsInBox, hazardsNearStands,
    planLeg, runSurvey, formatReport, parseArgs, cli, EXIT, DEFAULTS, CLS, STAND_SORT_RULE, PATCH_SORT_RULE,
} from './s1_exact_survey.mjs';

let pass = 0, fail = 0;
const j = (v) => JSON.stringify(v);
const A = (n, c, x = '') => { if (c) { pass++; console.log(`  ✔ ${n}`); } else { fail++; console.log(`  ✘ ${n}${x ? ` — ${x}` : ''}`); } };
const eq = (n, got, want) => A(n, j(got) === j(want), `got=${j(got)} want=${j(want)}`);
const ok = (n, c, x = '') => A(n, !!c, x);
const K = (c) => `${c[0]},${c[1]},${c[2]}`;

// ---------------------------------------------------------------- 合成世界（oracle 侧）
/**
 * 造 oracle。`cells` 是 Map："x,y,z" → 方块名（字符串）或 `{name, props}` 或 `null`（**读不到**）。
 * 未列出的格一律 air。返回 makeOracle 的产物，逻辑里不出现 World。
 */
function worldFrom(cells) {
    const raw = (x, y, z) => (cells.has(K([x, y, z])) ? cells.get(K([x, y, z])) : 'air');
    const name = (v) => (v === null || v === undefined ? null : (typeof v === 'string' ? v : v.name));
    return makeOracle((x, y, z) => name(raw(x, y, z)), (x, y, z) => {
        const v = raw(x, y, z);
        if (v === null || v === undefined) return null;
        return typeof v === 'string' ? { name: v, props: null } : { name: v.name, props: v.props ?? null };
    });
}
const setAll = (m, xs, ys, zs, v) => { for (const x of xs) for (const y of ys) for (const z of zs) m.set(`${x},${y},${z}`, v); };
const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);

/**
 * T1/T3/T4/T5 共用的底座：门框在 z=100 面上，x 10..13、y 40..44；地面 y=39；西侧 y=41 的架子上能站。
 * 1.16.1 的门框：外框 4 宽 × 5 高、开口 2×3、环 14 格。
 */
function baseRing(mutate) {
    const m = new Map();
    setAll(m, range(4, 20), [39], range(96, 104), 'stone');       // 地面（脚下 y=40 能站）
    setAll(m, range(4, 9), [41], range(96, 104), 'stone');        // 架子（脚下 y=42 能站）
    for (let j = 0; j < 5; j++) for (let i = 0; i < 4; i++) {
        const on = j === 0 || j === 4 || i === 0 || i === 3;
        if (on) m.set(`${10 + i},${40 + j},100`, 'obsidian');     // 环 14 格
    }
    m.set('11,41,100', { name: 'lava', props: { level: 0 } });    // 内部 2×3：源块岩浆
    if (mutate) mutate(m);
    return m;
}

const SURVEY_BOX = boxFromHint(10, 40, 100);   // 提示点取框原点 ⇒ 盒 x6..15/y37..47/z96..106

// ================================================================ T1
console.log('T1 合法 4×5 环（2 缺格 + 1 待挖 + 1 哭泣黑曜石）');
{
    const m = baseRing((mm) => {
        mm.set('13,42,100', 'air');          // needs_fill
        mm.set('12,44,100', 'air');          // needs_fill
        mm.set('10,41,100', 'crying_obsidian');
        mm.set('13,43,100', 'stone');        // needs_dig
        mm.set('14,42,100', 'short_grass'); // 框外一株草：压低 (13,42,100) 的 openFaces，让补格顺序真的由"外侧面"决定。
                                           // ⚠ 特意用**非实心**的方块：实心块会自己长出一个更好的站位（站得比架子还平），
                                           //   那就把这条用例的意图（补格顺序）改写掉了 —— 合成世界的坑与真世界一样在这。
    });
    const o = worldFrom(m);
    const r = runSurvey(o, { world: '<synthetic>', box: SURVEY_BOX, frameX: 10, frameY0: 40, frameZ0: 100 });

    ok('几何判为合法环', r.ok, r.why);
    eq('框面 = z 恒定', r.geom.plane, 'z_const');
    eq('框原点', r.geom.origin, [10, 40, 100]);
    eq('环分类计数', r.geom.counts, {
        obsidian: 10, crying_obsidian: 1, needs_dig: 1, needs_fill: 2, other: 0, unreadable: 0, ringTotal: 14, interiorTotal: 6,
    });
    eq('内部 6 格全是已知', r.geom.interior.every((c) => c.known), true);
    eq('岩浆源块按 level=0 认出', r.geom.interior.find((c) => K(c.xyz) === '11,41,100').kind, 'lava_source');
    eq('内部空气格', r.geom.interior.filter((c) => c.kind === 'air').length, 5);

    // ---- 站位：只有架子那一排够得着（地面脚格 y=40 到 y=44 的目标 rise=4 > maxRise=2）
    const st = r.stands;
    eq('合法站位数（架子上 y=42、x=9、z 97..103）', st.length, 7);
    // ★ 第一站位是 (9,42,97) 而不是"正对框"的 (9,42,100)：内部那个岩浆源 (11,41,100) 离 (9,42,100)
    //   正好 2 格 ⇒ 通道 B 的 hazardsNear=1 把它压后；z=97/103 是 3 格（干净），两者其余键全并列，
    //   最后由 `[x,y,z]↑` 显式打破（z=97 在前）。这正是"并列必须显式打破"落地后的样子。
    eq('第一站位（hazardsNear=0 优先，并列由 [x,y,z] 显式打破）', st[0].xyz, [9, 42, 97]);
    eq('第一站位 2 格内无危险', st[0].hazardsNear, 0);
    eq('第二站位（同样干净，z=103 与 z=97 并列后按 z 升序）', st[1].xyz, [9, 42, 103]);
    ok('正对框的 (9,42,100) 在表里但排在干净站位之后', st.findIndex((s) => K(s.xyz) === '9,42,100') > 1,
        j(st.map((s) => `${K(s.xyz)}/near=${s.hazardsNear}`)));
    eq('贴着岩浆源的那个站位 hazardsNear=1', st.find((s) => K(s.xyz) === '9,42,100').hazardsNear, 1);
    eq('第一站位的 3-D 上升量', st[0].rise, 2);
    eq('第一站位同时报水平距离', st[0].reachH, 4);
    eq('第一站位同时报三维距离', st[0].reach3, 4);
    ok('地面站位（rise 4 > 2）被排除且报出来', r.slice.stations[0].exact.standExcludedReasons.target_out_of_reach >= 9,
        j(r.slice.stations[0].exact.standExcludedReasons));
    ok('排序规则写进输出', r.slice.stations[0].exact.standSortRule === STAND_SORT_RULE);

    // ---- 挖格
    const digs = r.slice.stations[0].exact.targets.filter((t) => t.what === 'dig');
    eq('待挖格 1 个', digs.length, 1);
    eq('待挖格坐标 + 当前方块名 + 工具', [digs[0].xyz, digs[0].block, digs[0].tool], [[13, 43, 100], 'stone', 'iron_pickaxe']);

    // ---- 补格顺序：riskAdjacent 并列（都 0）→ openFaces 降序 ⇒ 框外面多的先做
    const fills = r.slice.stations[0].exact.targets.filter((t) => t.what === 'fill_cell');
    eq('待补格 2 个', fills.length, 2);
    eq('补格顺序（显式 order 1..N）', fills.map((f) => [f.order, f.xyz]), [[1, [12, 44, 100]], [2, [13, 42, 100]]]);
    eq('openFaces 打平了并列（3 > 2）', fills.map((f) => f.openFaces), [3, 2]);
    eq('riskAdjacent 都是 0', fills.map((f) => f.riskAdjacent), [0, 0]);
    eq('how 字段按 SCHEMA §5 写 two_bucket', fills.every((f) => f.how === 'two_bucket'), true);
    ok('补格规则写进输出', r.slice.stations[0].exact.patchOrderRule === PATCH_SORT_RULE);

    // ---- SCHEMA §5 形状
    const s = r.slice;
    eq('schema = aidqq-route/2', s.schema, 'aidqq-route/2');
    eq('stand 是坐标数组', s.stations[0].exact.stand[0], [9, 42, 97]);
    ok('hazards 是坐标数组', s.stations[0].exact.hazards.every((h) => Array.isArray(h) && h.length === 3));
    ok('verify.status = OFFLINE', s.stations[0].exact.verify.status === 'OFFLINE' && s.stations[0].exact.verify.evidence.includes('盒'));
    ok('顶层有 legs', Array.isArray(s.legs) && s.legs.length === 1);
    ok('人读摘要可生成', formatReport(r).includes('站位排序规则'));
}

// ================================================================ T2
console.log('\nT2 不是合法环 ⇒ 大声失败、不产出任何坐标');
{
    // 2a 4×6 全黑曜石：能切出两个"14 格全中"的 4×5，只有残差检查能把它们分开
    const m6 = new Map();
    setAll(m6, range(4, 20), [39], range(96, 104), 'stone');
    setAll(m6, range(10, 13), range(40, 45), [100], 'obsidian');
    const r6 = runSurvey(worldFrom(m6), { box: SURVEY_BOX });
    eq('4×6 被残差检查拒掉', [r6.ok, r6.why], [false, 'ring_not_4x5_residual']);
    eq('残差格里数 ≥ 2', r6.geometry.residual.length >= 2, true);

    // 2b 环里一块基岩：不是缺格，是这个门框修不了
    const rBed = runSurvey(worldFrom(baseRing((m) => m.set('13,42,100', 'bedrock'))), { box: SURVEY_BOX });
    eq('基岩格 → 不可破坏', [rBed.ok, rBed.why], [false, 'ring_has_unbreakable']);
    eq('指出是哪一格', rBed.geometry.cells, [{ xyz: [13, 42, 100], block: 'bedrock' }]);

    // 2c 已经点燃
    const rLit = runSurvey(worldFrom(baseRing((m) => m.set('13,42,100', 'portal'))), { box: SURVEY_BOX });
    eq('已点燃单独归因', [rLit.ok, rLit.why], [false, 'ring_already_lit']);

    // 2d 整盒都是空气：一个洞不是门框
    const rAir = runSurvey(worldFrom(new Map()), { box: SURVEY_BOX });
    eq('全空气洞 → 框料不足', [rAir.ok, rAir.why], [false, 'too_little_frame_material']);

    for (const [n, r] of [['4×6', r6], ['基岩', rBed], ['已点燃', rLit], ['全空气', rAir]]) {
        ok(`${n}：输出里没有任何坐标`, r.slice === undefined && r.stand === undefined);
        ok(`${n}：摘要里写明 why 且喊"不产出坐标"`, formatReport(r).includes('不产出任何坐标'));
    }
    eq('非法几何的 boxTotal 读不到统计存在', typeof r6.unreadable.boxTotal, 'number');
}

// ================================================================ T3
console.log('\nT3 oracle 返 null：进 unreadable、按不安全处理，且与"当成空气"结果不同');
{
    // 3a 站位的脚格读不到 ⇒ 排除，且原因分支是 below_unreadable（**不是**当空气）
    const mNull = baseRing((m) => { m.set('13,42,100', 'air'); m.set('12,44,100', 'air'); m.set('10,41,100', 'crying_obsidian'); m.set('13,43,100', 'stone'); for (const z of range(97, 103)) m.set(`9,41,${z}`, null); });
    const rN = runSurvey(worldFrom(mNull), { box: SURVEY_BOX });
    ok('几何仍然合法（读不到的是架子、不是框）', rN.ok, rN.why);
    eq('站位全被排除', rN.stands.length, 0);
    eq('排除原因 = below_unreadable', rN.slice.stations[0].exact.standExcludedReasons.below_unreadable, 7);
    eq('读不到的格进 unreadable 而不是当成空气', rN.slice.stations[0].exact.unreadable.boxTotal, 7);
    ok('unreadable 里点名了具体的格', rN.slice.stations[0].exact.unreadable.box.some((c) => K(c) === '9,41,100'));
    eq('没有站位 ⇒ leg 显式 ok:false（不凑一条链）', [rN.leg.ok, rN.leg.why], [false, 'no_legal_stand']);
    ok('摘要出现 ⚠⚠ 警告', rN.warnings.some((w) => w.includes('⚠⚠')));

    // 3a' **同样那一格当成空气** ⇒ 排除原因必须落到另一个分支（证明 unknown ≠ air）
    //  ⚠ 直接用 deriveStands 并把排除表上限调大：slice 里的 standExcluded 只留前 24 条（防 JSON 膨胀），
    //    而站位盒是 10×11×7=770 格，按枚举顺序那一格排在很后面。
    const mkTargets = (mm) => {
        const o = worldFrom(mm), g = resolveFrame(o.get, SURVEY_BOX, {});
        return [
            ...g.ring.filter((r) => r.cls === CLS.FILL).map((r) => ({ what: 'fill', xyz: r.xyz })),
            ...g.ring.filter((r) => r.cls === CLS.DIG).map((r) => ({ what: 'dig', xyz: r.xyz })),
        ];
    };
    const pick = (mm) => {
        const o = worldFrom(mm);
        const g = resolveFrame(o.get, SURVEY_BOX, {});
        const d = deriveStands(o.get, g, mkTargets(mm), { standCap: 1e6 });
        return { d, e: d.excluded.find((x) => K(x.xyz) === '9,42,100') };
    };
    const mAir = new Map(mNull);
    for (const z of range(97, 103)) mAir.set(`9,41,${z}`, 'air');
    const pN = pick(mNull), pA = pick(mAir);
    eq('null 时该站位被 below_unreadable 排除', [pN.e.xyz, pN.e.why], [[9, 42, 100], 'below_unreadable']);
    eq('当空气时同一格被 below_not_full_solid 排除', [pA.e.xyz, pA.e.why], [[9, 42, 100], 'below_not_full_solid']);
    ok('两个世界的排除原因不同（unknown 没被折叠成 air）', pN.e.why !== pA.e.why);
    eq('null 世界 0 个合法站位', pN.d.stands.length, 0);
    eq('当空气时站位表仍然是空的（脚下没东西本来就不能站）', pA.d.stands.length, 0);
    const rAir2 = runSurvey(worldFrom(mAir), { box: SURVEY_BOX });
    ok('当空气时 reasons 里根本没有 below_unreadable', !('below_unreadable' in rAir2.slice.stations[0].exact.standExcludedReasons),
        j(rAir2.slice.stations[0].exact.standExcludedReasons));
    eq('当空气时 unreadable 归零', rAir2.slice.stations[0].exact.unreadable.boxTotal, 0);

    // 3b standOk 的每一条分支都单独钉住（"读不到"与"不是空气/不是实心"必须落到不同分支）
    const so = (cells) => worldFrom(cells).get;
    const ledge = (over) => worldFrom(new Map([['9,41,100', 'stone'], ['9,42,100', 'air'], ['9,43,100', 'air'], ...Object.entries(over)])).get;
    eq('脚格 null → feet_unreadable', standOk(ledge({ '9,42,100': null }), 9, 42, 100).why, 'feet_unreadable');
    eq('脚格实心 → feet_not_air', standOk(ledge({ '9,42,100': 'stone' }), 9, 42, 100).why, 'feet_not_air');
    eq('脚格岩浆 → feet_is_hazard（不是笼统的 feet_not_air）', standOk(ledge({ '9,42,100': 'lava' }), 9, 42, 100).why, 'feet_is_hazard');
    eq('头格 null → head_unreadable', standOk(ledge({ '9,43,100': null }), 9, 42, 100).why, 'head_unreadable');
    eq('头格实心 → head_not_air', standOk(ledge({ '9,43,100': 'stone' }), 9, 42, 100).why, 'head_not_air');
    eq('头格岩浆块 → head_is_hazard', standOk(ledge({ '9,43,100': 'magma_block' }), 9, 42, 100).why, 'head_is_hazard');
    eq('脚下 null → below_unreadable', standOk(ledge({ '9,41,100': null }), 9, 42, 100).why, 'below_unreadable');
    eq('脚下岩浆 → below_is_hazard', standOk(ledge({ '9,41,100': 'lava' }), 9, 42, 100).why, 'below_is_hazard');
    eq('脚下岩浆块 → below_is_hazard', standOk(ledge({ '9,41,100': 'magma_block' }), 9, 42, 100).why, 'below_is_hazard');
    eq('脚下水 → below_not_full_solid（危险与不实心是两个分支）', standOk(ledge({ '9,41,100': 'water' }), 9, 42, 100).why, 'below_not_full_solid');
    eq('脚下草 → below_not_full_solid', standOk(ledge({ '9,41,100': 'short_grass' }), 9, 42, 100).why, 'below_not_full_solid');
    eq('全部合规 → ok', standOk(ledge({}), 9, 42, 100), { ok: true, why: null });
    void so;

    // 3c 环上某格读不到 ⇒ **几何直接判不定**（绝不能悄悄当成"又缺一格"）
    const rRing = runSurvey(worldFrom(baseRing((m) => { m.set('13,42,100', null); m.set('12,44,100', 'air'); m.set('10,41,100', 'crying_obsidian'); m.set('13,43,100', 'stone'); })), { box: SURVEY_BOX });
    eq('环上读不到 → 大声失败', [rRing.ok, rRing.why], [false, 'ring_cells_unreadable']);
    eq('点名那一格', rRing.geometry.cells, [[13, 42, 100]]);

    // 3d 补格排序里，读不到的邻格按"挨着岩浆"处理（排后面）
    const mU = baseRing((m) => {
        m.set('13,42,100', 'air'); m.set('12,44,100', 'air'); m.set('10,41,100', 'crying_obsidian'); m.set('13,43,100', 'stone');
        m.set('12,42,100', null);          // 内部格读不到；它是 (13,42,100) 的一个邻格
    });
    const po = patchOrder(worldFrom(mU).get, resolveFrame(worldFrom(mU).get, SURVEY_BOX, {}), null);
    eq('两个待补格', po.length, 2);
    const first = po.find((p) => K(p.xyz) === '12,44,100'), second = po.find((p) => K(p.xyz) === '13,42,100');
    ok('读不到邻格的那格 riskAdjacent+1', second.riskAdjacent === first.riskAdjacent + 1, `${first?.riskAdjacent} vs ${second?.riskAdjacent}`);
    eq('⇒ 顺序也把它排到后面', po.map((p) => K(p.xyz)), ['12,44,100', '13,42,100']);
}

// ================================================================ T4
console.log('\nT4 r18 §1.3 回归：水平更近、垂直高 6 格的高台不得排第一');
{
    // 目标里含**框底行** (13,40,100)，于是"框顶上"的平台 rise=6 —— 就是 r18 表里那一行
    const mk = (mut) => { const m = baseRing((mm) => {
        mm.set('13,40,100', 'air'); mm.set('12,44,100', 'air'); mm.set('10,41,100', 'crying_obsidian'); mm.set('13,43,100', 'stone');
        if (mut) mut(mm);
    }); return m; };
    const box = boxFromHint(10, 40, 100);

    // 4a 真实预算（maxRise=2）⇒ 高台连候选都不是
    const rD = runSurvey(worldFrom(mk((m) => { for (let z = 97; z <= 103; z++) m.set(`13,45,${z}`, 'stone'); })), { box });
    ok('默认预算下跑完', rD.ok, rD.why);
    const high = rD.stands.find((s) => K(s.xyz) === '13,46,100');
    ok('rise=6 的高台**不在**站位表里（预算直接拒掉）', !high);
    eq('它被记为够不到（不是静默消失）', rD.slice.stations[0].exact.standExcludedReasons.target_out_of_reach > 0, true);
    eq('正确站位排第一', rD.stands[0].xyz, [9, 42, 97]);
    eq('正确站位 rise=2', rD.stands[0].rise, 2);

    // 4b 把预算放宽（maxRise=8）⇒ 高台**合法**了，但排序仍然不选它 —— 这一条才是 §1.3 的本体
    const o2 = worldFrom(mk((m) => { for (let z = 97; z <= 103; z++) m.set(`13,45,${z}`, 'stone'); }));
    const geom = resolveFrame(o2.get, box, {});
    const tgt = [
        ...geom.ring.filter((r) => r.cls === CLS.FILL).map((r) => ({ what: 'fill', xyz: r.xyz })),
        ...geom.ring.filter((r) => r.cls === CLS.DIG).map((r) => ({ what: 'dig', xyz: r.xyz })),
    ];
    const d = deriveStands(o2.get, geom, tgt, { maxRise: 8 });
    const iHigh = d.stands.findIndex((s) => K(s.xyz) === '13,46,100');
    const iGood = d.stands.findIndex((s) => K(s.xyz) === '9,42,100');
    ok('放宽预算后高台是合法站位', iHigh >= 0, j(d.stands.map((s) => K(s.xyz))));
    ok('但它排在正确站位**后面**', iHigh > iGood, `high=${iHigh} good=${iGood}`);
    const hs = d.stands[iHigh], gs = d.stands[iGood];
    eq('高台的 3-D 上升量', hs.rise, 6);
    eq('高台的 riseUp（站位在目标之上 ⇒ 负数；最高目标是 y=44）', hs.riseUp, -2);
    ok('★ 高台的**水平**距离更小（这正是 r18 排错的那一列）', hs.reachH < gs.reachH, `high.reachH=${hs.reachH} good.reachH=${gs.reachH}`);
    ok('两个维度都报出来了（reachH 水平 / reach3 三维）', typeof hs.reachH === 'number' && typeof hs.reach3 === 'number' && typeof gs.reachH === 'number');
    ok('排序规则把 3-D 上升量放在第 1 键、水平放第 3 键', STAND_SORT_RULE.indexOf('rise(最大|Δy|)↑') < STAND_SORT_RULE.indexOf('reachH'));
    ok('排序规则末位显式打破并列（手册 §5）', /\[x,y,z\]↑.*末位显式打破/.test(STAND_SORT_RULE), STAND_SORT_RULE);

    // 4c 并列站位必须被显式打破，不能"随机"
    const dup = baseRing((m) => { m.set('13,42,100', 'air'); m.set('12,44,100', 'air'); m.set('10,41,100', 'crying_obsidian'); m.set('13,43,100', 'stone'); });
    const r1 = runSurvey(worldFrom(dup), { box }), r2 = runSurvey(worldFrom(dup), { box });
    eq('同一世界跑两次，站位表逐字相同（确定性）', r1.slice.stations[0].exact.stand, r2.slice.stations[0].exact.stand);
    ok('并列站位 ≥ 2 个（说明确实存在并列要打破）', r1.stands.length >= 2);
}

// ================================================================ T5
console.log('\nT5 唯一够得着的站位脚下是岩浆 ⇒ 排除并报出来');
{
    const m = baseRing((mm) => {
        mm.set('13,42,100', 'air'); mm.set('12,44,100', 'air'); mm.set('10,41,100', 'crying_obsidian'); mm.set('13,43,100', 'stone');
        for (let z = 97; z <= 103; z++) mm.set(`9,41,${z}`, { name: 'lava', props: { level: 0 } });   // 架子顶上整排岩浆
    });
    const r = runSurvey(worldFrom(m), { box: SURVEY_BOX });
    ok('几何仍合法', r.ok, r.why);
    eq('0 个合法站位', r.stands.length, 0);
    // 8 = 架子上 7 格（z 97..103） + 框内那格"岩浆源正上方"（11,42,100，脚下就是岩浆）—— 都该拒
    eq('排除原因专门记 below_is_hazard（不是笼统的"不合格"）', r.slice.stations[0].exact.standExcludedReasons.below_is_hazard, 8);
    eq('没有把危险站位混进 stand 列表', r.slice.stations[0].exact.stand, []);
    // slice 里的 standExcluded 只留前 24 条（防 JSON 膨胀），要点名某一格得直接问 deriveStands
    const o5 = worldFrom(m);
    const g5 = resolveFrame(o5.get, SURVEY_BOX, {});
    const t5 = [
        ...g5.ring.filter((x) => x.cls === CLS.FILL).map((x) => ({ what: 'fill', xyz: x.xyz })),
        ...g5.ring.filter((x) => x.cls === CLS.DIG).map((x) => ({ what: 'dig', xyz: x.xyz })),
    ];
    const d5 = deriveStands(o5.get, g5, t5, { standCap: 1e6 });
    eq('被排除的那一格点名报出来', d5.excluded.find((e) => K(e.xyz) === '9,42,100'), { xyz: [9, 42, 100], why: 'below_is_hazard' });
    eq('岩浆源正上方那格也拒（脚格是岩浆）', d5.excluded.find((e) => K(e.xyz) === '11,42,100')?.why, 'below_is_hazard');
    ok('岩浆也进了通道 A 的危险表', r.slice.stations[0].exact.hazards.some((h) => h[0] === 9 && h[1] === 41));
    eq('腿显式 ok:false', [r.leg.ok, r.leg.why], [false, 'no_legal_stand']);
    // 分支独立：脚下是普通非实心 ⇒ 另一个原因
    const g = standOk(worldFrom(new Map([['9,41,100', 'oak_slab'], ['9,42,100', 'air'], ['9,43,100', 'air']])).get, 9, 42, 100);
    eq('半砖按可站处理（作业面常常是半砖）', g.ok, true);
    const g2 = standOk(worldFrom(new Map([['9,41,100', 'short_grass']])).get, 9, 42, 100);
    eq('非实心 ⇒ below_not_full_solid（与 hazard 分开）', g2.why, 'below_not_full_solid');
}

// ================================================================ T6
console.log('\nT6 岩浆筑墙：绕行或显式 ok:false，绝不给穿岩浆的链');
{
    const floor = () => { const m = new Map(); setAll(m, range(0, 30), [59], range(0, 6), 'stone'); return m; };
    const wall = (m, gapZ) => { for (let z = 0; z <= 6; z++) if (z !== gapZ) m.set(`15,60,${z}`, { name: 'lava', props: { level: 0 } }); };
    const entry = [2, 60, 3], stand = [25, 60, 3];

    // 6a 封死的墙
    const mA = floor(); wall(mA, -1);
    const oA = worldFrom(mA);
    const rA = planLeg(oA.get, entry, stand, { maxLeg: 32 });
    eq('封死 ⇒ ok:false', [rA.ok, rA.why], [false, 'no_safe_path']);
    eq('失败时不发任何路点', rA.waypoints, []);
    ok('失败原因说清"走了多少、够不到"', rA.notes.includes('够不到站位'));

    // 6b 留一个缺口 ⇒ 必须绕，且绕行经过缺口
    const mB = floor(); wall(mB, 5);
    const oB = worldFrom(mB);
    const rB = planLeg(oB.get, entry, stand, { maxLeg: 4 });
    ok('有缺口 ⇒ 有安全链', rB.ok, rB.why);
    ok('★ 链里没有任何岩浆格', rB.path.every((p) => !isHazardName(oB.get(p[0], p[1], p[2]))));
    ok('★ 只从缺口那一列过墙', rB.path.some((p) => p[0] === 15 && p[2] === 5) && !rB.path.some((p) => p[0] === 15 && p[2] !== 5));
    ok('★ 确实绕了路（路径格数 > 直线曼哈顿 23）', rB.pathCells > 23, `pathCells=${rB.pathCells}`);
    ok('路点被压缩过（maxLeg=4 ⇒ 多个路点）', rB.waypoints.length >= 3, `waypoints=${rB.waypoints.length}`);
    ok('相邻路点 ≤ maxLeg', rB.waypoints.every((w, i) => i === 0 || Math.max(...[0, 1, 2].map((d) => Math.abs(w[d] - rB.waypoints[i - 1][d]))) <= 4));
    ok('每个路点自身都站得住', rB.waypoints.every((w) => standOk(oB.get, w[0], w[1], w[2]).ok));
    ok('首尾就是 entry 与站位', K(rB.waypoints[0]) === K(entry) && K(rB.waypoints[rB.waypoints.length - 1]) === K(stand));
    ok('notes 里说明了"只并排不经过"', rB.notes.includes('不经过'));

    // 6c 起点站不住 ⇒ 与"走了没到"是**不同的** why（r18 §5：两种失败输出上不能长得一样）
    const rC = planLeg(oB.get, [15, 60, 3], stand, { maxLeg: 32 });
    eq('起点不可走是独立分支', [rC.ok, rC.why], [false, 'entry_not_walkable']);
    const rD = planLeg(oB.get, entry, [15, 60, 0], { maxLeg: 32 });
    eq('终点不可走是独立分支', [rD.ok, rD.why], [false, 'stand_not_walkable']);

    // 6d 导航盒过大 ⇒ 拒绝硬跑，不给"走了一半"的链
    const rE = planLeg(oB.get, entry, stand, { navPad: 400, maxNavCells: 1000 });
    eq('导航盒超限 ⇒ ok:false', [rE.ok, rE.why], [false, 'nav_box_too_big']);
}

// ================================================================ T7 端到端（造真 .mca 跑 cli）
console.log('\nT7 端到端：造真 .mca → cli() → 退出码 + 落盘回读');
{
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 's1survey-'));
    /**
     * 造一个**单 chunk** 的真 .mca（只写 chunk 0,0，x 0..15 / z 0..15）。
     * ⚠ y 段没有 section 条目 ⇒ region_reader 返 'unknown'，这是我们要的能力，不用来造假。
     */
    const writeWorld = (dir, cells, { sectionY = [32, 48] } = {}) => {
        const regionDir = path.join(dir, 'region');
        fs.mkdirSync(regionDir, { recursive: true });
        const names = ['air'];
        for (const v of cells.values()) if (typeof v === 'string' && !names.includes(v)) names.push(v);
        const pid = new Map(names.map((n, i) => [n, i]));
        const Sections = sectionY.sort((a, b) => a - b).map((yBase) => {
            const idx = new Array(4096).fill(0);
            for (let y = 0; y < 16; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
                const v = cells.get(`${x},${yBase + y},${z}`);
                idx[x + z * 16 + y * 256] = typeof v === 'string' ? (pid.get(v) ?? 0) : 0;
            }
            const bits = bitsForPalette(names.length);
            return { Y: yBase / 16, Palette: names.map((n) => ({ Name: `minecraft:${n}` })), BlockStates: packBits(idx, bits, 'packed') };
        });
        const raw = writeNbt({ Level: { xPos: 0, zPos: 0, DataVersion: 2586, Sections } }, { rootName: '', rootType: 10 });
        const comp = zlib.deflateSync(raw);
        const payload = Buffer.alloc(5 + comp.length);
        payload.writeInt32BE(comp.length + 1, 0);   // ⚠ 1.16 的 len 字段**含** type 字节
        payload.writeUInt8(2, 4);
        comp.copy(payload, 5);
        const file = Buffer.alloc(8192 + 4096 + payload.length);
        file[0] = 0; file[1] = 0; file[2] = 2; file[3] = Math.max(1, Math.ceil(payload.length / 4096));
        payload.copy(file, 8192);
        fs.writeFileSync(path.join(regionDir, 'r.0.0.mca'), file);
        return dir;
    };

    // 合法世界：地面 y36/37、架子 y38(x0..3)、柱子 y38/39(x4..7,z4)、门框 y40..44(x4..7,z4)
    const cells = new Map();
    setAll(cells, range(0, 15), [36, 37], range(0, 15), 'stone');
    setAll(cells, range(0, 3), [38], range(0, 6), 'stone');
    setAll(cells, range(4, 7), [38, 39], [4], 'stone');
    for (let j = 0; j < 5; j++) for (let i = 0; i < 4; i++) {
        if (j === 0 || j === 4 || i === 0 || i === 3) cells.set(`${4 + i},${40 + j},4`, 'obsidian');
    }
    cells.set('7,40,4', 'air');        // needs_fill
    cells.set('4,41,4', 'stone');      // needs_dig
    cells.set('7,44,4', 'crying_obsidian');
    cells.set('5,41,4', 'lava');       // 内部
    const wGood = writeWorld(path.join(tmp, 'good'), cells);
    const out = path.join(tmp, 'out.json');
    const code = cli(['--world', wGood, '--out', out, '--frame-x', '4', '--frame-y0', '40', '--frame-z0', '4', '--entry', '8,38,8']);
    eq('合法世界 ⇒ 退出码 0', code, EXIT.OK);
    ok('out 文件落盘', fs.existsSync(out));
    const jf = JSON.parse(fs.readFileSync(out, 'utf8'));
    eq('切片 schema', jf.schema, 'aidqq-route/2');
    eq('第一站位（真实存档解析出来的）', jf.stations[0].exact.stand[0], [3, 39, 4]);
    eq('verify.status', jf.stations[0].exact.verify.status, 'OFFLINE');
    ok('verify.evidence 写明世界目录 + 工具 + 盒', jf.stations[0].exact.verify.evidence.includes('r.0.0') === false
        && jf.stations[0].exact.verify.evidence.includes('s1_exact_survey.mjs')
        && jf.stations[0].exact.verify.evidence.includes('盒'));
    eq('leg 从 entry 到站位成立', [jf.legs[0].ok, jf.legs[0].from, jf.legs[0].to], [true, 'entry', 'S1_portal']);
    ok('路点首尾正确', K(jf.legs[0].waypoints[0]) === '8,38,8' && K(jf.legs[0].waypoints.at(-1)) === '3,39,4');
    eq('目标：1 挖 1 补', jf.stations[0].exact.targets.map((t) => t.what).sort(), ['dig', 'fill_cell']);
    // 写完的落盘自检：2 空格缩进 + 末尾换行（SCHEMA §4 的哈希口径）
    ok('落盘格式符合 SCHEMA §4 哈希口径', fs.readFileSync(out, 'utf8').endsWith('\n') && JSON.stringify(jf, null, 2) + '\n' === fs.readFileSync(out, 'utf8'));

    // 非法世界（整盒空气）⇒ 退出码 3 且**不写** out
    const out2 = path.join(tmp, 'out2.json');
    const wBad = writeWorld(path.join(tmp, 'bad'), new Map());
    const code2 = cli(['--world', wBad, '--out', out2, '--frame-x', '4', '--frame-y0', '40', '--frame-z0', '4', '--entry', '8,38,8']);
    eq('非法几何 ⇒ 退出码 3', code2, EXIT.GEOMETRY_REJECTED);
    ok('非法几何**没有**产出 out 文件', !fs.existsSync(out2));

    // 已有旧文件时不覆盖（防止父 agent 拿到上一轮的结果当本轮）
    fs.writeFileSync(out2, '{"stale":true}\n', 'utf8');
    cli(['--world', wBad, '--out', out2, '--frame-x', '4', '--frame-y0', '40', '--frame-z0', '4']);
    eq('旧文件没被覆盖', JSON.parse(fs.readFileSync(out2, 'utf8')).stale, true);

    fs.rmSync(tmp, { recursive: true, force: true });
}

// ================================================================ T8 参数与默认盒
console.log('\nT8 参数解析、默认盒复现、纯函数口径');
{
    const b = boxFromHint(187, 39, 307);
    eq('默认盒复现任务层给的 x183..192/y36..46/z303..313', boxLabel(b), 'x183..192/y36..46/z303..313');
    ok('盒子比 4×5 的框大一大圈（手册 §5）', boxSize(b) > 20);
    const a = parseArgs(['--world', 'W', '--out', 'O.json', '--entry', '1,2,3', '--max-leg', '16']);
    eq('--entry 解析', a.entry, [1, 2, 3]);
    eq('--max-leg 解析', a.maxLeg, 16);
    eq('缺省值沿用 DEFAULTS', [a.frameX, a.frameY0, a.frameZ0, a.maxHoriz, a.maxRise], [187, 39, 307, 4, 2]);
    eq('缺 --out ⇒ 用法错', cli([]), EXIT.USAGE);
    eq('世界目录不存在 ⇒ 用法错', cli(['--world', path.join(os.tmpdir(), 'no-such-world-xyz'), '--out', path.join(tmp0(), 'x.json')]), EXIT.USAGE);

    // 归一与分类口径
    eq('minecraft: 前缀归一', normalizeName('minecraft:Obsidian'), 'obsidian');
    eq('读不到的几种表示都收成 null', [normalizeName(null), normalizeName('unknown'), normalizeName(''), normalizeName(undefined)], [null, null, null, null]);
    eq('读不到 ⇒ other（**不是** needs_fill）', classifyRingCell(null), CLS.OTHER);
    eq('air ⇒ needs_fill', classifyRingCell('air'), CLS.FILL);
    eq('obsidian / crying 分开', [classifyRingCell('obsidian'), classifyRingCell('crying_obsidian')], [CLS.OBSIDIAN, CLS.CRYING]);
    eq('石头 ⇒ needs_dig', classifyRingCell('stone'), CLS.DIG);
    eq('基岩 ⇒ other', classifyRingCell('bedrock'), CLS.OTHER);
    eq('岩浆只读到名字 ⇒ 如实 lava（不猜源块）', lavaKind('lava', null), 'lava');
    eq('level=0 ⇒ 源块', lavaKind('lava', { level: 0 }), 'lava_source');
    eq('level≠0 ⇒ 流动', lavaKind('lava', { level: 3 }), 'flowing_lava');
    eq('危险判据', [isHazardName('lava'), isHazardName('magma_block'), isHazardName('stone'), isHazardName(null)], [true, true, false, false]);
    eq('实心判据（null 不算实心）', [isFullSolid('stone'), isFullSolid('water'), isFullSolid(null)], [true, false, false]);
    // 环 14 / 内 6 的形状自己也要钉住
    const rc = rectCells([10, 40, 100], 'z');
    eq('4×5 = 20 格 = 环 14 + 内 6', [rc.all.length, rc.ring.length, rc.interior.length], [20, 14, 6]);
    const rcx = rectCells([100, 40, 10], 'x');
    eq('另一朝向的 6 个内格', rcx.interior.map(K).sort(), ['100,41,11', '100,41,12', '100,42,11', '100,42,12', '100,43,11', '100,43,12']);
    // 够得到度量的两个维度都算
    const mm = reachMetrics([9, 42, 100], [{ xyz: [13, 40, 100] }, { xyz: [12, 44, 100] }], {});
    eq('水平 vs 三维分开报', [mm.reachH, mm.rise, mm.riseUp, mm.reach3], [4, 2, 2, 4]);
    eq('刚好在预算内', [mm.ok, mm.broken.length], [true, 0]);
    // 越界时必须**点名是哪几格**（r18 §5：拒了 0 个 vs 没看，长得一模一样）
    const mm2 = reachMetrics([9, 42, 100], [{ xyz: [14, 40, 100] }, { xyz: [12, 44, 100] }], {});
    eq('超水平预算 ⇒ ok:false', mm2.ok, false);
    eq('并且点名越界的那一格与越界值（dy 报的是绝对值）', mm2.broken, [{ xyz: [14, 40, 100], horiz: 5, dy: 2 }]);
    const mm3 = reachMetrics([13, 46, 100], [{ xyz: [13, 40, 100] }], {});
    eq('超垂直预算（r18 那种"水平 0、垂直 6"）⇒ ok:false', [mm3.ok, mm3.reachH, mm3.rise, mm3.riseUp], [false, 0, 6, -6]);
    // 危险两通道分开
    const hz = [{ xyz: [1, 1, 1], name: 'lava' }];
    eq('通道 A 只给坐标', hazardsInBox({ hazards: hz }), [[1, 1, 1]]);
    eq('通道 B 按站位分组', hazardsNearStands(hz, [{ xyz: [2, 2, 2] }, { xyz: [40, 40, 40] }], 2).map((h) => h.n), [1, 0]);
}
function tmp0() { return path.join(os.tmpdir(), 's1survey-usg'); }

// ================================================================ 收尾
console.log(`\n${fail === 0 ? '全部通过' : '有失败'}：${pass}/${pass + fail}`);
process.exitCode = fail === 0 ? 0 : 1;
