// scene.mjs — MC-M1-TASK-08 微基准场景（编排器与 bot 共用同一份坐标定义）
//
// ★ 为什么要单独立这个文件：P8_MICRO3 的失败正是**两份坐标各写一遍、结果不一致**
//   加上「平台把岩浆埋了」造成的。坐标是本单最脆的一环，必须单一真源。
//
// ★★★ 布局铁律（P8_MICRO6 + P8_DIAG3 实测逼出来的，代价 6 轮机器时间）：
//   **站位与目标格必须在 z 上至少差 1 格。**
//   现象：bot 站 (204.5,70,200.0)，服务端把它放在 z=200.0、客户端报 z=200.5 ——
//   客户端与服务端差半格。此时正对着的东西正好压在 z 的**格界**上，射线命中哪一格
//   取决于浮点末位：实测客户端射线判 (205,70,200)，服务端却舀了 (205,70,201)，
//   于是「舀指定格」判据永远失败，而背包里**确实多出了 lava_bucket**（交互本身是好的）。
//   三个挨着的岩浆源（z=199/200/201）正好把这个歧义放大到必错。
//   现在：目标一律放在站位**斜前方**（x 差 1、z 差 1~1.5），半格偏差不再跨格。
//
//        y=71  ┌─ 眼睛高度
//        y=70  │  bot 站的一层（脚踩 y=69 的平台）；目标格也在这一层
//        y=69  ▓▓▓▓▓ 平台（bot 踩着它 → groundSafe 有实地）
//        y=68  （空）不要在这里放岩浆 —— P8_MICRO3 把岩浆放这儿，平台盖在上面，
//                 bot 看不见也够不着 → vis:"occluded"
//
//   平面（俯视，x 向东、z 向南）
//        z=198            z=200            z=202
//   x=195  waterCell(舀水)  ┌──────── 平台 x196..204 ────────┐  x=204  lavaCell(舀岩浆)
//        x=196                                  standWater/standLava  x=205
//              pourCell(200,70,198)   castCell(202,70,198)
//                    ↑ standPour(200.5,70,200)   ↑ standCast(202.5,70,200)

export const SCENE = {
    origin: { x: 200, y: 70, z: 200 },

    // 平台：y=69 一层 stone，bot 站上去脚底 y=70
    platform: { x0: 196, y0: 69, z0: 198, x1: 204, y1: 69, z1: 202 },

    // 舀取岩浆：平台**东侧外**、与 bot 脚同高（y=70），底下是坑 → 源块不扩散也不被压住
    lavaCells: [
        { x: 205, y: 70, z: 198 },
    ],
    lavaPit: { x0: 205, y0: 68, z0: 196, x1: 208, y1: 69, z1: 202 },

    // 舀取水：平台**西侧外**，同样与脚同高
    waterCell: { x: 195, y: 70, z: 198 },
    waterPit: { x0: 192, y0: 68, z0: 196, x1: 195, y1: 69, z1: 202 },

    // 倒水目标格：平台上，底下的 y=69 是平台 stone（可当支撑面）
    pourCell: { x: 200, y: 70, z: 198 },

    // 浇筑目标格：平台上，**该格自带岩浆源**，浇完变黑曜石
    castCell: { x: 202, y: 70, z: 198 },
    // ★ 浇筑要靠「把水倒在岩浆正上方 → 流体混合」实现（P8_DIAG1/2 定案：水桶点岩浆
    //   在 1.16.1 走不通）。倒水的支撑面必须是**实心块** —— 岩浆不算实心，所以上方那格
    //   (202,71,198) 四邻全是空气时没有可点的地方。这里给它东侧搭一块石台当支撑面。
    castShelf: { x: 203, y: 71, z: 198 },

    // bot 站位（都踩在平台上，脚底 y=70 落在 y=69 的 stone 上；与目标在 z 上差 2 格）
    stand: { x: 200.5, y: 70, z: 200.5 },
    standLava: { x: 204.5, y: 70, z: 200.0 },
    standWater: { x: 196.5, y: 70, z: 200.0 },
    standPour: { x: 200.5, y: 70, z: 200.0 },
    standCast: { x: 202.5, y: 70, z: 200.0 },

    // ★ 平台层的「清扫区」：y=70 这一层平台上除了本轮目标以外必须每轮清空。
    //   P8_MICRO_FINAL 实测：n=3 时 cast 3/3，n=30 时 cast **0/30**（都挂在
    //   `fill_scoop_fail:scoop_fail`）——前面 30 次 pour 留在 (200,70,198) 的水会顺着
    //   平台漫开（源块在 1.16 水平能铺 7 格），把水舱、站位、浇筑格全泡进去，
    //   后面每轮的「舀水 → 浇筑」几何全被污染。清扫区就是给每轮复位用的。
    sweep: { x0: 199, y0: 70, z0: 195, x1: 204, y1: 70, z1: 202 },
};

/** 服务端真值闸门要查的格子（编排器与 bot 都用这一份，避免口径漂移） */
export function sceneChecks() {
    const S = SCENE;
    return [
        { x: S.platform.x0, y: S.platform.y0, z: S.platform.z0, b: 'stone', what: '平台' },
        { x: S.lavaCells[0].x, y: S.lavaCells[0].y, z: S.lavaCells[0].z, b: 'lava', what: '岩浆源(舀取用)' },
        { x: S.waterCell.x, y: S.waterCell.y, z: S.waterCell.z, b: 'water', what: '水源(倒水用)' },
        { x: S.pourCell.x, y: S.pourCell.y, z: S.pourCell.z, b: 'air', what: '倒水目标格(应为空)' },
        { x: S.castCell.x, y: S.castCell.y, z: S.castCell.z, b: 'lava', what: '浇筑目标格(应为岩浆源)' },
        { x: S.castShelf.x, y: S.castShelf.y, z: S.castShelf.z, b: 'stone', what: '浇筑石台(倒水的支撑面)' },
    ];
}
