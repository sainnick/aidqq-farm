// frame_exposure.mjs — 门框"暴露面"取证（纯离线，**不开服**）
//
// 派单第 1 条：公平口径先行。
//   用 bench/route/tools/region_reader.mjs（手册 §5：只读取证一律走存档解析器）
//   列出 ① 门框每一格哪些面贴着空气；② 这些空气连到哪里（框东侧 x=188 是不是开放洞穴）。
//   到达确认和强信号只能认"有暴露面"的方块（手册 §7 暴露面判据）——
//   如果 bot 是隔着西墙"看到"门框的，那是透视，必须给强信号命中加暴露面检查。
//
// 数据源：`runs/P8R12_STATE2/worldA` —— **挖之前的存档快照**。
//   （worldB/worldC 是挖掉 (187,39,307) 和 (187,42,310) 之后的，会把结论带偏，不用于本单。）
//
// 阳性对照（手册 §4 第 10 条，报告"没有/不存在"之前必须附）：
//   ① 哭泣黑曜石 (187,42,310) 必须读成 crying_obsidian（R11 实测挖了 32.3s 那格）；
//   ② 框内 (187,40,308) 必须读成 lava 且 props.level === 0（r12 结论：它是源块）；
//   ③ 读数区 unknownCells 必须为 0 —— 有 unknown 就说明"没读到"，**不能当成空气**（手册 §5）。
//   三条任一不过 ⇒ 本脚本的"全被埋"结论一律作废。
//
// 用法：node frame_exposure.mjs [--stamp P8R12_STATE2] [--snap worldA] [--r 20]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from '../../route/tools/region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));

const argOf = (argv, k, d) => {
    const p = argv.indexOf(`--${k}`);
    return p >= 0 && argv[p + 1] && !argv[p + 1].startsWith('--') ? argv[p + 1] : d;
};
const STAMP = argOf(process.argv, 'stamp', 'P8R12_STATE2');
const SNAP = argOf(process.argv, 'snap', 'worldA');
const R = parseInt(argOf(process.argv, 'r', '20'), 10);

const RUNS = path.join(HERE, 'runs', STAMP, SNAP);
const OUT = path.join(HERE, 'runs', STAMP, `exposure_${SNAP}_r${R}.json`);

// ---------- 真框几何（R11/R12 实测：origin=187 39 307 axis=z，内部只有 x=187 这一层） ----------
const FRAME = { x: 187, y: 39, z: 307, axis: 'z' };
const frameCells = [];
for (let u = 0; u < 4; u++) {
    frameCells.push({ at: [187, 39, 307 + u], kind: 'bottom', u, optional: u === 0 || u === 3 });
    frameCells.push({ at: [187, 43, 307 + u], kind: 'top', u, optional: u === 0 || u === 3 });
}
for (let dy = 1; dy <= 3; dy++) {
    frameCells.push({ at: [187, 39 + dy, 307], kind: 'side-n', dy });
    frameCells.push({ at: [187, 39 + dy, 310], kind: 'side-s', dy });
}
const interior = [];
for (let dy = 1; dy <= 3; dy++) for (let u = 1; u <= 2; u++) interior.push([187, 39 + dy, 307 + u]);

// 三个必须补的格（r12 存档级真值）
const REQUIRED_TARGETS = [
    { at: [187, 39, 307], why: '底行缺格（r12 存档确认为 air）' },
    { at: [187, 42, 307], why: '左侧 dy=2 缺格（r12 新发现）' },
    { at: [187, 42, 310], why: 'crying_obsidian，须先铁镐挖掉' },
];
// 框内要舀的岩浆源
const LAVA_SRC = [187, 40, 308];

const AIR = new Set(['air', 'cave_air', 'void_air']);
const FACES = [
    { d: 'W', v: [-1, 0, 0] }, { d: 'E', v: [1, 0, 0] },
    { d: 'N', v: [0, 0, -1] }, { d: 'S', v: [0, 0, 1] },
    { d: 'Down', v: [0, -1, 0] }, { d: 'Up', v: [0, 1, 0] },
];
const key = (x, y, z) => `${x},${y},${z}`;

const w = openWorld(RUNS, { dims: ['overworld'] });
const nameAt = (x, y, z) => w.blockAt(x, y, z, 'overworld');
const stateAt = (x, y, z) => w.blockState(x, y, z, 'overworld');
const isAir = (n) => AIR.has(n);

// 可站立（脚下方块实心 + 脚下格与头两格是空气；用存档语义判，不用 mineflayer 的碰撞箱）
const STANDABLE_BELOW = new Set(['netherrack', 'nether_bricks', 'nether_brick_fence', 'nether_brick_stairs',
    'soul_sand', 'soul_soil', 'magma_block', 'basalt', 'blackstone', 'polished_blackstone',
    'polished_blackstone_bricks', 'obsidian', 'crying_obsidian', 'bedrock', 'glowstone',
    'netherrack', 'stone', 'granite', 'diorite', 'andesite', 'sandstone', 'quartz_block']);
const isSolidish = (n) => n !== 'unknown' && !isAir(n) && n !== 'lava' && n !== 'water' && n !== 'fire'
    && n !== 'nether_portal' && n !== 'end_portal' && n !== 'end_portal_frame' && n !== 'chest'
    && n !== 'spawner' && n !== 'nether_wart_block' && !n.endsWith('_door') && !n.endsWith('leaves')
    || n === 'chest';   // 箱子算"实心"（有碰撞箱），只是不能当落脚点舒适区
const canStand = (x, y, z) => {
    if (!isAir(nameAt(x, y, z))) return false;
    if (!isAir(nameAt(x, y + 1, z))) return false;
    const below = nameAt(x, y - 1, z);
    return isSolidish(below) && below !== 'unknown';
};

// ---------- 读全盒 ----------
// ⚠⚠ **洪水填充必须封在盒子里**：第一版没封，BFS 一路漫进整个已加载的下界，
//   把逐格缓存撑到 2GB 直接 OOM（读本身只要 301ms / 6MB）。教训与手册 §5「别造没上限的扫描」同族。
const box = {
    x1: FRAME.x - R, y1: FRAME.y - R - 4, z1: FRAME.z - R,
    x2: FRAME.x + R, y2: FRAME.y + R + 4, z2: FRAME.z + R,
};
// 洪水填充的边界（比 box 大，用来回答"这些空气**连到哪里**"）
const FR = R * 2;
const fbox = {
    x1: FRAME.x - FR, y1: FRAME.y - FR - 4, z1: FRAME.z - FR,
    x2: FRAME.x + FR, y2: FRAME.y + FR + 4, z2: FRAME.z + FR,
};
const inF = (x, y, z) => x >= fbox.x1 && x <= fbox.x2 && y >= fbox.y1 && y <= fbox.y2 && z >= fbox.z1 && z <= fbox.z2;
const inBox = (x, y, z) => x >= box.x1 && x <= box.x2 && y >= box.y1 && y <= box.y2 && z >= box.z1 && z <= box.z2;

const cellsIn = [];
for (let x = box.x1; x <= box.x2; x++)
    for (let y = box.y1; y <= box.y2; y++)
        for (let z = box.z1; z <= box.z2; z++) cellsIn.push([x, y, z]);
// 只缓存主盒内的读数；盒外直接问 reader（它自己有区块缓存，6MB）
const nameCache = new Map();
for (const [x, y, z] of cellsIn) nameCache.set(key(x, y, z), nameAt(x, y, z));
const nOf = (x, y, z) => {
    const k = key(x, y, z);
    if (nameCache.has(k)) return nameCache.get(k);
    const v = nameAt(x, y, z);
    if (inBox(x, y, z)) nameCache.set(k, v);
    return v;
};
const unknownCells = cellsIn.filter(([x, y, z]) => nOf(x, y, z) === 'unknown').length;
const hist = {};
for (const n of nameCache.values()) hist[n] = (hist[n] ?? 0) + 1;

// ---------- ① 逐格 6 面 ----------
const AIR_FAMILY = new Set([...AIR, 'lava', 'water']);
const faceReport = frameCells.map((c) => {
    const [x, y, z] = c.at;
    const self = nOf(x, y, z);
    const faces = FACES.map((f) => {
        const nx = x + f.v[0], ny = y + f.v[1], nz = z + f.v[2];
        const nn = nOf(nx, ny, nz);
        return {
            dir: f.d, at: [nx, ny, nz], name: nn,
            air: isAir(nn),
            // 液体也算"暴露"（能被看到/够到），但单独标出来
            liquid: nn === 'lava' || nn === 'water',
        };
    });
    return { ...c, self, faces, openFaces: faces.filter((f) => f.air).map((f) => f.dir), exposed: faces.filter((f) => f.air || f.liquid).map((f) => f.dir) };
});

// 空气连通分量（只穿过空气；1.16.1 存档里洞穴空气写的是 minecraft:air）
// ⚠ `Math.min(...arr)` 在十万级数组上会炸参数栈 ⇒ 一律用循环。
const minOf = (a) => { let m = Infinity; for (const v of a) if (v < m) m = v; return m; };
const maxOf = (a) => { let m = -Infinity; for (const v of a) if (v > m) m = v; return m; };
const compOf = new Map();
let comps = [];
{
    const seen = new Set();
    // 只从主盒内的空气起步（框面贴的空气必然在主盒内），但允许洪水分头走到 fbox
    for (const [x, y, z] of cellsIn) {
        const k = key(x, y, z);
        if (seen.has(k) || !isAir(nOf(x, y, z))) continue;
        const id = comps.length;
        const cells = [];
        const stack = [[x, y, z]];
        seen.add(k);
        while (stack.length) {
            const [cx, cy, cz] = stack.pop();
            cells.push([cx, cy, cz]);
            for (const f of FACES) {
                const nx = cx + f.v[0], ny = cy + f.v[1], nz = cz + f.v[2];
                if (!inF(nx, ny, nz)) continue;
                const nk = key(nx, ny, nz);
                if (seen.has(nk) || !isAir(nOf(nx, ny, nz))) continue;
                seen.add(nk);
                stack.push([nx, ny, nz]);
            }
        }
        const xs = cells.map((c) => c[0]), ys = cells.map((c) => c[1]), zs = cells.map((c) => c[2]);
        const comp = {
            id, size: cells.length,
            bbox: { x1: minOf(xs), x2: maxOf(xs), y1: minOf(ys), y2: maxOf(ys), z1: minOf(zs), z2: maxOf(zs) },
            // 顶到洪水边界 ⇒ 在 ±FR 内没有封住（大概率是更大的开放洞穴的一部分）
            hitsFloodEdge: minOf(xs) === fbox.x1 || maxOf(xs) === fbox.x2
                || minOf(ys) === fbox.y1 || maxOf(ys) === fbox.y2
                || minOf(zs) === fbox.z1 || maxOf(zs) === fbox.z2,
            // 与主盒相交的部分有多大（"框附近这一小片"到底有多空）
            inBoxCells: cells.filter((c) => inBox(c[0], c[1], c[2])).length,
        };
        for (const c of cells) compOf.set(key(c[0], c[1], c[2]), comp);
        comps.push(comp);
    }
    comps.sort((a, b) => b.size - a.size);
}

// 框面空气归属：哪一面贴的空气属于哪个分量
for (const fr of faceReport) {
    for (const f of fr.faces) {
        if (!f.air) { f.comp = null; continue; }
        const c = compOf.get(key(f.at[0], f.at[1], f.at[2]));
        f.comp = c ? c.id : null;
        f.compSize = c ? c.size : null;
    }
}

// ---------- ② 可站立格 + 到目标的视线 ----------
/** DDA 视线：只穿过空气，命中第一个实心格 → 返回是否看见目标 */
function losAir(eye, target) {
    const t = [target[0] + 0.5, target[1] + 0.5, target[2] + 0.5];
    const d = [t[0] - eye[0], t[1] - eye[1], t[2] - eye[2]];
    const dist = Math.hypot(d[0], d[1], d[2]);
    if (dist < 0.001) return { ok: true, dist, blockedBy: null };
    const dir = d.map((v) => v / dist);
    const STEPS = Math.ceil(dist * 8);
    for (let i = 1; i < STEPS; i++) {
        const tt = (i / STEPS) * dist;
        const p = [Math.floor(eye[0] + dir[0] * tt), Math.floor(eye[1] + dir[1] * tt), Math.floor(eye[2] + dir[2] * tt)];
        if (p[0] === target[0] && p[1] === target[1] && p[2] === target[2]) return { ok: true, dist, blockedBy: null };
        if (!isAir(nOf(p[0], p[1], p[2]))) return { ok: false, dist, blockedBy: p, blockedName: nOf(p[0], p[1], p[2]) };
    }
    return { ok: true, dist, blockedBy: null };
}

const standCells = [];
for (const [x, y, z] of cellsIn) if (canStand(x, y, z)) standCells.push([x, y, z]);

const reach = [];
for (const t of [...REQUIRED_TARGETS, { at: LAVA_SRC, why: '框内岩浆源（要舀）' }]) {
    const hits = [];
    for (const [x, y, z] of standCells) {
        const eye = [x + 0.5, y + 1.62, z + 0.5];
        const r = losAir(eye, t.at);
        if (r.ok && r.dist <= 4.0) {
            const c = compOf.get(key(x, y, z));
            hits.push({ at: [x, y, z], dist: +r.dist.toFixed(2), comp: c ? c.id : null });
        }
    }
    hits.sort((a, b) => a.dist - b.dist);
    reach.push({ target: t.at, why: t.why, self: nOf(...t.at), reachableCount: hits.length, nearest: hits.slice(0, 8) });
}

// ---------- 输出 ----------
const out = {
    stamp: STAMP, snap: SNAP, r: R, box, floodBox: fbox,
    stats: { cells: cellsIn.length, unknownCells, chunksRead: w.stats.chunksRead, chunkMiss: w.stats.chunkMiss },
    hist: Object.fromEntries(Object.entries(hist).sort((a, b) => b[1] - a[1])),
    components: comps.map((c) => ({ id: c.id, size: c.size, bbox: c.bbox, hitsFloodEdge: c.hitsFloodEdge, inBoxCells: c.inBoxCells })),
    frameFaces: faceReport,
    reach,
};
fs.writeFileSync(OUT, JSON.stringify(out, null, 2));

console.log(`# 门框暴露面取证  snapshot=${SNAP}  盒=(${box.x1}..${box.x2}, ${box.y1}..${box.y2}, ${box.z1}..${box.z2})`);
console.log(`\n[读数] 解析格数=${cellsIn.length}  unknown=${unknownCells}  chunksRead=${w.stats.chunksRead} chunkMiss=${w.stats.chunkMiss}`);

// ---- 阳性对照 ----
const cry = nOf(187, 42, 310);
const lavaSt = stateAt(...LAVA_SRC);
const ctrl = {
    crying_cell_is_crying_obsidian: cry === 'crying_obsidian',
    interior_lava_is_source: lavaSt.name === 'lava' && lavaSt.props && Number(lavaSt.props.level) === 0,
    no_unknown_in_read_region: unknownCells === 0,
};
console.log(`[阳性对照] ${JSON.stringify(ctrl)}  （(187,42,310)=${cry}  (187,40,308)=${lavaSt.name} level=${lavaSt.props ? lavaSt.props.level : '-'})`);
console.log(`[地形对照] 盒内主要方块：${Object.entries(out.hist).slice(0, 8).map(([k, v]) => `${k}=${v}`).join('  ')}`);

console.log(`\n[① 门框 14 格逐面]  ${'格'.padEnd(18)} ${'本块'.padEnd(18)} 贴空气的面`);
for (const fr of faceReport) {
    const tag = `${fr.at.join(',')}${fr.optional ? '(可选)' : ''}`;
    console.log(`  ${tag.padEnd(24)} ${String(fr.self).padEnd(18)} ${fr.openFaces.length ? fr.openFaces.join(',') : '——'}`);
    for (const f of fr.faces) {
        if (f.air) console.log(`        ${f.dir.padEnd(5)} (${f.at.join(',')}) = ${f.name}  分量#${f.comp} (${f.compSize} 格)`);
    }
}

console.log(`\n[② 空气连通分量] 共 ${comps.length} 个，前 6 大（洪水边界 ±${FR}）：`);
for (const c of comps.slice(0, 6)) {
    console.log(`  #${c.id} size=${String(c.size).padEnd(6)} 框内片=${String(c.inBoxCells).padEnd(6)} bbox x[${c.bbox.x1}..${c.bbox.x2}] y[${c.bbox.y1}..${c.bbox.y2}] z[${c.bbox.z1}..${c.bbox.z2}] 顶到洪水边界=${c.hitsFloodEdge}`);
}

const exposedDirs = new Set();
for (const fr of faceReport) for (const d of fr.exposed) exposedDirs.add(d);
console.log(`\n[③ 门框整体暴露方向] ${[...exposedDirs].join(', ') || '（完全没有）'}`);
const byDir = {};
for (const fr of faceReport) for (const f of fr.faces) {
    if (!f.air) continue;
    byDir[f.dir] = (byDir[f.dir] ?? 0) + 1;
}
console.log(`    各方向贴空气的面数：${JSON.stringify(byDir)}`);

console.log(`\n[④ 可达性] 盒内可站立格 ${standCells.length} 个；4 格内**有视线**够到的目标：`);
for (const t of reach) {
    console.log(`  (${t.target.join(',')}) ${t.self.padEnd(18)} 可达站位 ${String(t.reachableCount).padEnd(4)}  ${t.why}`);
    for (const h of t.nearest.slice(0, 4)) console.log(`        站 (${h.at.join(',')}) dist=${h.dist} 分量#${h.comp}`);
}
console.log(`\n已写出 ${OUT}`);
