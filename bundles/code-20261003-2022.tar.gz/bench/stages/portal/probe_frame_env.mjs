// probe_frame_env.mjs — 查清 4926685115947721762 门框的周边环境（为跑通 S1 铺路）
//
// 要查清三件事（r4 遗留的两个障碍）：
//   Q1 门框那 2 格岩浆（187,40,308 / 187,40,309）**周边是什么**？
//      门在洞穴里还是露天地表？岩浆是"一整池"还是"两格零星"？
//      真人处理门内岩浆的标准做法是**先用水浇灭**（水+岩浆→黑曜石/圆石）或绕开站位，
//      但要知道水池有多大才决定策略。
//   Q2 到岩浆源"走不到"的**真因**：r4 的导航目标是 `186,40,307` ——
//      **那本身就是一格岩浆**。pathfinder 不会走进液体格（它把 lava 当不可通行），
//      所以 `Took to long to decide path` 大概率不是"没有路"，而是**目标点不可站立**。
//      本单要验：把目标改成源块**旁边**的实心格，能不能走到。
//   Q3 合格水源 `170,40,298`（水平 8 格 Δy=1）走得到吗？门到水源的路上通不通？
//
// 只取证，不改任务层；泳道只有 B。
// 用法：node probe_frame_env.mjs --seed 4926685115947721762 --stamp P8R5_ENV

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');
const pf = require('mineflayer-pathfinder');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAMP = argOf(process.argv, 'stamp', 'P8R5_ENV');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'EnvBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null;
let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };
const bname = (x, y, z) => { try { return bot.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };
const AIR = new Set(['air', 'cave_air', 'void_air']);

// 门框（r4 实测）
const ORIGIN = { x: 187, y: 39, z: 307 };
const AXIS = 'z';
const IN_LAVA = [[187, 40, 308], [187, 40, 309]];
const LAVA_CAND = [186, 40, 307];
const WATER_CAND = [170, 40, 298];

let frameCells, interiorCells;

/** 门框周围 3D 快照：按 y 分层，打印真实方块名 */
function dumpNeighborhood(cx, cy, cz, r) {
    const layers = [];
    for (let y = cy - r; y <= cy + r; y++) {
        const rows = [];
        for (let z = cz - r; z <= cz + r; z++) {
            let row = '';
            for (let x = cx - r; x <= cx + r; x++) {
                const n = bname(x, y, z);
                row += (!n || AIR.has(n)) ? '.' : shortSym(n);
            }
            rows.push({ z, row });
        }
        layers.push({ y, rows });
    }
    return layers;
}
const SYM = {
    obsidian: 'O', crying_obsidian: 'C', netherrack: 'n', lava: 'L', flowing_lava: 'l',
    water: 'w', flowing_water: 'W', stone: 's', dirt: 'd', grass_block: 'g', magma_block: 'M',
    chest: 'H', air: '.', bedrock: 'B', cobblestone: 'c', sand: 'a', gravel: 'v',
    mossy_cobblestone: 'm', stone_bricks: 'k', deepslate: 'D', tuff: 'T', andesite: 'A',
    diorite: 'i', granite: 'G', coal_ore: 'o', iron_ore: 'r', gold_ore: 'R',
};
const shortSym = (n) => SYM[n] ?? (n ? n[0].toUpperCase() : '?');

/** 统计一格岩浆连成的"池子"有多大（6 连通，只统计已加载区块） */
function lavaPoolSize(x, y, z) {
    const seen = new Set();
    const stack = [[x, y, z]];
    while (stack.length) {
        const [cx, cy, cz] = stack.pop();
        const k = `${cx},${cy},${cz}`;
        if (seen.has(k)) continue;
        const n = bname(cx, cy, cz);
        if (n !== 'lava' && n !== 'flowing_lava') continue;
        seen.add(k);
        for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
            stack.push([cx + dx, cy + dy, cz + dz]);
        }
    }
    return { size: seen.size, cells: [...seen] };
}

/** 找一个「源块旁边能站」的实心格（pathfinder 的合法目标） */
function standableBeside(x, y, z) {
    for (const [dx, dy, dz] of [[0, 1, 0], [1, 1, 0], [-1, 1, 0], [0, 1, 1], [0, 1, -1], [0, 2, 0]]) {
        const fx = x + dx, fy = y + dy, fz = z + dz;
        const feet = bname(fx, fy, fz);
        const below = bname(fx, fy - 1, fz);
        if (feet && !AIR.has(feet) && feet !== 'lava' && feet !== 'water') {
            if (below && below !== 'lava' && below !== 'water') return [fx, fy, fz];
        }
    }
    return null;
}

async function tryWalk(target, label, timeout = 60000) {
    try {
        const p0 = bot.entity.position.floored();
        await bot.pathfinder.goto(new pf.goals.GoalNear(target[0], target[1], target[2], 1), { timeout, lavaGuard: true });
        const p1 = bot.entity.position.floored();
        return { label, target, ok: true, from: [p0.x, p0.y, p0.z], to: [p1.x, p1.y, p1.z],
            walked: Math.round(Math.hypot(p1.x - p0.x, p1.z - p0.z)) };
    } catch (e) {
        return { label, target, ok: false, error: String(e?.message ?? e).slice(0, 140) };
    }
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[env] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[env] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[env] server up in ${(server.bootMs / 1000).toFixed(0)}s seed=${SEED}`);

    const netherMod = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/nether.js')).href);
    frameCells = netherMod.frameCells; interiorCells = netherMod.interiorCells;

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    bot.loadPlugin(pf.pathfinder);
    await sleep(3500);
    cmd(`op ${LANE_B.username}`);
    log(`[env] bot in dim=${bot.game?.dimension}`);

    // 站到门旁边（门在 y≈39，洞里；先从上方落下去）
    cmd(`tp ${LANE_B.username} ${ORIGIN.x} ${ORIGIN.y + 6} ${ORIGIN.z + 4}`);
    await sleep(7000);
    const p0 = bot.entity.position.floored();
    log(`[env] 站位 [${p0.x},${p0.y},${p0.z}]`);

    // Q1 门内岩浆 + 周边环境
    const pool = lavaPoolSize(IN_LAVA[0][0], IN_LAVA[0][1], IN_LAVA[0][2]);
    const layers = dumpNeighborhood(ORIGIN.x, ORIGIN.y + 1, ORIGIN.z, 7);
    const layerTxt = layers.map((L) => `--- y=${L.y} ---  (x ${ORIGIN.x - 7}..${ORIGIN.x + 7}, 每行一个 z)`)
        .concat([]).join('\n');
    const lines = [];
    for (const L of layers) {
        lines.push(`--- y=${L.y} ---`);
        for (const r of L.rows) lines.push(`z=${r.z} ${r.row}`);
    }
    fs.writeFileSync(path.join(RUNS_DIR, 'frame_env.txt'), lines.join('\n'));

    // 门框逐格 + 内部逐格（真实方块名）
    const frameDetail = frameCells(ORIGIN, AXIS).map((c) => ({
        pos: [c.pos.x, c.pos.y, c.pos.z], kind: c.kind, optional: !!c.optional, got: bname(c.pos.x, c.pos.y, c.pos.z),
    }));
    const interiorDetail = interiorCells(ORIGIN, AXIS).map((p) => ({
        pos: [p.x, p.y, p.z], got: bname(p.x, p.y, p.z),
    }));

    // 门框下方与周围的地面情况（判断能不能绕开站位）
    const below = [];
    for (let dz = -3; dz <= 3; dz++) {
        below.push({ dz, y: ORIGIN.y - 1, got: bname(ORIGIN.x, ORIGIN.y - 1, ORIGIN.z + dz) });
    }

    // Q2/Q3 导航实测：先试"源块本身"（r4 的失败目标），再试"源块旁的实心格"
    const nav = [];
    const t0 = Date.now();
    nav.push(await tryWalk(LAVA_CAND, 'lava_source_itself'));
    log(`[env] 走到岩浆源本身: ${nav[0].ok ? 'OK' : 'FAIL ' + nav[0].error}`);

    const stand = standableBeside(LAVA_CAND[0], LAVA_CAND[1], LAVA_CAND[2]);
    if (stand) {
        cmd(`tp ${LANE_B.username} ${ORIGIN.x} ${ORIGIN.y + 6} ${ORIGIN.z + 4}`);
        await sleep(4000);
        nav.push(await tryWalk(stand, 'lava_source_beside'));
        log(`[env] 走到岩浆源旁(${stand.join(',')}): ${nav[nav.length - 1].ok ? 'OK' : 'FAIL'}`);
    } else {
        nav.push({ label: 'lava_source_beside', ok: false, error: '源块四周没有可站立的实心格' });
    }

    const wStand = standableBeside(WATER_CAND[0], WATER_CAND[1], WATER_CAND[2]);
    if (wStand) {
        nav.push(await tryWalk(wStand, 'water_source_beside'));
        log(`[env] 走到水源旁(${wStand.join(',')}): ${nav[nav.length - 1].ok ? 'OK' : 'FAIL'}`);
    } else {
        nav.push({ label: 'water_source_beside', ok: false, error: '水源四周没有可站立的实心格' });
    }

    const out = {
        seed: SEED, stamp: STAMP, at: new Date().toISOString(),
        origin: ORIGIN, axis: AXIS,
        botStart: [p0.x, p0.y, p0.z],
        interiorLava: {
            cells: IN_LAVA,
            poolSize: pool.size,
            poolCells: pool.cells.slice(0, 60),
            verdict: pool.size <= 4 ? '小水坑（几格就浇得掉）' : (pool.size <= 20 ? '中等水池' : '大池（需先筑堤或绕开）'),
        },
        frameDetail, interiorDetail, belowRow: below,
        nav,
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'frame_env.json'), JSON.stringify(out, null, 2));

    const md = [];
    md.push(`# 门框环境取证（${STAMP}）`, '');
    md.push(`- 种子 \`${SEED}\`；门 origin=(${ORIGIN.x},${ORIGIN.y},${ORIGIN.z}) axis=${AXIS}`);
    md.push(`- bot 落点 [${p0.x},${p0.y},${p0.z}]`, '');
    md.push('## Q1 门内岩浆', '');
    md.push(`- 内部岩浆格：${IN_LAVA.map((c) => c.join(',')).join(' | ')}`);
    md.push(`- **6-连通岩浆池大小 = ${pool.size} 格** ⇒ ${out.interiorLava.verdict}`);
    if (pool.size <= 20) md.push(`  - 池内全部格：${pool.cells.slice(0, 30).map((c) => c.join(',')).join(' | ')}`);
    md.push('', '### 门框逐格（真实方块名）', '');
    for (const c of frameDetail) md.push(`- \`${c.pos.join(',')}\` ${c.kind}${c.optional ? '(可省角)' : ''} = **${c.got ?? 'null'}**`);
    md.push('', '### 内部 2×3', '');
    for (const c of interiorDetail) md.push(`- \`${c.pos.join(',')}\` = **${c.got ?? 'null'}**`);
    md.push('', '### 门底一排（y-1）', '');
    md.push(below.map((b) => `z+${b.dz}=${b.got}`).join('  '));
    md.push('', '## Q2/Q3 导航实测', '');
    for (const n of nav) {
        md.push(`- **${n.label}** → ${n.ok ? `✅ 走到 [${n.to.join(',')}]（实走 ${n.walked} 格）` : `❌ ${n.error}`}`);
    }
    md.push('', '## 逐层图（x 从 ' + (ORIGIN.x - 7) + ' 到 ' + (ORIGIN.x + 7) + '）', '', '```', lines.join('\n'), '```', '');
    const mdTxt = md.join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'frame_env.md'), mdTxt);
    console.log(mdTxt);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
