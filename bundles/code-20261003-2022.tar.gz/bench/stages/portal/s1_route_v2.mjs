// s1_route_v2.mjs — MC-M1-TASK-08 r19：把 `s1_exact.json` 的结果落成 **v2 route 文件**
//
// 为什么单独一个文件、而不是就地改 `bench/route/4926685115947721762.json`：
//   ① SCHEMA §4 明写「冻结后再改要升版本号，例如 `<seed>.v2.json`」—— 那是**约定的做法**；
//   ② C 线还持有 v1 文件并且正在用它跑整链（`bench/route/` 是共享区，手册 §9.2）：
//      我就地改会把别人的在跑配置改坏。**串线即事故。**
//   ⇒ 本单只产出 `4926685115947721762.v2.json`（草稿，frozenAt=null），
//     由 C 线按整链节奏并入；本单自己直接读这份数据（任务单原话）。
//
// 同时满足两边的加载器（子 agent 在 `test_route_loader.mjs` §6.2 实测过）：
//   - 任务层 `route_loader.js`（v2：返回 exact/legs，不再粗化）
//   - bench `route_guard.mjs`（**仍按 §1.3 的文件级规则校验**：center 8 格对齐、radius ≥16、
//     lookFor 非空、每条 leg 两端站点的 `exact.stand` 非空）
// ⇒ 所以 v2 文件里 v1 字段照样写全，`exact` 是**加**上去的，不是替换。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(HERE, 's1_exact.json');
const OUT = process.argv.find((a) => a.startsWith('--out='))
    ? process.argv.slice(process.argv.indexOf('--out='))[0].split('=')[1]
    : 'D:/AI斗蛐蛐/bench/route/4926685115947721762.v2.json';

const src = JSON.parse(fs.readFileSync(SRC, 'utf8'));
const ex = src.exact;
const entry = src.legs[0].waypoints[0];

const station = (id, seq, kind, center, stand, notes) => ({
    id, seq, kind, dim: 'overworld',
    station: {
        center,                                   // v1 字段：8 格对齐，route_guard 要
        yHint: 'underground',
        radius: 24,                               // v1 字段：≥16，route_guard 要
        lookFor: ['obsidian'],                    // v1 字段：非空，route_guard 要
    },
    scout: { notes },                            // 加载器会整块丢弃（v1/v2 都丢）
    exact: {
        stand,
        targets: ex.targets,
        hazards: ex.hazards,
        verify: ex.verify,
    },
});

const doc = {
    schema: 'aidqq-route/2',
    seed: src.seed,
    mcVersion: '1.16.1',
    frozenAt: null,                              // 草稿：run 必须显式 --allow-draft
    sha256File: `${src.seed}.sha256`,
    normalFlowStations: ['S1_entry', 'S1_portal'],
    fallbackOnlyStations: [],
    orchestratorContract: 'S1 走精确坐标：按 leg 的 waypoints 走到 exact.stand[0]，' +
        '按 targets[].order 依次 dig → scoop_lava → fill_cell，最后 ignite。',
    legs: [{
        from: 'S1_entry',
        to: 'S1_portal',
        dim: 'overworld',
        waypoints: src.legs[0].waypoints,
        notes: src.legs[0].notes,
    }],
    stations: [
        station('S1_entry', 1, 'surface_entry', [208, 240], [entry], '地表入口路点（S1 段的起点）'),
        station('S1_portal', 2, 'ruined_portal', [184, 304], ex.stand,
            '主种子废弃传送门。框规则来自 NetherPortalBlock.PortalShape：必需黑曜石 10 格，' +
            '底角/顶角不在必需集合内；框内 2×3 必须是空气。' +
            `本次预勘：挖 ${ex.targets.filter((t) => t.what === 'dig').length} 格、` +
            `舀 ${ex.targets.filter((t) => t.what === 'scoop_lava').length} 格岩浆、` +
            `补 ${ex.targets.filter((t) => t.what === 'fill_cell').length} 格。`),
    ],
};

fs.writeFileSync(OUT, JSON.stringify(doc, null, 2) + '\n', 'utf8');
if (!fs.existsSync(OUT)) throw new Error('产物没落盘：' + OUT);
const back = JSON.parse(fs.readFileSync(OUT, 'utf8'));
console.log(`已写 ${OUT}`);
console.log(`  schema=${back.schema}  stations=${back.stations.map((s) => s.id).join(',')}`);
console.log(`  legs=${back.legs.length}  waypoints=${back.legs[0].waypoints.length}`);
console.log(`  S1_portal.exact.stand=${JSON.stringify(back.stations[1].exact.stand.slice(0, 3))}…`);
console.log(`  targets=${back.stations[1].exact.targets.length} 条：`);
for (const t of back.stations[1].exact.targets) console.log(`    order=${String(t.order).padStart(2)} ${t.what.padEnd(11)} ${t.xyz.join(',')}`);
