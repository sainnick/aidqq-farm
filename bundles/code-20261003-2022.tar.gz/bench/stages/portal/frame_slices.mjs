// frame_slices.mjs — 真框周围的**逐格切片**（纯离线，存档解析器）
//
// frame_exposure.mjs 回答"哪一面贴空气、连到哪里"；这个脚本回答"要站上去/要够到，
// 脚下到底有没有东西"，也就是**接近方案的施工图**。
//
// 用法：node frame_slices.mjs [--snap worldA] [--stamp P8R12_STATE2] [--y0 37] [--y1 45]
import path from 'path';
import { fileURLToPath } from 'url';
import { openWorld } from '../../route/tools/region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argOf = (argv, k, d) => {
    const p = argv.indexOf(`--${k}`);
    return p >= 0 && argv[p + 1] && !argv[p + 1].startsWith('--') ? argv[p + 1] : d;
};
const SNAP = argOf(process.argv, 'snap', 'worldA');
const STAMP = argOf(process.argv, 'stamp', 'P8R12_STATE2');
const Y0 = parseInt(argOf(process.argv, 'y0', '37'), 10);
const Y1 = parseInt(argOf(process.argv, 'y1', '45'), 10);
const w = openWorld(path.join(HERE, 'runs', STAMP, SNAP), { dims: ['overworld'] });
const nAt = (x, y, z) => w.blockAt(x, y, z, 'overworld');

const ABBR = {
    air: '.', cave_air: '.', void_air: '.', lava: 'L', water: 'w',
    obsidian: 'O', crying_obsidian: 'C', netherrack: 'n', nether_bricks: 'B',
    soul_sand: 's', magma_block: 'M', basalt: 'b', chest: '$', spawner: 'S',
    fire: 'f', nether_portal: 'P', glowstone: 'G', quartz_block: 'Q', nether_quartz_ore: 'q',
};
const ab = (n) => (n === 'unknown' ? '???' : (ABBR[n] ?? (n[0] ?? '?')));

// ---- ① 竖切片：x=184..190，每片 z=305..312，y=Y0..Y1 ----
console.log(`# 真框切片  snapshot=${SNAP}  y=${Y0}..${Y1}`);
console.log('   图例 . 空气  O obsidian  C crying_obsidian  n netherrack  L lava  ? 其它  ??? 读不到\n');
for (let x = 184; x <= 190; x++) {
    console.log(`── x=${x} ──`);
    console.log('        z=' + Array.from({ length: 8 }, (_, i) => String(305 + i).padStart(2)).join(''));
    for (let y = Y1; y >= Y0; y--) {
        const row = [];
        for (let z = 305; z <= 312; z++) row.push(ab(nAt(x, y, z)).padStart(2));
        console.log(`   y=${String(y).padStart(2)}  ` + row.join(''));
    }
    console.log('');
}

// ---- ② 三个要补的格：六面 + 脚下 ----
console.log('── 目标格邻域（能不能站上去/从哪够）──');
const targets = [
    { at: [187, 39, 307], tag: '底行缺格' },
    { at: [187, 42, 307], tag: '左侧 dy=2 缺格' },
    { at: [187, 42, 310], tag: 'crying_obsidian 侧格' },
    { at: [187, 40, 308], tag: '框内岩浆源' },
];
for (const t of targets) {
    const [x, y, z] = t.at;
    console.log(`\n  (${x},${y},${z}) ${t.tag}  本块=${nAt(x, y, z)}`);
    for (const [d, v] of [['W', [-1, 0, 0]], ['E', [1, 0, 0]], ['N', [0, 0, -1]], ['S', [0, 0, 1]], ['Down', [0, -1, 0]], ['Up', [0, 1, 0]]]) {
        const nx = x + v[0], ny = y + v[1], nz = z + v[2];
        const nn = nAt(nx, ny, nz);
        const below = nAt(nx, ny - 1, nz);
        const above = nAt(nx, ny + 1, nz);
        // 站位判据：该格是空气 + 上头一格是空气 + 脚下是实心
        const air = ['air', 'cave_air', 'void_air'].includes(nn);
        const airUp = ['air', 'cave_air', 'void_air'].includes(above);
        const solid = !['air', 'cave_air', 'void_air', 'lava', 'water', 'fire', 'unknown'].includes(below);
        const canStand = air && airUp && solid;
        console.log(`     ${d.padEnd(5)} (${nx},${ny},${nz})=${nn.padEnd(16)} 脚下=${below.padEnd(14)} 头上=${above.padEnd(12)} ${canStand ? '★可站' : ''}`);
    }
}

// ---- ③ 东西两侧 y=39..45 的"墙厚"（够不够走过去）----
console.log('\n── 东西两侧通透性（沿 z 看 x=186 / x=188 这一列）──');
for (const x of [186, 188]) {
    const air = [];
    for (let z = 305; z <= 312; z++) for (let y = 39; y <= 45; y++) {
        if (['air', 'cave_air', 'void_air'].includes(nAt(x, y, z))) air.push(`${y}/${z}`);
    }
    console.log(`  x=${x} 空气格 (y/z)：${air.length ? air.join(' ') : '（全实心）'}`);
}
