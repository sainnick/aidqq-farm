// probe_frame_geom.mjs — 导出「假框区」与「真框区」的真实方块，供离线几何闸门用例当夹具
//
// 为什么需要它（R10 → R11）：
//   设计会话要求「把 P8R10_PANEL 第 2 局的假框附近方块（158,10,299 一带）和真框各做一个用例，
//   前者必须拒、后者必须过」。而**那两处的方块当时没有落盘**，只有 `portal_frame_located origin=158 10 299`
//   这一行坐标。没有真实方块，用例就只能靠我编 —— 编出来的用例证明不了任何事。
//   ⇒ 这里开一次服把两片区域的方块**导出来**，离线用例直接用真实数据。
//
// 只取证，不改任务层；泳道只有 B。
// 用法：node probe_frame_geom.mjs --stamp P8R11_GEOM --seed 4926685115947721762

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAMP = argOf(process.argv, 'stamp', 'P8R11_GEOM');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'GeomBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const OUT = path.join(RUNS_DIR, 'frame_geom_blocks.json');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null; let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };
const bname = (x, y, z) => { try { return bot.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };

// 两片区域：假框（P8R10_PANEL trial_02 定位到的自然矿脉）与真框（S1_portal）
// 半径给足 12 格 × 高 14 格，够离线枚举 4×5 足迹用。
const REGIONS = [
    { key: 'fake_158_10_299', why: 'P8R10_PANEL trial_02 的 portal_frame_located（自然矿脉，必须被几何闸门拒）', cx: 158, cy: 10, cz: 299, r: 12, h: 14 },
    { key: 'real_187_39_307', why: 'S1_portal 真门（必须被几何闸门接受）', cx: 187, cy: 39, cz: 307, r: 12, h: 14 },
];

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[geom] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[geom] server up in ${(server.bootMs / 1000).toFixed(0)}s`);

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    await sleep(3000);
    await cmd(`op ${LANE_B.username}`);

    // 逐片：先 forceload 周边（服务端权威），再等区块到达客户端，最后读方块
    const out = { seed: SEED, stamp: STAMP, at: new Date().toISOString(), regions: {} };
    for (const R of REGIONS) {
        const x1 = R.cx - R.r, z1 = R.cz - R.r, x2 = R.cx + R.r, z2 = R.cz + R.r;
        await cmd(`forceload add ${x1} ${z1} ${x2} ${z2}`);
        await sleep(1500);
        // 等客户端真的看到这一片（blockAt 不再全 null）
        let ready = false;
        for (let k = 0; k < 60; k++) {
            if (bname(R.cx, R.cy, R.cz) !== null) { ready = true; break; }
            await sleep(500);
        }
        if (!ready) { log(`[geom] ${R.key} 区块没就绪，跳过`); continue; }
        const blocks = {};
        let nonAir = 0;
        for (let dx = -R.r; dx <= R.r; dx++) {
            for (let dz = -R.r; dz <= R.r; dz++) {
                for (let dy = 0; dy < R.h; dy++) {
                    const n = bname(R.cx + dx, R.cy - Math.floor(R.h / 2) + dy, R.cz + dz);
                    if (n === null) continue;            // 未加载的不猜
                    if (n === 'air' || n === 'cave_air' || n === 'void_air') continue;   // 只存非空气，夹具小得多
                    blocks[`${R.cx + dx},${R.cy - Math.floor(R.h / 2) + dy},${R.cz + dz}`] = n;
                    nonAir++;
                }
            }
        }
        out.regions[R.key] = { ...R, blocks, nonAir };
        log(`[geom] ${R.key}: 非空气方块 ${nonAir} 个`);
    }

    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));
    log(`[geom] 已写出 ${OUT}`);
    for (const [k, v] of Object.entries(out.regions)) {
        const cnt = {};
        for (const n of Object.values(v.blocks)) cnt[n] = (cnt[n] ?? 0) + 1;
        log(`[geom]   ${k}: ${JSON.stringify(cnt)}`);
    }

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
