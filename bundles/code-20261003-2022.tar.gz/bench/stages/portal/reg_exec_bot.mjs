// reg_exec_bot.mjs — BASIC-bootstrap 回归 bot（**代码根指向本线 worktree**）
//
// 为什么要单独写一份（任务单 §2「回归：在 worktree 代码上跑」）：
//   `bench/stages/basic-bootstrap/exec_bot.mjs:20` 把代码根**写死**成 `ROOT/mindcraft`
//   （主线 A 的目录），而且它是别的 stage 的文件 —— 任务单 §3 明令
//   「不改其他 stage 的 bench 脚本（它们写死了主目录路径，主线还在用）」。
//   所以本单**新增**这一份，只改一行常量（MINDCRAFT → mindcraft-wt/s1-portal），
//   其余协议逐行照抄，保证与被验收的 basic-bootstrap 语义完全一致：
//     fresh world → 正常出生 → 空背包直接开跑 → 木头→木板→木棍→工作台→木镐→stone ×16
//     零 kit、零 RCON、零 LLM。
// 协议相同 ⇒ 20 局结果与 P2C_M4B4（主线 19/20）可直接对照。
//
// 用法（由 run_portal.mjs --mode reg 调起，勿手跑）：
//   node reg_exec_bot.mjs --trial 1 --seed <seed> --out <runDir> --port 25567
//                         --username TaskBotB --target 16 --timeout-ms 300000
//                         --mc-version 1.16.1 --probe-ms 10000

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
// ★★ 本单唯一的改动：代码根指向 worktree（相对路径修正：ROOT 已经是工作区根，不能再拼 '..'）
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}

const TRIAL = parseInt(arg('trial', '0'), 10);
const SEED = arg('seed', 'unknown');
const OUT_DIR = arg('out', path.dirname(fileURLToPath(import.meta.url)));
const PORT = parseInt(arg('port', '25567'), 10);
const USERNAME = arg('username', 'TaskBotB');
const TARGET = parseInt(arg('target', '16'), 10);
const TIMEOUT_MS = parseInt(arg('timeout-ms', '300000'), 10);
const MC_VERSION = arg('mc-version', '1.16.1');
const TELEMETRY = path.join(OUT_DIR, 'telemetry.jsonl');
const RESULT = path.join(OUT_DIR, 'result.json');
const LOG = path.join(OUT_DIR, 'bot.log');
const PROBE = path.join(OUT_DIR, 'probe.jsonl');
const PROBE_MS = parseInt(arg('probe-ms', '10000'), 10);

fs.mkdirSync(OUT_DIR, { recursive: true });
const logLine = (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(LOG, line + '\n'); } catch { /* 忽略 */ }
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let finished = false;
let _spawned = false;
let _runtime = null;
let _probeTimer = null;

function probeTree(rt) {
    try { return (rt?._ctx?.stack?.renderTrace?.() ?? '').replace(/\[[^\]]*\]/g, '[]'); } catch { return ''; }
}

function startProbe(bot) {
    if (!(PROBE_MS > 0)) return;
    try { fs.rmSync(PROBE, { force: true }); } catch { /* 忽略 */ }
    _probeTimer = setInterval(() => {
        try {
            const invParts = bot.inventory.items().map((i) => `${i.name}:${i.count}`).sort();
            const p = bot.entity?.position;
            const w = bot.currentWindow;
            const furnace = w && String(w.type).includes('furnace')
                ? { f: Math.round(w.fuelSeconds ?? 0), p: Math.round(w.progressSeconds ?? 0) } : null;
            fs.appendFileSync(PROBE, JSON.stringify({
                t: Date.now(), event: 'bench_probe',
                inv: invParts.join(','),
                pos: p ? [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)] : null,
                digging: !!bot.targetDigBlock, furnace, tree: probeTree(_runtime),
            }) + '\n');
        } catch { /* 探针失败不影响试局 */ }
    }, PROBE_MS);
    _probeTimer.unref?.();
}

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const toolPlugin = require('mineflayer-tool').plugin;
    const { TaskRuntime } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/task_runner.js')).href);
    const { AcquireResourceTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/acquire_resource_task.js')).href);
    const { parseMission } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/mission.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
    bot.loadPlugin(pf.pathfinder);
    bot.loadPlugin(toolPlugin);

    const hardKill = setTimeout(() => {
        logLine('HARD_TIMEOUT: runner watchdog fired, exiting without result');
        finish({ status: 'RUNNER_TIMEOUT' }, 1);
    }, TIMEOUT_MS + 60000);

    bot.on('kicked', (r) => { logLine(`kicked: ${r}`); if (!finished) finish({ status: 'KICKED', reason: String(r) }, 1); });
    bot.on('error', (e) => {
        logLine(`bot_error: ${String(e).slice(0, 200)}`);
        if (!finished && !_spawned) finish({ status: 'CONNECT_FAIL', reason: String(e).slice(0, 120) }, 1);
    });
    bot.on('death', () => { logLine('death event: respawning in 800ms'); setTimeout(() => { try { bot.respawn(); } catch { /* 忽略 */ } }, 800); });

    bot.once('spawn', async () => {
        _spawned = true;
        try {
            await sleep(4000);
            const spawnPos = bot.entity.position.floored();
            const invSnap = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',') || '(empty)';
            logLine(`spawn: seed=${SEED} pos=[${spawnPos.x},${spawnPos.y},${spawnPos.z}] inventory=[${invSnap}]`);
            logLine(`mindcraft root = ${MINDCRAFT}`);
            logLine('protocol: NO KIT (bootstrap must be self-sufficient)');
            const mission = parseMission(JSON.stringify({ resource: 'stone', count: TARGET }));
            logLine(`start: mission=${JSON.stringify(mission)}`);
            const runtime = new TaskRuntime(bot, { mission, telemetryPath: TELEMETRY });
            _runtime = runtime;
            startProbe(bot);
            const root = new AcquireResourceTask({ resource: mission.resource, count: mission.count, timeoutMs: TIMEOUT_MS });
            const summary = await runtime.run(root);
            const fullInv = {};
            for (const it of bot.inventory.items()) fullInv[it.name] = (fullInv[it.name] ?? 0) + it.count;
            logLine(`end: ${summary.status} reason=${summary.failReason} dur=${(summary.durationMs / 1000).toFixed(1)}s inv=${JSON.stringify(summary.finalInventory)}`);
            finish({
                ...summary,
                spawnPos: [spawnPos.x, spawnPos.y, spawnPos.z], fullInventory: fullInv,
                mindcraftRoot: MINDCRAFT, kit: 'none',
            }, summary.status === 'SUCCESS' ? 0 : 1);
        } catch (e) {
            logLine(`fatal: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`);
            finish({ status: 'FAILED', failReason: 'INTERNAL', error: String(e).slice(0, 300) }, 1);
        }
    });

    function finish(summary, code) {
        if (finished) return;
        finished = true;
        clearTimeout(hardKill);
        if (_probeTimer) clearInterval(_probeTimer);
        try {
            fs.writeFileSync(RESULT, JSON.stringify({ trial: TRIAL, seed: SEED, target: TARGET, kit: 'none', ...summary }, null, 2));
        } catch (e) { logLine(`result write fail: ${e.message}`); }
        setTimeout(() => {
            try { bot.quit(); } catch { /* 忽略 */ }
            process.exit(code);
        }, 1200);
    }
}

main().catch((e) => { logLine(`boot fail: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`); process.exit(1); });
