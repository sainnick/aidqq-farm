// probe_scoop_geom.mjs — 门内岩浆「舀不走」的根因验证与修法（r5 决定性一步）
//
// 现象（runs/P8R5_DISPOSE2，服务端真值）：
//   站在 187,41,307 / 187,41,310（脚下 netherrack，**不在浆里**，岩浆死亡 0 ✅）
//   舀 187,40,308 / 187,40,309 → **两格都 scoop_fail**，桶始终是空桶
//   内部遥测 `liquid_act_fail` 的瞄准点 = (187.5, **40.95**, 308.5)
//     —— 即岩浆**顶面中心**，射线方向是**水平偏上**，而 bot 站在 y=41 与岩浆 y=40 **同层**
//
// 判读：1.16.1 的 `BucketItem.use`（use_item 通道）由**服务端**按玩家朝向打射线，
//   必须打中那格岩浆的**顶面**。bot 与目标同高时，射线几乎打不到脚边那一格的顶面
//   ⇒ 静默失败（服务端零异常，与手册 §3 记的"握桶静默拒收"是同一族问题）。
//
// 本脚本用**同一套生产原语**（liquid.js 的 scoopLiquidAt）扫一组站位，
// 找出真正能舀到的站位高度/方位：
//   A. 同层水平 4 方位（复现失败）
//   B. 站高 1 格俯视（y=42）
//   C. 站高 2 格俯视（y=43）
//   D. 对照：在**框外**那 8 格岩浆（187,40,308 的邻居 186,40,309 等）舀一次
//      —— 证明"舀岩浆原语本身没坏"，问题只在**几何/站位**。
//
// 只取证，不改任务层；泳道只有 B。
// 用法：node probe_scoop_geom.mjs --seed 4926685115947721762 --stamp P8R5_SCOOP

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');
const pf = require('mineflayer-pathfinder');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAMP = argOf(process.argv, 'stamp', 'P8R5_SCOOP');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'ScoopBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null; let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };
const bname = (x, y, z) => { try { return bot.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };
const LIQ = new Set(['lava', 'flowing_lava', 'water', 'flowing_water']);
const AIR = new Set(['air', 'cave_air', 'void_air']);

const DOOR = { x: 187, y: 39, z: 307 };
const TARGETS = {
    inFrame: [[187, 40, 308], [187, 40, 309]],     // 门框内那 2 格
    outside: [[186, 40, 309], [186, 40, 310]],     // 框外那 6 格里的 2 格（对照组）
};
const SAFE = [186, 40, 306];                       // r5 实测的门外安全落脚点

let scoopLiquidAt, liquidSourceInfo;

async function walkTo(t, label, timeout = 40000) {
    try {
        await bot.pathfinder.goto(new pf.goals.GoalNear(t[0], t[1], t[2], 1), { timeout, lavaGuard: true });
        return { ok: true, at: bot.entity.position.floored() };
    } catch (e) { return { ok: false, error: String(e?.message ?? e).slice(0, 100) }; }
}
/** 站位是否安全（不在浆里） */
function safe(p) {
    const f = bname(p.x, p.y, p.z); const b = bname(p.x, p.y - 1, p.z);
    return { ok: !LIQ.has(f) && !LIQ.has(b), feet: f, below: b };
}
/** 保证背包里有一只空桶 */
async function ensureEmptyBucket() {
    const n = bot.inventory.items().filter((i) => i.name === 'bucket').length;
    if (n >= 1) return true;
    cmd(`give ${LANE_B.username} minecraft:bucket 1`);
    await sleep(1800);
    return bot.inventory.items().some((i) => i.name === 'bucket');
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[scoop] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[scoop] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[scoop] server up in ${(server.bootMs / 1000).toFixed(0)}s`);

    const liq = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/liquid.js')).href);
    scoopLiquidAt = liq.scoopLiquidAt; liquidSourceInfo = liq.liquidSourceInfo;
    log('[scoop] 生产原语 liquid.js 已加载');

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    bot.loadPlugin(pf.pathfinder);
    await sleep(3500);
    cmd(`op ${LANE_B.username}`);

    let deaths = 0;
    bot.on('death', () => { deaths++; log('[scoop] ☠️ died'); });

    // 落到安全点（★不能 tp 到门上方，会掉进浆里 —— r5 第一版就是这么死的）
    cmd(`tp ${LANE_B.username} ${SAFE[0]} ${SAFE[1] + 1} ${SAFE[2]}`);
    await sleep(7000);
    await ensureEmptyBucket();
    const sp = bot.entity.position.floored();
    log(`[scoop] 起始落点 [${sp.x},${sp.y},${sp.z}] 安全=${safe(sp).ok} 背包=${bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',')}`);

    const results = [];
    /** 测一个「目标格 + 站位」的组合 */
    async function trial(target, stand, tag) {
        if (!await ensureEmptyBucket()) { results.push({ tag, target, stand, ok: false, reason: 'no_bucket' }); return; }
        const w = await walkTo([stand[0], stand[1], stand[2]], `scoop_${tag}`);
        if (!w.ok) { results.push({ tag, target, stand, ok: false, reason: `walk:${w.error}` }); log(`[scoop] ${tag} 走不到 ${stand.join(',')}`); return; }
        const s0 = safe(bot.entity.position.floored());
        const info = liquidSourceInfo(bot, new Vec3(target[0], target[1], target[2]));
        const r = await scoopLiquidAt(bot, new Vec3(target[0], target[1], target[2]), {
            telemetry: (e, d) => { if (e === 'liquid_act_fail' || e === 'liquid_act_ok') results.push({ tag, event: e, aim: d?.at, held: d?.held }); },
            label: `scoop_${tag}`, maxTries: 1,
        });
        const after = bname(...target);
        const inv = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',');
        const rec = {
            tag, target, stand, walkOk: true, standSafe: s0.ok, standBelow: s0.below,
            isSource: info?.isSource ?? null, level: info?.level ?? null,
            ok: r.ok, kind: r.kind ?? null, reason: r.reason ?? null, after, inv,
        };
        results.push(rec);
        log(`[scoop] ${tag} 站${stand.join(',')}(脚下${s0.below}) 舀${target.join(',')}[源=${info?.isSource}]: ${r.ok ? `✅ ${r.kind}` : `❌ ${r.reason}`} → ${after}｜${inv}`);
    }

    const T1 = TARGETS.inFrame[0];     // 187,40,308
    // A 同层水平 4 方位（复现 r5 的失败）
    for (const [dx, dz] of [[0, -1], [1, 0], [0, 1], [-1, 0]]) {
        await trial(T1, [T1[0] + dx, T1[1] + 1, T1[2] + dz], `A_same_${dx}_${dz}`);
        // 舀完就补回岩浆，保持每轮起点一致
        cmd(`setblock ${T1[0]} ${T1[1]} ${T1[2]} minecraft:lava`);
        await sleep(700);
    }
    // B/C 站高 1/2 格俯视
    for (const up of [1, 2]) {
        await trial(T1, [T1[0], T1[1] + up, T1[2] - 1], `B_up${up}`);
        cmd(`setblock ${T1[0]} ${T1[1]} ${T1[2]} minecraft:lava`);
        await sleep(700);
    }
    // D 对照组：框外那 6 格里的岩浆（同高度、同手法，只换位置）
    for (const O of TARGETS.outside) {
        await trial(O, [O[0], O[1] + 1, O[2] - 1], `D_outside_${O.join('_')}`);
        cmd(`setblock ${O[0]} ${O[1]} ${O[2]} minecraft:lava`);
        await sleep(700);
    }

    let lavaDeaths = 0;
    try {
        const txt = fs.readFileSync(path.join(RUNS_DIR, 'server.log'), 'utf8');
        lavaDeaths = (txt.match(/tried to swim in lava/g) ?? []).length;
    } catch { /* 忽略 */ }

    const fs2 = JSON.parse(JSON.stringify(results));
    const summary = fs2.filter((r) => r.tag && !r.event);
    const winners = summary.filter((r) => r.ok);
    fs.writeFileSync(path.join(RUNS_DIR, 'scoop_geom.json'), JSON.stringify({ seed: SEED, stamp: STAMP, results, deaths, lavaDeaths }, null, 2));

    const md = [];
    md.push(`# 舀岩浆站位几何验证（${STAMP}）`, '');
    md.push(`- 种子 \`${SEED}\`；门内岩浆 ${TARGETS.inFrame.map((t) => t.join(',')).join(' / ')}`);
    md.push(`- 起始落点 [${sp.x},${sp.y},${sp.z}]（安全=${safe(sp).ok}）`, '');
    md.push('| 试验 | 站位 | 脚下 | 目标 | 源块 | 结果 | 该格之后 | 背包 |', '|---|---|---|---|---|---|---|---|');
    for (const r of summary) {
        md.push(`| ${r.tag} | ${(r.stand ?? []).join(',')} | ${r.standBelow ?? '-'} | ${(r.target ?? []).join(',')} | ${r.isSource ?? '-'} | ${r.ok ? '✅ ' + r.kind : '❌ ' + (r.reason ?? '-')} | ${r.after ?? '-'} | ${r.inv ?? '-'} |`);
    }
    md.push('', '## 结论', '');
    if (winners.length) {
        md.push(`- **能舀到的组合 ${winners.length}/${summary.length}**：${winners.map((w) => `${w.tag}（站 ${w.stand.join(',')}）`).join('；')}`);
    } else {
        md.push('- **没有任何站位能舀到** —— 门内那 2 格岩浆在当前几何下舀不走。');
    }
    md.push(`- 岩浆死亡 = **${lavaDeaths}**｜bot death = **${deaths}**`);
    const mdTxt = md.join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'scoop_geom.md'), mdTxt);
    console.log(mdTxt);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
