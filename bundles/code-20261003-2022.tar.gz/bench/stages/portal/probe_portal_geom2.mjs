// probe_portal_geom2.mjs — 主种子废弃传送门「框体几何 + 箱子战利品 + 岩浆/水」一次性取证
//
// ★ 为什么重写（第一版 probe_portal_geom.mjs 的教训）：
//   第一版把方块名压成单字母符号再打印，于是 'B' 可能是 bedrock / birch_log / bricks、
//   'S' 可能是 stone_bricks / sandstone / smooth_stone、'n' 是 netherrack ——
//   **同一个字母对应多个方块，结论会建在误读上**。手册 §5：「扫描或核验工具读出异常时，
//   先证伪工具，再证伪世界」。所以本版：
//     ① 一律打印**真实方块名**（JSON），不压缩；
//     ② 门框判定直接调用**生产代码** nether.js 的 frameCells/checkFrame（含 1.16.1
//        「顶行两角可省」语义），不另写一份几何；
//     ③ 顺带报出 bot 所在维度与若干关键格的方块名（用来解码上一版的符号）。
//
// 要回答的三个问题（都直接决定本轮方案可行性）：
//   Q1 主种子废弃门的框体到底缺几格 obsidian？内部要清几格？
//   Q2 箱子里真实有什么？（派单按战利品表推的 E 值要拿实测校）
//   Q3 岩浆源/水源在门附近是否可得、离多远、什么高度？（决定局部浇筑代价）
//
// 只取证：不起新端口、不改任务层/共享文件，泳道只有 B。
// 公平口径：赛前预勘取证（与 SEED-03/ROUTE-02 同源的服务器权威通道），产出只进报告。
//
// 用法：node probe_portal_geom2.mjs --stamp P8R3_GEOM2 --seed -8839485814800629942

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const STAMP = argOf(process.argv, 'stamp', 'P8R3_GEOM2');
const SEED = argOf(process.argv, 'seed', '-8839485814800629942');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'GeomBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null;
let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };
const bname = (x, y, z) => { try { return bot.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };

// 生产几何（nether.js，ESM 动态导入）
let frameCells, interiorCells;
const AIR = new Set(['air', 'cave_air', 'void_air']);

/** 在给定范围内枚举所有可能的框体原点，用生产语义打分 */
function scanFrames(range) {
    const out = [];
    for (const axis of ['x', 'z']) {
        for (let y = range.y1; y <= range.y2 - 4; y++) {
            for (let x = range.x1; x <= range.x2 - 3; x++) {
                for (let z = range.z1; z <= range.z2 - 3; z++) {
                    const origin = { x, y, z };
                    const cells = frameCells(origin, axis);
                    let obs = 0, missing = [], wrong = [], optionalMissing = 0;
                    for (const c of cells) {
                        const n = bname(c.pos.x, c.pos.y, c.pos.z);
                        if (n === 'obsidian') { obs++; continue; }
                        if (c.optional) { if (!n || AIR.has(n)) optionalMissing++; else wrong.push({ pos: [c.pos.x, c.pos.y, c.pos.z], got: n, optional: true }); continue; }
                        if (!n || AIR.has(n)) missing.push({ pos: [c.pos.x, c.pos.y, c.pos.z], got: n ?? 'unloaded' });
                        else wrong.push({ pos: [c.pos.x, c.pos.y, c.pos.z], got: n });
                    }
                    const interior = interiorCells(origin, axis).map((p) => ({ pos: [p.x, p.y, p.z], got: bname(p.x, p.y, p.z) }));
                    const dirty = interior.filter((c) => c.got && !AIR.has(c.got));
                    if (obs >= 4) out.push({ axis, origin, obs, missing, wrong, optionalMissing, dirty, interior });
                }
            }
        }
    }
    out.sort((a, b) => b.obs - a.obs || a.missing.length - b.missing.length);
    return out;
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[geom2] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[geom2] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[geom2] server up in ${(server.bootMs / 1000).toFixed(0)}s seed=${SEED}`);

    const netherMod = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/nether.js')).href);
    frameCells = netherMod.frameCells;
    interiorCells = netherMod.interiorCells;
    log('[geom2] nether.js 几何已加载（生产代码）');

    const mineflayer = require('mineflayer');
    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    await sleep(3500);
    cmd(`op ${LANE_B.username}`);
    const dim = bot.game?.dimension ?? null;
    const spawn = bot.entity.position.floored();
    log(`[geom2] bot in, dim=${dim}, spawn=[${spawn.x},${spawn.y},${spawn.z}]`);

    // —— Q1 门框几何：tp 到 probe 命中的框体附近 ——
    cmd(`tp ${LANE_B.username} 180 100 356`);
    await sleep(7000);
    const RANGE = { x1: 172, x2: 190, y1: 70, y2: 86, z1: 346, z2: 366 };
    const frames = scanFrames(RANGE);
    log(`[geom2] 框体候选 ${frames.length} 个，最强 obs=${frames[0]?.obs ?? 0}`);

    // 逐格真值：把最佳候选周边整块 dump 成真实方块名
    const grid = {};
    for (let y = RANGE.y1; y <= RANGE.y2; y++) {
        for (let z = RANGE.z1; z <= RANGE.z2; z++) {
            for (let x = RANGE.x1; x <= RANGE.x2; x++) {
                const n = bname(x, y, z);
                if (n && !AIR.has(n)) grid[`${x},${y},${z}`] = n;
            }
        }
    }
    const countBy = {};
    for (const n of Object.values(grid)) countBy[n] = (countBy[n] ?? 0) + 1;

    // —— Q2 箱子：服务端真开箱 ——
    const chestKey = Object.keys(grid).find((k) => grid[k] === 'chest' || grid[k] === 'trapped_chest');
    let chest = { pos: chestKey ? chestKey.split(',').map(Number) : null, items: null, error: null };
    if (chest.pos) {
        const [cx, cy, cz] = chest.pos;
        try {
            cmd(`tp ${LANE_B.username} ${cx} ${cy + 2} ${cz + 1}`);
            await sleep(2500);
            const blk = bot.blockAt(new Vec3(cx, cy, cz));
            const win = await bot.openChest(blk);
            chest.items = win.containerItems().map((i) => `${i.name}x${i.count}`);
            try { win.close(); } catch { /* 忽略 */ }
        } catch (e) { chest.error = String(e?.message ?? e).slice(0, 160); }
    }

    // —— Q3 水/岩浆：门心 64 格内的源块（源块判据 level===0，与 liquid.js 同口径）——
    cmd(`tp ${LANE_B.username} 180 100 356`);
    await sleep(5000);
    const PORTAL = { x: 180, z: 356 };
    const scanLiquid = (name) => {
        let found = [];
        try {
            found = bot.findBlocks({
                matching: (b) => b && (b.name === name || b.name === `flowing_${name}`),
                count: 600, maxDistance: 64,
            }) ?? [];
        } catch { found = []; }
        const out = [];
        for (const f of found) {
            const bb = bot.blockAt(new Vec3(f.x, f.y, f.z));
            if (!bb) continue;
            let level = null;
            try { level = bb.getProperties?.()?.level ?? null; } catch { level = null; }
            out.push({ at: [f.x, f.y, f.z], name: bb.name, level, isSource: level === 0,
                dist: Math.round(Math.hypot(f.x - PORTAL.x, f.z - PORTAL.z)) });
        }
        return out;
    };
    const lavas = scanLiquid('lava');
    const waters = scanLiquid('water');
    const lavaSrc = lavas.filter((l) => l.isSource).sort((a, b) => a.dist - b.dist);
    const waterSrc = waters.filter((w) => w.isSource).sort((a, b) => a.dist - b.dist);

    const out = {
        stamp: STAMP, seed: SEED, at: new Date().toISOString(),
        bot: { dim, spawn: [spawn.x, spawn.y, spawn.z] },
        range: RANGE,
        nonAirCounts: Object.fromEntries(Object.entries(countBy).sort((a, b) => b[1] - a[1])),
        frames: frames.slice(0, 12),
        grid,                                   // 真实方块名（'x,y,z' → name）
        chest,
        liquids: {
            lavaCells: lavas.length, lavaSources: lavaSrc.length, lavaNearest: lavaSrc.slice(0, 10),
            waterCells: waters.length, waterSources: waterSrc.length, waterNearest: waterSrc.slice(0, 10),
        },
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'geom2_result.json'), JSON.stringify(out, null, 2));

    // —— 人读摘要 ——
    const md = [];
    md.push(`# 主种子废弃传送门取证 v2（${STAMP}）`, '');
    md.push(`- 种子 \`${SEED}\`；bot 维度 **${dim}**，出生点 [${spawn.x},${spawn.y},${spawn.z}]`);
    md.push(`- 取景区间 x${RANGE.x1}..${RANGE.x2} / y${RANGE.y1}..${RANGE.y2} / z${RANGE.z1}..${RANGE.z2}`);
    md.push(`- 非空气方块计数：${Object.entries(countBy).slice(0, 14).map(([k, v]) => `\`${k}\`=${v}`).join('  ')}`, '');
    md.push('## Q1 门框（生产几何 frameCells，1.16.1 顶行两角可省）', '');
    if (!frames.length) md.push('**没有任何 4×5 足迹含 ≥4 格 obsidian**');
    for (const f of frames.slice(0, 5)) {
        md.push(`- axis=\`${f.axis}\` origin=(${f.origin.x},${f.origin.y},${f.origin.z}) → **obsidian ${f.obs} / 缺 ${f.missing.length} / 错块 ${f.wrong.length} / 内部脏 ${f.dirty.length}**（缺 ${f.missing.length} 格中顶行可省角 ${f.optionalMissing}）`);
        if (f.missing.length) md.push(`  - 缺：${f.missing.map((m) => `${m.pos.join(',')}`).join(' | ')}`);
        if (f.wrong.length) md.push(`  - 错块：${f.wrong.map((m) => `${m.pos.join(',')}=\`${m.got}\``).join(' | ')}`);
        if (f.dirty.length) md.push(`  - 内部脏：${f.dirty.map((m) => `${m.pos.join(',')}=\`${m.got}\``).join(' | ')}`);
    }
    md.push('', '## Q2 箱子（服务端实开）', '');
    if (!chest.pos) md.push('- 区间内**没有箱子**');
    else md.push(`- 箱子 @ (${chest.pos.join(',')})：**${chest.error ? `开箱失败 ${chest.error}` : (chest.items?.join(', ') || '(空)')}**`);
    md.push('', '## Q3 门心 64 格内的液体（源块 = level 0）', '');
    md.push(`- 岩浆格 ${out.liquids.lavaCells}，其中**源块 ${lavaSrc.length}**${lavaSrc.length ? `：${lavaSrc.slice(0, 6).map((l) => `${l.at.join(',')}(${l.dist}格,y=${l.at[1]})`).join(' | ')}` : ''}`);
    md.push(`- 水格 ${out.liquids.waterCells}，其中**源块 ${waterSrc.length}**${waterSrc.length ? `：${waterSrc.slice(0, 6).map((w) => `${w.at.join(',')}(${w.dist}格,y=${w.at[1]})`).join(' | ')}` : ''}`);
    const mdTxt = md.join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'geom2_report.md'), mdTxt);
    console.log(mdTxt);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
