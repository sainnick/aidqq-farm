// s1_route_v2_r20.mjs — MC-M1-TASK-08 r20：把 v2 route 按**设计会话的源码判据**与
// **本单的判据**改到位。四处改动，全部可追溯：
//
//   ① targets 补第二格 `fill_cell (187,42,310)`。
//      依据 `NetherPortalBlock.java:243-279`（`calculatePortalHeight`）：高度逐行判，
//      行内 j==0 查 `leftDir`、j==width-1 查 `rightDir`，**两侧柱都必须恰好是 obsidian**
//      ⇒ 挖掉 (187,42,310) 的 crying_obsidian 之后，**这一格必须补回 obsidian**。
//      r19 只补了 (187,42,307) 一格 ⇒ 按它点不着门。
//
//   ② 新增一步 `check_frame_air`（order 80，ignite 之前）：
//      框内 6 格（z=308..309 × y=40..42）逐格确认全是空气。源码 `a()` 判据
//      （:282-284）只接受空气/可替换/门方块 —— 岩浆、水、圆石**一律不行**。
//      y=42 是半空，浇注时水会流进框内 ⇒ 不清掉就点不着。
//
//   ③ 站位换成**按判据选出来的**合规站位（不再是 r19 的 183,40,311——它眼睛到目标 4 格+）。
//      判据：脚下实心非危险 ∧ 6 邻无岩浆/岩浆块 ∧ 眼睛到每个目标 ≤4.5 格。
//      由 `s1_stand_path_pick.mjs` 在主种子 fresh world 上枚举 114 个站得住的格子得出。
//
//   ④ leg 的 notes 与站位注释写明**这段路要挖穿**（存档真值：入口到 y41 无可走通道），
//      免得下一单把 waypoints 当成"当下就能走"的路。
//
// ⚠ 只改 `bench/route/4926685115947721762.v2.json`（B 线 S1 段，归本线）。
//   **绝不碰 `.v2.fullroute.json`**（C 线的）。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argOf = (k, d) => { const a = process.argv.find((x) => x.startsWith(`--${k}=`)); return a ? a.slice(k.length + 3) : d; };
const ROUTE = argOf('route', 'D:/AI斗蛐蛐/bench/route/4926685115947721762.v2.json');
const PICK = argOf('pick', path.join(HERE, 's1_stand_path.json'));

const doc = JSON.parse(fs.readFileSync(ROUTE, 'utf8'));
const pick = JSON.parse(fs.readFileSync(PICK, 'utf8'));

// ── ① ② targets：整份重建（顺序是判据的一部分，不许局部 patch）
const TARGETS = [
    { what: 'dig', xyz: [187, 42, 310], order: 10, tool: 'iron_pickaxe', note: 'crying_obsidian：源码判据要求该格**恰好**是 obsidian' },
    { what: 'scoop_lava', xyz: [187, 40, 308], order: 20, note: '框内必须是空气（源码 a() 判据），当前 lava' },
    { what: 'scoop_lava', xyz: [187, 40, 309], order: 21, note: '框内必须是空气（源码 a() 判据），当前 lava' },
    { what: 'fill_cell', xyz: [187, 42, 307], order: 30, how: 'two_bucket', note: '空缺侧柱格，补 obsidian' },
    { what: 'fill_cell', xyz: [187, 42, 310], order: 31, how: 'two_bucket', note: '★ 挖掉 crying_obsidian 后必须补回：calculatePortalHeight 逐行判两侧柱（:257-261）' },
    {
        what: 'check_frame_air', xyz: [187, 41, 308], order: 80,
        frameInner: [[187, 40, 308], [187, 40, 309], [187, 41, 308], [187, 41, 309], [187, 42, 308], [187, 42, 309]],
        note: '点火前逐格确认框内 6 格全是空气：y=42 半空，浇注时水/圆石会流进框内，'
            + '源码 a()（:282-284）只接受空气/可替换/门方块 ⇒ 不清掉点不着',
    },
    { what: 'ignite', xyz: [187, 41, 308], order: 90, note: '框内任意一格空气即可点火（服务端按框内是否有点燃物触发）' },
];

// ── ③ 站位：按判据选出来的合规站位（全部 17 个都写进 stand，按排序优先级）
const compliant = pick.stands.top.filter((c) => c.compliant).map((c) => c.cell);
if (!compliant.length) throw new Error('存档枚举里没有合规站位 —— 不许退回 r19 的站位，按判据应为空即失败');

let touched = 0;
for (const st of doc.stations) {
    if (!st.exact) continue;
    st.exact.targets = TARGETS.map((t) => ({ ...t }));
    if (st.id === 'S1_portal') {
        st.exact.stand = compliant;                    // 按 farEye 升序（s1_stand_path_pick 的全序）
        st.exact.standCriteria = {
            reachMax: pick.criteria.reachMax,
            eyeHeight: pick.criteria.eyeHeight,
            rule: '脚下实心非危险 ∧ 6 邻(水平4+上下2)无 lava/flowing_lava/magma_block ∧ 眼睛到每个目标 ≤4.5 格',
            source: 'bench/stages/portal/s1_stand_path_pick.mjs @ bench/route/probe/_s1_main_fresh/4926685115947721762',
            candidatesScanned: pick.stands.totalCandidates,
            compliantCount: compliant.length,
            chosen: compliant[0],
            rejectedR19Stand: { cell: [183, 40, 311], why: '眼睛到 (187,42,307)/(187,42,310) 超过 4.5 格，不满足判据' },
        };
        touched++;
    } else if (st.id === 'S1_entry') {
        st.exact.standCriteria = {
            rule: '入口站位；body=air foot=sand head=air，6 邻无危险',
            source: 'bench/route/probe/_s1_main_fresh/4926685115947721762',
        };
    }
}

// ── ④ leg notes：写明这段要挖穿（r20 实测的存档真值）
for (const leg of doc.legs) {
    if (leg.to === 'S1_portal') {
        leg.notes = '从地表入口 206,64,242 走到作业站位。'
            + '相邻路点 ≤32 格（SCHEMA §5）。'
            + '★ r20 存档核验：入口脚下从 y=63 起全是实心沙/砂岩/石头，门框区可走格只有 y41 的 34 格，'
            + '**入口与门框之间没有现成通道**（连通域交集 0）⇒ 这条腿的性质是**挖穿**，'
            + '不是"当下就能走"。waypoints 是几何走廊，任务层必须边挖边走；'
            + '本单不因这条腿判失败，但它不能被当成"已验证可走"。';
        leg.evidenceLevel = 'geometry_not_walkable';
    }
}
doc.orchestratorContract = 'S1 走精确坐标：按 leg 的 waypoints 走到 exact.stand[0]（腿为挖穿语义），'
    + '按 targets[].order 依次 dig → scoop_lava → fill_cell(×2) → check_frame_air → ignite。';

fs.writeFileSync(ROUTE, JSON.stringify(doc, null, 2) + '\n', 'utf8');
const back = JSON.parse(fs.readFileSync(ROUTE, 'utf8'));
const p = back.stations.find((s) => s.id === 'S1_portal');
console.log('已写 ' + ROUTE);
console.log('  S1_portal.targets:');
for (const t of p.exact.targets) console.log(`    order=${String(t.order).padStart(2)} ${t.what.padEnd(15)} ${t.xyz.join(',')}`);
console.log('  S1_portal.stand (' + p.exact.stand.length + ' 个合规): ' + JSON.stringify(p.exact.stand.slice(0, 4)) + ' …');
console.log('  leg.evidenceLevel = ' + back.legs[0].evidenceLevel);
console.log('  改动站数: ' + touched);
