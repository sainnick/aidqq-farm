// gen_scout_world.mjs — MC-M1-TASK-08 r19：**干净**主种子存档，供离线预勘（S1 精确坐标）
//
// 为什么重开一份而不是直接用 `bench/route/probe/_bedhunt`：
//   r19 开工时我**假设** `_bedhunt` 被 fill-replace 污染过（手册 §5 的老规矩），于是重开了一份。
//   实测结论与那个假设**部分不符，如实记录**（手册 §5「归因必须引用遥测，不许无证据归因」）：
//   ✅ 假设成立的部分：两份世界在 (174,30,293) 不同 —— `_bedhunt`=lava、重开=cave_air；
//      (174,29,293) `_bedhunt`=lava、重开=water ⇒ `_bedhunt` 这一带**确实**被改过。
//   ❌ 假设不成立的部分：门框 5 个关键格（187,40,308 / 187,40,309 / 187,39,307 /
//      187,42,307 / 187,42,310）两份世界**逐格一致**，而且与 P8R18_PANEL4 那局
//      **真服实跑**的 bot 自己读到的值也一致（`portal_interior_lava_reuse` 遥测：
//      框内 lava=[[187,40,308],[187,40,309]]、missing=[[187,39,307],[187,42,307],[187,42,310]]）。
//      ⇒ 门框那一小片**不是**污染，是这个种子本来的样子；用它推精确坐标有实跑背书。
//   ⇒ 所以本脚本仍然保留（重开一份 = 少一个"这份存档被动过吗"的问号），但**不再以
//      "反污染"为理由**。真正的口径是：精确坐标要同时有「存档解析」与「实跑」两条通道对上。
//
// ⚠ 另注：这一带同时有 netherrack / magma_block / gold_block / stone_bricks。
//   主世界 y≈36~46 出现 netherrack 不是自然生成的，但它在**重开的世界**里同样存在、
//   且与实跑 bot 读到的岩浆位置吻合 —— 所以它是真的，不是解析器读错（见 r19 报告 §4）。
//   本单不去解释它的来源（超出范围），只保证不把它当成污染而丢掉真值。
//
// 做法：泳道 B fresh world（level-seed = 主种子）→ forceload 门框那片区块 → save-all flush
//       → 停服 → 把 spike_world 拷到 bench/route/probe/_s1_main_fresh/<seed>/。
// 不连 bot、不给 kit、不放任何方块 ⇒ 盘上的世界就是该种子的原样。
//
// 用法：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\stages\portal\gen_scout_world.mjs
//     --seed 4926685115947721762 --x1 176 --z1 296 --x2 192 --z2 320

import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import { argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log } from '../_lib/runner_core.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';

const LANE_B = {
    idx: 1, name: 'B',
    dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577,
    username: 'ScoutBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME),
    java: JAVA,
};

const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const X1 = parseInt(argOf(process.argv, 'x1', '176'), 10);
const Z1 = parseInt(argOf(process.argv, 'z1', '296'), 10);
const X2 = parseInt(argOf(process.argv, 'x2', '192'), 10);
const Z2 = parseInt(argOf(process.argv, 'z2', '320'), 10);
const OUT = argOf(process.argv, 'out', path.join(ROOT, 'bench/route/probe/_s1_main_fresh', SEED));

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 发一条服务端控制台命令（手册 §2：一律 stdin，不走 RCON），等 ms 后返回。 */
function cmd(server, line, ms = 300) {
    return new Promise((res) => {
        try { server.child.stdin.write(`${line}\n`); } catch { /* 忽略 */ }
        setTimeout(() => res(line), ms);
    });
}

async function main() {
    const mem = await waitFreeMem(2560 * 1024 * 1024, log);
    log(`free=${(mem / 1048576).toFixed(0)}MB`);
    freshWorld(LANE_B, SEED);
    log(`freshWorld seed=${SEED}`);
    const RUN_DIR = path.join(BENCH_DIR, 'runs', '_scout');
    fs.mkdirSync(RUN_DIR, { recursive: true });
    const server = await bootServerWithRetry(LANE_B, RUN_DIR, '1G', log);
    log(`server up in ${(server.bootMs / 1000).toFixed(0)}s`);
    const logFile = path.join(LANE_B.dir, 'logs', 'latest.log');
    const size0 = fs.existsSync(logFile) ? fs.statSync(logFile).size : 0;

    // 1.16.1 forceload add 要四个参数（手册 §3），异步加载 ⇒ 必须轮询到不再报 not loaded
    await cmd(server, `forceload add ${X1} ${Z1} ${X2} ${Z2}`, 3000);
    // 让世界把这一片生成出来：tp 一个玩家实体不需要，我们用 time + 多次 forceload query 触发
    for (let i = 0; i < 12; i++) {
        await cmd(server, `forceload query`, 1500);
        await cmd(server, `save-all flush`, 2500);
    }
    const txt = fs.existsSync(logFile) ? fs.readFileSync(logFile, 'utf8').slice(size0) : '';
    console.log('--- 控制台增量（forceload / save） ---');
    for (const line of txt.split(/\r?\n/)) {
        if (/forceload|Force loaded|not loaded|Saving|ERROR|WARN/.test(line)) console.log('  ' + line.slice(0, 190));
    }
    await cmd(server, 'stop', 1000);
    await stopServer(LANE_B, server);

    // 拷一份出来（cleanup 会删 lane 的 world）
    fs.rmSync(OUT, { recursive: true, force: true });
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    fs.cpSync(path.join(LANE_B.dir, 'spike_world'), OUT, { recursive: true });
    const mca = fs.readdirSync(path.join(OUT, 'region'));
    log(`copied → ${OUT}  region files: ${mca.join(',')}`);
    for (const f of fs.readdirSync(path.join(OUT, 'region'))) {
        log(`  ${f} ${fs.statSync(path.join(OUT, 'region', f)).size}B`);
    }
}
main().then(() => process.exit(0)).catch((e) => { console.error('SCOUT_WORLD_FAILED', e); process.exit(1); });
