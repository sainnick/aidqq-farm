// run_portal.mjs — MC-M1-TASK-08 S1+S4a 编排器（**只跑泳道 B 25567/25577**）
//
// 为什么不用 _lib 的 runMatrix：
//   runMatrix 内部固定 `buildLanes({count: cfg.lanes})`，而 buildLanes 的
//   serverPort = 25566 + i 是**写死**的（runner_core.mjs:77），没有任何"从 B 泳道起跑"的参数。
//   硬凑的做法只有 `MC_BENCH_SERVER=…laneB` + `--lanes 1` → 目录对、但 bot 拿到
//   `--port 25566`（主线 A 的端口），静默连错服。
//   本单任务单硬性要求「只用泳道 B」，所以这里**手工构造 lane B 对象**，
//   只 import _lib 的原语（waitFreeMem / freshWorld / bootServerWithRetry / stopServer），
//   **不修改 _lib 任何文件**（手册 §9：_lib 只能新增、不能改）。
//
// 为什么不用 _lib 的 preflight：
//   preflight 对 25566/25576/25567/25568/25578/8091 **全量**判占用，任一被占就是阻塞项。
//   那是为「三线并行、串任务即事故」设计的（对主线完全正确），但对本线只占一条泳道的
//   阶段来说，主线 A 在跑就会把本线一起锁死。本编排器改为**只判本线该占的那一对端口**，
//   并且发现别的线在跑时只**记录**不干预（杀进程一律先问用户，见根 AGENTS.md §2）。
//
// 模式：
//   --mode smoke    1 局 kit 起步冒烟
//   --mode chain    零 kit 真实链（obtain flint_and_steel + obtain bucket），只为记链尾位置/深度
//   --mode panel    开发面板：5 个种子
//   --mode matrix   正式矩阵：--trials 个 fresh seed（默认 10）
//   --mode main     主种子 ×5
//   --mode micro    委托给 micro_bench.mjs（原语微基准）
//   --mode reg      回归：转 basic-bootstrap（主线 A 的代码，本线只负责跑）

import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import { spawn, execSync } from 'child_process';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, killTree, log,
} from '../_lib/runner_core.mjs';
import { cleanup, cleanupSync, installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const NODE20 = path.join(ROOT, '.runtime', 'node-v20.20.2-win-x64', 'node.exe');

// ★ 本线唯一代码根 = worktree。runner 设进 env，bot 继承（standalone bot 读 env）。
const MINDCRAFT_ROOT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
process.env.MC_MINDCRAFT_ROOT = MINDCRAFT_ROOT;

// 1.16.1 环境（1.21.1 漏带会起错 jar → DEPENDENCY_CYCLE 0.3s，见手册 §2）
const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = argOf(process.argv, 'mc-version', '1.16.1');
const RCON_PASS = 'spike-rcon';

// —— 手工构造泳道 B（见文件头「为什么不用 runMatrix」）——
const LANE_B = {
    idx: 1, name: 'B',
    dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577,
    username: 'TaskBotB', rconPass: RCON_PASS,
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME),
    java: JAVA,
};

const MODE = argOf(process.argv, 'mode', 'smoke');
const STAMP = argOf(process.argv, 'stamp', `P8_${MODE}_${new Date().toISOString().slice(0, 13).replace(/[-T:]/g, '')}`);
const TRIALS = parseInt(argOf(process.argv, 'trials', MODE === 'main' ? '5' : MODE === 'panel' ? '5' : '10'), 10);
const SEED_LITERAL = argOf(process.argv, 'seed', '');
const SEEDS = argOf(process.argv, 'seeds', '');
const SEED_PREFIX = argOf(process.argv, 'seed-prefix', STAMP);
const TIMEOUT_MS = parseInt(argOf(process.argv, 'timeout-ms', '900000'), 10);
const NO_PROGRESS_S = parseInt(argOf(process.argv, 'no-progress-s', '120'), 10);
const PROBE_MS = parseInt(argOf(process.argv, 'probe-ms', '10000'), 10);
const KIT = argOf(process.argv, 'kit', '');
const KIT_DEPTH = parseInt(argOf(process.argv, 'kit-depth', '0'), 10);
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const SERVER_XMX = argOf(process.argv, 'server-xmx', '1G');
const FAIL_BUDGET = parseInt(argOf(process.argv, 'fail-budget', '0'), 10);   // 0 = 关
const BOT_TIMEOUT_SLACK = 90000;
const MAIN_SEED = '-8839485814800629942';   // 手册 §7 主种子

const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
fs.mkdirSync(RUNS_DIR, { recursive: true });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const seedFor = (n) => {
    if (SEEDS) { const l = SEEDS.split(',').map((s) => s.trim()); return l[n - 1] ?? `${SEED_PREFIX}-${String(n).padStart(2, '0')}`; }
    if (SEED_LITERAL) return SEED_LITERAL;
    return `${SEED_PREFIX}-${String(n).padStart(2, '0')}`;
};

/** 端口占用（只读观测；不杀任何进程） */
function portBusy(port) {
    try {
        const txt = execSync(`netstat -ano | findstr ":${port} "`, { encoding: 'utf8' });
        return txt.split(/\r?\n/).some((l) => l.includes('LISTENING'));
    } catch { return false; }
}
function foreignLaneNote() {
    const notes = [];
    for (const p of [25566, 25576, 25568, 25578]) {
        if (portBusy(p)) notes.push(p);
    }
    return notes;
}

/**
 * 等本线可以安全开跑。★判据不能只看端口：主线两批之间 25567 会短暂空闲，但那个目录
 * 正被别人循环起停服（P8_PROBE 实测抢进去 freshWorld 报 ENOTEMPTY）。以 _lib 的
 * 「活的 runner 是否拥有这个目录」为准（06c P0 泳道归属心跳）。
 */
async function waitLaneB(maxMs, note) {
    const st = await waitLane(LANE_B, {
        maxMs, pollMs: 20000,
        onWait: (s) => log(`泳道 B 不可用（${s.why}），排队等待`),
    });
    if (!st.usable) note?.(st);
    return st;
}

/** 跑一局：fresh world → boot → bot → 等结果 → 停服 */
async function runTrial(n, seed, extraArgs = [], opts = {}) {
    const trialDir = path.join(RUNS_DIR, `trial_${String(n).padStart(2, '0')}`);
    fs.mkdirSync(trialDir, { recursive: true });
    const row = { trial: n, seed, lane: 'B', startedAt: new Date().toISOString(), outcome: null };

    freshWorld(LANE_B, seed);
    // 删世界目录前必须确认：活着别人的目录绝不碰（P8_PROBE 的 ENOTEMPTY 就是这么来的）
    const stPre = laneStatus(LANE_B);
    if (!stPre.usable) {
        log(`trial ${n}: freshWorld 前泳道 B 不可用（${stPre.why}），等待 90s`);
        await sleep(90000);
        await waitLaneB(10 * 60 * 1000);
    }
    freshWorld(LANE_B, seed);
    // 等内存期间别的线可能把 B 抢走 → 开机前再查一次（宁可等也不要两台服撞同一端口）
    const st = await waitLaneB(10 * 60 * 1000);
    if (!st.usable) log(`trial ${n}: 泳道 B 仍不可用（${st.why}），强行开服可能有风险`);
    const server = await bootServerWithRetry(LANE_B, trialDir, SERVER_XMX, log);
    row.bootMs = server.bootMs;
    log(`trial ${n}: server up in ${(server.bootMs / 1000).toFixed(0)}s (seed=${seed})`);

    // ★★ 顺序修正（P8_SMOKE1 实测踩到）：**先 spawn bot，再注入 kit**。
    //   原来的写法是「先等 server.log 出现 joined the game → 再 spawn bot」，
    //   而那时候 bot 根本还没起 → 120s 必然超时 → 「bot 未进服，跳过 kit」，
    //   bot 却因为带了 --kit-desc 而跳过 kit 门 → 空背包去建门（P8_SMOKE1 实际就是这么废的）。
    //   bot 侧有 kit 闸门（portal_bot.waitForKit：等 kit_done.json + 复核背包），
    //   所以「先起 bot、后给 kit」是它本来预期的顺序。
    const botArgs = [
        path.join(BENCH_DIR, opts.botPath ?? 'portal_bot.mjs'),
        '--trial', String(n), '--seed', seed, '--out', trialDir,
        '--port', String(LANE_B.serverPort), '--username', LANE_B.username,
        '--timeout-ms', String(TIMEOUT_MS), '--mc-version', MC_VERSION,
        '--probe-ms', String(PROBE_MS),
        ...(KIT ? ['--kit-desc', KIT] : []),
        ...(KIT_DEPTH > 0 ? ['--kit-depth', String(KIT_DEPTH)] : []),
        ...extraArgs,
    ];
    const botLog = fs.openSync(path.join(trialDir, 'bot_console.log'), 'a');
    const bot = spawn(NODE20, botArgs, { stdio: ['ignore', botLog, botLog] });

    // kit 走服务器 stdin 控制台（手册 §2：RCON 会毒化服务进程）
    if (KIT) {
        try { LANE_B.serverChild = server.child; server.child.stdin.write(`op ${LANE_B.username}\n`); } catch { /* 忽略 */ }
        await sleep(1200);
        // 等 bot 进服（give 要人在线）；1.16 首个玩家登录要等世界出生点生成，实测能到 2 分钟
        const logPath = path.join(trialDir, 'server.log');
        const t0 = Date.now();
        let joined = false;
        while (Date.now() - t0 < 240000) {
            try { if (fs.readFileSync(logPath, 'utf8').includes('joined the game')) { joined = true; break; } } catch { /* 忽略 */ }
            await sleep(700);
        }
        if (joined) {
            for (const it of KIT.split(',').map((s) => s.trim()).filter(Boolean)) {
                const [name, count] = it.split(':');
                try { server.child.stdin.write(`give ${LANE_B.username} minecraft:${name.trim()} ${String(count ?? '1').trim()}\n`); } catch { /* 忽略 */ }
                await sleep(150);
            }
            await sleep(800);
            const rec = { kit: KIT, username: LANE_B.username, at: new Date().toISOString(), joined: true };
            fs.writeFileSync(path.join(trialDir, 'kit.json'), JSON.stringify(rec, null, 2));
            fs.writeFileSync(path.join(trialDir, 'kit_done.json'), JSON.stringify(rec, null, 2));
            log(`trial ${n}: kit injected = ${KIT}`);
        } else {
            log(`trial ${n}: bot 240s 未进服，kit 未注入`);
        }
    }

    // 监控：退出 / 硬超时 / 无进展（探针签名）
    const res = await new Promise((resolve) => {
        const probePath = path.join(trialDir, 'probe.jsonl');
        const t0 = Date.now();
        let lastSig = null, lastChange = Date.now(), poll = 0;
        const iv = setInterval(() => {
            if (bot.exitCode !== null) { clearInterval(iv); resolve({ code: bot.exitCode }); return; }
            if (Date.now() - t0 > TIMEOUT_MS + BOT_TIMEOUT_SLACK) { clearInterval(iv); killTree(bot.pid); resolve({ code: -9, hardTimeout: true }); return; }
            if (NO_PROGRESS_S > 0 && ++poll % 5 === 0) {
                let sig = null;
                try {
                    const buf = fs.readFileSync(probePath);
                    const tail = buf.subarray(Math.max(0, buf.length - 8192)).toString('utf8');
                    const line = tail.split(/\r?\n/).filter(Boolean).pop();
                    if (line) { const p = JSON.parse(line); sig = JSON.stringify({ i: p.inv ?? null, p: p.pos ?? null, d: !!p.digging, dim: p.dim ?? null, t: p.tree ?? '' }); }
                } catch { /* 忽略 */ }
                if (sig) {
                    if (sig !== lastSig) { lastSig = sig; lastChange = Date.now(); }
                    else if (Date.now() - lastChange > NO_PROGRESS_S * 1000) {
                        clearInterval(iv); killTree(bot.pid);
                        resolve({ code: -8, noProgress: true, frozenMs: Date.now() - lastChange });
                    }
                }
            }
        }, 1000);
        bot.on('exit', (code) => { clearInterval(iv); resolve({ code }); });
    });

    // 岩浆死亡（server.log 权威，判据同 runner_core lavaDeathsIn）
    try {
        const txt = fs.readFileSync(path.join(trialDir, 'server.log'), 'utf8');
        row.lavaDeaths = (txt.match(/tried to swim in lava/g) ?? []).length;
        row.deaths = (txt.match(/has made the journey to the afterlife/g) ?? []).length;
    } catch { row.lavaDeaths = 0; }

    // 结果
    let result = null;
    try { result = JSON.parse(fs.readFileSync(path.join(trialDir, 'result.json'), 'utf8')); } catch { /* 无结果 */ }
    if (res.noProgress) row.outcome = 'FAIL(NO_PROGRESS_ABORT)';
    else if (res.hardTimeout) row.outcome = 'FAIL(RUNNER_TIMEOUT)';
    else if (!result) row.outcome = 'FAIL(NO_RESULT)';
    else if (result.status === 'SUCCESS') row.outcome = 'SUCCESS';
    else row.outcome = `FAIL(${result.failReason ?? result.status ?? '?'})`;
    row.result = result ? {
        status: result.status, failReason: result.failReason ?? null,
        durationMs: result.durationMs ?? null,
        route: result.detail?.route ?? null, dim: result.detail?.dimension ?? null,
        door: result.detail?.door ?? null, netherLanding: result.detail?.netherLanding ?? null,
        stats: result.detail?.stats ?? null,
        realchainTail: result.realchainTail ?? null,
    } : null;
    row.botExit = res.code;
    row.dimChanges = result?.dimChanges ?? [];

    await stopServer(LANE_B, server);
    try { fs.appendFileSync(path.join(RUNS_DIR, 'summary.jsonl'), JSON.stringify(row) + '\n'); } catch { /* 忽略 */ }
    log(`trial ${n}: ${row.outcome} (${row.lavaDeaths} lava deaths, ${((row.result?.durationMs ?? 0) / 1000).toFixed(0)}s)`);
    return row;
}

async function main() {
    if (MODE === 'micro') {
        const p = spawn(NODE20, [path.join(BENCH_DIR, 'micro_bench.mjs'), ...process.argv.slice(2)], { stdio: 'inherit' });
        p.on('exit', (c) => process.exit(c ?? 0));
        return;
    }
    if (MODE === 'reg') {
        // 回归：BASIC-bootstrap 20 局，**跑本线 worktree 的代码**。
        //   为什么不转 basic-bootstrap/run_bench.mjs（转它会踩两个坑）：
        //     ① 它的 exec_bot.mjs:20 把代码根写死成主线 D:\AI斗蛐蛐\mindcraft，
        //        跑的就不是本单代码（任务单 §2 要求「在 worktree 代码上跑」）；
        //        而那个文件是别的 stage 的，任务单 §3 明令不许改 → 本单新增 reg_exec_bot.mjs
        //        （只改那一行常量，协议逐行照抄）。
        //     ② runMatrix 的 serverPort = 25566 + i 写死（runner_core.mjs:77），转过去
        //        bot 会拿到 --port 25566 = **主线 A 的端口**（静默连错服）。
        //   种子直接用 P2C_M4B4 那 20 个（主线 19/20 的那批），结果可直接 A/B。
        const REG_SEEDS = argOf(process.argv, 'seeds',
            'P2C_M4B4-01,P2C_M4B4-02,P2C_M4B4-03,P2C_M4B4-04,P2C_M4B4-05,'
            + 'P2C_M4B4-06,P2C_M4B4-08,P2C_M4B4-09,P2C_M4B4-10,P2C_M4B4-07,'
            + 'P2C_M4B4-11,P2C_M4B4-12,P2C_M4B4-13,P2C_M4B4-14,P2C_M4B4-15,'
            + 'P2C_M4B4-16,P2C_M4B4-17,P2C_M4B4-18,P2C_M4B4-20,P2C_M4B4-19').split(',');
        const regRows = [];
        for (let i = 0; i < TRIALS; i++) {
            const seed = REG_SEEDS[i] ?? `${STAMP}-${String(i + 1).padStart(2, '0')}`;
            const r = await runTrial(i + 1, seed, [], { botPath: 'reg_exec_bot.mjs' });
            regRows.push(r);
            log(`reg ${i + 1}/${TRIALS} ${seed}: ${r.outcome}`);
        }
        const regOk = regRows.filter((r) => r.outcome === 'SUCCESS').length;
        fs.writeFileSync(path.join(RUNS_DIR, 'reg_summary.json'), JSON.stringify({
            stamp: STAMP, codeRoot: MINDCRAFT_ROOT, total: regRows.length, success: regOk,
            baseline: 'P2C_M4B4 = 19/20（主线 mindcraft @e9e49d0 之前）',
            rows: regRows.map((r) => ({ trial: r.trial, seed: r.seed, outcome: r.outcome, ms: r.result?.durationMs ?? null })),
        }, null, 2));
        log(`=== 回归 BASIC-bootstrap：${regOk}/${regRows.length}（验收线 ≥19/20）===`);
        console.log(`RESULT_DIR=${RUNS_DIR}`);
        process.exit(regOk >= Math.ceil(regRows.length * 0.95) ? 0 : 2);
    }

    // 本线泳道闸门：以「活的 runner 是否拥有这个目录」为准，不只看端口（P8_PROBE 教训）
    const st0 = laneStatus(LANE_B);
    if (!st0.usable) {
        console.error(`[portal] 泳道 B 不可用（${st0.why}${st0.owner ? `，归属 ${st0.owner}` : ''}）。`);
        console.error('[portal] 本线是并行开发线，不抢别的线；下面会自动排队等待。');
    }
    const foreign = foreignLaneNote();
    if (foreign.length) log(`注意：其它线端口 ${foreign.join(',')} 正在被使用（本线只占 25567/25577，不干预）`);

    const stW = await waitLaneB(30 * 60 * 1000, (s) => console.error(`[portal] 泳道 B 持续不可用（${s.why}），放弃（不干预别的线，请协调后再跑）`));
    if (!stW.usable) process.exit(1);
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    // 内存排队期间别人可能抢走 B → 真正开跑前复查
    const st2 = await waitLaneB(10 * 60 * 1000, (s) => console.error(`[portal] 内存排队期间泳道 B 被占用（${s.why}），放弃`));
    if (!st2.usable) process.exit(1);

    const meta = {
        stamp: STAMP, stage: `PORTAL+ARRIVE (${MODE})`, lanes: 1,
        lanePorts: [LANE_B.serverPort, LANE_B.rconPort],
        mindcraftRoot: MINDCRAFT_ROOT, mcVersion: MC_VERSION,
        startedAt: new Date().toISOString(),
        params: { mode: MODE, trials: TRIALS, timeoutMs: TIMEOUT_MS, noProgressMs: NO_PROGRESS_S * 1000, kit: KIT || null, kitDepth: KIT_DEPTH || null, minFreeMb: MIN_FREE_MB, failBudget: FAIL_BUDGET || null },
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'run_meta.json'), JSON.stringify(meta, null, 2));

    const trials = MODE === 'chain' ? [1] : MODE === 'main'
        ? Array.from({ length: TRIALS }, (_, i) => ({ n: i + 1, seed: SEED_LITERAL || MAIN_SEED }))
        : Array.from({ length: TRIALS }, (_, i) => ({ n: i + 1, seed: seedFor(i + 1) }));

    // route 相关：开发局必须带 --allow-draft（草稿 frozenAt=null）；正式矩阵不许带。
    // 站 id 只能从命令行给「名字」，**不给坐标**（SCHEMA §3）。
    // ★ r5：补上 --route 透传。r3 起 ROUTE-02 的三份 route 成了权威，
    //   但 extraArgs 只转发了 --station/--trip-dist/--allow-draft，
    //   **--route 被吞掉了** → bot 一直用 portal_bot.mjs 的默认路径。
    //   而那个默认路径指向 B 线的旧草稿（r3 已按 ROUND3 §0.4 移进 fixtures/），
    //   于是 `route_load_failed: route_unreadable` 0.5s 判死（P8R5_SMOKE1）。
    const extraArgs = [
        ...(MODE === 'chain' ? ['--mode', 'realchain'] : []),
        ...(process.argv.includes('--allow-draft') ? ['--allow-draft'] : []),
        ...(argOf(process.argv, 'station', '') ? ['--station', argOf(process.argv, 'station', '')] : []),
        ...(argOf(process.argv, 'route', '') ? ['--route', argOf(process.argv, 'route', '')] : []),
        ...(argOf(process.argv, 'trip-dist', '') ? ['--trip-dist', argOf(process.argv, 'trip-dist', '')] : []),
    ];
    const rows = [];
    let fails = 0;

    // —— 到达确认闸门验收（补充单 §2）——
    //   故意把站心沿 x 轴挪开：20 格（仍在 radius 24 内）应**仍能找到门框**；
    //   挪到 radius 之外必须以 STATION_NOT_CONFIRMED **干净失败**（不卡死、不穿墙、不瞬移）。
    // 判据不依赖任务层内部 summary，直接扫 telemetry 事件（station_confirmed / station_not_confirmed）。
    if (MODE === 'gate') {
        const CASES = [
            { tag: 'OFFSET20', offset: 20, expect: 'CONFIRMED' },
            { tag: 'BEYOND_RADIUS', offset: 48, expect: 'STATION_NOT_CONFIRMED' },
        ];
        const out = [];
        for (let ci = 0; ci < CASES.length; ci++) {
            const c = CASES[ci];
            // ★ 每个 case 必须用**自己的 trial 目录**：trial_01 的 telemetry.jsonl 是追加写的，
            //   两个 case 共用时 `find()` 会拿到上一个 case 的 station_confirmed
            //   （P8_GATE 第一版因此把 BEYOND_RADIUS 判成 CONFIRMED，原始遥测其实是对的）。
            const row = await runTrial(ci + 1, MAIN_SEED, [
                '--allow-draft', '--station-offset', String(c.offset), '--confirm-turns', '4',
            ]);
            const tele = [];
            try {
                const p = path.join(RUNS_DIR, `trial_${String(ci + 1).padStart(2, '0')}`, 'telemetry.jsonl');
                for (const l of fs.readFileSync(p, 'utf8').split(/\r?\n/).filter(Boolean)) {
                    try { tele.push(JSON.parse(l)); } catch { /* 忽略 */ }
                }
            } catch { /* 无遥测 */ }
            const confirmed = tele.find((t) => t.event === 'station_confirmed');
            const notConfirmed = tele.find((t) => t.event === 'station_not_confirmed');
            const frameLocated = tele.find((t) => t.event === 'portal_frame_located');
            const got = confirmed ? 'CONFIRMED' : (notConfirmed ? 'STATION_NOT_CONFIRMED' : 'NONE');
            out.push({
                tag: c.tag, offset: c.offset, expect: c.expect, got,
                pass: got === c.expect,
                turns: confirmed?.turns ?? notConfirmed?.turns ?? null,
                distToCenter: notConfirmed?.dist ?? null,
                frameLocated: !!frameLocated,
                outcome: row.outcome,
                wallMs: row.result?.durationMs ?? null,
                lavaDeaths: row.lavaDeaths ?? 0,
            });
            log(`gate ${c.tag}: expect=${c.expect} got=${got} pass=${out[out.length - 1].pass}`);
        }
        fs.writeFileSync(path.join(RUNS_DIR, 'gate_result.json'), JSON.stringify({ stamp: STAMP, seed: MAIN_SEED, out }, null, 2));
        const allPass = out.every((o) => o.pass);
        console.log(`RESULT_DIR=${RUNS_DIR}`);
        log(`=== 到达确认闸门：${out.filter((o) => o.pass).length}/${out.length} 达标 ===`);
        process.exit(allPass ? 0 : 2);
    }

    for (const t of trials) {
        if (FAIL_BUDGET > 0 && fails >= FAIL_BUDGET) {
            log(`fail-budget 触发（已败 ${fails}/${FAIL_BUDGET}），提前收手`);
            break;
        }
        const row = await runTrial(t.n, t.seed, extraArgs);
        rows.push(row);
        if (row.outcome !== 'SUCCESS') fails++;
    }

    const ok = rows.filter((r) => r.outcome === 'SUCCESS').length;
    const lava = rows.reduce((s, r) => s + (r.lavaDeaths ?? 0), 0);
    meta.finishedAt = new Date().toISOString();
    meta.success = ok; meta.total = rows.length; meta.lavaDeaths = lava;
    meta.outcomes = rows.map((r) => ({ trial: r.trial, seed: r.seed, outcome: r.outcome }));
    fs.writeFileSync(path.join(RUNS_DIR, 'run_meta.json'), JSON.stringify(meta, null, 2));
    log(`=== ${STAMP}: ${ok}/${rows.length} SUCCESS, lava deaths = ${lava} ===`);
    console.log(`RESULT_DIR=${RUNS_DIR}`);
    process.exit(ok === rows.length ? 0 : 2);
}

installRunnerHooks(LANE_B);
main().catch((e) => { console.error(e); process.exit(1); });
