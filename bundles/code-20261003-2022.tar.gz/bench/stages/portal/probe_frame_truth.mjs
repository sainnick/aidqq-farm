// probe_frame_truth.mjs — 真框 14 格的**三通道同一时刻**对账（开一次服）
//
// 为什么必须再测一次：r12 的**报告表格**与它自己的证据文件对不上。
//   · `runs/P8R12_STATE2/parsed_frame.json`（存档解析器）三份快照 worldA/B/C 全都读成
//     (187,42,310) = **air**、且 14 格逐格读数**三份完全相同**；
//   · 而同一目录的 `client_boxes.json`（客户端方块状态）读成 `crying_obsidian`，
//     并且**确实挖了 250.1s**（徒手挖哭泣黑曜石的理论值，r12 报告自己也写了）；
//   · C 线 FRAME-BATCH 的服务端真值也是 `crying_obsidian:1`，样本格正是 (187,42,310)。
// ⇒ **存档读数与另外两条通道矛盾**。手册 §5：「读出全零/异常时先证伪工具，再证伪世界」，
//   而 §5 也说「取证动作必须紧贴它要证明的时刻」——所以这里三条通道**同一时刻**各读一次。
//
// 三条通道：
//   A 服务端控制台 `execute if block … run say <唯一标记>`（权威，标记唯一 ⇒ 无回执配对歧义）
//   B 客户端 `bot.blockAt`（服务端广播的方块包）
//   C 存档 `region/` + C 线 `region_reader`（`save-all flush` 之后立刻复制）
//
// 阳性对照（手册 §4 第 10 条）：
//   · 通道 A 必须能读出 obsidian 与 air 各至少一格（否则是控制台通道坏了，不是世界变了）；
//   · 通道 C 读数区 unknownCells 必须为 0；
//   · 三通道里若有任何一格不一致，原样记录，**不替任一通道圆场**。
//
// 用法：node probe_frame_truth.mjs --stamp P8R13_TRUTH --seed 4926685115947721762

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAMP = argOf(process.argv, 'stamp', 'P8R13_TRUTH');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'TruthBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const LOG_PATH = path.join(RUNS_DIR, 'server.log');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null; let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };
const bname = (x, y, z) => { try { return bot.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };

// 真框 14 格（与生产几何一致：4×5 沿 z，1.16.1 顶行两角可选）
const FRAME_CELLS = [];
for (let u = 0; u < 4; u++) {
    FRAME_CELLS.push({ at: [187, 39, 307 + u], kind: 'bottom', optional: u === 0 || u === 3 });
    FRAME_CELLS.push({ at: [187, 43, 307 + u], kind: 'top', optional: u === 0 || u === 3 });
}
for (let dy = 1; dy <= 3; dy++) {
    FRAME_CELLS.push({ at: [187, 39 + dy, 307], kind: 'sideN', dy });
    FRAME_CELLS.push({ at: [187, 39 + dy, 310], kind: 'sideS', dy });
}
// 再加几个决定"怎么走"的格子
const EXTRA = [
    { at: [186, 41, 307], kind: 'ref', why: '西侧 y41 站位（脚下是不是实心）' },
    { at: [186, 40, 307], kind: 'ref', why: '西侧 y41 的脚下' },
    { at: [185, 40, 307], kind: 'ref', why: '再往西一格' },
    { at: [188, 41, 307], kind: 'ref', why: '东侧 y41 站位' },
    { at: [188, 40, 307], kind: 'ref', why: '东侧 y41 的脚下' },
    { at: [187, 40, 308], kind: 'ref', why: '框内岩浆源' },
];
const ALL = [...FRAME_CELLS, ...EXTRA];

const CANDS = ['air', 'obsidian', 'crying_obsidian', 'lava', 'netherrack'];

/** 按**字节**读 server.log 增量（日志里有中文，按字符串长度回退会算错偏移） */
function makeLogTail() {
    let off = 0;
    return () => {
        if (!fs.existsSync(LOG_PATH)) return '';
        const st = fs.statSync(LOG_PATH);
        if (st.size < off) off = 0;
        if (st.size === off) return '';
        const fd = fs.openSync(LOG_PATH, 'r');
        const buf = Buffer.alloc(st.size - off);
        fs.readSync(fd, buf, 0, buf.length, off);
        fs.closeSync(fd);
        off = st.size;
        return buf.toString('utf8');
    };
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[truth] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[truth] server up in ${(server.bootMs / 1000).toFixed(0)}s`);

    const tail = makeLogTail();
    await sleep(1500);
    tail();   // 把启动噪声吃掉，之后只认自己发的标记

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    await sleep(3000);
    cmd(`op ${LANE_B.username}`);
    cmd(`forceload add 167 287 207 327`);
    await sleep(2000);
    cmd(`tp ${LANE_B.username} 185 41 307`);
    // 等客户端真的看到框（blockAt 不再 null），再等它稳定
    for (let k = 0; k < 80; k++) {
        if (bname(187, 41, 307) !== null && bname(187, 43, 308) !== null) break;
        await sleep(500);
    }
    await sleep(2000);
    tail();

    // ---- 通道 A：服务端控制台逐格逐候选（标记唯一 ⇒ 没有回执配对歧义）----
    const seen = new Set();
    const marks = [];
    for (const c of ALL) {
        const [x, y, z] = c.at;
        for (const cand of CANDS) {
            const mk = `TRUTH_${x}_${y}_${z}_${cand}`;
            marks.push(mk);
            cmd(`execute if block ${x} ${y} ${z} minecraft:${cand} run say ${mk}`);
        }
    }
    const deadline = Date.now() + 90 * 1000;
    while (seen.size < marks.length && Date.now() < deadline) {
        const chunk = tail();
        for (const m of marks) if (!seen.has(m) && chunk.includes(m)) seen.add(m);
        if (seen.size < marks.length) await sleep(400);
    }
    for (const m of marks) if (!seen.has(m)) seen.add(`__TIMEOUT__${m}`);

    const serverTruth = ALL.map((c) => {
        const [x, y, z] = c.at;
        for (const cand of CANDS) if (seen.has(`TRUTH_${x}_${y}_${z}_${cand}`)) return cand;
        return 'none-of-candidates';
    });

    // ---- 通道 B：客户端 ----
    const clientTruth = ALL.map((c) => bname(...c.at) ?? 'null');

    // ---- 通道 C：存档（save-all flush 之后立刻复制）----
    cmd('save-all flush');
    await sleep(8000);
    const WORLD = path.join(LANE_B.dir, 'spike_world');
    const snapDir = path.join(RUNS_DIR, 'worldA');
    const rs = path.join(WORLD, 'region'), rd = path.join(snapDir, 'region');
    fs.mkdirSync(rd, { recursive: true });
    for (const f of fs.readdirSync(rs)) fs.copyFileSync(path.join(rs, f), path.join(rd, f));
    const { openWorld } = await import('../../route/tools/region_reader.mjs');
    const w = openWorld(snapDir, { dims: ['overworld'] });
    const archTruth = ALL.map((c) => w.blockAt(c.at[0], c.at[1], c.at[2], 'overworld'));

    // ---- 对账 ----
    const rows = ALL.map((c, i) => ({
        at: c.at.join(','), kind: c.kind, optional: !!c.optional, why: c.why ?? '',
        server: serverTruth[i], client: clientTruth[i], archive: archTruth[i],
        agree: serverTruth[i] === clientTruth[i] && clientTruth[i] === archTruth[i],
    }));
    const out = { seed: SEED, stamp: STAMP, at: new Date().toISOString(), cands: CANDS, rows, stats: { ...w.stats } };
    fs.writeFileSync(path.join(RUNS_DIR, 'frame_truth_3ch.json'), JSON.stringify(out, null, 2));

    log('\n[truth] 三通道对账（server / client / archive）');
    for (const r of rows) {
        log(`  (${r.at.padEnd(12)}) ${r.kind.padEnd(7)}${r.optional ? '可选 ' : '     '} srv=${r.server.padEnd(18)} cli=${r.client.padEnd(18)} arc=${r.archive.padEnd(18)} ${r.agree ? '✅' : '❌不一致'}`);
    }
    const bad = rows.filter((r) => !r.agree);
    log(`\n[阳性对照] server 读到 obsidian 的格数=${serverTruth.filter((n) => n === 'obsidian').length}，air=${serverTruth.filter((n) => n === 'air').length}，超时标记=${[...seen].filter((s) => s.startsWith('__TIMEOUT__')).length}`);
    log(`[阳性对照] archive unknown 统计=${JSON.stringify(w.stats)}`);
    log(`\n[结论] 三通道全一致 ${rows.length - bad.length}/${rows.length}；不一致 ${bad.length} 格`);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
