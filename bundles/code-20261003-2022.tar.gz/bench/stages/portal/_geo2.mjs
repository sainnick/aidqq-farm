// 临时：打印门框一带真实方块名（用完删）
import { openWorld } from '../../route/tools/region_reader.mjs';
const W = 'D:/AI斗蛐蛐/bench/route/probe/_bedhunt';
const w = openWorld(W, { dims: ['overworld'] });
const interesting = (n) => n !== 'air' && n !== 'cave_air' && n !== 'void_air';
// 1) 死亡点一带 (174,28..32,291..295)
console.log('=== 死亡点一带 x172..176 y28..32 z291..295 ===');
for (let y = 32; y >= 28; y--) {
  const row = [];
  for (let z = 291; z <= 295; z++) {
    const r = [];
    for (let x = 172; x <= 176; x++) r.push(`${x},${y},${z}=${w.blockAt(x, y, z)}`);
    row.push(r.join(' '));
  }
  console.log(`y=${y} | ` + row.join('  ||  '));
}
// 2) 门框：所有非空气格 x183..192 y36..46 z303..313，按名字分组
console.log('\n=== 门框区 非空气格 (x183..192, y36..46, z303..313) ===');
const byName = new Map();
for (let y = 36; y <= 46; y++) for (let z = 303; z <= 313; z++) for (let x = 183; x <= 192; x++) {
  const n = w.blockAt(x, y, z);
  if (!interesting(n)) continue;
  if (!byName.has(n)) byName.set(n, []);
  byName.get(n).push(`${x},${y},${z}`);
}
for (const [n, list] of [...byName.entries()].sort((a, b) => b[1].length - a[1].length)) {
  console.log(`  ${n} (${list.length}): ${list.length <= 24 ? list.join(' ') : list.slice(0, 24).join(' ') + ' …'}`);
}
// 3) 框内候选：x=186..190, y=38..43, z=305..312 的 obsidian/crying 精确表
console.log('\n=== 门框区 obsidian/crying_obsidian 精确坐标 ===');
for (let y = 38; y <= 44; y++) {
  const row = [];
  for (let z = 305; z <= 312; z++) {
    const r = [];
    for (let x = 185; x <= 190; x++) {
      const n = w.blockAt(x, y, z);
      r.push(n === 'obsidian' ? 'O' : n === 'crying_obsidian' ? 'C' : n === 'lava' || n === 'flowing_lava' ? 'L' : n === 'magma_block' ? 'M' : interesting(n) ? '#' : '.');
    }
    row.push(`z${z}:` + r.join(''));
  }
  console.log(`y=${y} x185..190 ` + row.join(' '));
}
