// probe_lava_dispose.mjs — 门内那 2 格岩浆到底怎么处理才不烧死 bot（r5 决定性一步）
//
// r5 已确认的硬事实（全部服务端真值）：
//   · 门 origin=(187,39,307)；**必需补 3 格**（门槛 ≤3 内）：netherrack(187,39,307)、
//     air(187,42,307)、crying_obsidian(187,42,310)
//   · 门内**只有 2 格**岩浆（187,40,308 / 187,40,309），其余 6 格岩浆在框外
//   · 门 32 格内**没有水**；500 个"水源"全在 68 格外（超出扫描半径的假象），
//     门→水源的路在第 1 段就断了 ⇒ **浇水浇灭这条路走不通**
//   · 到岩浆源的导航**已修好**（目标改成源块旁的实心格 ⇒ 实测 OK）
//
// ⇒ 死局：「浇灭岩浆要水」+「附近没水」。所以本脚本验证另一条真人思路：
//   **用桶把门内的岩浆舀走**（不是浇灭，是舀掉）——门框内部留空即可点火。
//   这是原版玩家的标准操作之一，且**只需要岩浆源、不需要水**。
//
// 要验三件事：
//   Q1 舀走一格岩浆要几个桶？（1.16 舀岩浆 = 空桶变 lava_bucket，桶不会消失，
//      所以理论上 1 个桶反复舀-倒 就够，但倒到哪要选个不碍事的地方）
//   Q2 舀完门内 2 格后，框内是否变成 air（能点火）？
//   Q3 ★ 岩浆死亡风险：舀的时候人站在哪？会不会因为 lavaGuard 失效而掉进浆里？
//      （补充二把「岩浆死亡 0」列为硬线，这条必须实测）
//
// 只取证，不改任务层；泳道只有 B。
// 用法：node probe_lava_dispose.mjs --seed 4926685115947721762 --stamp P8R5_DISPOSE

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');
const pf = require('mineflayer-pathfinder');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAMP = argOf(process.argv, 'stamp', 'P8R5_DISPOSE');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'DispBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null;
let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };
const bname = (x, y, z) => { try { return bot.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };
const LIQ = new Set(['lava', 'flowing_lava', 'water', 'flowing_water']);
const AIR = new Set(['air', 'cave_air', 'void_air']);

const DOOR = { x: 187, y: 39, z: 307 };
const IN_LAVA = [[187, 40, 308], [187, 40, 309]];
const LAVA_SRC = [186, 40, 307];      // r5 实测：旁边的实心格 187,41,307 走得到

// 生产原语（直接 import，保证测的是要上线的代码）
let scoopLiquidAt, placeLiquidAt, liquidSourceInfo, standableBeside, isLavaSource;

function standable(t) {
    const cands = [[0, 1, 0], [0, 2, 0], [1, 1, 0], [-1, 1, 0], [0, 1, 1], [0, 1, -1], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];
    for (const [dx, dy, dz] of cands) {
        const fx = t[0] + dx, fy = t[1] + dy, fz = t[2] + dz;
        const feet = bname(fx, fy, fz); const below = bname(fx, fy - 1, fz);
        if (!feet || AIR.has(feet) || LIQ.has(feet)) continue;
        if (below && LIQ.has(below)) continue;
        return [fx, fy, fz];
    }
    return null;
}
async function walkTo(t, label, timeout = 45000) {
    try {
        const p0 = bot.entity.position.floored();
        await bot.pathfinder.goto(new pf.goals.GoalNear(t[0], t[1], t[2], 1), { timeout, lavaGuard: true });
        const p1 = bot.entity.position.floored();
        return { ok: true, from: [p0.x, p0.y, p0.z], to: [p1.x, p1.y, p1.z] };
    } catch (e) { return { ok: false, error: String(e?.message ?? e).slice(0, 120) }; }
}
/** bot 当前是否在浆里（岩浆死亡风险自检） */
function inLiquidNow() {
    const p = bot.entity?.position;
    if (!p) return { in: false };
    const feet = bname(Math.floor(p.x), Math.floor(p.y), Math.floor(p.z));
    const below = bname(Math.floor(p.x), Math.floor(p.y) - 1, Math.floor(p.z));
    return {
        in: LIQ.has(feet) || LIQ.has(below),
        feet: feet ?? null, below: below ?? null,
        pos: [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)],
        onGround: !!p.onGround,
    };
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[disp] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[disp] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[disp] server up in ${(server.bootMs / 1000).toFixed(0)}s`);

    const EX = (f) => import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec', f)).href);
    const liq = await EX('liquid.js');
    const pc = await EX('patch_cell.js');
    scoopLiquidAt = liq.scoopLiquidAt; placeLiquidAt = liq.placeLiquidAt;
    liquidSourceInfo = liq.liquidSourceInfo; isLavaSource = liq.isLavaSource;
    standableBeside = pc.standableBeside;
    log('[disp] 生产原语已加载（liquid.js / patch_cell.js）');

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    bot.loadPlugin(pf.pathfinder);
    await sleep(3500);
    cmd(`op ${LANE_B.username}`);

    const trace = [];
    const deaths = [];
    bot.on('death', () => { deaths.push({ at: new Date().toISOString(), pos: inLiquidNow().pos }); log('[disp] ☠️ bot died'); });

    // ★★ 落地前必须先探好落点：r5 第一版直接 `tp 到门上方 6 格`，
    //   bot 掉下来**正落进门内那 2 格岩浆**、当场烧死（server.log: `tried to swim in lava`）。
    //   这不是脚本的闲笔，正是补充二把「岩浆死亡 0」列为硬线的原因：
    //   **门就在岩浆池边上，任何"从天上掉下来"的落点选择都可能把人送进浆里。**
    //   正确做法：先算一个门外的安全落脚点（实心、非液体），tp 到它**旁边一格**再走过去。
    function safeStandNear(cx, cy, cz, radius = 6) {
        for (let r = 1; r <= radius; r++) {
            for (let dz = -r; dz <= r; dz++) {
                for (let dx = -r; dx <= r; dx++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
                    for (let dy = 2; dy >= -4; dy--) {
                        const fx = cx + dx, fy = cy + dy, fz = cz + dz;
                        const feet = bname(fx, fy, fz);
                        const below = bname(fx, fy - 1, fz);
                        if (feet && !AIR.has(feet) && !LIQ.has(feet) && below && !LIQ.has(below)) {
                            return [fx, fy, fz];
                        }
                    }
                }
            }
        }
        return null;
    }

    const safeSpot = safeStandNear(DOOR.x, DOOR.y, DOOR.z, 6);
    log(`[disp] 门外安全落脚点: ${safeSpot ? safeSpot.join(',') : '❌ 6 格内没找到'}`);
    // tp 到安全点**正上方 1 格**（只下落 1 格，不可能摔进浆），再走过去
    if (safeSpot) {
        cmd(`tp ${LANE_B.username} ${safeSpot[0]} ${safeSpot[1] + 1} ${safeSpot[2]}`);
    } else {
        cmd(`tp ${LANE_B.username} ${DOOR.x} ${DOOR.y + 6} ${DOOR.z + 4}`);
    }
    await sleep(7000);
    cmd(`give ${LANE_B.username} minecraft:bucket 2`);
    await sleep(2500);
    const inv0 = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',');
    const landed = inLiquidNow();
    log(`[disp] 初始背包: ${inv0}｜落点=${landed.pos} 在浆里=${landed.in}（脚下=${landed.below}）`);

    // ——— Q1/Q2/Q3：逐格舀走门内岩浆 ———
    for (const cell of IN_LAVA) {
        const lava = new Vec3(cell[0], cell[1], cell[2]);
        const before = { cell, got: bname(...cell), at: inLiquidNow() };
        // 站到岩浆旁的实心格（★不能用岩浆格本身当导航目标）
        const stand = standableBeside(bot, lava) ?? standable(cell);
        const walk = await walkTo(stand ?? [cell[0], cell[1] + 1, cell[2]], 'disp_approach');
        const standTxt = stand ? `${stand.x},${stand.y},${stand.z}` : 'none';
        trace.push({ step: 'approach', cell, stand, walk, at: inLiquidNow() });
        log(`[disp] 站到 ${standTxt}: ${walk.ok ? 'OK' : 'FAIL ' + walk.error}｜在浆里=${inLiquidNow().in}`);

        if (!walk.ok) continue;
        // 舀（生产原语 scoopLiquidAt）
        const s = await scoopLiquidAt(bot, lava, { telemetry: (e, d) => trace.push({ step: 'tele', event: e, d }), label: 'disp_scoop', maxTries: 2 });
        const got = bname(...cell);
        const inv = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',');
        trace.push({ step: 'scoop', cell, ok: s.ok, kind: s.kind, reason: s.reason ?? null, after: got, inv, at: inLiquidNow() });
        log(`[disp] 舀 ${cell.join(',')}: ${s.ok ? `OK(${s.kind})` : `FAIL ${s.reason}`} → 该格现在=${got}｜在浆里=${inLiquidNow().in}｜背包=${inv}`);
    }

    // 舀走后门内是否干净
    const interiorAfter = IN_LAVA.map((c) => ({ cell: c, got: bname(...c) }));

    // Q1 补充：满桶怎么处理（倒掉再舀下一格）
    const invEnd = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',');
    const lavaBucketCount = bot.inventory.items().filter((i) => i.name === 'lava_bucket').length;
    log(`[disp] 结束背包: ${invEnd}（lava_bucket=${lavaBucketCount}）`);

    // 岩浆死亡判定（server.log 权威）
    let lavaDeaths = 0; let deathLines = [];
    try {
        const txt = fs.readFileSync(path.join(RUNS_DIR, 'server.log'), 'utf8');
        lavaDeaths = (txt.match(/tried to swim in lava/g) ?? []).length;
        deathLines = txt.split(/\r?\n/).filter((l) => /afterlife|swim in lava/i.test(l));
    } catch { /* 忽略 */ }

    const out = {
        seed: SEED, stamp: STAMP, at: new Date().toISOString(),
        door: DOOR, interiorLava: IN_LAVA,
        inv0, invEnd, lavaBucketCount,
        interiorAfter, trace, deaths, lavaDeaths, deathLines,
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'lava_dispose.json'), JSON.stringify(out, null, 2));

    const md = [];
    md.push(`# 门内岩浆「舀走」可行性取证（${STAMP}）`, '');
    md.push(`- 种子 \`${SEED}\`；门 origin=(${DOOR.x},${DOOR.y},${DOOR.z})`);
    md.push(`- 初始背包：${inv0}｜结束背包：${invEnd}`, '');
    md.push('## 逐格舀走', '');
    for (const t of trace.filter((x) => x.step === 'approach' || x.step === 'scoop')) {
        if (t.step === 'approach') {
            const st = t.stand ? `${t.stand.x},${t.stand.y},${t.stand.z}` : 'none';
            md.push(`- **站位** ${st}：${t.walk.ok ? '✅' : `❌ ${t.walk.error}`}｜当时在浆里=${t.at.in}（脚下=${t.at.below}）`);
        } else md.push(`- **舀 ${t.cell.join(',')}**：${t.ok ? `✅ ${t.kind}` : `❌ ${t.reason}`} → 该格现在 **${t.after}**｜在浆里=${t.at.in}｜背包=${t.inv}`);
    }
    md.push('', '## 结果', '');
    md.push(`- 门内 2 格舀完后：${interiorAfter.map((i) => `${i.cell.join(',')}=${i.got}`).join(' | ')}`);
    md.push(`- **满桶数 = ${lavaBucketCount}**（1.16 舀岩浆不消耗桶，只把它灌满）`);
    md.push(`- **岩浆死亡 = ${lavaDeaths}**（server.log 权威）｜bot death 事件 = ${deaths.length}`);
    if (deathLines.length) md.push(`  - ${deathLines.slice(0, 5).join(' / ')}`);
    const mdTxt = md.join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'lava_dispose.md'), mdTxt);
    console.log(mdTxt);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
