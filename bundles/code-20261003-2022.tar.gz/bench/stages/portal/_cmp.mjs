// 临时：对拍两个世界 + 读 level.dat 种子（用完删）
import fs from 'node:fs';
import zlib from 'node:zlib';
import { openWorld } from '../../route/tools/region_reader.mjs';

function readSeed(dir) {
    const raw = fs.readFileSync(`${dir}/level.dat`);
    let i = 0;
    const u8 = () => raw[i++];
    const i8 = () => { const v = raw.readInt8(i); i += 1; return v; };
    const i16 = () => { const v = raw.readInt16BE(i); i += 2; return v; };
    const i32 = () => { const v = raw.readInt32BE(i); i += 4; return v; };
    const i64 = () => { const v = raw.readBigInt64BE(i); i += 8; return v; };
    const str = () => { const n = i16(); const s = raw.toString('utf8', i, i + n); i += n; return s; };
    const skip = (t) => {
        if (t === 0) i += 1;
        else if (t === 1) i += 1;
        else if (t === 2) i += 2;
        else if (t === 3) i += 4;
        else if (t === 4) i += 8;
        else if (t === 5) i += 4;
        else if (t === 6) i += 8;
        else if (t === 7) i += 8 + raw.readInt32BE(i);
        else if (t === 8) { str(); }
        else if (t === 9) { const n = i8(); i += 1 + Math.max(0, n) * 1; }
        else if (t === 10) { for (;;) { const tt = u8(); if (tt === 0) break; skip(tt); } }
        else if (t === 11) i += 4 * i32();
        else if (t === 12) i += 8 * i32();
    };
    i = 0;
    const t1 = u8(); skip(t1);           // root compound name
    const n = i16();
    for (let k = 0; k < n; k++) {
        const name = str();
        const type = u8();
        if (name === 'Data') {
            const dn = i16();
            for (let j = 0; j < dn; j++) {
                const dnm = str(); const dt = u8();
                if (dt === 8) return { seed: str(), field: `Data.${dnm}` };
                if (dt === 4) return { seed: `${i64()}`, field: `Data.${dnm}` };
                skip(dt);
            }
        }
        skip(type);
    }
    return { seed: 'NOT_FOUND' };
}

const A = 'D:/AI斗蛐蛐/bench/route/probe/_bedhunt';
const B = 'D:/AI斗蛐蛐/bench/route/probe/_s1_main_fresh/4926685115947721762';
console.log('_bedhunt  seed =', JSON.stringify(readSeed(A)));
console.log('fresh     seed =', JSON.stringify(readSeed(B)));

const wa = openWorld(A, { dims: ['overworld'] });
const wb = openWorld(B, { dims: ['overworld'] });
const probes = [
    [187, 42, 310], [187, 43, 308], [187, 39, 307], [187, 40, 309], [186, 40, 309],
    [174, 30, 293], [174, 29, 293], [206, 64, 242], [0, 0, 0], [187, 39, 309], [190, 40, 309], [190, 36, 303],
];
console.log('\ncell               bedhunt              fresh');
for (const [x, y, z] of probes) {
    console.log(`${x},${y},${z}`.padEnd(18), String(wa.blockAt(x, y, z)).padEnd(20), String(wb.blockAt(x, y, z)));
}
// 区块是否真的生成了：r.0.0 的扇区表
function sectors(file) {
    const fd = fs.openSync(file, 'r');
    const head = Buffer.alloc(8192);
    fs.readSync(fd, head, 0, 8192, 0);
    const cnt = head.readUInt32BE(0);
    const arr = [];
    for (let i = 0; i < cnt; i++) arr.push(head.readUInt32BE(4 + i * 4));
    fs.closeSync(fd);
    return { count: cnt, nonzero: arr.filter((v) => v > 0).length };
}
console.log('\nbedhunt r.0.0 :', JSON.stringify(sectors(`${A}/region/r.0.0.mca`)));
console.log('fresh    r.0.0 :', JSON.stringify(sectors(`${B}/region/r.0.0.mca`)));
