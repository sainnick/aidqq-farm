// verify_load.mjs — 离线自检：不连服，只确认新模块能加载 + 液体源块判据在 1.16.1 数据上正确
// （手册 §5：扫描/核验工具读出异常时，先证伪工具再证伪世界）
import { createRequire } from 'module';
const require = createRequire('D:/AI斗蛐蛐/mindcraft-wt/s1-portal/main.js');
const path = 'file:///D:/AI斗蛐蛐/mindcraft-wt/s1-portal/src/agent/tasks/exec/';

const mods = {};
for (const f of ['liquid.js', 'place_at.js', 'nether.js', 'portal_stage_task.js']) {
    mods[f] = await import(path + f);
    console.log(`load ${f}: OK  exports=${Object.keys(mods[f]).length}`);
}

// —— 关键：1.16.1 源块 = level 0（不是 8）——
// 用本仓装的 minecraft-data 造出真实的 1.16.1 lava 块对象，再喂给 liquidSourceInfo。
const BlockLoader = require('prismarine-block');   // CJS: module.exports = loader
const registry = require('prismarine-registry')('1.16.1');
const Block = BlockLoader(registry);
const mcData = require('minecraft-data')('1.16.1');

console.log('\n--- 1.16.1 lava 状态表 ---');
// registry.blocksByName 才是权威（minecraft-data 的 blocks.json 在这个版本可能没 minStateId）
const lavaDef = registry.blocksByName.lava;
const lavaRaw = mcData?.blocks?.lava ?? null;
console.log('registry: minStateId=', lavaDef?.minStateId, 'maxStateId=', lavaDef?.maxStateId,
    'states=', JSON.stringify(lavaDef?.states?.map?.((s) => `${s.name}x${s.num_values}`) ?? null));
if (lavaRaw) console.log('minecraft-data blocks.lava keys=', Object.keys(lavaRaw).join(','));

// 假 bot：blockAt 直接返回指定 stateId 的块
function fakeBot(stateIdOf) {
    return {
        blockAt(pos) {
            const sid = stateIdOf(Math.floor(pos.x), Math.floor(pos.y), Math.floor(pos.z));
            if (sid == null) return null;
            return Block.fromStateId(sid, 1);
        },
        world: { getColumn: () => null },
        registry,
    };
}
const lavaMin = lavaDef.minStateId;
const sourceBot = fakeBot(() => lavaMin + 0);      // level 0 = 源块
const flowingBot = fakeBot(() => lavaMin + 3);     // level 3 = 流动

const src = mods['liquid.js'].liquidSourceInfo(sourceBot, { x: 0, y: 0, z: 0 });
const flow = mods['liquid.js'].liquidSourceInfo(flowingBot, { x: 0, y: 0, z: 0 });
console.log('\n--- liquidSourceInfo ---');
console.log('源块  :', JSON.stringify({ name: src?.name, level: src?.level, isSource: src?.isSource }));
console.log('流动块:', JSON.stringify({ name: flow?.name, level: flow?.level, isSource: flow?.isSource }));

const ok = src?.isSource === true && flow?.isSource === false && flow?.level === 3;
console.log(`\n判定：源块识别=${src?.isSource} 流动块识别=${flow?.isSource} → ${ok ? '✅ 正确' : '❌ 仍错'}`);
process.exit(ok ? 0 : 2);
