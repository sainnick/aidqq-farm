// micro_two_bucket.mjs — 两桶打法的**完整循环**微基准（ROUND3 主种子定案）
//
// 为什么必须单独做微基准（手册 §4 第 2 条）：
//   两桶打法是一串**有顺序依赖**的动作 —— 舀浆 → 倒浆 → 验源块 → 倒水 → **舀回水**。
//   任何一步静默失败（1.16.1 的液体交互全是静默的：服务端日志零异常），
//   后面每一步都会跟着错，而真链上表现为"补格反复失败"，极难归因。
//   所以要在**受控场景**里把整串跑通 n 次，确认 ≥95%。
//
// 场景（server 权威布景，固定坐标）：
//   门框 = 4×5 最小框，缺 1 格（底行一格是空气）
//   目标缺格正下方 1 格处放**岩浆源**（模拟"缺格旁边就有岩浆"）
//   另备一只岩浆源在几格外，模拟"需要走过去舀"
//   桶 = 1 空桶 + 1 水桶（两桶打法的初始状态）
//
// 判据（每轮独立计数）：
//   ① 舀到岩浆          ② 倒进缺格且**是源块**  ③ 倒水后那格变 **obsidian**
//   ④ **水被舀回桶里**   ← 这一条是整套打法的命根子（不舀回来，第二格就没水了）
//   ⑤ 全程**岩浆死亡 0**
//
// 用法：node micro_two_bucket.mjs --stamp P8R6_MICRO --n 10

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';
// ★ r7：改用 srv_rpc 的**回执通道**发命令（与 SEED-03 / r5 的 micro_bench 同一套）。
//   之前直接 `server.child.stdin.write()` 有两个问题：
//     ① 连发几百条会被服务端静默丢弃（P8_PROBE2 记录过这个坑）；
//     ② 拿不到回执，没法判断命令到底成没成。
import { makeRpc, serveRpc } from './srv_rpc.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');
const pf = require('mineflayer-pathfinder');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const STAMP = argOf(process.argv, 'stamp', 'P8R6_MICRO');
const N = parseInt(argOf(process.argv, 'n', '10'), 10);
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const SEED = argOf(process.argv, 'seed', `${STAMP}-S`);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'MicroBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null; let bot = null;
let rpc = null;            // r7：回执通道（见文件头 import 注释）
let rpcStop = null;
const RPC_DIR = path.join(RUNS_DIR, 'rpc');
const SERVER_LOG = path.join(RUNS_DIR, 'server.log');
// 统一出口：命令一律经 rpc 发（有回执），不再直写 stdin。
// ⚠ `makeRpc` 产出的 `call(dir, id, cmd)` —— **第一个参数是 rpc 对象自己**（它内部
//   用 `dir.reqDir`/`dir.doneDir`），不是 rpc 目录路径。传路径会一路 undefined，
//   结果所有命令**静默超时**、一条都没发出去（表现：server.log 全零）。
//   正确用法见 `micro_bench.mjs`：`await rpc.call(rpc, rpc.nextId('m'), cmd, {...})`。
const cmd = async (c) => {
    if (!rpc) { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } return; }
    try { await rpc.call(rpc, rpc.nextId('m'), c, { timeoutMs: 15000 }); } catch { /* 忽略 */ }
};
// 布景专用：同 cmd，但布景量大、不等回执（避免几百条串行等 ack 拖到分钟级）
const setb = (x, y, z, name) => cmd(`setblock ${x} ${y} ${z} minecraft:${name}`);
const bname = (x, y, z) => { try { return bot?.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };

// ★★ r8：布景闸门的判据**读服务端**，不读客户端。
//   r7 §5.2 已经把这条写下来了（"就绪判据要读服务端回执、不能读客户端 blockAt"），
//   但**布景校验那一处漏改了**，还在用 bname() —— 于是它和 forceload 轮询用了两套标准。
//   实证（P8R8_MICRO）：服务端 `Changed the block` 计数在涨、场景真在成形，
//   客户端视图却还没同步，闸门全判 false，10 轮全废。
//   这里用 SEED-03 R3 / r3_fill.mjs 的标准做法：`execute if block … run say <marker>`
//   + 读 server.log。marker **每问一个就换一个唯一串**（手册 §5 的 FIFO 纪律：
//   迟到的旧回执不能被当成本条的答案，唯一串是唯一可靠的配对方式）。
let sceneProbeSeq = 0;
async function srvIfBlock(x, y, z, blk, tag) {
    const marker = `@@SCENE_${tag}_${sceneProbeSeq++}_${blk}`;
    await rpc.call(rpc, `sc${sceneProbeSeq}`, `execute if block ${x} ${y} ${z} minecraft:${blk} run say ${marker}`, { timeoutMs: 10000 }).catch(() => null);
    // ★ r8：窗口 5s → 8s。布景那 ~300 条 setblock 之后，**服务端线程还在追**，
    //   第一条 `execute if block` 排在队列末尾，5 秒内答不上来。
    //   实证（P8R8_SMOKE）：两轮的 `miss` 标记**最终都出现在 server.log 里**
    //   （tag 统计 miss=2），只是晚于轮询窗口 —— 即"格子是对的，是我问得太急"。
    for (let k = 0; k < 32; k++) {                     // 上限 8s
        await sleep(250);
        try { if (fs.readFileSync(SERVER_LOG, 'utf8').includes(marker)) return true; } catch { /* 日志还没生成 */ }
    }
    return false;
}

// —— 布景（单一真源：坐标只在这里定义一次，见手册 §5「场景坐标只能有一个真源」）——
const SCENE = {
    // 门框 origin（缺 1 格：底行中间那格），4 宽沿 x、5 高
    frame: { x: 100, y: 70, z: 100, axis: 'x' },
    // 缺格 = 底行第 2 格（挖掉它，制造"要补的空气格"）
    missing: [101, 70, 100],
    // ★ r8：岩浆源与地面**齐平**（不再挖坑），正下方垫石防漏、不水平铺开。
    //   真正的关键在下面的 `lavaStep` —— 池边高出一格的岸。
    lavaSource: [107, 69, 100],
    // ★★ 岸上的石阶：源块**正西 1 格、高 1 格**的实心块（`standableBeside` 的 `[-1,1,0]`）。
    //   bot 站上去脚在 y=71 ⇒ 岩浆落在下邻**两层**之外 ⇒ `lavaNear` 不拦；
    //   斜向下 2.8 格够得着、视线无遮挡。**必须在西侧**：东侧虽然也能命中 `[1,1,0]`，
    //   但接近路线仍要贴着源块同层走 ⇒ 护栏必拦（实测 SMOKE4 就在 (106,70,100) 被拦）。
    lavaStep: [106, 70, 100],
    // ★ r8：西侧那堵 1 格墙已删（不再由场景逼 bot 爬台阶）——
    //   `walkNear` 的到位判据已改成按**脚下方块**判（设计会话定调），场景不必替它兜底。
    //   留着墙会让微基准测不到判据本身：墙一在，bot 只能站在阶顶。
    // bot 站位（安全、不在液体里；与缺格在 z 上差 2 格——scene.mjs 的布局铁律）
    stand: [99, 71, 102],
    // ★ r8：舀浆站位 = 站在石阶顶面（脚 y=71），正对源块斜下方。
    standLava: [106, 71, 100],
};
const BOT = [SCENE.frame.x - 6, SCENE.frame.y + 8, SCENE.frame.z];

/**
 * 布景前置：确保布景区区块已就绪。
 *
 * ★★★ r7 三处修正（每处都是我自己踩的）：
 *   ① 「1.16.1 没有 /forceload」是**错的**。`/forceload` 1.14 就有；jar 里找不到
 *      `ForceloadCommand.class` 是因为 **jar 是混淆的**（手册 §3 新规则）。
 *      SEED-03 R1/R3 与 C 线的 `bench/route/tools/` 一直在 1.16.1 vanilla 上用它。
 *   ② 参数形式：`forceload add` 在 1.16.1 要**四个**（方块坐标 x1 z1 x2 z2）。
 *      我写两参数 → 服务器回显 "Marked chunk [0, 0]"，什么都没加载。
 *      正确写法见 `bench/route/tools/scan.mjs` 的 forceload()。
 *   ③ ★ 判据**不能用客户端 `bname()`**：客户端要等区块同步到本地，
 *      而服务端 setblock 早就成功了 —— 于是"服务端已就绪、客户端还没数据"会被误判成未就绪，
 *      死循环 60 次（P8R7_MICRO4：服务端 Changed=172，客户端 bname 永远 null）。
 *      SEED-03 R3 的判据是**读服务端回执**（r3_fill.mjs：「区块已到」= fill 不再返回 not loaded，
 *      比 chunkColumnLoad 事件更严格 —— 后者会被空 section 骗过）。
 *      这里用 srv_rpc 的 ack（命令已写进 stdin 并被服务端消化）作为等价判据。
 */
async function ensureChunksLoaded() {
    const S = SCENE;
    const x1 = S.frame.x - 10, z1 = S.frame.z - 10, x2 = S.frame.x + 10, z2 = S.frame.z + 10;
    const probeId = () => `chunkprobe_${Date.now().toString(36)}`;
    // ① forceload（四参数，方块坐标）
    const flId = probeId();
    await rpc.call(rpc, flId, `forceload add ${x1} ${z1} ${x2} ${z2}`, { timeoutMs: 15000 }).catch(() => null);
    await sleep(800);

    // ② 轮询探针：用 rpc 发 setblock，**等 ack**（= 服务端已处理完）。
    //    区块未加载时服务端会回 "That position is not loaded"；加载后就正常执行。
    //    ack 只能证明"命令写进 stdin"，所以再叠加一个**服务端真值查询**做二次确认：
    //    `execute if block <探针> <方块> run say <标记>`，标记出现在 server.log 才算就绪。
    const PROBE_X = S.frame.x, PROBE_Y = S.frame.y - 1, PROBE_Z = S.frame.z;
    const PROBES = ['stone', 'cobblestone', 'dirt', 'sand', 'gravel'];
    for (let i = 0; i < 40; i++) {
        const blk = PROBES[i % PROBES.length];
        const id = probeId();
        await rpc.call(rpc, id, `setblock ${PROBE_X} ${PROBE_Y} ${PROBE_Z} minecraft:${blk}`, { timeoutMs: 15000 }).catch(() => null);
        await sleep(300);
        // 服务端真值确认：让服务端自己说这一格是什么
        const marker = `@@CHUNKOK_${i}_${blk}`;
        const mid = probeId();
        await rpc.call(rpc, mid, `execute if block ${PROBE_X} ${PROBE_Y} ${PROBE_Z} minecraft:${blk} run say ${marker}`, { timeoutMs: 10000 }).catch(() => null);
        await sleep(350);
        try {
            if (fs.readFileSync(SERVER_LOG, 'utf8').includes(marker)) {
                return { ok: true, rounds: i + 1, probe: blk };
            }
        } catch { /* 日志还没生成 */ }
        await sleep(200);
    }
    return { ok: false, rounds: 40 };
}

// ★★ r8 修正（**这一处让 r7 的 10 轮全部白跑**）：buildScene 原来把 ~300 条 setblock
//   **丢进 rpc 队列就返回**（fire-and-forget），调用方只 `await sleep(1200)` 就去判闸门。
//   但光铺 17×17 地面实测就要 **13 秒**（server.log：约 45ms/条）。
//   ⇒ 闸门在第 10 条左右就开跑，**必然**判"布景失败"。
//   server.log 实证（P8R8_MICRO）：闸门 08:08:33 报失败时，地面才铺到 x=92，
//   目标格 (101,69,100) 根本还没发出去。**这不是原语坏，是 harness 自己没等。**
//   现在 buildScene 返回全部 promise，调用方 `await Promise.all` 到真正落到服务端为止。
function buildScene() {
    const ps = [];
    // 铺一块石台
    for (let dx = -8; dx <= 8; dx++) {
        for (let dz = -8; dz <= 8; dz++) {
            ps.push(setb(SCENE.frame.x + dx, SCENE.frame.y - 1, SCENE.frame.z + dz, 'stone'));
        }
    }
    // 门框：4 宽 × 5 高，只缺 missing 那一格
    for (let u = 0; u < 4; u++) {
        ps.push(setb(SCENE.frame.x + u, SCENE.frame.y, SCENE.frame.z, u === 1 ? 'air' : 'obsidian'));   // 底行缺 u=1
        ps.push(setb(SCENE.frame.x + u, SCENE.frame.y + 4, SCENE.frame.z, 'obsidian'));                  // 顶行
    }
    for (let dy = 1; dy <= 3; dy++) {
        ps.push(setb(SCENE.frame.x, SCENE.frame.y + dy, SCENE.frame.z, 'obsidian'));
        ps.push(setb(SCENE.frame.x + 3, SCENE.frame.y + dy, SCENE.frame.z, 'obsidian'));
    }
    // 内部 2×3 必须是空气（点火前提）
    for (let u = 1; u <= 2; u++) {
        for (let dy = 1; dy <= 3; dy++) ps.push(setb(SCENE.frame.x + u, SCENE.frame.y + dy, SCENE.frame.z, 'air'));
    }
    // ★★★ r8 重做岩浆几何（**这一处是 `approach_fail` + 岩浆死亡的共同根因**）
    //
    // 证据（P8R8_SMOKE3/runs/telemetry.json，服务端与客户端双证）：
    //   nav_lava_guard {"lavaAt":[107,69,100],"bot":[107,71,100]}
    //   nav_lava_retreat {"lavaAt":[107,69,100],"to":[107,71,100]}   ← 目标=当前格，**空操作**
    //   walk_near_navfail {"dist":1.91,"want":[108,69,100],"at":[107.6,70.8,100.5]}
    //   server.log: MicroBotB tried to swim in lava
    //
    // 根因链（`nav.js` 的 `lavaNear` 语义，不是原语坏）：
    //   ① 护栏对「脚下四邻 y-1」的岩浆是**无条件拦截**（`lavaAt(p.offset(dx,-1,dz), false)`，
    //      strict=false ⇒ 不看运动方向）。
    //   ② `standableBeside` 的候选表按顺序是 `[0,1,0] [0,2,0] [1,1,0] … [1,0,0] …`。
    //      我 r8 把 (108,70,100) 设成了**空气**（3×3 干台的净空），
    //      于是 `[1,1,0]` 被跳过，候选**掉到同层的 `[1,0,0]` = (108,69,100)**。
    //   ③ bot 站上 (108,69,100) ⇒ 脚在 y=70 ⇒ 岩浆 (107,69,100) 正好落在**下邻格** ⇒ 护栏必响。
    //   ④ 响了就 `retreatFromLava`，而 bot 此时**正悬在岩浆正上方**（dx=dz=0），
    //      撤离目标 = 当前格 = 空操作 ⇒ bot 落回岩浆顶面 ⇒ **岩浆死亡**。
    //
    // 正确几何（不改生产代码）：让候选停在 **`[1,1,0]`** ——
    //   源块与地面齐平，**东侧放一块高 1 格的石阶** `(108,70,100)`。
    //   bot 站上石阶 ⇒ 脚在 y=71 ⇒ 岩浆在**下邻两层之外** ⇒ 护栏**不响**；
    //   且岩浆在斜下方 2.8 格（够 4.5 的交互距离），**视线无遮挡**（r8 实测视线可命中）。
    //   这也正是真人姿势：站在池边高出一格的岸上，斜身舀池角的岩浆。
    const L = SCENE.lavaSource;
    ps.push(setb(L[0], L[1] - 1, L[2], 'stone'));        // 源块正下方垫石：岩浆源不会往下漏
    ps.push(setb(L[0], L[1] + 1, L[2], 'air'));          // 源块正上方：必须是空气（否则 `[0,1,0]` 先命中，视线被自家石阶挡死）
    ps.push(setb(L[0], L[1] + 2, L[2], 'air'));          // `[0,2,0]` 同样要跳过
    ps.push(setb(L[0] + 1, L[1] + 1, L[2], 'air'));      // ★ 东侧留空：把候选逼到西侧 `[-1,1,0]`
    ps.push(setb(L[0] - 1, L[1] + 1, L[2], 'stone'));    // ★★ 西侧石阶 = `standableBeside` 的 `[-1,1,0]`
    ps.push(setb(L[0] - 1, L[1] + 2, L[2], 'air'));      // 阶上净空
    // ⚠ 以下两格必须是 **y = L[1]+1（脚高层）**，**不是 L[1]**。
    //   我第一版写成 L[1]（=69，地板层），等于在地板上开了两个洞：
    //   岩浆立刻从 (107,69,100) 横向漏进 (106,69,100) → 灌进下面的天然洞穴满地蔓延
    //   （遥测实证 `lavaAt:[106,67,101]` / `[106,68,100]`）；
    //   同时石阶的 `below` 变成岩浆 ⇒ `standableBeside` 把它判掉 ⇒ 候选掉回同层 ⇒ 又撞护栏。
    //   **教训：场景里凡"要留空的格子"，必须先确认它不是承重的那一层。**
    // ⚠⚠ 第二版我又多写了一条「阶正面 (106,70,100) = air」——**那正是石阶自己**，
    //   后写的 air 把 stone 覆盖掉 ⇒ 闸门 `lavaStepOk:false` 当场抓住（这正是新增闸门的价值）。
    //   石阶的"正面"就是下面这两个南北落脚格，**不需要**再单独定义一格。
    ps.push(setb(L[0] - 1, L[1] + 1, L[2] + 1, 'air'));  // 阶南落脚
    ps.push(setb(L[0] - 1, L[1] + 1, L[2] - 1, 'air'));  // 阶北落脚
    // ★ r8：**删掉西侧那堵墙**。上一版靠"把『旁边』变成不可达"来逼 bot 爬上去 ——
    //   那是**场景替生产代码兜底**：真正的修法是 `walkNear` 的到位判据
    //   按**脚下方块**判（设计会话定调），墙就不该存在了。
    //   留着它会让微基准**测不到**判据本身：墙一在，bot 只能站在阶顶，
    //   `beside_not_on` 那条分支永远走不到。
    ps.push(setb(...SCENE.lavaSource, 'lava'));           // ★ 最后放源块（顺序：先改地形再放岩浆）
    // ★ r8：主站位仍是 3×3 干台（止溺），但**不再给岩浆源铺台** ——
    //   铺台会把石阶刷成空气，退回同层候选，就又踩中护栏了。
    padInto(ps, SCENE.stand[0], SCENE.stand[1], SCENE.stand[2]);
    return ps;
}

// ★★ r8：**干式站位台**。
//   r7 把"岩浆死亡"修好了（`tried to swim in lava` = 0，server.log 权威），
//   但冒烟（P8R8_SMOKE）里 bot 是**溺水**死的：`MicroBotB drowned`。
//   根因：站位 (99,71,102) 落在**自然地形的水体**里（y≈70 的河/湖），
//   bot 被 tp 过去后泡在水里，扛不过布景那 13 秒窗口。
//   → 站位改成 **3×3 实心台 + 3×3×2 净空**（把水整格清掉），tp 直接落在台面上。
//   真实世界的门边也确实该是干的：真人不会泡在水里舀桶。
function padInto(ps, cx, cy, cz, skip = []) {
    for (let dx = -1; dx <= 1; dx++) {
        for (let dz = -1; dz <= 1; dz++) {
            const x = cx + dx, z = cz + dz;
            const skipped = skip.some(([sx, sy, sz]) => sx === x && sy === cy - 1 && sz === z);
            if (!skipped) ps.push(setb(x, cy - 1, z, 'stone'));   // 台面
            ps.push(setb(x, cy, z, 'air'));                       // 脚下
            ps.push(setb(x, cy + 1, z, 'air'));                   // 头空间（**水在这里被清掉**）
        }
    }
    return ps;
}

// ★ r8：轮次开始的安全台。
//   r7 立下的硬规矩是"tp 必须排在轮次最前"（否则 bot 在 470 格外的出生点游荡踩岩浆），
//   但**不能直接 tp 到站位**——那是水（冒烟实测溺水）。
//   所以：先在场景正上方架一块 3×3 干台，tp 到那儿；布景完、闸门过，再 tp 到真正的站位台。
//   （forceload 是**世界级持久**的，第 2 轮起 ensureChunksLoaded 第一发探针就过，所以这个窗口很短。）
const STAGING = [SCENE.frame.x - 6, SCENE.frame.y + 20, SCENE.frame.z];
function buildStaging() { return padInto([], STAGING[0], STAGING[1], STAGING[2]); }

/** bot 是否还活着；死了就 respawn（r7：死着会卡在死亡界面，后续 give/tp 全落空） */
async function ensureAlive(i) {
    if (bot?.entity) return true;
    try { bot?.respawn(); } catch { /* 忽略 */ }
    for (let k = 0; k < 30; k++) { if (bot?.entity) { log(`[micro] 第 ${i} 轮 bot 已 respawn`); return true; } await sleep(200); }
    log(`[micro] ⚠️ 第 ${i} 轮 bot 死亡后 respawn 失败`);
    return false;
}

/**
 * 布景闸门（**服务端真值**）。整组**最多 3 遍**：
 * 只要有一遍全过就算过；只有 3 遍都还有 false 才是布景失败。
 * —— 不要把"服务端刚吃完 300 条 setblock 还没答上话"判成布景失败（P8R8_SMOKE 的教训）。
 */
async function sceneGate(i) {
    const one = async () => ({
        missingIsAir: await srvIfBlock(...SCENE.missing, 'air', 'miss'),
        belowMissingSolid: await srvIfBlock(SCENE.missing[0], SCENE.missing[1] - 1, SCENE.missing[2], 'stone', 'below'),
        lavaSourceOk: await srvIfBlock(...SCENE.lavaSource, 'lava', 'lava'),
        lavaEnclosed: await srvIfBlock(SCENE.lavaSource[0] + 1, SCENE.lavaSource[1], SCENE.lavaSource[2], 'stone', 'enc'),
        // ★★ r8 新增：**源块必须完全封闭**（下 + 四邻全是石头）。
        //   这一条是"岩浆满地蔓延"的**唯一**有效闸门：我把三格"要留空"写成了地板层，
        //   岩浆就从洞里灌进下面的天然洞穴（实测蔓延到 y=67，差 3 格），
        //   之后石阶 `below` 变岩浆 → `standableBeside` 判掉 → 候选掉回同层 → 护栏拦 → 落浆。
        //   三个下游症状共用一个上游原因，**所以要在上游一次拦住**。
        lavaSealedBelow: await srvIfBlock(SCENE.lavaSource[0], SCENE.lavaSource[1] - 1, SCENE.lavaSource[2], 'stone', 'sealD'),
        lavaSealedW: await srvIfBlock(SCENE.lavaSource[0] - 1, SCENE.lavaSource[1], SCENE.lavaSource[2], 'stone', 'sealW'),
        lavaSealedE: await srvIfBlock(SCENE.lavaSource[0] + 1, SCENE.lavaSource[1], SCENE.lavaSource[2], 'stone', 'sealE'),
        lavaSealedN: await srvIfBlock(SCENE.lavaSource[0], SCENE.lavaSource[1], SCENE.lavaSource[2] - 1, 'stone', 'sealN'),
        lavaSealedS: await srvIfBlock(SCENE.lavaSource[0], SCENE.lavaSource[1], SCENE.lavaSource[2] + 1, 'stone', 'sealS'),
        lavaStepSupport: await srvIfBlock(SCENE.lavaStep[0], SCENE.lavaStep[1] - 1, SCENE.lavaStep[2], 'stone', 'stepsup'),
        // ★ r8 新增：**西岸石阶 + 西侧墙必须在位**。它们共同决定
        //   `standableBeside` 停在 `[-1,1,0]`（护栏不响、视线可达、且 bot 必须真爬上去），
        //   还是退到同层候选（护栏必拦 → 落浆死亡）。塌了后面所有轮次都会以岩浆死亡收场。
        lavaStepOk: await srvIfBlock(...SCENE.lavaStep, 'stone', 'step'),
        lavaStepHeadroom: await srvIfBlock(SCENE.lavaStep[0], SCENE.lavaStep[1] + 1, SCENE.lavaStep[2], 'air', 'stephead'),
        // ★ r8：`lavaWall` 场景件已删（不再由场景逼 bot 爬台阶），对应闸门一并撤掉。
        lavaEastClear: await srvIfBlock(SCENE.lavaSource[0] + 1, SCENE.lavaSource[1] + 1, SCENE.lavaSource[2], 'air', 'eastclear'),
        lavaAboveAir: await srvIfBlock(SCENE.lavaSource[0], SCENE.lavaSource[1] + 1, SCENE.lavaSource[2], 'air', 'lavaabove'),
        standBelow: await srvIfBlock(SCENE.stand[0], SCENE.stand[1] - 1, SCENE.stand[2], 'stone', 'stand'),
        standLavaOk: await srvIfBlock(...SCENE.standLava, 'air', 'slava'),
        standLavaBelow: await srvIfBlock(SCENE.standLava[0], SCENE.standLava[1] - 1, SCENE.standLava[2], 'stone', 'slavab'),
    });
    let last = null;
    for (let pass = 1; pass <= 3; pass++) {
        last = await one();
        if (Object.values(last).every(Boolean)) {
            if (pass > 1) log(`[micro] 第 ${i} 轮布景闸门第 ${pass} 遍才全过（服务端积压，非布景问题）`);
            return last;
        }
        await sleep(1500);
    }
    return last;
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[micro] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[micro] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[micro] server up in ${(server.bootMs / 1000).toFixed(0)}s`);
    // ★ r7：起 rpc 回执通道（与 r5 的 micro_bench 同一套），此后所有命令经它发
    rpc = makeRpc(RPC_DIR);
    const served = serveRpc({ reqDir: rpc.reqDir, doneDir: rpc.doneDir, serverChild: server.child, log });
    rpcStop = served.stop;

    const EX = (f) => import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec', f)).href);
    const liquid = await EX('liquid.js');
    const pc = await EX('patch_cell.js');
    log('[micro] 生产原语已加载');

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    bot.loadPlugin(pf.pathfinder);
    await sleep(3000);
    await cmd(`op ${LANE_B.username}`);

    let deaths = 0;
    bot.on('death', () => { deaths++; log('[micro] ☠️ died'); });

    const rows = [];
    for (let i = 1; i <= N; i++) {
        // —— 每轮重置：只清背包 + 重建场景，**绝不 `kill` bot** ——
        // ★★★ r7 修正：r6 用 `kill` 做轮次重置，结果**第 2 轮起 bot 再也没起来**。
        //   server.log 证据（P8R7_MICRO3）：10 次 `Killed MicroBotB`，但
        //   **没有一次 respawn / 二次 joined the game** ⇒ bot 卡在死亡界面，
        //   后续 give/tp/forceload 全部落空（give 计数 = 0），
        //   表现出来是"区块永远不就绪"（轮询 60 次全失败）。
        //   正确做法照 r5 验证过 30/30 的 micro_bench/micro_bot：
        //   **`clear` 背包 + `fill` 清扫区 + 重建场景**，bot 全程活着。
        //
        // ★★ r7 再修一处（**岩浆死亡的直接原因**）：tp 必须放在轮次**最前面**。
        //   出生点是 `(-235,68,-248)`，布景在 `(100,70,100)` —— **相距 470 格**。
        //   去掉 kill 之后 bot 一直待在出生点那片地形上，而 `clear`/`buildScene` 要花好几秒，
        //   这段时间它仍在游荡 —— P8R7_MICRO6 实测就在这段窗口里
        //   `tried to swim in lava`（server.log：`No chunks were marked` 之后 1 秒）。
        //   **岩浆死亡 0 是硬线，所以"先把 bot 拉到场景边、再做一切事"是本微基准的强制顺序。**
        // ★ r8：tp 目标改成**上方安全台**（3×3 干台，见 buildStaging），不是站位本身 ——
        //   站位在自然水体里，直接 tp 过去会溺死（P8R8_SMOKE：MicroBotB drowned）。
        //   顺序：区块就绪 → 架安全台 → tp 到安全台 → clear → 布景 → 闸门 → tp 到站位。
        const chunks = await ensureChunksLoaded();
        if (!chunks.ok) {
            log(`[micro] 第 ${i} 轮区块没就绪（轮询 ${chunks.rounds} 次），跳过`);
            rows.push({ i, event: '_scene_fail', d: { chunksLoaded: false, rounds: chunks.rounds } });
            continue;
        }
        await Promise.all(buildStaging());
        await cmd(`tp ${LANE_B.username} ${STAGING[0]} ${STAGING[1]} ${STAGING[2]}`);
        await sleep(1000);
        if (!(await ensureAlive(i))) { rows.push({ i, event: '_scene_fail', d: { botDead: true } }); continue; }
        await cmd(`clear ${LANE_B.username}`);
        await sleep(500);
        // ★ r8：等布景命令**全部落到服务端**（~300 条，实测 13s）再判闸门。
        await Promise.all(buildScene());
        await sleep(400);
        // ★ r8：布景闸门**读服务端真值**（`execute if block … run say <marker>` + server.log），
        //   整组最多 3 遍 —— 一遍失败只说明"服务端还没答上话"，不说明布景坏了。
        const sceneOk = await sceneGate(i);
        if (!Object.values(sceneOk).every(Boolean)) {
            log(`[micro] 第 ${i} 轮**布景失败**（服务端真值）${JSON.stringify(sceneOk)} —— 场景没建起来，结果不可信`);
            rows.push({ i, event: '_scene_fail', d: sceneOk });
            continue;
        }
        // 客户端视图**有界等待**追上来：生产原语（liquid.js / patch_cell.js）读的是**客户端**
        // blockAt，服务端闸门过了不代表客户端已收到区块更新。这里只等、**不拿它当闸门**
        // （它就是不可靠的那个视图）；超时只告警，让原语自己的瞄准点遥测去暴露问题。
        // ★ r8：判据里**必须带上石阶与墙**。只等"岩浆源+缺格"是不够的 ——
        //   `standableBeside` 也读客户端视图，客户端没看到石阶就会跳过 `[-1,1,0]`，
        //   退而选中 `(107,70,101)`（实测 SMOKE5：want=[107,70,101] 而非石阶）。
        //   这是 r7 §5.2 那条纪律的第三次复发：**服务端真值与客户端视图必须分别等到位**。
        let clientSettled = false;
        for (let k = 0; k < 60; k++) {                  // 上限 12s
            if (bname(...SCENE.lavaSource) === 'lava' && bname(...SCENE.missing) === 'air'
                && bname(...SCENE.lavaStep) === 'stone') { clientSettled = true; break; }
            await sleep(200);
        }
        if (!clientSettled) log(`[micro] 第 ${i} 轮客户端视图 12s 未追上服务端（仅告警，继续）`);
        // 两桶打法的初始状态：**一只水桶 + 一只空桶**（复现"路上已装好水"）
        // （背包已在轮次开头 clear 过，这里不再重复 clear —— 两次 clear 相邻会互相抵消 give）
        await cmd(`give ${LANE_B.username} minecraft:water_bucket 1`);
        await sleep(400);
        await cmd(`give ${LANE_B.username} minecraft:bucket 1`);
        await sleep(400);
        await cmd(`give ${LANE_B.username} minecraft:stone_pickaxe 1`);
        await sleep(800);
        // 安全落点（★不能直接落到场景中心，可能掉进岩浆洞）
        await cmd(`tp ${LANE_B.username} ${SCENE.stand[0]} ${SCENE.stand[1] + 1} ${SCENE.stand[2]}`);
        await sleep(3000);
        if (bot.entity?.position) {
            // ★ 等落地。第一版没等，每轮测完的 bot 还悬在 tp 的下落途中 → 被判死
            //   （"☠️ died" 每轮都出现，但那是我自己 kill 的，不是测试失败；
            //   真正的问题是死后的 bot 状态不确定，give 的物品可能掉在死亡点）。
            for (let k = 0; k < 30; k++) { if (bot.entity.position.onGround) break; await sleep(200); }
            await sleep(400);
            // 确认真的站在地上、且不在液体里
            const p = bot.entity.position.floored();
            const feet = bname(p.x, p.y, p.z);
            if (feet === 'lava' || feet === 'water') {
                log(`[micro] 第 ${i} 轮落点在液体里（${feet}），重试一次 tp`);
                await cmd(`tp ${LANE_B.username} ${SCENE.stand[0]} ${SCENE.stand[1] + 1} ${SCENE.stand[2]}`);
                await sleep(2000);
            }
        }
        // ★ r8：站位已是 3×3 干台，但仍守住"死后必须 respawn"——
        //   r7 证明死着的 bot 会让后续 give/tp 全部落空（症状伪装成"区块永不就绪"）。
        if (!(await ensureAlive(i))) { rows.push({ i, event: '_scene_fail', d: { botDead: true } }); continue; }
        // 复核 kit 是否真的到手（give 偶发失败时不能带着空背包去测）
        const kitNow = {
            water: bot.inventory.items().filter((x) => x.name === 'water_bucket').length,
            empty: bot.inventory.items().filter((x) => x.name === 'bucket').length,
        };
        if (kitNow.water < 1 || kitNow.empty < 1) {
            log(`[micro] 第 ${i} 轮 kit 不到 ${JSON.stringify(kitNow)}，补发`);
            if (kitNow.water < 1) { await cmd(`give ${LANE_B.username} minecraft:water_bucket 1`); await sleep(500); }
            if (kitNow.empty < 1) { await cmd(`give ${LANE_B.username} minecraft:bucket 1`); await sleep(500); }
        }

        const before = {
            missing: bname(...SCENE.missing),
            water: bot.inventory.items().filter((x) => x.name === 'water_bucket').length,
            empty: bot.inventory.items().filter((x) => x.name === 'bucket').length,
        };
        const deathsBefore = deaths;
        const t0 = Date.now();

        // —— 跑完整循环（生产代码 castCellByHauling，两桶打法版）——
        // ⚠ ctx 必须带 `run.counters`：生产代码的 navTo 会写 `ctx.run.counters.navAttempts`
        //   / `navFailures` / `phaseMs.nav`（见 nav.js:93/127/138/144）。
        //   第一版只给了 {bot, telemetry}，于是 navTo 立刻抛 "Cannot read properties of
        //   undefined (reading 'navAttempts')" → 被 catch 吞掉 → 9~187ms 就
        //   `approach_fail:not_close_enough`。**看起来像"走不过去"，其实是 ctx 不完整。**
        //   —— 这正是手册 §5「先证伪工具」的又一次：先怀疑自己的 harness，再怀疑原语。
        const counters = { navAttempts: 0, navFailures: 0, phaseMs: { nav: 0, search: 0, mine: 0, recover: 0 } };
        const fakeCtx = {
            bot,
            run: { counters },
            telemetry: (e, d) => { if (e.startsWith('patch_') || e.startsWith('water_') || e.startsWith('nav_') || e.startsWith('walk_near')) rows.push({ i, event: e, d }); },
        };
        const r = await pc.castCellByHauling(bot, new Vec3(...SCENE.missing), {
            ctx: fakeCtx, GoalNear: pf.goals.GoalNear,
            telemetry: (e, d) => {
                // ★ r7：把 liquid_scoop_* / liquid_act_* 也收进 rows —— 里面有**瞄准点遥测**
                //   （射线的 eye / 方向 / 视线实际打到的方块 / 是否与预期一致），
                //   这是定位 scoop_fail 唯一缺的信息。
                // ★ r8：补 `walk_near_*` —— `not_close_enough` 的决定性字段
                //   （dist / at / want）**只在这两个事件里**，不收就永远只能靠推算。
                if (e.startsWith('patch_') || e.startsWith('water_') || e === 'cast_ok' || e === 'cast_fail'
                    || e.startsWith('nav_') || e.startsWith('liquid_') || e.startsWith('walk_near')) {
                    rows.push({ i, event: e, d });
                }
            },
            label: `micro${i}`,
        });
        const ms = Date.now() - t0;

        const after = {
            cell: bname(...SCENE.missing),
            water: bot.inventory.items().filter((x) => x.name === 'water_bucket').length,
            empty: bot.inventory.items().filter((x) => x.name === 'bucket').length,
            lavaBucket: bot.inventory.items().filter((x) => x.name === 'lava_bucket').length,
        };
        const tele = rows.filter((x) => x.i === i);
        const rec = {
            i, before, after, result: r, ms,
            // 五个判据分别记，别只看总成功
            c1_scooped: tele.some((x) => x.event === 'patch_scoop_ok'),
            c2_poured_source: tele.some((x) => x.event === 'patch_pour_ok'),
            c3_cast_obsidian: after.cell === 'obsidian',
            c4_water_recovered: after.water >= 1,        // ★ 命根子
            c5_no_lava_death: deaths === deathsBefore,
            ok: r.ok && after.cell === 'obsidian' && after.water >= 1,
        };
        log(`[micro] ${i}/${N} ${rec.ok ? '✅' : '❌'} cell=${after.cell} 水桶=${after.water} 空桶=${after.empty} `
            + `| scoop=${rec.c1_scooped} pour=${rec.c2_poured_source} cast=${rec.c3_cast_obsidian} 舀回水=${rec.c4_water_recovered} 无死亡=${rec.c5_no_lava_death} (${ms}ms) ${r.reason ?? ''}`);
        rows.push({ i, event: '_round', d: rec });
    }

    let lavaDeaths = 0;
    let drowns = 0;
    try {
        const txt = fs.readFileSync(path.join(RUNS_DIR, 'server.log'), 'utf8');
        lavaDeaths = (txt.match(/tried to swim in lava/g) ?? []).length;
        // ★ r8：溺水**单列**。派单的硬线是"岩浆死亡 0"，但溺水是**另一条**失败路径
        //   （P8R8_SMOKE 实测），混进"岩浆死亡"会掩盖站位落在自然水体里这种布景问题。
        drowns = (txt.match(/MicroBotB drowned/g) ?? []).length;
    } catch { /* 忽略 */ }

    const rounds = rows.filter((x) => x.event === '_round').map((x) => x.d);
    const sceneFails = rows.filter((x) => x.event === '_scene_fail').length;
    const stat = (k) => rounds.filter((r) => r[k]).length;
    const summary = {
        stamp: STAMP, seed: SEED, n: rounds.length, sceneFails,
        pass: rounds.filter((r) => r.ok).length,
        c1_scooped: stat('c1_scooped'),
        c2_poured_source: stat('c2_poured_source'),
        c3_cast_obsidian: stat('c3_cast_obsidian'),
        c4_water_recovered: stat('c4_water_recovered'),
        c5_no_lava_death: stat('c5_no_lava_death'),
        lavaDeaths, drowns, botDeaths: deaths,
        medianMs: rounds.map((r) => r.ms).sort((a, b) => a - b)[Math.floor(rounds.length / 2)] ?? null,
        rounds,
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'micro_two_bucket.json'), JSON.stringify(summary, null, 2));
    // ★ r8：**全量遥测落盘**。md 只印了 liquid_* 的瞄准点表，而 `not_close_enough`
    //   的决定性信息在 walkNear 的 `dist`/`at`/`want` 里（nav_* 事件）。
    //   不落盘就只能靠推算——推算过一次（以为 Δy=1 必然过不了），差点改错地方。
    fs.writeFileSync(path.join(RUNS_DIR, 'telemetry.json'), JSON.stringify(rows, null, 2));

    const rate = (k) => (rounds.length ? `${stat(k)}/${rounds.length} = ${(stat(k) / rounds.length * 100).toFixed(0)}%` : '-');
    const md = [
        `# 两桶打法微基准（${STAMP}）`, '',
        `- 种子 \`${SEED}\`；轮次 ${rounds.length}；判定 阈值 **≥95%**`,
        sceneFails ? `- ⚠ **布景失败轮次 = ${sceneFails}**（场景没建起来，这些轮次不计入）` : '- 布景校验全部通过',
        '',
        '| 判据 | 结果 | 门槛 |', '|---|---|---|',
        `| 整体成功 | **${summary.pass}/${rounds.length} = ${(summary.pass / Math.max(1, rounds.length) * 100).toFixed(0)}%** | ≥95% |`,
        `| ① 舀到岩浆 | ${rate('c1_scooped')} | — |`,
        `| ② 倒进缺格且是源块 | ${rate('c2_poured_source')} | — |`,
        `| ③ 倒水后变 obsidian | ${rate('c3_cast_obsidian')} | — |`,
        `| ④ **水舀回桶里** | ${rate('c4_water_recovered')} | — |`,
        `| ⑤ 岩浆死亡 0 | ${rate('c5_no_lava_death')} | **0 容忍** |`,
        '',
        `- **岩浆死亡总数 = ${lavaDeaths}**（server.log 权威）｜**溺水 = ${drowns}**｜bot death 事件 = ${deaths}`,
        `- 中位耗时 ${summary.medianMs}ms`, '',
        '## 逐轮', '',
        '| 轮 | 缺格之前 | 缺格之后 | 水桶 | 空桶 | 结果 | reason | ms |', '|---|---|---|---|---|---|---|---|',
        ...rounds.map((r) => `| ${r.i} | ${r.before.missing} | **${r.after.cell}** | ${r.after.water} | ${r.after.empty} | ${r.ok ? '✅' : '❌'} | ${r.result?.reason ?? '-'} | ${r.ms} |`),
        '', '## 瞄准点遥测（r7 新增，定位 scoop_fail 的关键）', '',
        '| 轮 | 事件 | 眼睛位置 | 想点的方块 | 视线实际打到 | 方块名 | 与预期一致 |',
        '|---|---|---|---|---|---|---|',
        ...rows.filter((x) => x.event === 'liquid_scoop_fail' || x.event === 'liquid_scoop_ok' || x.event === 'liquid_act_fail')
            .map((x) => {
                const a = x.d?.aim;
                if (!a) return `| ${x.i} | ${x.event} | - | - | - | - | - |`;
                return `| ${x.i} | ${x.event} | ${(a.eye ?? []).join(',')} | ${(a.wantRef ?? []).join(',')} | `
                    + `${a.rayHit ? (a.rayHit.at ?? []).join(',') : 'null'} | ${a.rayHit?.name ?? '-'} | ${a.hitMatchesWant ? '✅' : '❌'} |`;
            }).slice(0, 24),
    ].join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'micro_two_bucket.md'), md);
    console.log(md);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    // ★ r8：岩浆死亡 0（派单硬线）与溺水 0（布景站位问题）**都要 0** 才算过。
    const allOk = rounds.length > 0 && summary.pass / rounds.length >= 0.95 && lavaDeaths === 0 && drowns === 0;
    log(`=== 两桶打法微基准：${summary.pass}/${rounds.length}，岩浆死亡 ${lavaDeaths}，溺水 ${drowns} ===`);
    process.exit(allOk ? 0 : 2);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
