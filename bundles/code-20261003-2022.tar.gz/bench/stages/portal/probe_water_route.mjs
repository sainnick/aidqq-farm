// probe_water_route.mjs — 查 `4926685115947721762` 门到水源到底通不通（r5 拦路虎）
//
// 背景：r5 环境取证确认
//   · 门内岩浆只有 **2 格**（187,40,308 / 187,40,309），其余 6 格在框外 ⇒ 好处理
//   · 必需补 **3 格**（门槛 ≤3 内）：netherrack×1 + air×1 + crying_obsidian×1
//   · 到**岩浆**源的导航已修好（目标改成源块旁的实心格 ⇒ 实测 OK）
//   · 但到**水源** (170,40,298) 仍然 `Took to long to decide path` —— **浇筑必须水+岩浆混合**
//
// 本脚本要分辨三件事（每件都有不同的修法）：
//   Q1 水源那一格**旁边到底有没有能站的实心格**？（没有 = 站不到舀不了）
//   Q2 门到水源之间**是不通路**（洞被堵/有断崖）还是**pathfinder 算不出**？
//      做法：沿线每 6 格 tp 一次、逐点探路，看能走到最远在哪
//   Q3 沿途/门附近**有没有别的水源**（放宽搜索半径与 Δy），特别是门内那 8 格岩浆
//      ——**门内那 2 格岩浆如果旁边就有水，浇灭它反而顺带解决了浇水问题**
//
// 只取证，不改任务层；泳道只有 B。
// 用法：node probe_water_route.mjs --seed 4926685115947721762 --stamp P8R5_WATER

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');
const pf = require('mineflayer-pathfinder');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAMP = argOf(process.argv, 'stamp', 'P8R5_WATER');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'WaterBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null;
let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };
const bname = (x, y, z) => { try { return bot.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };
const LIQ = new Set(['lava', 'flowing_lava', 'water', 'flowing_water']);
const AIR = new Set(['air', 'cave_air', 'void_air']);

const DOOR = { x: 187, y: 39, z: 307 };     // 门框 origin
const WATER_MAIN = [170, 40, 298];          // r4/r5 认定的合格水源
const IN_LAVA = [[187, 40, 308], [187, 40, 309]];

function levelOf(x, y, z) {
    try { return bot.blockAt(new Vec3(x, y, z))?.getProperties?.()?.level ?? null; } catch { return null; }
}
function standableBeside(t) {
    const cands = [[0, 1, 0], [0, 2, 0], [1, 1, 0], [-1, 1, 0], [0, 1, 1], [0, 1, -1], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];
    for (const [dx, dy, dz] of cands) {
        const fx = t[0] + dx, fy = t[1] + dy, fz = t[2] + dz;
        const feet = bname(fx, fy, fz); const below = bname(fx, fy - 1, fz);
        if (!feet || AIR.has(feet) || LIQ.has(feet)) continue;
        if (below && LIQ.has(below)) continue;
        return [fx, fy, fz];
    }
    return null;
}
async function walkTo(target, timeout = 45000) {
    try {
        const p0 = bot.entity.position.floored();
        await bot.pathfinder.goto(new pf.goals.GoalNear(target[0], target[1], target[2], 1), { timeout, lavaGuard: true });
        const p1 = bot.entity.position.floored();
        return { ok: true, from: [p0.x, p0.y, p0.z], to: [p1.x, p1.y, p1.z], walked: Math.round(Math.hypot(p1.x - p0.x, p1.z - p0.z)) };
    } catch (e) { return { ok: false, error: String(e?.message ?? e).slice(0, 120) }; }
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[water] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[water] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[water] server up in ${(server.bootMs / 1000).toFixed(0)}s`);

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    bot.loadPlugin(pf.pathfinder);
    await sleep(3500);
    cmd(`op ${LANE_B.username}`);

    // Q1 主水源旁边能不能站
    cmd(`tp ${LANE_B.username} ${DOOR.x} ${DOOR.y + 6} ${DOOR.z + 4}`);
    await sleep(7000);
    const wStand = standableBeside(WATER_MAIN);
    const wInfo = {
        cell: WATER_MAIN, name: bname(...WATER_MAIN), level: levelOf(...WATER_MAIN),
        isSource: levelOf(...WATER_MAIN) === 0, stand: wStand,
    };
    log(`[water] Q1 水源 ${JSON.stringify(wInfo)}`);

    // 门附近（32 格内）所有水源，看有没有更近的
    const nearWaters = [];
    let found = [];
    try {
        found = bot.findBlocks({ matching: (b) => b && (b.name === 'water' || b.name === 'flowing_water'), count: 500, maxDistance: 32 }) ?? [];
    } catch { found = []; }
    for (const f of found) {
        const bb = bname(f.x, f.y, f.z);
        if (!bb) continue;
        const lv = levelOf(f.x, f.y, f.z);
        nearWaters.push({
            at: [f.x, f.y, f.z], level: lv, isSource: lv === 0,
            dist: Math.round(Math.hypot(f.x - DOOR.x, f.z - DOOR.z)),
            dy: Math.abs(f.y - (DOOR.y + 2)),
            stand: standableBeside([f.x, f.y, f.z]),
        });
    }
    nearWaters.sort((a, b) => a.dist - b.dist);
    log(`[water] Q3 门 32 格内水源 ${nearWaters.length}（源块 ${nearWaters.filter((w) => w.isSource).length}）`);

    // Q2 逐段探路：从门出发，沿直线走向主水源，看卡在哪
    const legs = [];
    const STEPS = 8;
    for (let i = 1; i <= STEPS; i++) {
        const t = i / STEPS;
        const x = Math.round(DOOR.x + (WATER_MAIN[0] - DOOR.x) * t);
        const z = Math.round(DOOR.z + (WATER_MAIN[2] - DOOR.z) * t);
        // 沿这一段找一个能站的实心格
        let cand = null;
        for (let dy = 2; dy >= -6 && !cand; dy--) {
            for (let [dx, dz] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2]]) {
                const fx = x + dx, fy = 40 + dy, fz = z + dz;
                const feet = bname(fx, fy, fz); const below = bname(fx, fy - 1, fz);
                if (feet && !AIR.has(feet) && !LIQ.has(feet) && below && !LIQ.has(below)) { cand = [fx, fy, fz]; break; }
            }
        }
        if (!cand) { legs.push({ i, x, z, ok: false, reason: '无可站立格' }); continue; }
        const r = await walkTo(cand, 40000);
        legs.push({ i, x, z, target: cand, ...r });
        log(`[water] Q2 段${i} (${x},${z})→${cand.join(',')}: ${r.ok ? `OK 走到${r.to.join(',')}` : 'FAIL ' + r.error}`);
        if (!r.ok) break;      // 卡住就不必再往后试了
    }

    // 门内岩浆旁边有没有水（浇灭岩浆需要水）
    const lavaBesideWater = [];
    for (const L of IN_LAVA) {
        for (let dx = -3; dx <= 3; dx++) {
            for (let dy = -2; dy <= 2; dy++) {
                for (let dz = -3; dz <= 3; dz++) {
                    const n = bname(L[0] + dx, L[1] + dy, L[2] + dz);
                    if (n === 'water' || n === 'flowing_water') {
                        lavaBesideWater.push({ at: [L[0] + dx, L[1] + dy, L[2] + dz], off: [dx, dy, dz], level: levelOf(L[0] + dx, L[1] + dy, L[2] + dz) });
                    }
                }
            }
        }
    }
    log(`[water] 门内岩浆 7 格范围内有水 ${lavaBesideWater.length} 格`);

    const out = {
        seed: SEED, stamp: STAMP, at: new Date().toISOString(),
        door: DOOR, waterMain: wInfo, nearWaters, legs, lavaBesideWater,
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'water_route.json'), JSON.stringify(out, null, 2));

    const md = [];
    md.push(`# 水源可达性取证（${STAMP}）`, '');
    md.push(`- 种子 \`${SEED}\`；门 (${DOOR.x},${DOOR.y},${DOOR.z})`, '');
    md.push('## Q1 主水源', '');
    md.push(`- 格 ${WATER_MAIN.join(',')} = **${wInfo.name}** level=${wInfo.level} 源块=${wInfo.isSource}`);
    md.push(`- **旁边能站的实心格：${wStand ? wStand.join(',') : '❌ 没有'}**`);
    md.push('', '## Q2 门 → 水源 逐段探路', '');
    for (const l of legs) md.push(`- 段${l.i} (${l.x},${l.z})：${l.ok ? `✅ 走到 [${l.to.join(',')}]` : `❌ ${l.reason ?? l.error}`}`);
    md.push('', '## Q3 门 32 格内的水源', '');
    md.push(`- 共 ${nearWaters.length} 格，其中源块 ${nearWaters.filter((w) => w.isSource).length}`);
    for (const w of nearWaters.slice(0, 10)) {
        md.push(`  - ${w.at.join(',')} level=${w.level} ${w.isSource ? '源' : '流'} 水平${w.dist}格 Δy=${w.dy} 旁边可站=${w.stand ? w.stand.join(',') : '❌'}`);
    }
    md.push('', '## 门内岩浆旁的水（浇灭岩浆用）', '');
    md.push(lavaBesideWater.length ? lavaBesideWater.map((w) => `${w.at.join(',')}(偏移${w.off.join(',')})`).join(' | ') : '- **门内岩浆 7 格范围内没有水**');
    const mdTxt = md.join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'water_route.md'), mdTxt);
    console.log(mdTxt);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
