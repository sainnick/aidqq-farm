// s1_exact_emit.mjs — MC-M1-TASK-08 r19：**L0 背作业** S1_portal 精确坐标（离线）
//
// 依据：`docs/research/data/src-1161/.../NetherPortalBlock.java` 的 `PortalShape`
//   （手册 §3：机制核验以带官方名的反编译源码为准）。
// 那份源码把 1.16.1 的判定写死了，本单的"要补哪几格"就是照它推出来的，不是猜的：
//
//   构造：`bottomLeft` = **框内**左下角那一格（空气、脚下是黑曜石）。
//         `width`  = 框内列数（沿 rightDir 数"空气且脚下黑曜石"的格数）。
//   `calculatePortalHeight()`：对每一列 c∈[0,width)
//         ① 该格必须**空气类**（岩浆/黑曜石都不算）；
//         ② c==0        ⇒ 该格 leftDir 那一格必须是 **obsidian**（左壁）
//            c==width-1 ⇒ 该格 rightDir 那一格必须是 **obsidian**（右壁）
//         循环结束 height=h 后，再要求**顶行**（框内正上方那 h+? 层）c∈[0,width) 全是 obsidian。
//   ⇒ **两个顶角与两个底角都不在必需集合里**；必需黑曜石只有 **10 格**。
//
// 因此主种子这一扇门（框在 x=187，展开方向 = z，框内 z∈{308,309}、y∈{40,41,42}）的
// 必需集合与现状（存档逐格读的）对照是：
//
//   左壁 z=307: (187,40,307)obsidian (187,41,307)obsidian (187,42,307)★空气  ← 要补
//   右壁 z=310: (187,40,310)obsidian (187,41,310)obsidian (187,42,310)★哭泣   ← 要挖+补
//   底行 y=39 : (187,39,308)obsidian (187,39,309)obsidian
//   顶行 y=43 : (187,43,308)obsidian (187,43,309)obsidian
//   框内 2×3 : (187,40,308)★岩浆 (187,40,309)★岩浆 + 4 格空气  ← ★两格岩浆必须舀干净
//
// ⇒ 要做的活一共 4 件：挖哭泣黑曜石、补左壁顶格、补右壁顶格、舀干框内两格岩浆，然后点火。
//   ⚠ r18 的 `missing` 只有 3 格且把 (187,39,307) 当成缺格 —— 那一格是**底角**，
//     按源码不在必需集合里（多干一格，浪费但不致命）。真正被漏掉的是**框内那两格岩浆**：
//     它不是"补格"，是"清空框内"，而 `a()` 判据要求框内是空气 ⇒ 不舀干就点不着。
//     这就是 r18 `ignites=0` 更靠得住的一条解释（待实跑证伪或坐实）。
//
// 用法：
//   & 'D:\AI斗蛐蛐\.runtime\node-v20.20.2-win-x64\node.exe' s1_exact_emit.mjs
//     [--world <dir>] [--out <json>] [--entry 206,64,242] [--scan 183,192,36,46,303,313]

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';
import { openWorld } from '../../route/tools/region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argOf = (k, d) => {
    const hit = process.argv.find((a) => a.startsWith(`--${k}=`) || a.startsWith(`--${k} `));
    if (!hit) return d;
    const v = hit.includes('=') ? hit.slice(hit.indexOf('=') + 1) : hit.slice(hit.indexOf(' ') + 1);
    return v.trim();
};
const argOf2 = (k, d) => {
    const i = process.argv.indexOf(`--${k}`);
    return i >= 0 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : d;
};

const SEED = '4926685115947721762';
const WORLD = argOf2('world', 'D:/AI斗蛐蛐/bench/route/probe/_s1_main_fresh/' + SEED);
const OUT = argOf2('out', path.join(HERE, 's1_exact.json'));
const ENTRY = argOf2('entry', '206,64,242').split(',').map(Number);
const SCAN = argOf2('scan', '183,192,36,46,303,313').split(',').map(Number);
const [SX0, SX1, SY0, SY1, SZ0, SZ1] = SCAN;

// —— 门框几何真源（来自 NetherPortalBlock.PortalShape 的判据，不是抄来的常量）——
const FRAME_X = 187;          // 框平面（1 格厚）
const FRAME_Z0 = 307;         // 展开方向 z 的**左壁**
const FRAME_Z1 = 310;         // 展开方向 z 的**右壁**
const IN_Z0 = 308, IN_Z1 = 309;   // 框内两列
const IN_Y0 = 40, IN_Y1 = 42;     // 框内三层
const BOTTOM_Y = IN_Y0 - 1;       // 底行 y=39
const TOP_Y = IN_Y1 + 1;          // 顶行 y=43

const HAZARD = new Set(['lava', 'flowing_lava', 'magma_block', 'water', 'flowing_water']);
const AIRY = new Set(['air', 'cave_air', 'void_air']);
const FRAME_MATS = new Set(['obsidian', 'crying_obsidian']);

const w = openWorld(WORLD, { dims: ['overworld'], unpackMode: 'packed' });
const get = (x, y, z) => {
    const n = w.blockAt(x, y, z);
    return n == null ? null : n;                 // null = **读不到**，绝不折成 'air'
};
const isAir = (x, y, z) => { const n = get(x, y, z); return n !== null && AIRY.has(n); };
const isHazard = (x, y, z) => { const n = get(x, y, z); return n !== null && HAZARD.has(n); };
const isFrameMat = (x, y, z) => { const n = get(x, y, z); return n !== null && FRAME_MATS.has(n); };

let unreadable = 0;
const noteUnreadable = (x, y, z) => {
    const n = get(x, y, z);
    if (n === null) unreadable++;
    return n;
};

// ═════════════════════════════════════════════════════════════════════════
// 1. 按源码判据推出"必需黑曜石集合"，逐格读现状
// ═════════════════════════════════════════════════════════════════════════
const required = [];           // 必须是 obsidian 的格
const interior = [];           // 必须是空气的格
for (let y = IN_Y0; y <= IN_Y1; y++) {
    required.push([FRAME_X, y, FRAME_Z0]);                  // 左壁
    required.push([FRAME_X, y, FRAME_Z1]);                  // 右壁
}
for (let z = IN_Z0; z <= IN_Z1; z++) required.push([FRAME_X, BOTTOM_Y, z]);   // 底行
for (let z = IN_Z0; z <= IN_Z1; z++) required.push([FRAME_X, TOP_Y, z]);      // 顶行
for (let y = IN_Y0; y <= IN_Y1; y++) for (let z = IN_Z0; z <= IN_Z1; z++) interior.push([FRAME_X, y, z]);

const missing = [], digFirst = [], interiorDirty = [];
for (const [x, y, z] of required) {
    const n = noteUnreadable(x, y, z);
    if (n === 'obsidian') continue;
    if (FRAME_MATS.has(n)) digFirst.push({ xyz: [x, y, z], block: n });   // 哭泣黑曜石：先挖
    missing.push({ xyz: [x, y, z], block: n ?? 'UNREADABLE' });
}
for (const [x, y, z] of interior) {
    const n = noteUnreadable(x, y, z);
    if (n === null) { interiorDirty.push({ xyz: [x, y, z], block: 'UNREADABLE' }); continue; }
    if (AIRY.has(n)) continue;
    interiorDirty.push({ xyz: [x, y, z], block: n });
}

// 顺带把"底角/顶角"记下来：证明它们**不在**必需集合里（省掉 r18 多干的那一格）
const corners = [[FRAME_X, BOTTOM_Y, FRAME_Z0], [FRAME_X, BOTTOM_Y, FRAME_Z1],
[FRAME_X, TOP_Y, FRAME_Z0], [FRAME_X, TOP_Y, FRAME_Z1]]
    .map(([x, y, z]) => ({ xyz: [x, y, z], block: noteUnreadable(x, y, z) ?? 'UNREADABLE', required: false }));

// ═════════════════════════════════════════════════════════════════════════
// 2. 站位：**脚下一格实心非危险、身体与头顶两格空气、周围不贴危险**
//    排序主键 = 垂直高差（rise）—— r18 §1.3：只按水平距离排会把"水平 0 格、垂直 6 格"
//    的门框顶平台排到第一，那是最差的一格。
// ═════════════════════════════════════════════════════════════════════════
const stands = [];
for (let y = IN_Y0 - 1; y <= TOP_Y + 2; y++) {
    for (let x = SX0; x <= SX1; x++) {
        for (let z = SZ0; z <= SZ1; z++) {
            // 别站进**框里**（必需黑曜石格与框内 2×3）。
            // ⚠ 但**允许站在门框顶面**（y = TOP_Y）—— 人就是这么干的：踩在顶行/顶角上俯身作业，
            //   r18 那次把 bot 逼到门框顶上并不是错，**排序把它排第一**才是错（§1.3）。
            const inFrameXz = x === FRAME_X && z >= FRAME_Z0 && z <= FRAME_Z1;
            if (inFrameXz && y !== TOP_Y) continue;
            if (inFrameXz && y === TOP_Y && z !== FRAME_Z0 && z !== FRAME_Z1) continue;   // 顶行中段下面就是框内，踩不住
            const under = noteUnreadable(x, y - 1, z);
            if (under === null) continue;                         // 读不到 ⇒ 不站（保守）
            if (HAZARD.has(under) || !isSolidish(under)) continue;
            if (!isAir(x, y, z) || !isAir(x, y + 1, z)) continue;
            // 周围 1 格有危险 ⇒ 直接剔（"站上去会不会死"这条通道，只管这一件事）
            let near = null;
            for (let dx = -1; dx <= 1 && !near; dx++) for (let dy = -2; dy <= 0 && !near; dy++) for (let dz = -1; dz <= 1; dz++) {
                if (dx === 0 && dy === 0 && dz === 0) continue;
                if (isHazard(x + dx, y + dy, z + dz)) near = [x + dx, y + dy, z + dz];
            }
            if (near) continue;
            const reach = Math.max(...required.map(([rx, , rz]) => Math.max(Math.abs(rx - x), Math.abs(rz - z))));
            const rise = Math.max(...required.map(([rx, ry, rz]) => Math.max(Math.abs(rx - x), Math.abs(ry - y), Math.abs(rz - z))));
            const dReach = Math.max(...digFirst.map((c) => Math.max(Math.abs(c.xyz[0] - x), Math.abs(c.xyz[2] - z))));
            stands.push({ feet: [x, y, z], under, reach, rise, dReach, d3: rise });
        }
    }
}
function isSolidish(name) {
    // 只有"整格实心"才算地面；液体、空气、台阶/板岩一律不算（板岩踩上去会掉下去）
    return !AIRY.has(name) && !HAZARD.has(name) && !name.endsWith('_slab') && !name.endsWith('_stairs')
        && name !== 'snow' && name !== 'scaffolding' && name !== 'ladder' && name !== 'vine';
}
stands.sort((a, b) => a.rise - b.rise || a.reach - b.reach
    || a.feet[0] - b.feet[0] || a.feet[2] - b.feet[2]);      // 显式打破并列（手册 §5）

// ═════════════════════════════════════════════════════════════════════════
// 3. 危险格清单（**只描述世界**，不回答"站上去会不会死"——那是站位那条通道的事）
// ═════════════════════════════════════════════════════════════════════════
const hazards = [];
for (let y = SY0; y <= SY1; y++) for (let z = SZ0; z <= SZ1; z++) for (let x = SX0; x <= SX1; x++) {
    if (isHazard(x, y, z)) hazards.push([x, y, z]);
}

// ═════════════════════════════════════════════════════════════════════════
// 4. 补格顺序（人按什么顺序补最省事；显式打破并列）
//    规则：**先挖后补**（挖出来的格子必须先腾空才浇得进去）；
//          同一层里从**离站位远**的先补（近的留到最后，避免补完的格子挡住手）；
//          再按 z、x 升序做**确定性**打破（手册 §5：并列不打破 = 随机选）。
// ═════════════════════════════════════════════════════════════════════════
const stand = stands[0]?.feet ?? null;
function orderKey(c) {
    const [, , z] = c.xyz;
    const far = stand ? -Math.hypot(c.xyz[0] - stand[0], c.xyz[2] - stand[2]) : 0;
    return [far, z, c.xyz[0], c.xyz[1]];
}
const digList = digFirst.slice().sort((a, b) => orderKey(a) - orderKey(b) || a.xyz[2] - b.xyz[2]);
const fillList = missing.filter((c) => !FRAME_MATS.has(c.block))
    .sort((a, b) => orderKey(a) - orderKey(b) || a.xyz[2] - b.xyz[2]);

// ═════════════════════════════════════════════════════════════════════════
// 5. 路点：地表入口 → 站位。逐段只允许"脚下有实心非危险地面"的落脚面。
// ═════════════════════════════════════════════════════════════════════════
const waypoints = [];
if (stand) {
    waypoints.push([ENTRY[0], ENTRY[1], ENTRY[2]]);
    // 先竖直降到站位正上方所在的地表，再水平推进
    let cur = ENTRY.slice();
    while (cur[1] > stand[1] + 1) {
        const ny = cur[1] - 1;
        if (!isSolidish(noteUnreadable(cur[0], ny - 1, cur[2]) ?? '')) { cur[2] += 1; continue; }  // 悬空 ⇒ 水平挪一格找地面
        cur[1] = ny;
        waypoints.push(cur.slice());
    }
    while (Math.abs(cur[0] - stand[0]) > 2 || Math.abs(cur[2] - stand[2]) > 2) {
        if (Math.abs(cur[0] - stand[0]) >= Math.abs(cur[2] - stand[2])) cur[0] += Math.sign(stand[0] - cur[0]);
        else cur[2] += Math.sign(stand[2] - cur[2]);
        waypoints.push(cur.slice());
    }
    waypoints.push(stand.slice());
    // 相邻路点 ≤32 格（SCHEMA §5）
    for (let i = 1; i < waypoints.length; i++) {
        const d = Math.max(...[0, 1, 2].map((k) => Math.abs(waypoints[i][k] - waypoints[i - 1][k])));
        if (d > 32) throw new Error(`路点 ${i} 与 ${i - 1} 相距 ${d} > 32，SCHEMA §5 不允许`);
    }
}

// ═════════════════════════════════════════════════════════════════════════
// 输出
// ═════════════════════════════════════════════════════════════════════════
const exact = {
    stand: stands.slice(0, 8).map((s) => s.feet),
    targets: [
        ...digList.map((c, i) => ({ what: 'dig', xyz: c.xyz, tool: 'iron_pickaxe', order: 10 + i, note: `${c.block}：源码判据要求该格是 obsidian` })),
        ...interiorDirty.map((c, i) => ({ what: 'scoop_lava', xyz: c.xyz, order: 20 + i, note: `框内必须是空气（源码 a() 判据），当前 ${c.block}` })),
        ...fillList.map((c, i) => ({ what: 'fill_cell', xyz: c.xyz, order: 30 + i, how: 'two_bucket', note: `当前 ${c.block}` })),
        { what: 'ignite', xyz: [FRAME_X, IN_Y1 - 1, IN_Z0], order: 90, note: '框内任意一格空气即可点火（服务端按框内是否有点燃物触发）' },
    ],
    hazards,
    verify: {
        status: 'OFFLINE',
        evidence: `${WORLD} + bench/route/tools/region_reader.mjs + bench/stages/portal/s1_exact_emit.mjs；框规则来自 docs/research/data/src-1161/.../NetherPortalBlock.java (PortalShape)`,
        unreadable,
    },
    _standDetail: stands.slice(0, 12),
    _requiredObsidian: required,
    _interior: interior,
    _optionalCorners: corners,
};

const doc = {
    schema: 'aidqq-route/2-exact-fragment',
    seed: SEED,
    station: 'S1_portal',
    legs: [{
        from: 'entry_surface', to: 'S1_portal', dim: 'overworld', waypoints,
        notes: `从地表入口 ${ENTRY.join(',')} 走到作业站位；相邻路点 ≤32 格（SCHEMA §5）`,
    }],
    exact,
};

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(doc, null, 2) + '\n', 'utf8');
if (!fs.existsSync(OUT)) throw new Error('产物没落盘：' + OUT);

console.log(`\n=== S1_portal L0 精确坐标（离线，seed ${SEED}）===`);
console.log(`世界：${WORLD}`);
console.log(`\n[1] 源码判据下的必需黑曜石 ${required.length} 格，逐格现状：`);
for (const [x, y, z] of required) console.log(`      ${x},${y},${z} = ${get(x, y, z) ?? 'UNREADABLE'}`);
console.log(`\n[2] 底角/顶角（**不在**必需集合里）：`);
for (const c of corners) console.log(`      ${c.xyz.join(',')} = ${c.block}`);
console.log(`\n[3] 要挖的格（先挖后补）：${digList.length}`);
for (const c of digList) console.log(`      ${c.xyz.join(',')} = ${c.block}`);
console.log(`\n[4] 框内必须是空气的格，当前非空气的 ${interiorDirty.length}：`);
for (const c of interiorDirty) console.log(`      ${c.xyz.join(',')} = ${c.block}`);
console.log(`\n[5] 要补的格（空气/非黑曜石）：${fillList.length}`);
for (const c of fillList) console.log(`      ${c.xyz.join(',')} = ${c.block}`);
console.log(`\n[6] 合法的空缺集合 = 挖 ${digList.length} + 舀 ${interiorDirty.length} + 补 ${fillList.length} = ${digList.length + interiorDirty.length + fillList.length} 件事`);
console.log(`\n[7] 站位候选 ${stands.length} 个，前 6（排序主键=垂直高差）：`);
for (const s of stands.slice(0, 6)) console.log(`      feet=${s.feet.join(',')} 脚下=${s.under} 水平reach=${s.reach} 三维rise=${s.rise}`);
console.log(`\n[8] 路点 ${waypoints.length} 个：`);
for (const p of waypoints) console.log(`      ${p.join(',')}`);
console.log(`\n[9] 危险格（扫描窗内）${hazards.length} 个；读不到格 ${unreadable} 个`);
console.log(`\n产物：${OUT}`);
