﻿// scout_lava.mjs — 主种子「浇门岩浆源」预勘（把草稿 route 的占位 fallback 换成真数据）
//
// 为什么需要它（阻断级发现，P8_SMOKE3）：
//   主种子废弃传送门 (176,352) 的框体是 **9 obsidian + 1 crying_obsidian**（SEED-03 R3 真值），
//   也就是差 1 格 obsidian。bot 手上有石镐 —— **1.16 里黑曜石必须钻石/下界合金镐才掉落**，
//   石镐挖了没用；补这一格只能**浇筑**，而 SEED-03 的 48 格扫描里**没有岩浆**（计数只有
//   stone/dirt/water）。于是「到站 → 补框」在原地物理上不可能，必须走 route 的 fallback
//   （岩浆池浇筑站）。而 ROUTE-02 的 route 还没交付，草稿里那个 fallback 站是占位的
//   （借用了村庄坐标、lookFor=lava 必然找不到）→ 整条链在验收前就断了。
//   章程（MC-CHARTER-01）把「浇门岩浆源」列为 P0 下钻项之一 —— 本脚本就是做这一项，
//   手法与 SEED-03 同源：**服务器权威**（自己起的服、自己 tp、自己 findBlocks）。
//
// 公平口径：这是**赛前预勘**，数据只进 route 的 station{}（8 格网格 + radius），
// 任务层运行时看不到本文件产生的任何精确坐标（route_loader 只投影 station）。
//
// 扫法：绕站心 32 格步长的方格网，每站 tp 过去等区块加载，再 findBlocks(lava, maxDistance 40)。
//      步长 32 < 40 ⇒ 覆盖无空洞；用**源块**判据（level 0，与 liquid.js 同口径）。
//
// 用法：node scout_lava.mjs --stamp P8_SCOUT_LAVA --seed -8839485814800629942

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';


const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const STAMP = argOf(process.argv, 'stamp', 'P8_SCOUT_LAVA');
const SEED = argOf(process.argv, 'seed', '-8839485814800629942');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const STEP = parseInt(argOf(process.argv, 'step', '32'), 10);
const RANGE = parseInt(argOf(process.argv, 'range', '112'), 10);
const SCAN_R = parseInt(argOf(process.argv, 'scan-r', '40'), 10);
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
// 扫格中心：默认取草稿 route 的 S1_portal 站心（--cx/--cz 可覆盖，用来专门扫废弃门周边）
const PORTAL = { x: 176, z: 352 };                              // 主种子废弃传送门站心（route/draft 同源）
const ORIGIN = {
    x: parseInt(argOf(process.argv, 'cx', String(PORTAL.x)), 10),
    z: parseInt(argOf(process.argv, 'cz', String(PORTAL.z)), 10),
};

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'ScoutBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });
let server = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };

async function tpTo(x, y, z) {
    cmd(`tp ${LANE_B.username} ${x} ${y} ${z}`);
    for (let i = 0; i < 40; i++) {
        await sleep(200);
        const p = bot?.entity?.position;
        if (p && Math.abs(p.x - x) < 1.5 && Math.abs(p.z - z) < 1.5) return true;
    }
    return false;
}

let bot = null;

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[scout] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[scout] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[scout] server up in ${(server.bootMs / 1000).toFixed(0)}s seed=${SEED}`);

    const mineflayer = require('mineflayer');
    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    log('[scout] bot in');
    await sleep(2500);
    cmd(`op ${LANE_B.username}`);

    // 找地面高度：站上去取脚底 y
    const spots = [];
    for (let dx = -RANGE; dx <= RANGE; dx += STEP) {
        for (let dz = -RANGE; dz <= RANGE; dz += STEP) spots.push({ x: ORIGIN.x + dx, z: ORIGIN.z + dz });
    }
    log(`[scout] 扫 ${spots.length} 个点（步长 ${STEP}，每点 maxDistance ${SCAN_R}）`);

    const found = new Map();     // "x,y,z" → {name, dist, from}
    let scanned = 0;
    for (const s of spots) {
        // 先把 bot 抬到 y=120 再落下去，落点就是当地地面（避免猜 y）
        cmd(`tp ${LANE_B.username} ${s.x} 120 ${s.z}`);
        for (let i = 0; i < 40; i++) { await sleep(150); if (bot.entity?.position?.y < 110) break; }
        await sleep(2200);        // 等区块流过来 + 落地
        let lavas = [];
        try {
            lavas = bot.findBlocks({
                matching: (b) => b && (b.name === 'lava' || b.name === 'flowing_lava'),
                count: 400, maxDistance: SCAN_R,
            }) ?? [];
        } catch { lavas = []; }
        const p = bot.entity.position;
        for (const l of lavas) {
            const k = `${l.x},${l.y},${l.z}`;
            if (found.has(k)) continue;
            // ★ findBlocks 返回的方块**没有 .name**（mineflayer 4.38 的 blocks.js:185
            //   `blocks.push(cursor.clone())`，clone 只带坐标/类型）——P8_SCOUT_LAVA 第一版
            //   就是因此把 114 个**全是源块**的岩浆记成「0 源块」（按 name 过滤全灭）。
            //   名字与源块判据一律回查 bot.blockAt（与 liquid.js 同口径：level 0 = 源）。
            const bb = bot.blockAt(new Vec3(l.x, l.y, l.z));
            const name = bb?.name ?? 'unknown';
            const level = (() => { try { return bb?.getProperties?.()?.level ?? null; } catch { return null; } })();
            found.set(k, {
                at: [l.x, l.y, l.z], name, level,
                isSource: level === 0,
                distFromPortal: Math.round(Math.hypot(l.x - PORTAL.x, l.z - PORTAL.z)),
                distY: l.y - Math.round(p.y),
            });
        }
        scanned++;
        if (scanned % 10 === 0) log(`[scout] ${scanned}/${spots.length} 点，累计岩浆格 ${found.size}`);
    }

    const sources = [...found.values()].filter((v) => v.isSource && v.name === 'lava');
    sources.sort((a, b) => a.distFromPortal - b.distFromPortal);
    const out = {
        stamp: STAMP, seed: SEED, scannedSpots: spots.length, step: STEP, scanRadius: SCAN_R,
        portalStation: PORTAL, origin: ORIGIN, at: new Date().toISOString(),
        allLava: [...found.values()].sort((a, b) => a.distFromPortal - b.distFromPortal).slice(0, 40),
        nearestSources: sources.slice(0, 20),
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'scout_lava.json'), JSON.stringify(out, null, 2));

    const md = [
        `# 主种子浇门岩浆源预勘（${STAMP}）`, '',
        `- 种子 \`${SEED}\`；绕站心 (${ORIGIN.x},${ORIGIN.z}) 步长 ${STEP} 扫 ${spots.length} 点，每点 maxDistance ${SCAN_R}`,
        `- 废弃传送门站心 (${PORTAL.x},${PORTAL.z})`,
        `- 命中岩浆格 ${found.size}，其中**源块** ${sources.length}`, '',
        '| 源块坐标(预勘) | 离废弃门 | y |', '|---|---|---|',
        ...sources.slice(0, 12).map((s) => `| ${s.at.join(',')} | ${s.distFromPortal} | ${s.at[1]} |`),
        '',
        sources.length
            ? `**最近源块离废弃传送门 ${sources[0].distFromPortal} 格** —— 补框要走 route 的 fallback（岩浆池浇筑站）。`
            : '**该区域没有岩浆源** —— 补框在主种子废弃门处物理上不可能。',
    ].join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'scout_lava.md'), md);
    console.log(md);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});

