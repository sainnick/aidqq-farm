﻿import fs from 'node:fs';
const d='D:/AI斗蛐蛐/mindcraft-wt/s1-portal/src/agent/tasks/exec/';
for(const f of fs.readdirSync(d)){
  if(!/\.(js|mjs)$/.test(f)) continue;
  const L=fs.readFileSync(d+f,'utf8').split(/\r?\n/);
  L.forEach((l,i)=>{ if(/frameMissing|missingCells|frameCells|frameMissingFilled/.test(l)) console.log(f+':'+(i+1)+': '+l.trim().slice(0,150)); });
}
