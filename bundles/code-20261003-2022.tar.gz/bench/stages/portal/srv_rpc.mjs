// srv_rpc.mjs — MC-M1-TASK-08 服控 RPC（文件队列，bot ⇄ 编排器 ⇄ 服务器 stdin）
//
// 为什么需要它（P8_PROBE2 实测踩出来的，不是猜的）：
//   微基准要用 setblock/fill/tp/give/clear 这些控制台命令，原实现是 **bot 走游戏内
//   聊天**发 /命令（micro-place 的老路子）。P8_PROBE2 的 server.log 证据：
//     [22:39:01] Successfully filled 45 blocks
//     [22:39:02] Successfully filled 12 blocks
//     [22:39:03] Successfully filled 12 blocks
//     —— 之后 3 个 setblock、2 个 data get、1 个 execute **全部没有留下任何日志**。
//   也就是说：短时间内连发的聊天命令会被服务端**静默丢弃**（"sending chat too fast"），
//   剩下 fill 那几条纯粹是运气。更糟的是 /setblock 成功时服务端不打日志，
//   所以「命令丢了」和「命令成了」从 server.log 上长得一模一样 —— 无法区分。
//
//   手册 §2 早就写过：**一律用服务器 stdin 控制台发命令**（RCON 会毒化服务进程）。
//   编排器本来就持有 server.child.stdin，所以正解是让**编排器**发命令，
//   bot 通过文件队列请求。好处：
//     - 没有聊天节流，没有 1.16.1 的聊天签名问题
//     - fill/setblock/tp/give 全部经同一条通道，行为一致
//     - 服务端真值查询（execute if block → say 标记 → 读 server.log）也能做
//     - bot 侧零聊天
//
// 协议（纯文件，无依赖）：
//   bot  → 编排器：写 <rpcDir>/req/<id>.txt（内容是一行服务端控制台命令，不带前导 /）
//   编排器 → 服务器：child.stdin.write(cmd + "\n")
//   编排器 → bot  ：写 <rpcDir>/done/<id>.ok
//   两种可选确认（默认用 ack，见 waitAck）：
//     ack  = 编排器确认「命令已写进 stdin」
//     log  = 编排器在 server.log 里等到某个标记（用于 `execute ... run say @@Ynnn`）
//
// 隔离：本 RPC 只对本线自己起的服生效，编排器是 server.child 的直接持有者，
// 不经 RCON、不碰别的线的服。

import fs from 'fs';
import path from 'path';

export function makeRpc(rpcDir) {
    const reqDir = path.join(rpcDir, 'req');
    const doneDir = path.join(rpcDir, 'done');
    fs.mkdirSync(reqDir, { recursive: true });
    fs.mkdirSync(doneDir, { recursive: true });
    let seq = 0;
    return {
        reqDir,
        doneDir,
        /** 递增 id（bot 侧与编排器侧各自独立计数也没问题：编排器按文件名排序处理） */
        nextId(prefix = 'c') { return `${prefix}_${Date.now().toString(36)}_${++seq}`; },
        /** bot 侧：发一条命令并等 ack */
        async call(dir, id, cmd, { timeoutMs = 30000, logFn = null } = {}) {
            const reqPath = path.join(dir.reqDir, `${id}.txt`);
            const donePath = path.join(dir.doneDir, `${id}.ok`);
            try { fs.rmSync(donePath, { force: true }); } catch { /* 忽略 */ }
            fs.writeFileSync(reqPath, cmd.endsWith('\n') ? cmd : cmd + '\n');
            const t0 = Date.now();
            while (Date.now() - t0 < timeoutMs) {
                if (fs.existsSync(donePath)) {
                    try { return fs.readFileSync(donePath, 'utf8').trim(); } catch { return ''; }
                }
                await new Promise((r) => setTimeout(r, 40));
            }
            logFn?.(`RPC 超时 ${timeoutMs}ms：${id} ${cmd}`);
            return null;
        },
    };
}

/**
 * 编排器侧：把 req 队列里的命令灌进服务器 stdin，并回 ack。
 * @param {object} opts { reqDir, doneDir, serverChild, log }
 * @returns {Promise<{handled:number, stop:Function}>}
 */
export function serveRpc({ reqDir, doneDir, serverChild, log = () => {} }, opts = {}) {
    const { pollMs = 150 } = opts;
    let running = true;
    const loop = async () => {
        while (running) {
            let files = [];
            try { files = fs.readdirSync(reqDir).filter((f) => f.endsWith('.txt')).sort(); } catch { files = []; }
            for (const f of files) {
                if (!running) return;
                const id = f.replace(/\.txt$/i, '');
                const src = path.join(reqDir, f);
                let cmd = null;
                try { cmd = fs.readFileSync(src, 'utf8').trim(); } catch { cmd = null; }
                try { fs.rmSync(src, { force: true }); } catch { /* 已处理 */ }
                if (cmd == null) continue;
                if (!cmd) {                       // 空命令 = 纯 ack
                    try { fs.writeFileSync(path.join(doneDir, `${id}.ok`), ''); } catch { /* 忽略 */ }
                    continue;
                }
                try {
                    serverChild.stdin.write(`${cmd}\n`);
                    log(`rpc> ${cmd}`);
                } catch (e) {
                    try { fs.writeFileSync(path.join(doneDir, `${id}.ok`), `ERR ${e.message}`); } catch { /* 忽略 */ }
                    continue;
                }
                // 给服务端一点时间把命令消化掉再回 ack（fill 几千格要好几秒）
                await new Promise((r) => setTimeout(r, 120));
                try { fs.writeFileSync(path.join(doneDir, `${id}.ok`), 'ok'); } catch { /* 忽略 */ }
            }
            await new Promise((r) => setTimeout(r, pollMs));
        }
    };
    loop().catch((e) => log(`rpc loop error: ${e.message}`));
    return { stop: () => { running = false; } };
}

/** 读 server.log 尾部（服务端真值通道用） */
export function tailFile(file, maxBytes = 16384) {
    try {
        const buf = fs.readFileSync(file);
        return buf.subarray(Math.max(0, buf.length - maxBytes)).toString('utf8');
    } catch { return ''; }
}
