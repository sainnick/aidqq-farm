// probe_seed_select.mjs — 备选种子 S1 选种取证（ROUND3 补充节 B-1）
//
// 目的：设计会话已裁决「重选主种子」，要求对两个备选种子做与 r3 同规格的取证，
// 并按**明确判据**自动定种子：
//   · 框内缺几格、缺格被什么占着（用**生产代码** nether.js 的 frameCells 逐格判定）
//   · 箱子开出什么（服务端实开，不用战利品表推算）
//   · 岩浆源是否合格：**源块(level 0) + 离门 ≤48 格 + 与门高度差 ≤8 格 + 走得到**
//   合格种子 = 缺格 ≤1 且（箱子能补上 或 有合格岩浆源可局部浇筑）
//   两个都合格 → 优先 4926685115947721762
//
// ★ 为什么岩浆判据要加「高度差 ≤8 格」（r3 的教训）：
//   r3 只报了水平距离，门在 y≈77 而唯一源块在 y=33（垂直差 44 格），
//   「离门 138 格」这个数字完全掩盖了搬运成本。**搬运岩浆是三维的**，
//   水平 48 格但垂直差 44 格在实操上比水平 60 格、垂直差 2 格贵得多。
//
// 走得到怎么判：用 mineflayer-pathfinder 从门边实际导航一次到源块旁边
// （GoalNear，lavaGuard），**不 tp**。导航失败即「走不到」。
// 公平口径：这是赛前预勘取证（与 SEED-03/ROUTE-02 同源），产出只进报告与种子裁决。
//
// 用法：node probe_seed_select.mjs --seed 4926685115947721762 --stamp P8R3_SEL1

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');
const pf = require('mineflayer-pathfinder');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAMP = argOf(process.argv, 'stamp', `P8R3_SEL_${SEED}`);
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

// —— 派单给定的岩浆合格判据 ——
const LAVA_MAX_DIST = parseInt(argOf(process.argv, 'lava-max-dist', '48'), 10);
const LAVA_MAX_DY = parseInt(argOf(process.argv, 'lava-max-dy', '8'), 10);
const SCAN_R = parseInt(argOf(process.argv, 'scan-r', '64'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'SeedBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null;
let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };
const bname = (x, y, z) => { try { return bot.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };
const AIR = new Set(['air', 'cave_air', 'void_air']);

let frameCells, interiorCells;

/** 枚举所有候选框体（生产几何），按 obsidian 数降序 */
function scanFrames(range) {
    const out = [];
    for (const axis of ['x', 'z']) {
        for (let y = range.y1; y <= range.y2 - 4; y++) {
            for (let x = range.x1; x <= range.x2 - 3; x++) {
                for (let z = range.z1; z <= range.z2 - 3; z++) {
                    const origin = { x, y, z };
                    const cells = frameCells(origin, axis);
                    let obs = 0; const missing = []; const wrong = []; let optionalMissing = 0;
                    for (const c of cells) {
                        const n = bname(c.pos.x, c.pos.y, c.pos.z);
                        if (n === 'obsidian') { obs++; continue; }
                        if (c.optional) {
                            if (!n || AIR.has(n)) optionalMissing++;
                            else wrong.push({ pos: [c.pos.x, c.pos.y, c.pos.z], got: n, optional: true });
                            continue;
                        }
                        if (!n || AIR.has(n)) missing.push({ pos: [c.pos.x, c.pos.y, c.pos.z], got: n ?? 'unloaded' });
                        else wrong.push({ pos: [c.pos.x, c.pos.y, c.pos.z], got: n });
                    }
                    const dirty = interiorCells(origin, axis)
                        .map((p) => ({ pos: [p.x, p.y, p.z], got: bname(p.x, p.y, p.z) }))
                        .filter((c) => c.got && !AIR.has(c.got));
                    if (obs >= 4) out.push({ axis, origin, obs, missing, wrong, optionalMissing, dirty });
                }
            }
        }
    }
    out.sort((a, b) => b.obs - a.obs || a.missing.length - b.missing.length);
    return out;
}

/** 派单合格判据：源块 + 水平 ≤48 + 垂直差 ≤8 */
function judgeLava(src, portalY) {
    const dy = Math.abs(src.at[1] - portalY);
    return {
        ...src, dy,
        distOk: src.dist <= LAVA_MAX_DIST,
        dyOk: dy <= LAVA_MAX_DY,
        qualifies: src.dist <= LAVA_MAX_DIST && dy <= LAVA_MAX_DY,
    };
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[sel] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[sel] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[sel] server up in ${(server.bootMs / 1000).toFixed(0)}s seed=${SEED}`);

    const netherMod = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/nether.js')).href);
    frameCells = netherMod.frameCells;
    interiorCells = netherMod.interiorCells;
    log('[sel] nether.js 生产几何已加载');

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    bot.loadPlugin(pf.pathfinder);
    await sleep(3500);
    cmd(`op ${LANE_B.username}`);
    const dim = bot.game?.dimension ?? null;
    const spawn = bot.entity.position.floored();
    log(`[sel] bot in dim=${dim} spawn=[${spawn.x},${spawn.y},${spawn.z}]`);

    // —— 阶段 1：读 route 拿站心（只读 station，不读 scout）——
    const routeFile = path.join(ROOT, 'bench', 'route', `${SEED}.json`);
    const route = JSON.parse(fs.readFileSync(routeFile, 'utf8'));
    const st1 = route.stations.find((s) => s.id === 'S1_portal');
    if (!st1) { console.error('[sel] route 里没有 S1_portal'); process.exit(1); }
    // ★ 只取站级数据（center 对齐 8 格 + radius），与任务层可见口径一致
    const cx = Math.round(Number(st1.station.center[0]) / 8) * 8;
    const cz = Math.round(Number(st1.station.center[1]) / 8) * 8;
    const R = st1.station.radius;
    log(`[sel] S1_portal 站心=(${cx},${cz}) radius=${R}（已 8 格网格化）`);

    // —— 阶段 2：框体几何（站心邻域，生产几何逐格）——
    // ★★ r4 修掉的一个致命 bug：区间 y 原来**硬编码 60..92**。
    //   但三个种子的门真实高度完全不同（主种子 y=75..79、本脚本测的两个是 y=40..43 / 42..46），
    //   `yHint:"surface"` 只表示"地表附近"，**不等于 60..92**。
    //   后果：扫不到门 → frames=0 → 误判"缺 0 格"→ 又因"箱子 0 块 ≥ 0 格"判成 **✅ 合格**，
    //   **两个种子都被判成合格，纯属假阳性**。手册 §5：先证伪工具再下结论。
    //   修法：y 区间从 route 的 **scout 采样点高度**推导（预勘期用 scout 合规，见下），
    //   并留足余量；scout 缺失时才退回全高度扫描。
    const scoutYs = (st1.scout?.points ?? []).map((p) => Number(p.y)).filter((y) => Number.isFinite(y));
    let yLo; let yHi;
    if (scoutYs.length) {
        yLo = Math.max(0, Math.min(...scoutYs) - 8);
        yHi = Math.min(120, Math.max(...scoutYs) + 8);
        log(`[sel] 区间 y 由 scout 采样推导：scout y=[${Math.min(...scoutYs)}..${Math.max(...scoutYs)}] → 扫 ${yLo}..${yHi}`);
    } else {
        yLo = 0; yHi = 120;
        log('[sel] ⚠ scout 无采样点，退回全高度扫描 0..120（慢）');
    }
    cmd(`tp ${LANE_B.username} ${cx} ${Math.min(110, yHi + 6)} ${cz}`);
    await sleep(8000);
    const RANGE = { x1: cx - 18, x2: cx + 18, y1: yLo, y2: yHi, z1: cz - 18, z2: cz + 18 };
    const frames = scanFrames(RANGE);
    const best = frames[0] ?? null;
    log(`[sel] 框体候选 ${frames.length}，最佳 obs=${best?.obs ?? 0} 缺=${best?.missing.length ?? '-'}`);

    // 缺格是否"非 obsidian 但需要 obsidian"（=要处理），可选角单列
    const needCells = best ? best.missing.concat(best.wrong.filter((w) => !w.optional)) : [];
    const needNonOptional = best ? needCells.length : 0;

    // —— 阶段 3：箱子（服务端实开）——
    let chest = { pos: null, items: null, error: null };
    const chestCandidates = [];
    for (let y = RANGE.y2; y >= RANGE.y1; y--) {
        for (let z = RANGE.z1; z <= RANGE.z2; z++) {
            for (let x = RANGE.x1; x <= RANGE.x2; x++) {
                const n = bname(x, y, z);
                if (n === 'chest' || n === 'trapped_chest') chestCandidates.push({ x, y, z });
            }
        }
    }
    if (chestCandidates.length) {
        const c = chestCandidates[0];
        chest.pos = [c.x, c.y, c.z];
        try {
            cmd(`tp ${LANE_B.username} ${c.x} ${c.y + 2} ${c.z + 1}`);
            await sleep(2500);
            const win = await bot.openChest(bot.blockAt(new Vec3(c.x, c.y, c.z)));
            const agg = new Map();
            for (const it of win.containerItems()) agg.set(it.name, (agg.get(it.name) ?? 0) + it.count);
            chest.items = Object.fromEntries(agg);
            try { win.close(); } catch { /* 忽略 */ }
        } catch (e) { chest.error = String(e?.message ?? e).slice(0, 160); }
    }

    // —— 阶段 4：岩浆源 + 水源（派单合格判据）——
    const portalY = best ? best.origin.y : (scoutYs.length ? Math.round(scoutYs.reduce((a, b) => a + b, 0) / scoutYs.length) : 70);
    // ★ tp 高度同样要跟着修正：原来固定 110，门在 y=40 时会摔下去、影响 findBlocks 的已加载区块。
    cmd(`tp ${LANE_B.username} ${cx} ${Math.min(110, yHi + 6)} ${cz}`);
    await sleep(6000);
    const scanLiq = (name) => {
        let found = [];
        try {
            found = bot.findBlocks({
                matching: (b) => b && (b.name === name || b.name === `flowing_${name}`),
                count: 800, maxDistance: SCAN_R,
            }) ?? [];
        } catch { found = []; }
        const out = [];
        for (const f of found) {
            const bb = bot.blockAt(new Vec3(f.x, f.y, f.z));
            if (!bb) continue;
            let level = null;
            try { level = bb.getProperties?.()?.level ?? null; } catch { level = null; }
            if (level !== 0) continue;                      // 只要源块
            out.push({ at: [f.x, f.y, f.z], name: bb.name, dist: Math.round(Math.hypot(f.x - cx, f.z - cz)) });
        }
        return out;
    };
    const lavaSrc = scanLiq('lava').map((s) => judgeLava(s, portalY)).sort((a, b) => a.dist - b.dist);
    const waterSrc = scanLiq('water').map((s) => judgeLava(s, portalY)).sort((a, b) => a.dist - b.dist);
    const lavaOk = lavaSrc.filter((l) => l.qualifies);
    const waterOk = waterSrc.filter((w) => w.qualifies);
    log(`[sel] 岩浆源 ${lavaSrc.length}（合格 ${lavaOk.length}） 水源 ${waterSrc.length}（合格 ${waterOk.length}）`);

    // —— 阶段 5：走得到吗（对最佳岩浆源实际导航一次，不 tp）——
    let walk = null;
    if (best && lavaOk.length) {
        const t = lavaOk[0];
        const start = new Vec3(cx, portalY + 2, cz);
        try {
            cmd(`tp ${LANE_B.username} ${cx} ${portalY + 3} ${cz}`);
            await sleep(4000);
            const p0 = bot.entity.position.floored();
            await bot.pathfinder.goto(new pf.goals.GoalNear(t.at[0], t.at[1] + 1, t.at[2], 2), { timeout: 90000, lavaGuard: true });
            const p1 = bot.entity.position.floored();
            walk = {
                target: t.at, ok: true,
                from: [p0.x, p0.y, p0.z], to: [p1.x, p1.y, p1.z],
                walked: Math.round(Math.hypot(p1.x - p0.x, p1.z - p0.z)),
            };
        } catch (e) {
            walk = { target: t.at, ok: false, error: String(e?.message ?? e).slice(0, 140) };
        }
        log(`[sel] 走到岩浆源：${walk?.ok ? 'OK' : 'FAIL'} ${JSON.stringify(walk?.walked ?? walk?.error ?? '')}`);
    }

    // —— 判定 ——
    // ★★ 假阳性闸门：r4 第一版「框体候选 0 → 缺 0 格 → 箱子 0 块 ≥ 0 → ✅ 合格」
    //   把两个根本没扫到门的种子判成了合格。**找不到框体 ≠ 不缺格**，
    //   它等于「工具没测到目标」，按手册 §5 必须先证伪工具、判失败重来。
    const toolFailed = !best;
    const chestObsidian = chest.items?.obsidian ?? 0;
    const chestFst = chest.items?.flint_and_steel ?? 0;
    const chestCanFix = !toolFailed && chestObsidian >= needNonOptional;
    const canCast = lavaOk.length > 0 && waterOk.length > 0;
    const qualifies = !toolFailed && needNonOptional <= 1 && (chestCanFix || canCast);

    const out = {
        seed: SEED, stamp: STAMP, at: new Date().toISOString(),
        bot: { dim, spawn: [spawn.x, spawn.y, spawn.z] },
        station: { center: [cx, cz], radius: R, range: RANGE, scoutYs },
        toolFailed,
        frames: frames.slice(0, 8),
        best,
        needCells, needNonOptional,
        chest: { ...chest, chestsFound: chestCandidates.length },
        liquids: {
            lavaSources: lavaSrc.slice(0, 12), lavaQualified: lavaOk.length,
            waterSources: waterSrc.slice(0, 12), waterQualified: waterOk.length,
            walk,
        },
        verdict: {
            needNonOptional, chestObsidian, chestFst, chestCanFix, canCast, qualifies, toolFailed,
            rule: `缺格 ≤1 且（箱子能补上 或 有合格岩浆源可局部浇筑）；岩浆合格 = 源块 + 水平≤${LAVA_MAX_DIST} + 垂直差≤${LAVA_MAX_DY}`,
        },
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'seed_select.json'), JSON.stringify(out, null, 2));

    const md = [];
    md.push(`# 备选种子 S1 取证与选种判定（${STAMP}）`, '');
    md.push(`- 种子 \`${SEED}\`；维度 ${dim}；站心 (${cx},${cz}) radius ${R}`);
    md.push(`- 取景区间 x${RANGE.x1}..${RANGE.x2} / y${RANGE.y1}..${RANGE.y2} / z${RANGE.z1}..${RANGE.z2}`);
    md.push(`- （y 区间来源：${scoutYs.length ? `route scout 采样 y=[${Math.min(...scoutYs)}..${Math.max(...scoutYs)}] ±8` : '⚠ scout 无采样，退回全高度'}）`, '');
    md.push('## 框体（生产几何 frameCells）', '');
    if (!best) md.push('**未找到含 ≥4 格 obsidian 的 4×5 足迹** ⇒ 工具没测到目标，**不可**据此判"缺 0 格"');
    else {
        md.push(`- 最佳：axis=\`${best.axis}\` origin=(${best.origin.x},${best.origin.y},${best.origin.z}) → **obsidian ${best.obs} / 必需缺格 ${best.missing.length} / 错块 ${best.wrong.length} / 内部脏 ${best.dirty.length}**`);
        if (best.missing.length) md.push(`  - 空气缺格：${best.missing.map((m) => m.pos.join(',')).join(' | ')}`);
        if (best.wrong.length) md.push(`  - 错块：${best.wrong.map((m) => `${m.pos.join(',')}=\`${m.got}\`${m.optional ? '(可省角)' : ''}`).join(' | ')}`);
        if (best.dirty.length) md.push(`  - 内部脏：${best.dirty.map((m) => `${m.pos.join(',')}=\`${m.got}\``).join(' | ')}`);
    }
    md.push(`- **⇒ 必须补的 obsidian = ${toolFailed ? '未知（工具失败）' : `${needNonOptional} 格`}**`, '');
    md.push('## 箱子（服务端实开）', '');
    if (!chest.pos) md.push('- 区间内**没有箱子**');
    else md.push(`- @ (${chest.pos.join(',')})，区间内共 ${chest.candidates ?? 0} 个；内容：${chest.error ? `开箱失败 ${chest.error}` : `\`${Object.entries(chest.items ?? {}).map(([k, v]) => `${k}x${v}`).join('` `') || '(空)'}`}`);
    md.push(`- **obsidian ${chestObsidian} 块 / flint_and_steel ${chestFst} 个 ⇒ 箱子能补齐？ ${chestCanFix ? '✅' : '❌'}**`, '');
    md.push(`## 液体（合格 = 源块 + 水平≤${LAVA_MAX_DIST} + 垂直差≤${LAVA_MAX_DY}）`, '');
    md.push(`- 岩浆源共 ${lavaSrc.length}，**合格 ${lavaOk.length}**${lavaOk.length ? `：${lavaOk.slice(0, 4).map((l) => `${l.at.join(',')}(${l.dist}格,Δy=${l.dy})`).join(' | ')}` : ''}`);
    if (lavaSrc.length && !lavaOk.length) md.push(`  - 最接近的：${lavaSrc.slice(0, 3).map((l) => `${l.at.join(',')}(${l.dist}格,Δy=${l.dy})`).join(' | ')}`);
    md.push(`- 水源共 ${waterSrc.length}，**合格 ${waterOk.length}**${waterOk.length ? `：${waterOk.slice(0, 4).map((w) => `${w.at.join(',')}(${w.dist}格,Δy=${w.dy})`).join(' | ')}` : ''}`);
    if (walk) md.push(`- **走得到？ ${walk.ok ? `✅ 从 (${walk.from.join(',')}) 走到 (${walk.to.join(',')})，实走 ${walk.walked} 格` : `❌ ${walk.error}`}**`);
    md.push('', '## 判定', '');
    md.push(`- 缺格 **${toolFailed ? '未知' : needNonOptional}**（须 ≤1）｜箱子 obsidian **${chestObsidian}**（可补：${chestCanFix ? '是' : '否'}）｜合格岩浆+水：${canCast ? '是' : '否'}`);
    if (toolFailed) md.push('- ### **❌ 工具失败（未测到框体）—— 本次结果不可用于选种，需修区间后重跑**');
    else md.push(`- ### **${qualifies ? '✅ 合格 → 可作 S1 开发种子' : '❌ 不合格'}**`);
    const mdTxt = md.join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'seed_select.md'), mdTxt);
    console.log(mdTxt);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
