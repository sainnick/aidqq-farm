﻿import fs from 'node:fs'; import path from 'node:path';
const root='D:/AI斗蛐蛐/docs/research/data/src-1161';
const hits=[];
(function walk(d){ let e=[]; try{e=fs.readdirSync(d,{withFileTypes:true})}catch{return}
  for(const x of e){ const p=path.join(d,x.name); if(x.isDirectory()) walk(p); else if(/Portal(Shape|Block)\.java$/.test(x.name)) hits.push(p); } })(root);
console.log('found:',hits.join('\n       '));
for(const h of hits){
  const L=fs.readFileSync(h,'utf8').split(/\r?\n/);
  L.forEach((l,i)=>{ if(/topLeft|topRight|offset\(i, 0|offset\(0, j|this\.width|this\.height|calculateTopRight|setBlockState/.test(l)) console.log(path.basename(h)+':'+(i+1)+': '+l.trim().slice(0,140)); });
}
