// s1_stand_path_pick.mjs — MC-M1-TASK-08 r20
//
// 干什么：两件事，都只用**存档真值**（bench/route/probe/_s1_main_fresh，主种子 fresh world）：
//   ① 按任务单给的判据枚举并排序作业站位（不二选一）：
//        A 脚下实心非危险（body 空气族 / foot 实心非危险）
//        B 脚边与脚下一圈无岩浆（水平 4 邻 + 上下 2 格 = 6 邻，无 lava/flowing_lava/magma_block）
//        C **眼睛**到每个目标 ≤ 4.5 格（眼睛 = feet.y + 1.62；目标 = 目标格中心 (y+0.5)）
//      三个都满足的才叫"合规站位"；全都不满足时按任务单 fallback 到 186,41,306。
//   ② 在存档里搜一条**真站得住、且不与岩浆/岩浆块相邻**的路径（入口 → 门框边），
//      替换掉 r19 那批"从没验证过可走性"的几何路点。
//
// ★ 硬线：读不到（null / 'unknown'）一律记 unreadable，**绝不折算成空气**（手册 §5 头号反例）。
//   危险优先于几何：身体格本身是危险 ⇒ 直接判不合格，不许被"空气族检查"掩盖。
//
// 用法：node s1_stand_path_pick.mjs [--world=<dir>] [--out=<json>]

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';
import { openWorld } from '../../route/tools/region_reader.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const argOf = (k, d) => {
  const a = process.argv.find((x) => x.startsWith(`--${k}=`));
  return a ? a.slice(k.length + 3) : d;
};
const WORLD = argOf('world', 'D:/AI斗蛐蛐/bench/route/probe/_s1_main_fresh/4926685115947721762');
const OUT = argOf('out', path.join(HERE, 's1_stand_path.json'));

// ── 族定义（1.16.1；cave_air/void_air 是 1.13 起就有的）
const AIR = new Set(['air', 'cave_air', 'void_air']);
const LIQUID = new Set(['water', 'flowing_water', 'lava', 'flowing_lava']);
const HAZARD = new Set(['lava', 'flowing_lava', 'magma_block']);

/** 读方块：null / undefined / 'unknown' / 非字符串 ⇒ 记 unreadable，**不当空气** */
const unread = [];
const seenUnread = new Set();
const world = openWorld(WORLD, { dims: ['overworld'] });
const read = (x, y, z) => {
  let n;
  try { n = world.blockAt(x, y, z); } catch { n = null; }
  if (n === undefined || n === null || n === '' || n === 'unknown' || n === 'null' || n === 'undefined') {
    const k = `${x},${y},${z}`;
    if (!seenUnread.has(k)) { seenUnread.add(k); unread.push(k); }
    return null;
  }
  return n;
};
const isAir = (n) => n !== null && AIR.has(n);
/** 实心非危险：不是空气、不是液体、不是危险、不是不可替换的"悬空" */
const solidNonHazard = (n) => n !== null && !AIR.has(n) && !LIQUID.has(n) && !HAZARD.has(n);

const FACES6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

// ── 判据 A+B+C
/** B：6 邻里危险格数（脚那一格也算在内 —— 它同样是"脚下的危险"） */
const hazardNear = (x, y, z) => {
  let n = 0;
  const at = [];
  for (const [dx, dy, dz] of FACES6) {
    if (read(x + dx, y + dy, z + dz) !== null && HAZARD.has(read(x + dx, y + dy, z + dz))) { n++; at.push(`${x + dx},${y + dy},${z + dz}`); }
  }
  return { n, at };
};
/** A：站得住 = 身体格空气族 + 脚下实心非危险 + 头格空气族（头格是硬条件，玩家高 1.8） */
const standable = (x, y, z) => {
  const body = read(x, y, z), foot = read(x, y - 1, z), head = read(x, y + 1, z);
  const why = [];
  if (body === null) why.push('body_unreadable');
  else if (HAZARD.has(body)) why.push('body_hazard');
  else if (!AIR.has(body)) why.push('body_not_air');
  if (foot === null) why.push('foot_unreadable');
  else if (HAZARD.has(foot)) why.push('foot_is_hazard');
  else if (!solidNonHazard(foot)) why.push('foot_not_solid');
  if (head === null) why.push('head_unreadable');
  else if (!AIR.has(head)) why.push('head_not_air');
  return { ok: why.length === 0, why, body, foot, head };
};
/** C：眼睛到目标格中心的三维距离 */
const EYE_H = 1.62;
const eyeDist = (sx, sy, sz, tx, ty, tz) =>
  Math.hypot(sx + 0.5 - (tx + 0.5), (sy + EYE_H) - (ty + 0.5), sz + 0.5 - (tz + 0.5));
const REACH_MAX = 4.5;

// ── 目标清单（r20：补两格！）
//   挖 (187,42,310) 哭泣黑曜石 → 舀 (187,40,308)/(187,40,309) → 补 (187,42,307) 与 (187,42,310) → 点火 (187,41,308)
const TARGETS = [
  { what: 'dig', xyz: [187, 42, 310], order: 10, tool: 'iron_pickaxe' },
  { what: 'scoop_lava', xyz: [187, 40, 308], order: 20 },
  { what: 'scoop_lava', xyz: [187, 40, 309], order: 21 },
  { what: 'fill_cell', xyz: [187, 42, 307], order: 30, how: 'two_bucket' },
  { what: 'fill_cell', xyz: [187, 42, 310], order: 31, how: 'two_bucket' },
  { what: 'ignite', xyz: [187, 41, 308], order: 90 },
];
/** 框内 6 格（源码 a() 判据：必须全是空气/可替换/门方块，岩浆水圆石都不行） */
const FRAME_INNER = [];
for (let y = 40; y <= 42; y++) for (let z = 308; z <= 309; z++) FRAME_INNER.push([187, y, z]);

// ═══════════════════ ① 站位枚举 ═══════════════════
const ENUM = { x0: 178, x1: 200, y0: 36, y1: 48, z0: 300, z1: 322 };
const cands = [];
for (let x = ENUM.x0; x <= ENUM.x1; x++) {
  for (let y = ENUM.y0; y <= ENUM.y1; y++) {
    for (let z = ENUM.z0; z <= ENUM.z1; z++) {
      const s = standable(x, y, z);
      if (!s.ok) continue;
      const hz = hazardNear(x, y, z);
      // 眼睛到每个目标的最远距离（主键：越小越好）
      const dists = TARGETS.map((t) => eyeDist(x, y, z, t.xyz[0], t.xyz[1], t.xyz[2]));
      const far = Math.max(...dists);
      const unreachable = TARGETS.filter((t, i) => dists[i] > REACH_MAX).map((t) => t.what + '@' + t.xyz.join(','));
      cands.push({
        cell: [x, y, z], foot: s.foot, hazardNear: hz.n, hazardAt: hz.at,
        farEye: Number(far.toFixed(3)), dists: dists.map((d) => Number(d.toFixed(2))),
        noHazard: hz.n === 0, withinReach: far <= REACH_MAX, unreachable,
        compliant: hz.n === 0 && far <= REACH_MAX,
      });
    }
  }
}
// 排序：先合规、再无危险、再远距离小、最后坐标字典序（**全序**，不靠输入顺序）
cands.sort((a, b) => (b.compliant - a.compliant) || (a.noHazard - b.noHazard)
  || (a.hazardNear - b.hazardNear) || (a.farEye - b.farEye)
  || (a.cell[0] - b.cell[0]) || (a.cell[1] - b.cell[1]) || (a.cell[2] - b.cell[2]));

// ═══════════════════ ② 路径搜索（严格可走：BFS over 严格站得住 ∧ 6 邻无危险） ═══════════════════
const walkable = (x, y, z) => {
  const s = standable(x, y, z);
  if (!s.ok) return false;
  return hazardNear(x, y, z).n === 0;
};
/** 起点：地表入口（存档里读到的真实站得住格）；终点：门框边一圈 */
const ENTRY = [206, 64, 242];
const entryOk = walkable(ENTRY[0], ENTRY[1], ENTRY[2]);

const GOALS = [];
for (let x = 183; x <= 191; x++) for (let y = 39; y <= 44; y++) for (let z = 305; z <= 313; z++) {
  if (walkable(x, y, z)) GOALS.push([x, y, z]);
}

const BFS = { x0: 178, x1: 202, y0: 34, y1: 70, z0: 298, z1: 324 };
const key = (x, y, z) => `${x},${y},${z}`;
const prev = new Map();
let found = null;
if (entryOk) {
  const q = [ENTRY];
  prev.set(key(...ENTRY), null);
  let qi = 0;
  const goalSet = new Set(GOALS.map((g) => key(...g)));
  while (qi < q.length && found === null) {
    const [cx, cy, cz] = q[qi++];
    if (goalSet.has(key(cx, cy, cz))) { found = [cx, cy, cz]; break; }
    for (const [dx, dy, dz] of FACES6) {
      if (dy !== 0 && Math.abs(dy) > 1) continue;                 // 只允许平走 / 上 1 / 下 1
      const nx = cx + dx, ny = cy + dy, nz = cz + dz;
      if (nx < BFS.x0 || nx > BFS.x1 || ny < BFS.y0 || ny > BFS.y1 || nz < BFS.z0 || nz > BFS.z1) continue;
      const k = key(nx, ny, nz);
      if (prev.has(k)) continue;
      if (!walkable(nx, ny, nz)) continue;
      prev.set(k, [cx, cy, cz]);
      q.push([nx, ny, nz]);
    }
  }
}
let pathCells = null;
if (found) {
  pathCells = [];
  let cur = found;
  while (cur) { pathCells.push(cur); cur = prev.get(key(...cur)); }
  pathCells.reverse();
}

// ═══════════════════ 输出 ═══════════════════
const compliant = cands.filter((c) => c.compliant);
const doc = {
  world: WORLD,
  criteria: { reachMax: REACH_MAX, eyeHeight: EYE_H, hazardFaces: 6, body: '空气族', foot: '实心非危险', head: '空气族' },
  targets: TARGETS,
  frameInner: FRAME_INNER,
  stands: {
    totalCandidates: cands.length,
    compliantCount: compliant.length,
    chosen: compliant.length ? compliant[0] : null,
    top: cands.slice(0, 12),
  },
  path: {
    entry: ENTRY, entryWalkable: entryOk,
    goalCount: GOALS.length,
    found: !!found, length: pathCells ? pathCells.length : 0,
    cells: pathCells,
  },
  unreadable: unread,
};
fs.writeFileSync(OUT, JSON.stringify(doc, null, 2) + '\n', 'utf8');
if (!fs.existsSync(OUT)) throw new Error('没落盘: ' + OUT);

console.log('=== 站位（判据：脚下实心非危险 ∧ 6 邻无危险 ∧ 眼睛到每个目标 ≤' + REACH_MAX + '）===');
console.log('候选站得住的格子: ' + cands.length + '，其中合规: ' + compliant.length);
console.log('前 8:');
for (const c of cands.slice(0, 8)) {
  console.log(`  ${JSON.stringify(c.cell)} foot=${c.foot} hazardNear=${c.hazardNear} farEye=${c.farEye} `
    + `${c.compliant ? 'COMPLIANT' : ''}${c.withinReach ? '' : ' 够不着:' + c.unreachable.join('|')}`);
}
console.log('\n=== 路径（严格可走：BFS over 站得住 ∧ 6 邻无危险，|dy|≤1）===');
console.log('入口 ' + JSON.stringify(ENTRY) + ' 可走=' + entryOk + '，可达终点数=' + GOALS.length);
console.log(pathCells
  ? '找到路径，长度 ' + pathCells.length + '：' + pathCells.map((c) => c.join(',')).join(' → ')
  : '★ 严格可走路径不存在（存档真值：这 99 个路点走不通）');
console.log('\nunreadable 格数: ' + unread.length + (unread.length ? '：' + unread.slice(0, 20).join(' ') : ''));
console.log('已写 ' + OUT);
