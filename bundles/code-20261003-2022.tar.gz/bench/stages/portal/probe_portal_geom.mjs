// probe_portal_geom.mjs — 主种子废弃传送门「框体到底缺几格」+ 箱子真实战利品 + 岩浆站可用性
//
// 为什么要它（开工前的读数发现的疑点，必须用**服务端真值**定案，不能靠推理 probe JSON）：
//   ① 派单 §B 的前提是「主种子废弃门框体 = obsidian:9 + crying:1，**只差 1 格**」。
//      但 bench/route/probe 的采样点（fill-replace 逐格采样，服务器权威）读出来的几何是：
//        crying_obsidian (180,77,356)
//        obsidian (180,77..80,355) 与 (180,77..80,358)   ← 两根侧柱，z 向 4 格宽
//        另有 (177,75,354)、(178,76,356) 两块**不在这个框里**
//      按 4×5 门框（z=355..358 × y=77..81）算，**底行/顶行缺的不是一个「格」，而是 6–7 格**。
//      若属实 → 「开箱拿 1 块黑曜石补上」这条路在期望上根本不够（E=0.61 块/箱）。
//   ② 上一轮 bot 把框定位成 origin(177,75,354) axis=x，随后挖了
//      (178,76,354)/(179,76,354)/(180,76,354)/(180,77,354) 四格 —— 那是**错框的内部**，
//      相当于在拆真实地形。需要确认框到底该沿哪个轴、缺哪几格。
//   ③ ROUTE-02 的 S1b_lava_pool 站心 (160,336) 离门只有 22.6 格，看着很近；但它的
//      hitBoxes **全部落在 y=0..15**（近基岩层）—— 若岩浆真在 y≈10，从 y≈78 的门框
//      搬一桶岩浆要爬 60+ 格，路线 B / 局部浇筑的代价与「22.6 格」给人的印象完全不同。
//
// 本脚本只取证，不改任何任务层/共享文件；起停只碰泳道 B（25567/25577）。
// 公平口径：本脚本是**赛前预勘取证**（与 SEED-03/ROUTE-02 同源的服务器权威通道），
// 产出只进报告与 route 草稿，不进任务层。
//
// 用法：node probe_portal_geom.mjs --stamp P8R3_GEOM --seed -8839485814800629942

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const STAMP = argOf(process.argv, 'stamp', 'P8R3_GEOM');
const SEED = argOf(process.argv, 'seed', '-8839485814800629942');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'GeomBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};

const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null;
let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };

// —— 取证范围（覆盖 probe 采样到的全部结构块 + 余量）——
const BOX = { x1: 172, x2: 188, y1: 70, y2: 86, z1: 348, z2: 364 };
const PORTAL_HINT = { x: 180, y: 80, z: 356 };      // probe 里框体最高那格附近
const LAVA_STATION = { x: 160, z: 336 };            // ROUTE-02 S1b_lava_pool 站心

const SYM = {
    air: '.', cave_air: '.', void_air: '.',
    obsidian: 'O', crying_obsidian: 'C', chest: 'H', trapped_chest: 'H',
    lava: 'L', flowing_lava: 'l', water: 'w', flowing_water: 'W',
    stone: 's', dirt: 'd', grass_block: 'g', netherrack: 'n',
    gold_block: 'G', gilded_blackstone: 'b', bedrock: 'B',
    fire_charge: 'F', flint: 'f', flint_and_steel: 'S', golden_apple: 'A',
};
const symOf = (n) => (n && SYM[n]) || (n ? n[0].toUpperCase() : '?');

async function tpTo(x, y, z, settleMs = 2500) {
    cmd(`tp ${LANE_B.username} ${x} ${y} ${z}`);
    await sleep(settleMs);
}

/** 逐格读 box，返回 {layers: Map(y -> string[]), counts, unloaded} */
function dumpBox(b) {
    const layers = new Map();
    const counts = new Map();
    let unloaded = 0;
    for (let y = BOX.y1; y <= BOX.y2; y++) {
        const rows = [];
        for (let z = BOX.z1; z <= BOX.z2; z++) {
            let row = '';
            for (let x = BOX.x1; x <= BOX.x2; x++) {
                let blk = null;
                try { blk = bot.blockAt(new Vec3(x, y, z)); } catch { blk = null; }
                if (!blk) { unloaded++; row += '?'; continue; }
                counts.set(blk.name, (counts.get(blk.name) ?? 0) + 1);
                row += symOf(blk.name);
            }
            rows.push(row);
        }
        layers.set(y, rows);
    }
    return { layers, counts, unloaded };
}

function renderLayers(layers) {
    const out = [];
    const ys = [...layers.keys()].sort((a, b) => b - a);
    const xs = [];
    for (let x = BOX.x1; x <= BOX.x2; x++) xs.push(String(Math.abs(x) % 10));
    out.push(`x= ${xs.join('')}`);
    for (const y of ys) {
        out.push(`--- y=${y} ---`);
        for (const row of layers.get(y)) out.push(`z${row[0] ? '' : ''}${row}`);
    }
    return out.join('\n');
}

/** 门框判定：沿两轴各试 4×5 足迹，返回命中最多者（服务端真值，不猜） */
function detectFrames(countsByName) {
    const isFrameBlock = (n) => n === 'obsidian' || n === 'crying_obsidian';
    const cells = frameCellsList();
    const out = [];
    for (const axis of ['x', 'z']) {
        for (let oy = BOX.y1; oy <= BOX.y2 - 4; oy++) {
            for (let ox = BOX.x1; ox <= BOX.x2 - 3; ox++) {
                for (let oz = BOX.z1; oz <= BOX.z2 - 3; oz++) {
                    const origin = axis === 'x' ? { x: ox, y: oy, z: oz } : { x: ox, y: oy, z: oz };
                    let present = 0, missing = 0, wrong = 0, dirty = 0;
                    const missList = [], wrongList = [], dirtyList = [];
                    for (const c of cells(origin, axis)) {
                        let blk = null;
                        try { blk = bot.blockAt(new Vec3(c.x, c.y, c.z)); } catch { blk = null; }
                        const n = blk?.name ?? null;
                        if (n === 'obsidian') present++;
                        else if (!n || n === 'air' || n === 'cave_air' || n === 'void_air') { missing++; missList.push([c.x, c.y, c.z, 'air']); }
                        else if (n === 'crying_obsidian') { dirty++; dirtyList.push([c.x, c.y, c.z, n]); }
                        else { wrong++; wrongList.push([c.x, c.y, c.z, n]); }
                    }
                    for (const c of interiorCellsList(origin, axis)) {
                        let blk = null;
                        try { blk = bot.blockAt(new Vec3(c.x, c.y, c.z)); } catch { blk = null; }
                        const n = blk?.name ?? null;
                        if (n && n !== 'air' && n !== 'cave_air' && n !== 'void_air') { dirty++; dirtyList.push([c.x, c.y, c.z, n]); }
                    }
                    if (present + dirty >= 6 && (wrong === 0)) {
                        out.push({ axis, origin, present, missing, wrong, dirty, missList, wrongList, dirtyList });
                    }
                }
            }
        }
    }
    out.sort((a, b) => (b.present + b.dirty) - (a.present + a.dirty) || a.missing - b.missing);
    return out;
}

// 与 nether.js 同口径：4 宽 × 5 高，底行 + 两侧 + 顶行
function frameCellsList() {
    return (origin, axis) => {
        const cells = [];
        for (let u = 0; u < 4; u++) cells.push({ x: origin.x + u, y: origin.y, z: origin.z });          // 底行
        for (let dy = 1; dy <= 3; dy++) {
            cells.push({ x: origin.x, y: origin.y + dy, z: origin.z });
            cells.push({ x: origin.x + 3, y: origin.y + dy, z: origin.z });
        }
        for (let u = 0; u < 4; u++) cells.push({ x: origin.x + u, y: origin.y + 4, z: origin.z });      // 顶行
        return cells;
    };
}
function interiorCellsList() {
    return (origin, axis) => {
        const cells = [];
        for (let u = 1; u <= 2; u++) {
            for (let dy = 1; dy <= 3; dy++) cells.push({ x: origin.x + u, y: origin.y + dy, z: origin.z });
        }
        return cells;
    };
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[geom] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[geom] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[geom] server up in ${(server.bootMs / 1000).toFixed(0)}s seed=${SEED}`);

    const mineflayer = require('mineflayer');
    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    log('[geom] bot in');
    await sleep(3000);
    cmd(`op ${LANE_B.username}`);
    cmd(`gamerule doDaylightCycle false`);
    cmd(`gamerule doWeatherCycle false`);
    cmd(`time set day`);
    await sleep(1000);

    // ① 门框几何：tp 到门附近，强制加载后逐格读
    await tpTo(PORTAL_HINT.x, 100, PORTAL_HINT.z, 6000);
    const dump = dumpBox(bot);
    const layersTxt = renderLayers(dump.layers);
    fs.writeFileSync(path.join(RUNS_DIR, 'portal_layers.txt'), layersTxt);
    log(`[geom] box dump: unloaded=${dump.unloaded}, distinct=${dump.counts.size}`);

    const frames = detectFrames();
    fs.writeFileSync(path.join(RUNS_DIR, 'frames.json'), JSON.stringify({ box: BOX, frames }, null, 2));

    // ② 箱子真实战利品（服务端开箱 = 真值，不用战利品表推算）
    const chestPos = findChest();
    let chestItems = null;
    if (chestPos) {
        try {
            await tpTo(chestPos.x, chestPos.y + 2, chestPos.z + 1, 1500);
            const blk = bot.blockAt(new Vec3(chestPos.x, chestPos.y, chestPos.z));
            const win = await bot.openChest(blk);
            chestItems = win.containerItems().map((i) => `${i.name}x${i.count}`);
            try { win.close(); } catch { /* 忽略 */ }
        } catch (e) {
            chestItems = [`ERROR: ${String(e).slice(0, 120)}`];
        }
    }

    // ③ 岩浆：ROUTE-02 站心正上方的垂直剖面 + 站心半径 24 内的源块
    await tpTo(LAVA_STATION.x, 100, LAVA_STATION.z, 5000);
    const col = [];
    for (let y = 0; y <= 100; y += 1) {
        let blk = null;
        try { blk = bot.blockAt(new Vec3(LAVA_STATION.x, y, LAVA_STATION.z)); } catch { blk = null; }
        if (blk && (blk.name === 'lava' || blk.name === 'flowing_lava')) {
            const lvl = (() => { try { return blk.getProperties?.()?.level ?? null; } catch { return null; } })();
            col.push({ y, name: blk.name, level: lvl, isSource: lvl === 0 });
        }
    }
    // 站心 24 格内的岩浆源块（公平口径：bot 自己看得见的）
    let lavas = [];
    try {
        lavas = bot.findBlocks({ matching: (b) => b && (b.name === 'lava' || b.name === 'flowing_lava'), count: 400, maxDistance: 32 }) ?? [];
    } catch { lavas = []; }
    const srcs = [];
    for (const l of lavas) {
        const bb = bot.blockAt(new Vec3(l.x, l.y, l.z));
        const lvl = (() => { try { return bb?.getProperties?.()?.level ?? null; } catch { return null; } })();
        if (lvl === 0) {
            srcs.push({ at: [l.x, l.y, l.z], distToPortal: Math.round(Math.hypot(l.x - PORTAL_HINT.x, l.z - PORTAL_HINT.z)) });
        }
    }
    srcs.sort((a, b) => a.distToPortal - b.distToPortal);

    const out = {
        stamp: STAMP, seed: SEED, at: new Date().toISOString(),
        box: BOX, unloadedCells: dump.unloaded,
        boxCounts: Object.fromEntries([...dump.counts.entries()].sort((a, b) => b[1] - a[1])),
        frames,
        chest: { pos: chestPos, items: chestItems },
        lavaStation: { center: LAVA_STATION, columnLava: col, sourcesWithin32: srcs },
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'geom_result.json'), JSON.stringify(out, null, 2));

    // —— 人读的摘要 ——
    const md = [];
    md.push(`# 主种子废弃传送门框体取证（${STAMP}）`, '');
    md.push(`- 种子 \`${SEED}\`；取景区间 x${BOX.x1}..${BOX.x2} / y${BOX.y1}..${BOX.y2} / z${BOX.z1}..${BOX.z2}；未加载格 ${dump.unloaded}`);
    md.push(`- 区间方块计数：${Object.entries(out.boxCounts).slice(0, 12).map(([k, v]) => `${k}=${v}`).join('  ')}`, '');
    md.push('## 框体候选（服务端逐格真值，按 obsidian 数排序）', '');
    if (!frames.length) md.push('**没有命中任何 4×5 足迹** —— 框体残破程度超出「补几格」的量级。');
    for (const f of frames.slice(0, 6)) {
        md.push(`- axis=${f.axis} origin=(${f.origin.x},${f.origin.y},${f.origin.z}) → **已有 obsidian ${f.present} / 缺 ${f.missing} / 错块 ${f.wrong} / 脏格 ${f.dirty}**`);
        if (f.missList.length) md.push(`  - 缺：${f.missList.map((m) => m.slice(0, 3).join(',')).join(' | ')}`);
        if (f.dirtyList.length) md.push(`  - 脏：${f.dirtyList.map((m) => `${m.slice(0, 3).join(',')}=${m[3]}`).join(' | ')}`);
    }
    md.push('', '## 箱子真实战利品', '');
    md.push(chestPos ? `- 箱子 @ (${chestPos.x},${chestPos.y},${chestPos.z})：**${(chestItems ?? []).join(', ') || '(空)'}**` : '- **区间内没找到箱子**');
    md.push('', '## 岩浆（ROUTE-02 S1b_lava_pool 站心正上方垂直剖面）', '');
    md.push(col.length ? `- 站心 (${LAVA_STATION.x},*,${LAVA_STATION.z}) 的岩浆层：${col.map((c) => `y=${c.y}${c.isSource ? '(源)' : '(流)'}`).join(', ')}` : '- 站心正上方**没有岩浆**');
    md.push(`- 站心 32 格内岩浆**源块** ${srcs.length} 个${srcs.length ? `：${srcs.slice(0, 8).map((s) => `${s.at.join(',')}(离门${s.distToPortal})`).join(' | ')}` : ''}`);
    md.push('', '## 逐层图（x 从 ' + BOX.x1 + ' 到 ' + BOX.x2 + '，每行一个 z）', '', '```', layersTxt, '```', '');
    const mdTxt = md.join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'geom_report.md'), mdTxt);
    console.log(mdTxt);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

function findChest() {
    for (let y = BOX.y2; y >= BOX.y1; y--) {
        for (let z = BOX.z1; z <= BOX.z2; z++) {
            for (let x = BOX.x1; x <= BOX.x2; x++) {
                let b = null;
                try { b = bot.blockAt(new Vec3(x, y, z)); } catch { b = null; }
                if (b && (b.name === 'chest' || b.name === 'trapped_chest')) return { x, y, z };
            }
        }
    }
    return null;
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
