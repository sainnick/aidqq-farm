// portal_bot.mjs — MC-M1-TASK-08 S1+S4a benchmark 执行机器人（standalone）
//
// 与 basic-iron/exec_bot.mjs 同协议（零 kit 零 RCON 零 LLM），差别三处：
//   1. 根任务 = PortalStageTask（S1 地狱门 + S4a 进下界），不走 agent.js 的
//      MISSION→AcquireResourceTask 分发（agent.js:268 是写死 AcquireResourceTask 的，
//      而 standalone bot 本来就自己 new 根任务，所以**不需要改任何共享文件**）。
//   2. MC_MINDCRAFT_ROOT：默认指向本线 worktree（D:\AI斗蛐蛐\mindcraft-wt\s1-portal），
//      避免和主线 A 的 D:\AI斗蛐蛐\mindcraft 串。全部既有 stage 的 MINDCRAFT 是写死的
//      （basic-iron/exec_bot.mjs:29、micro-place/place_bot.mjs:19），这里只改本文件这一行。
//   3. --kit-desc / kit_done.json：runner_core 会给，但**没有任何既有 bot 消费它**
//      （已全量 grep 确认）——所以这里自己实现闸门：等 marker + 复核背包，再开任务。
//
// 用法：
//   node portal_bot.mjs --trial 1 --seed <seed> --out <runDir> [--port 25567]
//                      [--username TaskBotB] [--timeout-ms 900000] [--mc-version 1.16.1]
//                      [--kit-desc "<items>"] [--kit-depth 28] [--mode portal|realchain]
//                      [--no-trip] [--no-return] [--probe-ms 10000]

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
// ★ 本单唯一改动：根目录指向 worktree。runner 也可用 MC_MINDCRAFT_ROOT 覆盖。
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}
const hasFlag = (name) => process.argv.includes(`--${name}`);

const TRIAL = parseInt(arg('trial', '0'), 10);
const SEED = arg('seed', 'unknown');
const OUT_DIR = arg('out', BENCH_DIR);
const PORT = parseInt(arg('port', '25567'), 10);
const USERNAME = arg('username', 'TaskBotB');
const TIMEOUT_MS = parseInt(arg('timeout-ms', '900000'), 10);
const MC_VERSION = arg('mc-version', '1.16.1');
const KIT_DESC = arg('kit-desc', '');
const KIT_DEPTH = parseInt(arg('kit-depth', '0'), 10);
const MODE = arg('mode', 'portal');          // portal | realchain
const PROBE_MS = parseInt(arg('probe-ms', '10000'), 10);
const NO_TRIP = hasFlag('no-trip');
const NO_RETURN = hasFlag('no-return');
const REALCHAIN_ITEMS = arg('realchain', 'flint_and_steel,bucket').split(',');

// —— L2 站级（补充单 §1.2/§1.3）——
// route 文件只由 bench 传给任务层；**任务层自己不会去猜路径**，也不接受坐标参数。
// 开发局带 --allow-draft（草稿 frozenAt=null）；正式矩阵/拍摄局必须不带。
const ROUTE_FILE = arg('route', path.join(ROOT, 'bench', 'route', '-8839485814800629942.draft.json'));
const STATION_ID = arg('station', 'S1_portal');
const ALLOW_DRAFT = hasFlag('allow-draft');
const STATION_OFFSET = parseInt(arg('station-offset', '0'), 10) || 0;
const TRIP_DIST = parseInt(arg('trip-dist', '96'), 10) || 96;
const CONFIRM_TURNS = parseInt(arg('confirm-turns', '6'), 10) || 6;

const TELEMETRY = path.join(OUT_DIR, 'telemetry.jsonl');
const RESULT = path.join(OUT_DIR, 'result.json');
const LOG = path.join(OUT_DIR, 'bot.log');
const PROBE = path.join(OUT_DIR, 'probe.jsonl');
const KIT_MARKER = path.join(OUT_DIR, 'kit_done.json');

fs.mkdirSync(OUT_DIR, { recursive: true });
const logLine = (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(LOG, line + '\n'); } catch { /* 忽略 */ }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let finished = false;
let _spawned = false;
let _runtime = null;
let _probeTimer = null;
let _lastDim = null;
const _dimChanges = [];

// —— runner 级进度探针（runner_core awaitBotExit 靠它判无进展）——
function probeTree(rt) {
    try { return (rt?._ctx?.stack?.renderTrace?.() ?? '').replace(/\[[^\]]*\]/g, '[]'); } catch { return ''; }
}
function startProbe(bot) {
    if (!(PROBE_MS > 0)) return;
    try { fs.rmSync(PROBE, { force: true }); } catch { /* 忽略 */ }
    _probeTimer = setInterval(() => {
        try {
            const inv = bot.inventory.items().map((i) => `${i.name}:${i.count}`).sort().join(',');
            const p = bot.entity?.position;
            fs.appendFileSync(PROBE, JSON.stringify({
                t: Date.now(), event: 'bench_probe',
                inv,
                pos: p ? [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)] : null,
                digging: !!bot.targetDigBlock,
                furnace: null,
                // 维度是本单新增的保活维度：下界往返期间 pos/inv 长时间不变，
                // 没有 dim 会被 runner 当成"无进展"硬中止。
                dim: bot.game?.dimension ?? null,
                tree: probeTree(_runtime),
            }) + '\n');
        } catch { /* 探针失败不影响试局 */ }
    }, PROBE_MS);
    _probeTimer.unref?.();
}

function finish(summary, code) {
    if (finished) return;
    finished = true;
    clearTimeout(hardKill);
    if (_probeTimer) clearInterval(_probeTimer);
    try {
        fs.writeFileSync(RESULT, JSON.stringify({
            trial: TRIAL, seed: SEED, port: PORT, username: USERNAME,
            mindcraftRoot: MINDCRAFT, mode: MODE,
            kit: KIT_DESC || 'none', kitDepth: KIT_DEPTH || null,
            dimChanges: _dimChanges, ...summary,
        }, null, 2));
    } catch (e) { logLine(`result write fail: ${e.message}`); }
    setTimeout(() => { try { botRef?.quit?.(); } catch { /* 忽略 */ } process.exit(code); }, 1200);
}

/**
 * kit 闸门：runner_core 的 give 通道是「等 bot 进服 → 逐个 give → 写 kit_done.json」，
 * 但它**不知道** bot 什么时候算准备好起任务。既有 bot 都没消费这个 marker（已 grep 确认），
 * 所以这里两段等：① marker 落盘 ② 背包里真的看到 kit 物品。
 */
async function waitForKit(bot) {
    if (!KIT_DESC) return { ok: false, why: 'no_kit' };
    const want = KIT_DESC.split(',').map((s) => s.trim()).filter(Boolean).map((s) => s.split(':')[0]);
    const t0 = Date.now();
    let marker = false;
    while (Date.now() - t0 < 120000) {
        if (fs.existsSync(KIT_MARKER)) { marker = true; break; }
        await sleep(300);
    }
    if (!marker) { logLine('kit: 120s 未见 kit_done.json（可能 runner 未传 --kit）'); return { ok: false, why: 'no_marker' }; }
    // 复核背包：give 是逐条 + 120ms 间隔，可能还在路上
    const t1 = Date.now();
    while (Date.now() - t1 < 30000) {
        const have = want.filter((n) => bot.inventory.items().some((i) => i.name === n));
        if (have.length === want.length) return { ok: true, want };
        await sleep(300);
    }
    const have = want.filter((n) => bot.inventory.items().some((i) => i.name === n));
    logLine(`kit: 超时，背包只到 ${have.length}/${want.length}（${have.join(',')}）`);
    return { ok: false, why: 'inv_timeout', have, want };
}

let botRef = null;
let hardKill = null;

/** 往下挖到目标 Y（bench 脚手架：只服务于「kit 复现真实链尾深度」这一条验收） */
async function digDownTo(bot, targetY, maxLayers = 80) {
    let dug = 0;
    for (let i = 0; i < maxLayers; i++) {
        const p = bot.entity?.position?.floored();
        if (!p) break;
        if (p.y <= targetY) break;
        try { bot.setControlState('sneak', true); } catch { /* 忽略 */ }
        const below = bot.blockAt(new (require('vec3'))(p.x, p.y - 1, p.z));
        if (below && below.boundingBox === 'block' && below.name !== 'lava' && below.name !== 'water') {
            try {
                const item = bot.inventory.items().find((i) => i.name.endsWith('pickaxe'))
                    ?? bot.inventory.items().find((i) => i.name.endsWith('shovel'));
                if (item) { await bot.equip(item, 'hand'); }
                await bot.dig(below);
                dug++;
            } catch { /* 挖不动就换个办法 */ }
        }
        await sleep(250);
    }
    try { bot.setControlState('sneak', false); } catch { /* 忽略 */ }
    // 掉进坑里后等落地
    for (let i = 0; i < 30; i++) {
        const p = bot.entity?.position;
        if (p && p.onGround) break;
        await sleep(100);
    }
    return { dug, y: bot.entity?.position?.floored()?.y ?? null };
}

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const toolPlugin = require('mineflayer-tool').plugin;
    const EX = (f) => import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec', f)).href);
    const { TaskRuntime } = await EX('task_runner.js');
    const { AcquireResourceTask } = await EX('acquire_resource_task.js');
    const { PortalStageTask } = await EX('portal_stage_task.js');
    const { countItems } = await EX('task.js');
    const { navigate } = { navigate: null };

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
    botRef = bot;
    bot.loadPlugin(pf.pathfinder);
    bot.loadPlugin(toolPlugin);

    hardKill = setTimeout(() => {
        logLine('HARD_TIMEOUT: runner watchdog fired, exiting without result');
        finish({ status: 'RUNNER_TIMEOUT' }, 1);
    }, TIMEOUT_MS + 60000);

    bot.on('kicked', (r) => { logLine(`kicked: ${r}`); if (!finished) finish({ status: 'KICKED', reason: String(r) }, 1); });
    bot.on('error', (e) => {
        logLine(`bot_error: ${String(e).slice(0, 200)}`);
        if (!finished && !_spawned) finish({ status: 'CONNECT_FAIL', reason: String(e).slice(0, 120) }, 1);
    });
    bot.on('death', () => {
        logLine('death event: respawning in 800ms');
        setTimeout(() => { try { bot.respawn(); } catch { /* 忽略 */ } }, 800);
    });
    // 维度切换保活 + 记录（本单新增：S4a 要跨维度，探针签名必须能反映）
    bot.on('spawn', () => {
        const d = bot.game?.dimension ?? null;
        if (_lastDim && d !== _lastDim) {
            _dimChanges.push({ from: _lastDim, to: d, t: Date.now() });
            logLine(`dimension: ${_lastDim} -> ${d}`);
        }
        _lastDim = d;
    });

    bot.once('spawn', async () => {
        _spawned = true;
        _lastDim = bot.game?.dimension ?? null;
        try {
            await sleep(4000);
            const spawnPos = bot.entity.position.floored();
            logLine(`spawn: seed=${SEED} dim=${_lastDim} pos=[${spawnPos.x},${spawnPos.y},${spawnPos.z}]`);
            logLine(`mindcraft root = ${MINDCRAFT}`);

            // —— kit 闸门（开发期用；正式矩阵不传 --kit-desc，整段跳过）——
            if (KIT_DESC) {
                const k = await waitForKit(bot);
                logLine(`kit gate: ${JSON.stringify(k)}`);
            }

            // —— kit 深度复现（任务单 §2：kit 局要复现真实链尾的**深度**，不只是背包）——
            if (KIT_DEPTH > 0) {
                const cur = bot.entity.position.floored().y;
                logLine(`kit depth: 目标 y=${KIT_DEPTH}，当前 y=${cur}`);
                if (cur > KIT_DEPTH + 2) {
                    // 往下挖到目标深度：sneak + 挖脚下（真实铁链尾就是一层层这么下去的）。
                    // 这是 bench 脚手架（复现真实前置的工况），不是任务层原语，故放 bot 里。
                    const r = await digDownTo(bot, KIT_DEPTH);
                    const now = bot.entity.position.floored();
                    logLine(`kit depth: 挖到 y=${now.y}（${JSON.stringify(r)}）`);
                    runtime.telemetry?.('kit_depth', { targetY: KIT_DEPTH, gotY: now.y, dug: r.dug });
                }
            }

            const invSnap = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',') || '(empty)';
            logLine(`inventory before task = [${invSnap}]`);

            const runtime = new TaskRuntime(bot, {
                mission: { resource: MODE === 'realchain' ? 'portal' : 'portal', count: 1, raw: 'enter nether' },
                telemetryPath: TELEMETRY, stackMaxDepth: 8,
            });
            _runtime = runtime;
            startProbe(bot);

            let root;
            if (MODE === 'realchain') {
                // 零 kit 真实链：依次 obtain，**只为记录链尾的位置/深度**（任务单 §2 第一条）。
                // 本单不依赖 S0（主线 A 做），所以这里只跑任务不判定成败。
                const { makeCtx } = await EX('task_runner.js');
                const { driveTask } = await EX('task_runner.js');
                const rc = makeCtx(bot, { telemetry: (e, d) => runtime.telemetry(e, d), stackMaxDepth: 8 });
                for (const it of REALCHAIN_ITEMS) {
                    const child = await driveTask(
                        new AcquireResourceTask({ resource: it, count: 1, timeoutMs: 540000 }),
                        rc, { tickMs: 250 });
                    const p = bot.entity.position.floored();
                    logLine(`realchain ${it}: ${child.status} reason=${child.failReason ?? '-'} pos=[${p.x},${p.y},${p.z}] dim=${bot.game?.dimension}`);
                    runtime.telemetry('realchain_step', {
                        item: it, status: child.status, reason: child.failReason ?? null,
                        y: p.y, x: p.x, z: p.z,
                    });
                }
                const p = bot.entity.position.floored();
                const chainTail = { y: p.y, x: p.x, z: p.z, inv: bot.inventory.items().map((i) => `${i.name}x${i.count}`) };
                logLine(`REALCHAIN TAIL = ${JSON.stringify(chainTail)}`);
                finish({ status: 'SUCCESS', realchainTail: chainTail, spawnPos: [spawnPos.x, spawnPos.y, spawnPos.z] }, 0);
                return;
            }

            root = new PortalStageTask({
                kit: !!KIT_DESC,
                timeoutMs: TIMEOUT_MS,
                shortTrip: !NO_TRIP,
                allowReturn: !NO_RETURN,
                anchorPath: path.join(OUT_DIR, 'anchor.json'),
                // L2 站级
                routeFile: ROUTE_FILE,
                stationId: STATION_ID,
                allowDraftRoute: ALLOW_DRAFT,
                stationOffset: STATION_OFFSET,
                tripDist: TRIP_DIST,
                confirmMaxTurns: CONFIRM_TURNS,
            });
            logLine(`route=${ROUTE_FILE} station=${STATION_ID} allowDraft=${ALLOW_DRAFT} offset=${STATION_OFFSET} tripDist=${TRIP_DIST}`);
            const summary = await runtime.run(root);
            const fullInv = {};
            for (const it of bot.inventory.items()) fullInv[it.name] = (fullInv[it.name] ?? 0) + it.count;
            logLine(`end: ${summary.status} reason=${summary.failReason} dur=${(summary.durationMs / 1000).toFixed(1)}s`);
            logLine(`detail: ${JSON.stringify(summary.detail)}`);
            if (summary.taskTree) logLine(`task tree:\n${summary.taskTree}`);
            finish({
                ...summary,
                spawnPos: [spawnPos.x, spawnPos.y, spawnPos.z],
                finalPos: bot.entity.position ? [bot.entity.position.floored().x, bot.entity.position.floored().y, bot.entity.position.floored().z] : null,
                fullInventory: fullInv,
            }, summary.status === 'SUCCESS' ? 0 : 1);
        } catch (e) {
            logLine(`fatal: ${String(e && e.stack ? e.stack : e).slice(0, 600)}`);
            finish({ status: 'FAILED', failReason: 'INTERNAL', error: String(e).slice(0, 300) }, 1);
        }
    });
}

main().catch((e) => { logLine(`boot fail: ${String(e && e.stack ? e.stack : e).slice(0, 600)}`); process.exit(1); });
