// death_audit.mjs — **死亡口径审计**：把"这一局到底死没死、死在哪"钉死
//
// 为什么要单独写这个工具（r15 的起点，r14 报告在这里翻车了）：
//   ① r14 用**单一子串** `tried to swim` 判岩浆死亡，读出 0，写成"岩浆死亡 0 硬线达成"。
//      手工 §5：**扫描工具读出"全零"时，先证伪工具**。这次不是读错数，是**搜索词本身就窄**。
//   ② 1.16.1 里"看着像岩浆"其实是**岩浆块**的字面量只有一个坑：
//        `discovered the floor was lava`  → `death.attack.hotFloor`
//        = `DamageSource.HOT_FLOOR`（DamageSource.java:21），**唯一产地是 `MagmaBlock.java:28`**
//        ⇒ **站在岩浆块上**，不是岩浆。而岩浆块每 tick 扣 1 血 ⇒ 站着不动约 1 秒就死。
//        `tried to swim in lava`        → `death.attack.lava`
//        = `DamageSource.LAVA`（Entity.java:390，isInLava() 时触发）—— **这才是岩浆死亡**。
//      出处：1.16.1 `assets/minecraft/lang/en_us.json:2165-2167` + 上面两个类。
//   ③ `result.json` 的 `metrics.deaths` **漏计**：全语料 47 个 trial 实测 4 次死亡，
//      计数器只记 1 次（`task_runner.js:102` 靠任务循环轮询 `ctx.takeDeath()`，
//      死亡若发生在长 await 里就要等下一拍才被消费）。
//      ⇒ **单一口径不能当安全闸门**，必须三通道交叉：
//         `server.log` 死亡行（权威） × `bot.log` 的 `death event: respawning` × `metrics.deaths`
//
// 口径（手册 §4.10 阳性对照）：本工具的分类表有**真实阳性样本**做对照，见 `death_audit_selftest.mjs`：
//   `P8R8_SMOKE3/server.log`  → `MicroBotB tried to swim in lava`  ⇒ 真岩浆死亡
//   `P8R14_PANEL2/.../server.log` → `TaskBotB discovered the floor was lava` ⇒ 岩浆块死亡
//   `P8R13_PANEL/.../server.log` → 一条都没有              ⇒ 阴性对照
//
// 用法：
//   node death_audit.mjs                      # 审计整个 runs/ 语料
//   node death_audit.mjs --run P8R14_PANEL2   # 只审一个 run（自动找 trial_XX）
//   node death_audit.mjs --selftest           # 跑分类表的阳性/阴性对照
// 退出码：0 = 没有岩浆死亡；3 = 有岩浆死亡（硬线破了）；2 = 工具自身出错。
//         ⚠ 退出码**只把岩浆死亡算硬线**；岩浆块/坠落/溺水等照报不误，但不自动判死
//         （它们是"必须披露"，不是本单的硬线）——由报告按口径处理。

import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

// ⚠ 必须用 fileURLToPath，**不能**用 `new URL(...).pathname`：
//   工作区路径里有中文（`D:\AI斗蛐蛐`），`pathname` 会返回**百分号编码**的
//   `%E6%96%97...` ⇒ 拼出来的路径不存在 ⇒ 审计"零死亡" ⇒ 假通过。
//   （这跟 r14 同一族的坑：搜索/扫描通道坏了，读数全零还看起来很正常。）
const RUNS_DIR = fileURLToPath(new URL('./runs/', import.meta.url));

/**
 * 1.16.1 死亡文案 → 分类。
 * ⚠ **不要**用"长得像什么"归类：`discovered the floor was lava` 里没有 lava 伤害源，
 *   它是 hotFloor（岩浆块）。分类表的每一行都注明 msgId 与出处。
 */
const DEATH_CLASSES = [
    // —— 岩浆（硬线）——
    { re: /tried to swim in lava(?! to escape)/, cls: 'LAVA', msgId: 'death.attack.lava', src: 'DamageSource.LAVA (Entity.java:390, isInLava)' },
    { re: /tried to swim in lava to escape/, cls: 'LAVA_PLAYER', msgId: 'death.attack.lava.player', src: 'DamageSource.java:188-193' },
    // —— 岩浆块（**不是**岩浆！站着约 1s 就死）——
    { re: /discovered the floor was lava/, cls: 'HOT_FLOOR', msgId: 'death.attack.hotFloor', src: 'MagmaBlock.java:28 (唯一产地)' },
    // —— 火 ——
    { re: /burned to death/, cls: 'ON_FIRE', msgId: 'death.attack.onFire', src: 'Entity.java:353' },
    { re: /went up in flames/, cls: 'IN_FIRE', msgId: 'death.attack.inFire', src: 'BaseFireBlock.java:57' },
    // —— 水/坠落/窒息/饥饿/爆炸/挤压 ——
    { re: /drowned/, cls: 'DROWN', msgId: 'death.attack.drown', src: 'LivingEntity.java:328；仅水（FluidTags.a），**永不用于岩浆**' },
    { re: /fell from a high place/, cls: 'FALL', msgId: 'death.attack.fall', src: 'Entity.java:1345' },
    { re: /hit the ground too hard/, cls: 'FALL', msgId: 'death.attack.fall', src: 'Entity.java:1345' },
    { re: /suffocated in a wall/, cls: 'IN_WALL', msgId: 'death.attack.inWall', src: 'LivingEntity.java:296' },
    { re: /starved to death/, cls: 'STARVE', msgId: 'death.attack.starve', src: 'FoodData.java:66' },
    { re: /blew up/, cls: 'EXPLOSION', msgId: 'death.attack.explosion', src: 'DamageSource.java:106（苦力怕/TNT）' },
    { re: /went off with a bang/, cls: 'FIREWORKS', msgId: 'death.attack.fireworks', src: 'DamageSource.java:73-75（烟花，**不是**苦力怕）' },
    { re: /was squashed by/, cls: 'CRAMMING', msgId: 'death.attack.cramming', src: 'DamageSource.java:23' },
    { re: /experienced kinetic energy/, cls: 'FLY_INTO_WALL', msgId: 'death.attack.flyIntoWall', src: 'DamageSource.java:28' },
    { re: /tried to crawl out of the void/, cls: 'VOID', msgId: 'death.attack.outOfWorld', src: '1.16.1 仍有' },
];

/**
 * 从一行 server.log 里解析死亡。
 *
 * ⚠ 踩过的坑（第一版）：想用"剥前缀 → 取玩家名 + 消息"的两段式正则，结果**一条都匹配不上**
 *   —— 1.16.1 的前缀是 `[16:27:17] [Server thread/INFO]: `，**方括号里自己带冒号**，
 *   `[^:\s]+` 取名字时直接卡在那个 `:` 上。更糟的是"岩浆死亡=0"那条断言**因此假通过**
 *   （什么都解析不到 ⇒ 当然是 0）。⇒ 改成**整行匹配消息 + 从匹配位置往前取名字**，
 *   前缀格式再怎么变都不影响分类。
 */
export function parseDeathLine(line) {
    for (const c of DEATH_CLASSES) {
        const m = c.re.exec(line);
        if (!m) continue;
        const toks = line.slice(0, m.index).trim().split(/\s+/).filter(Boolean);
        const who = toks.length ? toks[toks.length - 1].replace(/\]:$/, '') : '(未知)';
        return { who, msg: m[0], cls: c.cls, msgId: c.msgId, src: c.src, line: line.trim() };
    }
    return null;
}

/** 读一个 trial 目录的四通道死亡证据 */
export function auditTrial(dir, username = null) {
    const out = { dir, username, deaths: [], metricsDeaths: null, botLogDeaths: 0, taskOnDeath: 0, notes: [] };
    // ① server.log（权威）
    const slog = join(dir, 'server.log');
    if (existsSync(slog)) {
        for (const line of readFileSync(slog, 'utf8').split(/\r?\n/)) {
            const d = parseDeathLine(line);
            if (!d) continue;
            // 归属：只算 bot 自己的（username 缺失时按"带玩家名的都算"并标注）
            if (username && d.who !== username) { out.notes.push(`他人死亡（已排除）: ${d.who} ${d.msg}`); continue; }
            out.deaths.push(d);
        }
    }
    // ② result.json 的 metrics.deaths（**已知会漏计**，只作对照）
    const rj = join(dir, 'result.json');
    if (existsSync(rj)) {
        try { out.metricsDeaths = JSON.parse(readFileSync(rj, 'utf8'))?.metrics?.deaths ?? null; }
        catch (e) { out.notes.push(`result.json 解析失败: ${String(e).slice(0, 60)}`); }
    }
    // ③ bot.log 的 respawn 行（bot 自己看见了）
    const blog = join(dir, 'bot.log');
    if (existsSync(blog)) {
        out.botLogDeaths = (readFileSync(blog, 'utf8').match(/death event: respawning/g) ?? []).length;
    }
    // ④ telemetry 的 task_on_death
    const tel = join(dir, 'telemetry.jsonl');
    if (existsSync(tel)) {
        out.taskOnDeath = readFileSync(tel, 'utf8').split(/\r?\n/)
            .filter((l) => l.includes('"task_on_death"')).length;
    }
    return out;
}

/** 一个 trial 的死亡结论 */
export function verdict(a) {
    const lava = a.deaths.filter((d) => d.cls === 'LAVA' || d.cls === 'LAVA_PLAYER');
    const other = a.deaths.filter((d) => d.cls !== 'LAVA' && d.cls !== 'LAVA_PLAYER');
    return { lava, other, lavaCount: lava.length, otherCount: other.length };
}

const fmt = (a) => {
    const v = verdict(a);
    const dis = [];
    if (a.metricsDeaths != null && a.metricsDeaths !== a.deaths.length) {
        dis.push(`metrics.deaths=${a.metricsDeaths} ≠ server.log=${a.deaths.length}`);
    }
    if (a.botLogDeaths !== a.deaths.length) dis.push(`bot.log respawn=${a.botLogDeaths} ≠ server.log=${a.deaths.length}`);
    if (a.taskOnDeath !== a.deaths.length) dis.push(`task_on_death=${a.taskOnDeath} ≠ server.log=${a.deaths.length}`);
    return {
        run: a.dir.replace(/\\/g, '/').split('/').slice(-2).join('/'),
        who: a.username ?? '(未记录)',
        server: a.deaths.length, lava: v.lavaCount, other: v.otherCount,
        metrics: a.metricsDeaths, respawn: a.botLogDeaths, onDeath: a.taskOnDeath,
        classes: a.deaths.map((d) => d.cls).join(',') || '-',
        disagree: dis.join('; ') || '-',
    };
};

function selftest() {
    let pass = 0, fail = 0;
    const ok = (c, n, x = '') => { if (c) { pass++; console.log(`  ✅ ${n}`); } else { fail++; console.log(`  ❌ ${n}${x ? '  → ' + x : ''}`); } };

    console.log('=== death_audit.selftest：分类表 + 阳性/阴性对照 ===\n');

    // —— 阳性对照 ①：真岩浆死亡 ——（**真实语料**，不是编的字符串）
    {
        const d = auditTrial(join(RUNS_DIR, 'P8R8_SMOKE3'), 'MicroBotB');
        const v = verdict(d);
        ok(d.deaths.length === 1, '阳性①a：P8R8_SMOKE3 确实解析出 1 条死亡（不是"解析器什么都没读到"的假通过）', `n=${d.deaths.length}`);
        ok(v.lavaCount === 1, '阳性①b：它被判 LAVA', `lava=${v.lavaCount}`);
        ok(d.deaths[0]?.who === 'MicroBotB', '阳性①c：归属玩家名解析正确', d.deaths[0]?.who);
    }
    // —— 阳性对照 ②：岩浆块死亡（**不是**岩浆）——
    {
        const d = auditTrial(join(RUNS_DIR, 'P8R14_PANEL2', 'trial_01'), 'TaskBotB');
        const v = verdict(d);
        ok(v.lavaCount === 0, '阳性②a：P8R14_PANEL2 的 `discovered the floor was lava` **不算**岩浆', `lava=${v.lavaCount}`);
        ok(v.otherCount === 1 && v.other[0].cls === 'HOT_FLOOR', '阳性②b：它被判 HOT_FLOOR（岩浆块）', JSON.stringify(v.other.map((x) => x.cls)));
    }
    // —— 阴性对照 ——
    {
        const d = auditTrial(join(RUNS_DIR, 'P8R13_PANEL', 'trial_01'), 'TaskBotB');
        ok(d.deaths.length === 0, '阴性：P8R13_PANEL 没有死亡行', `n=${d.deaths.length}`);
    }
    // —— ★ 反向验收：把岩浆块字面量**误当成岩浆**的实现必须被抓到 ——
    {
        const d = auditTrial(join(RUNS_DIR, 'P8R14_PANEL2', 'trial_01'), 'TaskBotB');
        const v = verdict(d);
        ok(!(v.other[0]?.msgId === 'death.attack.lava'), '★反向：`discovered the floor was lava` 的 msgId 不得是 death.attack.lava', v.other[0]?.msgId);
    }
    // —— 归属：他人の死亡不算 bot 的 ——
    {
        const d = auditTrial(join(RUNS_DIR, 'P8R8_SMOKE3'), 'TaskBotB');   // 那局是 MicroBotB 死的
        ok(d.deaths.length === 0, '归属：username 不匹配 ⇒ 不计为 bot 的死亡', `n=${d.deaths.length}`);
    }
    // —— 样板行不得被误判成死亡（登录/成就/给予）——
    {
        const junk = parseDeathLine('[12:00:00] [Server thread/INFO]: TaskBotB joined the game');
        ok(junk === null, '样板：`joined the game` 不算死亡', JSON.stringify(junk));
        const give = parseDeathLine('[12:00:00] [Server thread/INFO]: TaskBotB made the advancement [Stone Age]');
        ok(give === null, '样板：成就行不算死亡', JSON.stringify(give));
    }
    // —— 四通道一致性必须被报出来（这正是 r14 漏掉的那条）——
    {
        const d = auditTrial(join(RUNS_DIR, 'P8R14_PANEL2', 'trial_01'), 'TaskBotB');
        const row = fmt(d);
        ok(/metrics\.deaths=1/.test(row.disagree) === false || row.metrics === 1,
            '四通道：P8R14_PANEL2 的 metrics.deaths=1 与 server.log=1 一致（对照组）', row.disagree);
        const p = auditTrial(join(RUNS_DIR, 'P8R14_PANEL', 'trial_01'), 'TaskBotB');
        const prow = fmt(p);
        ok(/metrics\.deaths=0/.test(prow.disagree) && /server\.log=1/.test(prow.disagree),
            '★四通道：P8R14_PANEL 报出 metrics.deaths=0 ≠ server.log=1（r14 漏的就是这条）', prow.disagree);
    }

    console.log(`\n=== ${pass} 通过 / ${fail} 失败 ===`);
    return fail === 0;
}

/** 遍历 runs/ 下所有 trial_XX（有 result.json 或 server.log 的都算） */
function* iterTrials(root) {
    if (!existsSync(root)) return;
    for (const run of readdirSync(root)) {
        const rd = join(root, run);
        if (!statSync(rd).isDirectory()) continue;
        const subs = readdirSync(rd).filter((s) => /^trial_\d+$/.test(s) && statSync(join(rd, s)).isDirectory());
        if (subs.length) { for (const s of subs) yield join(rd, s); }
        else if (existsSync(join(rd, 'server.log'))) yield rd;   // 早期 run 没有 trial_XX
    }
}

function main() {
    const argv = process.argv.slice(2);
    if (argv.includes('--selftest')) { process.exit(selftest() ? 0 : 2); }

    const only = argv.includes('--run') ? argv[argv.indexOf('--run') + 1] : null;
    const root = only ? join(RUNS_DIR, only) : RUNS_DIR;
    const rows = [];
    for (const dir of iterTrials(root)) {
        let username = null;
        const rj = join(dir, 'result.json');
        if (existsSync(rj)) { try { username = JSON.parse(readFileSync(rj, 'utf8'))?.username ?? null; } catch { /* 缺就缺 */ } }
        rows.push(fmt(auditTrial(dir, username)));
    }
    rows.sort((a, b) => (b.server - a.server) || a.run.localeCompare(b.run));

    console.log(`\n=== 死亡口径审计（1.16.1 分类表，来源见文件头）===`);
    console.log(`扫描 ${rows.length} 个 trial 目录\n`);
    console.log(['trial', 'who', 'server', 'LAVA', 'other', 'metrics', 'respawn', 'onDeath', 'classes', '口径不一致'].join('\t'));
    for (const r of rows.filter((r) => r.server || r.disagree !== '-')) {
        console.log([r.run, r.who, r.server, r.lava, r.other, r.metrics, r.respawn, r.onDeath, r.classes, r.disagree].join('\t'));
    }
    const totalLava = rows.reduce((n, r) => n + r.lava, 0);
    const totalOther = rows.reduce((n, r) => n + r.other, 0);
    const disagree = rows.filter((r) => r.disagree !== '-').length;
    console.log(`\n合计：岩浆死亡 ${totalLava}｜非岩浆死亡 ${totalOther}｜四通道口径不一致的 trial ${disagree} 个`);
    console.log(totalLava === 0
        ? '✅ 硬线「岩浆死亡 0」在**本工具分类下**成立（注意：岩浆块/坠落/溺水另计，必须披露）'
        : `🚨 硬线破了：${totalLava} 次岩浆死亡`);
    process.exit(totalLava === 0 ? 0 : 3);
}

main();
