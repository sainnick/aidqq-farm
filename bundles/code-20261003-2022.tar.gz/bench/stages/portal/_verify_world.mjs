// 临时：校验 fresh scout world 的门框几何（用完删）
import { openWorld } from '../../route/tools/region_reader.mjs';
const W = process.argv[2] || 'D:/AI斗蛐蛐/bench/route/probe/_s1_main_fresh/4926685115947721762';
const w = openWorld(W, { dims: ['overworld'] });
const byName = new Map();
for (let y = 36; y <= 46; y++) for (let z = 303; z <= 313; z++) for (let x = 183; x <= 192; x++) {
  const n = w.blockAt(x, y, z);
  if (!n || n === 'air' || n === 'cave_air' || n === 'void_air') continue;
  if (!byName.has(n)) byName.set(n, []);
  byName.get(n).push(`${x},${y},${z}`);
}
console.log('=== ' + W + ' ===');
for (const [n, list] of [...byName.entries()].sort((a, b) => b[1].length - a[1].length)) {
  console.log(`  ${n} (${list.length}): ${list.length <= 30 ? list.join(' ') : list.slice(0, 30).join(' ') + ' …'}`);
}
console.log('\n=== 门框候选环 x185..190 y38..44 z305..312 ===');
for (let y = 44; y >= 38; y--) {
  const row = [];
  for (let z = 305; z <= 312; z++) {
    const r = [];
    for (let x = 185; x <= 190; x++) {
      const n = w.blockAt(x, y, z);
      r.push(n === 'obsidian' ? 'O' : n === 'crying_obsidian' ? 'C' : n === 'lava' || n === 'flowing_lava' ? 'L' : n === 'magma_block' ? 'M' : (!n || n === 'air' || n === 'cave_air' || n === 'void_air') ? '.' : '#');
    }
    row.push(`z${z}:` + r.join(''));
  }
  console.log(`y=${y} x185..190 ` + row.join(' '));
}
console.log('\n=== 死亡点一带 x172..176 y28..32 z291..295 ===');
for (let y = 32; y >= 28; y--) {
  const row = [];
  for (let z = 291; z <= 295; z++) {
    const r = [];
    for (let x = 172; x <= 176; x++) r.push(`${x},${y},${z}=${w.blockAt(x, y, z)}`);
    row.push(r.join(' '));
  }
  console.log(`y=${y} | ` + row.join('  ||  '));
}
