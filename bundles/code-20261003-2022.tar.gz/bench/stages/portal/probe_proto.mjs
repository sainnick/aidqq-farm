// probe_proto.mjs — 只读探针：1.16.1 block_place 包到底有哪些字段（决定 insideBlock 策略能不能用）
import { createRequire } from 'module';
const require = createRequire('D:/AI斗蛐蛐/mindcraft-wt/s1-portal/');
const md = require('minecraft-data')('1.16.1');

const f = md.protocol.play.toClient.types.packet_block_place ?? md.protocol.play.toClient.types.packet_block_place;
console.log('=== toClient packet_block_place ===');
console.log(JSON.stringify(f, null, 1));
console.log('\n=== toServer packet_block_place ===');
const g = md.protocol.play.toServer.types.packet_block_place;
console.log(JSON.stringify(g, null, 1));

console.log('\n=== features ===');
for (const k of ['blockPlaceHasInsideBlock', 'blockPlaceHasHeldItem', 'blockPlaceHasHandAndIntCursor', 'usesLoginPacket']) {
    console.log(k, '=', md.version?.features?.[k]);
}
const protoVer = md.version?.version;
console.log('\nfeatures by version 1.16.1:');
const feat = require('minecraft-data/minecraft-data/data/pc/common/features.json');
console.log(JSON.stringify(feat['1.16.1'] ?? feat['1.16'] ?? 'not found', null, 1).slice(0, 1200));
