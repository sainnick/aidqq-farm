// probe_see_station.mjs — 「bot 在站心上方到底能不能看见门」的定向取证
//
// R11 面板连跑两局，下探阶段 `descend_step` 的 count 恒 0：
//   bot 在 (175~176, 55→8, 304) 一路挖，门在 (187, 39-43, 307-310)。
//   3D 直线距离 ≈17 格 < scanStation 的 maxDistance(32)，水平 ≈12 格 < radius(24)，
//   **按理应该扫得到**，可 count 就是 0。
//
// 两种可能，药完全不同：
//   (a) findBlocks 根本没扫到 —— 那一带的**区块/段没加载**（客户端只有已收到的 section）
//   (b) 扫到了但被**水平半径**过滤掉了（bot 偏得比 radius 还远）
// scanStation 现在会返回 {raw, outOfRadius, findErr}，本探针把它们打出来。
//
// 用法：node probe_see_station.mjs --stamp P8R11_SEE

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAMP = argOf(process.argv, 'stamp', 'P8R11_SEE');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'SeeBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null; let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };

// 与 run_portal 用的同一个 station（读真 route，避免手抄走样）
// ★ route 里的 `center` 是**数组** `[x, z]`，route_loader 会归一成 `{x, z}`；
//   探针直接读原始 JSON ⇒ 必须自己转，否则 `center.x === undefined` ⇒
//   水平半径过滤整个失效（`NaN > radius` 恒 false）。
const ROUTE = path.join(ROOT, 'bench', 'route', '4926685115947721762.json');
const STATION = (() => {
    const j = JSON.parse(fs.readFileSync(ROUTE, 'utf8'));
    const s = j.stations.find((x) => x.id === 'S1_portal').station;
    const c = Array.isArray(s.center) ? { x: s.center[0], z: s.center[1] } : s.center;
    return { id: 'S1_portal', center: c, radius: s.radius, yHint: s.yHint, lookFor: s.lookFor };
})();

// 三个观测点：站心上方（面板里的真实起点）、门正上方、门旁
const VIEWPOINTS = [
    { key: 'above_center_y55', pos: [176, 55, 304], why: '面板 descend 起点附近' },
    { key: 'above_portal_y55', pos: [187, 55, 308], why: '门正上方 12 格' },
    { key: 'beside_portal', pos: [186, 41, 306], why: '门外一格（r5 的安全落脚点）' },
];

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000 });
    if (!st.usable) { console.error(`[see] 等不到泳道 B`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[see] server up in ${(server.bootMs / 1000).toFixed(0)}s`);

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    await sleep(3000);
    await cmd(`op ${LANE_B.username}`);

    const { scanStation } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/station_nav.js')).href);
    const out = { seed: SEED, station: STATION, at: new Date().toISOString(), views: [] };

    // 先 forceload + 等客户端收到（不然测的是"没加载"而不是"判据对不对"）
    await cmd(`forceload add 160 290 200 320`);
    await sleep(2000);

    for (const V of VIEWPOINTS) {
        await cmd(`tp ${LANE_B.username} ${V.pos[0]} ${V.pos[1]} ${V.pos[2]}`);
        await sleep(2500);
        // 等客户端 chunk 到位：反复扫到"门那一格有方块"或超时
        let seen = null;
        for (let k = 0; k < 20; k++) {
            const b = bot.blockAt(new Vec3(187, 42, 310));   // 真 crying_obsidian 那一格
            if (b) { seen = b.name; break; }
            await sleep(500);
        }
        const s = scanStation(bot, STATION);
        const p = bot.entity.position;
        const rec = {
            key: V.key, why: V.why, pos: V.pos,
            actualPos: [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)],
            horizToCenter: +Math.hypot(p.x - STATION.center.x, p.z - STATION.center.z).toFixed(1),
            cryingObsidianAt187_42_310: seen,       // 客户端到底看不看得到门那一格
            raw: s.raw, outOfRadius: s.outOfRadius, findErr: s.findErr,
            count: s.count, strong: s.strong, strongNames: s.strongNames,
            firstHits: (s.blocks || []).slice(0, 5).map((b) => `${b.name}@${b.at.join(',')}`),
        };
        out.views.push(rec);
        log(`[see] ${V.key}: raw=${s.raw} outOfRadius=${s.outOfRadius} count=${s.count} strong=${s.strong} 门格=${seen ?? 'null'} findErr=${s.findErr ?? 'none'}`);
    }

    fs.writeFileSync(path.join(RUNS_DIR, 'see_station.json'), JSON.stringify(out, null, 2));
    log(`[see] 已写出 see_station.json`);
    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

function pathToFileURL(p) { return new URL(`file:///${p.replace(/\\/g, '/')}`); }

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
