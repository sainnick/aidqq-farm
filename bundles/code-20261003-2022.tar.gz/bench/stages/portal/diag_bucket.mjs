﻿// diag_bucket.mjs — 判定诊断：1.16.1 上「桶」到底走哪条交互通道能生效
//
// 背景（P8_MICRO1..5 全部 0/30，已排除的场景类原因）：
//   - 场景已按 scene.mjs 摆好，服务端真值 5/5 通过（execute if block … lava → say 标记出现在 log）
//   - 客户端看得到岩浆源（blockAt: lava / level 0 / isSource true）
//   - 客户端手上有 bucket（held:"bucket"），面可见（vis:"ok"），距离 ~1 格
//   - activateBlock 与手写 block_place{insideBlock:true} 两条都试过，**服务端日志一行异常都没有**
//     （没有 "Ignoring use-item-on packet … which is not loaded"，没有 Exception，没有断线）
//   ⇒ 「服务端根本没处理这次交互」和「服务端处理了但判 PASS」必须区分开。
//
// 本诊断的判据全部取**服务端真值**，不靠客户端自说自话：
//   ① data get entity TaskBotB SelectedItem  → 服务端认为主手拿的是什么
//   ② execute if block X Y Z minecraft:lava  → 服务端认为岩浆还在不在（= 有没有真被舀走）
//   ③ server.log 增量里有没有 "Ignoring use-item-on" / Exception（= 包到了但被前置检查拒了）
//
// 六个 cell：
//   S1 activateBlock(lava, up)                     mineflayer 4.38 原路径（lookAt force=false）
//   S2 raw block_place{insideBlock:true}            1.16.1 schema 全 7 字段 + 先转再发
//   S3 lookAt(force) + activateItem()               use_item 包（上游 legacy 层的桶走法）
//   S4 bot._genericPlace(lava, up)                  ★ place.js 已验收 120/120 用的就是它
//   S5 对照组：cobblestone 放方块                    证明这个场景里 use_item_on 通道本身通不通
//   S6 站到岩浆正上方低头 activateItem               最像真人的那一种
//
// 一次跑完出一张表，验收物：runs/P8_DIAG_BUCKET/diag_bucket.json

import { fileURLToPath } from 'url';
import path from 'path';
import { pathToFileURL } from 'url';
import fs from 'fs';
import { createRequire } from 'module';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';
import { tailFile } from './srv_rpc.mjs';
import { SCENE } from './scene.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
// ★ 默认值修正：ROOT 已经是 D:\AI斗蛐蛐（portal → stages → bench → 根），
//   再拼 '..' 会退到 D:\ → require 找不到 vec3。micro_bench/run_portal 里同款默认值
//   也依赖外部设 MC_MINDCRAFT_ROOT 才能跑对，这里不依赖环境变量。
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
// vec3 只在 worktree 的 node_modules 里有，bench 目录自己没有 → 走 worktree 的 require
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = argOf(process.argv, 'mc-version', '1.16.1');
const STAMP = argOf(process.argv, 'stamp', 'P8_DIAG_BUCKET');
const SET = argOf(process.argv, 'set', '1');
const SEED = argOf(process.argv, 'seed', `${STAMP}-S`);
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const LOG_PATH = path.join(RUNS_DIR, 'server.log');
const OUT = path.join(RUNS_DIR, 'diag_bucket.json');

const LANE_B = {
    idx: 1, name: 'B',
    dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'TaskBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

// —— 场景（用 scene.mjs 的坐标，但只取本诊断需要的几格）——
const LAVA = SCENE.lavaCells[0];                       // (205,70,200) 舀取目标
const WATER = SCENE.waterCell;                         // (195,70,200)
const CAST = SCENE.castCell;                           // (201,70,200) 浇筑目标
const PLAT = SCENE.platform;                           // 196..204 / 69 / 198..202
const STAND = SCENE.standLava;                         // (204.5,70,200)
const CELL_ABOVE_LAVA = { x: LAVA.x, y: LAVA.y + 1, z: LAVA.z };
const AIR_CELL = { x: 202, y: 70, z: 201 };            // 对照组放圆石用

let server = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };
const logMark = () => LOG_PATH.length;   // 仅用于切片起点

/** execute … run say <mark> → 标记出现在 server.log 才算服务端答了 */
async function truth(cmdline, tag, timeoutMs = 6000) {
    const m = `@@${tag}_${Date.now().toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`;
    cmd(`${cmdline} run say ${m}`);
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
        if (tailFile(LOG_PATH, 262144).includes(m)) return { hit: true, mark: m };
        await sleep(120);
    }
    return { hit: false, mark: m };
}
const isLavaAt = (p) => truth(`execute if block ${p.x} ${p.y} ${p.z} minecraft:lava`, 'L');

/** 服务端认为主手拿的是什么（data get 的输出行在 log 里） */
async function serverHeld(tag) {
    const before = tailFile(LOG_PATH, 65536).length;
    cmd(`data get entity ${LANE_B.username} SelectedItem`);
    const t0 = Date.now();
    while (Date.now() - t0 < 6000) {
        const slice = tailFile(LOG_PATH, 262144).slice(before - 0);
        const line = slice.split(/\r?\n/).reverse().find((l) => l.includes('entity data'));
        if (line) return line.trim().slice(0, 300);
        await sleep(150);
    }
    return '(no data get output)';
}

async function tpTo(x, y, z) {
    cmd(`tp ${LANE_B.username} ${x} ${y} ${z}`);
    for (let i = 0; i < 40; i++) {
        await sleep(200);
        const p = bot?.entity?.position;
        if (p && Math.abs(p.x - x) < 0.8 && Math.abs(p.z - z) < 0.8 && Math.abs(p.y - y) < 2) return true;
    }
    return false;
}

/** 复位：给桶（默认空桶，可指定 water_bucket/lava_bucket）、清背包、岩浆复位、目标格清空 */
async function reset(give = 'minecraft:bucket') {
    cmd(`clear ${LANE_B.username}`);
    cmd(`give ${LANE_B.username} ${give} 1`);
    cmd(`give ${LANE_B.username} minecraft:cobblestone 8`);
    await sleep(600);
    cmd(`fill ${LAVA.x} ${LAVA.y} ${LAVA.z} ${LAVA.x} ${LAVA.y} ${LAVA.z} minecraft:air`);
    cmd(`fill ${LAVA.x} ${LAVA.y} ${LAVA.z} ${LAVA.x} ${LAVA.y} ${LAVA.z} minecraft:lava`);
    cmd(`fill ${CAST.x} ${CAST.y} ${CAST.z} ${CAST.x} ${CAST.y} ${CAST.z} minecraft:air`);
    cmd(`fill ${WATER.x} ${WATER.y} ${WATER.z} ${WATER.x} ${WATER.y} ${WATER.z} minecraft:water`);
    cmd(`fill ${AIR_CELL.x} ${AIR_CELL.y} ${AIR_CELL.z} ${AIR_CELL.x} ${AIR_CELL.y} ${AIR_CELL.z} minecraft:air`);
    await sleep(900);
    try {
        const want = give.split(':')[1];
        const it = bot.inventory.items().find((i) => i.name === want);
        if (it) await bot.equip(it, 'hand');
        await sleep(400);
    } catch (e) { /* 忽略 */ }
}

const clientView = (p) => {
    const b = bot.blockAt(new Vec3(p.x, p.y, p.z));
    return b ? b.name : null;
};

let bot = null;
const cells = [];

async function runCell(name, desc, attempt, opts = {}) {
    await reset(opts.give ?? 'minecraft:bucket');
    if (opts.tp) await tpTo(opts.tp.x, opts.tp.y, opts.tp.z);
    await sleep(500);
    const before = {
        clientBlock: clientView(opts.target ?? LAVA),
        clientHeld: bot.heldItem?.name ?? null,
        serverHeld: await serverHeld('H'),
    };
    const markStart = tailFile(LOG_PATH, 262144).length;
    const t0 = Date.now();
    let thrown = null;
    try { await attempt(); } catch (e) { thrown = String(e && e.message ? e.message : e).slice(0, 160); }
    // 轮询客户端是否看到变化（最多 2.5s）
    let clientChanged = false;
    for (let i = 0; i < 25; i++) {
        await sleep(100);
        if (opts.judgeClient?.()) { clientChanged = true; break; }
    }
    const ms = Date.now() - t0;
    const stillLava = await isLavaAt(opts.target ?? LAVA);
    const logSlice = tailFile(LOG_PATH, 262144).slice(markStart);
    const suspicious = logSlice.split(/\r?\n/).filter((l) =>
        /Ignoring use-item-on|not loaded|Exception|Decoder|packet/i.test(l)).map((l) => l.slice(0, 160));
    const row = {
        cell: name, desc,
        clientHeldBefore: before.clientHeld, serverHeldBefore: before.serverHeld,
        clientBlockBefore: before.clientBlock,
        clientHeldAfter: bot.heldItem?.name ?? null,
        clientBlockAfter: clientView(opts.target ?? LAVA),
        clientChanged, ms, thrown,
        serverStillLava: stillLava.hit,      // true = 服务端那边岩浆还在（= 没舀走）
        serverLogFlags: suspicious,
    };
    cells.push(row);
    console.log(`[${name}] ${JSON.stringify(row)}`);
    return row;
}

async function main() {
    // 1) 泳道 B 闸门
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}），排队`) });
    if (!st.usable) { console.error(`[diag] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    const st2 = laneStatus(LANE_B);
    if (!st2.usable) { console.error(`[diag] freshWorld 前泳道 B 被占（${st2.why}）`); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[diag] server up in ${(server.bootMs / 1000).toFixed(0)}s`);
    cmd(`op ${LANE_B.username}`);

    // 2) bot 进服
    const mineflayer = require('mineflayer');
    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res);
        bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 60s')), 60000);
    });
    log('[diag] bot spawned');
    await sleep(2000);
    cmd(`op ${LANE_B.username}`);

    // 3) 摆场景（先 tp 让区块热起来，P8_MICRO1 的教训）
    await tpTo(SCENE.stand.x, SCENE.stand.y, SCENE.stand.z);
    await sleep(6000);
    cmd(`fill 190 60 195 210 72 205 minecraft:air`);
    cmd(`fill ${PLAT.x0} ${PLAT.y0} ${PLAT.z0} ${PLAT.x1} ${PLAT.y1} ${PLAT.z1} minecraft:stone`);
    cmd(`fill ${SCENE.lavaPit.x0} ${SCENE.lavaPit.y0} ${SCENE.lavaPit.z0} ${SCENE.lavaPit.x1} ${SCENE.lavaPit.y1} ${SCENE.lavaPit.z1} minecraft:air`);
    for (const c of SCENE.lavaCells) cmd(`fill ${c.x} ${c.y} ${c.z} ${c.x} ${c.y} ${c.z} minecraft:lava`);
    cmd(`fill ${SCENE.waterPit.x0} ${SCENE.waterPit.y0} ${SCENE.waterPit.z0} ${SCENE.waterPit.x1} ${SCENE.waterPit.y1} ${SCENE.waterPit.z1} minecraft:air`);
    cmd(`fill ${WATER.x} ${WATER.y} ${WATER.z} ${WATER.x} ${WATER.y} ${WATER.z} minecraft:water`);
    await sleep(3000);

    // 4) 场景真值闸门
    const gate = [];
    gate.push({ what: '平台', ...(await truth(`execute if block ${PLAT.x0} ${PLAT.y0} ${PLAT.z0} minecraft:stone`, 'P')) });
    gate.push({ what: '岩浆源', ...(await isLavaAt(LAVA)) });
    gate.push({ what: '水源', ...(await truth(`execute if block ${WATER.x} ${WATER.y} ${WATER.z} minecraft:water`, 'W')) });
    const sceneOk = gate.every((g) => g.hit);
    log(`[diag] 场景真值 ${gate.filter((g) => g.hit).length}/${gate.length}`);
    if (!sceneOk) { console.error('[diag] 场景真值没过，不开测'); await stopServer(LANE_B, server); process.exit(1); }

    await tpTo(STAND.x, STAND.y, STAND.z);
    await sleep(1500);
    log(`[diag] 站位 ${JSON.stringify(bot.entity.position)}`);

    const lavaV = new Vec3(LAVA.x, LAVA.y, LAVA.z);
    const lavaBlock = () => bot.blockAt(lavaV);

    if (SET === '1') {
    // —— S1 activateBlock（mineflayer 原路径）——
    await runCell('S1_activateBlock', 'bot.activateBlock(lava, up)',
        async () => { await bot.activateBlock(lavaBlock(), new Vec3(0, 1, 0)); },
        { judgeClient: () => bot.heldItem?.name === 'lava_bucket' });

    // —— S2 raw block_place insideBlock:true（1.16.1 全 7 字段）——
    await runCell('S2_blockPlaceInside', '手写 block_place{insideBlock:true} + 先 lookAt(force)',
        async () => {
            const b = lavaBlock();
            await bot.lookAt(b.position.offset(0.5, 0.5, 0.5), true);
            await sleep(200);
            bot._client.write('block_place', {
                hand: 0, location: b.position, direction: 1,
                cursorX: 8, cursorY: 8, cursorZ: 8, insideBlock: true,
            });
        },
        { judgeClient: () => bot.heldItem?.name === 'lava_bucket' });

    // —— S3 lookAt + activateItem（use_item 包）——
    await runCell('S3_activateItem', 'lookAt(force) + bot.activateItem()',
        async () => {
            const b = lavaBlock();
            await bot.lookAt(b.position.offset(0.5, 0.5, 0.5), true);
            await sleep(250);
            await bot.activateItem();
        },
        { judgeClient: () => bot.heldItem?.name === 'lava_bucket' });

    // —— S4 bot._genericPlace（place.js 已验收 120/120 用的就是它）——
    await runCell('S4_genericPlace', 'bot._genericPlace(lava, up)（place.js 同款）',
        async () => { await bot._genericPlace(lavaBlock(), new Vec3(0, 1, 0), { swingArm: 'right' }); },
        { judgeClient: () => bot.heldItem?.name === 'lava_bucket' });

    // —— S5 对照组：放圆石（证明 use_item_on 通道本身通不通）——
    await runCell('S5_control_cobble', '对照组：placeBlock 放 cobblestone（place.js 同款）',
        async () => {
            const it = bot.inventory.items().find((i) => i.name === 'cobblestone');
            if (it) await bot.equip(it, 'hand');
            await sleep(400);
            const ref = bot.blockAt(new Vec3(AIR_CELL.x, AIR_CELL.y - 1, AIR_CELL.z));
            await bot.placeBlock(ref, new Vec3(0, 1, 0));
            await sleep(1200);
        },
        { target: AIR_CELL, judgeClient: () => clientView(AIR_CELL) === 'cobblestone' });

    // —— S6 站到岩浆正上方低头（最像真人）——
    await runCell('S6_lookDown', '站到岩浆正上方 + 低头 activateItem',
        async () => {
            const b = bot.blockAt(new Vec3(LAVA.x, LAVA.y + 1, LAVA.z));
            await bot.lookAt(b.position.offset(0.5, 0.9, 0.5), true);
            await sleep(250);
            await bot.activateItem();
        },
        { tp: { x: LAVA.x + 0.5, y: LAVA.y + 1, z: LAVA.z + 0.5 }, judgeClient: () => bot.heldItem?.name === 'lava_bucket' });
    } else if (SET === '3') {
        // ============ 第三轮：真原语 vs 裸 activateItem，同一站位同一目标，逐项对照 ============
        const liq = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/liquid.js')).href);
        const eye = () => bot.entity.position.offset(0, bot.entity.eyeHeight ?? 1.62, 0);
        const dirTo = (p) => {
            const e = eye(); const t = new Vec3(p.x + 0.5, p.y + 0.5, p.z + 0.5);
            const d = t.minus(e); const len = d.norm(); return d.scaled(1 / len);
        };
        /** 客户端自己算一遍射线：看第一步打到哪一格（faceVisible 内部同款） */
        const clientRayHit = (d, maxD = 6) => {
            const e = eye();
            for (let t = 0.05; t <= maxD; t += 0.04) {
                const q = e.plus(d.scaled(t));
                const c = q.floored();
                const b = bot.blockAt(c);
                if (b && b.name !== 'air' && b.name !== 'cave_air' && b.name !== 'void_air') {
                    return { at: [c.x, c.y, c.z], name: b.name, dist: +t.toFixed(2) };
                }
            }
            return null;
        };
        const snapshot = (tag) => ({
            tag,
            pos: [+bot.entity.position.x.toFixed(2), +bot.entity.position.y.toFixed(2), +bot.entity.position.z.toFixed(2)],
            eye: [+eye().x.toFixed(2), +eye().y.toFixed(2), +eye().z.toFixed(2)],
            yaw: +bot.entity.yaw.toFixed(3), pitch: +bot.entity.pitch.toFixed(3),
            held: bot.heldItem?.name ?? null,
            inv: bot.inventory.items().map((i) => `${i.name}x${i.count}@${i.slot}`).join(','),
        });

        const tgt = LAVA;   // 诊断里成功过的就是这一格 (205,70,200)
        const rows = [];
        for (let i = 0; i < 2; i++) {
            // —— A) 走真原语 scoopLiquidAt ——
            cmd(`clear ${LANE_B.username}`);
            cmd(`give ${LANE_B.username} minecraft:bucket 4`);
            await sleep(800);
            cmd(`fill ${tgt.x} ${tgt.y} ${tgt.z} ${tgt.x} ${tgt.y} ${tgt.z} minecraft:air`);
            cmd(`fill ${tgt.x} ${tgt.y} ${tgt.z} ${tgt.x} ${tgt.y} ${tgt.z} minecraft:lava`);
            await sleep(900);
            await tpTo(STAND.x, STAND.y, STAND.z);
            await sleep(600);
            const before = snapshot(`A${i + 1}_before`);
            const dir0 = dirTo(tgt);
            const ray0 = clientRayHit(dir0);
            const r = await liq.scoopLiquidAt(bot, tgt, { telemetry: null, label: `diagA${i + 1}` });
            const afterA = snapshot(`A${i + 1}_after`);
            const lavaGoneA = !(await isLavaAt(tgt)).hit;
            rows.push({ phase: 'A_primitive', i: i + 1, ok: r.ok, reason: r.reason ?? null, detail: r.detail ?? null, before, ray0, afterA, serverLavaGone: lavaGoneA });
            console.log(JSON.stringify(rows[rows.length - 1]));

            // —— B) 紧接着裸 activateItem（如果 A 失败，看裸包能不能成）——
            cmd(`fill ${tgt.x} ${tgt.y} ${tgt.z} ${tgt.x} ${tgt.y} ${tgt.z} minecraft:air`);
            cmd(`fill ${tgt.x} ${tgt.y} ${tgt.z} ${tgt.x} ${tgt.y} ${tgt.z} minecraft:lava`);
            await sleep(900);
            const b = bot.blockAt(new Vec3(tgt.x, tgt.y, tgt.z));
            await bot.lookAt(b.position.offset(0.5, 0.5, 0.5), true);
            await sleep(250);
            const dir1 = dirTo(tgt);
            const ray1 = clientRayHit(dir1);
            const b4 = snapshot(`B${i + 1}_beforeActivateItem`);
            await bot.activateItem();
            let okB = false;
            for (let k = 0; k < 25; k++) { await sleep(100); if (bot.heldItem?.name === 'lava_bucket') { okB = true; break; } }
            const lavaGoneB = !(await isLavaAt(tgt)).hit;
            rows.push({ phase: 'B_rawActivateItem', i: i + 1, ok: okB, ray1, before: b4, after: snapshot(`B${i + 1}_after`), serverLavaGone: lavaGoneB, serverHeld: await serverHeld('HB') });
            console.log(JSON.stringify(rows[rows.length - 1]));
        }
        fs.writeFileSync(path.join(RUNS_DIR, 'diag_primitive_vs_raw.json'), JSON.stringify({ stamp: STAMP, target: tgt, stand: STAND, rows }, null, 2));

        // 直接落进汇总表，让 md 也能看
        for (const r of rows) {
            cells.push({
                cell: `${r.phase}_${r.i}`, desc: r.phase,
                clientHeldBefore: r.before?.held ?? null, serverHeldBefore: '-',
                clientBlockBefore: 'lava', clientHeldAfter: r.after?.held ?? null,
                clientBlockAfter: r.ok ? '(变了)' : 'lava', clientChanged: r.ok,
                ms: 0, thrown: null,
                serverStillLava: r.serverLavaGone ? false : true,
                serverLogFlags: r.ray0 ? [`clientRay→${r.ray0.name}@${r.ray0.at} d=${r.ray0.dist}`] : [],
            });
        }
    } else if (SET === '4') {
        // ===== 第四轮：完全复刻 micro_bot 的每轮序列，逐项对比「带 tp / 不带 tp」 =====
        const liq = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/liquid.js')).href);
        const tgt = LAVA;
        const rows = [];
        const snap = (tag) => ({
            tag,
            pos: [+bot.entity.position.x.toFixed(2), +bot.entity.position.y.toFixed(2), +bot.entity.position.z.toFixed(2)],
            yaw: +bot.entity.yaw.toFixed(3), pitch: +bot.entity.pitch.toFixed(3),
            quickBar: bot.quickBarSlot,
            held: bot.heldItem?.name ?? null, heldSlot: bot.heldItem?.slot ?? null,
            inv: bot.inventory.items().map((i) => `${i.name}x${i.count}@${i.slot}`).join(','),
            clientTarget: clientView(tgt),
        });

        const round = async (n, doTp) => {
            // —— 复刻 micro_bot 的一轮 ——
            cmd(`give ${LANE_B.username} minecraft:bucket 4`);
            cmd(`clear ${LANE_B.username} minecraft:water_bucket`);
            cmd(`clear ${LANE_B.username} minecraft:lava_bucket`);
            await sleep(700);
            cmd(`fill ${tgt.x} ${tgt.y} ${tgt.z} ${tgt.x} ${tgt.y} ${tgt.z} minecraft:air`);
            cmd(`fill ${tgt.x} ${tgt.y} ${tgt.z} ${tgt.x} ${tgt.y} ${tgt.z} minecraft:lava`);
            await sleep(500);
            if (doTp) { await tpTo(STAND.x, STAND.y, STAND.z); await sleep(300); }
            const before = snap(`R${n}${doTp ? '_tp' : '_notp'}_before`);
            const serverHeld0 = await serverHeld(`H${n}`);
            const r = await liq.scoopLiquidAt(bot, tgt, { telemetry: null, label: `diagR${n}` });
            const after = snap(`R${n}${doTp ? '_tp' : '_notp'}_after`);
            const gone = !(await isLavaAt(tgt)).hit;
            const row = { n, doTp, ok: r.ok, reason: r.reason ?? null, detail: r.detail ?? null, before, after, serverLavaGone: gone, serverHeld0 };
            rows.push(row);
            console.log(JSON.stringify(row));
        };

        await round(1, true);
        await round(2, false);
        await round(3, true);
        // 收尾：裸 activateItem（不 equip、不 lookAt），看这时候还打不打得中
        cmd(`fill ${tgt.x} ${tgt.y} ${tgt.z} ${tgt.x} ${tgt.y} ${tgt.z} minecraft:air`);
        cmd(`fill ${tgt.x} ${tgt.y} ${tgt.z} ${tgt.x} ${tgt.y} ${tgt.z} minecraft:lava`);
        await sleep(800);
        const bare0 = snap('bare_before');
        await bot.activateItem();
        await sleep(1200);
        const bareGone = !(await isLavaAt(tgt)).hit;
        rows.push({ phase: 'bare_activateItem', bare0, after: snap('bare_after'), serverLavaGone: bareGone, serverHeld: await serverHeld('HB') });
        console.log(JSON.stringify(rows[rows.length - 1]));

        fs.writeFileSync(path.join(RUNS_DIR, 'diag_micro_repro.json'), JSON.stringify({ stamp: STAMP, target: tgt, stand: STAND, rows }, null, 2));
        for (const r of rows) {
            cells.push({
                cell: r.phase ?? `R${r.n}${r.doTp ? '_tp' : '_notp'}`, desc: r.phase ?? (r.doTp ? '带 tp' : '不带 tp'),
                clientHeldBefore: r.before?.held ?? r.bare0?.held ?? null, serverHeldBefore: '-',
                clientBlockBefore: 'lava', clientHeldAfter: r.after?.held ?? null,
                clientBlockAfter: r.serverLavaGone ? '(服务端:没了)' : 'lava', clientChanged: !!r.serverLavaGone,
                ms: 0, thrown: null, serverStillLava: r.serverLavaGone ? false : true, serverLogFlags: [],
            });
        }
    } else {
    // ================= 第二轮：S3 定案之后，问「倒水/浇筑能不能用 block_place」 =================

    // —— S7 activateItem 连续 5 次（可靠性：微基准要 ≥95%，单次成功不算数）——
    for (let i = 0; i < 5; i++) {
        await runCell(`S7_activateItem_${i + 1}`, `lookAt(force)+activateItem() 第 ${i + 1}/5 次`,
            async () => {
                const b = lavaBlock();
                await bot.lookAt(b.position.offset(0.5, 0.5, 0.5), true);
                await sleep(250);
                await bot.activateItem();
            },
            { judgeClient: () => bot.heldItem?.name === 'lava_bucket' });
    }

    // —— W1 潜行 + block_place（验证「必须从上/潜行才能舀」这条原版规则）——
    await runCell('W1_sneakPlace', 'setControlState(sneak) + block_place',
        async () => {
            const b = lavaBlock();
            await bot.lookAt(b.position.offset(0.5, 0.5, 0.5), true);
            bot.setControlState('sneak', true);
            await sleep(600);                       // 等服务端看到潜行态
            await bot.activateBlock(b, new Vec3(0, 1, 0));
            await sleep(1000);
            bot.setControlState('sneak', false);
            await sleep(200);
        },
        { judgeClient: () => bot.heldItem?.name === 'lava_bucket' });

    // —— P1 倒水：手持 water_bucket，点目标格**脚下的支撑面**（面=UP，液体落到目标格）——
    const pourTarget = SCENE.pourCell;                       // (200,70,199)，脚下 (200,69,199) 是平台 stone
    await runCell('P1_pour_blockPlace', 'water_bucket + 点支撑面 UP（block_place）',
        async () => {
            const ref = bot.blockAt(new Vec3(pourTarget.x, pourTarget.y - 1, pourTarget.z));
            await bot.lookAt(ref.position.offset(0.5, 1.0, 0.5), true);
            await sleep(250);
            await bot.activateBlock(ref, new Vec3(0, 1, 0));
        },
        { give: 'minecraft:water_bucket', target: pourTarget, judgeClient: () => clientView(pourTarget) === 'water' });

    // —— P2 倒水：潜行版 ——
    await runCell('P2_pour_sneak', 'water_bucket + 潜行 + 点支撑面 UP',
        async () => {
            const ref = bot.blockAt(new Vec3(pourTarget.x, pourTarget.y - 1, pourTarget.z));
            await bot.lookAt(ref.position.offset(0.5, 1.0, 0.5), true);
            bot.setControlState('sneak', true);
            await sleep(600);
            await bot.activateBlock(ref, new Vec3(0, 1, 0));
            await sleep(1000);
            bot.setControlState('sneak', false);
        },
        { give: 'minecraft:water_bucket', target: pourTarget, judgeClient: () => clientView(pourTarget) === 'water' });

    // —— P3 浇筑：手持 water_bucket 点岩浆源的顶面 → 应变黑曜石 ——
    await runCell('P3_cast_blockPlace', 'water_bucket + 点岩浆源顶面（block_place）',
        async () => {
            cmd(`fill ${CAST.x} ${CAST.y} ${CAST.z} ${CAST.x} ${CAST.y} ${CAST.z} minecraft:lava`);
            await sleep(800);
            const b = bot.blockAt(new Vec3(CAST.x, CAST.y, CAST.z));
            await bot.lookAt(b.position.offset(0.5, 0.9, 0.5), true);
            await sleep(250);
            await bot.activateBlock(b, new Vec3(0, 1, 0));
        },
        { give: 'minecraft:water_bucket', target: CAST, judgeClient: () => clientView(CAST) === 'obsidian' });

    // —— P4 浇筑：潜行版 ——
    await runCell('P4_cast_sneak', 'water_bucket + 潜行 + 点岩浆源顶面',
        async () => {
            cmd(`fill ${CAST.x} ${CAST.y} ${CAST.z} ${CAST.x} ${CAST.y} ${CAST.z} minecraft:lava`);
            await sleep(800);
            const b = bot.blockAt(new Vec3(CAST.x, CAST.y, CAST.z));
            await bot.lookAt(b.position.offset(0.5, 0.9, 0.5), true);
            bot.setControlState('sneak', true);
            await sleep(600);
            await bot.activateBlock(b, new Vec3(0, 1, 0));
            await sleep(1000);
            bot.setControlState('sneak', false);
        },
        { give: 'minecraft:water_bucket', target: CAST, judgeClient: () => clientView(CAST) === 'obsidian' });

    // —— P5 倒水：activateItem（use_item）能不能倒？—— vanilla 的 BucketItem.use 只舀不倒，
    //    这一格是给报告用的判据，不是候选方案 ——
    await runCell('P5_pour_activateItem', 'water_bucket + activateItem（use_item 能不能倒）',
        async () => {
            const ref = bot.blockAt(new Vec3(pourTarget.x, pourTarget.y - 1, pourTarget.z));
            await bot.lookAt(ref.position.offset(0.5, 1.0, 0.5), true);
            await sleep(250);
            await bot.activateItem();
        },
        { give: 'minecraft:water_bucket', target: pourTarget, judgeClient: () => clientView(pourTarget) === 'water' });
    }

    // 汇总
    const verdict = cells.map((c) => `${c.cell}=${c.clientChanged ? 'OK' : 'no'}`).join(' ');
    const out = { stamp: STAMP, seed: SEED, mcVersion: MC_VERSION, sceneGate: gate, cells, verdict };
    fs.writeFileSync(OUT, JSON.stringify(out, null, 2));

    const md = [
        `# 桶交互通道诊断（${STAMP}）`, '',
        `- 场景真值：${gate.filter((g) => g.hit).length}/${gate.length} 通过`, '',
        '| cell | 手法 | 客户端看到变化 | 服务端岩浆还在 | 客户端主手(前→后) | 服务端主手(前) | 日志异常 |',
        '|---|---|---|---|---|---|---|',
        ...cells.map((c) => `| ${c.cell} | ${c.desc} | ${c.clientChanged ? '✅' : '❌'} | ${c.serverStillLava ? '在（=没舀走）' : '没了（=舀走了）'} | ${c.clientHeldBefore}→${c.clientHeldAfter} | ${(c.serverHeldBefore || '').replace(/\|/g, '/').slice(0, 60)} | ${c.serverLogFlags.length ? c.serverLogFlags.join(' ; ').slice(0, 90) : '无'} |`),
        '', `**结论：${verdict}**`, '',
    ].join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'diag_bucket.md'), md);
    console.log(md);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1200);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});


