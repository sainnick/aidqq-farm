// probe_frame_state.mjs — 真框周围 ±8 格的方块真值（R12 取证）
//
// 设计会话要求（三条）：
//   ① 用 C 线的 `bench/route/tools/region_reader.mjs` 离线解析存档（手册 §5：只读取证走解析器，
//      控制台只用于布景）。做法：卡住时 `save-all flush`，再离线读。
//   ② 验证打法假设：**框内那 2 格岩浆源本身就是浇筑要用的岩浆**。
//      顺序应改成「先用空桶舀走框内岩浆源 → 直接倒进缺格 → 倒水浇成 obsidian → 舀回水」，
//      而不是先挖框格、让岩浆四处流。并对账：先挖底行缺格是不是把框内岩浆放出来、
//      流成了那 12 格流动岩浆。
//   ③ 哭泣黑曜石 32.3s 比理论 41.7s 短（疑服务端挖到 70% 就判完成），用解析器确认那一格
//      在服务端确实是 air。
//
// ★ 为什么"源块还是流动"要两个来源（1.16.1 的硬约束）：
//   Anvil 的 palette 条目里 `Name` 对**源块和流动块是同一个**（都是 `minecraft:lava`），
//   区别只在 `Properties.level` —— 而 `region_reader` 只取 `Name`（`bare(e.Name)`）。
//   那个文件是 **C 线的**，我不改它（跨线改动要设计会话出单）。
//   ⇒ 分工：**解析器**给"这一格是什么方块 / 是不是 air"（含 ③），
//     **客户端方块状态**给 level 判定 source/flowing（数据来自**服务端广播的方块更新包**，
//     是服务端权威值，只是走另一条通道）。两边交叉，不靠控制台回执。
//
// 流程：起服 → tp 到框旁 → 记录「挖之前」状态 → save-all flush（存档快照 A）
//       → 挖掉底行缺格 → 等岩浆流 → 记录「挖之后」状态 → save-all flush（快照 B）
//       → 离线用 region_reader 解析两个快照。
//
// 用法：node probe_frame_state.mjs --stamp P8R12_STATE --seed 4926685115947721762

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane } from './lane_guard.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const STAMP = argOf(process.argv, 'stamp', 'P8R12_STATE');
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'StateBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });
// ★ 快照目录要在起服前就定好，`copyRegion` 在每个 save-all 之后**立刻**调用。
//   ⚠ 第一版把三次复制都放在**所有挖掘之后**（脚本末尾）⇒ worldA/B/C 其实是**同一个**状态，
//   "挖之前/挖之后"的对照全部失效。这个坑与本单同源的教训同源：
//   **取证动作必须紧贴它要证明的那个时刻**，否则快照证明不了任何事。
const worldDirOf = (serverTemplate) => path.join(serverTemplate, 'spike_world');

// 真框（R11 实测 portal_frame_located origin=187 39 307 axis=z）
const FRAME = { origin: { x: 187, y: 39, z: 307 }, axis: 'z' };
const R = 8;                                   // ±8 格
const MISSING = [187, 39, 307];                // 底行缺格（R11 挖过的那一格）
const CRYING = [187, 42, 310];                 // 哭泣黑曜石那一格（R11 挖过，32.3s）
// 框内 2×3（axis=z ⇒ 沿 z 展开 u=0..3，内部 u=1..2）
const INTERIOR = [];
for (let dy = 1; dy <= 3; dy++) for (let u = 1; u <= 2; u++) INTERIOR.push([187, 39 + dy, 307 + u]);

/** 把世界存档的 region/ 复制成快照（只读取证要的就是它；不复制整个世界目录，上次 cpSync 会失败退出） */
function copyRegion(worldDir, dst) {
    const s = path.join(worldDir, 'region'), d = path.join(dst, 'region');
    fs.mkdirSync(d, { recursive: true });
    for (const f of fs.readdirSync(s)) fs.copyFileSync(path.join(s, f), path.join(d, f));
}

let server = null; let bot = null;
const cmd = (c) => { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } };

/** 客户端方块状态：名字 + level（源块/流动的判据） */
function readBox() {
    const out = {};
    for (let dx = -R; dx <= R; dx++) {
        for (let dz = -R; dz <= R; dz++) {
            for (let dy = -R; dy <= R; dy++) {
                const x = FRAME.origin.x + dx, y = FRAME.origin.y + dy, z = FRAME.origin.z + dz;
                let b = null;
                try { b = bot.blockAt(new Vec3(x, y, z)); } catch { b = null; }
                if (!b) continue;
                let level = null;
                try { const p = b.getProperties?.() ?? b.properties; level = (p && (p.level ?? p.Level)) ?? null; } catch { level = null; }
                out[`${x},${y},${z}`] = { name: b.name, level: level === null ? null : Number(level) };
            }
        }
    }
    return out;
}

const key = (p) => `${p[0]},${p[1]},${p[2]}`;
const isSource = (c) => c && c.name === 'lava' && c.level === 0;

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000 });
    if (!st.usable) { console.error('[state] 等不到泳道 B'); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[state] server up in ${(server.bootMs / 1000).toFixed(0)}s`);

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    await sleep(3000);
    await cmd(`op ${LANE_B.username}`);
    var WORLD = path.join(LANE_B.dir, 'spike_world');
    const { equipForBlock } = { equipForBlock: (b) => bot.tool.equipForBlock(b, { requireHarvest: false }) };

    // 传送到框旁，等区块到位
    await cmd(`forceload add ${FRAME.origin.x - 20} ${FRAME.origin.z - 20} ${FRAME.origin.x + 20} ${FRAME.origin.z + 20}`);
    await cmd(`tp ${LANE_B.username} 186 40 306`);       // r5 记录的门外安全落脚点
    for (let k = 0; k < 60; k++) {
        try { if (bot.blockAt(new Vec3(187, 42, 310))?.name === 'crying_obsidian') break; } catch { /* 等 */ }
        await sleep(500);
    }
    await sleep(1500);

    // ===== 快照 A：挖之前 =====
    const boxA = readBox();
    const cryA = boxA[key(CRYING)];
    log(`[state] A 哭泣黑曜石格 (${key(CRYING)}) = ${cryA ? `${cryA.name}` : 'unknown'}`);
    const lavaA = Object.entries(boxA).filter(([, c]) => c.name === 'lava');
    log(`[state] A 框周围 lava 格数 = ${lavaA.length}，其中源块(level=0) = ${lavaA.filter(([, c]) => c.level === 0).length}`);
    log(`[state] A 框内 2×3：${INTERIOR.map((p) => `${p.join('/')}=${boxA[key(p)]?.name ?? '-'}${boxA[key(p)]?.name === 'lava' ? `(L${boxA[key(p)].level})` : ''}`).join('  ')}`);
    cmd('save-all flush');
    await sleep(6000);
    copyRegion(WORLD, path.join(RUNS_DIR, 'worldA'));
    log('[state] 快照 A 已复制');

    // ===== 挖掉底行缺格，观察岩浆 =====
    const mb = bot.blockAt(new Vec3(...MISSING));
    log(`[state] 底行缺格 (${MISSING.join(',')}) = ${mb?.name ?? 'unknown'}`);
    if (mb && mb.boundingBox === 'block') {
        try { await equipForBlock(mb); } catch { /* 忽略 */ }
        const tDig = Date.now();
        try { await bot.dig(mb); log(`[state] 挖掘耗时 ${((Date.now() - tDig) / 1000).toFixed(1)}s`); } catch (e) { log(`[state] 挖掘失败 ${e.message}`); }
        for (let k = 0; k < 120; k++) {
            let b = null; try { b = bot.blockAt(new Vec3(...MISSING)); } catch { b = null; }
            if (!b || b.boundingBox !== 'block') break;
            await sleep(100);
        }
    }
    await sleep(3000);   // 让岩浆有时间流

    // ===== 快照 B：挖掉底行缺格之后（观察框内岩浆是否被放出来）=====
    const boxB = readBox();
    const lavaB = Object.entries(boxB).filter(([, c]) => c.name === 'lava');
    log(`[state] B 框周围 lava 格数 = ${lavaB.length}，其中源块(level=0) = ${lavaB.filter(([, c]) => c.level === 0).length}`);
    copyRegion(WORLD, path.join(RUNS_DIR, 'worldB'));
    log('[state] 快照 B 已复制');
    log(`[state] B 框内 2×3：${INTERIOR.map((p) => `${p.join('/')}=${boxB[key(p)]?.name ?? '-'}${boxB[key(p)]?.name === 'lava' ? `(L${boxB[key(p)].level})` : ''}`).join('  ')}`);

    // ===== R12-③：挖掉**哭泣黑曜石**那一格，验证它在服务端是否真变 air =====
    const cb = bot.blockAt(new Vec3(...CRYING));
    log(`[state] 哭泣黑曜石格 (${CRYING.join(',')}) = ${cb?.name ?? 'unknown'}`);
    let digMs = null;
    if (cb && cb.boundingBox === 'block') {
        try { await equipForBlock(cb); } catch { /* 忽略 */ }
        const t0 = Date.now();
        try { await bot.dig(cb); digMs = Date.now() - t0; log(`[state] 哭泣黑曜石挖掘耗时 ${(digMs / 1000).toFixed(1)}s`); } catch (e) { log(`[state] 哭泣黑曜石挖掘失败 ${e.message}`); }
        for (let k = 0; k < 600; k++) {                 // 最多 60s（理论 41.7s，留富余）
            let b = null; try { b = bot.blockAt(new Vec3(...CRYING)); } catch { b = null; }
            if (!b || b.boundingBox !== 'block') break;
            await sleep(100);
        }
        await sleep(800);
        log(`[state] 挖后该格 = ${(bot.blockAt(new Vec3(...CRYING))?.name) ?? 'unknown'}（客户端视角）`);
    }
    cmd('save-all flush');
    await sleep(6000);
    copyRegion(WORLD, path.join(RUNS_DIR, 'worldC'));
    const boxC = readBox();
    const cryC = boxC[key(CRYING)];
    log(`[state] C 哭泣黑曜石格 = ${cryC ? cryC.name : 'unknown'}  digMs=${digMs}`);


    fs.writeFileSync(path.join(RUNS_DIR, 'client_boxes.json'), JSON.stringify({
        frame: FRAME, radius: R, missing: MISSING, crying: CRYING, interior: INTERIOR,
        digMsMissing: null,
        before: { box: boxA, cryingCell: cryA, lavaCount: lavaA.length, lavaSources: lavaA.filter(([, c]) => c.level === 0).length },
        afterMissing: { box: boxB, lavaCount: lavaB.length, lavaSources: lavaB.filter(([, c]) => c.level === 0).length },
        afterCrying: { box: boxC, cryingCell: cryC, digMsCrying: digMs },
    }, null, 2));
    log(`[state] 已写出 client_boxes.json + 世界快照 A/B/C（region/）`);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    process.exit(0);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
