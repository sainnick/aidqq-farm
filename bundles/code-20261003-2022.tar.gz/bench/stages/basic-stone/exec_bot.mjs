// exec_bot.mjs — MC-M1-TASK-01 BASIC-stone benchmark 执行机器人（standalone）
//
// 直接装载正式任务层（mindcraft/src/agent/tasks/exec/，与 DECIDER_MODE=tasked 同一套模块），
// 不加载 prompter/history/self-prompt——零 LLM 是结构性保证，不是纪律性约定。
//
// 试验协议（继承 REUSE SPIKE 已验证口径，experiments/exec-reuse-spike/run_trial.sh）：
//   fresh world（seed 由 runner 注入）→ 正常出生 → RCON 注入 1 把木镐（唯一非游戏内动作，
//   已在协议记录；木器/合成属 BASIC-wood/BASIC-craft，本轮禁止扩展）→ 任务层闭环 → 终态出结果。
//
// 用法：node exec_bot.mjs --trial 1 --seed <seed> --out <runDir> [--port 25566] [--rcon-port 25576]
//       [--username TaskBot] [--target 16] [--timeout-ms 300000]

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import net from 'net';
import fs from 'fs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const MINDCRAFT = path.join(ROOT, 'mindcraft');
// 依赖解析锚定 mindcraft/node_modules；任务层模块自身的裸导入同样从其所在目录向上解析
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}

const TRIAL = parseInt(arg('trial', '0'), 10);
const SEED = arg('seed', 'unknown');
const OUT_DIR = arg('out', path.dirname(fileURLToPath(import.meta.url)));
const PORT = parseInt(arg('port', '25566'), 10);
const RCON_PORT = parseInt(arg('rcon-port', '25576'), 10);
const USERNAME = arg('username', 'TaskBot');
const TARGET = parseInt(arg('target', '16'), 10);
const TIMEOUT_MS = parseInt(arg('timeout-ms', '300000'), 10);
// MC-M1-TASK-03：版本开关（默认 1.21.1 = TASK-01 原口径，1.16.1 迁移闸门用 --mc-version 注入）
const MC_VERSION = arg('mc-version', '1.21.1');
const TELEMETRY = path.join(OUT_DIR, 'telemetry.jsonl');
const RESULT = path.join(OUT_DIR, 'result.json');
const LOG = path.join(OUT_DIR, 'bot.log');

fs.mkdirSync(OUT_DIR, { recursive: true });
const logLine = (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(LOG, line + '\n'); } catch {}
};

// ---- 极简 RCON（与 spike 同协议：[len][id][type][payload][0,0]，仅用于发 kit） ----
// 认证失败时服务器回 id=-1、空 payload——必须显式校验，否则空响应会伪装成成功
const RCON_PASS = arg('rcon-pass', 'spike-rcon');
function rcon(command, port = RCON_PORT) {
    return new Promise((resolve, reject) => {
        const sock = net.connect(port, '127.0.0.1');
        let buf = Buffer.alloc(0), sentCmd = false, got = false;
        const pkt = (id, type, payload) => {
            const body = Buffer.alloc(12 + payload.length);
            body.writeInt32LE(id, 0); body.writeInt32LE(type, 4);
            body.write(payload, 8);
            const head = Buffer.alloc(4); head.writeInt32LE(body.length, 0);
            return Buffer.concat([head, body]);
        };
        sock.on('connect', () => sock.write(pkt(1, 3, RCON_PASS)));
        sock.on('data', (d) => {
            buf = Buffer.concat([buf, d]);
            while (buf.length >= 4) {
                const len = buf.readInt32LE(0);
                if (buf.length < len + 4) break;
                const id = buf.readInt32LE(4);
                const payload = buf.toString('utf8', 12, 4 + len - 2);
                buf = buf.slice(4 + len);
                if (id === 1) {
                    if (!sentCmd) { sentCmd = true; sock.write(pkt(2, 2, command)); }
                } else {
                    got = true; sock.end();
                    if (id === -1) { reject(new Error('rcon auth failed')); return; }
                    resolve(payload); return;
                }
            }
        });
        sock.on('error', reject);
        setTimeout(() => { sock.destroy(); if (!got) reject(new Error('rcon timeout')); }, 8000);
    });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let finished = false;

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const toolPlugin = require('mineflayer-tool').plugin;
    const { TaskRuntime } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/task_runner.js')).href);
    const { AcquireResourceTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/acquire_resource_task.js')).href);
    const { parseMission } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/mission.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
    bot.loadPlugin(pf.pathfinder);
    bot.loadPlugin(toolPlugin);

    // 硬看门狗：任务层自身有超时，这里是 runner 级保险（360s）
    const hardKill = setTimeout(() => {
        logLine('HARD_TIMEOUT: runner watchdog fired, exiting without result');
        finish({ status: 'RUNNER_TIMEOUT' }, 1);
    }, TIMEOUT_MS + 60000);

    bot.on('kicked', (r) => { logLine(`kicked: ${r}`); if (!finished) finish({ status: 'KICKED', reason: String(r) }, 1); });
    bot.on('error', (e) => logLine(`bot_error: ${String(e).slice(0, 200)}`));
    // 死亡 → 重生 → 重新注入 kit（kit 是协议常量：本 benchmark 测任务层，不测「没工具走 200 格」；
    // 死亡数照记进 metrics，岩浆/坠落生存问题留给后续 defense benchmark）
    let spawns = 0;
    bot.on('death', () => { logLine('death event: respawning in 800ms'); setTimeout(() => { try { bot.respawn(); } catch {} }, 800); });
    bot.on('spawn', async () => {
        spawns++;
        if (spawns <= 1) return; // 首次 spawn 由 once('spawn') 主流程负责
        try {
            const resp = await rcon(`give ${USERNAME} wooden_pickaxe 1`);
            logLine(`rekit after respawn: ${String(resp).slice(0, 60)}`);
        } catch (e) { logLine(`rekit fail: ${e.message}`); }
    });

    bot.once('spawn', async () => {
        try {
            await sleep(4000); // 世界落定（spike 同款）
            let kitOk = false, kitResp = '';
            for (let a = 0; a < 3 && !kitOk; a++) {
                try {
                    kitResp = await rcon(`give ${USERNAME} wooden_pickaxe 1`);
                    kitOk = kitResp.includes('Gave'); // 空响应/错误信息一律不算给到
                } catch (e) { kitResp = e.message; }
                if (!kitOk) { logLine(`kit_fail attempt ${a + 1}: ${String(kitResp).slice(0, 80)}`); await sleep(2000); }
            }
            if (!kitOk) { logLine('FATAL: no kit, abort trial'); finish({ status: 'FAILED', failReason: 'KIT_FAILED' }, 1); return; }
            await sleep(1500);
            const invSnap = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',') || '(empty)';
            const pick = bot.inventory.items().find((i) => i.name === 'wooden_pickaxe');
            logLine(`kit resp="${String(kitResp).slice(0, 80)}" inventory=[${invSnap}] pick=${pick ? `id${pick.type} durUsed=${pick.durabilityUsed}` : 'MISSING'}`);
            const mission = parseMission(JSON.stringify({ resource: 'stone', count: TARGET }));
            logLine(`start: seed=${SEED} pos=${fmtPos(bot)} mission=${JSON.stringify(mission)}`);
            const runtime = new TaskRuntime(bot, { mission, telemetryPath: TELEMETRY });
            const root = new AcquireResourceTask({ resource: mission.resource, count: mission.count, timeoutMs: TIMEOUT_MS });
            const summary = await runtime.run(root);
            logLine(`end: ${summary.status} reason=${summary.failReason} dur=${(summary.durationMs / 1000).toFixed(1)}s inv=${JSON.stringify(summary.finalInventory)}`);
            finish(summary, summary.status === 'SUCCESS' ? 0 : 1);
        } catch (e) {
            logLine(`fatal: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`);
            finish({ status: 'FAILED', failReason: 'INTERNAL', error: String(e).slice(0, 300) }, 1);
        }
    });

    function fmtPos(b) { const p = b.entity.position; return [Math.round(p.x), Math.round(p.y), Math.round(p.z)]; }

    function finish(summary, code) {
        if (finished) return;
        finished = true;
        clearTimeout(hardKill);
        try {
            fs.writeFileSync(RESULT, JSON.stringify({ trial: TRIAL, seed: SEED, target: TARGET, ...summary }, null, 2));
        } catch (e) { logLine(`result write fail: ${e.message}`); }
        setTimeout(() => {
            try { bot.quit(); } catch {}
            process.exit(code);
        }, 1200);
    }
}

main().catch((e) => { logLine(`boot fail: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`); process.exit(1); });
