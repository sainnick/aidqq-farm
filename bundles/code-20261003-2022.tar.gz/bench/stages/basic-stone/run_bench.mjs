// run_bench.mjs — MC-M1-TASK-01 BASIC-stone benchmark runner（fresh world × N trials 顺序执行）
//
// fresh world 规范（任务书 §6）：每个 trial 独立世界（删 world 三件套 + 注入 level-seed），
// benchmark 世界与节目 attempt 世界（server/）完全分离——本 runner 只动已登记的独立测试服
// experiments/exec-reuse-spike/server-spike（端口 25566/25576，shared.md 登记）。
//
// 用法：node run_bench.mjs --trials 20 [--start 1] [--target 16] [--timeout-ms 300000]
// 环境变量：MC_BENCH_SERVER（默认 experiments/exec-reuse-spike/server-spike）
//           MC_BENCH_JAVA（默认 Eclipse Adoptium JRE 21）
// 产物：runs/trial_NN/{server.log, bot.log, telemetry.jsonl, result.json} + runs/summary.jsonl

import { spawn, spawnSync } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import net from 'net';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const SERVER_DIR = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/exec-reuse-spike/server-spike');
const JAVA = process.env.MC_BENCH_JAVA || 'C:/Program Files/Eclipse Adoptium/jre-21.0.12.101-hotspot/bin/java.exe';
// MC-M1-TASK-03：jar 与 bot 协议版本可切换（默认 1.21.1 原口径；1.16.1 迁移用
// MC_BENCH_JAR=server-1.16.1.jar + --mc-version 1.16.1 + MC_BENCH_SERVER/MC_BENCH_JAVA 指向 1.16 环境）
const JAR = path.join(SERVER_DIR, process.env.MC_BENCH_JAR || 'paper-1.21.1-133.jar');
const MC_VERSION = arg('mc-version', process.env.MC_BENCH_VERSION || '1.21.1');
const SERVER_PORT = 25566, RCON_PORT = 25576;

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}
const TRIALS = parseInt(arg('trials', '20'), 10);
const START = parseInt(arg('start', '1'), 10);
const TARGET = parseInt(arg('target', '16'), 10);
const TIMEOUT_MS = parseInt(arg('timeout-ms', '300000'), 10);
const RUNSTAMP = arg('stamp', `M1S${new Date().toISOString().slice(0, 13).replace(/[-T:]/g, '')}`);
// MC-M1-TASK-04：seed 复跑参数（默认不设 → seed 仍由 stamp 派生，原行为不变）
const SEED_PREFIX = arg('seed-prefix', RUNSTAMP);
const SEED_LITERAL = arg('seed', '');
const RUNS_DIR = path.join(BENCH_DIR, 'runs', RUNSTAMP);

const WORLD_DIRS = ['spike_world', 'spike_world_nether', 'spike_world_the_end'].map((d) => path.join(SERVER_DIR, d));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (msg) => { console.log(`[bench ${new Date().toISOString().slice(11, 19)}] ${msg}`); };

// ---- 极简 RCON（同 spike 协议，停服用） ----
const RCON_PASS = 'spike-rcon';
function rcon(command) {
    return new Promise((resolve, reject) => {
        const sock = net.connect(RCON_PORT, '127.0.0.1');
        let buf = Buffer.alloc(0), sentCmd = false, got = false;
        const pkt = (id, type, payload) => {
            const body = Buffer.alloc(12 + payload.length);
            body.writeInt32LE(id, 0); body.writeInt32LE(type, 4);
            body.write(payload, 8);
            const head = Buffer.alloc(4); head.writeInt32LE(body.length, 0);
            return Buffer.concat([head, body]);
        };
        sock.on('connect', () => sock.write(pkt(1, 3, RCON_PASS)));
        sock.on('data', (d) => {
            buf = Buffer.concat([buf, d]);
            while (buf.length >= 4) {
                const len = buf.readInt32LE(0);
                if (buf.length < len + 4) break;
                const id = buf.readInt32LE(4);
                const payload = buf.toString('utf8', 12, 4 + len - 2);
                buf = buf.slice(4 + len);
                if (id === 1) { if (!sentCmd) { sentCmd = true; sock.write(pkt(2, 2, command)); } }
                else {
                    got = true; sock.end();
                    if (id === -1) { reject(new Error('rcon auth failed')); return; }
                    resolve(payload); return;
                }
            }
        });
        sock.on('error', reject);
        setTimeout(() => { sock.destroy(); if (!got) reject(new Error('rcon timeout')); }, 8000);
    });
}

function freshWorld(seed) {
    for (const d of WORLD_DIRS) fs.rmSync(d, { recursive: true, force: true });
    const spPath = path.join(SERVER_DIR, 'server.properties');
    const lines = fs.readFileSync(spPath, 'utf8').split(/\r?\n/).filter((l) => !l.startsWith('level-seed='));
    lines.push(`level-seed=${seed}`);
    fs.writeFileSync(spPath, lines.join('\n') + '\n');
}

async function bootServer(runDir) {
    const serverLog = path.join(runDir, 'server.log');
    const out = fs.openSync(serverLog, 'w');
    const child = spawn(JAVA, ['-Xms512M', '-Xmx1536M', '-jar', JAR, '--nogui'], { cwd: SERVER_DIR, stdio: ['ignore', out, out] });
    const t0 = Date.now();
    while (Date.now() - t0 < 300000) {
        await sleep(2000);
        try {
            const txt = fs.readFileSync(serverLog, 'utf8');
            if (txt.includes('Done (')) return { child, bootMs: Date.now() - t0 };
        } catch {}
        if (child.exitCode !== null) break;
    }
    fs.closeSync(out);
    throw new Error('server boot timeout/crash');
}

async function stopServer(child) {
    try { await rcon('stop'); } catch {}
    const t0 = Date.now();
    while (Date.now() - t0 < 60000) {
        if (child.exitCode !== null) return;
        await sleep(2000);
    }
    try { child.kill('SIGKILL'); } catch {}
    spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' });
}

function killTree(pid) {
    try { spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { stdio: 'ignore' }); } catch {}
}

async function runTrial(n) {
    // MC-M1-TASK-04：--seed 字面量优先（固定种子 ×N）；否则 --seed-prefix 派生（默认=stamp 原行为）
    const seed = SEED_LITERAL || `${SEED_PREFIX}-${String(n).padStart(2, '0')}`;
    const runDir = path.join(RUNS_DIR, `trial_${String(n).padStart(2, '0')}`);
    fs.mkdirSync(runDir, { recursive: true });
    const row = { trial: n, seed, startedAt: new Date().toISOString() };

    freshWorld(seed);
    log(`trial ${n}: fresh world seed=${seed}, booting server...`);
    let server;
    try {
        server = await bootServer(runDir);
    } catch (e) {
        row.outcome = 'SERVER_FAIL'; row.error = String(e);
        return row;
    }
    row.bootMs = server.bootMs;
    log(`trial ${n}: server up in ${(server.bootMs / 1000).toFixed(0)}s, launching exec_bot (target ${TARGET} stone)`);

    const botProc = spawn(process.execPath, [
        path.join(BENCH_DIR, 'exec_bot.mjs'),
        '--trial', String(n), '--seed', seed, '--out', runDir,
        '--port', String(SERVER_PORT), '--rcon-port', String(RCON_PORT),
        '--username', 'TaskBot', '--target', String(TARGET), '--timeout-ms', String(TIMEOUT_MS),
        '--mc-version', MC_VERSION,
    ], { stdio: 'inherit' });

    const exitCode = await new Promise((resolve) => {
        const t0 = Date.now();
        const poll = setInterval(() => {
            if (botProc.exitCode !== null) { clearInterval(poll); resolve(botProc.exitCode); }
            else if (Date.now() - t0 > TIMEOUT_MS + 90000) { clearInterval(poll); killTree(botProc.pid); resolve(-9); }
        }, 1000);
        botProc.on('exit', (code) => { clearInterval(poll); resolve(code); });
    });
    row.botExit = exitCode;
    log(`trial ${n}: bot exit=${exitCode}, stopping server...`);
    await stopServer(server.child);
    await sleep(2000);

    try {
        const result = JSON.parse(fs.readFileSync(path.join(runDir, 'result.json'), 'utf8'));
        row.result = result;
        row.outcome = result.status === 'SUCCESS' ? 'SUCCESS' : `FAIL(${result.failReason ?? '?'})`;
    } catch {
        row.outcome = 'NO_RESULT';
    }
    return row;
}

async function main() {
    fs.mkdirSync(RUNS_DIR, { recursive: true });
    const summaryPath = path.join(RUNS_DIR, 'summary.jsonl');
    log(`BASIC-stone benchmark: ${TRIALS} trials (start=${START}), stamp=${RUNSTAMP}, runs→${RUNS_DIR}`);
    const rows = [];
    for (let n = START; n < START + TRIALS; n++) {
        const row = await runTrial(n);
        rows.push(row);
        fs.appendFileSync(summaryPath, JSON.stringify(row) + '\n');
        log(`trial ${n}: ${row.outcome}${row.result ? ` dur=${((row.result.durationMs ?? 0) / 1000).toFixed(1)}s` : ''}`);
    }
    const ok = rows.filter((r) => r.outcome === 'SUCCESS').length;
    log(`DONE: ${ok}/${rows.length} SUCCESS`);
    process.exit(0);
}

main().catch((e) => { console.error(e); process.exit(1); });
