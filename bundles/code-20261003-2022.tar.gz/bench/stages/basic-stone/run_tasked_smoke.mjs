// run_tasked_smoke.mjs — MC-M1-TASK-01 DECIDER_MODE=tasked 真机冒烟
//
// 走真实 mindcraft 链路（main.js → mindserver → AgentProcess → agent.js）验证 tasked 模式：
//   - fresh world 测试服（同一台 25566/25576 spike 服）
//   - PROFILES 指向 TaskBot 沙箱 profile（memory 写 bots/TaskBot/，不碰节目 GLM53 记忆）
//   - DECIDER_MODE=tasked + TASKED_MISSION 注入，任务层接管，期望零 LLM 调用
//   - 验收：TASKED_RESULT 出现且 status=SUCCESS；bot.log/mindserver 输出无 promptConvo
//
// 用法：node run_tasked_smoke.mjs [--seed tasked-smoke-1] [--target 16] [--mc-version 1.16.1]
// 版本开关（MC-M1-TASK-03 G5）：--mc-version 注入 SETTINGS_JSON.minecraft_version（agent 子进程
// 经 init_agent.js 应用），配合 MC_BENCH_SERVER / MC_BENCH_JAR / MC_BENCH_JAVA 指向 1.16 环境；
// 默认 1.21.1 = TASK-01 原口径。

import { spawn, spawnSync } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import net from 'net';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const SERVER_DIR = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/exec-reuse-spike/server-spike');
const JAVA = process.env.MC_BENCH_JAVA || 'C:/Program Files/Eclipse Adoptium/jre-21.0.12.101-hotspot/bin/java.exe';
const JAR = path.join(SERVER_DIR, process.env.MC_BENCH_JAR || 'paper-1.21.1-133.jar');
const MINDCRAFT = path.join(ROOT, 'mindcraft');
const PROFILE = path.join(BENCH_DIR, 'taskbot_profile.json');
const MINDSERVER_PORT = 8091; // 冒烟专用，避开节目 8080（shared.md 登记）
// 生产管线钉死 Node 20（vision 模块在 node24 加载即崩，director.mjs 同款约束），tasked 冒烟必须同轨
const NODE20 = path.join(ROOT, '.runtime', 'node-v20.20.2-win-x64', 'node.exe');

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}
const SEED = arg('seed', `M1TS${Date.now()}`);
const TARGET = parseInt(arg('target', '16'), 10);
const MC_VERSION = arg('mc-version', process.env.MC_BENCH_VERSION || '1.21.1');
const RUN_DIR = path.join(BENCH_DIR, 'runs', 'tasked_smoke');
fs.mkdirSync(RUN_DIR, { recursive: true });

const WORLD_DIRS = ['spike_world', 'spike_world_nether', 'spike_world_the_end'].map((d) => path.join(SERVER_DIR, d));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (m) => console.log(`[smoke ${new Date().toISOString().slice(11, 19)}] ${m}`);

function rcon(command) {
    return new Promise((resolve, reject) => {
        const sock = net.connect(25576, '127.0.0.1');
        let buf = Buffer.alloc(0), sentCmd = false, got = false;
        const pkt = (id, type, payload) => {
            const body = Buffer.alloc(12 + payload.length);
            body.writeInt32LE(id, 0); body.writeInt32LE(type, 4);
            body.write(payload, 8);
            const head = Buffer.alloc(4); head.writeInt32LE(body.length, 0);
            return Buffer.concat([head, body]);
        };
        sock.on('connect', () => sock.write(pkt(1, 3, 'spike-rcon')));
        sock.on('data', (d) => {
            buf = Buffer.concat([buf, d]);
            while (buf.length >= 4) {
                const len = buf.readInt32LE(0);
                if (buf.length < len + 4) break;
                const id = buf.readInt32LE(4);
                const payload = buf.toString('utf8', 12, 4 + len - 2);
                buf = buf.slice(4 + len);
                if (id === 1) { if (!sentCmd) { sentCmd = true; sock.write(pkt(2, 2, command)); } }
                else { got = true; sock.end(); if (id === -1) { reject(new Error('auth failed')); return; } resolve(payload); return; }
            }
        });
        sock.on('error', reject);
        setTimeout(() => { sock.destroy(); if (!got) reject(new Error('timeout')); }, 8000);
    });
}

async function main() {
    // 预检：端口被残留进程占用时直接失败并给出 PID（禁止静默复用脏环境）
    for (const port of [25566, 25576, MINDSERVER_PORT]) {
        const busy = spawnSync('netstat', ['-ano']).stdout.toString().split('\n')
            .some((l) => l.includes(`:${port} `) && l.includes('LISTENING'));
        if (busy) { console.error(`[smoke] FATAL: port ${port} busy — kill the leftover process first`); process.exit(1); }
    }

    // fresh world
    for (const d of WORLD_DIRS) fs.rmSync(d, { recursive: true, force: true });
    const spPath = path.join(SERVER_DIR, 'server.properties');
    const lines = fs.readFileSync(spPath, 'utf8').split(/\r?\n/).filter((l) => !l.startsWith('level-seed='));
    lines.push(`level-seed=${SEED}`);
    fs.writeFileSync(spPath, lines.join('\n') + '\n');

    log('booting fresh-world server...');
    const serverLog = path.join(RUN_DIR, 'server.log');
    const out = fs.openSync(serverLog, 'w');
    const server = spawn(JAVA, ['-Xms512M', '-Xmx1536M', '-jar', JAR, '--nogui'], { cwd: SERVER_DIR, stdio: ['ignore', out, out] });
    const t0 = Date.now();
    while (Date.now() - t0 < 300000) {
        await sleep(2000);
        try { if (fs.readFileSync(serverLog, 'utf8').includes('Done (')) break; } catch {}
        if (server.exitCode !== null) { console.error('server died'); process.exit(1); }
    }
    log(`server up (${((Date.now() - t0) / 1000).toFixed(0)}s), launching mindcraft agent in DECIDER_MODE=tasked`);

    const resultPath = path.join(RUN_DIR, 'tasked_result.json');
    const agentLog = path.join(RUN_DIR, 'agent.log');
    // 陈旧结果必须清掉：上一轮残留会让 verdict 读到旧 mission
    for (const f of [resultPath, agentLog, path.join(RUN_DIR, 'tasked_telemetry.jsonl')]) {
        try { fs.rmSync(f, { force: true }); } catch {}
    }
    const aout = fs.openSync(agentLog, 'a');
    const agent = spawn(NODE20, ['main.js'], {
        cwd: MINDCRAFT,
        env: {
            ...process.env,
            MINECRAFT_PORT: '25566',
            MINDSERVER_PORT: String(MINDSERVER_PORT),
            DECIDER_MODE: 'tasked',
            TASKED_MISSION: `obtain ${TARGET} stone`,
            TASKED_RESULT: resultPath,
            TASKED_TELEMETRY: path.join(RUN_DIR, 'tasked_telemetry.jsonl'),
            TASKED_TIMEOUT_MS: '300000',
            PROFILES: JSON.stringify([PROFILE]),
            SETTINGS_JSON: JSON.stringify({ minecraft_version: MC_VERSION, render_bot_view: false, production_report_url: '', load_memory: false, init_message: null }),
        },
        stdio: ['ignore', aout, aout],
    });

    const exitCode = await new Promise((resolve) => {
        const t1 = Date.now();
        // kit 注入（与 spike/bench 同协议：RCON give 木镐，唯一非游戏内动作）：
        // 等 agent 出现在服务器日志再给，给完校验响应
        let kitDone = false;
        const kitPoll = setInterval(async () => {
            if (kitDone) { clearInterval(kitPoll); return; }
            try {
                const txt = fs.readFileSync(serverLog, 'utf8');
                if (txt.includes('TaskBot joined the game')) {
                    kitDone = true;
                    clearInterval(kitPoll);
                    const resp = await rcon(`give TaskBot wooden_pickaxe 1`);
                    log(`kit: ${String(resp).slice(0, 60)}`);
                }
            } catch { /* 服务器还没就绪，下轮再试 */ }
        }, 2000);
        const poll = setInterval(() => {
            if (agent.exitCode !== null) { clearInterval(poll); resolve(agent.exitCode); }
            else if (fs.existsSync(resultPath)) { clearInterval(poll); resolve(awaitExit()); }
            else if (Date.now() - t1 > 420000) { clearInterval(poll); resolve(-1); }
        }, 2000);
        const awaitExit = () => new Promise((r2) => {
            const p2 = setInterval(() => {
                if (agent.exitCode !== null) { clearInterval(p2); r2(agent.exitCode); }
            }, 1000);
            setTimeout(() => { clearInterval(p2); r2(agent.exitCode ?? -2); }, 30000);
        });
        agent.on('exit', (code) => resolve(code));
    });

    // 收尾：优雅停服
    try { await rcon('stop'); } catch {}
    await sleep(3000);
    try { spawnSync('taskkill', ['/PID', String(server.pid), '/T', '/F'], { stdio: 'ignore' }); } catch {}
    try { spawnSync('taskkill', ['/PID', String(agent.pid), '/T', '/F'], { stdio: 'ignore' }); } catch {}

    let verdict = { tasked_smoke: 'FAIL', reason: 'no result file' };
    if (fs.existsSync(resultPath)) {
        const r = JSON.parse(fs.readFileSync(resultPath, 'utf8'));
        const agentTxt = fs.readFileSync(agentLog, 'utf8');
        const llmSuspect = /promptConvo|llmChoice|bailianChoice|Prompting/.test(agentTxt);
        verdict = {
            tasked_smoke: r.status === 'SUCCESS' && !llmSuspect ? 'PASS' : 'FAIL',
            status: r.status,
            failReason: r.failReason,
            durationSec: +(r.durationMs / 1000).toFixed(1),
            finalInventory: r.finalInventory,
            llm_suspect_in_log: llmSuspect,
            modes_off_confirmed: /all modes off/.test(agentTxt),
            selfprompt_skipped: /skipping self-prompt restore|task layer takes over/.test(agentTxt),
        };
    }
    console.log(JSON.stringify(verdict, null, 2));
    fs.writeFileSync(path.join(RUN_DIR, 'smoke_verdict.json'), JSON.stringify(verdict, null, 2));
    process.exit(verdict.tasked_smoke === 'PASS' ? 0 : 1);
}

main().catch((e) => { console.error(e); process.exit(1); });
