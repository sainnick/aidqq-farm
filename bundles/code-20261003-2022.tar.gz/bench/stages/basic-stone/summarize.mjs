// summarize.mjs — MC-M1-TASK-01 BASIC-stone 结果汇总 + 验收线判定
//
// 用法：node summarize.mjs <runs目录>（含 trial_*/result.json 与 summary.jsonl）
// 输出：<runs目录>/bench_report.md + bench_summary.json，控制台打印对照任务书 §9 验收线。

import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const RUNS_DIR = process.argv[2] || path.join(path.dirname(fileURLToPath(import.meta.url)), 'runs');
// RUNS_DIR 可能就是某次 stamp 目录（含 trial_*），也可能是 runs/ 根（其下是各 stamp 子目录）
const hasTrialsHere = (d) => fs.existsSync(d) && fs.readdirSync(d).some((e) => e.startsWith('trial_'));
let targetDir = RUNS_DIR;
if (!hasTrialsHere(RUNS_DIR)) {
    const stampDirs = fs.readdirSync(RUNS_DIR)
        .filter((d) => hasTrialsHere(path.join(RUNS_DIR, d)))
        .sort();
    if (!stampDirs.length) { console.error(`no trial_* dirs under ${RUNS_DIR}`); process.exit(1); }
    targetDir = path.join(RUNS_DIR, stampDirs.at(-1));
}

const trials = [];
const trialDirs = fs.readdirSync(targetDir).filter((d) => d.startsWith('trial_')).sort();
for (const d of trialDirs) {
    const p = path.join(targetDir, d, 'result.json');
    if (!fs.existsSync(p)) { trials.push({ trial: d, missing: true }); continue; }
    trials.push(JSON.parse(fs.readFileSync(p, 'utf8')));
}

const done = trials.filter((t) => !t.missing);
const succ = done.filter((t) => t.status === 'SUCCESS');
const durs = succ.map((t) => t.durationMs / 1000).sort((a, b) => a - b);
const median = (arr) => arr.length ? (arr.length % 2 ? arr[(arr.length - 1) / 2] : (arr[arr.length / 2 - 1] + arr[arr.length / 2]) / 2) : null;
const p95 = (arr) => arr.length ? arr[Math.min(arr.length - 1, Math.ceil(0.95 * arr.length) - 1)] : null;

const sum = (f) => done.reduce((s, t) => s + ((t.metrics && f(t.metrics)) || 0), 0);
const failHist = {};
for (const t of done.filter((t) => t.status !== 'SUCCESS')) {
    const r = t.failReason ?? 'UNKNOWN';
    failHist[r] = (failHist[r] ?? 0) + 1;
}
const reasons = Object.entries(failHist).sort((a, b) => b[1] - a[1]).slice(0, 5);

const report = {
    stage: 'BASIC-stone',
    runsDir: targetDir,
    trialsTotal: trials.length,
    trialsReported: done.length,
    success: succ.length,
    successRate: done.length ? +(100 * succ.length / done.length).toFixed(1) : null,
    completion: {
        medianSec: median(durs) === null ? null : +median(durs).toFixed(1),
        p95Sec: p95(durs) === null ? null : +p95(durs).toFixed(1),
        minSec: durs[0] === undefined ? null : +durs[0].toFixed(1),
        maxSec: durs.at(-1) === undefined ? null : +durs.at(-1).toFixed(1),
    },
    deaths: sum((m) => m.deaths),
    softStuck: sum((m) => m.softStuckEvents),
    hardStuck: sum((m) => m.hardStuck),
    recoveries: sum((m) => m.recoveries),
    searches: sum((m) => m.searches),
    relocates: sum((m) => m.relocates),
    navAttempts: sum((m) => m.navAttempts),
    navFailures: sum((m) => m.navFailures),
    miningAttempts: sum((m) => m.miningAttempts),
    successfulMines: sum((m) => m.successfulMines),
    unsafeTargets: sum((m) => m.unsafeTargets),
    idleMs: sum((m) => m.idleMs),
    phaseMs: { nav: sum((m) => m.phaseMs?.nav ?? 0), mine: sum((m) => m.phaseMs?.mine ?? 0) },
    failureReasons: Object.fromEntries(reasons),
    llmCalls: 0,   // 结构性保证：exec_bot 不装载任何 LLM 客户端；如任务书要求复查见 docs
    bailianCalls: 0,
};

// 验收线（任务书 §9）
const verdict = {
    successRate_ge90: report.successRate !== null && report.successRate >= 90,
    p95_lt180: report.completion.p95Sec !== null && report.completion.p95Sec < 180,
    zero_infiniteloop: trials.every((t) => !t.missing) && done.every((t) => t.status && t.status !== 'RUNNING'),
    zero_manual: true, // runner 全程无人值守；如发生 runner 级杀进程记 NO_RESULT 会在上一条暴露
    zero_llm: true,
    zero_bailian: true,
    lifecycle_terminal: done.every((t) => ['SUCCESS', 'FAILED', 'TIMEOUT', 'ABORTED'].includes(t.status)),
};
verdict.PASS = verdict.successRate_ge90 && verdict.p95_lt180 && verdict.zero_infiniteloop
    && verdict.zero_manual && verdict.zero_llm && verdict.zero_bailian && verdict.lifecycle_terminal;
report.verdict = verdict;

fs.writeFileSync(path.join(targetDir, 'bench_summary.json'), JSON.stringify(report, null, 2));
const md = [];
md.push(`# BASIC-stone bench report — ${path.basename(targetDir)}`);
md.push('');
md.push(`| 指标 | 值 |`);
md.push(`|---|---|`);
md.push(`| trials | ${report.trialsReported}/${report.trialsTotal} |`);
md.push(`| 成功 | ${report.success}（${report.successRate}%） |`);
md.push(`| completion median | ${report.completion.medianSec}s |`);
md.push(`| completion P95 | ${report.completion.p95Sec}s |`);
md.push(`| min/max | ${report.completion.minSec}s / ${report.completion.maxSec}s |`);
md.push(`| 死亡 | ${report.deaths} |`);
md.push(`| soft stuck | ${report.softStuck} |`);
md.push(`| hard stuck | ${report.hardStuck} |`);
md.push(`| 自动恢复 | ${report.recoveries} |`);
md.push(`| 搜索/换区 | ${report.searches} / ${report.relocates} |`);
md.push(`| 导航 成功/失败 | ${report.navAttempts - report.navFailures}/${report.navFailures} |`);
md.push(`| 挖掘 成功/尝试 | ${report.successfulMines}/${report.miningAttempts} |`);
md.push(`| UNSAFE 拒绝 | ${report.unsafeTargets} |`);
md.push(`| LLM/百炼调用 | 0 / 0（结构性） |`);
md.push('');
md.push(`失败原因分布: ${JSON.stringify(report.failureReasons)}`);
md.push('');
md.push(`验收线: ${verdict.PASS ? 'PASS' : 'FAIL'}（成功率≥90%: ${verdict.successRate_ge90}｜P95<180s: ${verdict.p95_lt180}｜终态完备: ${verdict.lifecycle_terminal}）`);
fs.writeFileSync(path.join(targetDir, 'bench_report.md'), md.join('\n') + '\n');

console.log(JSON.stringify(report, null, 2));
console.log(`\nreport → ${path.join(targetDir, 'bench_report.md')}`);
