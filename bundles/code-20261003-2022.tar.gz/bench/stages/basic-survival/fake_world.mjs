// fake_world.mjs — MC-M1-TASK-07（G 线）：离线自检用的假世界 / 假 bot
//
// 用途：让**不开服**就能验状态机与中断契约（任务单 §2.1「用构造的事件流验证」）。
// 只实现被测代码真正用到的那几个面，其余一律 undefined —— 缺什么就会在测试里炸出来，
// 这比造一个"什么都能干"的假 bot 更能暴露"测试其实没走到那条分支"。
//
// ⚠ 边界：凡是需要 pathfinder 的分支（脱离/掩体/拉近的 navTo）**故意不做**——
//   `new pf.Movements(bot)` 要真 registry，造假 registry 只会得到"看起来跑了"的假覆盖。
//   那些分支留给实服微基准（见报告「离线段未覆盖清单」）。

import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
// bench/ 自己没有 node_modules；`vec3` 等依赖只存在于任务层那一份（worktree 的
// node_modules 是指向主目录的 junction）⇒ 用 createRequire 锚到任务层解析。
// TASK_LAYER_DIR 默认 G 线 worktree（派单 §G 线指定路径）；换线/换机用环境变量覆盖。
export const TASK_LAYER = process.env.TASK_LAYER_DIR || 'D:/AI斗蛐蛐/mindcraft-wt/s0-survival';
const require = createRequire(path.join(TASK_LAYER, 'package.json'));
const { Vec3 } = require('vec3');
const { EventEmitter } = require('node:events');
export { Vec3 };

/** 把任务层模块 URL 化（selftest 用它 import 真实实现）。 */
export function taskModule(rel) {
    return new URL(`file:///${path.join(TASK_LAYER, 'src/agent/tasks/exec', rel).replace(/\\/g, '/')}`).href;
}

const AIR = { name: 'air', boundingBox: 'empty' };
const STONE = { name: 'stone', boundingBox: 'block' };
const WATER = { name: 'water', boundingBox: 'empty' };
const LAVA = { name: 'lava', boundingBox: 'empty' };

/**
 * 造一个假世界。
 * @param {object} o
 * @param {Array<[number,number,number]>} [o.solid]  实心方块坐标表
 * @param {Array<[number,number,number]>} [o.water]
 * @param {Array<[number,number,number]>} [o.lava]
 * @param {boolean} [o.unloadedFromX]  ≥ 该 x 的区块视为未加载（blockAt → null）
 */
export function makeWorld({ solid = [], water = [], lava = [], unloadedFromX = null } = {}) {
    const solidSet = new Set(solid.map(([x, y, z]) => `${x},${y},${z}`));
    const waterSet = new Set(water.map(([x, y, z]) => `${x},${y},${z}`));
    const lavaSet = new Set(lava.map(([x, y, z]) => `${x},${y},${z}`));
    const at = (x, y, z) => {
        const k = `${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`;
        if (unloadedFromX != null && Math.floor(x) >= unloadedFromX) return null;   // 未加载
        if (solidSet.has(k)) return { ...STONE, position: new Vec3(x, y, z) };
        if (waterSet.has(k)) return { ...WATER, position: new Vec3(x, y, z) };
        if (lavaSet.has(k)) return { ...LAVA, position: new Vec3(x, y, z) };
        return { ...AIR, position: new Vec3(x, y, z) };
    };
    return { at, solidSet };
}

/**
 * 造一只假敌对实体。
 * ⚠ `type` 默认必须是 **'mob'**，不是 'hostile'/'animal'——
 *   mineflayer 4.38 的 `entity.type` 来自 minecraft-data 注册表项，1.16.1 里
 *   **107 个实体 type 全是 "mob"**（实测 {mob:101, UNKNOWN:6}），没有一个是
 *   'hostile'/'animal'。这里原来默认 'hostile'，于是
 *   `melee_tick.visibleHostiles` 那道按 type 的预过滤在**离线**能过、
 *   在**真服**恒空 —— 与本单 `entity.look` 完全同族的"假 bot 比真库宽"。
 */
export function makeEntity({ id = 1, name = 'zombie', pos = [0, 0, 0], health = 20, width = 0.6, height = 1.95, type = 'mob', velocity = [0, 0, 0] } = {}) {
    return {
        id, name, type, health, width, height,
        position: new Vec3(pos[0], pos[1], pos[2]),
        velocity: new Vec3(velocity[0], velocity[1], velocity[2]),
        isValid: true,
    };
}

/**
 * 造一个假 bot。事件用 Node EventEmitter（与 mineflayer 同构：on/removeListener/once）。
 * @param {object} o { world, pos, yaw, pitch, health, food, items, entities, time }
 */
export function makeBot(o = {}) {
    const world = o.world ?? makeWorld();
    const pos = new Vec3(...(o.pos ?? [0.5, 64, 0.5]));
    const bot = new EventEmitter();
    bot.entity = {
        position: pos,
        height: 1.8,
        velocity: new Vec3(0, 0, 0),
        // ⚠ 朝向字段必须与 prismarine-entity 的 `Entity` 一致：**只有 `yaw`/`pitch`
        //   两个数字，没有 `look`**（实测 `'look' in new Entity(1) === false`；
        //   mineflayer `entities.js:927 fetchEntity` 就是 `new Entity(id)`）。
        //   这个假 bot 原来自己造了个 `entity.look = {x,y}`，于是 gaze_guard 读
        //   `e.look` 的那条 bug 在离线自检里**测不出来**（真库根本没有这个字段，
        //   生产里恒为 undefined）—— 假 bot 补了真库没有的东西，把真 bug 盖成了绿灯。
        //   教训：假 bot 的字段集合要**等于**真库，不能比真库宽。
        yaw: o.yaw ?? 0,
        pitch: o.pitch ?? 0,
    };
    bot.registry = { blocksByName: {}, fluidsByName: {} };
    bot._health = o.health ?? 20;
    Object.defineProperty(bot, 'health', {
        get: () => bot._health,
        set: (v) => { bot._health = v; bot.emit('health', v); },   // 事件语义同 mineflayer
    });
    bot.food = o.food ?? 20;
    bot.time = { time: o.time ?? 0 };
    bot.entities = {};
    for (const e of o.entities ?? []) bot.entities[e.id] = e;
    bot._items = o.items ?? [];
    bot.inventory = {
        items: () => bot._items,
        slots: bot._items,
        _items: bot._items,
    };
    bot.quickBarSlot = 0;
    bot.heldItem = bot._items[0] ?? null;
    bot.activeItem = null;
    bot.blockAt = (v) => world.at(v?.x ?? 0, v?.y ?? 0, v?.z ?? 0);
    // —— 动作面（假实现，只记账）——
    bot.calls = { attack: [], lookAt: [], look: [], lookSent: [], equip: [], activate: [], consume: 0, nav: [] };
    bot.attack = (e) => { bot.calls.attack.push(e.id); if (o.killOnAttack) delete bot.entities[e.id]; };
    bot.lookAt = (p, force) => { bot.calls.lookAt.push([p?.x, p?.y, p?.z, force]); return true; };
    // `bot.look(yaw, pitch, force)` —— 照抄 mineflayer 4.38 physics.js:329-355 的算法：
    //   灵敏度量化（0.15  Notchian 度 → 0.00261799 rad）、先加后判、force=true 不发包。
    // 之所以照抄而不是记一笔：只有复现这段数学，离线用例才**抓得住**"把 Vec3 当 yaw 传"
    // 这类签名错误（真库会把 entity.yaw 写成 NaN，假 bot 也必须写出 NaN）。
    bot.look = async (yaw, pitch, force) => {
        bot.calls.look.push([yaw, pitch, force]);
        const sens = 0.15 * Math.PI / 180;            // conv.fromNotchianPitch(0.15)
        const yawChange = Math.round((yaw - bot.entity.yaw) / sens) * sens;
        const pitchChange = Math.round((pitch - bot.entity.pitch) / sens) * sens;
        if (yawChange === 0 && pitchChange === 0) return;
        bot.entity.yaw += yawChange;
        bot.entity.pitch += pitchChange;
        bot.calls.lookSent.push(!force);              // force=true ⇒ 一个旋转包都不发（手册 §3）
    };
    bot.equip = (item) => { bot.calls.equip.push(item?.name); bot.heldItem = item; };
    bot.activateItem = (use) => { bot.calls.activate.push(use); bot.activeItem = use ? (bot._items.find((i) => i.name === 'shield') ?? null) : null; };
    bot.consume = () => { bot.calls.consume++; };
    bot.clearControlStates = () => {};
    // pathfinder 是**故意**不给的：`new pf.Movements(bot)` 要真 registry，造假只会得到
    // "看起来跑了"的假覆盖（实测：TypeError: Cannot read properties of undefined (reading 'id')）。
    // 所以任何走到 navTo 的分支（脱离/掩体/拉近）都靠这个哨兵**显式报错**，
    // 报错文案直接说明"该分支归实服微基准覆盖"，而不是留一个看不懂的 TypeError。
    bot.pathfinder = new Proxy({}, {
        get(_, prop) { throw new Error(`FAKE_BOT_NO_PATHFINDER: 离线自检不覆盖 ${String(prop)}（需实服微基准）`); },
    });
    bot.setHealth = (v) => { bot.health = v; };
    bot.spawnEntity = (e) => { bot.entities[e.id] = e; };
    return bot;
}

/** 造一个假 ctx（与 makeCtx 同形，但 stack 交给我们控制）。 */
export function makeFakeCtx(bot, extra = {}) {
    const events = [];
    const run = {
        blacklist: new Set(),
        counters: { ...(extra.counters ?? {}) },
        defenseActive: false,
    };
    const ctx = {
        bot,
        run,
        stack: extra.stack ?? null,
        activeChain: [],
        deathEvents: [],
        stuckEvents: [],
        events,
        telemetry: (event, data = {}) => { events.push({ event, ...data }); },
        takeDeath() { return this.deathEvents.shift() ?? null; },
        takeStuck(taskId) { return null; },
    };
    return ctx;
}

/** 地面平板（站位测试用）：以 (cx,cy,cz) 为中心铺一块地板。 */
export function floorPlate(cx, cy, cz, r = 6) {
    const out = [];
    for (let x = cx - r; x <= cx + r; x++) for (let z = cz - r; z <= cz + r; z++) out.push([x, cy - 1, z]);
    return out;
}
