// creeper_los_invariance.mjs — MC-M1-TASK-07（G 线，第八轮）：
// 「第七轮那个 DDA 逐轴方向的修复，会不会影响 creeper 组的成绩？」
//
// —— 为什么必须问这个 ——
// 苦力怕组要送农场跑 n≥30（本地三条泳道被别线占满）。要拿这批数据去和**修复前**
// 跑过的 creeper 数据放在一起比，就必须先说清 DDA 修复对该组是不是一个**混淆项**。
//
// —— 两条独立的通道 ——
//   ① **结构性**（强）：creeper 微基准的测量路径压根不调用 LOS 射线 ⇒ 修复**结构上**
//      不可能改变该组任何一项读数。这条比几何强，因为它不依赖"某个具体几何"。
//   ② **几何性**（本单原本要验的那条）：即便去测 LOS，场景的**名义几何**下
//      修复前后同判。本脚本把它的**边界**一起扫出来——不变性不是全局成立的，
//      说出边界在哪才算数。
//
// 用法：node bench/stages/basic-survival/analysis/creeper_los_invariance.mjs
//       （纯离线：不连服、不占端口、不碰泳道；TASK_LAYER_DIR 可覆盖任务层路径）

import path from 'node:path';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BENCH = path.join(HERE, '..');
const TASK_LAYER = process.env.TASK_LAYER_DIR || path.resolve(BENCH, '../../../mindcraft-wt/s0-survival');
const require = createRequire(path.join(TASK_LAYER, 'package.json'));
const { Vec3 } = require('vec3');

const LOS = await import(pathToFileURL(path.join(TASK_LAYER, 'src/agent/tasks/exec/defense/los.js')).href);
const { ARENA, legacyRaycast } = await import(pathToFileURL(path.join(BENCH, 'micro/scenarios.mjs')).href);
const { legacyRaycastBlock, fingerprint } = await import(pathToFileURL(path.join(HERE, 'dda_legacy.mjs')).href);
const { makeBot, makeEntity } = await import(pathToFileURL(path.join(BENCH, 'fake_world.mjs')).href);

const CREEP_HEIGHT = 1.7;                 // 1.16.1 苦力怕碰撞箱高〔wiki·Creeper〕
const EYE_BOT = 1.8 * 0.9;                // 玩家眼高 1.62（los.js EYE_HEIGHT）
const EYE_CREEP = CREEP_HEIGHT * 0.9;

// 竞技场世界：**逐格照抄** `micro/scenarios.mjs` 的布景命令语义。
// ⚠⚠ 这里**不能**用 `fake_world.makeWorld({solid: plate})` —— 它把**平台外也当成空气**，
//   而真服上平台外是**未加载**（blockAt → null）。这个差别直接决定结论对错：
//   旧遍历一旦走出平台，读到"空气"就会一路 march 到 maxSteps=256 并返回 **null（=看得见）**
//   ⇒ 分叉被这个假世界**吃掉**。第一次跑本脚本时就是这个坑：量出"dz≥0.8 零分叉"，
//   而独立复核用"平台外=null"量到"≤1 格必分叉"。**照实建世界**（与 dda_offline_check.mjs 同口径）。
const ARENA_TOP = 204;
function makeArenaWorld() {
    const inArena = (x, y, z) => x >= ARENA.minX && x <= ARENA.maxX && z >= ARENA.minZ && z <= ARENA.maxZ
        && y >= ARENA.floorY && y <= ARENA_TOP;
    return {
        at(x, y, z) {
            const X = Math.floor(x), Y = Math.floor(y), Z = Math.floor(z);
            if (!inArena(X, Y, Z)) return null;                       // 平台外/地板下/头顶以上 = 未加载
            const pos = new Vec3(X, Y, Z);
            // 唯一真值标记（scenarios.mjs ARENA.marker）要先判，否则被地板的 stone 吃掉
            if (X === ARENA.marker[0] && Y === ARENA.marker[1] && Z === ARENA.marker[2]) {
                return { name: 'gold_block', boundingBox: 'block', position: pos };
            }
            if (Y === ARENA.floorY) return { name: 'stone', boundingBox: 'block', position: pos };
            return { name: 'air', boundingBox: 'empty', position: pos };
        },
    };
}
const world = makeArenaWorld;

/** 格序列指纹（"访问了哪些格、按什么顺序"）——比 step 数更有意义：两版步数差一个 0/1 基约定。 */
const cellSeq = (r) => (r.cells ?? []).map((c) => `${c.x},${c.y},${c.z}`).join('>');

/**
 * bot 站在 (8+fx, standY, 8+fz)、creep 在 (cx, standY+dyFeet, cz) 时两套遍历的读数。
 * `dyFeet` 用来扫"creep 眼位与 bot 眼位差多少"——那才是决定分叉与否的量。
 */
function probe(fx, fz, creepX, creepZ, dyFeet = 0) {
    const bot = makeBot({ world: world(), pos: [8 + fx, ARENA.standY, 8 + fz] });
    const creep = makeEntity({ id: 1, name: 'creeper', pos: [creepX, ARENA.standY + dyFeet, creepZ], height: CREEP_HEIGHT });
    const from = LOS.eyeOf(bot), to = LOS.entityEye(creep);
    const fixed = LOS.raycastBlockTrace(bot, from, to, { trace: true });
    const leg = legacyRaycastBlock(bot, from, to);
    const dy = to.y - from.y;
    // y 轴要"被踩到"必须 tMaxY ≤ 1；否则射线在到达终点前根本不换 y 层 ⇒ y 轴那个 bug 不可能发作
    const fracY = from.y - Math.floor(from.y);
    const tMaxYCorrect = dy === 0 ? Infinity : Math.abs(1 / dy) * (dy > 0 ? (Math.floor(from.y) + 1 - from.y) : fracY);
    return {
        from: { x: +from.x.toFixed(4), y: +from.y.toFixed(4), z: +from.z.toFixed(4) },
        to: { x: +to.x.toFixed(4), y: +to.y.toFixed(4), z: +to.z.toFixed(4) },
        dx: +(to.x - from.x).toFixed(4), dy: +dy.toFixed(4), dz: +(to.z - from.z).toFixed(4),
        fixed: fingerprint(fixed), fixedKind: fixed.hitKind, fixedCells: fixed.cells.length,
        legacy: fingerprint(leg), legacyKind: leg.hitKind, legacyCells: leg.cells.length,
        diverge: (fixed.hit === null) !== (leg.hit === null),
        seqDiffer: cellSeq(fixed) !== cellSeq(leg),
        tMaxYCorrect: +tMaxYCorrect.toFixed(4),
    };
}

const line = (s = '') => console.log(s);
line('════════ creeper 组 × DDA 逐轴方向修复：不变性核查（离线）════════');
line(`竞技场（唯一真源，micro/scenarios.mjs:ARENA）：x/z ${ARENA.minX}..${ARENA.maxX}、地板 y=${ARENA.floorY}、站位 y=${ARENA.standY}、中心 (${ARENA.cx}, ${ARENA.cz})`);
line(`眼位（用 los.js 真函数算，不自己估）：bot y=${ARENA.standY}+${EYE_BOT}=${(ARENA.standY + EYE_BOT).toFixed(3)}、creep y=${ARENA.standY}+${EYE_CREEP}=${(ARENA.standY + EYE_CREEP).toFixed(3)}`);
line(`creep 刷怪点（场景命令）：summon minecraft:creeper 8.5 ${ARENA.standY} 20.5\n`);

// ---------------------------------------------------------------- ① 名义几何
line('── ① 名义几何：summon 那一刻（bot 在正中心、creep 正对 12 格外）──');
const nominal = probe(0.5, 0.5, 8.5, 20.5);
line(`  from=[${nominal.from.x}, ${nominal.from.y}, ${nominal.from.z}]  to=[${nominal.to.x}, ${nominal.to.y}, ${nominal.to.z}]`);
line(`  (dx,dy,dz)=(${nominal.dx}, ${nominal.dy}, ${nominal.dz})`);
line(`  修复后：${nominal.fixed.padEnd(28)} kind=${nominal.fixedKind.padEnd(9)} 格数=${nominal.fixedCells}`);
line(`  修复前：${nominal.legacy.padEnd(28)} kind=${nominal.legacyKind.padEnd(9)} 格数=${nominal.legacyCells}`);
line(`  ⇒ 结论${nominal.diverge ? '**相反**' : '**相同**'}，访问格序列${nominal.seqDiffer ? '**不同**' : '**逐格一致**'}`);
line('  为什么必然相同（可复核的一条，不是"试出来没分叉"）：');
line(`   **y 轴在 t=1 之前一步都不会走。** 该几何的 Δy=${nominal.dy}（bot 眼 202.62 vs creep 眼 202.53，`);
line('   两者眼位都用 height×0.9，苦力怕 1.7 比玩家 1.8 矮 0.1 格 ⇒ 眼位只差 0.09）；');
line(`   而"下一条 y 边界"的参数 t = ${nominal.tMaxYCorrect} = 0.62/0.09。**修复前那个"方向取错"的 y tMax`);
line('   在 dx=0 时恰好同值、dx>0 时是 0.38/0.09=4.222 —— 两者都 ≫ 1，一样走不到。**');
line('   ⇒ 射线在 t≤1 的全程里始终停在 y=202 这一层，那个分支根本没有执行的机会。');
line('   ⚠ 顺带更正本单开工时的推导：曾以为"dx=0 纯 z 射线所以不变"。**dx=0 只是充分条件、不是原因**——');
line('     ②a 显示 dz≥0.8 时 100 个小数位置（其中 90 个 dx≠0）全部零分叉；而 dz≲0.7 时连 dx=0 的格子也分叉');
line('     （机制 A）。所以正确的说法是"**水平距离够大时新旧逐格一致**"，与 dx 无关。');
line('');

// ---------------------------------------------------------------- ② 边界扫描
line('── ② 边界扫描：不变性到底在哪里失效（这一节推翻了我自己先写的那版结论）──');
line('   (a) 扫水平距离 dz（creep 在中心线上、bot 扫满 10×10 个格内小数位置）');
const FRACS = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9];
const dzScan = [];
for (let dz = 0.1; dz <= 3.001; dz += 0.1) {
    let n = 0;
    for (const fx of FRACS) for (const fz of FRACS) if (probe(fx, fz, 8.5, ARENA.cz + dz).diverge) n++;
    dzScan.push([+dz.toFixed(1), n]);
}
line('    dz(格) : ' + dzScan.filter(([d]) => d <= 1.2).map(([d]) => d.toFixed(1)).join('  '));
line('    分叉/100: ' + dzScan.filter(([d]) => d <= 1.2).map(([, n]) => String(n).padStart(4)).join('  '));
line('    …');
line('    dz(格) : ' + dzScan.filter(([d]) => d > 1.2).map(([d]) => d.toFixed(1)).join(' '));
line('    分叉/100: ' + dzScan.filter(([d]) => d > 1.2).map(([, n]) => String(n).padStart(4)).join(' '));
const lastAll = [...dzScan].reverse().find(([, n]) => n === 100);
const lastNonZero = [...dzScan].reverse().find(([, n]) => n > 0);
line(`    ⇒ 本扫描形状下：dz ≥ ${(lastNonZero[0] + 0.1).toFixed(1)} 格 **100 个小数位置零分叉**；dz ≤ ${lastAll[0].toFixed(1)} 格 **100 个全分叉**`);
line('    ⚠ 刀口位置**随扫描形状变**：独立复核用另一套扫描（bot 固定偏移、creep 沿方位角逼近）');
line('      量到"首个分叉 = 1−frac_x、≥1.5 格必一致"。两个扫描在**≥1.5 格零分叉**上一致，');
line('      但 0.8 / 1.0 这两个具体数字不要当常数引用——要引就把扫描形状一起引。');

line('\n   (b) 机制归因：分叉来自**两个不同的原因**，别混成一条');
line('      【机制 A｜近身 dz≲0.4：缺 t≤1 收尾】终点格与起点格同格（ez==z0，射线根本不需要跨 z 边界），');
line('        正确实现在 t>1 时按 t∈[0,1] 收尾判通视；修复前**没有这条收尾**，于是继续 march，');
line('        一路撞上 y=200 的地板石 ⇒ 把"贴脸可见"读成"被地板挡住"。这一条**与逐轴方向无关**。');
{
    const r = probe(0.5, 0.5, 8.5, ARENA.cz + 0.3);
    line(`      证据（fx=fz=0.5、dz=0.3）：修复后 ${r.fixedKind}/${r.fixed}（${r.fixedCells} 格）；修复前 ${r.legacyKind}/${r.legacy}（${r.legacyCells} 格）`);
}
line('      【机制 B｜0.5≲dz≲0.7：z 轴 tMax 方向取错】把 z 的"下一格边界"t 算成 fz/|dz| 而不是 (1−fz)/|dz|；');
line('        当这个错值**大于 x 轴的首个 t** 时，遍历会先踩 x 轴；而终点格要求 x 回到 ex==x0，');
line('        x 一旦走出去就永远回不来 ⇒ 终点格永不可达 ⇒ 一路 march 撞地板。同 §4.16.2 的失效模式。');
{
    const r = probe(0.9, 0.9, 8.5, ARENA.cz + 0.6);
    line(`      证据（fx=fz=0.9、dz=0.6）：修复后 ${r.fixedKind}/${r.fixed}（${r.fixedCells} 格）；修复前 ${r.legacyKind}/${r.legacy}（${r.legacyCells} 格）`);
}
line('');

// ---------------------------------------------------------------- ③ 两份 legacy 副本差分
line('── ③ 对照实现自身的差分：两份独立的"修复前副本"必须同判 ──');
line('   （dda_legacy.mjs 是从 git show 02ac320 抄的；scenarios.mjs:legacyRaycast 是第七轮抄的）');
{
    // 两个方向都要覆盖：一份只会返回 visible 的对照实现是**没有信息量**的，
    // 所以必须再取一个"两份都判被挡"的几何，证明差分不是在比同一个常量。
    const cases = [
        ['名义几何 dz=12（应同判 visible）', 0.5, 0.5, 12.0, 'visible'],
        ['贴脸 dz=0.3（应同判被挡/机制A）', 0.5, 0.5, 0.3, 'BLOCKED'],
    ];
    for (const [label, fx, fz, dz, want] of cases) {
        const bot = makeBot({ world: world(), pos: [8 + fx, ARENA.standY, 8 + fz] });
        const creep = makeEntity({ id: 1, name: 'creeper', pos: [8.5, ARENA.standY, 8.5 + dz], height: CREEP_HEIGHT });
        const from = LOS.eyeOf(bot), to = LOS.entityEye(creep);
        const a = legacyRaycastBlock(bot, from, to);
        const b = legacyRaycast(bot, from, to);
        const same = fingerprint(a) === fingerprint(b);
        const wantOk = fingerprint(a).startsWith(want);
        line(`  ${label}`);
        line(`      dda_legacy=${fingerprint(a).padEnd(30)} scenarios=${fingerprint(b).padEnd(30)} ${same ? '两份一致 ✓' : '**两份不一致** ✗'}${wantOk ? '' : ' （与预期不符 ✗）'}`);
        if (!same || !wantOk) process.exitCode = 1;
    }
    line('  ⇒ 两份副本在"同判 visible"与"同判被挡"两种情形下都一致 ⇒ 差分可用（自检 T16 里有钉子）');
}

// ---------------------------------------------------------------- ④ 结构性
line('\n── ④ 结构性：creeper 测量路径的函数体里有没有射线调用 ──');
const RAY_NAMES = ['raycastBlockTrace', 'raycastBlock', 'canSeeEntity', 'hasLineOfSight', 'losMargin', 'pickCover'];
/** 取 `{...}` 块（跳过字符串/模板串/行注释/块注释），起点给定。 */
function braceBlock(src, openIdx) {
    let depth = 0, inStr = null, inLine = false, inBlock = false;
    for (let k = openIdx; k < src.length; k++) {
        const c = src[k], nx = src[k + 1];
        if (inLine) { if (c === '\n') inLine = false; continue; }
        if (inBlock) { if (c === '*' && nx === '/') { inBlock = false; k++; } continue; }
        if (inStr) { if (c === '\\') { k++; continue; } if (c === inStr) inStr = null; continue; }
        if (c === '/' && nx === '/') { inLine = true; k++; continue; }
        if (c === '/' && nx === '*') { inBlock = true; k++; continue; }
        if (c === '"' || c === "'" || c === '`') { inStr = c; continue; }
        if (c === '{') depth++;
        else if (c === '}' && --depth === 0) return src.slice(openIdx, k + 1);
    }
    return null;
}
const DEF = path.join(TASK_LAYER, 'src/agent/tasks/exec/defense');
const PATH_FN = [
    ['responses.js', ['decideCreeper', 'pickFleeSpot', 'groundSafe', 'standable', 'openSky', 'safeName']],
    ['melee_tick.js', ['bestWeapon', 'hasWeapon', 'isEntityGone']],
    ['threat_table.js', ['creeperFusingNow', 'creeperFusingMeta']],
    ['los.js', ['isSolid', 'blocksSight']],
];
let structuralFail = 0;
for (const [file, fns] of PATH_FN) {
    const src = fs.readFileSync(path.join(DEF, file), 'utf8');
    for (const fn of fns) {
        const m = new RegExp(`(?:export\\s+)?function\\s+${fn}\\s*\\(`).exec(src);
        if (!m) { line(`  ${file}:${fn}  **函数没找到**（提取失败，不能当成"干净"）`); structuralFail++; continue; }
        const body = braceBlock(src, src.indexOf('{', m.index));
        const hit = RAY_NAMES.filter((n) => body.includes(n));
        if (hit.length) { line(`  ${file}:${fn}  ✗ 调用了 ${hit.join(',')}`); structuralFail++; }
        else line(`  ${file}:${fn}  ✓ 无射线调用`);
    }
}
{
    const src = fs.readFileSync(path.join(BENCH, 'micro/scenarios.mjs'), 'utf8');
    const i = src.indexOf('    creeper: {');
    const body = i < 0 ? null : braceBlock(src, src.indexOf('{', i));
    const hit = body ? RAY_NAMES.filter((n) => body.includes(n)) : ['<场景块未找到>'];
    line(`  micro/scenarios.mjs:SCENARIOS.creeper  ${hit.length && hit[0] !== '<场景块未找到>' ? `✗ ${hit.join(',')}` : (body ? '✓ 无射线调用' : '**场景块未找到**')}`);
    if (hit.length && hit[0] !== '<场景块未找到>') structuralFail++;
}
line(`\n  ⇒ 结构性结论：${structuralFail === 0 ? 'creeper 测量路径**一次都没调用 LOS 射线** ⇒ DDA 修复结构上不可能改变该组读数' : `**有 ${structuralFail} 处需人工看**（不要当成通过）`}`);
line('  ⚠ 这条是**静态**检查：它能抓住"在已枚举的这些函数里加了一行 canSeeEntity"，');
line('    抓不住"新加了一个我没枚举到的中间函数、它里面调了射线"。所以它必须和 ①② 一起读，');
line('    不能单独当作"该组与 LOS 无关"的证明。');
line('');

// ---------------------------------------------------------------- 结论
line('════════ 口径结论 ════════');
line('1. creeper 组与 DDA 逐轴方向修复**无因果关系**，两条独立通道指向同一结论：');
line('   ① 该组测量路径**一次都不调用 LOS 射线**（④，静态枚举 + 场景块扫描）—— 这条是主证，');
line('      因为它不依赖任何具体几何；');
line('   ② 即便去测：**水平距离 ≥0.8 格时新旧遍历逐格一致**（②a，dz 从 0.8 到 3.0 每 0.1 扫、');
line('      每个距离再扫 10×10 个格内小数位置，全零分叉）。');
line('   ⇒ **n≥30 的 creeper 数据可以和修复前的 creeper 数据并排比**，DDA 修复不是混淆项。');
line('2. 不变性的**边界（必须一起说，否则第 1 条会被当成"LOS 与苦力怕无关"）**：');
line('   · dz ≤ 0.4：**100/100 全分叉**，机制是修复前**缺 t∈[0,1] 收尾**（机制 A）；');
line('   · 0.5 ≤ dz ≤ 0.7：少数格子分叉，机制是 z 轴 tMax 方向取错（机制 B）；');
line('   · dz ≥ 0.8：零分叉（另一套独立扫描形状给的是 ≥1.5；≥1.5 两边一致）。');
line('   ⇒ **"贴脸 1 格以内"是真会翻的**。苦力怕在 3 格内起爆、真打起来会贴到 1 格内，');
line('     所以在**生产**里这条修复对苦力怕仍然有意义——只是它进不了本组的读数（因为本组不调 LOS）。');
line('3. 独立复核另外挖出**两条与逐轴方向无关的语义差异**（本组同样进不了，但跨区块/贴边调用要当心）：');
line('   · 修复前**终点格为 null 时返回 null（＝"看得见"）**，修复后返回 `unloaded`（＝"看不见"）。');
line('     这是收尾语义的变更，跨区块边缘的调用会变。');
line('   · 修复前用严格 `<`、修复后用 `<=`：bot 恰站在格边界（frac=0）时旧 tMax 恰为 0，');
line('     并列裁决方向相反 ⇒ bot 站在"格边界正上方"这一类位置行为不同。');
line('4. 三条不能推广：');
line('   · 不能推广成"苦力怕处置与 LOS 无关"——生产 DefenseLayer 对每只敌对实体都算视线；');
line('   · 不能推广到别的地形——上面所有零分叉都建立在"平台内、只有 y=200 一层地板、');
line('     且 201..204 全空气"这个空旷竞技场上；真实地形里"误访的格恰好是实心"很容易成立；');
line('   · 不能推广到 skeleton/melee 两组——它们本来就直接走 LOS 判据。');
line('5. creep 的 x 在真服上是否恒为 8.5：**INCONCLUSIVE（离线不可答）**——那是服务端实体的');
line('   寻路/碰撞箱行为，离线没有实体，不编。要答就用 raydiag 组做同服 A/B。');
line('6. 方法论（本轮最值钱的一条）：① 的结论我是**先按推导写好、打印在扫描结果上面**的，');
line('   扫描一跑就出现"表全零、而我自己的结论说该有 ✗"的自相矛盾。回头重推才发现真因不同，');
line('   而且还多出一个推导里根本没有的机制 A。凡是"结论由推导给出"的扫描表，');
line('   都要让扫描有机会推翻它——否则错的推导会把读者带进下一轮。');
process.exit(process.exitCode ?? 0);
