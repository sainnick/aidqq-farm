// mutation_gaze_los_r8.mjs — MC-M1-TASK-07（G 线，第八轮）：第八轮新增断言的**变异测试**。
//
// 为什么必须做：手册 §5 与 T13/T14 的教训——「断言和被测代码同源错误时，断言是假的绿」。
// 上一轮 T14 补完 9 条之后没有配套做变异（是本轮补的欠账）；本轮 T15/T16 一上手就配上。
//
// 手法：逐个把生产代码**改坏** → 跑离线自检 → 必须出现指定的 FAIL → 还原。
//   ① 「必须红」= 至少有一条 FAIL，且**必须包含我指名的那一条**（不是"随便哪条红"就算过，
//     否则一条无关的红会掩盖这条钉子其实是空转的）。
//   ② 还原必须可靠：用 try/finally，且还原后校验文件内容与原始一致（Windows 上写文件
//     可能带 BOM/换行变化，所以按内容比对而不是按哈希）。
//
// 用法：node bench/stages/basic-survival/analysis/mutation_gaze_los_r8.mjs
//       （纯离线；只改自己 worktree 里的生产文件，且每次都还原）

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BENCH = path.join(HERE, '..');
const DEF = path.resolve(BENCH, '../../../mindcraft-wt/s0-survival/src/agent/tasks/exec/defense');
const SELFTEST = path.join(BENCH, 'selftest_defense.mjs');

/** 变异清单：每一项 = 改坏一处 + 指名必须因此变红的那条用例。 */
const MUTANTS = [
    {
        id: 'M1 阈值退回 10°',
        file: 'threat_table.js',
        from: 'gazeGuardDeg: 15,',
        to: 'gazeGuardDeg: 10,',
        expect: 'T15 常量就是 15°',
    },
    {
        id: 'M2 阈值放大到 30°（守卫变钝，该拦的导航被吞）',
        file: 'threat_table.js',
        from: 'gazeGuardDeg: 15,',
        to: 'gazeGuardDeg: 30,',
        expect: 'T15 阴性：背对末影人',
    },
    {
        id: 'M3 lookVector 的 z 分量反号退回（第七轮修过的那处）',
        file: 'gaze_guard.js',
        from: 'return new Vec3(-Math.sin(yaw) * cp, Math.sin(pitch), -Math.cos(yaw) * cp);',
        to: 'return new Vec3(-Math.sin(yaw) * cp, Math.sin(pitch), Math.cos(yaw) * cp);',
        expect: 'T15 阴性：背对末影人',
    },
    {
        id: 'M4 lookVector 的 y 分量反号退回（抬头被当成低头）',
        file: 'gaze_guard.js',
        from: 'return new Vec3(-Math.sin(yaw) * cp, Math.sin(pitch), -Math.cos(yaw) * cp);',
        to: 'return new Vec3(-Math.sin(yaw) * cp, -Math.sin(pitch), -Math.cos(yaw) * cp);',
        expect: 'T15 阴性：背对末影人',
    },
    {
        id: 'M5 退路俯仰压成 0（=没有退路 ⇒ 闩锁该被抓住）',
        file: 'gaze_guard.js',
        from: 'bot.look(Number.isFinite(yaw) ? yaw : 0, TRAVEL_PITCH_DEG * Math.PI / 180, false)?.catch?.(() => {});',
        to: 'bot.look(Number.isFinite(yaw) ? yaw : 0, 0, false)?.catch?.(() => {});',
        expect: 'T15 闩锁回归锁',
    },
    {
        id: 'M6 去掉 t∈[0,1] 收尾（修复的 ②，机制 A 的来源）',
        file: 'los.js',
        from: 'if (!(tNext <= 1 + 1e-9)) return done(\'past_end\', null);',
        to: 'if (false) return done(\'past_end\', null);',
        expect: 'T16 反向钉子',
    },
    {
        id: 'M7 DDA 逐轴方向退回共用 stepX（修复的 ①，机制 B 的来源）',
        file: 'los.js',
        from: '    if (dx !== 0) tMaxX = tDeltaX * (stepX > 0 ? (x + 1 - from.x) : (from.x - x));\n    if (dy !== 0) tMaxY = tDeltaY * (stepY > 0 ? (y + 1 - from.y) : (from.y - y));\n    if (dz !== 0) tMaxZ = tDeltaZ * (stepZ > 0 ? (z + 1 - from.z) : (from.z - z));',
        to: '    const bound = (c, cell) => (stepX > 0 ? (cell + 1 - c) : (c - cell));\n    if (dx !== 0) tMaxX = tDeltaX * bound(from.x, x);\n    if (dy !== 0) tMaxY = tDeltaY * bound(from.y, y);\n    if (dz !== 0) tMaxZ = tDeltaZ * bound(from.z, z);',
        expect: 'T16 机制 B',
    },
    {
        id: 'M8 并列裁决从 <= 退回 <（bot 站格边界时行为不同）',
        file: 'los.js',
        from: 'if (tMaxX <= tMaxY && tMaxX <= tMaxZ) { tNext = tMaxX; axis = \'x\'; }',
        to: 'if (tMaxX < tMaxY && tMaxX < tMaxZ) { tNext = tMaxX; axis = \'x\'; }',
        // ⚠ 这条**第一版没被抓住**（0 条 FAIL）：T14 只覆盖了 1.4 格那种"非并列"几何，
        //   并列裁决在整个自检里没有钉子。补了 T16「并列裁决的可复现性」才变红。
        //   ——这就是"变异测试自己也会骗人"的同族：不是钉子写错，是**根本没写**。
        expect: 'T16 并列裁决的可复现性',
    },
];

const backup = new Map();
for (const m of MUTANTS) {
    const p = path.join(DEF, m.file);
    if (!backup.has(p)) backup.set(p, fs.readFileSync(p, 'utf8'));
}
const restore = () => { for (const [p, s] of backup) fs.writeFileSync(p, s); };

function runSelftest() {
    const r = spawnSync(process.execPath, [SELFTEST], { encoding: 'utf8', cwd: BENCH, timeout: 180000 });
    return { code: r.status, out: `${r.stdout ?? ''}${r.stderr ?? ''}` };
}

const log = (s = '') => console.log(s);
let pass = 0, fail = 0;
log('════════ 第八轮新增断言的变异测试（改坏 → 必须红 → 还原）════════\n');
try {
    // 基线：不变异时必须全绿，否则下面"红"没有意义
    const base = runSelftest();
    const baseFails = (base.out.match(/^\s+FAIL\s{2}/gm) ?? []).length;
    log(`基线（未变异）：退出码 ${base.code}，FAIL ${baseFails} 条`);
    if (base.code !== 0 || baseFails > 0) {
        log('  ✗ 基线就不干净 —— 变异测试整体无意义，先修基线');
        process.exit(1);
    }
    log('');
    for (const m of MUTANTS) {
        const p = path.join(DEF, m.file);
        const orig = backup.get(p);
        if (!orig.includes(m.from)) {
            log(`  ✗ ${m.id}\n     定位失败：${m.file} 里找不到待改文本（生产代码已变？先更新本清单）`);
            fail++;
            continue;
        }
        fs.writeFileSync(p, orig.replace(m.from, m.to));
        const r = runSelftest();
        restore();
        if (fs.readFileSync(p, 'utf8') !== orig) {
            log(`  ✗ ${m.id}：还原后内容与原始不一致 —— 手工检查 ${m.file}`);
            fail++;
            continue;
        }
        const fails = (r.out.match(/^\s+FAIL\s{2}(.*)$/gm) ?? []).map((s) => s.replace(/^\s+FAIL\s+/, '').trim());
        const named = fails.some((f) => f.startsWith(m.expect));
        const okMut = r.code !== 0 && fails.length > 0 && named;
        log(`  ${okMut ? '✓' : '✗'} ${m.id}`);
        log(`     期望红：${m.expect}　⇒ 实际 ${fails.length} 条 FAIL，${named ? '包含' : '**不包含**'}该条`);
        if (!okMut && fails.length) log(`     实际红的：${fails.slice(0, 4).join(' | ')}`);
        if (okMut) pass++; else fail++;
    }
} finally {
    restore();
}
log(`\n═══ 变异测试：${pass}/${MUTANTS.length} 有效 ═══`);
log(fail ? `✗ ${fail} 个变异没被抓住（要么钉子是空转，要么本清单的定位文本过期）` : '✓ 每个变异都被指名的那条用例抓住');
// 还原后的最终确认：必须回到全绿
const after = runSelftest();
const afterFails = (after.out.match(/^\s+FAIL\s{2}/gm) ?? []).length;
log(`还原后复跑：退出码 ${after.code}，FAIL ${afterFails} 条 ${after.code === 0 && afterFails === 0 ? '✓' : '✗'}`);
process.exit(fail === 0 && after.code === 0 && afterFails === 0 ? 0 : 1);
