// dda_legacy.mjs — MC-M1-TASK-07（G 线，第八轮）：**修复前** `los.js:raycastBlock`
// 的逐行副本，作为"DDA 逐轴方向"这个 bug 的**唯一对照源**。
//
// ⚠⚠ 为什么单独一个模块，而不是谁需要就在自己文件里抄一份：
//   第七轮已经出现过两份"照抄"（`micro/scenarios.mjs:legacyRaycast` 与
//   `analysis/dda_offline_check.mjs:currentWalk`），而 `dda_offline_check.mjs`
//   那一份**与真实修复前代码并不逐行一致**（它用 `tMaxX` 记 t、终点判定顺序不同、
//   没有 `isLoaded` 守卫）⇒ 两份对照实现互相不一致时，谁也发现不了。
//   本文件是**从 `git show 02ac320:src/agent/tasks/exec/defense/los.js` 抄下来的**，
//   唯一的新增是 `hitKind` 记录（不改变任何一条控制流）。
//   自检 T16 里有**差分断言**：`dda_legacy` 必须与 `scenarios.mjs:legacyRaycast`
//   在同一批几何上逐格同判（两份独立副本互为对照，防"我抄错了"）。
//
// —— 被对照的那一行（就是它）——
//   const bound = (c, cell) => (stepX > 0 ? (cell + 1 - c) : (c - cell));
//   let tMaxY = dy === 0 ? Infinity : tDeltaY * bound(from.y, y);   // 方向取的仍是 stepX
//   let tMaxZ = dz === 0 ? Infinity : tDeltaZ * bound(from.z, z);   // 同上
// 只要 dy（或 dz）与 dx **异号**，对应轴 tMax 被算大 ⇒ 遍历留在错误的高度层里走、
// 永远踩不到终点格（终点判定要求三轴同时等于终点格）⇒ 一路走到 maxSteps，
// 中途撞上地板或未加载区块 ⇒ 返回"被遮挡"。

/** 修复前的 `safeBlockAt`（同一个 try/catch 形状）。 */
function safeBlockAt(bot, x, y, z) {
    try { return bot.blockAt({ x, y, z }); } catch { return null; }
}
const blocksSight = (b) => !!b && b.boundingBox === 'block';
const isLoaded = (b) => !!b;

/**
 * 修复前遍历（02ac320 原文 + hitKind 记录）。
 *
 * @param {object} bot 只需 `blockAt({x,y,z}) → {boundingBox}|null`（与 `makeBot` 同形）
 * @returns {{hit:object|null, hitKind:string, steps:number, cells:Array}}
 *   `hit` 与修复前**逐字同义**：被挡返回那一格、通视返回 null。
 *   ⚠ `hitKind` 是本文件新增的记录字段，修复前没有它——
 *     而"为什么它返回 null"正是这次要分清的（endpoint 通视 vs 撞地板 vs 未加载）。
 */
export function legacyRaycastBlock(bot, from, to, opts = {}) {
    const maxSteps = opts.maxSteps ?? 256;
    const cells = [];
    let x = Math.floor(from.x), y = Math.floor(from.y), z = Math.floor(from.z);
    const ex = Math.floor(to.x), ey = Math.floor(to.y), ez = Math.floor(to.z);
    const dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
    if (dx === 0 && dy === 0 && dz === 0) return { hit: null, hitKind: 'degenerate', steps: 0, cells };

    const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
    const tDeltaX = dx === 0 ? Infinity : Math.abs(1 / dx);
    const tDeltaY = dy === 0 ? Infinity : Math.abs(1 / dy);
    const tDeltaZ = dz === 0 ? Infinity : Math.abs(1 / dz);
    // ★★★ 就是这三行：bound 只闭包了 stepX，三根轴共用 ★★★
    const bound = (c, cell) => (stepX > 0 ? (cell + 1 - c) : (c - cell));
    let tMaxX = dx === 0 ? Infinity : tDeltaX * bound(from.x, x);
    let tMaxY = dy === 0 ? Infinity : tDeltaY * bound(from.y, y);
    let tMaxZ = dz === 0 ? Infinity : tDeltaZ * bound(from.z, z);

    let steps = 0;
    for (; steps <= maxSteps; steps++) {
        let axis;
        if (tMaxX < tMaxY && tMaxX < tMaxZ) { x += stepX; tMaxX += tDeltaX; axis = 'x'; }
        else if (tMaxY < tMaxZ) { y += stepY; tMaxY += tDeltaY; axis = 'y'; }
        else { z += stepZ; tMaxZ += tDeltaZ; axis = 'z'; }

        if (steps > maxSteps) return { hit: null, hitKind: 'exhausted', steps, cells };
        if (x === ex && y === ey && z === ez) {
            const endBlock = safeBlockAt(bot, x, y, z);
            cells.push({ x, y, z, axis, t: Number((axis === 'x' ? tMaxX : axis === 'y' ? tMaxY : tMaxZ).toFixed(6)), end: true });
            const blocked = blocksSight(endBlock) && isLoaded(endBlock);
            return { hit: blocked ? { x, y, z, index: steps } : null, hitKind: blocked ? 'endpoint_solid' : 'endpoint', steps, cells };
        }
        const b = safeBlockAt(bot, x, y, z);
        cells.push({ x, y, z, axis, end: false });
        if (b === null) return { hit: { x, y, z, index: steps, unloaded: true }, hitKind: 'unloaded', steps, cells };
        if (blocksSight(b)) return { hit: { x, y, z, index: steps }, hitKind: 'solid', steps, cells };
    }
    return { hit: null, hitKind: 'exhausted', steps, cells };
}

/** 判据同形：hit 非 null = 被遮挡（`los.js:hasLineOfSight` 取 `=== null` 为通视）。 */
export const legacySees = (r) => r.hit === null;

/** 两套遍历的结论指纹（用来做差分断言 / 分叉统计）。 */
export function fingerprint(r) {
    if (r.hit) return `BLOCKED:${r.hitKind}@${r.hit.x},${r.hit.y},${r.hit.z}`;
    return 'visible';
}
