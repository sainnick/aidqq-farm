// dda_offline_check.mjs — MC-M1-TASK-07（G 线，第七轮）：
// `los.js` 的体素 DDA 射线**离线分叉矩阵**——把生产遍历逐行照抄一份，
// 与"正确实现"在同一片合成空地上跑同一批几何，看两者在哪里分叉、分叉成什么。
//
// 用途（两级）：
//   ① 离线：先证明"空旷场地里 1.4 格的目标会被判看不见"**在离线就能复现**（不必烧服务器），
//      并把分叉的充要条件列清（哪类方向/几何会踩）——这一步给修法定向。
//   ② 真服：micro/raydiag 场景用生产代码的 `raycastBlockTrace` 打逐格读数，
//      证明真服上踩的是同一个坑（离线/真服必须对上，否则是另一个问题）。
//
// ⚠ 本文件**不改生产代码**，只做对照；`currentWalk` 必须与 los.js:raycastBlock 的
//   遍历逻辑逐行一致（含 step 顺序、tMax 推进、终点格处理、maxSteps 上限），
//   否则它就不是"生产行为"而是"我以为的生产行为"。

import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));

// ---------------------------------------------------------------- 合成世界
// 复刻 melee 场景的竞技场（scenarios.mjs ARENA）：y=200 石地板，201..204 空气，
// 平台 0..24；**平台外一律 null**（区块未加载）——真实服务器上 blockAt 对未加载格返回 null。
const ARENA = { min: 0, max: 24, floorY: 200, topY: 204 };
const world = new Map();
function blockAt(x, y, z) {
    const k = `${x},${y},${z}`;
    if (world.has(k)) return world.get(k);
    let b;
    if (y === ARENA.floorY) b = { name: 'stone', boundingBox: 'block' };
    else if (y > ARENA.floorY && y <= ARENA.topY) b = { name: 'air', boundingBox: 'empty' };
    else b = null;                                  // 竞技场外 / 地板下 = 未加载
    world.set(k, b);
    return b;
}
const blocksSight = (b) => !!b && b.boundingBox === 'block';

// ------------------------------------------------- 生产遍历（照抄 los.js:32-71）
/** @returns {{hit:object|null, cells:Array, steps:number, hitKind:string|null}} */
function currentWalk(from, to, maxSteps = 256) {
    const cells = [];
    let x = Math.floor(from.x), y = Math.floor(from.y), z = Math.floor(from.z);
    const ex = Math.floor(to.x), ey = Math.floor(to.y), ez = Math.floor(to.z);
    const dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
    if (dx === 0 && dy === 0 && dz === 0) return { hit: null, cells, steps: 0, hitKind: null };
    const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
    const tDeltaX = dx === 0 ? Infinity : Math.abs(1 / dx);
    const tDeltaY = dy === 0 ? Infinity : Math.abs(1 / dy);
    const tDeltaZ = dz === 0 ? Infinity : Math.abs(1 / dz);
    // ⚠⚠ 生产原文：`bound` 闭包的是 **stepX**，三根轴共用 ⇒ y/z 的"到下一格边界"
    //    用了 **x 的方向**。这正是本文件要与 correctWalk 对照的那一处。
    const bound = (c, cell) => (stepX > 0 ? (cell + 1 - c) : (c - cell));
    let tMaxX = dx === 0 ? Infinity : tDeltaX * bound(from.x, x);
    let tMaxY = dy === 0 ? Infinity : tDeltaY * bound(from.y, y);
    let tMaxZ = dz === 0 ? Infinity : tDeltaZ * bound(from.z, z);
    let steps = 0;
    for (; steps <= maxSteps; steps++) {
        let axis;
        if (tMaxX < tMaxY && tMaxX < tMaxZ) { x += stepX; tMaxX += tDeltaX; axis = 'x'; }
        else if (tMaxY < tMaxZ) { y += stepY; tMaxY += tDeltaY; axis = 'y'; }
        else { z += stepZ; tMaxZ += tDeltaZ; axis = 'z'; }
        if (steps > maxSteps) return { hit: null, cells, steps, hitKind: null };
        if (x === ex && y === ey && z === ez) {
            const endBlock = blockAt(x, y, z);
            return {
                hit: blocksSight(endBlock) ? { x, y, z, index: steps } : null,
                cells: cells.concat([{ x, y, z, axis, t: +tMaxX.toFixed(4), end: true, ...desc(x, y, z) }]),
                steps, hitKind: 'endpoint',
            };
        }
        const b = blockAt(x, y, z);
        cells.push({ x, y, z, axis, t: +tMaxX.toFixed(4), end: false, ...desc(x, y, z) });
        if (b === null) return { hit: { x, y, z, index: steps, unloaded: true }, cells, steps, hitKind: 'unloaded' };
        if (blocksSight(b)) return { hit: { x, y, z, index: steps }, cells, steps, hitKind: 'solid' };
    }
    return { hit: null, cells, steps, hitKind: 'exhausted' };
}
function desc(x, y, z) {
    const b = blockAt(x, y, z);
    return { name: b ? b.name : null, bb: b ? b.boundingBox : null, onRay: null };
}

// ------------------------------------------------- 正确实现（逐轴 bound + t>1 收尾）
function correctWalk(from, to, maxSteps = 256) {
    const cells = [];
    let x = Math.floor(from.x), y = Math.floor(from.y), z = Math.floor(from.z);
    const ex = Math.floor(to.x), ey = Math.floor(to.y), ez = Math.floor(to.z);
    const dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
    if (dx === 0 && dy === 0 && dz === 0) return { hit: null, cells, steps: 0, hitKind: null };
    const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
    const tDeltaX = dx === 0 ? Infinity : Math.abs(1 / dx);
    const tDeltaY = dy === 0 ? Infinity : Math.abs(1 / dy);
    const tDeltaZ = dz === 0 ? Infinity : Math.abs(1 / dz);
    // 逐轴：到本轴"下一格边界"的 t。
    // ⚠ 零位移轴必须显式置 Infinity：`Infinity * 0 = NaN`，NaN 会让后面所有比较为 false
    //   ⇒ 遍历会永远挑中某个轴、一路走到 maxSteps（我自己第一版就踩了这个，
    //   与生产代码里 `dx === 0 ? Infinity : …` 的三处守卫是同一个道理）。
    let tMaxX = Infinity, tMaxY = Infinity, tMaxZ = Infinity;
    if (dx !== 0) tMaxX = tDeltaX * (stepX > 0 ? (x + 1 - from.x) : (from.x - x));
    if (dy !== 0) tMaxY = tDeltaY * (stepY > 0 ? (y + 1 - from.y) : (from.y - y));
    if (dz !== 0) tMaxZ = tDeltaZ * (stepZ > 0 ? (z + 1 - from.z) : (from.z - z));
    let t = 0, steps = 0, hit = null, hitKind = null;
    while (steps <= maxSteps) {
        // 取 t 最小轴推进一格
        let tNext = Math.min(tMaxX, tMaxY, tMaxZ);
        let axis = tMaxX <= tMaxY && tMaxX <= tMaxZ ? 'x' : (tMaxY <= tMaxZ ? 'y' : 'z');
        if (tNext > 1 + 1e-9) { hitKind = 'past_end'; break; }   // 射线已越过终点 ⇒ 通视
        t = tNext;
        if (axis === 'x') { x += stepX; tMaxX += tDeltaX; }
        else if (axis === 'y') { y += stepY; tMaxY += tDeltaY; }
        else { z += stepZ; tMaxZ += tDeltaZ; }
        steps++;
        const b = blockAt(x, y, z);
        const isEnd = (x === ex && y === ey && z === ez);
        cells.push({ x, y, z, axis, t: +t.toFixed(4), end: isEnd, ...desc(x, y, z) });
        if (b === null) { hit = { x, y, z, index: steps, unloaded: true }; hitKind = 'unloaded'; break; }
        if (blocksSight(b)) { hit = { x, y, z, index: steps }; hitKind = 'solid'; break; }
        if (isEnd) { hitKind = 'endpoint'; break; }               // 终点格是空气 ⇒ 通视
    }
    return { hit, cells, steps, hitKind };
}

// ---------------------------------------------------------------- 用例
// 上一轮真服实测（MIC_MELEE_N3 trial 1 的无目标诊断遥测）：
//   botEye = [2.26, 203.22, 8.48]、bot 脚下 stone、4 只僵尸 eyeDist = 3.81 / 1.40 / 2.39 / 4.09，
//   4 只全部 isHostile=true 且 canSee=false。
// 僵尸眼位 = feet(y=201) + 1.95*0.9 = 202.755（los.js:entityEye）；水平距离由 eyeDist 反解。
const BOT_EYE = { x: 2.26, y: 203.22, z: 8.48 };
const ZOMBIE_EYE_Y = 201 + 1.95 * 0.9;

function targetAt(eyeDist, azDeg) {
    const dy = ZOMBIE_EYE_Y - BOT_EYE.y;
    const dh = Math.sqrt(Math.max(0, eyeDist * eyeDist - dy * dy));
    const a = azDeg * Math.PI / 180;
    return { x: BOT_EYE.x + dh * Math.cos(a), y: ZOMBIE_EYE_Y, z: BOT_EYE.z + dh * Math.sin(a) };
}

const rows = [];
for (const eyeDist of [1.4, 2.39, 3.81, 4.09]) {
    for (let az = 0; az < 360; az += 15) {
        const to = targetAt(eyeDist, az);
        const cur = currentWalk(BOT_EYE, to);
        const cor = correctWalk(BOT_EYE, to);
        rows.push({
            eyeDist, az,
            curVerdict: cur.hit ? `BLOCKED(${cur.hitKind}@${cur.hit.x},${cur.hit.y},${cur.hit.z})` : 'visible',
            corVerdict: cor.hit ? `BLOCKED(${cor.hitKind}@${cor.hit.x},${cor.hit.y},${cor.hit.z})` : 'visible',
            curSteps: cur.steps, corSteps: cor.steps,
            diverge: (!!cur.hit) !== (!!cor.hit),
        });
    }
}

const div = rows.filter((r) => r.diverge);
const curBlocked = rows.filter((r) => r.curVerdict !== 'visible');
console.log(`用例：bot 眼位 [${BOT_EYE.x}, ${BOT_EYE.y}, ${BOT_EYE.z}]（MIC_MELEE_N3 真服实测值），`
    + `僵尸眼位 y=${ZOMBIE_EYE_Y.toFixed(3)}，眼距 {1.4,2.39,3.81,4.09} × 方位角 0..345°/15° = ${rows.length} 例`);
console.log(`合成世界：y=200 stone、y=201..204 air（0..24 平台内），平台外与地板下 = null（未加载）\n`);
console.log('分叉统计：');
console.log(`  生产遍历判"看不见"：${curBlocked.length}/${rows.length} 例`);
console.log(`  正确遍历判"看不见"：${rows.filter((r) => r.corVerdict !== 'visible').length}/${rows.length} 例`);
console.log(`  **两者结论不一致：${div.length}/${rows.length} 例**\n`);
console.log('按眼距分组的分叉：');
for (const d of [1.4, 2.39, 3.81, 4.09]) {
    const g = div.filter((r) => r.eyeDist === d);
    const gAll = rows.filter((r) => r.eyeDist === d);
    console.log(`  eyeDist=${d}：分叉 ${g.length}/${gAll.length} 例  方位角 ${g.map((r) => r.az).join(',') || '(无)'}`);
}
console.log('\n1.4 格的全部方位角明细（生产 vs 正确）：');
for (const r of rows.filter((x) => x.eyeDist === 1.4)) {
    console.log(`  az=${String(r.az).padStart(3)}°  生产 ${r.curVerdict.padEnd(34)} steps=${String(r.curSteps).padStart(3)}`
        + `   正确 ${r.corVerdict.padEnd(14)} steps=${String(r.corSteps).padStart(3)} ${r.diverge ? '  ← 分叉' : ''}`);
}
console.log('\n一个具体分叉例的逐格读数（az=0°, eyeDist=1.4）：');
const demo = currentWalk(BOT_EYE, targetAt(1.4, 0));
const demoOk = correctWalk(BOT_EYE, targetAt(1.4, 0));
console.log(`  from=[${BOT_EYE.x}, ${BOT_EYE.y}, ${BOT_EYE.z}] to=[${targetAt(1.4, 0).x.toFixed(3)}, ${ZOMBIE_EYE_Y.toFixed(3)}, ${targetAt(1.4, 0).z.toFixed(3)}] 终点格=[${Math.floor(targetAt(1.4, 0).x)},${Math.floor(ZOMBIE_EYE_Y)},${Math.floor(targetAt(1.4, 0).z)}]`);
console.log(`  生产遍历（steps=${demo.steps}, hit=${demo.hitKind}）：`);
for (const c of demo.cells.slice(0, 12)) console.log(`    ${c.axis} → (${c.x},${c.y},${c.z}) ${c.name ?? 'NULL(未加载)'} bb=${c.bb ?? '-'} t=${c.t}`);
if (demo.cells.length > 12) console.log(`    …共 ${demo.cells.length} 格`);
console.log(`  正确遍历（steps=${demoOk.steps}, hit=${demoOk.hitKind}）：`);
for (const c of demoOk.cells) console.log(`    ${c.axis} → (${c.x},${c.y},${c.z}) ${c.name ?? 'NULL(未加载)'} bb=${c.bb ?? '-'} t=${c.t}`);

process.exit(0);
