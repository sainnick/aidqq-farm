// summarize.mjs — MC-M1-TASK-07（G 线）BASIC-survival 汇总（设计 §5.2 指标 / §5.3 验收线）
//
// 用法：node summarize.mjs --stamp S0_2026... [--runs runs]
//
// 读三样东西（手册 §5 归因纪律：结论必须能指到原始数据）：
//   1. runs/<stamp>/summary.jsonl          —— runner 每局一行
//   2. runs/<stamp>/trial-*/result.json    —— 任务层终态 + defense 统计 + deathLog
//   3. runs/<stamp>/trial-*/server.log     —— **服务端死亡行**（死因的权威来源；
//      客户端只知道自己死了，不知道是谁杀的）
//
// 六个指标（设计 §5.2）与验收线（§5.3）逐条对照输出；时间指标按**全部 trial** 算
// （失败局记预算值——手册 §5 口径，不只算成功局）。

import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}
const STAMP = arg('stamp', '');
if (!STAMP) { console.error('用法：node summarize.mjs --stamp <stamp>'); process.exit(1); }
const RUNS = path.join(BENCH_DIR, arg('runs', 'runs'));
const RUN_DIR = path.join(RUNS, STAMP);
const WINDOW_MS = 1200000;   // 失败局的预算值（20 分钟窗口）

// —— 验收线（设计 §5.3）——
const LINES = {
    deathRate: { max: 0.10, label: '死亡率 ≤10%（2/20）', hard: false },
    completion: { min: 0.60, label: '完成率 ≥60%', hard: false },
    recovery: { min: 0.70, label: '恢复成功率 ≥70%（打断局内）', hard: false },
    stuck: { max: 0, label: '误判卡死 = 0', hard: true },
    interruptsMedian: { max: 6, label: '每局打断次数中位 ≤6', hard: false },
    creeperDeaths: { max: 1, label: '苦力怕相关死亡 ≤1', hard: false },
};

// —— 死因分桶（1.16.1 服务端死亡行）——
const DEATH_PATTERNS = [
    [/(was blown up by|blew up by) Creeper|Creeper.*(blew up|explod)/i, 'creeper'],
    [/tried to swim in lava/i, 'lava'],
    [/fell from a high place|didnt survive the fall/i, 'fall'],
    [/drowned/i, 'drown'],
    [/was shot by Skeleton|Skeleton.*shoot/i, 'skeleton'],
    [/(was slain by|was killed by|was slain after|was doomed by) Zombie/i, 'zombie'],
    [/(was slain by|was killed by|was doomed by) (Spider|Drowned|Enderman|Slime|Witch|Silverfish|CaveSpider|Blaze|Piglin|Zombified)/i, 'other_mob'],
    [/went up in flames|burned to death|was burnt|was burned/i, 'fire'],
    [/fell out of the world|didnt survive/i, 'void'],
    [/was slain by|was killed by|drowned|fell|burned|blew up/i, 'other'],
];

/** 从 server.log 抽死亡行。**只认带玩家名的行**（`X was slain by …`），避免把
 *  "X tried to swim in lava" 之类的模板行与无关的 kill 消息混进来。 */
function deathCauses(serverLogPath) {
    let text = '';
    try { text = fs.readFileSync(serverLogPath, 'utf8'); } catch { return { causes: [], lines: [] }; }
    const lines = text.split(/\r?\n/).filter((l) => /:\s+\[[^\]]+\]/.test(l) || /\]:/.test(l));
    const out = [];
    for (const l of lines) {
        const m = l.match(/(?:was slain by|was killed by|was slain after|was doomed by|tried to swim in lava|fell from a high place|drowned|went up in flames|burned to death|fell out of the world|didnt survive the fall)/i);
        if (!m) continue;
        for (const [re, cause] of DEATH_PATTERNS) {
            if (re.test(l)) { out.push({ cause, line: l.trim().slice(0, 200) }); break; }
        }
    }
    return { causes: out, lines: lines.slice(-3) };
}

/** 读任务层遥测（坏行跳过，不因单行截断废掉整份）。 */
function readTelemetry(p) {
    let text = '';
    try { text = fs.readFileSync(p, 'utf8'); } catch { return []; }
    const out = [];
    for (const l of text.split(/\r?\n/)) {
        if (!l.trim()) continue;
        try { out.push(JSON.parse(l)); } catch { /* 截断行 */ }
    }
    return out;
}

/**
 * 把 defense_begin / defense_end 按 round 配对 —— 裁决 4 要的「每次防御多少 ms」。
 * 遥测是**先 begin 后 end**（end 在 finally 里发），所以用 Map 按 round 存最省事；
 * 配不上的 begin（进程被硬杀）也要显示出来，不能悄悄少一轮。
 */
function pairDefenseRounds(tele) {
    const byRound = new Map();
    for (const e of tele) {
        if (e.event === 'defense_begin') {
            byRound.set(e.round, { round: e.round, threat: e.threat, dist: e.dist, level: e.level, beginT: e.t, ms: null, status: null, actions: null });
        } else if (e.event === 'defense_end') {
            const r = byRound.get(e.round) ?? { round: e.round, threat: e.threat, ms: null, status: null, actions: null };
            r.ms = e.ms; r.status = e.status; r.actions = e.actions; r.failReason = e.failReason;
            byRound.set(e.round, r);
        }
    }
    return [...byRound.values()].sort((a, b) => a.round - b.round);
}

function median(arr) {
    if (!arr.length) return null;
    const s = [...arr].sort((a, b) => a - b);
    const m = s.length >> 1;
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}
function p90(arr) {
    if (!arr.length) return null;
    const s = [...arr].sort((a, b) => a - b);
    return s[Math.min(s.length - 1, Math.floor(s.length * 0.9))];
}
const pct = (x) => (x == null ? 'n/a' : `${(x * 100).toFixed(0)}%`);

// —— 收集 ——
const summaryPath = path.join(RUN_DIR, 'summary.jsonl');
if (!fs.existsSync(summaryPath)) { console.error(`找不到 ${summaryPath}`); process.exit(1); }
const rows = fs.readFileSync(summaryPath, 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l));

const trials = [];
for (const row of rows) {
    // runner 的 summary 行**没有 runDir**，但把整份 result 内联在 row.result 里（权威且免去
    // 猜目录名）。目录名两种写法都见过（trial_01 / trial-01），所以磁盘兜底两种都试。
    const cands = [
        row.runDir,
        path.join(RUN_DIR, `trial_${String(row.trial).padStart(2, '0')}`),
        path.join(RUN_DIR, `trial-${String(row.trial).padStart(2, '0')}`),
    ].filter(Boolean);
    const runDir = cands.find((d) => fs.existsSync(path.join(d, 'result.json'))) ?? cands[0];
    let result = row.result ?? null;
    if (!result) {
        try { result = JSON.parse(fs.readFileSync(path.join(runDir, 'result.json'), 'utf8')); } catch { /* 无 result = 硬超时/未跑完 */ }
    }
    if (!result) console.error(`⚠ trial ${row.trial}：拿不到 result（${runDir}），该局按预算值计`);
    const { causes, lines } = deathCauses(path.join(runDir, 'server.log'));
    // 形状自检：deathCauses 返回 {causes: [...], lines: [...]}，解构后 causes **就是数组**。
    // （第一版写的是 `causes.causes.length` —— 脚本从没在真数据上跑过，第一次跑就炸在这。
    //   手册 §5「先证伪工具，再证伪世界」这条对**自己写的工具**同样成立。）
    if (!Array.isArray(causes)) throw new Error(`deathCauses 形状变了：causes=${typeof causes}（期望数组）`);
    const def = result?.defense ?? null;
    const metrics = result?.metrics ?? {};
    const tele = readTelemetry(path.join(runDir, 'telemetry.jsonl'));
    trials.push({
        trial: row.trial, seed: row.seed, lane: row.lane ?? null,
        outcome: row.outcome ?? result?.status ?? 'NO_RESULT',
        success: (result?.status ?? row.outcome) === 'SUCCESS',
        durationMs: result?.durationMs ?? WINDOW_MS,
        ok: row.ok ?? null,
        wallMs: row.wallMs ?? null,
        earlyStop: row.earlyStop ?? null,
        interrupts: def?.interrupts ?? metrics.defenseInterrupts ?? 0,
        interruptsByType: def?.byType ?? {},
        emergencyTriggers: def?.emergencyTriggers ?? 0,
        healthTriggers: def?.healthTriggers ?? 0,
        stuckViolations: metrics.defenseStuckViolations ?? 0,
        defenseActions: metrics.defenseActions ?? 0,
        frozenSamples: metrics.defenseFrozenSamples ?? 0,
        // —— 裁决 4 指定的四项遥测 ——
        defenseSpentMs: result?.defenseSpentMs ?? 0,
        defenseBudgetExhausted: !!result?.defenseBudgetExhausted,
        gazeInstalled: def?.gazeGuardInstalled ?? false,
        gazeRejects: def?.gazeRejects ?? 0,
        gazeRejectEvents: tele.filter((e) => e.event === 'gaze_guard_reject').length,
        defenseRounds: pairDefenseRounds(tele),
        throttle: tele.some((e) => e.event === 'defense_throttle'),
        budgetExhaustedEvents: tele.filter((e) => e.event === 'defense_budget_exhausted').length,
        afterBudgetObserved: tele.filter((e) => e.event === 'defense_threat_after_budget').length,
        deaths: causes.length,
        deathCauses: causes.map((c) => c.cause),
        deathLines: causes.map((c) => c.line),
        tail: lines,
    });
}

// —— 指标 ——
const n = trials.length;
const successes = trials.filter((t) => t.success);
const deaths = trials.filter((t) => t.deaths > 0);
const interrupted = trials.filter((t) => t.interrupts > 0);
const recovered = interrupted.filter((t) => t.success);
const stuckTotal = trials.reduce((a, t) => a + t.stuckViolations, 0);
const allByType = {};
for (const t of trials) for (const [k, v] of Object.entries(t.interruptsByType)) allByType[k] = (allByType[k] ?? 0) + v;
const causeDist = {};
for (const t of trials) for (const c of t.deathCauses) causeDist[c] = (causeDist[c] ?? 0) + 1;
const durations = trials.map((t) => t.durationMs / 1000);

const metrics = {
    '完成率': { v: successes.length / n, line: LINES.completion, pass: successes.length / n >= LINES.completion.min },
    '死亡率': { v: deaths.length / n, line: LINES.deathRate, pass: deaths.length / n <= LINES.deathRate.max },
    '恢复成功率（打断局内）': {
        v: interrupted.length ? recovered.length / interrupted.length : null,
        line: LINES.recovery,
        pass: interrupted.length ? recovered.length / interrupted.length >= LINES.recovery.min : null,
    },
    '误判卡死（硬线）': { v: stuckTotal, line: LINES.stuck, pass: stuckTotal <= LINES.stuck.max },
    '每局打断次数中位': { v: median(trials.map((t) => t.interrupts)), line: LINES.interruptsMedian, pass: (median(trials.map((t) => t.interrupts)) ?? 0) <= LINES.interruptsMedian.max },
    '苦力怕相关死亡': { v: causeDist.creeper ?? 0, line: LINES.creeperDeaths, pass: (causeDist.creeper ?? 0) <= LINES.creeperDeaths.max },
};

console.log(`\n═══ BASIC-survival 汇总（${STAMP}）═══`);
console.log(`trials=${n}  SUCCESS=${successes.length}  有死亡的局=${deaths.length}  被打断的局=${interrupted.length}\n`);
console.log('── 验收线对照 ──');
for (const [k, m] of Object.entries(metrics)) {
    const val = m.v == null ? 'n/a' : (typeof m.v === 'number' && m.v <= 1 && k.includes('率') ? pct(m.v) : m.v);
    const mark = m.pass == null ? '  ? ' : (m.pass ? ' ✅' : (m.line.hard ? ' ⛔' : ' ❌'));
    console.log(`${mark} ${k.padEnd(22)} = ${String(val).padEnd(6)}  （${m.line.label}）`);
}
const hardOk = Object.values(metrics).every((m) => m.pass !== false || !m.line.hard);
console.log(`\n硬线（误判卡死=0）：${hardOk ? '达标' : '未达标 —— 按任务单第 1 次就提前收手'}`);

console.log('\n── 用时（全部 trial 口径，失败局记预算 1200s）──');
console.log(`median=${median(durations)?.toFixed(1)}s   P90=${p90(durations)?.toFixed(1)}s   max=${Math.max(...durations).toFixed(1)}s`);
console.log(`成功局用时 median=${median(successes.map((t) => t.durationMs / 1000))?.toFixed(1)}s（旁边对照，非验收口径）`);

console.log('\n── 死因分布（服务端 server.log 死亡行）──');
if (!Object.keys(causeDist).length) console.log('（无死亡）');
for (const [k, v] of Object.entries(causeDist).sort((a, b) => b[1] - a[1])) console.log(`  ${k.padEnd(12)} ${v}`);

console.log('\n── 打断（威胁类型分布）──');
if (!Object.keys(allByType).length) console.log('（无打断）');
for (const [k, v] of Object.entries(allByType).sort((a, b) => b[1] - a[1])) console.log(`  ${k.padEnd(12)} ${v}`);
console.log(`  EMERGENCY 触发 ${trials.reduce((a, t) => a + t.emergencyTriggers, 0)} 次；掉血即时触发 ${trials.reduce((a, t) => a + t.healthTriggers, 0)} 次`);

console.log('\n── 逐局表 ──');
console.log(['trial', 'seed', 'lane', 'outcome', 'dur(s)', '中断', '动作', '冻结采样', '卡死违规', '守卫装', '守卫拒', '死因'].join('\t'));
for (const t of trials) {
    console.log([t.trial, t.seed, t.lane ?? '-', t.outcome, (t.durationMs / 1000).toFixed(0),
        t.interrupts, t.defenseActions, t.frozenSamples, t.stuckViolations,
        t.gazeInstalled ? 'Y' : 'n', t.gazeRejects, t.deathCauses.join(',') || '-'].join('\t'));
}

// —— 裁决 4 点名的四项：单局/多局都直接答 ——
console.log('\n── 防御轮明细（裁决 4 指定）──');
const allRounds = trials.flatMap((t) => t.defenseRounds.map((r) => ({ ...r, trial: t.trial })));
if (!allRounds.length) console.log('（无防御轮）');
else {
    console.log(['trial', 'round', 'threat', 'dist', 'status', 'ms', 'actions'].join('\t'));
    for (const r of allRounds) {
        console.log([r.trial, r.round, r.threat ?? '-', r.dist ?? '-', r.status ?? 'UNTERMINATED', r.ms ?? '-', r.actions ?? '-'].join('\t'));
    }
    const msList = allRounds.map((r) => r.ms).filter((x) => typeof x === 'number');
    console.log(`每轮 ms: n=${msList.length} median=${median(msList)} max=${Math.max(...msList)}`);
}
console.log('\n── 裁决 4 四项 ──');
for (const t of trials) {
    console.log(`trial ${t.trial}:`);
    console.log(`  ① defense_begin/end = ${t.defenseRounds.length} 轮，每轮 ms 见上表；防御总墙钟 ${t.defenseSpentMs}ms`);
    console.log(`  ② defenseStuckViolations = ${t.stuckViolations}  ${t.stuckViolations === 0 ? '✅ 硬线' : '⛔ 硬线未达标'}`);
    console.log(`  ③ 视线守卫：${t.gazeInstalled ? '已装' : '未装'}，拒绝 ${t.gazeRejects} 次（gaze_guard_reject 事件 ${t.gazeRejectEvents} 条）`);
    console.log(`  ④ 主任务：${t.outcome} ${t.success ? '✅ 完成' : '❌ 未完成'}${t.failReason ? ` (${t.failReason})` : ''}，用时 ${(t.durationMs / 1000).toFixed(1)}s`);
    if (t.budgetExhaustedEvents) console.log(`  ⚠ defense_budget_exhausted ×${t.budgetExhaustedEvents}，其后只记威胁 ${t.afterBudgetObserved} 次`);
    if (t.throttle) console.log(`  ⚠ defense_throttle（撞到 maxInterrupts）`);
}

const out = {
    stamp: STAMP, trials: n, successes: successes.length,
    completionRate: successes.length / n, deathRate: deaths.length / n,
    recoveryRate: interrupted.length ? recovered.length / interrupted.length : null,
    stuckViolations: stuckTotal, interruptsMedian: median(trials.map((t) => t.interrupts)),
    creeperDeaths: causeDist.creeper ?? 0,
    medianS: median(durations), p90S: p90(durations),
    deathCauseDist: causeDist, interruptsByType: allByType,
    hardLineOk: hardOk, trials_: trials,
    defenseRounds: allRounds,
    defenseSpentMs: trials.reduce((a, t) => a + t.defenseSpentMs, 0),
    stuckViolationsTotal: stuckTotal,
    gazeRejectsTotal: trials.reduce((a, t) => a + t.gazeRejects, 0),
};
fs.writeFileSync(path.join(RUN_DIR, 'report.json'), JSON.stringify(out, null, 2));
console.log(`\n落盘：${path.join(RUN_DIR, 'report.json')}`);
