// wait_lane.mjs — G 线借泳道前的有界等待（一次性工具，不属于 bench 交付物）
// 判据：端口空闲 **且** 该泳道的线锁不是 live（= 持有者真的释放了，不只是"两局之间"）。
// 用法：node wait_lane.mjs --max-s 600 --prefer B,A,C
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const MAX_S = parseInt(arg('max-s', '600'), 10);
const PREFER = String(arg('prefer', 'B,A,C')).split(',').map((s) => s.trim().toUpperCase());
const BASE = 25566, BASE_RCON = 25576;
const NAMES = ['A', 'B', 'C', 'D', 'E'];
const LOCK = path.join('D:/AI斗蛐蛐/experiments/mc1161-gate/.line-locks');

function portBusy(port) {
    try {
        const out = execFileSync('netstat', ['-ano'], { encoding: 'utf8', maxBuffer: 1 << 24 });
        return out.split(/\r?\n/).some((l) => new RegExp(`[:.]${port}\\s+\\S+\\s+LISTENING`).test(l));
    } catch { return true; }   // 查不到就当忙，宁可不借
}
function lockLive(line) {
    const f = path.join(LOCK, `${line}.json`);
    let rec = null;
    try { rec = JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; }   // 没锁文件 = 没人持
    if (!rec) return null;
    if (!rec.live) return { ...rec, live: false };
    // live 但 pid 已死 ⇒ 陈旧锁，可借（手册：允许接管陈旧锁，但这里我们不接管，只是判可用）
    let alive = false;
    try { process.kill(rec.pid, 0); alive = true; } catch { alive = false; }
    if (!alive) return { ...rec, live: false, stale: true };
    const ageS = (Date.now() - new Date(rec.at ?? rec.startedAt ?? 0).getTime()) / 1000;
    return { ...rec, live: true, ageS: Math.round(ageS) };
}

const t0 = Date.now();
let n = 0;
for (;;) {
    n++;
    const state = PREFER.map((L) => {
        const idx = NAMES.indexOf(L);
        const lock = lockLive(L);
        return {
            lane: L, port: BASE + idx,
            portBusy: portBusy(BASE + idx),
            lockWho: lock?.who ?? null, lockLive: lock?.live ?? false, lockAgeS: lock?.ageS ?? null,
        };
    });
    const free = state.find((s) => !s.portBusy && !s.lockLive);
    console.log(`[${Math.round((Date.now() - t0) / 1000)}s #${n}] ` +
        state.map((s) => `${s.lane}:${s.portBusy ? 'port占用' : 'port空'}/${s.lockLive ? `锁活(${s.lockWho},${s.lockAgeS}s)` : (s.lockWho ? '锁陈旧' : '无锁')}`).join('  '));
    if (free) { console.log(`FREE_LANE=${free.lane}`); process.exit(0); }
    if ((Date.now() - t0) / 1000 > MAX_S) { console.log('TIMEOUT_NO_LANE'); process.exit(2); }
    await new Promise((r) => setTimeout(r, 15000));
}
