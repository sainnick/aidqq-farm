// run_bench.mjs — MC-M1-TASK-07（G 线）BASIC-survival benchmark runner
//
// 协议（设计 §5.1/§5.3 + 验收协议 v3）：
//   开发面板   --trials 5 --lanes N              （固定 5 个种子，最多 3 次迭代）
//   正式矩阵   --trials 20 --lanes N             （零 kit，只跑一次，失败预算提前收手）
//   回归       --trials 20（BASIC-bootstrap M4B4 对照）/ --defense 0
//
// 与其他 stage 的三处差别：
//   1. **难度 easy**：模板 server.properties 里 difficulty=easy，并用控制台 /difficulty easy 双保险。
//      不改共享模板（experiments/mc1161-gate/server-1161 是别的线也在用的）——
//      每次 run 在自己的 runs/<stamp>/.server/ 下物化一份模板，泳道 A 用它、泳道 B/C 由
//      runner_core 派生出 .server_laneB / .server_laneC。完全自包含。
//   2. **起始时刻 12500**：走 runner_core 唯一的 stdin 控制台通道（injectKit 的 exec 通道），
//      **不是 RCON**（手册 §2：RCON 会毒化服务进程；任务单也点名改走控制台）。
//      只发 exec、不发任何 give ⇒ 仍是零 kit；kit_done.json 同时当"世界与时间就绪"的栅栏。
//   3. **no-progress-s 放宽到 200s**：夜间作业 + 战斗天然有长静默段（下挖/熔炼/防御走位）。
//      runner 的无进展守卫签名是 {inv,pos,digging,furnace,tree}，防御期间靠任务树出现
//      Defense 节点保活；200s 是"能等到黎明"与"真卡死仍会被判负"之间的折中。
//
// 参数：--lanes/--seeds/--seed-prefix/--trials/--start/--target/--timeout-ms/--stamp
//       --mc-version/--no-progress-s/--fail-budget/--min-free-mb/--server-xmx
//       --defense 0|1（0 = 关防御层，跑回归基线用）
//       --dev（开发面板预设：5 局、dusk 起步、带 kit 宽限）
// 环境变量：TASK_LAYER_DIR（任务层路径，默认 G 线 worktree）
//           MC_BENCH_JAR / MC_BENCH_JAVA / MC_BENCH_SERVER

import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import { argOf, runMatrix, parseFailBudget, parseLanes } from '../_lib/runner_core.mjs';
import { SCENARIOS } from './micro/scenarios.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
// —— 微基准 vs 矩阵：两种执行体，两种 kit 通道 ——
//   --scenario <creeper|melee|skeleton|gaze> ⇒ 走 micro/micro_defense.mjs（开发期，允许 kit+op 造场景）
//   不给 ⇒ 走 exec_bot.mjs（正式矩阵，零 kit、不给 op）
const SCENARIO = argOf(process.argv, 'scenario', '');
if (SCENARIO && !SCENARIOS[SCENARIO]) {
    console.error(`未知场景 "${SCENARIO}"（可用：${Object.keys(SCENARIOS).join(' / ')}）`);
    process.exit(1);
}
const SRC_SERVER = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
// ⚠ 便携 JDK11 的真实路径**带一层版本目录**（jdk/jdk-11.0.32.1+1/bin/java.exe）。
//   第一版写成 jdk/bin/java.exe ⇒ spawn ENOENT，整局在起服那一步就废了（09:06:22 实测）。
//   仍可用 MC_BENCH_JAVA 覆盖；改这里之前先 Test-Path 一下。
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR = process.env.MC_BENCH_JAR || path.join(SRC_SERVER, 'server-1.16.1.jar');
const MC_VERSION = argOf(process.argv, 'mc-version', '1.16.1');
const TASK_LAYER = process.env.TASK_LAYER_DIR || path.join(ROOT, 'mindcraft-wt/s0-survival');

const TRIALS = parseInt(argOf(process.argv, 'trials', '20'), 10);
const START = parseInt(argOf(process.argv, 'start', '1'), 10);
const TARGET = argOf(process.argv, 'target', '1');
const RUNSTAMP = argOf(process.argv, 'stamp', `S0_${new Date().toISOString().slice(0, 13).replace(/[-T:]/g, '')}`);
const SEED_PREFIX = argOf(process.argv, 'seed-prefix', RUNSTAMP);
const SEED_LITERAL = argOf(process.argv, 'seed', '');
const SEED_LIST = argOf(process.argv, 'seeds', '');
const LANES = parseInt(argOf(process.argv, 'lanes', '1'), 10);
const LANE_NAMES = parseLanes(process.argv);
const NO_PROGRESS_S = parseInt(argOf(process.argv, 'no-progress-s', '200'), 10);
const FAIL_BUDGET = parseFailBudget(argOf(process.argv, 'fail-budget', ''));
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const SERVER_XMX = argOf(process.argv, 'server-xmx', '1G');
const PROBE_MS = parseInt(argOf(process.argv, 'probe-ms', '5000'), 10);
const TIMEOUT_MS = parseInt(argOf(process.argv, 'timeout-ms', '1260000'), 10);  // 21 分钟（窗口 24000tick + 余量）
const DEFENSE = argOf(process.argv, 'defense', '1');
// 裁决①：凝视守卫也显式开（本单要测它；别的线默认不装，拒绝 lookAt 会让调用方拿旧朝向干活）
const DEFENSE_GAZE = argOf(process.argv, 'defense-gaze-guard', '1');
const DEFENSE_WALL_MS = parseInt(argOf(process.argv, 'defense-wall-ms', '30000'), 10);
// 裁决②：整局防御总墙钟（TaskRuntime 侧强制；到点只记威胁、不再抢占）
const DEFENSE_TOTAL_MS = parseInt(argOf(process.argv, 'defense-total-ms', '120000'), 10);
const START_TIME = argOf(process.argv, 'start-time', '12500');   // 设计 §5.1：黄昏
// 验收协议 v3 §0.1：只有传了 --kit 才走 give 通道。开发面板可传；正式矩阵不传 = 零 kit。
// 微基准：kit 由**场景定义**给出（scenarios.mjs 的唯一真源）—— 物品 + 场景命令，
//   场景命令一律走服务器 stdin 控制台（`exec:` 前缀），**不需要 bot 是 op**。
//   （实测：bot 用 chat 发带参数的命令全部失败，而控制台同命令正常；详见 scenarios.mjs 头注）
// 矩阵：不给 --kit ⇒ 零 kit，bot 也不是 op —— 公平口径少一个变量。
const KIT = argOf(process.argv, 'kit', SCENARIO ? microKit(SCENARIO) : '');
const BOTS = ['TaskBot', 'TaskBotB', 'TaskBotC'];   // runner_core 的用户名约定（仅诊断用）

/** 把场景的物品 kit + 控制台命令拼成 runner 的 --kit 串（逗号分隔，injectKit 按 ',' 拆）。 */
function microKit(name) {
    const s = SCENARIOS[name];
    const items = String(s.kit || '').split(',').map((x) => x.trim()).filter(Boolean);
    const cmds = (s.console || []).map((c) => `exec:${c}`);
    return [...cmds, ...items].join(',');
}

const RUNS_DIR = path.join(BENCH_DIR, 'runs', RUNSTAMP);
const TEMPLATE = path.join(RUNS_DIR, '.server');

/** 物化本 run 专属的 1.16.1 模板（difficulty=easy）。不改共享模板。 */
function materializeTemplate() {
    fs.mkdirSync(TEMPLATE, { recursive: true });
    const src = path.join(SRC_SERVER, 'server.properties');
    const tpl = fs.readFileSync(src, 'utf8');
    const lines = tpl.split(/\r?\n/)
        .filter((l) => !/^level-seed=/.test(l))
        .map((l) => {
            if (l.startsWith('difficulty=')) return 'difficulty=easy';      // ★ 本单唯一改动的协议项
            if (l.startsWith('gamemode=')) return 'gamemode=survival';
            if (l.startsWith('spawn-monsters=')) return 'spawn-monsters=true';  // easy 下敌对要能刷
            if (l.startsWith('max-players=')) return 'max-players=4';
            return l;
        });
    fs.writeFileSync(path.join(TEMPLATE, 'server.properties'), lines.join('\n') + '\n');
    const eula = path.join(SRC_SERVER, 'eula.txt');
    if (fs.existsSync(eula)) fs.copyFileSync(eula, path.join(TEMPLATE, 'eula.txt'));
    if (!fs.existsSync(JAR)) throw new Error(`jar 不存在：${JAR}（用 MC_BENCH_JAR 覆盖）`);
    // 起服前的最后一道自查：java/jar 任一不存在都要**在这里**炸，并说清是哪个，
    // 而不是等 spawn ENOENT（那行只给路径，不给上下文，第一版就是这么浪费了一局）。
    if (!fs.existsSync(JAVA)) throw new Error(`java 不存在：${JAVA}（便携 JDK11 带版本目录；用 MC_BENCH_JAVA 覆盖）`);
    return TEMPLATE;
}

/**
 * 微基准的 outcome 映射（裁决 3）。
 *
 * runner_core 写的 `outcome` 是**矩阵那套**语义（`botExit !== 0` ⇒ FAIL），
 * 对微基准没意义：微基准的 bot 在**判负时也正常退出 1**，于是一律被记成 `FAIL(?)`
 * —— 上一轮 n=6 明明 3 PASS，却整列 FAIL(?)，复盘时极具误导性。
 *
 * 这里在 runMatrix 结束后，按每局 `result.json.verdict` 回写 `outcome`，
 * 并把原值留在 `runnerOutcome` 里（不丢信息），另加 `microVerdict` 便于脚本直接筛。
 */
function remapMicroOutcomes(summaryPath, runsDir) {
    if (!fs.existsSync(summaryPath)) return 0;
    const lines = fs.readFileSync(summaryPath, 'utf8').split('\n').filter((l) => l.trim());
    let n = 0;
    const rows = lines.map((l) => {
        const row = JSON.parse(l);
        const cands = [
            row.runDir,
            path.join(runsDir, `trial_${String(row.trial).padStart(2, '0')}`),
            path.join(runsDir, `trial-${String(row.trial).padStart(2, '0')}`),
        ].filter(Boolean);
        const dir = cands.find((d) => fs.existsSync(path.join(d, 'result.json')));
        if (!dir) return row;
        let verdict = null;
        try { verdict = JSON.parse(fs.readFileSync(path.join(dir, 'result.json'), 'utf8')).verdict ?? null; } catch { /* 无结果 */ }
        if (!verdict) return row;
        row.runnerOutcome = row.runnerOutcome ?? row.outcome;   // 原值留档；**幂等**：重复 remap 不覆盖
        row.microVerdict = verdict;
        row.outcome = verdict === 'PASS' ? 'MICRO_PASS' : `MICRO_FAIL(${verdict})`;
        n++;
        return row;
    });
    fs.writeFileSync(summaryPath, rows.map((r) => JSON.stringify(r)).join('\n') + '\n');
    return n;
}

// ⚠ 这行曾经被我用 remapMicroOutcomes 的函数定义整行顶掉 ⇒ trialNumbers 变成 undefined
//   ⇒ runMatrix 拿到 undefined 的 trials、**一局没跑却"成功"退出**（只留下 .server 目录）。
//   教训：插入代码时 old_string 要含足够上下文，别拿一整条声明当锚点。
const trialNumbers = Array.from({ length: TRIALS }, (_, i) => START + i);
const seedList = SEED_LIST ? SEED_LIST.split(',').map((s) => s.trim()) : null;
const seedFor = (n) => {
    if (seedList) return seedList[n - START] ?? `${SEED_PREFIX}-${String(n).padStart(2, '0')}`;
    return SEED_LITERAL || `${SEED_PREFIX}-${String(n).padStart(2, '0')}`;
};

// 矩阵：harness 的世界级动作（难度 + 起始时刻），**只发命令不给物品** ⇒ 零 kit。
// 微基准：kit 来自场景定义（物品），场景本身由 bot 用 op 造 ⇒ 这里**不**注入 exec。
const harnessExec = SCENARIO
    ? KIT
    : (KIT || `exec:difficulty easy,exec:time set ${START_TIME}`);

console.log(`[S0] stamp=${RUNSTAMP} trials=${TRIALS} lanes=${LANES}${LANE_NAMES.length ? `(${LANE_NAMES.join(',')})` : ''}`);
console.log(`[S0] task layer : ${TASK_LAYER}`);
console.log(`[S0] template   : ${TEMPLATE} (difficulty=easy)`);
if (SCENARIO) {
    console.log(`[S0] mode=MICRO scenario=${SCENARIO} (${SCENARIOS[SCENARIO].label})`);
    console.log(`[S0] kit（控制台 exec + 物品）: ${KIT || '(none)'}`);
} else {
    console.log(`[S0] harness cmd: ${harnessExec}`);
    console.log(`[S0] defense=${DEFENSE} gaze=${DEFENSE_GAZE} single=${DEFENSE_WALL_MS}ms total=${DEFENSE_TOTAL_MS}ms no-progress=${NO_PROGRESS_S}s`);
}

materializeTemplate();

// --remap-only <stamp>：只对已有 run 做 outcome 重映射后退出（不跑局）。
// 用途：映射逻辑必须能在**真数据**上验过，不能"加了但没跑过"。
const REMAP_ONLY = argOf(process.argv, 'remap-only', '');
if (REMAP_ONLY) {
    // ⚠ 这里必须用 REMAP_ONLY 自己拼路径：RUNSTAMP 来自 --stamp，而 remap 模式不传它
    //   ⇒ 早先版本指向了一个不存在的目录、**静默重映射 0 局**却报成功。
    const RD = path.join(BENCH_DIR, 'runs', String(REMAP_ONLY));
    const sp = path.join(RD, 'summary.jsonl');
    const n = remapMicroOutcomes(sp, RD);
    console.log(`[S0] remap-only ${REMAP_ONLY}：重映射 ${n} 局 → ${sp}`);
    for (const l of fs.readFileSync(sp, 'utf8').split('\n').filter((x) => x.trim())) {
        const r = JSON.parse(l);
        console.log(`[S0]   trial ${r.trial} ${r.outcome}${r.runnerOutcome ? `（runner 原值 ${r.runnerOutcome}）` : ''}`);
    }
    if (n === 0) { console.error('[S0] ⚠ 一局都没重映射到：检查该 stamp 的 trial 目录名与 result.json 是否存在'); process.exit(1); }
    process.exit(0);
}

await runMatrix({
    runsDir: RUNS_DIR,
    summaryPath: path.join(RUNS_DIR, 'summary.jsonl'),
    execBotPath: SCENARIO ? path.join(BENCH_DIR, 'micro', 'micro_defense.mjs') : path.join(BENCH_DIR, 'exec_bot.mjs'),
    stageLabel: SCENARIO
        ? `MICRO-defense/${SCENARIO} (${SCENARIOS[SCENARIO].label})`
        : `BASIC-survival (easy, dusk${START_TIME}, defense=${DEFENSE})`,
    templateDir: TEMPLATE,
    jarPath: JAR,
    java: JAVA,
    rconPass: 'spike-rcon',
    trials: trialNumbers,
    seedFor,
    extraBotArgs: () => (SCENARIO
        ? ['--scenario', SCENARIO]
        : [
            '--target', String(TARGET),
            '--defense', String(DEFENSE),
            '--defense-gaze-guard', String(DEFENSE_GAZE),
            '--defense-wall-ms', String(DEFENSE_WALL_MS),
            '--defense-total-ms', String(DEFENSE_TOTAL_MS),
        ]),
    lanes: LANES,
    laneNames: LANE_NAMES,
    mcVersion: MC_VERSION,
    timeoutMs: TIMEOUT_MS,
    noProgressMs: NO_PROGRESS_S * 1000,
    probeMs: PROBE_MS,
    // 微基准一局=一个样本，判负就是判负（不做"4 败收手"那套矩阵语义）
    failBudget: FAIL_BUDGET || (SCENARIO ? null : { mode: 'fail', n: 4 }),
    minFreeBytes: MIN_FREE_MB * 1048576,
    serverXmx: SERVER_XMX,
    kit: harnessExec,
}).then(({ ok, total }) => {
    if (SCENARIO) {
        const n = remapMicroOutcomes(path.join(RUNS_DIR, 'summary.jsonl'), RUNS_DIR);
        const rows = fs.readFileSync(path.join(RUNS_DIR, 'summary.jsonl'), 'utf8').split('\n').filter((l) => l.trim())
            .map((l) => JSON.parse(l));
        const pass = rows.filter((r) => r.outcome === 'MICRO_PASS').length;
        console.log(`[S0] outcome 已按 result.json.verdict 重映射：${pass}/${rows.length} MICRO_PASS（重映射 ${n} 局）`);
        for (const r of rows) console.log(`[S0]   trial ${r.trial} ${r.outcome}${r.runnerOutcome ? `（runner 原值 ${r.runnerOutcome}）` : ''}`);
    }
    console.log(`[S0] done ${ok}/${total} → ${RUNS_DIR}`);
    console.log(`[S0] 汇总：node ${path.join(BENCH_DIR, 'summarize.mjs')} --stamp ${RUNSTAMP}`);
    fs.mkdirSync(RUNS_DIR, { recursive: true });
    process.exit(0);
}).catch((e) => { console.error('[S0] run_bench failed:', e); process.exit(1); });
