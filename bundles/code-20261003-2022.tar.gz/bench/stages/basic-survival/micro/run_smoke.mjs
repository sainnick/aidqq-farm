// run_smoke.mjs — G 线：借泳道跑微基准冒烟的驱动（等泳道 → 跑 → 被占就重试）
//
// 为什么要它：泳道是共享资源（手册 §9.2 泳道归属看 .lane-owners 心跳）。
// 各开发线在自己两局之间进出泳道，所以"看一次就起跑"必然有概率撞上 —— run_bench
// 遇到活锁会**正确地停下让路**（"✗ 线锁被占 … 不要接管"），于是这一轮直接白等。
// 这里把「等一个真正释放的窗口 + 抢跑 + 失败重试」包起来，一次调用跑完一组。
//
// 用法：node run_smoke.mjs --scenario creeper --trials 3 --stamp MIC_X --attempts 4
// 判据：判空闲 = **端口空闲 且 该泳道线锁不活**（"两局之间"那种空窗不算——
//       持有者下一局就会抢回去，撞上去是两败俱伤）。

import { execFileSync, spawnSync } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BENCH = path.join(HERE, '..');
const NODE = process.execPath;
function arg(n, d) { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; }

const SCENARIO = arg('scenario', 'melee');
const TRIALS = arg('trials', '3');
const STAMP = arg('stamp', `MIC_${SCENARIO.toUpperCase()}`);
const TIMEOUT_MS = arg('timeout-ms', '240000');
const ATTEMPTS = parseInt(arg('attempts', '4'), 10);
const WAIT_S = parseInt(arg('wait-s', '300'), 10);
const PREFER = arg('prefer', 'A,C,B').split(',');
const LANE_WAIT_S = parseInt(arg('lane-wait-s', '420'), 10);   // 单次 attempt 里的心跳等待上限（7 分钟）

function freeLane() {
    // ⚠⚠ `wait_lane.mjs` 在**上一层**（`basic-survival/`），不在 `micro/` 里。
    //   原来这里写的是 `path.join(HERE, 'wait_lane.mjs')` = `micro/wait_lane.mjs`，
    //   而那个文件**不存在** ⇒ spawnSync 抛 ENOENT、r.stdout 为空 ⇒ 正则匹配不上
    //   ⇒ freeLane() 恒返回 null ⇒ 一路打印"没有空闲泳道"，**看起来像"泳道被别人占着"**，
    //   实际是本脚本自己的路径错了。与 micro_defense.mjs 的 TASK_LAYER 默认路径
    //   少退一级是同一族（报告 bug #11）。
    //   路径写错时必须**报出来**，不能伪装成"没有空闲泳道"——后者会把人引去
    //   错误地怀疑别的线占着泳道。
    const p = path.join(BENCH, 'wait_lane.mjs');
    if (!fs.existsSync(p)) {
        console.log(`  ✗ 找不到 ${p} —— 这是脚本自身的路径错误，不是泳道被占`);
        return null;
    }
    // ⚠ 等待时长必须给够：原来硬编码 `--max-s 1`（只看一眼），
    //   三个泳道都被占时它 1 秒就放弃、再靠外层 20s 轮询硬熬 —— 那是"空等轮询"，
    //   不是"按心跳等"。`wait_lane.mjs` 自己就是 15s 一跳的心跳（有界、可中断、
    //   每跳打印三条泳道的端口/锁状态），把上限交给 `--lane-wait-s`。
    const r = spawnSync(NODE, [p, '--max-s', String(LANE_WAIT_S), '--prefer', PREFER.join(',')], { encoding: 'utf8', timeout: (LANE_WAIT_S + 30) * 1000 });
    if (r.error) { console.log(`  ✗ wait_lane 起不来：${r.error.message}`); return null; }
    const m = /FREE_LANE=(\w)/.exec(r.stdout || '');
    if (!m && (r.stderr || '').trim()) console.log(`  ✗ wait_lane 报错：${String(r.stderr).trim().slice(0, 200)}`);
    // 心跳逐跳打印（等待过程本身就是证据：借道按心跳、不抢、不接管别人的活锁）
    if (!m) {
        const beats = (r.stdout || '').split(/\r?\n/).filter((l) => /^\[\s*\d+s #\d+\]/.test(l));
        for (const l of beats.slice(-6)) console.log(`  ${l.trim()}`);
        if ((r.stdout || '').includes('TIMEOUT_NO_LANE')) console.log('  （wait_lane 到上限：三条泳道都没真正释放）');
    }
    return m ? m[1] : null;
}

function trialFailureKind(dir) {
    for (const d of fs.readdirSync(dir)) {
        const rj = path.join(dir, d, 'result.json');
        if (fs.existsSync(rj)) {
            try {
                const j = JSON.parse(fs.readFileSync(rj, 'utf8'));
                if (j?.detail?.why === 'connect') return { kind: 'connect', trial: d, error: String(j.detail.error).slice(0, 80) };
            } catch { /* result.json 半截落盘 */ }
        }
        // 服没起来 ⇒ trial 目录里只有 server.log。**泳道竞态**的指纹：
        //   `FAILED TO BIND TO PORT` + `Address already in use`（别的线先起服占了同一口）。
        const sl = path.join(dir, d, 'server.log');
        if (fs.existsSync(sl)) {
            try {
                const txt = fs.readFileSync(sl, 'utf8');
                if (txt.includes('FAILED TO BIND TO PORT')) return { kind: 'bind', trial: d, error: 'Address already in use' };
            } catch { /* 日志半截 */ }
        }
    }
    return null;
}

/** 只认「连接层 / 泳道层」两种可重试的失败；场景闸门失败与判据 FAIL 一律不重试。 */
function retryableFailure(stamp) {
    const dir = path.join(BENCH, 'runs', stamp);
    if (!fs.existsSync(dir)) return null;
    const f = trialFailureKind(dir);
    if (!f) return null;
    // 把服务端侧证据一起打出来（服到位了吗、原始错误是什么），避免"重试掩盖确定性 bug"
    let done = false;
    try { done = fs.readFileSync(path.join(dir, f.trial, 'server.log'), 'utf8').includes('Done ('); } catch {}
    console.log(`  [证据] ${f.trial}: 失败层=${f.kind}，服务端 Done(${done})，错误=${f.error}`);
    return f;
}

for (let attempt = 1; attempt <= ATTEMPTS; attempt++) {
    console.log(`\n######## attempt ${attempt}/${ATTEMPTS} scenario=${SCENARIO} ########`);
    const lane = freeLane();
    if (!lane) { console.log('  心跳等到上限仍没有真正空闲的泳道，让路（不接管别人的活锁）'); await new Promise((r) => setTimeout(r, 20000)); continue; }
    console.log(`  借到泳道 ${lane}，起跑（trials=${TRIALS}）`);
    const r = spawnSync(NODE, [
        path.join(BENCH, 'run_bench.mjs'),
        '--scenario', SCENARIO, '--lane', lane, '--trials', TRIALS,
        '--timeout-ms', TIMEOUT_MS, '--no-progress-s', '240', '--probe-ms', '3000',
        '--stamp', STAMP,
    ], { encoding: 'utf8', env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
    const out = `${r.stdout || ''}\n${r.stderr || ''}`;
    // 只挑关键行，避免刷屏
    for (const line of out.split(/\r?\n/)) {
        if (/verdict=|DONE|线锁被占|toolFailed|scenario gates|common gates|cleanup .*(CLEAN|DIRTY)|done \d+\//.test(line)) console.log(`  | ${line.trim()}`);
    }
    const summary = path.join(BENCH, 'runs', STAMP, 'summary.jsonl');
    const ran = fs.existsSync(summary) && fs.readFileSync(summary, 'utf8').trim().length > 0;
    if (ran && retryableFailure(STAMP)) {
        // ⚠ bot 连不上 / 服抢不到端口 ≠ 场景或原语坏了。两种实测：
        //   ① 2026-10-03 10:41：服务端 `Done (21.044s)` 之后 3 秒 bot 就
        //      `connect ETIMEDOUT 127.0.0.1:25567`，而同一端口 85 秒前那局正常通过
        //      ⇒ Windows loopback/NIO 抖动族（手册 §2），不是配置错。
        //   ② 2026-10-03 10:48：B 线 portal 的服先起在 25567（共享模板目录
        //      `experiments/mc1161-gate/server-1161_laneB`），我的服
        //      `FAILED TO BIND TO PORT / Address already in use` ⇒ 泳道竞态。
        // 而 `runner_core.bootServerWithRetry` **只对"起服即崩"重试**（bind 失败不算崩），
        // `run_smoke` 又只看"summary 有没有落盘" ⇒ 这两种都会被当成"跑过了"。
        // 这里补**窄口径**重试：只认连接层/泳道层，且必须把证据打出来——
        // 手册 §2「重试会掩盖确定性 bug」，所以场景闸门失败、判据 FAIL 一律**不**重试。
        console.log('  ⚠ 失败在连接层/泳道层（不是场景也不是判据）→ 下一轮重试');
        await new Promise((r2) => setTimeout(r2, 20000));
        continue;
    }
    if (ran) {
        console.log(`  ✅ 跑完并落盘：${summary}`);
        process.exit(0);
    }
    console.log('  ⚠ 这一轮没跑成（多半是线锁被占），下一轮重试');
    await new Promise((r2) => setTimeout(r2, 15000));
}
console.log(`\n❌ ${ATTEMPTS} 轮都没抢到泳道，停下让路（不接管别人的活锁）`);
process.exit(2);
