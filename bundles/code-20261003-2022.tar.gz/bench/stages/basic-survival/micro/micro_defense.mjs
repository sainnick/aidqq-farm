// micro_defense.mjs — MC-M1-TASK-07（G 线）防御微基准执行机器人
//
// 4 组场景（苦力怕 / 僵尸近战 / 骷髅 / 末影人凝视）共用这一个 bot；
// 场景定义在 scenarios.mjs（**唯一真源**，手册 §5），由 run_bench 拼成控制台命令注入。
// 测量全部走生产**原语**：decideCreeper / pickFleeSpot / navTo / meleeBeat / decideSkeleton /
// pickCover / wouldStare / installGazeGuard —— 本文件不含任何策略、也不发任何服务器命令。
//
// —— 为什么本文件一条命令都不发 ——
// 实测（MIC_CREEPER_S1 / MIC_GAZE_PROBE2）：bot 用 chat 发命令，**带参数的一律失败**，
// 回包是 `commands.failed` + `<--[HERE]`，而 1.16.1 的 `commands.failed` **本身就是空串**
// ⇒ 服务端只给玩家看输入和标记，真实原因只进服务端日志，客户端侧查不出来。
// 判决实验：`/list`（无参）**成功**并返回在线列表 ⇒ 通道通、已登录、也是 op；
// 失败的是全部带参数命令。⇒ 场景一律交给控制台（手册 §2/§5 的要求），见 scenarios.mjs 头注。
//
// 裁决 1 口径（设计会话 10-02 夜）：**开发期允许 kit + summon + 固定站位 + 布景硬闸门**。
//   - 物品/场景：--kit 通道（控制台），kit.json 留痕
//   - 硬闸门：不通过 ⇒ toolFailed 判负，**绝不**把"场景没建起来"读成"原语坏了"
//     （TASK-08 r6 的教训：4 轮微基准每轮都在测假的东西）
//
// 用法（一般由 run_bench.mjs --scenario <name> 调起）：
//   node micro_defense.mjs --scenario creeper --trial 1 --seed x --out <dir> --port 25568 \
//        --username TaskBotC --mc-version 1.16.1 --timeout-ms 300000

import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BENCH_DIR = path.join(HERE, '..');
const TASK_LAYER = process.env.TASK_LAYER_DIR || path.resolve(BENCH_DIR, '../../../mindcraft-wt/s0-survival');
const require = createRequire(path.join(TASK_LAYER, 'package.json'));
const pf = require('mineflayer-pathfinder');
const { ARENA, commonGates, SCENARIOS } = await import(pathToFileURL(path.join(HERE, 'scenarios.mjs')).href);

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}
const SCENARIO = arg('scenario', 'melee');
const TRIAL = parseInt(arg('trial', '0'), 10);
const SEED = arg('seed', 'unknown');
const OUT_DIR = arg('out', BENCH_DIR);
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const MC_VERSION = arg('mc-version', '1.16.1');
const TIMEOUT_MS = parseInt(arg('timeout-ms', '300000'), 10);
const PROBE_MS = parseInt(arg('probe-ms', '3000'), 10);
const KIT_DESC = arg('kit-desc', '');

const TELEMETRY = path.join(OUT_DIR, 'telemetry.jsonl');
const RESULT = path.join(OUT_DIR, 'result.json');
const LOG = path.join(OUT_DIR, 'bot.log');
const PROBE = path.join(OUT_DIR, 'probe.jsonl');
const KIT_DONE = path.join(OUT_DIR, 'kit_done.json');

fs.mkdirSync(OUT_DIR, { recursive: true });
const log = (m) => { const l = `[${new Date().toISOString()}] ${m}`; console.log(l); try { fs.appendFileSync(LOG, l + '\n'); } catch {} };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const tele = (event, data = {}) => {
    const rec = JSON.stringify({ t: Date.now(), event, ...data });
    try { console.log(`[micro] ${rec}`); } catch {}
    try { fs.appendFileSync(TELEMETRY, rec + '\n'); } catch {}
};
let finished = false, _spawned = false;
let _probeTimer = null;

/**
 * 全局兜底：**把崩溃变成数据**。
 * Node 20 对未处理的 rejection 直接终止进程 —— 一崩就整局 result.json 落不了盘，
 * 复盘只剩一行 `NO_RESULT`，完全看不出是哪一步炸的（MIC_CREEPER_S9 三局全这样）。
 * 这里先落一份 FAIL 结果（带原因），再退出；已落盘的结果不会被覆盖。
 */
process.on('unhandledRejection', (reason) => {
    const msg = String(reason && reason.message ? reason.message : reason).slice(0, 300);
    try { log(`UNHANDLED_REJECTION: ${msg}`); } catch {}
    finish({ verdict: 'FAIL', detail: { why: 'unhandled_rejection', error: msg } }, 1);
});
process.on('uncaughtException', (err) => {
    const msg = String(err && err.message ? err.message : err).slice(0, 300);
    try { log(`UNCAUGHT_EXCEPTION: ${msg}`); } catch {}
    finish({ verdict: 'FAIL', detail: { why: 'uncaught_exception', error: msg } }, 1);
});

function finish(payload, code) {
    if (finished) return;
    finished = true;
    if (_probeTimer) clearInterval(_probeTimer);
    try { fs.writeFileSync(RESULT, JSON.stringify({ trial: TRIAL, seed: SEED, scenario: SCENARIO, mcVersion: MC_VERSION, kit: KIT_DESC || '(none)', ...payload }, null, 2)); } catch (e) { log(`result write fail: ${e.message}`); }
    setTimeout(() => process.exit(code), 800);
}

async function main() {
    if (!SCENARIOS[SCENARIO]) throw new Error(`未知场景 ${SCENARIO}（可用：${Object.keys(SCENARIOS).join('/')}）`);
    const scen = SCENARIOS[SCENARIO];
    const mineflayer = require('mineflayer');
    const prod = await import(pathToFileURL(path.join(TASK_LAYER, 'src/agent/tasks/exec/defense/index.js')).href);
    const { navTo } = await import(pathToFileURL(path.join(TASK_LAYER, 'src/agent/tasks/exec/nav.js')).href);
    // ⚠ 必须用**生产自己的** makeRunState()，不能拿 `{counters:{}}` 凑：
    //   navTo 会写 `ctx.run.counters.phaseMs.nav`，裸 {} 里 phaseMs 是 undefined
    //   ⇒ 抛 "Cannot read properties of undefined (reading 'nav')"，**导航一次都没真走**
    //   ⇒ 看起来像"生产后撤太慢、fuse 预算不够"，其实是 harness 的假象
    //   （MIC_CREEPER_S10 三局 damage=10 全部由此而来）。顺带白拿真实 navAttempts/phaseMs。
    const { makeRunState } = await import(pathToFileURL(path.join(TASK_LAYER, 'src/agent/tasks/exec/task_runner.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
    bot.loadPlugin(pf.pathfinder);

    const hardKill = setTimeout(() => { log('HARD_TIMEOUT'); finish({ verdict: 'FAIL', detail: { why: 'hard_timeout' } }, 1); }, TIMEOUT_MS + 60000);
    bot.on('kicked', (r) => { log(`kicked: ${r}`); if (!finished) finish({ verdict: 'FAIL', detail: { why: 'kicked' } }, 1); });
    bot.on('error', (e) => { log(`bot_error: ${e}`); if (!finished && !_spawned) finish({ verdict: 'FAIL', detail: { why: 'connect', error: String(e).slice(0, 160) } }, 1); });
    bot.on('death', () => { log('death event'); setTimeout(() => { try { bot.respawn(); } catch {} }, 600); });

    bot.once('spawn', async () => {
        _spawned = true;
        try {
            // ① 等 harness 栅栏：injectKit 会先等 "joined the game" 再注入，所以
            //    kit_done.json 落盘 ⇔ 物品给了 **且** 场景命令都发过了。
            const t0 = Date.now();
            while (!fs.existsSync(KIT_DONE) && Date.now() - t0 < 60000) await sleep(300);
            if (!fs.existsSync(KIT_DONE)) {
                log('harness gate timeout（kit 未注入：场景多半没建起来）');
                finish({ verdict: 'FAIL', detail: { why: 'kit_gate_timeout' } }, 1);
                return;
            }
            log(`harness gate ready in ${Date.now() - t0}ms, kit=[${KIT_DESC || 'none'}]`);
            await sleep(ARENA.settleMs);

            // ② 通用闸门：脚下的地板是 stone / 脚与头是空气（fill 没生效时这里直接挡住）
            let gates = [];
            const tGate = Date.now();
            for (;;) {
                gates = commonGates(bot);
                if (gates.every((g) => g.ok) || Date.now() - tGate > ARENA.gateTimeoutMs) break;
                await sleep(400);
            }
            log(`common gates: ${JSON.stringify(gates)} (${Date.now() - tGate}ms)`);
            if (!gates.every((g) => g.ok)) {
                finish({ verdict: 'FAIL', gates, detail: { why: 'arena_gates_failed', gates } }, 1);
                return;
            }
            log(`position=[${bot.entity.position}] inv=[${bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',') || 'empty'}]`);

            // ③ 场景专属闸门（实体在不在、武器/盾/掩体在不在、有没有多出来的怪）
            const ctxBase = {
                bot, prod, tele, log, sleep,
                run: makeRunState(),
                telemetry: (e, d) => tele(e, d),
                dist3d: (e) => bot.entity.position.distanceTo(e.position),
                hdist: (e) => Math.hypot(bot.entity.position.x - e.position.x, bot.entity.position.z - e.position.z),
                navToSpot: async (pos) => {
                    // ⚠ 必须自己吞异常：navTo 的 `new pf.Movements(bot)` 在它自己的 try 之外，
                    //   抛出来就是一个 rejected promise；而调用方（creeper measure）是
                    //   **条件性 await** 它的（循环耗尽时不 await）⇒ 未处理的 rejection
                    //   会让 Node 直接崩掉进程，**整局数据全丢**（MIC_CREEPER_S9 三局全 NO_RESULT）。
                    try {
                        const ok = await navTo(ctxBase, new pf.goals.GoalNear(pos.x, pos.y, pos.z, 1), { timeoutMs: 20000, label: 'micro_nav' });
                        tele('micro_nav', { to: [pos.x, pos.y, pos.z], ok });
                        return ok;
                    } catch (e) {
                        tele('micro_nav_threw', { to: [pos.x, pos.y, pos.z], error: String(e && e.message ? e.message : e).slice(0, 160) });
                        return false;
                    }
                },
            };
            const sgates = await scen.gates(ctxBase);
            tele('scenario_gates', { scenario: SCENARIO, gates: sgates });
            log(`scenario gates: ${JSON.stringify(sgates)}`);
            if (!sgates.every((g) => g.ok)) {
                finish({ verdict: 'FAIL', gates: sgates, detail: { why: 'scenario_gates_failed', gates: sgates } }, 1);
                return;
            }

            // ④ 测量
            const r = await scen.measure(ctxBase);
            tele('measure_done', { scenario: SCENARIO, verdict: r.verdict, samples: r.samples, navAttempts: ctxBase.run.counters.navAttempts, navFailures: ctxBase.run.counters.navFailures, phaseMs: ctxBase.run.counters.phaseMs });
            log(`verdict=${r.verdict} samples=${JSON.stringify(r.samples)} nav(尝试/失败)=${ctxBase.run.counters.navAttempts}/${ctxBase.run.counters.navFailures}`);
            finish({ verdict: r.verdict, gates: sgates, samples: r.samples, detail: r.detail, commonGates: gates, runCounters: ctxBase.run.counters }, r.verdict === 'PASS' ? 0 : 1);
        } catch (e) {
            log(`fatal: ${e && e.stack ? e.stack : e}`);
            finish({ verdict: 'FAIL', detail: { why: 'exception', error: String(e && e.message ? e.message : e).slice(0, 300) } }, 1);
        } finally {
            clearTimeout(hardKill);
        }
    });

    if (PROBE_MS > 0) {
        _probeTimer = setInterval(() => {
            try {
                const p = bot.entity?.position;
                fs.appendFileSync(PROBE, JSON.stringify({
                    t: Date.now(), event: 'bench_probe',
                    inv: bot.inventory.items().map((i) => `${i.name}:${i.count}`).sort().join(','),
                    pos: p ? [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)] : null,
                    digging: false, furnace: null, tree: `micro:${SCENARIO}`,
                }) + '\n');
            } catch { /* 探针失败不影响测量 */ }
        }, PROBE_MS);
        _probeTimer.unref?.();
    }
}

main().catch((e) => { log(`boot fail: ${e && e.stack ? e.stack : e}`); process.exit(1); });
