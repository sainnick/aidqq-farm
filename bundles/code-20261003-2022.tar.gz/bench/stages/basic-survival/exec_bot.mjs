// exec_bot.mjs — MC-M1-TASK-07（G 线）BASIC-survival 执行机器人（standalone）
//
// 协议（设计 §5.1）：
//   难度 easy（harness 层：server.properties 模板 + 控制台 /difficulty easy 双保险）
//   起始时刻 /time set 12500（黄昏）——**harness 层动作，与种子注入同先例**；
//     玩家视角只是"天黑了"，不构成游戏内信息泄漏（设计 §5.1 原文口径）。
//   MISSION = obtain 1 iron_pickaxe（与 TASK-06 同目标 ⇒ 对照组天然存在）
//   零 kit：不给任何物品。--kit 只被用来跑 harness 的 exec 命令（时间/难度），
//     `injectKit` 里的 give 循环因为没有任何普通物品条目而完全不执行。
//   窗口 24000 tick ≈ 20 分钟真实时间。
//
// 与 basic-iron/exec_bot.mjs 的三处**故意**差别：
//   1. 任务层从 TASK_LAYER_DIR 导入（默认 G 线 worktree），不是主目录 mindcraft/ ——
//      否则测的就是 A 线的代码。
//   2. **不加载 mineflayer-pvp**（设计 §4：#52 可隔墙攻击、#53 无法停止/无法设攻击范围，
//      与中断语义和苦力怕距离管理直接冲突；基准局建议直接不加载）。近战是自写的 MeleeTick。
//   3. 等 kit_done.json 作为"世界与时间已就绪"的栅栏（与 bench 既有约定一致：
//      不等就会出现"计划器读背包时时间还没设"的竞态）。
//
// 用法（由 run_bench.mjs 调起，一般不手动跑）：
//   node exec_bot.mjs --trial 1 --seed <seed> --out <runDir> --port 25566 --username TaskBot \
//        --mc-version 1.16.1 --timeout-ms 1200000 --probe-ms 5000

import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import fs from 'fs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const TASK_LAYER = process.env.TASK_LAYER_DIR
    || path.resolve(HERE, '../../../mindcraft-wt/s0-survival');
const require = createRequire(path.join(TASK_LAYER, 'package.json'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}

const TRIAL = parseInt(arg('trial', '0'), 10);
const SEED = arg('seed', 'unknown');
const OUT_DIR = arg('out', HERE);
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const TIMEOUT_MS = parseInt(arg('timeout-ms', '1200000'), 10);
const MC_VERSION = arg('mc-version', '1.16.1');
const PROBE_MS = parseInt(arg('probe-ms', '5000'), 10);
// 裁决①（设计会话 10-02 夜）：**默认关、显式开**。这里默认 '0'，由 run_bench 显式传 '1' ——
// 双端都显式，避免"哪天默认值被改回去、别的线的回归悄悄变了"这种无声漂移。
const DEFENSE = arg('defense', '0') === '1';
const DEFENSE_GAZE = arg('defense-gaze-guard', '0') === '1';
const DEFENSE_WALL_MS = parseInt(arg('defense-wall-ms', '30000'), 10);   // 任务单硬要求①默认 30s
const DEFENSE_TOTAL_MS = parseInt(arg('defense-total-ms', '120000'), 10); // 裁决②：整局总墙钟默认 120s
const KIT_DESC = arg('kit-desc', '');

const TELEMETRY = path.join(OUT_DIR, 'telemetry.jsonl');
const RESULT = path.join(OUT_DIR, 'result.json');
const LOG = path.join(OUT_DIR, 'bot.log');
const PROBE = path.join(OUT_DIR, 'probe.jsonl');
const KIT_DONE = path.join(OUT_DIR, 'kit_done.json');

fs.mkdirSync(OUT_DIR, { recursive: true });
const logLine = (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(LOG, line + '\n'); } catch {}
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let finished = false;
let _spawned = false;

/** 死因日志（本地记录）。**服务端那一份才是权威**（summarize 解析 server.log 的死亡行）。 */
const deathLog = [];
let _runtime = null;
let _probeTimer = null;

function probeTree(rt) {
    try {
        const trace = rt?._ctx?.stack?.renderTrace?.() ?? '';
        return trace.replace(/\[[^\]]*\]/g, '[]');   // 状态保留、时长剥除
    } catch { return ''; }
}

function startProbe(bot) {
    if (!(PROBE_MS > 0)) return;
    try { fs.rmSync(PROBE, { force: true }); } catch {}
    _probeTimer = setInterval(() => {
        try {
            const invParts = bot.inventory.items().map((i) => `${i.name}:${i.count}`).sort();
            const p = bot.entity?.position;
            const run = _runtime?._ctx?.run;
            fs.appendFileSync(PROBE, JSON.stringify({
                t: Date.now(), event: 'bench_probe',
                inv: invParts.join(','),
                pos: p ? [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)] : null,
                digging: !!bot.targetDigBlock,
                // ⚠ runner 的 probeSig 只取 {inv,pos,digging,furnace,tree} 五个字段，
                //   下面这个 def **不进签名**（我改不了 _lib，也不该改）。防御期间保活靠的是
                //   tree 签名（任务树里会出现 Defense 节点）——这也是为什么 no-progress-s 要放宽。
                def: run?.defenseActive ? 'active' : 'idle',
                defCounters: run ? {
                    interrupts: run.counters.defenseInterrupts ?? 0,
                    actions: run.counters.defenseActions ?? 0,
                    stuckViolations: run.counters.defenseStuckViolations ?? 0,
                } : null,
                tree: probeTree(_runtime),
            }) + '\n');
        } catch { /* 探针失败不影响试局 */ }
    }, PROBE_MS);
    _probeTimer.unref?.();
}

/** 等 harness 栅栏：kit_done.json 落盘 ⇒ 时间/难度已设好、give 阶段已过。 */
async function waitHarnessReady(timeoutMs = 90000) {
    if (!KIT_DESC) return 'no-kit-channel';
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
        if (fs.existsSync(KIT_DONE)) return 'ready';
        await sleep(500);
    }
    return 'timeout';
}

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const toolPlugin = require('mineflayer-tool').plugin;
    const { TaskRuntime } = await import(pathToFileURL(path.join(TASK_LAYER, 'src/agent/tasks/exec/task_runner.js')).href);
    const { AcquireResourceTask } = await import(pathToFileURL(path.join(TASK_LAYER, 'src/agent/tasks/exec/acquire_resource_task.js')).href);
    const { CraftingTask } = await import(pathToFileURL(path.join(TASK_LAYER, 'src/agent/tasks/exec/crafting_task.js')).href);
    const { parseMission } = await import(pathToFileURL(path.join(TASK_LAYER, 'src/agent/tasks/exec/mission.js')).href);
    const { resourceDef } = await import(pathToFileURL(path.join(TASK_LAYER, 'src/agent/tasks/exec/resources.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
    bot.loadPlugin(pf.pathfinder);
    bot.loadPlugin(toolPlugin);
    // ⚠ 故意**不** bot.loadPlugin(pvp)：设计 §4 的裁定（基准局不加载 pvp）。
    //   自检脚本可断言：`node -e "…"` 里查 mcdata.js 会看到 pvp 仍被加载，但本 bot 不走那条路。

    const hardKill = setTimeout(() => {
        logLine('HARD_TIMEOUT: runner watchdog fired, exiting without result');
        finish({ status: 'RUNNER_TIMEOUT' }, 1);
    }, TIMEOUT_MS + 60000);

    bot.on('kicked', (r) => { logLine(`kicked: ${r}`); if (!finished) finish({ status: 'KICKED', reason: String(r) }, 1); });
    bot.on('error', (e) => {
        logLine(`bot_error: ${String(e).slice(0, 200)}`);
        if (!finished && !_spawned) finish({ status: 'CONNECT_FAIL', reason: String(e).slice(0, 120) }, 1);
    });
    bot.on('death', () => {
        const rec = { t: Date.now(), hp: bot.health, food: bot.food, pos: bot.entity?.position ? [bot.entity.position.x, bot.entity.position.y, bot.entity.position.z] : null };
        deathLog.push(rec);
        logLine(`death event: hp=${rec.hp} pos=${JSON.stringify(rec.pos)} (服务端死亡行由 summarize 解析)`);
        setTimeout(() => { try { bot.respawn(); } catch {} }, 800);
    });
    bot.on('kickedWhileDead', () => { /* 占位：1.16 无此事件，保留可读性 */ });

    bot.once('spawn', async () => {
        _spawned = true;
        try {
            const gate = await waitHarnessReady();
            logLine(`harness gate: ${gate} (kit-desc=${KIT_DESC || 'none'})`);
            await sleep(4000);   // 世界落定
            const spawnPos = bot.entity.position.floored();
            const invSnap = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',') || '(empty)';
            logLine(`spawn: seed=${SEED} pos=[${spawnPos.x},${spawnPos.y},${spawnPos.z}] inventory=[${invSnap}]`);
            logLine(`protocol: difficulty=easy, time=12500 (harness), NO ITEMS GIVEN, NO LLM, pvp=off, defense=${DEFENSE} gaze=${DEFENSE_GAZE} total=${DEFENSE_TOTAL_MS}ms`);

            const missionCount = Math.max(1, parseInt(arg('target', '1'), 10) || 1);
            const mission = parseMission(`obtain ${missionCount} iron_pickaxe`);
            logLine(`start: mission=${JSON.stringify(mission)}`);
            const def = resourceDef(mission.resource);
            const runtime = new TaskRuntime(bot, {
                mission, telemetryPath: TELEMETRY, stackMaxDepth: 8,
                defense: DEFENSE, defenseGazeGuard: DEFENSE_GAZE,
                defenseWallMs: DEFENSE_WALL_MS, defenseScanMs: 500,
                defenseTotalMs: DEFENSE_TOTAL_MS,
                maxInterrupts: 60,
            });
            _runtime = runtime;
            startProbe(bot);
            const root = def.gather === false
                ? new CraftingTask({ item: def.item, count: mission.count, timeoutMs: TIMEOUT_MS, gatherTimeoutMs: 420000 })
                : new AcquireResourceTask({ resource: mission.resource, count: mission.count, timeoutMs: TIMEOUT_MS });
            const summary = await runtime.run(root);
            const fullInv = {};
            for (const it of bot.inventory.items()) fullInv[it.name] = (fullInv[it.name] ?? 0) + it.count;
            logLine(`end: ${summary.status} reason=${summary.failReason} dur=${(summary.durationMs / 1000).toFixed(1)}s inv=${JSON.stringify(summary.finalInventory)}`);
            logLine(`defense summary: ${JSON.stringify(summary.defense)}`);
            if (summary.taskTree) logLine(`task tree:\n${summary.taskTree}`);
            finish({ ...summary, spawnPos: [spawnPos.x, spawnPos.y, spawnPos.z], fullInventory: fullInv, deathLog }, summary.status === 'SUCCESS' ? 0 : 1);
        } catch (e) {
            logLine(`fatal: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`);
            finish({ status: 'FAILED', failReason: 'INTERNAL', error: String(e).slice(0, 300) }, 1);
        }
    });

    function finish(summary, code) {
        if (finished) return;
        finished = true;
        clearTimeout(hardKill);
        if (_probeTimer) clearInterval(_probeTimer);
        try {
            fs.writeFileSync(RESULT, JSON.stringify({
                trial: TRIAL, seed: SEED, resource: 'iron_pickaxe', kit: 'none',
                difficulty: 'easy', startTime: 12500, pvp: false,
                defense: DEFENSE, defenseGazeGuard: DEFENSE_GAZE, defenseTotalMs: DEFENSE_TOTAL_MS,
                ...summary,
            }, null, 2));
        } catch (e) { logLine(`result write fail: ${e.message}`); }
        setTimeout(() => { try { bot.quit(); } catch {} process.exit(code); }, 1200);
    }
}

main().catch((e) => { logLine(`boot fail: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`); process.exit(1); });
