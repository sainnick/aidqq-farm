// selftest_defense.mjs — MC-M1-TASK-07（G 线 / S0 BASIC-survival）离线自检
//
// 任务单 §2.1：「DefenseTask 状态机、中断/恢复契约（设计 §3.3 的六行表）都要有离线单测，
// 用构造的事件流验证」。本文件就是那份自检。
//
// 跑法：node bench/stages/basic-survival/selftest_defense.mjs
//       （TASK_LAYER_DIR=<worktree> 可覆盖任务层路径；不需要服务器、不占端口、不起泳道）
//
// 组织：T1..T10。每组都是"构造输入 → 断言输出"，失败会打印**期望 vs 实际**。
// T9 是静态引用检查 —— TASK-08 r7 的教训：语法检查和导出检查都抓不到
// "未定义标识符"，必须做**名字级**检查（那次是漏了 import，模块能加载、自检全绿，
// 一直跑到真调用那行才炸 ReferenceError）。

import path from 'node:path';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { makeWorld, makeBot, makeEntity, makeFakeCtx, floorPlate, taskModule, TASK_LAYER, Vec3 } from './fake_world.mjs';

const EXEC = taskModule('');
const load = (rel) => import(taskModule(rel));

// —— 微型断言框架（带计时：自检本身卡住时要能一眼看出是哪一组）——
const results = [];
let group = '';
const G = (name) => { group = name; console.log(`\n── ${name} ──`); };
async function t(name, fn) {
    const t0 = Date.now();
    try {
        await fn();
        const ms = Date.now() - t0;
        results.push({ group, name, ok: true, ms });
        console.log(`  PASS  ${name}${ms > 500 ? `  [${ms}ms]` : ''}`);
    } catch (e) {
        const ms = Date.now() - t0;
        results.push({ group, name, ok: false, ms, err: String(e && e.message ? e.message : e) });
        console.log(`  FAIL  ${name}\n        ${String(e && e.message ? e.message : e).split('\n').slice(0, 6).join('\n        ')}`);
    }
}
function eq(actual, expected, msg = '') {
    const a = JSON.stringify(actual), b = JSON.stringify(expected);
    if (a !== b) throw new Error(`${msg}\n  期望: ${b}\n  实际: ${a}`);
}
function ok(cond, msg) { if (!cond) throw new Error(msg || '期望为真，实际为假'); }

// ==================================================================== 载入真实实现
const TT = await load('defense/threat_table.js');
const LOS = await load('defense/los.js');
const GG = await load('defense/gaze_guard.js');
const MT = await load('defense/melee_tick.js');
const SH = await load('defense/shield.js');
const FD = await load('defense/food.js');
const ND = await load('defense/night_decision.js');
const RS = await load('defense/responses.js');
const DT = await load('defense/defense_task.js');
const DL = await load('defense/defense_layer.js');
const { ExecTask, FailReason, TaskStatus, sleep } = await load('task.js');
const { driveTask, makeCtx, makeRunState, TaskRuntime } = await load('task_runner.js');
const { ProgressChecker } = await load('progress_checker.js');
const { TaskStack } = await load('task_stack.js');

// ==================================================================== T1 威胁表与分级
G('T1 威胁表与分级（设计 §1.1/§1.3）');
{
    await t('主世界表齐全（6 类 + 僵尸村民）', () => {
        for (const n of ['creeper', 'skeleton', 'zombie', 'spider', 'drowned', 'enderman']) ok(TT.isHostile(n, 0), `${n} 缺`);
    });
    await t('下界威胁只登记不实现（implemented=false）', () => {
        for (const n of ['ghast', 'blaze', 'hoglin', 'piglin']) {
            ok(TT.isHostile(n, -1), `${n} 未登记`);
            ok(!TT.actionable(n, -1), `${n} 不该被派发`);
        }
        ok(!TT.isHostile('ghast', 0), '主世界不该认下界条目');
    });
    await t('分级门限：<6 紧急 / <12 接战 / <24 监视 / 之外忽略', () => {
        const c = (d, los = true) => TT.classify({ distance: d, los })?.level ?? null;
        eq(c(3), TT.THREAT_LEVEL.EMERGENCY, '3 格');
        eq(c(5.9), TT.THREAT_LEVEL.EMERGENCY, '5.9 格');
        eq(c(8), TT.THREAT_LEVEL.ENGAGED, '8 格');
        eq(c(11.9), TT.THREAT_LEVEL.ENGAGED, '11.9 格');
        eq(c(20), TT.THREAT_LEVEL.MONITORED, '20 格');
        eq(c(24), null, '24 格应忽略');
    });
    await t('公平口径：losStrict 下无视线一律不升级（任务单硬要求③）', () => {
        const r = TT.classify({ distance: 2, los: false });
        eq(r.level, TT.THREAT_LEVEL.MONITORED, '墙后 2 格不得成为紧急');
        ok(r.reason === 'no_los');
    });
    await t('已膨胀苦力怕在 defuseRange 内直接紧急（fuse 加权）', () => {
        const r = TT.classify({ distance: 6, los: true, fusing: true });
        eq(r.level, TT.THREAT_LEVEL.EMERGENCY);
        eq(r.reason, 'creeper_fusing');
    });
    await t('迟滞：ENGAGED 实体退到 12~16 之间仍算接战（退出阈值 16）', () => {
        const r = TT.classify({ distance: 14, los: true }, { engagedExitApplied: true });
        eq(r.level, TT.THREAT_LEVEL.ENGAGED, '14 格应仍接战');
        const r2 = TT.classify({ distance: 17, los: true }, { engagedExitApplied: true });
        eq(r2.level, TT.THREAT_LEVEL.MONITORED, '17 格应已退出');
    });
    await t('包围盒判据：宽 1.3 的 creep 判为已膨胀', () => {
        ok(TT.creeperLooksFused(makeEntity({ name: 'creeper', width: 1.3 })));
        ok(!TT.creeperLooksFused(makeEntity({ name: 'creeper', width: 0.6 })));
    });
}

// ==================================================================== T2 体素视线
G('T2 体素射线 LOS（设计 §1.3）');
{
    await t('中间一堵墙 → 看不见', () => {
        const w = makeWorld({ solid: floorPlate(0, 64, 0), solid: [[5, 64, 0], [5, 65, 0], [5, 66, 0], [5, 67, 0]] });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        const e = makeEntity({ pos: [10.5, 64, 0.5] });
        eq(LOS.canSeeEntity(bot, e), false);
    });
    await t('空旷 → 看得见', () => {
        const w = makeWorld({ solid: floorPlate(0, 64, 0) });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        eq(LOS.canSeeEntity(bot, makeEntity({ pos: [10.5, 64, 0.5] })), true);
    });
    await t('水不遮挡（boundingBox=empty）', () => {
        const w = makeWorld({ solid: floorPlate(0, 64, 0), water: [[5, 65, 0]] });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        eq(LOS.canSeeEntity(bot, makeEntity({ pos: [10.5, 64, 0.5] })), true);
    });
    await t('未加载区块判为不可见（宁可假阴性）', () => {
        const w = makeWorld({ solid: floorPlate(0, 64, 0), unloadedFromX: 8 });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        eq(LOS.canSeeEntity(bot, makeEntity({ pos: [10.5, 64, 0.5] })), false);
    });
    await t('对角线方向不漏格（斜穿墙角判遮挡）', () => {
        // 角上放一块，(0,0,0)→(3,0,3) 的斜线必须被它挡住
        const w = makeWorld({ solid: [[1, 64, 1]] });
        const bot = makeBot({ world: w, pos: [0.5, 64.5, 0.5] });
        const hit = LOS.raycastBlock(bot, new Vec3(0.5, 64.5, 0.5), new Vec3(3.5, 64.5, 3.5));
        ok(hit !== null, '斜线应命中墙角');
    });
    await t('同一格内的目标（0 距离）通视', () => {
        const w = makeWorld();
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        eq(LOS.raycastBlock(bot, new Vec3(0.5, 64, 0.5), new Vec3(0.5, 64, 0.5)), null);
    });
}

// ==================================================================== T3 末影人凝视守卫
G('T3 凝视守卫（设计 §1.4）');
{
    const mk = (yaw, pitch, ePos) => {
        // ⚠⚠ yaw/pitch 都是 mineflayer **内部**约定（第七轮更正，勿再改回）：
        //   · 末影人在 +z ⇒ bot 正对它要 **yaw = π**（内部 yaw = π − 线上 yaw；线上 yaw 0 = 南 = +z）
        //   · 内部 pitch **正 = 抬头**（`physics.js:361 pitch = atan2(Δy, 地面距离)`）
        //   这两行注释原来写的是"yaw=0 ⇒ 朝 +z；pitch 正值向下"（**线上约定**），
        //   而代码读的是内部字段 ⇒ 断言和被测代码一起错，`lookVector` 的两个反号钉了半年。
        const bot = makeBot({ world: makeWorld(), pos: [0.5, 64, 0.5], yaw, pitch: pitch * Math.PI / 180, entities: [makeEntity({ id: 7, name: 'enderman', pos: ePos, height: 2.9 })] });
        return bot;
    };
    const FACE_SOUTH = Math.PI;          // 末影人在 +z 时的"正对它"内部 yaw
    await t('正对末影人（yaw=π）→ 会盯上', () => {
        const bot = mk(FACE_SOUTH, 0, [0.5, 64, 10.5]);
        const e = Object.values(bot.entities)[0];
        const r = GG.wouldStare(bot, e);
        ok(r.stare, `应判盯上，实际 deg=${r.deg}`);
    });
    await t('抬头看天（pitch=+60 抬头偏离）→ 不盯', () => {
        const bot = mk(FACE_SOUTH, 60, [0.5, 64, 10.5]);
        const e = Object.values(bot.entities)[0];
        ok(!GG.wouldStare(bot, e).stare);
    });
    await t('64 格外 → 不触发', () => {
        const bot = mk(FACE_SOUTH, 0, [0.5, 64, 70.5]);
        const e = Object.values(bot.entities)[0];
        const r = GG.wouldStare(bot, e);
        eq(r.stare, false);
        ok(r.dist > 64, `距离应 >64，实际 ${r.dist}`);
    });
    await t('installGazeGuard 拦截危险 lookAt、可还原', () => {
        const bot = mk(FACE_SOUTH, 0, [0.5, 64, 10.5]);
        const g = GG.installGazeGuard(bot, {});
        ok(g.installed, '应装上');
        bot.lookAt(new Vec3(0.5, 64, 10.5), false);
        eq(g.rejected(), 1, '应拦下 1 次');
        eq(bot.calls.lookAt.length, 0, '原 lookAt 不应被调用');
        g.restore();
        bot.lookAt(new Vec3(0.5, 64, 10.5), false);
        eq(bot.calls.lookAt.length, 1, '还原后应放行');
    });
    await t('无末影人时守卫完全透明（不拦任何 lookAt）', () => {
        const bot = makeBot({ world: makeWorld(), pos: [0.5, 64, 0.5], entities: [makeEntity({ id: 1, name: 'zombie', pos: [0.5, 64, 5.5] })] });
        const g = GG.installGazeGuard(bot, {});
        bot.lookAt(new Vec3(1, 2, 3), false);
        eq(g.rejected(), 0);
        eq(bot.calls.lookAt.length, 1);
    });
}

// ==================================================================== T4 MeleeTick
G('T4 MeleeTick 原语（设计 §2.1）');
{
    await t('武器优先级：石剑优先于木剑优先于斧', () => {
        const bot = makeBot({ world: makeWorld(), items: [{ name: 'wooden_axe', count: 1 }, { name: 'wooden_sword', count: 1 }, { name: 'stone_sword', count: 1 }] });
        eq(MT.bestWeapon(bot).name, 'stone_sword');
    });
    await t('冷却门：归一化强度 <0.99 不出手，满了才出手', () => {
        eq(MT.weaponCooldownMs('stone_sword'), 625, '剑冷却应为 625ms');
        eq(MT.weaponCooldownMs('stone_axe'), 1000);
        const bot = makeBot({ world: makeWorld(), time: 10_000, items: [{ name: 'stone_sword', count: 1 }] });
        const st = MT.makeMeleeState();
        st.lastAttackAt = 10_000;   // 刚刚打过
        // ⚠ 门限常量在 threat_table（MT 没有 re-export 它，用 MT.XXX 会拿到 undefined，
        //   `x < undefined` 恒 false —— 这类"断言自己写错但看起来像被测代码坏了"的坑）
        ok(MT.attackStrength(bot, st.lastAttackAt, 'stone_sword') < TT.ATTACK_COOLDOWN_GATE, '刚打完冷却应未满');
        st.lastAttackAt = 10_000 - 700;   // 过了 700ms > 625ms
        ok(MT.attackStrength(bot, st.lastAttackAt, 'stone_sword') >= TT.ATTACK_COOLDOWN_GATE, '700ms 后应已满');
    });
    await t('目标选择：粘滞优先 + 超距不选 + 墙后不选', () => {
        const near = makeEntity({ id: 1, name: 'zombie', pos: [2.5, 64, 0.5] });
        const far = makeEntity({ id: 2, name: 'zombie', pos: [20.5, 64, 0.5] });
        const w = makeWorld({ solid: floorPlate(0, 64, 0) });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5], entities: [near, far] });
        eq(MT.pickTarget(bot, [near, far], {}).id, 1, '只该选近的');
        eq(MT.pickTarget(bot, [near], { locked: far })?.id ?? 1, 1, '锁定的目标太远应改选近的');
    });
    await t('站位评分：背后有墙的候选得分更高', () => {
        // 目标在 (0,64,0)，候选站在 (1,64,0) 时其身后 (2,64,0) 是墙
        const w = makeWorld({ solid: [...floorPlate(0, 64, 0), [2, 64, 0]] });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        const target = makeEntity({ pos: [0.5, 64, 0.5] });
        const st = MT.pickStance(bot, target, [target]);
        ok(st && st.why.includes('back_wall'), `期望含 back_wall，实际 ${st && st.why}`);
    });
    await t('isEntityGone：实体从 entities 移除即判定消失', () => {
        const e = makeEntity({ id: 3 });
        const bot = makeBot({ world: makeWorld(), entities: [e] });
        eq(MT.isEntityGone(bot, e), false);
        delete bot.entities[3];
        eq(MT.isEntityGone(bot, e), true);
    });
    await t('撤退线：hp<8 触发', () => {
        eq(MT.shouldRetreat(null, 7), true);
        eq(MT.shouldRetreat(null, 8), false);
    });
}

// ==================================================================== T5 过夜决策
G('T5 过夜决策树（设计 §2.5）');
{
    const nightBot = (o = {}) => makeBot({ world: makeWorld({ solid: o.solid ?? [] }), pos: o.pos ?? [0.5, 64, 0.5], time: o.time ?? 14_000_000 /* 14000 tick */, items: o.items ?? [] });
    await t('白天 → 继续干活', () => {
        eq(ND.decideNight({ bot: nightBot({ time: 1000_000 }), interruptsTonight: 0, hostilesWithin16: 0 }).action, 'continue');
    });
    await t('A：地下（头顶 ≥10 实心）→ 继续干活', () => {
        const solid = []; for (let y = 65; y <= 78; y++) solid.push([0, y, 0]);
        const r = ND.decideNight({ bot: nightBot({ solid }), interruptsTonight: 0, hostilesWithin16: 0 });
        eq(r.action, 'continue'); eq(r.reason, 'underground_work');
    });
    await t('B：地表 + 有床 + 无怪物 → 睡觉', () => {
        const r = ND.decideNight({ bot: nightBot({ items: [{ name: 'red_bed', count: 1 }] }), interruptsTonight: 0, hostilesWithin16: 0 });
        eq(r.action, 'sleep'); eq(r.reason, 'surface_with_bed');
    });
    await t('B 前置：16 格内有怪物 → 不睡，改壁龛', () => {
        const r = ND.decideNight({ bot: nightBot({ items: [{ name: 'red_bed', count: 1 }] }), interruptsTonight: 0, hostilesWithin16: 2 });
        eq(r.action, 'shelter'); eq(r.reason, 'bed_blocked_by_monsters');
    });
    await t('C：地表 + 无床 → 挖壁龛', () => {
        const r = ND.decideNight({ bot: nightBot({}), interruptsTonight: 0, hostilesWithin16: 0 });
        eq(r.action, 'shelter'); eq(r.reason, 'surface_no_bed');
    });
    await t('D：同区域一夜打断 ≥3 → 强制壁龛（优先于一切）', () => {
        const r = ND.decideNight({ bot: nightBot({ items: [{ name: 'red_bed', count: 1 }] }), interruptsTonight: 3, hostilesWithin16: 0 });
        eq(r.action, 'shelter'); eq(r.reason, 'escalate_thrash'); eq(r.escalate, true);
    });
    await t('深夜临近天亮 → shouldWrapUp', () => {
        eq(ND.shouldWrapUp(nightBot({ time: 22_800_000 })), true);   // 22800 tick，距 23000 不足 2400
        eq(ND.shouldWrapUp(nightBot({ time: 14_000_000 })), false);
    });
}

// ==================================================================== T6 处置决策
G('T6 苦力怕/骷髅/末影人处置（设计 §2.2/§2.3/§1.4）');
{
    await t('苦力怕已膨胀 → 无论血量武器一律后撤 ≥7 格', () => {
        const bot = makeBot({ world: makeWorld(), items: [{ name: 'iron_sword', count: 1 }] });
        const r = RS.decideCreeper({ bot, creeper: makeEntity({ name: 'creeper' }), dist: 3, fusing: true, hp: 20, armed: true });
        eq(r.route, 'disengage'); eq(r.reason, 'fusing_retreat'); eq(r.minRange, 7);
    });
    await t('苦力怕未膨胀 + hp≥12 + 有武器 → 贴脸击杀', () => {
        const bot = makeBot({ world: makeWorld(), items: [{ name: 'stone_sword', count: 1 }] });
        const r = RS.decideCreeper({ bot, creeper: makeEntity({ name: 'creeper' }), dist: 4, fusing: false, hp: 15, armed: true });
        eq(r.route, 'kill'); eq(r.standoff, 2);
    });
    await t('苦力怕未膨胀 + 低血 → 后撤（即便有武器）', () => {
        const bot = makeBot({ world: makeWorld(), items: [{ name: 'stone_sword', count: 1 }] });
        const r = RS.decideCreeper({ bot, creeper: makeEntity({ name: 'creeper' }), dist: 4, fusing: false, hp: 6, armed: true });
        eq(r.route, 'disengage'); eq(r.reason, 'low_hp_retreat');
    });
    await t('后撤落点：远离苦力怕、不落岩浆、优先露天', () => {
        const solid = floorPlate(0, 64, 0, 30);
        const w = makeWorld({ solid, lava: [[0, 62, -4]] });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        const spot = RS.pickFleeSpot(bot, new Vec3(0.5, 64, 2.5), { minRange: 7 });
        ok(spot, '应找到落点');
        ok(spot.dist >= 7, `落点距离应 ≥7，实际 ${spot.dist}`);
        ok(spot.pos.z < 0.5, '应往远离威胁的方向（-z）跑');
    });
    await t('后撤落点：四周全是岩浆时返回 null（不硬闯）', () => {
        // 岩浆放 y=62（地板 y=63 之下）：这样"脚下有支撑"成立、只有地面安全判据不成立
        // —— 才能单独验到 groundSafe 这一条。若把岩浆放 y=63，makeWorld 里 solid 优先，
        // 岩浆会被地板挡掉，测到的其实是"没地板 ⇒ 站不了"，是一条假通过。
        const solid = floorPlate(0, 64, 0, 8);
        const lava = [];
        for (let x = -8; x <= 8; x++) for (let z = -8; z <= 8; z++) if (Math.abs(x) > 1 || Math.abs(z) > 1) lava.push([x, 62, z]);
        const bot = makeBot({ world: makeWorld({ solid, lava }), pos: [0.5, 64, 0.5] });
        eq(RS.pickFleeSpot(bot, new Vec3(0.5, 64, 2.5), { minRange: 7 }), null);
    });
    await t('骷髅：<3.2 格直接近战', () => {
        const bot = makeBot({ world: makeWorld() });
        eq(RS.decideSkeleton({ bot, skeleton: makeEntity({ name: 'skeleton' }), dist: 2, hp: 20, shield: false, hostiles: 1 }).phase, 'melee');
    });
    await t('骷髅：hp<8 + 多只 → 全速脱离（撤退线）', () => {
        const bot = makeBot({ world: makeWorld() });
        const r = RS.decideSkeleton({ bot, skeleton: makeEntity({ name: 'skeleton' }), dist: 10, hp: 5, shield: true, hostiles: 3 });
        eq(r.phase, 'withdraw'); eq(r.minRange, 24); eq(r.reason, 'hp_low_multi_archers');
    });
    await t('骷髅掩体：站到断视线位置才被认可（且要 27 条射线全断）', () => {
        const solid = [...floorPlate(0, 64, 0), [3, 64, 0], [3, 65, 0], [3, 66, 0]];   // 3 格处一堵墙
        const bot = makeBot({ world: makeWorld({ solid }), pos: [0.5, 64, 0.5] });
        const cover = RS.pickCover(bot, makeEntity({ name: 'skeleton', pos: [8.5, 64, 0.5] }));
        ok(cover, '应找到掩体');
        // ⚠ 第七轮：reason 带上了余量读数（眼位周围 ±0.5 的 3×3×3 = 27 条射线全断）。
        //   原来这里写死 eq(reason,'los_broken')，只能证明"有一条断了"——那正是真服上失效的判据。
        ok(/^los_broken\(\d+\/27\)$/.test(cover.reason), `reason 应带余量读数，实际 ${cover.reason}`);
        eq(cover.margin, '27/27');
    });
    await t('末影人：<4 格 → 后撤（贴脸会被传送）', () => {
        const bot = makeBot({ world: makeWorld() });
        const r = RS.decideEnderman({ bot, enderman: makeEntity({ name: 'enderman' }), dist: 2 });
        eq(r.action, 'back_off'); eq(r.minRange, 5);
    });
    await t('末影人：头顶两格实心 → 蹲掩体', () => {
        const w = makeWorld({ solid: [[0, 65, 0], [0, 66, 0]] });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        eq(RS.decideEnderman({ bot, enderman: makeEntity({ name: 'enderman' }), dist: 20 }).action, 'crouch_cover');
    });
    await t('脱离判据：全部敌对 ≥24 格才算脱身', () => {
        const bot = makeBot({ world: makeWorld(), pos: [0.5, 64, 0.5] });
        const near = makeEntity({ id: 1, name: 'zombie', pos: [10.5, 64, 0.5] });
        const far = makeEntity({ id: 2, name: 'zombie', pos: [40.5, 64, 0.5] });
        eq(RS.isDisengaged(bot, [far]), true);
        eq(RS.isDisengaged(bot, [near, far]), false);
    });
}

// ==================================================================== T7 状态机（构造事件流）
G('T7 DefenseTask 状态机（设计 §3.4）');
{
    const T0 = 1_000_000;
    await t('IDLE→ASSESS→ENGAGE→CLEAR→IDLE 主线', () => {
        const s = DT.makeDefenseState({ wallMs: 30000 });
        const seq = [];
        const step = (input, now = T0) => { const r = DT.reduce(s, input, now); if (r.changed) seq.push(`${r.from}->${r.to}`); return r; };
        step({ type: 'trigger', name: 'zombie', id: 1, level: TT.THREAT_LEVEL.ENGAGED, dist: 9 });
        step({ type: 'assess_done', plan: { route: 'engage', action: 'melee' } });
        step({ type: 'beat_result', cleared: false });
        step({ type: 'beat_result', cleared: true });   // ENGAGE→CLEAR 必须由 beat_result 触发
        step({ type: 'cleared' });
        eq(seq.join(' '), 'IDLE->ASSESS ASSESS->ENGAGE ENGAGE->CLEAR CLEAR->IDLE');
        eq(s.state, DT.DefenseState.IDLE);
    });
    await t('墙钟到点强制降级为脱离（任务单硬要求①）', () => {
        const s = DT.makeDefenseState({ wallMs: 30000 });
        DT.reduce(s, { type: 'trigger', name: 'zombie', id: 1, level: TT.THREAT_LEVEL.ENGAGED, dist: 9 }, T0);
        DT.reduce(s, { type: 'assess_done', plan: { route: 'engage', action: 'melee' } }, T0 + 100);
        const r = DT.reduce(s, { type: 'beat_result', cleared: false }, T0 + 40000);   // 远超墙钟
        eq(r.reason, 'wall_deadline');
        eq(r.forced, true);
        eq(s.state, DT.DefenseState.DISENGAGE);
        eq(s.plan.minRange, 24, '强制脱离必须去 24 格');
        ok(s.actions.some((a) => a.action === 'deadline_force_disengage'), '应有墙钟强制动作记录');
    });
    await t('冻结期间不允许无限防御：到点必进 DISENGAGE（连续 10 拍都到点）', () => {
        const s = DT.makeDefenseState({ wallMs: 1000 });
        DT.reduce(s, { type: 'trigger', name: 'skeleton', id: 2, level: 2, dist: 10 }, T0);
        let t = T0;
        for (let i = 0; i < 10; i++) { t += 500; DT.reduce(s, { type: 'beat_result', cleared: false }, t); }
        eq(s.state, DT.DefenseState.DISENGAGE, '到点后必须脱离');
    });
    await t('同威胁连败 3 次 → 转脱离（设计 §3.2③）', () => {
        const s = DT.makeDefenseState({ wallMs: 600000 });
        DT.reduce(s, { type: 'trigger', name: 'skeleton', id: 2, level: 2, dist: 10 }, T0);
        DT.reduce(s, { type: 'assess_done', plan: { route: 'engage', action: 'melee' } }, T0);
        const r1 = DT.reduce(s, { type: 'engagement_failed', reason: 'a' }, T0 + 100);
        eq(r1.reason, 'retry_same_threat');
        DT.reduce(s, { type: 'engagement_failed', reason: 'b' }, T0 + 200);
        const r3 = DT.reduce(s, { type: 'engagement_failed', reason: 'c' }, T0 + 300);
        eq(r3.reason, 'fail_budget');
        eq(s.state, DT.DefenseState.DISENGAGE);
    });
    await t('失败预算按威胁分桶：换威胁不串味', () => {
        const s = DT.makeDefenseState({ wallMs: 600000 });
        DT.reduce(s, { type: 'trigger', name: 'skeleton', id: 2, level: 2, dist: 10 }, T0);
        DT.reduce(s, { type: 'assess_done', plan: { route: 'engage' } }, T0);
        DT.reduce(s, { type: 'engagement_failed' }, T0 + 10);
        DT.reduce(s, { type: 'engagement_failed' }, T0 + 20);   // skeleton 已 2 次
        eq(s.failures.get('skeleton'), 2);
        // 换威胁：升级抢占
        const esc = DT.reduce(s, { type: 'trigger', name: 'creeper', id: 3, level: 3, dist: 4 }, T0 + 30);
        eq(esc.reason, 'threat_escalated');
        eq(s.threat.name, 'creeper');
        eq(s.failures.get('creeper') ?? 0, 0, 'creeper 预算应为 0');
    });
    await t('已在防御中且新威胁不更高 → 不重派、不重置墙钟', () => {
        const s = DT.makeDefenseState({ wallMs: 30000 });
        DT.reduce(s, { type: 'trigger', name: 'skeleton', id: 2, level: 2, dist: 10 }, T0);
        const dl = s.deadlineAt;
        const r = DT.reduce(s, { type: 'trigger', name: 'zombie', id: 4, level: 2, dist: 8 }, T0 + 500);
        eq(r.reason, 'already_defending');
        eq(s.deadlineAt, dl, '墙钟不得被重置');
    });
    await t('低血 → 立即转脱离', () => {
        const s = DT.makeDefenseState({ wallMs: 30000 });
        DT.reduce(s, { type: 'trigger', name: 'zombie', id: 1, level: 2, dist: 9 }, T0);
        DT.reduce(s, { type: 'assess_done', plan: { route: 'engage' } }, T0);
        const r = DT.reduce(s, { type: 'beat_result', cleared: false, lowHp: true, hp: 5 }, T0 + 100);
        eq(r.reason, 'low_hp');
        eq(s.state, DT.DefenseState.DISENGAGE);
    });
    await t('决策直接是脱离时不浪费 ENGAGE 预算', () => {
        const s = DT.makeDefenseState({ wallMs: 30000 });
        DT.reduce(s, { type: 'trigger', name: 'creeper', id: 1, level: 3, dist: 3, fusing: true }, T0);
        const r = DT.reduce(s, { type: 'assess_done', plan: { route: 'disengage', minRange: 7, reason: 'fusing_retreat' } }, T0 + 10);
        eq(r.reason, 'plan_is_disengage');
        eq(s.state, DT.DefenseState.DISENGAGE);
    });
    await t('脱离完成 → 标回避 + 该威胁预算清零 + 回 IDLE', () => {
        const s = DT.makeDefenseState({ wallMs: 30000 });
        DT.reduce(s, { type: 'trigger', name: 'creeper', id: 1, level: 3, dist: 3, fusing: true }, T0);
        DT.reduce(s, { type: 'assess_done', plan: { route: 'disengage', minRange: 24 } }, T0 + 10);
        DT.reduce(s, { type: 'disengaged' }, T0 + 5000);
        eq(s.state, DT.DefenseState.IDLE);
        ok(s.avoid.has('creeper'), '应标记回避');
        eq(s.failures.get('creeper'), 0, '预算应清零');
        eq(s.threat, null);
    });
    await t('防御期间死亡 → 回 IDLE（交给既有死亡路径）', () => {
        const s = DT.makeDefenseState({ wallMs: 30000 });
        DT.reduce(s, { type: 'trigger', name: 'zombie', id: 1, level: 2, dist: 9 }, T0);
        DT.reduce(s, { type: 'assess_done', plan: { route: 'engage' } }, T0);
        const r = DT.reduce(s, { type: 'death' }, T0 + 300);
        eq(r.reason, 'death');
        eq(s.state, DT.DefenseState.IDLE);
    });
    await t('每次动作遥测都带威胁类型和距离（任务单硬要求②）', () => {
        const s = DT.makeDefenseState({ wallMs: 30000 });
        DT.reduce(s, { type: 'trigger', name: 'skeleton', id: 42, level: 2, dist: 11 }, T0);
        DT.reduce(s, { type: 'assess_done', plan: { route: 'engage' } }, T0);
        ok(s.actions.length >= 2);
        for (const a of s.actions) {
            eq(a.threat, 'skeleton', `动作 ${a.action} 缺威胁类型`);
            eq(typeof a.dist, 'number', `动作 ${a.action} 缺距离`);
            ok(typeof a.at === 'number', `动作 ${a.action} 缺时间戳`);
        }
    });
}

// ==================================================================== T8 中断/恢复契约（设计 §3.3 六行表）
G('T8 中断/恢复契约（设计 §3.3）');
{
    // —— 契约①：defenseActive 期间 checker 不采样；恢复后窗口重置 ——
    await t('契约① defenseActive 期间采样直接丢弃（不判卡死）', () => {
        const bot = makeBot({ world: makeWorld(), pos: [0.5, 64, 0.5] });
        const task = new ExecTask('T'); task.progressSignature = () => 'frozen';
        const ctx = makeFakeCtx(bot);
        ctx.run.counters.defenseFrozenSamples = 0;
        const chk = new ProgressChecker(task, ctx, { tickMs: 1, taskWindowMs: 10, hardWindowMs: 20, moveWindowMs: 10 });
        chk.update(ctx);                      // 正常采样一次，建立基线
        ctx.run.defenseActive = true;
        for (let i = 0; i < 50; i++) chk.update(ctx);   // 模拟战斗期间长时间不推进
        eq(chk.hardStuck(), false, '冻结期间不得判 hard stuck');
        eq(ctx.run.counters.defenseFrozenSamples, 50, '每次采样都应计入冻结通道');
        ctx.run.defenseActive = false;
        chk.update(ctx);
        eq(chk.lastProgressAt > chk._lastTickAt - 50, true, '恢复后窗口应被重置（lastProgressAt 被推到当前）');
    });
    await t('契约② 冻结期间 hard stuck 成立会留违规证据（硬线指标的数据源）', () => {
        const bot = makeBot({ world: makeWorld() });
        const task = new ExecTask('T'); task.progressSignature = () => 'x';
        const ctx = makeFakeCtx(bot);
        const chk = new ProgressChecker(task, ctx, { tickMs: 1, taskWindowMs: 5, hardWindowMs: 5, moveWindowMs: 5 });
        chk.hardFired = true;                 // 人为制造"已判死"
        ctx.run.defenseActive = true;
        chk.update(ctx);
        eq(ctx.run.counters.defenseStuckViolations, 1, '应记 1 次违规');
    });
    await t('契约③ DEFENSE_ABORT 不计入子任务失败预算', async () => {
        const bot = makeBot({ world: makeWorld() });
        const ctx = makeFakeCtx(bot);
        const stack = new TaskStack({ maxDepth: 6, maxFailures: 2 });
        ctx.stack = stack;
        class Boom extends ExecTask {
            constructor() { super('Boom'); }
            async tick(c) { this._fail(FailReason.DEFENSE_ABORT, { threat: 'zombie' }); }
        }
        // 同一个 key 连败 4 次（远超 maxFailures=2）——若 DEFENSE_ABORT 被计预算，
        // 第 3 次就该被 DEPENDENCY_BUDGET 拦下
        let lastStatus = null;
        for (let i = 0; i < 4; i++) {
            const t = await stack.run(ctx, 'k:test', 'Test', () => new Boom());
            lastStatus = t.failReason;
        }
        eq(lastStatus, FailReason.DEFENSE_ABORT, '4 次都应是 DEFENSE_ABORT，未被预算拦下');
        eq(stack.budgets.has('k:test'), false, '预算表里不该有这个 key');
        // 对照：普通失败必须照常计预算
        class Fail2 extends ExecTask { constructor() { super('F'); } async tick(c) { this._fail(FailReason.CRAFT_FAILED); } }
        await stack.run(ctx, 'k:normal', 'N', () => new Fail2());
        await stack.run(ctx, 'k:normal', 'N', () => new Fail2());
        const third = await stack.run(ctx, 'k:normal', 'N', () => new Fail2());
        eq(third.failReason, FailReason.DEPENDENCY_BUDGET, '普通失败的预算闸门仍应生效');
    });
    await t('契约④ 中断计数走独立通道（不污染 failCounts / summary.metrics 语义）', async () => {
        const run = makeRunState();
        const before = run.counters.deaths;
        run.counters.defenseInterrupts = 3;
        eq(run.counters.deaths, before, '中断不得改 deaths');
        ok('defenseInterrupts' in run.counters && run.counters.defenseInterrupts === 3);
        eq(run.defenseActive, false, '初始必须未冻结');
    });
    await t('契约⑤/⑥ 端到端：被抢占 → 防御 → 重入根任务（defenseActive 全程不泄漏）', async () => {
        const zombie = makeEntity({ id: 11, name: 'zombie', pos: [3.5, 64, 0.5] });
        const w = makeWorld({ solid: floorPlate(0, 64, 0) });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5], entities: [zombie], time: 1_000_000, killOnAttack: true });
        const r = await runScenario({ bot, defense: true });
        eq(r.status, 'SUCCESS', `根任务终态应为 SUCCESS，实际 ${r.status}/${r.failReason}`);
        eq(r.rootRuns, 2, '根任务应跑 2 轮（被抢占 + 重入）');
        eq(r.interrupts, 1, `应恰好中断 1 次，实际 ${r.interrupts}`);
        eq(r.metrics.defenseInterrupts, 1, '计数应走独立通道');
        ok(r.metrics.defenseActions > 0, '应有防御动作计数');
        // 冻结采样计数：通道必须存在；**行为**由上面的契约① 确定性覆盖。
        // 这里断言不了 >0 —— 本场景的防御轮 ~25ms 就结束（僵尸一刀死），
        // 而 ProgressChecker 的采样周期是 500ms，采样根本没落在冻结窗口内。
        // （顺带确认：防御期间**所有** checker 都被冻结，包括 DefenseTask 自己的 ——
        //  它的独立计时是墙钟上限，不是卡死判定，这与设计 §3.2③ 一致。）
        ok(typeof r.metrics.defenseFrozenSamples === 'number', '冻结采样计数通道必须存在');
        eq(r.metrics.defenseStuckViolations, 0, '硬线：冻结期间不得有 hard stuck');
        eq(r.defenseActiveLeak, 0, '防御结束后不得残留 defenseActive');
        ok(r.defenseStats && r.defenseStats.interrupts === 1, 'summary.defense 应带中断统计（设计 §5.2 指标 3）');
        ok(r.tree.includes('Defense('), '任务树里应出现 Defense 节点');
    });
    await t('对照组：defense:false 时根任务只跑 1 轮（与防御上线前等价）', async () => {
        const bot = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0) }), pos: [0.5, 64, 0.5], time: 1_000_000 });
        const r = await runScenario({ bot, defense: false });
        eq(r.rootRuns, 1, '不该有第二轮');
        eq(r.interrupts, 0);
        eq(r.status, 'SUCCESS');
        eq(r.defenseStats, null, '关防御时 summary.defense 应为 null');
    });
    // —— 裁决①（设计会话 10-02 夜）：防御层与凝视守卫都「默认关、显式开」——
    await t('裁决① 不传 defense ⇒ 默认关（不装层、不装守卫、循环只跑一轮）', async () => {
        const z = makeEntity({ id: 31, name: 'zombie', pos: [3.5, 64, 0.5] });
        const bot = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0) }), pos: [0.5, 64, 0.5], entities: [z], time: 1_000_000, killOnAttack: true });
        const r = await runScenario({ bot });            // ← 故意**不传** defense
        eq(r.rootRuns, 1, '默认关时根任务只应跑 1 轮');
        eq(r.interrupts, 0);
        eq(r.defenseStats, null, '默认关 ⇒ summary.defense 为 null');
        eq(r.status, 'SUCCESS');
        eq(z.id in bot.entities, true, '僵尸应还在（防御默认关 ⇒ 没人打过它）；这条断言是本测试的核心');
    });
    await t('裁决① defense:true 但不传 gaze ⇒ 守卫不装（lookAt 不被拦）', async () => {
        const z = makeEntity({ id: 32, name: 'zombie', pos: [3.5, 64, 0.5], height: 2.9 });
        const e = makeEntity({ id: 33, name: 'enderman', pos: [0.5, 64, 10.5], height: 2.9 });
        const bot = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0) }), pos: [0.5, 64, 0.5], entities: [z, e], time: 1_000_000, killOnAttack: true });
        const r = await runScenario({ bot, defense: true });    // 不传 defenseGazeGuard
        eq(r.status, 'SUCCESS');
        eq(r.defenseStats.gazeGuardInstalled, false, '默认不该装凝视守卫');
        eq(r.defenseStats.gazeRejects, 0);
    });
    await t('裁决① 显式 defenseGazeGuard:true ⇒ 守卫装上并留痕', async () => {
        const z = makeEntity({ id: 34, name: 'zombie', pos: [3.5, 64, 0.5] });
        const e = makeEntity({ id: 35, name: 'enderman', pos: [0.5, 64, 10.5], height: 2.9 });
        const bot = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0) }), pos: [0.5, 64, 0.5], entities: [z, e], time: 1_000_000, killOnAttack: true });
        const r = await runScenario({ bot, defense: true, defenseGazeGuard: true });
        eq(r.status, 'SUCCESS');
        eq(r.defenseStats.gazeGuardInstalled, true, '显式开应装上');
        ok(typeof r.defenseStats.gazeRejects === 'number', '拒绝次数必须可读（0 与"没装"靠 installed 区分）');
    });
    // —— 裁决②：整局防御总墙钟 ——
    await t('裁决② 总预算 0 ⇒ 一次都不抢占，但主任务仍跑到终态（不是被 break 掉）', async () => {
        const z = makeEntity({ id: 41, name: 'zombie', pos: [3.5, 64, 0.5] });
        const bot = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0) }), pos: [0.5, 64, 0.5], entities: [z], time: 1_000_000, killOnAttack: true });
        const r = await runScenario({ bot, defense: true, defenseTotalMs: 0 });
        eq(r.interrupts, 0, '预算为 0 ⇒ 一次防御都不该跑');
        ok(r.tele.some((x) => x.e === 'defense_budget_exhausted'), '应发 defense_budget_exhausted');
        eq(r.defenseStats.budgetExhausted, true);
        // ⚠ 两个"interrupts"语义不同，别混：defenseStats.interrupts = **层排队的**中断数
        //   （这一局是 1：层在耗尽前排过一次）；r.interrupts = **真跑起来的防御轮数**（0）。
        //   裁决②的语义就是"排了但不抢"。
        eq(r.defenseStats.interrupts, 1, '层排过 1 次中断（但 runtime 没执行）');
        ok(r.defenseStats.threatsSeen > 0, '耗尽后仍要「只记威胁」（threatsSeen 继续涨）');
        eq(r.rootRuns, 2, '根任务应被还回去重入并跑完');
        eq(r.status, 'SUCCESS', '关键：耗尽不能变成因防御而提前判负');
    });
    await t('裁决② 预算内跑防御，超额后转为只记不排', async () => {
        const z = makeEntity({ id: 42, name: 'zombie', pos: [3.5, 64, 0.5] });
        const bot = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0) }), pos: [0.5, 64, 0.5], entities: [z], time: 1_000_000, killOnAttack: false });
        // rootTicks=14 ⇒ 重入后根任务要跑 ~70ms 才成功（> 50ms 扫描周期），
        // 这样防御轮之后**必然**还有第二次中断，才验得到"超额 → 耗尽"这一步。
        // （第一版 rootTicks=2，重入 10ms 就成功、第二次中断没来，耗尽分支根本没被执行到。）
        const r = await runScenario({ bot, defense: true, defenseTotalMs: 1, wallMs: 60, rootTicks: 14 });
        ok(r.interrupts >= 1, `预算内应至少跑 1 次防御，实际 ${r.interrupts}`);
        ok(r.tele.some((x) => x.e === 'defense_budget_exhausted'), '超额后应发 defense_budget_exhausted');
        eq(r.defenseStats.budgetExhausted, true);
        const firstExhaust = r.tele.findIndex((x) => x.e === 'defense_budget_exhausted');
        const beginsAfter = r.tele.slice(firstExhaust).filter((x) => x.e === 'defense_begin').length;
        eq(beginsAfter, 0, '耗尽之后不得再发起防御');
        eq(r.status, 'SUCCESS');
    });
    await t('端到端：throttle 闸门（反复被抢占会提前收手，不会永不收敛）', async () => {
        const z = makeEntity({ id: 21, name: 'zombie', pos: [3.5, 64, 0.5] });
        const w = makeWorld({ solid: floorPlate(0, 64, 0) });
        // killOnAttack=false ⇒ 僵尸打不死 ⇒ 每次防御都会耗到墙钟并被反复抢占
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5], entities: [z], time: 1_000_000, killOnAttack: false });
        const t0 = Date.now();
        const r = await runScenario({ bot, defense: true, maxInterrupts: 2, wallMs: 60, neverSucceed: true });
        const ms = Date.now() - t0;
        ok(r.interrupts <= 3, `中断次数应被闸门限制，实际 ${r.interrupts}`);
        ok(['FAILED', 'TIMEOUT'].includes(r.status) || r.status === 'SUCCESS', `终态须为终态，实际 ${r.status}`);
        // 主判据是**行为**而不是时钟：「找不到脱离落点就转到任务超时」曾让这个场景烧 79s
        // （每轮各烧满 5s 任务超时 ×3）。修法是两次落空即收工并记 defense_disengage_unreachable。
        ok(r.tele.some((x) => x.e === 'defense_disengage_unreachable'),
            '应出现 defense_disengage_unreachable（证明是"收工"而不是"转到超时"）');
        ok(!r.tele.some((x) => x.e === 'defense_disengage_unreachable' && x.attempts > 2),
            '尝试次数不应超过 2 次');
        ok(ms < 12000, `throttle 场景不应退化到逐轮超时（曾 79s），实际 ${ms}ms`);
    });
}

// —— 端到端场景：用**真实 TaskRuntime** 驱动（不复制它的循环）——
//   僵尸在 3 格外、有地板、无墙 ⇒ DefenseLayer 的真实 500ms 扫描会命中它；
//   僵尸近战即死（killOnAttack）⇒ 全程不碰 navTo（离线边界，见 fake_world 的哨兵）。
async function runScenario({ bot, defense, defenseGazeGuard, maxInterrupts = 60, wallMs = 3000, defenseTotalMs = 120000, neverSucceed = false, rootTicks = 2 }) {
    const tele = [];
    const root = new (class extends ExecTask {
        constructor() { super('RootTask'); this.runs = 0; this._n = 0; }
        onStart() { this.runs++; }
        async tick() {
            this._n++;
            if (this._n >= rootTicks && !neverSucceed) this._succeed({ n: this._n });
        }
    })();

    const rt = new TaskRuntime(bot, {
        mission: { resource: 'iron_pickaxe', count: 1 },
        defense, defenseGazeGuard, defenseScanMs: 50, defenseWallMs: wallMs,
        defenseTotalMs, maxInterrupts,
        tickMs: 5,
    });
    rt.telemetry = (e, d) => { tele.push({ e, ...d }); };
    const summary = await rt.run(root);
    return {
        status: summary.status,
        failReason: summary.failReason,
        rootRuns: root.runs,
        interrupts: tele.filter((x) => x.e === 'defense_begin').length,
        metrics: summary.metrics,
        defenseStats: summary.defense,
        defenseActiveLeak: rt._ctx.run.defenseActive ? 1 : 0,
        tree: summary.taskTree,
        tele,
    };
}

// ==================================================================== T9 静态引用检查
G('T9 静态引用检查（TASK-08 r7 教训：语法/导出检查抓不到未定义标识符）');
{
    const EXEC_DIR = path.join(TASK_LAYER, 'src/agent/tasks/exec');
    // 新目录全部 + **本单改过的 4 个共享文件**。
    // 共享文件一并纳入是有代价换来的：`defenseSpentMs` 声明在 try 块内却在块外用，
    // 语法检查、导出检查、甚至"import 能不能解析"全都不会报，只有名字级检查会。
    const files = fs.readdirSync(path.join(EXEC_DIR, 'defense')).filter((f) => f.endsWith('.js')).map((f) => `defense/${f}`);
    for (const f of ['task_runner.js', 'task_stack.js', 'progress_checker.js', 'task.js']) files.push(f);
    const GLOBALS = new Set(['Math', 'JSON', 'Object', 'Array', 'Set', 'Map', 'Number', 'String', 'Boolean', 'Date', 'Error', 'Promise', 'RegExp', 'Symbol', 'Infinity', 'NaN', 'undefined', 'isNaN', 'parseInt', 'parseFloat', 'console', 'process', 'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval', 'Vec3', 'structuredClone', 'globalThis', 'this', 'null', 'true', 'false', 'sleep', 'window', 'module', 'exports', 'Buffer', 'URL', 'encodeURIComponent', 'decodeURIComponent', 'TextEncoder', 'queueMicrotask', 'Intl', 'Proxy', 'Reflect', 'WeakMap', 'WeakSet', 'TypeError', 'RangeError', 'Uint8Array', 'ArrayBuffer', 'performance']);
    for (const rel of files) {
        await t(`${rel}：无未定义标识符`, () => {
            const src = fs.readFileSync(path.join(EXEC_DIR, rel), 'utf8');
            // 收集已定义：import {a,b} / import x / const|let|var|function|class 名 + 参数 + 对象属性键
            const defined = new Set(GLOBALS);
            for (const m of src.matchAll(/import\s+([^;]+?)\s+from\s+['"][^'"]+['"]/g)) {
                const clause = m[1];
                for (const br of clause.matchAll(/\{([^}]*)\}/g)) {
                    for (const part of br[1].split(',')) {
                        const n = part.split(/\s+as\s+/).pop()?.trim();
                        if (n) defined.add(n);
                    }
                }
                const def = clause.replace(/\{[^}]*\}/g, '').replace(/^,|,$/g, '').trim();
                if (def) defined.add(def);
            }
            for (const m of src.matchAll(/\b(?:const|let|var|function|class)\s+([A-Za-z_$][\w$]*)/g)) defined.add(m[1]);
            for (const m of src.matchAll(/\bfunction\s*\*?\s*([A-Za-z_$][\w$]*)\s*\(([^)]*)\)/g)) {
                for (const p of m[2].split(',')) { const n = p.trim().split(/[=\s]/)[0]; if (n) defined.add(n); }
            }
            for (const m of src.matchAll(/\(([^)]*)\)\s*=>/g)) {
                for (const p of m[1].split(',')) { const n = p.trim().split(/[=\s]/)[0]; if (n && n !== '...') defined.add(n); }
            }
            for (const m of src.matchAll(/\(([^)]*)\)\s*\{/g)) {
                for (const p of m[1].split(',')) { const n = p.trim().split(/[=\s]/)[0]; if (n) defined.add(n); }
            }
            // 类方法名 / 对象字面量简写方法名：`^\s{2,}name(...)  {` 或 `(...) =>`
            // （漏掉这一类会把 defense_layer/defense_task 的所有方法误报成未定义）
            for (const m of src.matchAll(/^[ \t]{2,}(?:static\s+|async\s+|get\s+|set\s+|\*\s*)*([A-Za-z_$][\w$]*)\s*\(([^)]*)\)\s*(?:\{|=>)/gm)) {
                defined.add(m[1]);
                for (const p of m[2].split(',')) { const n = p.trim().split(/[=\s]/)[0]; if (n) defined.add(n); }
            }
            // 未定义引用：裸标识符出现在「调用或取值」位置
            const stripped = src
                .replace(/\/\*[\s\S]*?\*\//g, ' ')
                .replace(/\/\/[^\n]*/g, ' ')
                .replace(/(['"])(?:\\.|(?!\1).)*\1/g, ' ')
                .replace(/`(?:\\.|[^`\\])*`/g, ' ');
            const bad = new Set();
            for (const m of stripped.matchAll(/(?<![.\w$'"`])([a-z_$][\w$]*)\s*\(/g)) {
                if (!defined.has(m[1])) bad.add(m[1]);
            }
            // 单独排除 JS 内建原型方法
            const ignore = /^(require|import|export|if|for|while|switch|catch|return|typeof|await|new|throw|super|void|delete|do|else|try|finally|case|default|in|of|instanceof|yield|class|function|async|get|set|constructor)$/;
            const real = [...bad].filter((n) => !ignore.test(n));
            eq(real, [], `未定义标识符: ${real.join(', ')}`);
        });
    }
}

// ==================================================================== T10/T11 微基准支持逻辑
G('T10/T11 微基准支持逻辑（纯函数，离线可判）');
{
    // —— T10：fuse 元数据轨迹反推（设计会话给的 metadata[15] 假设必须能被数据证伪）——
    await t('T10 analyzeFuseTrace：能反推出"膨胀时翻转的索引"及其时刻/距离', () => {
        // 第三参 over = 该时刻 creep 是否已膨胀（模拟元数据翻转）
        const row = (ms, dist, over) => {
            const meta = Array(20).fill(0);
            if (over) meta[15] = 1;
            return { ms, dist, meta };
        };
        // 合成轨迹：12 格外一路走近，2.9 格时 15 号翻成 1
        const trace = [row(0, 12, false), row(100, 8, false), row(200, 5, false),
            row(300, 3.4, false), row(400, 2.9, true), row(500, 2.9, true)];
        const a = TT.analyzeFuseTrace(trace);
        eq(a.hypothesis15, true, '15 号假设应被数据支持');
        eq(a.hypothesis15Detail.index, 15);
        eq(a.hypothesis15Detail.from, 0);
        eq(a.hypothesis15Detail.to, 1);
        eq(a.hypothesis15Detail.dist, 2.9, '首次翻转在 over=true 的那一行（2.9 格），不是上一行 3.4');
        eq(a.samples, 6);
    });
    await t('T10 analyzeFuseTrace：索引猜错时能如实报"不支持"（不硬套 15）', () => {
        const row = (ms, dist, over) => {
            const meta = Array(20).fill(0);
            if (over) meta[11] = 1;          // 假设：其实变的是 11 号
            return { ms, dist, meta };
        };
        const trace = [row(0, 12, false), row(100, 6, false), row(200, 3, true), row(300, 3, true)];
        const a = TT.analyzeFuseTrace(trace);
        eq(a.hypothesis15, false, '15 号不该被"凑"成真');
        eq(a.best.index, 11, '反推出的真实索引应是 11');
    });
    await t('T10 analyzeFuseTrace：样本不足时安全返回（不抛、不瞎报）', () => {
        eq(TT.analyzeFuseTrace([]).changed, []);
        eq(TT.analyzeFuseTrace([{ ms: 0, dist: 1, meta: [0] }]).hypothesis15, false);
        eq(TT.analyzeFuseTrace(null).samples, 0);
    });
    await t('T10 creeperFusingMeta：读到 1 判膨胀、读到别的判不膨胀、缺字段返 null', () => {
        const mk = (v) => ({ metadata: Array(20).fill(0).map((_, i) => (i === 15 ? v : 0)) });
        eq(TT.creeperFusingMeta(mk(1)), true);
        eq(TT.creeperFusingMeta(mk(0)), false);
        eq(TT.creeperFusingMeta(mk(-1)), false);
        eq(TT.creeperFusingMeta({ metadata: [] }), null, '索引够不到时必须返 null（=未知，不是"没膨胀"）');
        eq(TT.creeperFusingMeta({}), null);
    });
    // —— T11：撤退几何（裁决 2：落点 ≥9、到位判据 ≥7.5）——
    await t('T11 decideCreeper 三个距离分开给（minRange/targetRange/safeRange）', () => {
        const bot = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0, 30) }), pos: [0.5, 64, 0.5], items: [] });
        const p = RS.decideCreeper({ bot, creeper: makeEntity({ name: 'creeper' }), dist: 5, fusing: true, hp: 20 });
        eq(p.route, 'disengage');
        eq(p.minRange, 7, 'wiki 取消引爆距离仍是判据');
        eq(p.targetRange, 9, '落点要留余量');
        eq(p.safeRange, 7.5, '到位以实际水平距离为准');
    });
    await t('T11 pickFleeSpot 按 ≥9 选点时，落点真的 ≥9 格', () => {
        const w = makeWorld({ solid: floorPlate(0, 64, 0, 30) });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        const creep = new Vec3(0.5, 64, 5.5);
        const spot = RS.pickFleeSpot(bot, creep, { minRange: 9 });
        ok(spot, '应找到落点');
        const d = Math.hypot(spot.pos.x - creep.x, spot.pos.z - creep.z);
        ok(d >= 9, `落点应 ≥9 格，实际 ${d.toFixed(2)}`);
    });
    // —— T12：接线后的性质（阳性对照已过：MIC_FUSEPROBE 实测 2.92 格时 metadata[15] 由 -1→1）——
    await t('T12 creeperFusingNow 走元数据：读到 1 立刻判 fuse，缺失时交给 <6 兜底', () => {
        const creep = (v) => ({ name: 'creeper', width: 0.6, metadata: Array(20).fill(0).map((_, i) => (i === 15 ? v : 0)) });
        eq(TT.creeperFusingNow(creep(1)), true);
        eq(TT.creeperFusingNow(creep(-1)), false);
        eq(TT.creeperFusingNow({ name: 'creeper', width: 1.3 }), false, 'width 变大也不算数（实测恒 0.6，接上是假信号）');
        eq(TT.creeperFusingNow({ name: 'creeper' }), false, '读不到元数据 ⇒ 未知按 false，交给 <6 兜底');
    });
    await t('T12 fuse 元数据的真正价值：确认 fuse 在烧 ⇒ 强制后撤路线（而不是贴脸击杀）', () => {
        const creep = (v) => ({ name: 'creeper', width: 0.6, metadata: Array(20).fill(0).map((_, i) => (i === 15 ? v : 0)) });
        const bot = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0, 30) }), items: [{ name: 'iron_sword', count: 1 }] });
        // 读到 1（fuse 在烧）时，即便满血带剑也必须后撤 —— 贴脸击杀来不及，fuse 只有 1.5s
        const armed = RS.decideCreeper({ bot, creeper: creep(1), dist: 2.9, fusing: true, hp: 20, armed: true });
        eq(armed.route, 'disengage', 'fuse 在烧时不能走击杀路线');
        eq(armed.reason, 'fusing_retreat');
        // 没读到（-1）时，满血带剑才允许贴脸
        const canKill = RS.decideCreeper({ bot, creeper: creep(-1), dist: 2.9, fusing: false, hp: 20, armed: true });
        eq(canKill.route, 'kill');
    });
    await t('T12 分级：2.92 格读到 fuse ⇒ EMERGENCY（reason=creeper_fusing）；>7 格则不算（wiki：拉开 7 格取消引爆）', () => {
        const on = TT.classify({ distance: 2.92, los: true, fusing: true });
        eq(on.level, TT.THREAT_LEVEL.EMERGENCY);
        eq(on.reason, 'creeper_fusing');
        // ⚠ 这条护栏是**有意的**：wiki 说 creep 拉开 7 格会取消引爆 ⇒ 10 格外还报 fuse 是假的
        const far = TT.classify({ distance: 10, los: true, fusing: true });
        eq(far.level, TT.THREAT_LEVEL.ENGAGED, '>7 格不该按"正在引爆"处理');
        // 没有 fuse 信号时，20 格外只是 MONITORED（10 格因为 < engaged 门槛 12 本来就是 ENGAGED）
        eq(TT.classify({ distance: 20, los: true, fusing: false }).level, TT.THREAT_LEVEL.MONITORED);
        eq(TT.classify({ distance: 10, los: true, fusing: false }).level, TT.THREAT_LEVEL.ENGAGED);
    });
}
    // —— T13：三组从未实跑的微基准，其**唯一量化判据**的离线覆盖 ——
//   背景：melee/skeleton/gaze 三组一直只跑过 n=3 的苦力怕组，从未实跑；预算是被
//   预约与内存挡住的（报告 §4.14）。而"三组的离线自检"当时是**空的**：
//   `meleeBeat`/`visibleHostiles`/`equipShield`/`raiseShield`/`hasShield`/`staringEndermen`
//   各 0 条用例。本组把三组的判据逻辑离线钉住 —— 实跑那三组时若失败，能立刻分清
//   是"生产原语坏了"还是"场景/闸门建错了"（手册 §5 微基准自检清单最后一条）。
G('T13 三组冒烟的判据逻辑（melee / skeleton / gaze）+ 两个真 bug 的回归钉子');
{
    // —— 凝视守卫：朝向读数 ——
    // 背景：mineflayer 4.38 的实体**没有** `look` 属性（prismarine-entity 只有
    // `yaw`/`pitch` 两个数字；`entities.js:927 fetchEntity` 就是 `new Entity(id)`）。
    // 原来的 `lookVector` 读 `e.look ?? {x:0,y:0}` ⇒ 线上恒取 {0,0} ⇒ 夹角判据整条是死的。
    // 而假 bot 自己造了 `entity.look`，所以自检一直是绿的 —— 这三条就是钉这个的。
    const mkG = (yaw, pitch, ePos) => makeBot({
        world: makeWorld(), pos: [0.5, 64, 0.5], yaw, pitch,
        entities: [makeEntity({ id: 7, name: 'enderman', pos: ePos, height: 2.9 })],
    });
    await t('T13 lookVector 读 entity.yaw/pitch，不读不存在的 entity.look（decoy 回归钉子）', () => {
        const bot = mkG(0, 0, [0.5, 64, 10.5]);
        // 故意塞一个"指向 -z"的诱饵：若代码还在读 entity.look，朝向会被带偏
        bot.entity.look = { x: Math.PI, y: 0 };
        const v = GG.lookVector(bot);
        ok(v, '应算出朝向向量');
        // ⚠ 第七轮更正：mineflayer **内部** yaw=0 面向 **−z**（内部 yaw = π − 线上 yaw，
        //   而线上 yaw=0 = 南 = +z ⇒ 内部 = π 才是 +z）。旧断言写 v.z>0.9 是跟着
        //   lookVector 那个 z 反号一起错的——**断言和被测代码同源错误时，断言是假的绿**。
        ok(v.z < -0.9 && Math.abs(v.x) < 1e-9, `内部 yaw=0 应朝 −z，实际 ${JSON.stringify(v)}`);
    });
    await t('T13 wouldStare 的 10° 夹角门是活的（正对 → 判盯上；偏 20° → 不判）', () => {
        // ⚠ 第七轮更正：末影人在 +z ⇒ bot **正对它**的内部 yaw 是 π（不是 0）。
        //   旧用例用 yaw=20° 配 +z 的末影人，夹角其实是 ~159°，"不判盯上"过得毫无信息量。
        const face = Object.values(mkG(Math.PI, 0, [0.5, 64, 10.5]).entities)[0];
        const rFace = GG.wouldStare(mkG(Math.PI, 0, [0.5, 64, 10.5]), face);
        ok(rFace.deg < 10, `正对时夹角应 <10°（几何 atan(Δy/d)），实际 ${rFace.deg?.toFixed(2)}`);
        eq(rFace.stare, true, '正对末影人必须判盯上（否则守卫形同虚设）');
        const bot20 = mkG(Math.PI + 20 * Math.PI / 180, 0, [0.5, 64, 10.5]);
        const r20 = GG.wouldStare(bot20, Object.values(bot20.entities)[0]);
        ok(r20.deg > 15, `偏航 20° 应给出 ~20° 夹角，实际 ${r20.deg?.toFixed(2)}`);
        eq(r20.stare, false, '超过 10° 阈值就不该判盯上（这条才是"门是活的"的证据）');
    });
    await t('T13 朝向读不到（yaw=NaN）按"会盯上"处理 —— 安全守卫不许漏判', () => {
        const bot = mkG(0, 0, [0.5, 64, 10.5]);
        bot.entity.yaw = NaN;
        const e = Object.values(bot.entities)[0];
        const r = GG.wouldStare(bot, e);
        eq(r.stare, true, '读不到朝向时必须保守判盯上');
        eq(r.reason, 'facing_unreadable');
    });
    await t('T13 safeLookAt 退路：bot.look 收两个数字、force=false、俯仰真压到 −15°、yaw 不被写成 NaN', () => {
        // ⚠ 第七轮：mkG(0,…) 原来表示"正对 +z 的末影人"，那是**线上约定**；
        //   内部约定下正对 +z 是 yaw=π（见 T14 钉子）。
        const bot = mkG(Math.PI, 0, [0.5, 64, 10.5]);
        eq(GG.safeLookAt(bot, new Vec3(0.5, 66.6, 10.5), {}), true, '正对末影人时应拒绝');
        eq(bot.calls.look.length, 1, '应调用过一次 bot.look');
        const [yawArg, pitchArg, forceArg] = bot.calls.look[0];
        // ↓ 这一条就是抓"把 Vec3 当 yaw 传"的钉子：真库里那会让 entity.yaw 变成 NaN
        ok(typeof yawArg === 'number' && Number.isFinite(yawArg), `yaw 必须是有限数字，实际 ${typeof yawArg}`);
        ok(typeof pitchArg === 'number' && Math.abs(pitchArg + 15 * Math.PI / 180) < 1e-9, `pitch 应为 −15°（弧度），实际 ${pitchArg}`);
        eq(forceArg, false, 'force 必须 false —— force=true 时 4.38 一个旋转包都不发（手册 §3）');
        eq(bot.calls.lookSent[0], true, 'force=false ⇒ 旋转包真的发出去了');
        const pitchDeg = bot.entity.pitch * 180 / Math.PI;
        ok(Math.abs(pitchDeg + 15) < 0.2, `实体俯仰应落到 −15° 附近，实际 ${pitchDeg.toFixed(2)}°`);
        ok(Number.isFinite(bot.entity.yaw), 'yaw 不得被污染成 NaN');
        ok(Math.abs(bot.entity.yaw - Math.PI) < 0.01, `yaw 应保持原值 π，实际 ${bot.entity.yaw}`);
    });
    await t('T13 没有人盯时不干预（守卫保持透明），也绝不发旋转包', () => {
        const bot = makeBot({ world: makeWorld(), pos: [0.5, 64, 0.5], entities: [makeEntity({ id: 1, name: 'zombie', pos: [0.5, 64, 5.5] })] });
        eq(GG.safeLookAt(bot, new Vec3(1, 2, 3), {}), false, '调用方应照常 lookAt');
        eq(bot.calls.look.length, 0, '不该动朝向');
    });
    await t('T13 staringEndermen 遍历对象型 bot.entities 不抛（提效条目②的回归钉子）+ 按距离排序', () => {
        // 4.x 的 bot.entities 是**以 id 为键的对象**，对它 for...of 会抛 not iterable
        const near = makeEntity({ id: 1, name: 'enderman', pos: [0.5, 64, 6.5], height: 2.9 });
        const far = makeEntity({ id: 2, name: 'enderman', pos: [0.5, 64, 12.5], height: 2.9 });
        const cow = makeEntity({ id: 3, name: 'cow', pos: [0.5, 64, 6.5] });   // type 用默认的 'mob'（真库 1.16.1 全是 mob）
        const bot = makeBot({ world: makeWorld(), pos: [0.5, 64, 0.5], yaw: Math.PI, pitch: 0, entities: [near, far, cow] });
        let out;
        try { out = GG.staringEndermen(bot); } catch (e) { throw new Error(`staringEndermen 抛了：${e.message}`); }
        eq(out.map((o) => o.entity.id), [1, 2], '应只收末影人且按距离升序');
    });

    // —— MeleeTick 冷却门（melee 组唯一的量化判据：最短出手间隔）——
    await t('T13 meleeBeat 冷却门端到端：首拍出手 → 同刻不出手 → 618ms 仍不出 → 625ms 出手', async () => {
        const w = makeWorld({ solid: floorPlate(0, 64, 0) });
        const z = makeEntity({ id: 7, name: 'zombie', pos: [1.5, 64, 0.5] });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5], time: 1_000_000, entities: [z], items: [{ name: 'stone_sword', count: 1, slot: 0 }] });
        const st = MT.makeMeleeState();
        const r1 = await MT.meleeBeat({ bot }, st, { dimensionId: 0 });
        eq(r1.fired, true, '首拍应出手');
        eq(r1.reason, 'fired');
        eq(r1.weapon, 'stone_sword', '应换手到石剑');
        eq(bot.calls.attack.length, 1);
        eq(bot.calls.lookAt[0][3], false, 'lookAt 必须 force=false，否则服务端按旧朝向打（手册 §3）');
        bot.time.time = 1_000_000;                                  // 同一刻
        const r2 = await MT.meleeBeat({ bot }, st, { dimensionId: 0 });
        eq(r2.fired, false);
        eq(r2.reason, 'cooldown');
        eq(bot.calls.attack.length, 1, '冷却未满不得重复出手');
        bot.time.time = 1_000_000 + 618;                            // 0.99×625 = 618.75，刚差一点
        const r3 = await MT.meleeBeat({ bot }, st, { dimensionId: 0 });
        eq(r3.reason, 'cooldown', `618ms 仍未到门（strength=${r3.strength?.toFixed(4)}）`);
        bot.time.time = 1_000_000 + 625;                            // 满冷却
        const r4 = await MT.meleeBeat({ bot }, st, { dimensionId: 0 });
        eq(r4.fired, true, '满冷却应再次出手');
        eq(bot.calls.attack.length, 2);
        eq(st.swings, 2);
    });
    await t('T13 melee 组的 560ms 下限有据：0.99 门在 618.75ms，余量 59ms', () => {
        const gateMs = TT.ATTACK_COOLDOWN_GATE * MT.weaponCooldownMs('stone_sword');
        ok(Math.abs(gateMs - 618.75) < 0.01, `0.99×625 应为 618.75，实际 ${gateMs}`);
        ok(gateMs > 560, 'scenarios.mjs 的 560ms 下限必须**低于**理论门限，否则会把抖动当违规');
        eq(MT.weaponCooldownMs('iron_axe'), 1000, '斧冷却 1.0s（设计 §2.1 标未核验，值取 1/1.0）');
    });
    await t('T13 visibleHostiles 只收「敌对 + 可见」：牛不算、墙后的僵尸不算', () => {
        const w = makeWorld({ solid: [...floorPlate(0, 64, 0), [5, 64, 0], [5, 65, 0], [5, 66, 0], [5, 67, 0]] });
        const zNear = makeEntity({ id: 1, name: 'zombie', pos: [2.5, 64, 0.5] });
        const zWall = makeEntity({ id: 2, name: 'zombie', pos: [10.5, 64, 0.5] });
        const cow = makeEntity({ id: 3, name: 'cow', pos: [2.5, 64, 0.5] });   // type 用默认的 'mob'（真库 1.16.1 全是 mob）
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5], entities: [zNear, zWall, cow] });
        eq(MT.visibleHostiles(bot, 0).map((e) => e.id), [1], '只该收近处那只僵尸');
    });
    await t('T13 回归钉子：真库 1.16.1 的 entity.type 全是 "mob"（无 hostile/animal）⇒ 按 type 预过滤会把敌对全跳光', () => {
        // 真值：minecraft-data('1.16.1').entitiesArray 的 type 分布 = {mob:101, UNKNOWN:6}
        // 1.16.1 **没有任何一个实体**的 type 是 'hostile' 或 'animal'。
        // 假 bot 的 makeEntity 默认 type 必须是 'mob' 才是忠实的。
        const z = makeEntity({ id: 1, name: 'zombie', pos: [2.5, 64, 0.5] });
        eq(z.type, 'mob', '假实体的默认 type 应为 mob（与真库一致）');
        const bot = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0) }), pos: [0.5, 64, 0.5], entities: [z] });
        eq(MT.visibleHostiles(bot, 0).map((e) => e.id), [1],
            'type="mob" 的敌对实体必须被收进来（旧实现按 hostile/animal 预过滤 ⇒ 恒空 ⇒ 近战在真服上从未生效）');
        // 玩家本人永远不是目标（名字判据已排除，这里额外钉住 type==='player' 这一支）
        const me = makeEntity({ id: 9, name: 'player', pos: [2.5, 64, 0.5], type: 'player' });
        const b2 = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0) }), pos: [0.5, 64, 0.5], entities: [z, me] });
        eq(MT.visibleHostiles(b2, 0).map((e) => e.id), [1], '玩家不得进目标集合');
    });

    // —— 盾牌（skeleton 组的 equipped/raised 记录项）——
    await t('T13 盾牌：无盾返回 false 而不是抛；有盾装得上、举得起、遥测带 250ms 激活延迟', () => {
        const none = makeBot({ world: makeWorld(), items: [] });
        eq(SH.hasShield(none), false);
        eq(SH.equipShield(none), false, '没盾必须返 false，不能抛');
        eq(SH.raiseShield(none), false);
        const b = makeBot({ world: makeWorld(), items: [{ name: 'shield', count: 1, slot: 3 }] });
        eq(SH.hasShield(b), true);
        eq(SH.equipShield(b), true);
        eq(b.calls.equip, ['shield']);
        const tele = [];
        eq(SH.raiseShield(b, { telemetry: (e, d) => tele.push([e, d]) }), true);
        eq(b.calls.activate, [true], '举盾走 activateItem(true)');
        eq(SH.isRaising(b), true);
        eq(tele.length, 1);
        eq(tele[0][0], 'shield_raise');
        eq(tele[0][1].activateMs, SH.SHIELD_ACTIVATE_MS);
        eq(SH.SHIELD_ACTIVATE_MS, 250, '1.16.1 激活延迟 5 tick = 250ms ⇒ 起盾必须提前');
    });
    await t('T13 skeleton 组的 LOS 判据用的是"真断视线"而不是"到了附近"', () => {
        // 有柱体 ⇒ 看不见；拆掉柱子 ⇒ 看得见。判据是 canSeeEntity，不是距离
        const pillar = [[5, 64, 0], [5, 65, 0], [5, 66, 0], [5, 67, 0]];
        const blocked = makeBot({ world: makeWorld({ solid: [...floorPlate(0, 64, 0), ...pillar] }), pos: [0.5, 64, 0.5] });
        const open = makeBot({ world: makeWorld({ solid: floorPlate(0, 64, 0) }), pos: [0.5, 64, 0.5] });
        const sk = makeEntity({ id: 9, name: 'skeleton', pos: [10.5, 64, 0.5] });
        eq(LOS.canSeeEntity(blocked, sk), false, '柱体后必须断视线');
        eq(LOS.canSeeEntity(open, sk), true, '无遮挡必须看得见');
    });
}

// ==================================================================== T14 第七轮真 bug 的回归钉子
// ① `los.js` 的 DDA 逐轴方向写错（bound 闭包 stepX）⇒ 空旷场地上把"看得见"读成"看不见"
// ② `pickCover` 单点采样、且从脚底发射线 ⇒ 掩体零余量（真服上骷髅走位 0.3 格就失效）
G('T14 第七轮：DDA 逐轴方向 + 掩体多射线余量');
{
    // —— ① 真服几何原样复原：MIC_MELEE_N3 的 botEye=[2.26,203.22,8.48]（被僵尸打飞、半空），
    //    僵尸眼位 y=202.755（feet 201 + 1.95×0.9），眼距 1.40 格。地板 y=200、其上全是空气。
    const ARENA_FLOOR = 200;
    const plate = floorPlate(2, 201, 8, 8);          // 地板 y=200，顶面 201
    const botEyeY = 201.6 + 1.62;                    // = 203.22（与真服读数逐位相同）
    const zEyeY = 201 + 1.95 * 0.9;                  // = 202.755
    await t('T14 空旷场地：目标在下方且在 +x 侧（异号几何）必须看得见', () => {
        const w = makeWorld({ solid: plate });
        const bot = makeBot({ world: w, pos: [2.26, 201.6, 8.48] });
        eq(Number(LOS.eyeOf(bot).y.toFixed(3)), 203.22, 'bot 眼位应与真服读数一致');
        // 方位角扫描：旧实现在 dx>0 的那一半（az 0..90 与 270..360）会把 1.4 格目标判成看不见
        const bad = [];
        for (let az = 0; az < 360; az += 15) {
            const dy = zEyeY - botEyeY;
            const dh = Math.sqrt(Math.max(0, 1.4 * 1.4 - dy * dy));
            const a = az * Math.PI / 180;
            const z = makeEntity({ id: 1, name: 'zombie', pos: [2.26 + dh * Math.cos(a), 201, 8.48 + dh * Math.sin(a)] });
            if (!LOS.canSeeEntity(bot, z)) bad.push(az);
        }
        eq(bad, [], `24 个方位角里有 ${bad.length} 个被误判成看不见：${bad.join(',')}°`);
    });
    await t('T14 逐格读数通道：hitKind + 每格方块名/boundingBox + t≤1 收尾', () => {
        const w = makeWorld({ solid: plate });
        const bot = makeBot({ world: w, pos: [2.26, 201.6, 8.48] });
        const z = makeEntity({ id: 1, name: 'zombie', pos: [3.578, 201, 8.48] });
        const from = LOS.eyeOf(bot), to = LOS.entityEye(z);
        const tr = LOS.raycastBlockTrace(bot, from, to, { trace: true });
        eq(tr.hit, null, '空旷场地应通视');
        eq(tr.hitKind, 'endpoint', '应停在终点格（不是撞墙、不是未加载）');
        ok(tr.cells.length <= 4, `1.4 格只该走 2~4 格，实际 ${tr.cells.length}（旧实现会走到 maxSteps=256）`);
        for (const c of tr.cells) {
            eq(c.name, 'air', `(${c.x},${c.y},${c.z}) 应是空气`);
            eq(c.boundingBox, 'empty');
            eq(c.loaded, true);
            ok(c.t >= 0 && c.t <= 1 + 1e-9, `t 必须落在 [0,1]，实际 ${c.t}`);
        }
        // 墙 ⇒ solid；未加载 ⇒ unloaded（"读失败"与"被墙挡住"必须能分开）
        // ⚠ 挡块必须落在**中间的格**上：起点格按设计不判遮挡，终点格是另一条分支
        //   （hitKind='endpoint_solid'/'endpoint'）。这条用 4 格外的目标，中间有 4 格可放。
        const zFar = makeEntity({ id: 2, name: 'zombie', pos: [6.578, 201, 8.48] });
        const toFar = LOS.entityEye(zFar);
        const trFar = LOS.raycastBlockTrace(bot, from, toFar, { trace: true });
        eq(trFar.hitKind, 'endpoint', '4 格外的空旷射线应停在终点格');
        ok(trFar.cells.length >= 4, `4 格远应走过 ≥4 格，实际 ${trFar.cells.length}`);
        const walled = makeBot({ world: makeWorld({ solid: [...plate, [4, 203, 8]] }), pos: [2.26, 201.6, 8.48] });
        const trW = LOS.raycastBlockTrace(walled, from, toFar, { trace: true });
        eq(trW.hitKind, 'solid', '中间格的挡块必须判 solid');
        eq(trW.hit.x, 4); eq(trW.hit.y, 203); eq(trW.hit.z, 8);
        const un = makeBot({ world: makeWorld({ solid: plate, unloadedFromX: 3 }), pos: [2.26, 201.6, 8.48] });
        const trUn = LOS.raycastBlockTrace(un, from, to, { trace: true });
        eq(trUn.hitKind, 'unloaded', '未加载必须是独立的 hitKind，不能与 solid 混同');
        eq(trUn.hit.unloaded, true);
    });
    await t('T14 零位移轴不得产生 NaN（Infinity*0 会让遍历永远挑同一根轴）', () => {
        const w = makeWorld({ solid: floorPlate(0, 64, 0) });
        const bot = makeBot({ world: w, pos: [0.5, 64, 0.5] });
        // dz=0（纯 x 方向）：tMaxZ 必须是 Infinity 而不是 NaN
        const tr = LOS.raycastBlockTrace(bot, new Vec3(0.5, 65.62, 0.5), new Vec3(10.5, 65.62, 0.5), { trace: true });
        eq(tr.hit, null);
        ok(tr.cells.every((c) => Number.isFinite(c.t)), '每格 t 都必须有限');
        ok(tr.cells.length <= 11, `纯 x 方向 10 格只该走 ≤11 格，实际 ${tr.cells.length}`);
    });

    // —— ② 掩体余量：单点断视线不算数
    await t('T14 losMargin：只断中心那一条 ⇒ 不算有效掩体（27 条要全断）', () => {
        // 眼位高度放**一格**挡块，且要放在**靠近目标**那一端（x=9）：
        // 挡块若放在远端（x=5），±0.5 的俯仰偏移射线在起点附近抬升不足 0.3 格、
        // 仍在同一层里 ⇒ 27 条全被挡，"没有余量"这条判据就测不出来了。
        const thin = [...floorPlate(0, 64, 0), [9, 65, 0]];
        const bot = makeBot({ world: makeWorld({ solid: thin }), pos: [0.5, 64, 0.5] });
        const sk = makeEntity({ id: 9, name: 'skeleton', pos: [10.5, 64, 0.5] });
        const eye = LOS.entityEye(sk);
        const m = LOS.losMargin(bot, LOS.eyeAt(new Vec3(1.5, 64, 0.5)), eye);
        eq(m.n, 27, '采样数必须是 3×3×3=27');
        eq(LOS.hasLineOfSight(bot, eye, LOS.eyeAt(new Vec3(1.5, 64, 0.5))), false, '中心那一条确实被挡（前提）');
        eq(m.all, false, '单格挡块只断一部分 ⇒ 必须判为"没有余量"');
        ok(m.broken > 0 && m.broken < 27, `应有部分断、部分不断（实际 ${m.broken}/27）`);
        eq(RS.pickCover(bot, sk), null, '只有部分断视线的落点不得被选成掩体（真服失效模式）');
    });
    await t('T14 losMargin：整面墙 ⇒ 27 条全断，落点被认可', () => {
        const wall = [[5, 64, 0], [5, 65, 0], [5, 66, 0], [5, 67, 0], [5, 68, 0]];
        const bot = makeBot({ world: makeWorld({ solid: [...floorPlate(0, 64, 0), ...wall] }), pos: [0.5, 64, 0.5] });
        const sk = makeEntity({ id: 9, name: 'skeleton', pos: [10.5, 64, 0.5] });
        const cover = RS.pickCover(bot, sk);
        ok(cover, '整面墙后应找到掩体');
        eq(cover.margin, '27/27');
    });
    await t('T14 pickCover 的射线从**眼位**发出，不是从脚底', () => {
        // 一格高的台阶挡得住"脚底射线"，挡不住"眼位射线" ⇒ 用脚底会把假掩体判成真掩体
        const step = [...floorPlate(0, 64, 0), [3, 64, 0]];      // 台阶顶面 y=65
        const bot = makeBot({ world: makeWorld({ solid: step }), pos: [0.5, 64, 0.5] });
        const sk = makeEntity({ id: 9, name: 'skeleton', pos: [10.5, 64, 0.5] });
        const fromEye = LOS.losMargin(bot, LOS.eyeAt(new Vec3(1.5, 64, 0.5)), LOS.entityEye(sk));
        ok(fromEye.broken < fromEye.n, '眼位射线应从台阶上方穿过去（所以没有有效掩体）');
        eq(RS.pickCover(bot, sk), null, '只挡脚底射线的台阶不得算掩体');
    });

    // —— ③ lookVector 的 y/z 符号：对着 **mineflayer 自己的 conversions** 钉，
    //    不对着我的推导钉（否则推导和代码同源错误时，钉子也是假的）。
    const reqLayer = createRequire(path.join(TASK_LAYER, 'package.json'));
    const conv = reqLayer('mineflayer/lib/conversions');
    const mkV = (yaw, pitch) => GG.lookVector(makeBot({ world: makeWorld(), pos: [0.5, 64, 0.5], yaw, pitch }));
    await t('T14 lookVector 的轴向：内部 yaw=π 面向 +z（南）、pitch 正 = 抬头', () => {
        const south = mkV(Math.PI, 0);                       // 线上 yaw 0 = 南 = +z
        ok(south.z > 0.999 && Math.abs(south.x) < 1e-9, `内部 yaw=π 应朝 +z，实际 ${JSON.stringify(south)}`);
        const north = mkV(0, 0);
        ok(north.z < -0.999, `内部 yaw=0 应朝 −z，实际 ${JSON.stringify(north)}`);
        const up = mkV(Math.PI, 30 * Math.PI / 180);
        ok(up.y > 0.49, `pitch=+30° 应抬头（y>0），实际 y=${up.y?.toFixed(3)}`);
        const down = mkV(Math.PI, -15 * Math.PI / 180);
        ok(down.y < -0.25, `pitch=−15°（行进默认俯仰）应低头（y<0），实际 y=${down.y?.toFixed(3)}`);
    });
    await t('T14 lookVector 与 mineflayer 的 conversions 逐轴一致（61×5 扫描）', () => {
        // 期望值走真库的换算：内部 (yaw,pitch) → 线上 (ψ,θ) → vanilla 朝向向量
        //   vanilla: (-sinψ·cosθ, -sinθ, cosψ·cosθ)
        let worst = 0, worstAt = null;
        for (let iy = 0; iy < 61; iy++) {
            for (const ip of [-80, -30, -15, 0, 30]) {
                const yaw = (iy / 60) * 2 * Math.PI, pitch = ip * Math.PI / 180;
                const psi = conv.toNotchianYaw(yaw) * Math.PI / 180;
                const th = conv.toNotchianPitch(pitch) * Math.PI / 180;
                const want = new Vec3(-Math.sin(psi) * Math.cos(th), -Math.sin(th), Math.cos(psi) * Math.cos(th));
                const got = mkV(yaw, pitch);
                for (const k of ['x', 'y', 'z']) {
                    const d = Math.abs(want[k] - got[k]);
                    if (d > worst) { worst = d; worstAt = { yaw: +(yaw * 180 / Math.PI).toFixed(1), pitch: ip, axis: k, want: +want[k].toFixed(4), got: +got[k].toFixed(4) }; }
                }
            }
        }
        ok(worst < 1e-9, `最大逐轴偏差 ${worst.toExponential(2)}（最大处 ${JSON.stringify(worstAt)}）`);
    });
}

// ==================================================================== T15 凝视阈值 10°→15°（第八轮）
// 阈值本身不是一个"调参"——它是**几何判据**：调错了两个方向都坏：
//   调太小 ⇒ 末影人近身时漏判（deg 随 d 递减 ⇒ 漏判在**近端**，不是远端，§4.16.9 已更正过一次方向）；
//   调太大 ⇒ 正常导航被拦；符号没修时还有更坏的一层：z 反号会让"末影人在背后"也算盯上
//             ⇒ 退路只压俯仰不动 yaw ⇒ **永久闩锁**（64 格内末影人大致在前方时所有 lookAt 全被吞）。
// 所以这一组的设计原则是：**每一条"应该拦"都必须配一条"必须放行"**，
// 只有正向断言的用例集，等于没测（θ 取 90 也是"全过"）。
G('T15 凝视守卫阈值 15°（几何判据，正反成对）');
{
    // 平地同高：bot 眼位 = 站位 64 + 1.62 = 65.62；末影人眼位 = 64 + 2.9×0.9 = 66.61 ⇒ Δy = 0.99
    const BOT_Y = 64, EYE_Y = 66.61, DY = EYE_Y - (BOT_Y + 1.62);
    const atDeg = (d) => (Math.atan(DY / d) * 180) / Math.PI;      // 平视 pitch=0 时的夹角
    /** 末影人在 +z 方向 d 格、方位角偏 phi 度（phi=0 即正前）；yaw 用**内部**约定。 */
    const mk = (yaw, pitch, { d, phi = 0, dz = null, height = 2.9 } = {}) => {
        const a = (phi * Math.PI) / 180;
        const z = dz ?? (d * Math.cos(a));
        const x = d * Math.sin(a);
        return makeBot({
            world: makeWorld(), pos: [0.5, BOT_Y, 0.5], yaw, pitch: (pitch * Math.PI) / 180,
            entities: [makeEntity({ id: 7, name: 'enderman', pos: [0.5 + x, BOT_Y, 0.5 + z], height })],
        });
    };
    const stareOf = (bot) => GG.wouldStare(bot, Object.values(bot.entities)[0]);
    const FACE_SOUTH = Math.PI;           // 内部 yaw=π = 面向 +z（末影人在 +z）

    await t('T15 常量就是 15°（阈值被谁改过都要在这里露出来）', () => {
        eq(TT.ENDERMAN.gazeGuardDeg, 15, 'gazeGuardDeg 应为 15');
    });
    await t('T15 模型锚点：d=6 → 9.37°、d=4 → 13.90°（与真服实测 9.37 吻合到 0.005°）', () => {
        ok(Math.abs(atDeg(6) - 9.37) < 0.005, `d=6 应≈9.37°，实际 ${atDeg(6).toFixed(4)}`);
        ok(Math.abs(atDeg(4) - 13.90) < 0.005, `d=4 应≈13.90°，实际 ${atDeg(4).toFixed(4)}`);
    });
    await t('T15 正向：平视正对时 4–16 格全程必须拦（θ=10 会漏掉 4、5 两格）', () => {
        for (const d of [4, 5, 6, 7, 8, 10, 12, 14, 16]) {
            const r = stareOf(mk(FACE_SOUTH, 0, { d }));
            ok(r.stare, `d=${d}（deg=${atDeg(d).toFixed(2)}）应判盯上并拦下 lookAt`);
            ok(r.deg < 15, `d=${d} 的 deg=${r.deg?.toFixed(2)} 应 < 15`);
        }
    });
    // —— 阴性对照组：没有这一组，θ=90 也能让上面全过 ——
    await t('T15 阴性：背对末影人 / 侧偏 / 低头挖矿 / 64 格外，四种都必须放行', () => {
        const back = stareOf(mk(0, 0, { d: 6 }));            // yaw=0 = 面向 −z，末影人在背后
        eq(back.stare, false, `背对必须放行（deg=${back.deg?.toFixed(1)}）`);
        const side20 = stareOf(mk(FACE_SOUTH, 0, { d: 6, phi: 20 }));
        ok(side20.deg > 15, `侧偏 20° 的 deg 应 >15，实际 ${side20.deg?.toFixed(2)}`);
        eq(side20.stare, false, '侧偏 20° 必须放行');
        const mine = stareOf(mk(FACE_SOUTH, -30, { d: 6 }));
        ok(mine.deg > 25, `低头 30° 的 deg 应 >25，实际 ${mine.deg?.toFixed(2)}`);
        eq(mine.stare, false, '挖矿低头必须放行（行进默认俯仰 −15° 不能被拦）');
        const far = stareOf(mk(FACE_SOUTH, 0, { d: 70 }));
        eq(far.stare, false, '64 格外不触发');
    });
    await t('T15 锥宽是 15° 附近而不是更宽：侧偏 10° 仍应拦', () => {
        // 这一条与上面"侧偏 20° 放行"成对：它证明判据既不是恒真也不是 90° 锥
        const r = stareOf(mk(FACE_SOUTH, 0, { d: 6, phi: 10 }));
        ok(r.deg < 15, `侧偏 10° 的 deg 应 <15，实际 ${r.deg?.toFixed(2)}`);
        eq(r.stare, true, '侧偏 10° 应仍在锥内被拦');
    });
    await t('T15 判据是严格小于：deg 恰等于 θ 时放行', () => {
        const bot = mk(FACE_SOUTH, 0, { d: 6 });
        const e = Object.values(bot.entities)[0];
        const deg = GG.wouldStare(bot, e).deg;
        eq(GG.wouldStare(bot, e, { thetaDeg: deg }).stare, false, 'deg < deg 必须为假（严格小于）');
    });
    // ★ 最贵的一条：把 §4.16.9 说的"永久闩锁"变成一个**可执行**的回归锁。
    //   守卫拒绝一次 lookAt 之后会把俯仰压到 −15°；如果那个姿态**仍然**被判成"在盯"，
    //   守卫就会把自己锁死——此后每一次 lookAt 都被拒、而退路永远不生效。
    //   符号反号时正是这样（末影人在背后 ⇒ 压俯仰也救不回来）。阈值从 10 调到 15
    //   把"压到 −15°后仍 <θ"的风险放大了（θ 越大越容易落进锥内），所以必须有这条钉子。
    await t('T15 闩锁回归锁：退路压到 −15° 之后必须能重新进入守卫（否则永久闩锁）', () => {
        for (const d of [4, 6, 10, 16, 40]) {
            const bot = mk(FACE_SOUTH, 0, { d });
            const e = Object.values(bot.entities)[0];
            ok(GG.wouldStare(bot, e).stare, `前提：d=${d} 平视应先被判盯上`);
            eq(GG.safeLookAt(bot, new Vec3(1, 2, 3)), true, `d=${d} 的 lookAt 应被守卫拒绝`);
            eq(bot.calls.look.length, 1, `d=${d} 应发出过 1 次退路 look（压俯仰）`);
            const after = GG.wouldStare(bot, e);
            ok(!after.stare, `d=${d} 退路之后 deg=${after.deg?.toFixed(2)} 仍 <15 ⇒ **永久闩锁**（守卫把自己锁死）`);
        }
    });
    await t('T15 已知残留缺口显式化：平视且 d ≤ 3.70 格仍判"不盯"（θ 单值模型的固有代价）', () => {
        // 0.99/tan(15°) = 3.695 ⇒ d 越小 deg 越大 ⇒ 近端反而放行。
        // 写成断言是让它成为**一条被记录的已知边界**，而不是哪天被人当 bug 顺手"修掉"。
        const near = stareOf(mk(FACE_SOUTH, 0, { d: 3.0 }));
        eq(near.stare, false, 'd=3.0 平视当前判不盯（已知缺口，报告 §4.17 已列给设计会话）');
        const edge = stareOf(mk(FACE_SOUTH, 0, { d: 3.70 }));
        ok(Math.abs(edge.deg - 15) < 0.05, `d=3.70 的 deg 应≈15°，实际 ${edge.deg?.toFixed(2)}`);
        const over = stareOf(mk(FACE_SOUTH, 0, { d: 3.71 }));
        eq(over.stare, true, '越过 3.70 就该进锥内');
    });
}

// ==================================================================== T16 creeper 组 × DDA 修复：不变性钉子（第八轮）
// 用途：creeper 组要送农场跑 n≥30，要拿它和**修复前**跑过的 creeper 数据并排比，
// 就必须钉住"DDA 修复对该组不是混淆项"。两层：
//   A 结构性（主证）：creeper 测量路径一次都不调用 LOS 射线 ⇒ 结构上不可能被影响。
//   B 几何性：即便去测，场景几何下新旧遍历同判；**并把边界钉成会红的钉子**（贴脸会分叉）。
// 全程离线：不连服、不占端口、不碰泳道。
G('T16 creeper 组与 DDA 修复的不变性（两层：结构性 + 几何边界）');
{
    const { ARENA, legacyRaycast } = await import('./micro/scenarios.mjs');
    const { legacyRaycastBlock } = await import('./analysis/dda_legacy.mjs');
    const CREEP_H = 1.7;                      // 1.16.1 苦力怕碰撞箱高〔wiki·Creeper〕
    // ⚠ 世界模型**照实建**：平台内 201..204 空气、y=200 石地板、**平台外与地板下 = 未加载(null)**。
    //   不能用 makeWorld({solid:…})——它把平台外也当空气，而旧遍历走出平台后会一路读到空气、
    //   march 到 maxSteps 返回 null（＝"看得见"）⇒ **分叉被假世界吃掉**。
    const arenaWorld = () => {
        const inA = (x, y, z) => x >= ARENA.minX && x <= ARENA.maxX && z >= ARENA.minZ && z <= ARENA.maxZ
            && y >= ARENA.floorY && y <= ARENA.clearTopY;
        return { at: (x, y, z) => {
            const X = Math.floor(x), Y = Math.floor(y), Z = Math.floor(z);
            if (!inA(X, Y, Z)) return null;
            const pos = new Vec3(X, Y, Z);
            if (X === ARENA.marker[0] && Y === ARENA.marker[1] && Z === ARENA.marker[2]) return { name: 'gold_block', boundingBox: 'block', position: pos };
            if (Y === ARENA.floorY) return { name: 'stone', boundingBox: 'block', position: pos };
            return { name: 'air', boundingBox: 'empty', position: pos };
        } };
    };
    /** bot 在 (8+fx, standY, 8+fz)、creep 在 (8.5, standY, 8.5+dz)：两套遍历的读数。 */
    const probe = (fx, fz, dz) => {
        const bot = makeBot({ world: arenaWorld(), pos: [8 + fx, ARENA.standY, 8 + fz] });
        const creep = makeEntity({ id: 1, name: 'creeper', pos: [8.5, ARENA.standY, 8.5 + dz], height: CREEP_H });
        const from = LOS.eyeOf(bot), to = LOS.entityEye(creep);
        const fx2 = LOS.raycastBlockTrace(bot, from, to, { trace: true });
        const lg = legacyRaycastBlock(bot, from, to);
        return { fx2, lg, diverge: (fx2.hit === null) !== (lg.hit === null) };
    };
    const FRACS = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9];

    await t('T16 眼位差 Δy=0.09 是"y 轴走不到"的根因（两套的 tMaxY 都 > 1）', () => {
        const bot = makeBot({ world: arenaWorld(), pos: [ARENA.cx, ARENA.standY, ARENA.cz] });
        const creep = makeEntity({ id: 1, name: 'creeper', pos: [8.5, ARENA.standY, 20.5], height: CREEP_H });
        eq(Number(LOS.eyeOf(bot).y.toFixed(3)), 202.62, 'bot 眼位（站位 + 1.8×0.9）');
        eq(Number(LOS.entityEye(creep).y.toFixed(3)), 202.53, 'creep 眼位（站位 + 1.7×0.9）');
        eq(Number((LOS.entityEye(creep).y - LOS.eyeOf(bot).y).toFixed(3)), -0.09, 'Δy 应为 −0.09');
        // 下一条 y 边界的参数：0.62/0.09 = 6.889 ≫ 1 ⇒ 遍历在到达终点前不会换 y 层
        const tMaxY = 0.62 / 0.09;
        ok(tMaxY > 1, `tMaxY=${tMaxY.toFixed(3)} 必须 > 1，否则 y 轴那个 bug 就会发作`);
    });
    await t('T16 名义几何（summon 点）新旧逐格一致', () => {
        const r = probe(0.5, 0.5, 12);
        eq(r.diverge, false, 'summon 那一刻必须同判');
        eq(r.fx2.hitKind, 'endpoint');
        eq(r.fx2.cells.length, 12, '12 格外的射线应走 12 格');
        eq(r.lg.hit, null, '修复前也应判通视');
    });
    await t('T16 水平距离 ≥1.5 格：100 个小数位置全零分叉（不变性的适用范围）', () => {
        // 刀口随扫描形状变（本扫描是 dz≥0.8，另一套独立扫描给的是 ≥1.5），
        // 所以断言取**两边都成立**的 1.5，不把某一个扫描形状的数字当常数。
        for (const dz of [1.5, 3, 5.5, 12]) {
            const bad = [];
            for (const fx of FRACS) for (const fz of FRACS) if (probe(fx, fz, dz).diverge) bad.push(`${fx}/${fz}`);
            eq(bad, [], `dz=${dz} 有 ${bad.length} 个分叉：${bad.slice(0, 6).join(' ')}`);
        }
    });
    await t('T16 反向钉子：贴脸 dz≤0.4 **必然**分叉（否则这条不变性声明就是空话）', () => {
        // 这条与上面那条成对：只钉"不变"不钉"会变"，那"不变"可能只是台架没跑到那里。
        for (const dz of [0.1, 0.2, 0.3, 0.4]) {
            const n = FRACS.filter((fx) => FRACS.filter((fz) => probe(fx, fz, dz).diverge).length).length;
            eq(n, 10, `dz=${dz} 应 10/10 个 frac_x 全部分叉，实际 ${n}/10`);
        }
        const r = probe(0.5, 0.5, 0.3);
        eq(r.fx2.hit, null, '修复后贴脸应通视（按 t∈[0,1] 收尾）');
        eq(r.fx2.hitKind, 'past_end');
        ok(r.lg.hit !== null, '修复前会一路 march 撞地板 ⇒ 判被挡（机制 A：缺 t≤1 收尾）');
        eq(r.lg.hitKind, 'solid');
    });
    await t('T16 机制 B：z 轴 tMax 方向取错 ⇒ 终点格永不可达（dz≈0.6、bot 偏离中心线）', () => {
        const r = probe(0.9, 0.9, 0.6);
        eq(r.diverge, true, '这一格应当分叉（机制 B 的阳性对照）');
        eq(r.fx2.hit, null, '修复后应一步踩到终点格');
        eq(r.fx2.cells.length, 1);
        ok(r.lg.cells.length > 5, `修复前应 march 很长一段（实际 ${r.lg.cells.length} 格）才撞上地板`);
        eq(r.lg.hitKind, 'solid');
    });
    await t('T16 两份"修复前副本"必须同判（dda_legacy vs scenarios.legacyRaycast）', () => {
        // 只比"都是 visible"的对照实现是没有信息量的 ⇒ 两种结论各取一个。
        for (const [label, dz, want] of [['dz=12（visible）', 12, 'visible'], ['dz=0.3（被挡）', 0.3, 'BLOCKED']]) {
            const bot = makeBot({ world: arenaWorld(), pos: [8.5, ARENA.standY, 8.5] });
            const creep = makeEntity({ id: 1, name: 'creeper', pos: [8.5, ARENA.standY, 8.5 + dz], height: CREEP_H });
            const from = LOS.eyeOf(bot), to = LOS.entityEye(creep);
            const a = legacyRaycastBlock(bot, from, to);
            const b = legacyRaycast(bot, from, to);
            const fa = a.hit ? `BLOCKED:${a.hitKind}@${a.hit.x},${a.hit.y},${a.hit.z}` : 'visible';
            const fb = b.hit ? `BLOCKED:${b.hitKind}@${b.hit.x},${b.hit.y},${b.hit.z}` : 'visible';
            eq(fa, fb, `${label}：两份修复前副本必须同判`);
            ok(fa.startsWith(want), `${label}：实际 ${fa}，与预期 ${want} 不符`);
        }
    });
    await t('T16 并列裁决的可复现性：新旧实现在"bot 恰站格边界"时**不等价**（第三条差异）', () => {
        // 修复前用严格 `<`、修复后用 `<=`：从格角出发的完美对角线上 tMaxX == tMaxZ，
        // 两者的并列裁决方向相反 ⇒ 访问格序列不同。独立复核在它自己的扫描里量到
        // "frac=0 的 5366 例分叉 745（13.9%）"。⇒ 这条必须被钉住：
        // ① 它是"旧 ≡ 新"这个声明的**第三个例外**（前两个是机制 A 收尾语义、机制 B 逐轴方向）；
        // ② 它在上一轮 T14 之后一直**没有覆盖**——变异测试 M8 把 `<=` 改回 `<` 时自检一条没红。
        const w = arenaWorld();
        const bot = makeBot({ world: w, pos: [ARENA.cx, ARENA.standY, ARENA.cz] });
        const from = new Vec3(8, 202, 8), to = new Vec3(12, 202, 12);   // 恰好格角出发的 x-z 完美对角线
        const seq = () => LOS.raycastBlockTrace(bot, from, to, { trace: true })
            .cells.map((c) => `${c.axis}${c.x},${c.y},${c.z}`).join(' ');
        const got = seq();
        eq(got, 'x9,202,8 z9,202,9 x10,202,9 z10,202,10 x11,202,10 z11,202,11 x12,202,11 z12,202,12',
            '并列裁决必须固定为"先 x"（<= 版本），且逐格可复现');
        eq(seq(), got, '同一几何重复跑必须逐格一致（可复现性）');
        // 反向对照：同一格序列必须被"修复前那套严格 <"判成不同 ⇒ 证明这条差异真实存在，
        // 不是我在自说自话（否则"钉住"钉的是一个不存在的差异）。
        const legacySeq = legacyRaycastBlock(bot, from, to).cells.map((c) => `${c.x},${c.y},${c.z}`).join(' ');
        ok(legacySeq !== got.replace(/[xz]/g, ''), `严格 < 的并列裁决应给出不同序列，实际 ${legacySeq}`);
    });
    await t('T16 结构性：creeper 测量路径的函数体里没有射线调用', () => {
        const RAY = ['raycastBlockTrace', 'raycastBlock', 'canSeeEntity', 'hasLineOfSight', 'losMargin', 'pickCover'];
        const braceBlock = (src, open) => {
            let depth = 0, str = null, line = false, blk = false;
            for (let k = open; k < src.length; k++) {
                const c = src[k], n = src[k + 1];
                if (line) { if (c === '\n') line = false; continue; }
                if (blk) { if (c === '*' && n === '/') { blk = false; k++; } continue; }
                if (str) { if (c === '\\') { k++; continue; } if (c === str) str = null; continue; }
                if (c === '/' && n === '/') { line = true; k++; continue; }
                if (c === '/' && n === '*') { blk = true; k++; continue; }
                if (c === '"' || c === "'" || c === '`') { str = c; continue; }
                if (c === '{') depth++;
                else if (c === '}' && --depth === 0) return src.slice(open, k + 1);
            }
            return null;
        };
        const DEF = path.join(TASK_LAYER, 'src/agent/tasks/exec/defense');
        const targets = [
            ['responses.js', ['decideCreeper', 'pickFleeSpot', 'groundSafe', 'standable', 'openSky', 'safeName']],
            ['melee_tick.js', ['bestWeapon', 'hasWeapon', 'isEntityGone']],
            ['threat_table.js', ['creeperFusingNow', 'creeperFusingMeta']],
            ['los.js', ['isSolid', 'blocksSight']],
        ];
        for (const [file, fns] of targets) {
            const src = fs.readFileSync(path.join(DEF, file), 'utf8');
            for (const fn of fns) {
                const m = new RegExp(`(?:export\\s+)?function\\s+${fn}\\s*\\(`).exec(src);
                ok(m, `${file}:${fn} 没找到——提取失败不能当成"干净"`);
                const body = braceBlock(src, src.indexOf('{', m.index));
                ok(body, `${file}:${fn} 函数体提取失败`);
                const hit = RAY.filter((n) => body.includes(n));
                eq(hit, [], `${file}:${fn} 竟然调用了 ${hit.join(',')} ⇒ creeper 路径已依赖 LOS，"与修复无关"这句失效`);
            }
        }
        // 场景块本身也不能偷偷调 LOS（路径用 import.meta.url 定位，别拼 ../..）
        const scen = fs.readFileSync(new URL('./micro/scenarios.mjs', import.meta.url), 'utf8');
        const i = scen.indexOf('    creeper: {');
        ok(i >= 0, 'scenarios.mjs 里找不到 creeper 场景块');
        const sbody = braceBlock(scen, scen.indexOf('{', i));
        ok(sbody, 'creeper 场景块提取失败');
        eq(RAY.filter((n) => sbody.includes(n)), [], 'creeper 场景块里出现了射线调用');
    });
}
const pass = results.filter((r) => r.ok).length;
const fail = results.filter((r) => !r.ok);
console.log(`\n═══ 离线自检：${pass}/${results.length} PASS ═══`);
const slowest = [...results].sort((a, b) => b.ms - a.ms).slice(0, 3);
console.log(`最慢 3 项：${slowest.map((r) => `${r.name} ${r.ms}ms`).join(' | ')}（总墙钟 ${results.reduce((a, r) => a + r.ms, 0)}ms）`);
if (fail.length) {
    console.log(`失败 ${fail.length} 项：`);
    for (const f of fail) console.log(`  - [${f.group}] ${f.name}\n    ${f.err}`);
    process.exit(1);
}
process.exit(0);
