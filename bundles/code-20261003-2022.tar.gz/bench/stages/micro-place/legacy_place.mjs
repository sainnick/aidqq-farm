// legacy_place.mjs — 当前（TASK-06b 版）放置口径的**原样复制**，只给微基准做「修复前」对照用。
// 来源：mindcraft/src/agent/tasks/exec/crafting_task.js::_placeOwnTable（候选扫描 + 8s withTimeout
// + placeBlock + 200ms 后 blockAt 验证 + badDests + 三轮走位），手持校验同 _ensureTableInHand。
// 任务层代码不在这里改；修好的原语在 mindcraft/src/agent/tasks/exec/place.js。

const LIQUIDS = new Set(['water', 'lava', 'flowing_water', 'flowing_lava']);
const REPLACEABLE = new Set(['air', 'cave_air', 'void_air', 'water', 'grass', 'tall_grass', 'fern', 'snow', 'dead_bush']);
const DYS = [-1, 0, 1, 2];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const posKey = (p) => `${p.x},${p.y},${p.z}`;

function withTimeout(promise, ms, label) {
    return new Promise((resolve, reject) => {
        const t = setTimeout(() => reject(new Error(label)), ms);
        promise.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); });
    });
}

/** 手持校验（同 _ensureTableInHand：equip 两次 + 复查 heldItem） */
async function ensureInHand(bot, item, trace) {
    for (let i = 0; i < 2; i++) {
        if (bot.heldItem?.name === item) return true;
        const it = bot.inventory.items().find((x) => x.name === item);
        if (!it) { trace.holdNoItem = (trace.holdNoItem ?? 0) + 1; return false; }
        try { await withTimeout(bot.equip(it, 'hand'), 5000, 'equip_timeout'); } catch (e) { trace.holdEquipFail = (trace.holdEquipFail ?? 0) + 1; }
        await sleep(300);
    }
    trace.holdMismatch = bot.heldItem?.name ?? null;
    return bot.heldItem?.name === item;
}

/**
 * 一次放置尝试（复刻 _placeOwnTable 的循环语义）。
 * @returns {{ok:boolean, reason:string, tried:number, detail:object}}
 */
export async function placeLegacy(bot, item, ctx = {}) {
    const maxTries = ctx.maxTries ?? 10;
    const rounds = ctx.rounds ?? 3;
    const badDests = new Set();
    const trace = { rejected: {}, holdRetry: 0, tried: 0, walkRounds: 0 };
    let lastFail = null;
    if (!(await ensureInHand(bot, item, trace))) return { ok: false, reason: 'hold_fail', tried: 0, detail: trace };

    for (let round = 0; round < rounds; round++) {
        if (round > 0) {
            const ang = Math.random() * Math.PI * 2;
            const dist = 4 + Math.floor(Math.random() * 3);
            const from = bot.entity.position.floored();
            const to = { x: Math.round(from.x + Math.cos(ang) * dist), y: from.y, z: Math.round(from.z + Math.sin(ang) * dist) };
            trace.walkRounds++;
            await new Promise((res) => {
                bot.pathfinder.goto(new ctx.GoalNear(to.x, to.y, to.z, 2)).then(() => res(), () => res());
                setTimeout(res, 12000);
            });
            await sleep(300);
        }
        const feet = bot.entity.position.floored();
        const candidates = [];
        for (const dy of DYS) for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
            if (dx === 0 && dz === 0 && dy <= 0) continue;
            candidates.push(feet.offset(dx, dy, dz));
        }
        candidates.sort((a, b) => bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b));
        for (const refPos of candidates) {
            if (trace.tried >= maxTries) break;
            const ref = bot.blockAt(refPos);
            if (!ref || ref.boundingBox !== 'block' || LIQUIDS.has(ref.name)) { trace.rejected.ref_not_solid = (trace.rejected.ref_not_solid ?? 0) + 1; continue; }
            const dest = refPos.offset(0, 1, 0);
            if (badDests.has(posKey(dest))) { trace.rejected.bad_dest = (trace.rejected.bad_dest ?? 0) + 1; continue; }
            const destBlock = bot.blockAt(dest);
            if (!destBlock || !REPLACEABLE.has(destBlock.name)) { trace.rejected.dest_not_replaceable = (trace.rejected.dest_not_replaceable ?? 0) + 1; continue; }
            if (dest.y >= feet.y && dest.y <= feet.y + 1
                && Math.abs(dest.x + 0.5 - bot.entity.position.x) < 0.85
                && Math.abs(dest.z + 0.5 - bot.entity.position.z) < 0.85) { trace.rejected.bbox_overlap = (trace.rejected.bbox_overlap ?? 0) + 1; continue; }
            if (bot.entity.position.distanceTo(dest) > 3.2) { trace.rejected.too_far = (trace.rejected.too_far ?? 0) + 1; continue; }
            trace.tried++;
            const attempt = { ref: [refPos.x, refPos.y, refPos.z], refName: ref.name, face: 'up', dest: [dest.x, dest.y, dest.z] };
            trace.attempt = attempt;
            const t0 = Date.now();
            try {
                await withTimeout(bot.placeBlock(ref, { x: 0, y: 1, z: 0 }), 8000, 'place_timeout');
            } catch (e) {
                const msg = String(e && e.message ? e.message : e);
                lastFail = { ...attempt, pos: [dest.x, dest.y, dest.z], error: msg.slice(0, 120), ms: Date.now() - t0 };
                if (/holding an item/i.test(msg)) {
                    trace.holdRetry++;
                    if (await ensureInHand(bot, item, trace)) continue;
                    return { ok: false, reason: 'hold_fail', tried: trace.tried, detail: { ...trace, lastFail } };
                }
                badDests.add(posKey(dest));
                continue;
            }
            await sleep(200);
            const placed = bot.blockAt(dest);
            if (placed && placed.name === item) return { ok: true, reason: 'ok', tried: trace.tried, detail: { ...trace, dest: [dest.x, dest.y, dest.z], ref: attempt.ref, refName: attempt.refName, face: 'up', clientBlockAfter: placed.name, ms: Date.now() - t0 } };
            badDests.add(posKey(dest));
            lastFail = { ...attempt, pos: [dest.x, dest.y, dest.z], error: `post-check ${placed?.name ?? 'null'}!=${item}`, clientBlockAfter: placed?.name ?? null, ms: Date.now() - t0 };
        }
        if (trace.tried >= maxTries) break;
    }
    return { ok: false, reason: lastFail ? 'place_fail' : 'no_candidate', tried: trace.tried, detail: { ...trace, lastFail, dest: lastFail?.pos ?? null, ref: lastFail?.ref ?? null, refName: lastFail?.refName ?? null } };
}
