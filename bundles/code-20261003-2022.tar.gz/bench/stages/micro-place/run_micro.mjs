// run_micro.mjs — MC-M1-TASK-06c P1 放置微基准编排（手册 §4.2「底层原语用微基准测」）。
//
// 2026-10-01 设计会话补充后**只复现一个场景**：bot 垂直下挖后站在竖井底部放工作台/熔炉
// （A 泳道 shaft，attempt 轮换 pure/ledge 两种井底），B 泳道 ground 当地面对照。
// 两条泳道并行，各泳道独立服务器/世界/bot；每次放置落一行记录，失败时补服务端真值。
// 原设计的三地形×三物品（平地/凹地/隧道）架子已删——MP_LEG 实测平地/凹地 180/180 全成功，
// 根本碰不到真局的失败，通用架子测不出东西。
//
// 用法：node run_micro.mjs --impl legacy|fixed --stamp M1 [--n 30] [--lanes 2]
//       [--terrains shaft,ground] [--items crafting_table,furnace]
// 产物：runs/<stamp>/lane_<T>/micro_results.jsonl + runs/<stamp>/micro_report.md + aggregate.json
// 收尾：自动 cleanup（停服、删世界、复核端口/进程），摘要落 runs/<stamp>/cleanup.txt

import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { argOf, buildLanes, bootServerWithRetry, stopServer, freshWorld, waitFreeMem, log } from '../_lib/runner_core.mjs';
import { preflight } from '../_lib/preflight.mjs';
import { cleanup, installRunnerHooks } from '../_lib/cleanup.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const NODE20 = path.join(ROOT, '.runtime/node-v20.20.2-win-x64/node.exe');
const JAR = path.join(TEMPLATE, process.env.MC_BENCH_JAR || 'server-1.16.1.jar');
const RCON_PASS = 'spike-rcon';

const IMPL = argOf(process.argv, 'impl', 'legacy');
const STAMP = argOf(process.argv, 'stamp', `MP_${IMPL}_${new Date().toISOString().slice(5, 16).replace(/[-T:]/g, '')}`);
const N = parseInt(argOf(process.argv, 'n', '30'), 10);
const LANES = parseInt(argOf(process.argv, 'lanes', '2'), 10);
const ITEMS = argOf(process.argv, 'items', 'crafting_table,furnace');
const TERRAINS = (argOf(process.argv, 'terrains', 'shaft,ground')).split(',');
const XMX = argOf(process.argv, 'server-xmx', '1G');
const LANE_CAP_MS = parseInt(argOf(process.argv, 'lane-timeout-ms', '2400000'), 10);

const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
fs.mkdirSync(RUNS_DIR, { recursive: true });
process.env.JAVA_TOOL_OPTIONS ||= '-Djava.net.preferIPv4Stack=true';
installRunnerHooks(() => `micro-place ${STAMP}`);

const t0 = Date.now();
log(`micro-place impl=${IMPL} terrains=${TERRAINS.join(',')} items=${ITEMS} n=${N} lanes=${LANES} → ${path.relative(ROOT, RUNS_DIR)}`);

const pf = await preflight({ killStale: true, requireLanes: LANES, logFn: log });
for (const l of pf.lines) log(`preflight:${l}`);
if (!pf.ok) { log('PREFLIGHT BLOCKED，不开跑'); process.exit(1); }

const lanesArr = buildLanes({ count: LANES, templateDir: TEMPLATE, jarPath: JAR, rconPass: RCON_PASS, logFn: log });
for (const l of lanesArr) l.java = JAVA;

const perLane = TERRAINS.slice(0, LANES).map((terrain, i) => ({ terrain, lane: lanesArr[i] }));
const seedFor = (terrain) => `MCPLACE-${terrain}-${STAMP}`;

const laneRuns = perLane.map(({ terrain, lane }) => {
    const dir = path.join(RUNS_DIR, `lane_${terrain}`);
    fs.mkdirSync(dir, { recursive: true });
    return { terrain, lane, dir };
});

const readTail = (p) => { try { return fs.readFileSync(p, 'utf8'); } catch { return ''; } };

async function runLane({ terrain, lane, dir }) {
    await waitFreeMem(2560 * 1048576, log); // 手册 §4.7 内存护栏（白天 2 条，第 3 条会排队）
    freshWorld(lane, seedFor(terrain));
    log(`lane ${lane.name} (${terrain}): booting :${lane.serverPort} seed=${seedFor(terrain)}`);
    const server = await bootServerWithRetry(lane, dir, XMX, log);
    log(`lane ${lane.name} (${terrain}): server up in ${(server.bootMs / 1000).toFixed(0)}s`);
    const botLog = fs.openSync(path.join(dir, 'bot_console.log'), 'w');
    const botArgs = [path.join(BENCH_DIR, 'place_bot.mjs'), '--out', dir, '--port', String(lane.serverPort),
        '--username', lane.username, '--terrain', terrain, '--impl', IMPL, '--n', String(N),
        '--items', ITEMS, '--seed', seedFor(terrain)];
    const bot = spawn(NODE20, botArgs, { cwd: BENCH_DIR, stdio: ['ignore', botLog, botLog] });
    try {
        // 等 bot 进服 → stdin 发 op → 写 setup.json 放行（服务端真值查询要权限）
        const tj = Date.now();
        while (!/joined the game/.test(readTail(path.join(dir, 'server.log'))) && Date.now() - tj < 120000) await new Promise((r) => setTimeout(r, 1000));
        if (!/joined the game/.test(readTail(path.join(dir, 'server.log')))) throw new Error('bot 60s 未进服');
        try { lane.serverChild = server.child; server.child.stdin.write(`op ${lane.username}\n`); } catch (e) { log(`lane ${lane.name}: op 发送失败 ${e}`); }
        await new Promise((r) => setTimeout(r, 1500));
        fs.writeFileSync(path.join(dir, 'setup.json'), JSON.stringify({ op: lane.username, at: new Date().toISOString() }));
        log(`lane ${lane.name} (${terrain}): bot 已 op，放行`);

        const td = Date.now();
        while (!fs.existsSync(path.join(dir, 'done.json')) && bot.exitCode === null && Date.now() - td < LANE_CAP_MS) {
            await new Promise((r) => setTimeout(r, 3000));
        }
        if (!fs.existsSync(path.join(dir, 'done.json'))) log(`lane ${lane.name} (${terrain}): 未完成（botExit=${bot.exitCode} ${((Date.now() - td) / 60000).toFixed(1)}min）`);
    } finally {
        try { bot.kill(); } catch { /* 忽略 */ }
        fs.closeSync(botLog);
        await stopServer(lane, server);
    }
    return { terrain, lane: lane.name };
}

const results = await Promise.all(laneRuns.map(async (r) => {
    try { await runLane(r); return { ...r, ok: true }; }
    catch (e) { log(`lane ${r.terrain} FAILED: ${String(e && e.message ? e.message : e).slice(0, 200)}`); return { ...r, ok: false, error: String(e) }; }
}));

// ---- 汇总 ----
const rows = [];
for (const r of laneRuns) {
    const p = path.join(r.dir, 'micro_results.jsonl');
    if (fs.existsSync(p)) for (const l of fs.readFileSync(p, 'utf8').split('\n').filter(Boolean)) { try { rows.push(JSON.parse(l)); } catch { /* 忽略 */ } }
}
const median = (a) => (a.length ? a.slice().sort((x, y) => x - y)[Math.floor((a.length - 1) / 2)] : null);
const cell = (terrain, item) => rows.filter((r) => r.terrain === terrain && r.item === item);
const byCellAgg = {};
for (const terrain of [...new Set(rows.map((r) => r.terrain))]) {
    byCellAgg[terrain] = {};
    for (const item of [...new Set(rows.map((r) => r.item))]) {
        const c = cell(terrain, item);
        if (!c.length) continue;
        const fails = c.filter((r) => !r.ok);
        byCellAgg[terrain][item] = {
            n: c.length, ok: c.length - fails.length, rate: +(((c.length - fails.length) / c.length) * 100).toFixed(1),
            reasons: Object.fromEntries(Object.entries(fails.reduce((m, r) => { m[r.reason] = (m[r.reason] ?? 0) + 1; return m; }, {}))),
            failMsMedian: median(fails.map((r) => r.ms)), okMsMedian: median(c.filter((r) => r.ok).map((r) => r.ms)),
            triedMedian: median(c.map((r) => r.tried)), tpsMedian: median(c.map((r) => r.tps).filter((x) => x != null)),
            failWithAckPacket: fails.filter((r) => (r.packetCount ?? 0) > 0).length,
            failServerHasBlock: fails.filter((r) => r.serverBlock && /minecraft:(?!air)/.test(r.serverBlock)).length,
            failHeldMismatch: fails.filter((r) => r.serverHeld && !r.serverHeld.includes(item)).length,
            failBboxOverlap: fails.filter((r) => r.bboxOverlapSelf).length,
            failMovedElsewhere: fails.filter((r) => (r.clientSeeBlocksNear ?? []).length > 0).length,
            failAckAtDest: fails.filter((r) => (r.updatesAtDest ?? []).length > 0).length,
            failNoUpdateAtDest: fails.filter((r) => (r.updatesAtDest ?? []).length === 0).length,
            failInvDropped: fails.filter((r) => /SelectedItem.Count'?: 0|Count': 0/.test(JSON.stringify(r.serverHeldCount ?? ''))).length,
            rejectedSum: fails.reduce((m, r) => { for (const [k, v] of Object.entries(r.rejected ?? {})) m[k] = (m[k] ?? 0) + v; return m; }, {}),
        };
    }
}
const totalOk = rows.filter((r) => r.ok).length;
// 失败机制对账：目标格 客户端 vs 服务端真值
const mech = { clientAirServerSolid: 0, serverAgree: 0, clientSolid: 0, noDest: 0, selfBox: 0 };
for (const r of rows) {
    if (r.bboxOverlapSelf) mech.selfBox++;
    if (r.ok) continue;
    if (!r.dest) { mech.noDest++; continue; }
    if (r.clientSawAirAtDest && r.serverAirAtDest === false) mech.clientAirServerSolid++;
    else if (r.clientSawAirAtDest) mech.serverAgree++;
    else mech.clientSolid++;
}
const perCellRates = Object.entries(byCellAgg).flatMap(([t, items]) => Object.entries(items).map(([i, v]) => `${t}/${i}: ${v.rate}%`));
// 按井底形态再切一刀（shaft 场景 pure/ledge 是两类不同的失败，合并看会掩盖）
const byShape = {};
for (const r of rows) {
    const k = `${r.terrain}/${r.shape ?? '-'}/${r.item}`;
    (byShape[k] ??= { n: 0, ok: 0, reasons: {}, failTries: [] });
    byShape[k].n++;
    if (r.ok) byShape[k].ok++;
    else { byShape[k].reasons[r.reason] = (byShape[k].reasons[r.reason] ?? 0) + 1; byShape[k].failTries.push(r.tried ?? 0); }
}
const shapeView = Object.fromEntries(Object.entries(byShape).map(([k, v]) => [k, {
    n: v.n, ok: v.ok, rate: +((v.ok / v.n) * 100).toFixed(1), reasons: v.reasons,
    triedMedian: median(v.failTries),
}]));
// 验收：P1 要求「每类 ≥98% + 放置失败中位 ≤1/30」——失败中位按「每 30 次里的失败次数」口径换算
const failPer30 = {};
for (const [t, items] of Object.entries(byCellAgg)) {
    for (const [i, v] of Object.entries(items)) {
        const cellFails = rows.filter((r) => r.terrain === t && r.item === i && !r.ok).length;
        failPer30[`${t}/${i}`] = +(cellFails / Math.max(1, v.n) * 30).toFixed(2);
    }
}
const agg = {
    stamp: STAMP, impl: IMPL, n: N, wallMin: +((Date.now() - t0) / 60000).toFixed(1),
    lanes: results.map((r) => ({ terrain: r.terrain, lane: r.lane, booted: r.ok, error: r.error ?? null })),
    total: rows.length, ok: totalOk, rate: +((totalOk / Math.max(1, rows.length)) * 100).toFixed(1),
    perCellRates, cells: byCellAgg, byShape: shapeView, failPer30, mech,
    acceptance: (() => {
        const cells = Object.values(byCellAgg).flatMap((items) => Object.entries(items));
        const all98 = cells.length > 0 && cells.every(([, v]) => v.rate >= 98);
        const medianFail = median(Object.values(failPer30));
        const medOk = medianFail !== null && medianFail <= 1;
        return { cells: cells.length, perCell98: all98, failPer30Median: medianFail, medianFailOk: medOk, pass: all98 && medOk };
    })(),
};
fs.writeFileSync(path.join(RUNS_DIR, 'aggregate.json'), JSON.stringify(agg, null, 2));

const md = [`# micro-place ${IMPL} — ${STAMP}`, '',
    `总尝试 ${rows.length}，成功 ${totalOk}（${agg.rate}%）；墙钟 ${agg.wallMin}min；泳道 ${results.map((r) => `${r.terrain}=${r.lane}${r.ok ? '' : '(BOOTFAIL)'}`).join(' ')}`, '',
    '| 地形 | 物品 | n | 成功率 | 失败原因 | 成功中位ms | 失败中位ms | tried中位 | TPS中位 | 失败时有block_change包 | 服务端目标格有块 | 服务端手持不符 | 自身碰撞箱占格 | 放到别处 |',
    '|---|---|---|---|---|---|---|---|---|---|---|---|---|---|'];
for (const [t, items] of Object.entries(byCellAgg)) {
    for (const [i, v] of Object.entries(items)) {
        md.push(`| ${t} | ${i} | ${v.n} | ${v.rate}% | ${JSON.stringify(v.reasons)} | ${v.okMsMedian} | ${v.failMsMedian} | ${v.triedMedian} | ${v.tpsMedian} | ${v.failWithAckPacket} | ${v.failServerHasBlock} | ${v.failHeldMismatch} | ${v.failBboxOverlap} | ${v.failMovedElsewhere} | ${v.failAckAtDest}/${v.failNoUpdateAtDest} |`);
    }
}
md.push('', '失败候选被扫描层拒绝的计数（rejectedSum）：', '```');
for (const [t, items] of Object.entries(byCellAgg)) md.push(`${t}: ${JSON.stringify(Object.fromEntries(Object.entries(items).map(([k, v]) => [k, v.rejectedSum])))}`);
md.push('```');
md.push('', `## 按井底形态（验收：每格 ≥98%，失败中位 ≤1/30）`, '',
    '| 地形/形态/物品 | n | 成功率 | 失败原因 | 失败时 tried 中位 |', '|---|---|---|---|---|');
for (const [k, v] of Object.entries(shapeView)) md.push(`| ${k} | ${v.n} | ${v.rate}% | ${JSON.stringify(v.reasons)} | ${v.triedMedian} |`);
md.push('', `每 30 次的失败次数（验收线 ≤1）：${JSON.stringify(failPer30)} → 中位 ${agg.acceptance.failPer30Median}；`
    + `每格≥98%=${agg.acceptance.perCell98}，失败中位≤1/30=${agg.acceptance.medianFailOk} → **${agg.acceptance.pass ? 'PASS' : 'FAIL'}**`);
md.push('', '## 失败机制对账（目标格：客户端看到的 vs 服务端真值）', '',
    `失败里「客户端认为是空气、服务端是实心」（幻影空气/旧数据）= **${mech.clientAirServerSolid}** 次；`
    + `服务端同意是空气但仍没放上（服务端另有拒收理由）= **${mech.serverAgree}** 次；`
    + `客户端本来就认为不是空气 = **${mech.clientSolid}** 次；无目标格可比 = ${mech.noDest} 次。`,
    `被挑中的目标格里，落在 bot 自己碰撞箱内的 = ${mech.selfBox} 次。`);
fs.writeFileSync(path.join(RUNS_DIR, 'micro_report.md'), md.join('\n') + '\n');
log(`汇总: ${totalOk}/${rows.length} (${agg.rate}%) 每格≥98%=${agg.acceptance.perCell98} → ${path.join(RUNS_DIR, 'micro_report.md')}`);

const cu = await cleanup({ label: `micro-place ${STAMP} ${IMPL}`, rmWorlds: true, dirs: laneRuns.map((r) => ({ dir: r.lane.dir, port: r.lane.serverPort })) });
fs.writeFileSync(path.join(RUNS_DIR, 'cleanup.txt'), cu.lines.join('\n') + '\n');
process.exit(agg.acceptance.pass ? 0 : 2);
