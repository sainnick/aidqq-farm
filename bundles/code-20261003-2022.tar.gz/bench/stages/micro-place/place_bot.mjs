// place_bot.mjs — MC-M1-TASK-06c P1 放置微基准的执行 bot（一泳道一进程，一种地形）。
//
// 干什么：进服 → 等 runner 把它 op（要查服务端真值）→ 用命令摆地形 → 3 种物品各放 N 次；
// 每次成功/失败都落一行记录；失败时额外查「服务端视角」：目标格方块、服务端认为手里拿着什么、
// 手里数量（据此区分：服务端拒收 / 放到别处了 / 手持脱同步 / 客户端丢了回包）。
// 姿势 still/moving 交替（moving = 寻路走动中放置，真局里大多数放置就是这么发生的）。
//
// 用法：node place_bot.mjs --out <runDir> --port 25566 --username TaskBot --terrain flat
//       --impl legacy|fixed --n 30 [--seed MCPLACE-flat-1]
// 地形与坐标全部由本 bench 自己摆（坐标只出现在 bench/experiments 与报告，不进任务层/MISSION）。

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = path.join(ROOT, 'mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const OUT = path.resolve(arg('out', BENCH_DIR));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const SEED = arg('seed', 'MCPLACE');
const TERRAIN = arg('terrain', 'flat');
const IMPL = arg('impl', 'legacy');
const N = parseInt(arg('n', '30'), 10);
const ITEMS = arg('items', 'crafting_table,furnace,cobblestone').split(',');
const MC_VERSION = arg('mc-version', '1.16.1');

const RES = path.join(OUT, 'micro_results.jsonl');
const SETUP = path.join(OUT, 'setup.json');
const DONE = path.join(OUT, 'done.json');
const SERVER_LOG = path.join(OUT, 'server.log');   // 服务端真值答案的权威来源（同步落盘）
fs.mkdirSync(OUT, { recursive: true });
for (const f of [RES, DONE]) { try { fs.rmSync(f, { force: true }); } catch { /* 忽略 */ } }
const log = (m) => console.log(`[${TERRAIN} ${new Date().toISOString().slice(11, 19)}] ${m}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const writeRow = (row) => fs.appendFileSync(RES, JSON.stringify(row) + '\n');

// 站点原点（bench 专用）
const SX = 200, SY = 68, SZ = 200;
// MC-M1-TASK-06c §1 设计会话补充：**只复现一个场景**——bot 垂直下挖后站在竖井底部放东西
// （现成遥测离线统计：铁链 328 次 place_fail 里 252 次紧跟在垂直下挖之后）。地形只剩
// ① shaft（竖井，按 attempt 轮换三种井底形态）② ground（地面对照）。不用 fill 复位。
//
// shaft 三种井底形态（都是「竖井 + 井底」的真实几何，候选数量递增）：
//   pure   ：严格 1×1、深 5 格的井，井底除了 bot 自己站的格子全是实心井壁 → 旧口径一个合格
//            候选都找不到（telemetry：34 次目标格就是 bot 自己站的格子那一类）；
//   ledge  ：同样 1×1 深 5，井底一侧踩开一格（下挖过程的产物）→ 有一格可放；
//   tunnel ：井底通向一条 5 格长、脚下高度+头顶高度两层的水平隧道——**telemetry 例子里失败目标格
//            在 bot 西侧 2–3 格、脚下高度**，只有这种「井底开进已有坑道」的形态才会出现；
//            候选很多（隧道地面一路可放），是最能压出失败率的形态。
const SHAFT_DEPTH = 5;
const SHAFT_AIR = (depth = SHAFT_DEPTH) => { const c = []; for (let y = SY - depth + 1; y <= SY; y++) c.push(`${SX} ${y} ${SZ}`); return c; };
const SHAFT_BOTTOM = (depth = SHAFT_DEPTH) => SY - depth + 1;
const TERRAINS = {
    ground: {
        stand: [SX + 0.5, SY + 1, SZ + 0.5],
        build: [
            `fill ${SX - 7} ${SY} ${SZ - 7} ${SX + 7} ${SY} ${SZ + 7} minecraft:stone`,
            `fill ${SX - 7} ${SY + 1} ${SZ - 7} ${SX + 7} ${SY + 8} ${SZ + 7} minecraft:air`,
        ],
        // 服务端真值：等这些格真的到位再开测（fill 2000 格的回包要好几秒，MP_SHAFT_LEG 踩过）
        expect: [{ x: SX, y: SY + 1, z: SZ, block: 'air' }, { x: SX + 2, y: SY, z: SZ, block: 'stone' }],
        walk: [[SX + 3, SY + 1, SZ + 3], [SX - 3, SY + 1, SZ - 3]],
    },
    shaft: {
        shapeOf: (i) => ['pure', 'ledge', 'tunnel'][i % 3],
        build: (shape, depth = SHAFT_DEPTH) => {
            const bot0 = SHAFT_BOTTOM(depth);
            const cmds = [
                `fill ${SX - 7} ${SY - 8} ${SZ - 7} ${SX + 7} ${SY} ${SZ + 7} minecraft:stone`,
                `fill ${SX - 7} ${SY + 1} ${SZ - 7} ${SX + 7} ${SY + 8} ${SZ + 7} minecraft:air`,
                // 1×1 竖井：逐格挖（模拟垂直下挖），正好 depth 格
                ...SHAFT_AIR(depth).map((c) => `setblock ${c} minecraft:air`),
            ];
            if (shape === 'ledge') {
                cmds.push(`setblock ${SX + 1} ${bot0} ${SZ} minecraft:air`);
                cmds.push(`setblock ${SX + 1} ${bot0 + 1} ${SZ} minecraft:air`);
            }
            if (shape === 'tunnel') {
                // 井底向西开一条 5 格长、2 层高的水平坑道（bot 脚部高度 + 头部高度）
                for (let d = 1; d <= 5; d++) {
                    cmds.push(`setblock ${SX - d} ${bot0} ${SZ} minecraft:air`);
                    cmds.push(`setblock ${SX - d} ${bot0 + 1} ${SZ} minecraft:air`);
                }
            }
            return cmds;
        },
        // 服务端真值闸门用的期望图：按形态区分「这一格应该是井壁石头还是被踩开的空气」。
        // （MP_SH3 踩过：不分形态的话，同一格在 pure 期望 stone、在 ledge 又期望 air，闸门永远不过。）
        expect: (shape, depth = SHAFT_DEPTH) => {
            const b0 = SHAFT_BOTTOM(depth);
            const east = shape === 'ledge' ? 'air' : 'stone';   // 井底东侧被踩开的那一格
            const west = shape === 'tunnel' ? 'air' : 'stone';  // 井底西侧通向坑道
            const e = [
                { x: SX, y: b0, z: SZ, block: 'air' },       // bot 站的格子
                { x: SX, y: b0, z: SZ + 1, block: 'stone' },  // 四面井壁（脚下高度）
                { x: SX, y: b0, z: SZ - 1, block: 'stone' },
                { x: SX + 1, y: b0, z: SZ, block: east },
                { x: SX - 1, y: b0, z: SZ, block: west },
                { x: SX, y: b0 + 1, z: SZ + 1, block: 'stone' },  // 头部高度井壁
                { x: SX, y: b0 + 1, z: SZ - 1, block: 'stone' },
                { x: SX + 1, y: b0 + 1, z: SZ, block: east },
                { x: SX - 1, y: b0 + 1, z: SZ, block: west },
                { x: SX, y: b0 - 1, z: SZ, block: 'stone' },  // 井底
                { x: SX, y: b0 + 2, z: SZ, block: 'air' },     // 井内上方
            ];
            if (shape === 'tunnel') {
                for (let d = 2; d <= 5; d++) e.push({ x: SX - d, y: b0, z: SZ, block: 'air' }, { x: SX - d, y: b0 + 1, z: SZ, block: 'air' });
            }
            return e;
        },
        stand: (shape, depth = SHAFT_DEPTH) => [SX + 0.5, SHAFT_BOTTOM(depth), SZ + 0.5],
    },
};

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const { Vec3 } = require('vec3');
    const implMod = IMPL === 'fixed'
        ? await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/place.js')).href)
        : await import(pathToFileURL(path.join(BENCH_DIR, 'legacy_place.mjs')).href);
    const placeImpl = IMPL === 'fixed' ? implMod.placeItem : implMod.placeLegacy;

    // 进服重试（手册 §2 的 loopback 抖动对客户端同样成立：MP_SHFIX_SMOKE laneA 就是
    // 服务器已 Done 之后 bot connect ETIMEDOUT 127.0.0.1:25566，整条泳道白跑）
    let bot = null;
    for (let a = 1; a <= 4; a++) {
        try {
            bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
            await new Promise((resolve, reject) => {
                bot.once('spawn', resolve);
                bot.once('error', reject);
                setTimeout(() => reject(new Error('spawn timeout 60s')), 60000);
            });
            break;
        } catch (e) {
            log(`connect 失败（第 ${a}/4 次）：${String(e && e.message ? e.message : e).slice(0, 120)}`);
            try { bot?.end?.(); } catch { /* 忽略 */ }
            bot = null;
            if (a === 4) throw e;
            await sleep(8000);
        }
    }
    log(`spawned pos=${bot.entity.position.toArray()}`);
    bot.loadPlugin(pf.pathfinder);

    // ---- 游戏内命令通道（op 权限；串行：打点 say → 发命令 → 收下一条回包）----
    let msgQueue = [];
    bot.on('message', (m) => { try { msgQueue.push(String(m.toString ? m.toString() : m)); } catch { msgQueue.push('?'); } });
    let seq = 0;
    async function cmd(text, { waitMs = 900 } = {}) {
        const id = `@@C${++seq}`;
        const asCmd = (t) => bot.chat(t.startsWith('/') ? t : `/${t}`);
        msgQueue = [];
        asCmd(`say ${id}`);
        const t0 = Date.now();
        while (Date.now() - t0 < 3000 && !msgQueue.some((s) => s.includes(id))) await sleep(25);
        msgQueue = [];
        asCmd(text);
        const tw = Date.now();
        while (Date.now() - tw < waitMs && !msgQueue.length) await sleep(25);
        await sleep(50);
        const reply = msgQueue.join(' | ');
        msgQueue = [];
        return reply || '(no-reply)';
    }

    // ---- 回包观察 + TPS（world age 增量/墙钟，手册 §4.7 口径）----
    const packets = [];
    const updates = [];
    let packetWindow = null;
    const blockName = (id) => { try { return bot.registry.blocks?.[id]?.name ?? id; } catch { return id; } };
    bot._client.on('block_change', (p) => { if (packetWindow) packets.push({ ev: 'block_change', pos: [p.location.x, p.location.y, p.location.z], type: p.type, t: Date.now() - packetWindow }); });
    bot._client.on('multi_block_change', (p) => { if (packetWindow) packets.push({ ev: 'multi_block_change', pos: [p.chunkX ?? 0, 0, p.chunkZ ?? 0], type: p.records?.length ?? 0, t: Date.now() - packetWindow }); });
    let tps = null, tpsWin = [];
    setInterval(() => {
        try {
            const age = bot.time?.age;
            if (age == null) return;
            tpsWin.push([age, Date.now()]);
            while (tpsWin.length > 12) tpsWin.shift();
            const a = tpsWin[0], b = tpsWin.at(-1);
            if (b[1] - a[1] >= 1000) tps = +(((b[0] - a[0]) / ((b[1] - a[1]) / 1000)).toFixed(2));
        } catch { /* 忽略 */ }
    }, 1000);

    bot.world.on('blockUpdate', (o, n) => {
        if (!packetWindow || !o || !n) return;
        updates.push({ pos: o.position.toArray(), from: blockName(o.id), to: blockName(n.id), t: Date.now() - packetWindow });
    });
    await sleep(3500);

    const tOp = Date.now();
    while (!fs.existsSync(SETUP) && Date.now() - tOp < 120000) await sleep(300);
    if (!fs.existsSync(SETUP)) throw new Error('runner 未写 setup.json（op 没完成）');
    log('op ready');

    const T = TERRAINS[TERRAIN];
    if (!T) throw new Error(`unknown terrain ${TERRAIN}`);
    const shapeOf = (i) => (T.shapeOf ? T.shapeOf(i) : '-');
    const buildFor = (i) => (Array.isArray(T.build) ? T.build : T.build(shapeOf(i)));
    const standFor = (i) => (Array.isArray(T.stand) ? T.stand : T.stand(shapeOf(i)));
    const expectFor = (i) => (Array.isArray(T.expect) ? T.expect : T.expect(shapeOf(i)));
    /** 服务端真值查询：这一格在服务端是不是指定方块。
     *  ★ 走 server.log 而不是聊天回包。MP_SH3 踩过两个坑：
     *    ① 标记必须每次唯一——共用 @@Y 时，上一条命令的回包会被当成本条结果（假通过）；
     *    ② 聊天回包会迟到——大 fill 还在处理时 execute 查询被排在后面，500ms 窗口早就关了，
     *       迟到的回包落进下一条命令的窗口 → 明明是石头却判成「不是」（假失败，闸门 60s 都不通过）。
     *  server.log 是同步落盘的，标记出现在日志里就是服务端真的答了。 */
    const isBlock = async (c) => {
        const id = `@@Y${++seq}`;
        // 命令照旧从客户端聊天通道发（bot 没有服务器 stdin），但**答案**只看 server.log。
        await cmd(`execute if block ${c.x} ${c.y} ${c.z} minecraft:${c.block} run say ${id}`, { waitMs: 120 });
        const t0 = Date.now();
        while (Date.now() - t0 < 5000) {
            try { if (fs.readFileSync(SERVER_LOG, 'utf8').includes(id)) return true; } catch { /* 日志还没建 */ }
            await sleep(60);
        }
        return false;
    };
    for (const it of ITEMS) await cmd(`give @s minecraft:${it} 64`);
    // 真局里走到井底时手上一定有镐（石镐/铁镐）。竖井修复要「挖开一格井壁当壁龛」，
    // 空手挖石头 7.5s 会把修复本身变成新的慢点，所以给一把铁镐（bench 侧 dev kit，不进正式矩阵）。
    if (TERRAIN === 'shaft') await cmd('give @s minecraft:iron_pickaxe 1', { waitMs: 400 });
    // ★ 摆地形时 bot 必须站在 fill 体积外面。
    //   MP_SH3 踩过：fill 把 bot 正在站的那一格也填成石头 → 服务端把 bot 从方块里弹出去 →
    //   扫描时的 feet 已经不在井底，碰撞箱自检整个失效（记录里出现过 dest=bot 自己那格却没被拒），
    //   后面所有数字都不可信。等候点选在 build 体积正上方、同一个区块内（跨区块会触发
    //   update_light 空列，见下面 tp 只走同区块的说明）。
    const STAGE = [SX - 4.5, SY + 1, SZ + 0.5];
    await cmd(`tp ${STAGE[0]} ${STAGE[1]} ${STAGE[2]}`, { waitMs: 600 });
    await sleep(2500);
    let sIdx = -1;
    const setupOnce = async (i) => {
        const s = standFor(i);
        await cmd(`tp ${STAGE[0]} ${STAGE[1]} ${STAGE[2]}`, { waitMs: 300 });
        await sleep(500);
        for (const c of buildFor(i)) await cmd(c, { waitMs: 500 });
        // ★ 服务端真值闸门：这些格没真的到位就不开测。
        //   MP_SHAFT_LEG 踩过：fill 2000 格的回包要好几秒，期间就发放置包，量到的全是「地形还没摆好」
        //   的假成功率（117/117），连目标格都落在本该是实心井壁的地方。
        const want = expectFor(i);
        const t0 = Date.now();
        let pending = want;
        while (Date.now() - t0 < 60000) {
            pending = [];
            for (const c of want) if (!await isBlock(c)) pending.push(c);
            if (!pending.length) break;
            await sleep(700);
        }
        if (pending.length) log(`⚠ 地形未按预期就位（服务端真值），仍继续：${JSON.stringify(pending)}`);
        else log(`terrain ok (${shapeOf(i)}) 服务端真值通过，${((Date.now() - t0) / 1000).toFixed(1)}s`);
        // 走进井底（与等候点同一个区块，不触发区块卸载/重载）
        await cmd(`tp ${s[0]} ${s[1]} ${s[2]}`, { waitMs: 300 });
        await sleep(1400);
        if (Math.abs(bot.entity.position.x - s[0]) > 0.6 || Math.abs(bot.entity.position.y - s[1]) > 1.2) {
            log(`⚠ 站位没到位 bot=${bot.entity.position.toArray().map((v) => v.toFixed(1))} want=${s}`);
        }
    };
    await setupOnce(0);
    sIdx = 0;
    log(`terrain ready; pos=${bot.entity.position.toArray()} held=${bot.heldItem?.name}`);

    const ctx = { GoalNear: pf.goals.GoalNear, maxTries: 10, rounds: 3 };
    let walkToggle = 0, attempts = 0;
    const tStart = Date.now();
    for (const item of ITEMS) {
        const blockId = bot.registry.blocksByName[item]?.id;
        for (let i = 0; i < N; i++) {
            // 竖井场景：每次尝试都重新摆一次井底（对应真局「又往下挖了一格、站在新的井底」），
            // 且必须等服务端真值确认地形到位（见 setupOnce）。地面对照：still/moving 交替。
            const shape = shapeOf(i);
            if (shape !== shapeOf(sIdx) || Array.isArray(T.build)) await setupOnce(i);
            sIdx = i;
            const posture = TERRAIN === 'shaft' ? 'still' : (i % 2 === 0 ? 'still' : 'moving');
            const held = bot.inventory.items().find((x) => x.name === item);
            if (!held || held.count < 4) await cmd(`give @s minecraft:${item} 32`, { waitMs: 400 });
            try { await bot.equip(bot.inventory.items().find((x) => x.name === item), 'hand'); } catch { /* impl 会自查手持 */ }
            await sleep(150);

            let moveStart = 0;
            if (posture === 'moving' && T.walk) {
                const w = T.walk[walkToggle++ % T.walk.length];
                moveStart = Date.now();
                bot.pathfinder.goto(new pf.goals.GoalNear(w[0], w[1], w[2], 1)).catch(() => { });
            }
            packets.length = 0;
            updates.length = 0;
            packetWindow = Date.now();
            const t0 = Date.now();
            let out;
            try { out = await placeImpl(bot, item, ctx); }
            catch (e) { out = { ok: false, reason: 'impl_threw', tried: 0, detail: { error: String(e && e.message ? e.message : e).slice(0, 200), stack: String(e && e.stack ? e.stack : '').split('\n').slice(0, 4).join(' | ').slice(0, 400) } }; }
            const ms = Date.now() - t0;
            packetWindow = null;
            if (posture === 'moving') { try { bot.pathfinder.stop(); } catch { /* 忽略 */ } await sleep(200); }

            // dest/ref 的归一化：legacy 返回数组，place.js 返回 Vec3/普通对象，统一成数组
            const asArr = (v) => (v == null ? null : Array.isArray(v) ? v : [v.x, v.y, v.z].map((n) => Math.round(n)));
            const dest = asArr(out.dest ?? out.detail?.dest ?? out.detail?.lastFail?.pos ?? null);

            const rec = {
                terrain: TERRAIN, shape, impl: IMPL, item, i, posture, seed: SEED,
                ok: !!out.ok, reason: out.reason, tried: out.tried ?? 0, ms, tps,
                moveMs: posture === 'moving' ? Date.now() - moveStart : 0,
                pos: [+bot.entity.position.x.toFixed(2), +bot.entity.position.y.toFixed(2), +bot.entity.position.z.toFixed(2)],
                onGround: !!bot.entity.onGround,
                clientHeld: bot.heldItem?.name ?? null,
                invCount: bot.inventory.items().filter((x) => x.name === item).reduce((s, x) => s + x.count, 0),
                rejected: out.detail?.rejected ?? null,
                packets: packets.map((p) => `${p.ev}@${p.pos.join(',')}#${p.type}`).slice(0, 8),
                packetCount: packets.length,
                lastError: out.detail?.lastFail?.error ?? out.detail?.error ?? null,
                dest,
                ref: asArr(out.ref ?? out.detail?.ref ?? out.detail?.lastFail?.ref ?? null),
                refName: out.refName ?? out.detail?.refName ?? out.detail?.lastFail?.refName ?? null,
                face: out.face ?? out.detail?.face ?? (out.detail?.lastFail?.face ?? 'up'),
                clientBlockAfter: dest ? (bot.blockAt(new Vec3(dest[0], dest[1], dest[2]))?.name ?? null) : null,
                updatesInWindow: updates.length,
                updatesAtDest: dest ? updates.filter((u) => u.pos.join() === dest.join()).map((u) => `${u.from}>${u.to}@${u.t}ms`).slice(0, 4) : [],
                packetsAtDest: dest ? packets.filter((p) => p.pos.join() === dest.join()).map((p) => `${p.ev}#${p.type}@${p.t}ms`).slice(0, 4) : [],
            };
            if (!out.ok) {
                if (dest) rec.serverBlock = (await cmd(`data get block ${dest[0]} ${dest[1]} ${dest[2]} id`)).slice(0, 100);
                rec.serverHeld = (await cmd('data get entity @s SelectedItem id')).slice(0, 100);
                rec.serverHeldCount = (await cmd('data get entity @s SelectedItem.Count')).slice(0, 70);
                rec.clientSeeBlocksNear = blockId ? bot.findBlocks({ matching: [blockId], maxDistance: 8, count: 24 }).map((p) => p.toArray()).slice(0, 12) : [];
                // 目标格是否被 bot 自己的碰撞箱占着（服务端会静默拒收）
                if (dest) {
                    const ex = Math.abs(dest[0] + 0.5 - bot.entity.position.x) < 0.3 + 0.5;
                    const ez = Math.abs(dest[2] + 0.5 - bot.entity.position.z) < 0.3 + 0.5;
                    const ey = dest[1] >= Math.floor(bot.entity.position.y) && dest[1] <= Math.floor(bot.entity.position.y) + 1;
                    rec.bboxOverlapSelf = ex && ez && ey;
                    rec.destEntities = Object.values(bot.entities).filter((e) => e.position && Math.abs(e.position.x - dest[0]) < 0.6 && Math.abs(e.position.z - dest[2]) < 0.6 && e.position.y >= dest[1] - 0.2 && e.position.y <= dest[1] + 1.2).map((e) => `${e.name}@${e.position.toArray().map((v) => +v.toFixed(1)).join(',')}`).slice(0, 4);
                }
            }
            // ★ 每次尝试都做一次「目标格 客户端 vs 服务端」对账（设计会话补充第 3 条：保留服务端真值
            //   观测通道作为验证手段）。这是区分失败机制的关键：目标格服务端是实心 → 幻影空气/
            //   旧数据；服务端是空气但没放上 → 服务端另有拒收理由（自身碰撞/手持/距离）。
            if (dest) {
                rec.clientSawAirAtDest = ['air', 'cave_air', 'void_air'].includes(bot.blockAt(new Vec3(dest[0], dest[1], dest[2]))?.name ?? '');
                rec.serverAirAtDest = await isBlock({ x: dest[0], y: dest[1], z: dest[2], block: 'air' });
                rec.disagree = rec.ok ? false : (rec.clientSawAirAtDest && !rec.serverAirAtDest ? 'client_air_server_solid' : 'server_agree');
            }
            writeRow(rec);
            attempts++;
            if (attempts % 10 === 0) log(`${item}#${i}: ok=${rec.ok} reason=${rec.reason} | 累计 ${attempts}/${N * ITEMS.length} 用时 ${((Date.now() - tStart) / 60000).toFixed(1)}min`);
        }
    }
    const rows = fs.readFileSync(RES, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
    const okc = rows.filter((r) => r.ok).length;
    fs.writeFileSync(DONE, JSON.stringify({ terrain: TERRAIN, impl: IMPL, total: rows.length, ok: okc, byItem: ITEMS.map((it) => ({ item: it, n: rows.filter((r) => r.item === it).length, ok: rows.filter((r) => r.item === it && r.ok).length })) }, null, 2));
    log(`DONE ${okc}/${rows.length}`);
    bot.quit();
    process.exit(0);
}

main().catch((e) => { log(`FATAL ${String(e && e.stack ? e.stack : e).slice(0, 400)}`); try { fs.writeFileSync(DONE, JSON.stringify({ fatal: String(e && e.message ? e.message : e) }, null, 2)); } catch { /* 忽略 */ } process.exit(1); });
