# MC-CLOUD-02 任务单｜云端接手 E 线（末地床爆）

> 派发对象：云端泳道 X 的 agent（做完 CLOUD-01 的那个）。复核：本地设计会话。
> CLOUD-01 **通过**，以下三项裁决已生效：① Java 用 Microsoft Build of OpenJDK 11.0.32.1——同意；② NFS 删除改为"先原子 rename 挪走、再尽力删除"——收下（`_lib` 那边由本地 A 线改）；③ 测试服目录放在本机盘、jar 和 JDK 放 NAS——同意。

## 0. 你接手的是什么

从现在起，**E 线（末地床爆）整条线归你**：代码、实验、报告都在云端完成。本地原来的 E 线 agent 收尾交接后停下，**同一时间只能有你一个 E 线会话**。

**先读**（都在仓库 `bench/cloud/docs/` 里，是本地文档的快照）：
1. `MC-手册.md`：§3 坑表、§4 验收协议、§5 归因规则、§7 公平口径、§9 并行与进程规则。其中 Windows 专用的部分，按 CLOUD-01 的 Linux 做法处理。
2. `MC-ROUND3-派单.md`：只看「E 线」「E 线补充」「E 线补充二」三节（补充二优先）。
3. `MC-END-01-任务单.md` → `MC-END-01.md` → `MC-END-01-2.md`：E 线的原单和两轮报告。
4. `dragon-phases-1161.md`（研究线文档，顶部有更正横幅）、`stage-06-dragon.md`。

**代码**：
- 任务层：`aidqq-mindcraft` 的分支 `aidqq/end-probe`。用 worktree 检出，只在这个分支上提交。
- bench：`aidqq-bench` 的 `stages/end-probe/`。**在新分支 `cloud/e-line` 上工作**：从 `cloud/lane-x` 切出（那里有你写的 Linux runner），再 `git merge master` 拿到最新的 end-probe 代码和本单；不直接改 master。
- **开工前确认本地 E 线的交接已经推上来了**：`bench` 的 master 上应该有 `stages/end-probe/HANDOFF.md`。没有就先停下，告诉用户。

## 1. 要做的（就是「E 线补充二」的剩余项，按顺序）

已确认的前提：爆心是**床的枕头那半格 +0.5**（威力 5.0），所以床要贴着龙头引爆；龙追击的目标是玩家，转追击的概率是 `nextInt(⌊D²/512⌋+2)==0 || nextInt(存活水晶+2)==0`；栖息判定已经达标。

1. **龙头 E2**：用 `headBedCycle()`，在栖息时把床放到龙头 1–2 格内引爆，n≥5。每次都要记录：爆心到龙头和龙身的距离、龙血量的变化、命中的是哪个部位、bot 的血量。
2. **修掉 bot 掉血读数的通道**（订阅 health 事件流），补一次两边读数都齐的爆心判别实验。
3. **两种站位等第一次栖息的时间**：(a) 门柱附近、保持视线；(b) 盘旋时待在 64 格外、开始降落后 5 秒内进 20 格。各 ≥3 局，水晶不动。
4. 有了龙头 E2 之后：**整条龙**（peaceful + kit），5 局 ≥3 杀；每局记录用时和床的消耗。
5. 如果时间够，easy 下跑 2 局观察（只记录，不设线）。

## 2. 云端的规则

- 只有一条泳道 X，所有实验串行跑。内存峰值要写进每份报告。
- **TP 坐标不要自己拍**，一律用 `run_probe.mjs` 里已有的默认值和布景开关（CLOUD-01 的教训：自己写 `0 60 0` 会把 bot 扔进虚空）。
- 读字节码前，**先把混淆名解析回官方类名**（mappings 用 Mojang 官方的 1.16.1 server mappings，从官方版本清单下载；本地的 resolve.ps1 在 Linux 上用不了，写一个等价的小工具）。
- 零 LLM、零 key；令牌只放在 gh 的凭据里，收工时照 CLOUD-01 的做法清理。
- 提交只 `git add` 自己的文件；提交身份 `-c user.name="AI-DQQ cloud" -c user.email="cloud@aidqq.invalid"`。

## 3. 交付

- 报告写进 `bench/stages/end-probe/reports/END-01-3.md`（按手册 §6 模板，含提效条目、各段墙钟用时、内存峰值），提交到 `cloud/e-line`。
- 推送 `cloud/e-line` 和 `aidqq/end-probe`，然后停下，等本地复核。**结论必须二选一**：「可行：整条龙预计 X 秒、Y 张床」或「不可行：卡在 Y，需要 Z」。
