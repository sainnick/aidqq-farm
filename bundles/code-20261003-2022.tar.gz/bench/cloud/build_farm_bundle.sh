#!/usr/bin/env bash
# 打包农场（泳道 Y）要用的代码 → D:/AI斗蛐蛐/farm-mirror/bundles/
# 只打包已提交的内容（git archive），排除决策模型测试记录等不需要公开的文件。
# 用法（Git Bash）：bash bench/cloud/build_farm_bundle.sh [mindcraft分支...]
#   默认 mindcraft 分支：aidqq/main；可追加 aidqq/s2-barter 等，每个分支解到 mindcraft-<分支名>/
set -euo pipefail
ROOT="D:/AI斗蛐蛐"
OUT="$ROOT/farm-mirror/bundles"
STAGE="$(mktemp -d)"
BRANCHES=("${@:-aidqq/main}")
mkdir -p "$OUT"

git -C "$ROOT/bench" archive --format=tar --prefix=bench/ master -- . \
  ':(exclude)results_*' ':(exclude)annotation*' ':(exclude)decision_*' \
  ':(exclude)analysis.json' ':(exclude)_*' ':(exclude)*.py' | tar -x -C "$STAGE"

# 小云端机（泳道 X）的 Linux runner 与 CLOUD-01 报告在 bench 的 cloud/lane-x 分支上，一并带上（不含 runs/ 数据）
git -C "$ROOT/bench" fetch -q private 2>/dev/null || true
git -C "$ROOT/bench" archive --format=tar --prefix=bench/ private/cloud/lane-x   cloud/run_lane.mjs cloud/tps_tap.mjs cloud/fetch_jdk.sh "cloud/CLOUD-01-报告.md" | tar -x -C "$STAGE"

MC_LIST=""
for b in "${BRANCHES[@]}"; do
  d="mindcraft"; [ "$b" != "aidqq/main" ] && d="mindcraft-${b##*/}"
  git -C "$ROOT/mindcraft" archive --format=tar --prefix="$d/" "$b" src package.json settings.js | tar -x -C "$STAGE"
  MC_LIST="$MC_LIST\"$b\": \"$(git -C "$ROOT/mindcraft" rev-parse --short "$b")\", "
done

# 安全检查：邮箱、令牌、本机用户路径，命中就中止
if grep -rIlE '[A-Za-z0-9._%+-]+@(gmail|qq|163|outlook|hotmail)\.com|sk-[A-Za-z0-9_-]{16,}|gh[op]_[A-Za-z0-9]{20,}|Users[/\\]eru' "$STAGE"; then
  echo "安全检查未通过（上面列出的文件），中止" >&2; rm -rf "$STAGE"; exit 1
fi

STAMP="$(date +%Y%m%d-%H%M)"
tar --force-local -czf "$OUT/code-$STAMP.tar.gz" -C "$STAGE" .
SHA="$(sha256sum "$OUT/code-$STAMP.tar.gz" | cut -d' ' -f1)"
cat > "$OUT/MANIFEST.json" <<EOF
{
  "latest": "code-$STAMP.tar.gz",
  "sha256": "$SHA",
  "sizeBytes": $(stat -c %s "$OUT/code-$STAMP.tar.gz"),
  "source": { "bench/master": "$(git -C "$ROOT/bench" rev-parse --short master)", "bench/cloud/lane-x": "$(git -C "$ROOT/bench" rev-parse --short private/cloud/lane-x)", ${MC_LIST%, } },
  "npmPins": { "mineflayer": "4.38.0", "mineflayer-pathfinder": "2.4.5", "minecraft-data": "3.114.0", "minecraft-protocol": "1.68.0", "prismarine-block": "1.23.0", "prismarine-chunk": "1.41.0", "prismarine-world": "3.7.0", "prismarine-recipe": "1.5.0", "prismarine-item": "1.18.0", "vec3": "0.1.10" }
}
EOF
rm -rf "$STAGE"
echo "OK $OUT/code-$STAMP.tar.gz  sha256=$SHA"
