# MC-CLOUD-01 任务单｜云端 Linux 测试泳道试运行（泳道 X）

> 派发对象：云端 Debian 12 机器上的 agent（2 vCPU / 3GB 内存 / 无 swap / 无 GPU / 500G NAS 工作区）。复核：本地设计会话。
> 这是《AI斗蛐蛐》Minecraft 线的一部分。本机只做**无画面的 bench 测试**（测试服 + mineflayer bot），**不做拍摄**。
> 遇到颠覆性结论先停下报告；不扩大范围。

## 0. 背景（只需要知道这些）

- 本地开发机内存只够同时跑 2–3 个测试服，各开发线一直在排队。本机的目标是成为**泳道 X**，专门给 E 线（末地床爆探针）跑测试。
- 代码在两个**私有** GitHub 仓库：
  - `sainnick/aidqq-bench`（分支 `master`）：bench 测试脚本、`stages/_lib` 公共基建、`route/` 路线文件、本任务单；
  - `sainnick/aidqq-mindcraft`（分支 `aidqq/main` 主线；`aidqq/end-probe` 是 E 线；`aidqq/s1-portal` 是 B 线）：mindcraft 和我们的任务层（`src/agent/tasks/exec/`）。
- **测试全程零 LLM、零 key**：bench 的 bot 不调用任何模型，不需要任何 API key。**禁止**把任何 key 或令牌写进仓库或文件。
- 规则全文在本地的 `docs/MC-手册.md`（不在仓库里）。本单已经摘录了你需要的部分（§4、§5）。

## 1. 准备

1. GitHub 认证：用 `gh auth login` 的设备码流程，**让用户在浏览器里授权**；令牌只存在 gh 自己的凭据里，不写进任何文件。
2. 克隆到 NAS 工作区：`aidqq-bench` → `<WS>/bench`，`aidqq-mindcraft` → `<WS>/mindcraft`（分支 `aidqq/main`）；E 线代码用 `git worktree add <WS>/mindcraft-wt/end-probe aidqq/end-probe`。
3. Java：下载便携的 Temurin **JDK 11**（linux x64，官方来源）放到 `<WS>/runtime/`，不改系统设置。
4. 服务端：Mojang 官方 **vanilla 1.16.1** server jar，下载后校验 sha1（官方版本清单里给的值）。测试服目录放在 `<WS>/servers/laneX/`，端口用 25566/25576（云端机器上没有别的线在用）；`server.properties` 设 `online-mode=false`、`view-distance=8`、只监听 127.0.0.1；启动参数 `-Xmx1G`。
5. Node 依赖：**不要**对整个 mindcraft 做 `npm install`（依赖很重，3GB 无 swap 会被 OOM 杀掉）。只装 bench 实际 import 到的包（mineflayer、mineflayer-pathfinder、minecraft-data、prismarine-*、vec3 等，版本按 `mindcraft/package.json` 和 lock 文件对齐）。方法：先跑一次，看缺哪个模块就补哪个，记下最终清单。装的时候限制 Node 内存（`NODE_OPTIONS=--max-old-space-size=512`）。
6. 有 root 的话，试着在系统盘上建一个 2GB 的 swapfile，作为防 OOM 的兜底；容器不允许就跳过，并在报告里写明。

## 2. Linux 兼容（重要）

`stages/_lib/`（runner_core、preflight、cleanup、line_lock）和部分 stage 脚本里用了 **Windows 专用命令**（taskkill、PowerShell 的 CIM 查询、netstat 解析、`.exe` 路径）。**不要改这些现有文件**（它们归本地 A 线维护）。做法：
- 新建 `bench/cloud/`，写一个 Linux 版的单泳道 runner：`run_lane.mjs`，只跑泳道 X。进程只用 `process.kill` 结束**自己 spawn 出来的子进程**；端口检查用 `ss`；路径和 Java 位置都通过环境变量传入（例如 `MC_BENCH_JAVA`、`MC_BENCH_JAR`、`MC_MINDCRAFT_ROOT`）。
- 直接复用各 stage 的 `exec_bot.mjs` 和 bot 脚本（它们本身大多跨平台；遇到 Windows 专属写法，在 `bench/cloud/` 里写一个适配包装，不改原文件）。
- 报告里列一张表：`_lib` 里哪些函数需要做跨平台，并给出修改建议，交给本地设计会话安排。

## 3. 验收

| 项 | 要求 |
|---|---|
| BASIC-bootstrap（stage `basic-bootstrap`，零 kit）× 5 局，种子取本地基线 M4B4 的前 5 个（种子表在 `bench/stages/basic-bootstrap/` 的 run 脚本或 README 里，找不到就在报告里说明你用了哪 5 个） | ≥4/5 成功 |
| 资源 | 全程记录内存峰值（服务端 + bot 合计）；**零 OOM** |
| 服务器 TPS | 每局记录（用 bot 收到的 world age 增量除以墙钟换算）；平均 <18 的局标 LAGGED，**照样计成绩** |
| 耗时 | 照样记录，但**不和本地比**（硬件不同），只用来判断这条泳道能不能用 |
| E 线冒烟 | 用 `aidqq/end-probe` 分支 + `stages/end-probe/` 跑 1 局最简单的冒烟（例如只进末地、读一次龙的阶段和血量就退出），证明这条泳道 E 线能用 |
| 收工 | 测试服停掉、world 删掉、没有残留进程（只结束自己 spawn 的） |

## 4. 规则摘录（来自本地手册）

- 时间指标按全部局计算；归因必须引用遥测事件（事件名 + 次数 + 时间戳）；20 局以内 1–2 局的差距属于噪声。
- 读方块一律用 `bot.blockAt` / prismarine-world；1.16.1 的方块状态用 `block.getProperties()`。
- "没找到目标"必须判失败，不能当成"不需要处理"。
- 不调 LLM、不用任何 key；不 push 到任何非 `sainnick/aidqq-*` 的远端。

## 5. 交付

- 新代码只放在 `bench/cloud/` 下，提交到 `aidqq-bench` 的**新分支 `cloud/lane-x`**（不要直接改 master）；提交身份 `-c user.name="AI-DQQ cloud" -c user.email="cloud@aidqq.invalid"`；只 `git add` 自己的文件。
- 报告 `bench/cloud/CLOUD-01-报告.md`：环境清单（版本、安装了哪些包）、5 局逐局结果、内存峰值、TPS、`_lib` 跨平台改造建议表、提效条目（最多 3 条）。
- 推送 `cloud/lane-x` 分支，然后停下，等本地复核。
