// tps_tap.mjs — 泳道 X 的 TPS 采集适配层（不修改任何既有文件）
//
// 为什么需要它：
//   任务单 §3 要求「用 bot 收到的 world age 增量除以墙钟换算 TPS」。world age 是
//   minecraft-protocol 登录态里的 `client.state.time.time`（单位 tick，20 tick = 1s），
//   只有 bot 进程内部能看到；而 exec_bot.mjs 是既有文件、归本地 A 线维护，**不能改**。
//   所以本文件以 `node --import` 预加载的方式，在 exec_bot 之前把 mineflayer.createBot
//   包一层，旁路采样 world age 并落 world_age.jsonl。对既有代码零侵入。
//
// 用法（由 run_lane.mjs 拼装，不要手跑）：
//   MC_MINDCRAFT_ROOT=<root> node --import ./tps_tap.mjs <stage>/exec_bot.mjs --out <runDir> ...

import { createRequire } from 'module';
import path from 'path';
import fs from 'fs';

const argOf = (argv, name, dflt) => {
    const i = argv.indexOf(`--${name}`);
    return i >= 0 ? argv[i + 1] : dflt;
};

// 必须与 exec_bot.mjs 用**同一个** require 基址，否则解析到不同路径 → 不是同一个
// require 缓存条目 → 这里的 patch 对 exec_bot 不可见。
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT
    || path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../mindcraft');
const OUT_DIR = argOf(process.argv, 'out', process.cwd());
const SAMPLE_MS = parseInt(process.env.MC_TPS_SAMPLE_MS || '1000', 10);

fs.mkdirSync(OUT_DIR, { recursive: true });
const OUT = path.join(OUT_DIR, 'world_age.jsonl');

function worldAgeTicks(bot) {
    // world age（tick）在本协议栈里的落点：mineflayer 的 time 插件把登录态的
    // clocks[当前维度].totalTicks 换算成 bot.time.time（timeOfDay = time % 24000）。
    // 直接读 client.state.time 在本栈上恒为 undefined —— 那是协议层字段，play 态不挂。
    const t = bot?.time?.time;
    if (typeof t === 'number' && Number.isFinite(t)) return t;
    const raw = bot?.time?.bigTime;
    if (raw != null) { const n = Number(raw); if (Number.isFinite(n)) return n; }
    return null;
}

function install() {
    let mineflayer;
    try {
        mineflayer = createRequire(path.join(MINDCRAFT, 'main.js'))('mineflayer');
    } catch (e) {
        process.stderr.write(`[tps_tap] 无法从 ${MINDCRAFT} 解析 mineflayer：${e.message}（TPS 采集关闭，不影响 bot 成绩）\n`);
        return;
    }
    if (!mineflayer || mineflayer.__laneXTapped) return;
    const original = mineflayer.createBot;
    mineflayer.createBot = function (opts) {
        const bot = original.apply(this, arguments);
        let timer = null;
        const stop = () => { if (timer) { clearInterval(timer); timer = null; } };
        bot.once('spawn', () => {
            let warned = false;
            timer = setInterval(() => {
                const ticks = worldAgeTicks(bot);
                if (ticks == null) {
                    if (!warned) { warned = true; process.stderr.write('[tps_tap] bot.time.time 仍不可用，本局不记 TPS\n'); }
                    return;
                }
                try {
                    fs.appendFileSync(OUT, JSON.stringify({ wallMs: Date.now(), worldAgeTicks: ticks }) + '\n');
                } catch { /* 采样失败不影响试局 */ }
            }, SAMPLE_MS);
            timer.unref?.();
        });
        for (const ev of ['end', 'kicked', 'error', 'death']) bot.on(ev, stop);
        return bot;
    };
    mineflayer.__laneXTapped = true;
    process.stderr.write('[tps_tap] world age 采集已挂上 → ' + OUT + '\n');
}

install();
