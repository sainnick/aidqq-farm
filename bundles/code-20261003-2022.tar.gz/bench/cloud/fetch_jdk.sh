#!/usr/bin/env bash
# fetch_jdk.sh — 多连接分片下载 Temurin JDK 11（绕过单连接限速）
# 纯下载工具，不属于交付物；交付物只有 run_lane.mjs 和 CLOUD-01-报告.md
set -uo pipefail

URL="${1:?usage: fetch_jdk.sh <url> <outfile> [nconn]}"
OUT="${2:?missing outfile}"
N="${3:-8}"

curl -sSI -L -m 30 "$URL" 2>/dev/null | grep -i '^content-length' | tail -1 | tr -d '\r' | awk '{print $2}' > /tmp/.jtotal
TOTAL=$(cat /tmp/.jtotal 2>/dev/null || echo 0)
if [ -z "$TOTAL" ] || [ "$TOTAL" -lt 1000000 ]; then
  echo "无法确定总大小（得到 '${TOTAL}'），退化为单连接下载" >&2
  exec curl -sSL -m 3600 --retry 3 -o "$OUT" "$URL"
fi
echo "总大小 ${TOTAL} bytes，分 ${N} 连接"

CHUNK=$(( (TOTAL + N - 1) / N ))
WORK="${OUT}.parts"
rm -rf "$WORK"; mkdir -p "$WORK"

for i in $(seq 0 $((N-1))); do
  START=$(( i * CHUNK ))
  END=$(( START + CHUNK - 1 ))
  [ "$END" -ge "$TOTAL" ] && END=$(( TOTAL - 1 ))
  [ "$START" -ge "$TOTAL" ] && break
  (
    for attempt in 1 2 3 4 5; do
      curl -sSL -m 900 -r "${START}-${END}" -o "${WORK}/part.$(printf '%02d' $i)" "$URL" && \
      [ -s "${WORK}/part.$(printf '%02d' $i)" ] && break
      sleep $((attempt * 3))
    done
  ) &
done
wait

cat "${WORK}"/part.* > "$OUT"
GOT=$(stat -c%s "$OUT")
rm -rf "$WORK"
echo "下载完成: ${GOT} bytes (期望 ${TOTAL})"
[ "$GOT" -eq "$TOTAL" ] || { echo "大小不符" >&2; exit 1; }
