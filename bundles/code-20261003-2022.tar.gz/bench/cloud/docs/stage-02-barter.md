# Stage 02 · 堡垒遗迹易物：投金锭、捡物品、金锭来源（MC-RESEARCH-01 Part A）

> 前置：stage-01（已在下界、锚点已建）、stage-04 骨干（下界移动）。产出：末影珍珠 ≥14 颗 + 抗火药水 ≥1（顺带）。
> 核心真值（jar 实证，见 data/README.md）：**1.16.1 易物 E[0.2837 珍珠]/锭（4.73%/锭、每次 4-8 颗）；12 颗 E=50.8 锭 / P90=96 锭；14 颗 E=59.1 / P90=107**。
> **1.16.1 专属红利：没有猪灵蛮兵**（1.16.2 才加入）——穿一件金装即安全易物。

## SSG 口径修订（MC-RESEARCH-03，2026-10-01）

> 本节按 `bench/route/SCHEMA.md`（aidqq-route/1）+ 手册 §7 SSG 路线型改写。**以下原文全部保留**，仅作对照基线（A 口径）。
> 关键差异：**长距离搜索改为 `do station S_bastion`；到达确认后，结构内部（金箱/猪群）仍由 bot 自己找。**

### R2.1 需要的 route 站

| 站 id | kind | dim | lookFor | radius | yHint | 备注 |
|---|---|---|---|---|---|---|
| `S_bastion` | `bastion` | the_nether | `polished_blackstone_bricks` / `chiseled_polished_blackstone` / `basalt` / `gilded_blackstone` | 48 | nether_mid | 堡垒遗迹本体 |

**不新增 kind**——`bastion` 已够。金锭来源见 R2.4。

### R2.2 状态机改版：三相（本节是本单最重要的改动）

原 S3 是**串行**易物循环（选一头 → 投 → 等 6.5s → 捡）。SSG 口径下它被否决为架构缺陷（推导见 R2.3）。改为**三相**：

```text
BARTER_STAGE (SSG)
 P0 kit_gate      iron_pickaxe / iron_sword+shield / golden_armor≥1 / 建筑块≥32
                  金锭预算见 R2.4 —— 不足则本段直接 PARTIAL 上抛
 S0 do station S_bastion   → navToRegion + 到达确认闸门（findBlocks 堡垒特征块）
                          → 失败以 STATION_NOT_CONFIRMED 上抛，走 fallback
 S1 搜刮相（预期会被敌对）
    a. 到达后**自己**扫描并开启看得见的箱子（白名单取金系/铁系/食物/金甲）
    b. 1.16.1 无蛮兵，但开箱/挖金仍会把周围猪灵变敌对 → 预期被围
    c. 1.16.1 peaceful 猪灵存疑（RESEARCH-02 标"需实测"）→ easy 难度下按"有"设计
 S2 脱战相
    a. 举盾后退 ≥16 格脱离近战 → 等仇恨消退（**时长未核验，设计按 30s + 实测校准**）
    b. hp 回到可战斗水位，吃食物
    c. 敌对猪灵残留计数 >0 → 继续脱战，不进入 S3
 S3 并行易物相（核心）
    见 R2.3 的 N 槽位状态机
 S4 exit          转 stage-03（要塞）或按编排器指令返主世界
```

**为什么把开箱(S1)和易物(S3)拆成两相**：1.16.1 虽无蛮兵，但开箱会让猪灵集体敌对；**在敌对状态下做易物等于送死**。拆开后，易物相在"全员中立"状态下进行，节拍才稳。

### R2.3 并行投锭：N 槽位状态机（本单核心交付）

**改动的性质**：从"一次伺候一头"变成"同时伺候 N 头"。这不是调参，是状态机结构。

```text
S3 BARTER_LOOP
  选槽：把站位可达、脚下实心非岩浆、成年/非交易中/非敌对的猪灵分配到 N 个 slot
       （slot = 站位锚点，一个 slot 绑定一头猪灵）
  每 tick 并行推进所有 slot（**不是循环等待**）：

  slot 状态机
    IDLE ──有金锭 & 有空闲 slot──> AIMING
    AIMING ──lookAt(猪灵头部 1.3 格)──> THROWING
    THROWING ──equip(gold_ingot)+activateEntity──> WAIT_DEBIT
    WAIT_DEBIT ──2s 内 inventory 减 1？── 是→ WAIT_PLAY(125 tick) / 否→ 逼近到 2.4 重试 1 次，仍失败→ 拉黑该个体、slot 回 IDLE
    WAIT_PLAY ──125 tick 到点──> COLLECTING
    COLLECTING ──entityScan 落地物 → navTo 捡起 → 库存增量验证──> IDLE
    任一相 ──hp<8 / 敌对猪灵出现 / 掉落物掉进岩浆──> ABORT_ALL（全槽停投，脱战优先）

  记账：每槽独立累计 pearls / ingots；**实测锭/珍珠比 < 理论 0.2837×0.5 时告警**
  退出条件：ender_pearl ≥ 目标眼数（见 R2.5）或金锭耗尽或超时
```

**关键实现点**：
- **125 tick 是每槽独立的**，所以总吞吐 = N × (60/6.5) 次/分。N 越大越快，**这是 S2 能不能进预算的唯一开关**。
- 投锭**不能同时对同一个猪灵投**（会被吃），slot 必须一人一猪。
- 掉落物共享：多个 slot 的掉落会落在同一片区域，**COLLECTING 要做归并**，否则 N 个 slot 互相抢路。

### R2.4 金锭来源（L2 下的可行路径）

| 路径 | 做法 | 评价 |
|---|---|---|
| **A. 堡垒开箱（S1 搜刮相）** | 到达堡垒后自己找箱开 | **v1 走这条**。treasure 箱 E=12.85 锭/箱 → 需 ~4 箱达 51 锭 |
| B. 下界金矿 | 自己找 `nether_gold_ore`（铁镐 2–6 粒/块，≥9 粒合 1 锭） | 补充手段；挖金矿**不**激怒猪灵，可与 S3 并行 |
| C. 主世界带 64 锭出发 | 需预勘一个主世界金来源站 | **需新增 kind `gold_source`**（见下），v1 不做 |

> ⚠️ **待设计会话裁决**：`bench/route/SCHEMA.md` §2 的 kind 列表末尾是 `...`，看似可扩展，但该文件写明"改本规范只能由设计会话做"。**本单不自行新增 kind**；若要 C 路径，请设计会话在 schema 里加 `gold_source`。

### R2.5 眼数预算：SSG 口径下可以收紧

原预算 **14 眼**（12 填门 + 2 定位损耗）里的"2 定位损耗"来自投眼三角定位。**SSG 口径下我们不投眼定位**（直接走向已知门室，见 stage-05 修订节）→ **没有碎裂损耗**。

| | A 口径 | **SSG 口径** |
|---|---|---|
| 门框数 | 12 | 12 |
| 预填眼（10%/框，wiki 口径） | E=1.2 | E=1.2 |
| 定位投掷损耗 | ~2 | **0** |
| **眼预算** | **14** | **12** |

→ **12 眼 = 6 根棒**即可，珍珠目标从 14 降到 **12**（留 1 颗余量取 13）。**E[投锭次数] = 13/0.2837 ≈ 46 投。**

### R2.6 指标：每分钟投锭次数（升为架构验收线）

**推导**：每槽投一次后必须等满把玩期才可再投，故单槽上限 = 60/6.5 = **9.23 次/分**；N 槽并行 = **N × 9.23**。

| N（并行猪灵数） | 投锭次数/分 | 46 投的纯等待 | 加上开销 |
|---:|---:|---:|---:|
| 1（串行，原设计） | 9.2 | **320s** | ~450s ❌ |
| 2 | 18.5 | 159s | ~250s ❌ |
| **3** | **27.7** | 100s | ~180s |
| **4** | **36.9** | 80s | **~150s** ✅ |
| 6 | 55.4 | 50s | ~110s |

**验收线：`barter_throws_per_minute ≥ 27`（对应 N≥3）**；**目标值 ≥ 37（N=4）**。
**段预算：P50 150s / P90 180s。**

> 🚨 **修正 DECISION-01 §3.1**：那里给易物段的是 **90s**。按上表，90s 只够 N=6 的纯等待（50s）+ 40s 开销，**留不出 S1 搜刮和 COLLECTING 的时间**。**诚实的 P50 是 150s，不是 90s。** 详见 `MC-RESEARCH-03.md` §4 的总账修正。

### R2.7 实测清单（交 S2 开发单，本单不开服）

| # | 待测 | 为什么必须测 | 预期验收 |
|---|---|---|---|
| B1 | **猪灵把玩期实际时长** | 6.5s/125tick 源自 rmalde 行为参数，`version-differences.md` §二 登记为"部分未核验"。**整个 R2.6 推导对它线性敏感** | 实测 ±0.3s；>7.5s 则 N 需求上浮 |
| B2 | **N 槽并行是否真的能并行** | 机制上每头猪灵独立计时，但**未查证**：投锭是否会打断邻近猪灵的计时 | N=4 稳定跑满 46 投即成立 |
| B3 | **易物局敌对猪灵的清查耗时** | 脱战相按 30s 设计，未核验 | 实测 P50/P90，超 60s 则 S1/S3 拆相的收益要重算 |
| B4 | **实测锭/珍珠比 vs 理论 0.2837** | 验证记账告警阈值 | ≥50% 理论值，否则判"投空/捡漏" |
| B5 | **堡垒 treasure 箱的金锭实测分布** | 理论 12.85 锭/箱是 loot table 期望，**含方差** | 需确认 4 箱能否达 46 锭 |

---

## 0. 金锭来源（优先级瀑布）

| 源 | 期望产出 | 成本/风险 |
|---|---|---|
| 1. 随身金锭预算（主世界带回） | 主世界获取：埋藏宝藏 4.6 折金/箱、沉船宝藏 1.2、沙漠神殿 2.9、要塞走廊…；或挖金矿熔炼 | TASK-06 铁链顺路；**推荐出发预算：64 锭（E 覆盖 12 颗珍珠）** |
| 2. 堡垒遗迹箱子 | treasure 12.85 折金/箱、hoglin_stable 6.9、other 2.67、bridge 2.3 | 开箱会激怒周围猪灵——挑 16 格无猪灵时开，或打完再开 |
| 3. 下界金矿（nether_gold_ore） | 铁镐 2-6 金粒/块，≥9 粒合成 1 锭 | 无敌对风险（挖金矿不激怒猪灵；挖镶金黑石/金块会） |
| 4. 遗迹内金块 | 每块=9 锭，铁镐可挖 | 同 2 的仇恨风险 |

- **预算口径**：目标 14 颗珍珠（12 填门 + 定位损耗）→ E 需 59 锭；**带 64 锭出发、堡垒内按需补到 ~96（P90）**。教材的"平均 200-300 锭"是 1.21.1 口径（易物被砍半后），1.16.1 不适用。
- 顺带收益：抗火药水+喷溅合计 **4.73%/锭**——投 60 锭期望 ~2.8 瓶，几乎必然攒出 1-2 瓶，**直接供 stage-03 打烈焰人用**。

## 1. 状态机

```text
BARTER_STAGE
 S0 kit_gate      iron_pickaxe(挖金) / golden_armor ≥1 件（没有→用 2 锭合成金靴/盔优先靴子）
                  / 食物 ≥8 / 铁剑+盾（仇恨处置）
 S1 find_bastion  findBlocks(堡垒特征块: polished_blackstone_bricks/basalt/chiseled_polished_blackstone
                  gilded_blackstone, 半径 128) → 聚类取最近；navTo 前沿观测点（保持与结构 ≥24 格）
                  失败恢复：候选不可达→拉黑+wander/relocate（FindResourceTask 骨架）
 S2 acquire_gold  包内金锭 < 目标(见 §0) → 就近取金：箱子(S2c) → 金矿(S2o) → 金块(S2b)
    S2c chest     开箱前置：24 格内无存活猪灵（entityScan）；开箱→白名单取物（金系/铁系/食物/金甲）
                  开箱动作立即使猪灵敌对 → 开完立即 S4 处置或撤到掩体
    S2o ore       findBlocks(nether_gold_ore, 32) → equip iron_pickaxe → digWithVerify（复用 CollectResourceTask 挖掘通道）
    成功判定：gold_ingot ≥ 目标 或 全来源耗尽（→ S5 PARTIAL 上抛）
 S3 barter_loop   循环直到 ender_pearl ≥ 14：
    a. 选猪灵：成年（非 baby）、非敌对（metadata aggro 位=0）、未持锭、24 格内、脚下为实心非岩浆
    b. 站位：与猪灵 2.5-3.2 格、身后留 2×2 掩体；脚下若多洞 → 先铺 catch floor（4 格垫底防掉落，
       rmalde prepareBarterFloor 思想）
    c. 投锭：equip(gold_ingot) → lookAt(猪灵头部) → activateEntity → **借记验证**：2s 内 inventory.gold_ingot
       减 1 才算成交（rmalde waitForGoldDebit；没减=距离不够，逼近到 2.4 重试一次，再败拉黑该个体 3s）
    d. 等待：~6.5s（125 tick）猪灵把玩期；每 tick 扫威胁（见 S4），被中断则放弃本次等待
    e. 捡拾：entityScan item 落地物 → navTo 捡起 → 库存增量验证；珍珠以外的产物（石英/砂砾/线…）
       按 §5 清仓规则丢弃腾格
    f. 记账：累计 pearls/ingot 实测比值，低于理论值 50% 时告警（投空/捡漏排查信号）
 成功判定：ender_pearl ≥ 14（或含眼合成余量的动态目标）
 S5 exit          返回锚点门（stage-04）或转 stage-03
```

## 2. 依赖的 PRIMITIVE

| 原语 | 来源 | 用途 |
|---|---|---|
| ScanBlocksTask（stage-01 立项） | 共用 | S1 找堡垒、S2o 找金矿 |
| `bot.findBlocks` + 实体扫描 `bot.entities` | mineflayer | 猪灵/落地物/威胁；**只认 bot.entity 视野内实体** |
| entity 谓词读 metadata | mineflayer（协议同步字段） | baby 位（metadata[16]）、敌对位（metadata[14]&4，rmalde 同款判据）——客户端可见信息 |
| `bot.activateEntity(e)` / `bot.lookAt` / `bot.equip` | mineflayer | 投锭 |
| `CollectResourceTask.digWithVerify` | 既有 | S2o 挖金矿（三通道验证直接复用） |
| `bot.openContainer` + 白名单取出 | skills.js 既有开箱通道 | S2c |
| 反射安全网 + DefenseChain（新 ~120 行） | 新写 | 岩浆/坠落即时反应；敌对猪灵/恶魂的"举盾后退-脱战-回位"三步处置 |
| 库存管家 `reserveItemSpace` 思想 | 新写 ~50 行 | 腾格丢弃白名单（石英/砂砾/灵魂沙/下界砖…见 rmalde unneededInventoryItems 的白名单思想，自写清单） |

## 3. 公平口径

- 全部信息=已加载区块方块 + 视野内实体 + 自身库存/位置/朝向。**无透视**：猪灵在未加载区块不算数；箱内物品开箱前不可知（用 loot table 期望做决策属于"AI 的知识"，允许——等价玩家背表）。
- 允许的硬编码知识：易物概率表（本单 data/，等价速通者常识）、猪灵机制（穿金中立/开箱挖金敌对/把玩 ~6s，wiki 口径）、1.16.1 无蛮兵。
- 禁止：读服务器侧仇恨表/生成计划；给猪灵坐标常量（必须 entityScan 现场发现）。

## 4. 常见失败模式 ×5

| # | 失败 | 对策 |
|---|---|---|
| 1 | **开箱/挖金触发猪灵敌对**（无金装瞬间围殴） | 硬顺序：先穿金装再靠近；开箱后立即脱战（举盾后退 16+ 格等仇恨消退，消退时长未核验——按 30s 设计+实测校准）；1.16.1 无蛮兵是本策略成立前提 |
| 2 | 珍珠掉进岩浆/洞（捡不到） | 投锭位预铺 catch floor；选猪灵时排除脚下 2 格内有岩浆/悬空者；掉落物 300s 存在期足够走过去 |
| 3 | 投锭无借记（距离/朝向/猪灵 busy） | 借记验证 2s 超时→逼近重投→拉黑；连 3 个个体失败→换观测点（防 dispatch 风暴，P0 教训） |
| 4 | 猪灵把玩中被恶魂/烈焰人打断，掉落物被炸飞 | 等待期每 tick 威胁扫描（rmalde waitForBarter 思想）；优先选室内/掩体内的猪灵做交易 |
| 5 | 背包满，珍珠捡不起来 | 投锭前 reserveItemSpace（预丢垃圾）；金粒 ≥9 先合成、砂砾/石英按白名单丢弃 |

## 5. 参考来源

- **AltoClef**（MIT）：`tasks/resources/TradeWithPiglinsTask.java`（2s 无进展拉黑个体、跳过 hoglin 64 格内/幼体/交易中个体、>72 格防 deload）、`tasks/resources/CollectGoldIngotTask.java`（下界金粒→锭→挖金矿的取金顺序）、`tasks/resources/KillAndLootTask.java`、`ResourceTask.java`（捡地→容器→挖→主动获取的 tick 顺序）。
- **rmalde**（只借鉴设计）：`covered-barter.mjs`（catch floor、投锭距离分档 3.15/2.4、6 秒等待期逐 tick 威胁扫描、safeNearbyPickup 的威胁位判据）、`bastion-gold.mjs`（护墙挖金：记录回退高度、借记验证、被挡目标 5 分钟黑名单、64 锭批量完成）、`nether-supplies.mjs`（barterTargets 公式、waitForGoldDebit、备用抗火目标公式）。
- **Odyssey**（MIT）：`killMob`、`collectItem`、`chestAPIs`（思路级）。

## 6. 实现规模估计

- 新写：BarterStageTask ~220（选个体/投锭/借记/等待/捡拾）+ 金来源路由 ~120 + DefenseChain ~120 + 库存管家 ~50 ≈ **510 行**
- 复用：采集/合成/导航全复用；金甲合成走 CraftingTask
- **基准测试 `BARTER`**：起点=下界出生态 kit+64 金锭（RCON 给锭，测的是易物环节不是取金环节）；固定种子（堡垒已知存在的 Top3 种子）；指标：14 颗达成率 ≥90%、用时 P90、**金效（锭/珍珠）实测 vs 理论 3.53**（>2 倍偏离要归因）、死亡=0。
- 取金环节单独小基准 `GOLD`（带 0 锭进下界，只靠箱子+金矿凑 64 锭）——可后置，不阻塞主线。
