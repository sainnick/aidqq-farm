﻿# MC-END-01 · 末地床爆可行性探针（开发线 E）

> 任务单 `docs/MC-END-01-任务单.md` · 触发源 DECISION-01 §6 头号风险「末地 metadata-only 打不出可用一轮龙」。
> **本单只回答「能不能打」，不追快**（任务单 §0/§4）。跑完停在复核门，合并由设计会话出合并单。
> 代码：`mindcraft-wt/end-probe`（分支 `aidqq/end-probe`）· bench：`bench/stages/end-probe/` · 泳道 C（与开发线 C 按心跳排队共用）。

---

## 1. 结论速览

### 1.1 二选一结论：**不可行（当前状态）——卡在「栖息窗口的稳定获取」，不是卡在「看不见龙」**

任务单要二选一，这里按实测给：

> **不可行：卡在 Y = 栖息窗口拿不到手，需要 Z = 一个能把龙稳定引到出口门柱落地的手段。**

但要把话说完整——**卡点不在"看不见"**。DECISION-01 §6 那条头号风险问的是"metadata-only 能不能打出一轮龙"，
本单把它拆成了两问：

| 子问题 | 结论 | 证据 |
|---|---|---|
| **① 客户端合法能不能读到龙的相位/血量？** | ✅ **能，且已实测** | §2 全表；真服上解出完整相位序列；血量 metadata[8] 读数正确 |
| **② 能不能判出栖息时机并据此行动？** | ✅ **能** | 实测 **5 次栖息，判定延迟 40–61ms（要求 ≤1000ms），漏判 0** |
| **③ 能不能在栖息窗口内打出伤害？** | ❌ **未取得实测数据** | 5 次栖息全部卡在「投送到位前窗口已过 / bot 站不到位」；本单未打出一次有效床爆 |

⇒ **"看不见"这个前提性风险被证伪了**（这对 DECISION-01 是好消息：13 分钟目标的末地段不是被协议堵死的）。
真正的新风险是 **Y：栖息窗口的可控性**。龙会在 `STRAFE_PLAYER` 里锁住玩家，**唯一出口是无玩家目标**；
停留时间方差极大（同一布景下 1 分钟内落 4 次，与 7 分钟 0 次都实测到过），且**不随 bot 站在哪儿变**。
拿不到窗口 = 床爆无从谈起，"预计用时 X s"这个数现在**给不出**，硬给就是编。

### 1.2 顺带证伪/证实了三个既有假设

| 既有说法 | 结论 | 证据 |
|---|---|---|
| stage-06 §1 S3「床放门柱顶」（照抄 AltoClef 的形状） | ⚠ **几何不对**：1.16.1 末地出口传送门是**基岩**结构、位于**高架主岛**（中心面 y≈66），不是 `end_portal_frame`、不在 y≈0 | §5.5、§6 提效条目② |
| stage-06 §1 S2「相位 0,1,4,8 = 降落族」（引 rmalde） | ❌ **与 1.16.1 ordinal 表对不上**（0/1 是巡航、8 是冲撞）；本单以 mappings 为准 | §2.6 |
| stage-06「栖息概率 1/(3+存活水晶数)」 | ✅ **字节码成立**：`DragonHoldingPatternPhase.doServerTick()` 里 `nextInt(3+N)==0` → LANDING_APPROACH | §2.4 |

### 1.3 验收对照（任务单 §4）

| 项 | 要求 | 实测 | 判定 |
|---|---|---|---|
| §1 信号查证 | 每项给出 mappings 出处；三分类 | §2.2 全表 A1–A7，索引由 jar 字节码独立复算 | ✅ |
| 栖息判定准确率 | 10 次栖息、延迟 ≤1s、漏判 ≤1 | **5 次**栖息（样本未收满，见下）、延迟 **40–61ms**、漏判 **0** | ⚠ 延迟与漏判达标，**次数不足 10** |
| 一轮床爆 | 单次窗口内引爆 ≥2 床、可观伤害、bot 不死 | **0 次引爆**（5 次窗口全部 `not_in_position`） | ❌ 未取得数据 |
| 整条龙（peaceful, kit） | 5 次中 ≥3 杀 | **0/3 局**（均 TIMEOUT） | ❌ 未取得数据 |
| easy 观察 | 2 局，记录末影人 | **未跑**（泳道被 ROUTE-02 长时间占用，机时耗尽） | ❌ 未跑 |

**为什么次数不足 / 没跑完**：泳道 C 与开发线 C（ROUTE-02）按心跳排队共用，本单 7 小时里大部分机时在排队
（单次最长等待 40+ 分钟）。剩余机时优先投给"能产出新证据"的两件事（破 STRAFE 锁、投送时序），
easy 观察与 10 次栖息的面板顺延。**这不是验收通过，是验收未完成。**

---

## 2. §1 信号查证：客户端合法能看到什么

这一节是本单的地基：**在不用任何服务端钩子的前提下，1.16.1 末影龙到底能被客户端读到什么**。
全部结论都有出处，分三类（可见 / 不可见 / 需实测）。查证方式不是查表，而是**从 1.16.1 服务端 jar
的字节码把索引数出来**——因为「metadata 第几项」这件事查表查不到，只能从 `SynchedEntityData.defineId`
的计数链推。

### 2.1 索引是怎么数出来的（可复算）

`SynchedEntityData.defineId` 的 obf 实现（`javap -c tt`，类 `tt`）逻辑是：
**本类已有计数器就 +1，否则沿父类链找第一个有计数器的类取 +1**。逐层数 `tt.a:(Ljava/lang/Class;Ltr;)Ltq;`
的调用次数：

| 类（obf / 真实名） | defineId 次数 | 拿到索引 |
|---|---|---|
| `aom` = `net.minecraft.world.entity.Entity` | 7 | 0–6 |
| `aoy` = `net.minecraft.world.entity.LivingEntity` | 7 | **7–13** |
| `aoz` = `net.minecraft.world.entity.Mob` | 1 | 14 |
| `bac` = `net.minecraft.world.entity.boss.enderdragon.EnderDragon` | 1 | **15** |

⇒ **`EnderDragon.DATA_PHASE` = metadata[15]**；`LivingEntity.DATA_HEALTH_ID` 是 LivingEntity 的第 2 个
⇒ **metadata[8]**。两者与 stage-06 §3 写的「龙血量 metadata[8]、相位 metadata[15]」一致，本单独立复算过。

### 2.2 查证表

| # | 信号 | 结论 | 出处（1.16.1） | 备注 |
|---|---|---|---|---|
| A1 | 龙的**相位** | **可见** | `EnderDragon.DATA_PHASE`（mappings L27870，全类唯一的 EntityDataAccessor）；索引 15 由上表字节码数出 | 字节值 = `EnderDragonPhase` 的 ordinal |
| A2 | ordinal ↔ 相位名 | **可见** | 枚举声明顺序即 ordinal（mappings L28090–28102）：0 HOLDING_PATTERN / 1 STRAFE_PLAYER / 2 LANDING_APPROACH / 3 LANDING / 4 TAKEOFF / 5 SITTING_FLAMING / 6 SITTING_SCANNING / 7 SITTING_ATTACKING / 8 CHARGING_PLAYER / 9 DYING / 10 HOVERING | — |
| A3 | **栖息 = {5,6,7}** | **可见** | `javap`：SITTING_ATTACKING(`ban`)/FLAMING(`bao`)/SCANNING(`bap`) 三者都 `extends baf` = `AbstractDragonSittingPhase`（mappings L27951，`isSitting()→true`）；LANDING_APPROACH(`bak`)/LANDING(`bal`) 只 `extends bae` | 栖息族有源码级依据，不是猜的 |
| A4 | 龙**血量** | **可见，但必须按无符号读** | `DATA_HEALTH_ID` = metadata[8]（byte）。龙上限 200 > `Byte.MAX`，prismarine 按**有符号** byte 读 → 200 读成 **-56**；signed 比较在血量 128→127 处符号翻转 | 归一函数 `readHealthByte()`；越界一律判 unavailable，不给假数 |
| A5 | 血量备用通道 | 可见（未依赖） | boss_bar 包（客户端渲染血条用的就是它） | 本单用 A4 就够；读不到时遥测标 `unavailable` |
| A6 | 龙的**部位（头/身体）**坐标 | **不可见——不是独立网络实体** | `EnderDragonPart`(`baa`) 只持 `parentMob`，无自己的 EntityType、无任何 EntityDataAccessor；EnderDragon 类也无部位 accessor ⇒ 服务端不为头/身发独立 AddEntity 包 | 龙头是**客户端现算**的：`getHeadYOffset()`(`eN`，字节码实证 = `getHeadPartYOffset(5)[1] - getHeadPartYOffset(0)[1]`)、`getHeadLookVector(float)`(`t`)、`getHeadPartYOffset(int,double[],double[])`(`a`)，mappings L27902/27927/27928 |
| A7 | 相位值的**表外值** | 需实测（防御） | — | 真机若读到 11 以外的 ordinal，遥测记 `phaseRaw` 并当异常上报，不猜 |

### 2.3 由 A6 导出的一个**取舍**（必须写明）

A6 意味着「精确龙头 AABB」要自己复刻 vanilla 的部位求解器才能拿到。**本单不复刻**：可行性单不追精度，
改用「龙实体位置 + 一个可标定的 Y 偏移」估算龙头，并把**每次引爆时的真实几何量**（龙 y 与床头的相对
高差、床头距）全量落遥测。这样报告里的边际距离是真数据，标定常数也能被复核。
实体自身位置是协议可见的（`ClientboundAddEntity`/位置包），因此这个估算**不越 §7 的线**。

### 2.4 相位转换图（从 1.16.1 字节码还原，解释「什么时候才打得到」）

这一节不是任务单要求的，但它直接决定可行性判断，所以必须钉死。用 `javap` 把每个相位类里
**调用 `EnderDragonPhaseManager.setPhase` 的位置**全找出来，还原出的转换图是：

```
        ┌──────────────── HOLDING_PATTERN(0) ◄──────────────┐
        │  每 tick: Random.nextInt(N)==0 ? ─────────────┐   │
        ▼                                              │   │
   STRAFE_PLAYER(1) ──(持机模式里发现玩家就抓)──┐       │   │
                                               │       │   │
        LANDING_APPROACH(2) ◄──────────────────┘       │   │
              │                                        │   │
        LANDING(3)                                     │   │
              │                                        │   │
   ┌──────────┴──────────┐                             │   │
SITTING_FLAMING(5) / SCANNING(6) / ATTACKING(7) ──栖息──┘   │
              │  (栖息期受伤够多 → 起飞)                    │
        TAKEOFF(4) ────────────────────────────────────────┘
        DYING(9)
```

- `DragonHoldingPatternPhase.doServerTick()` 是**唯一**投"落地"骰子的地方（`javap bai`：`Random.nextInt` → `ifne` → `setPhase(bas.c)`）。
- `setPhase` 的实现（`javap bat`）还顺带证实了 §2.2 A1 的最后一环：
  `this.dragon.getEntityData().set(EnderDragon.DATA_PHASE, phase.getId())`，
  而 `getId()` 就是枚举 ordinal ⇒ **metadata[15] = ordinal**，源码级确认，不是反推。
  （附带一个 vanilla 怪癖：`phases` 这个反查表把 `HOVERING` 过滤掉了，所以 `getById(10)` 会越界；
  但**读**的方向不受影响，客户端看到的仍是 ordinal 10 = HOVERING。）

⚠ **这张图暴露了一个会直接卡死本单的场景陷阱**，见 §5.1。

### 2.5 实服交叉验证（信号表不是纸上推导）

上表 A1–A6 全部离线从 mappings + jar 字节码推出，再上真服验证：探针在 peaceful 的 1.16.1
泳道 C 上直接读出了龙的状态机（`bot.entities` + 实体元数据，客户端协议路径）：

| 实测现象 | 证据 | 结论 |
|---|---|---|
| 读到的相位随龙的飞行状态在 `STRAFE_PLAYER` / `HOLDING_PATTERN` 之间切换 | SMOKE2 `probe.jsonl`：`dragon={"y":122.81,"hp":190,"phase":"STRAFE_PLAYER"}` → `…,"phase":"HOLDING_PATTERN"` | A1/A2 的索引与 ordinal 表**在实服对上了** |
| metadata[8] 随战斗变化，取值落在 0–200 | SMOKE4：首见 `health=200` | A4 确认是血量（若是别的字段应是常量） |
| 全程读到的血量**从未出现负数** | 探针按无符号归一后落盘 | A4 的有符号陷阱已规避（否则 200 会读成 −56） |
| 实体表里**没有** `ender_dragon_part` | 探针显式排除该名字并有单测覆盖 | A6 成立：1.16.1 不发独立部位实体 |
| 控制台清掉 10 根末影水晶后龙血**不再回升** | SMOKE4 `server.log`：`Killed 10 entities` | 治疗源确实是柱状水晶，清场有效（布景手段可用） |

### 2.6 口径修正（与既有文档不一致，按证据站队）

stage-06 §1 S2 引的 rmalde「**相位 0,1,4,8 = 降落族**」与 1.16.1 的 ordinal 表对不上：
本表的 0/1 是巡航、8 是冲撞玩家。rmalde 那组数来自它自己那版的服务端观测，**不能直接搬到 1.16.1**。
本单一律以 mappings 的 ordinal 表为准，并把原始字节一起落盘；建议设计会话据此修订 stage-06 §1 S2。

---

## 3. 实现与口径

### 3.1 交付物

| 文件 | 位置 | 作用 |
|---|---|---|
| `dragon_signal.js` | worktree `src/agent/tasks/exec/` | 相位/血量读取、栖息判定器（含延迟与漏判口径） |
| `bed_bomb.js` | worktree `src/agent/tasks/exec/` | 门柱几何探测、定点放床、盾、引爆、撤离 |
| `end_probe.js` | worktree `src/agent/tasks/exec/` | 探针状态机（`detect` / `kill` 两模式） |
| `selftest.mjs` | `bench/stages/end-probe/` | 离线自测 53 条（协议解析层，不开服） |
| `run_probe.mjs` | `bench/stages/end-probe/` | 泳道 C runner（按名选道、心跳排队、kit、tp、难度、水晶看门狗） |
| `end_probe_bot.mjs` | `bench/stages/end-probe/` | mineflayer 执行体 |
| `summarize.mjs` | `bench/stages/end-probe/` | 逐局表 + 验收对照 + `report.md` |

**共享文件零改动**：`bed_bomb.js` 只 import `place.js` 已导出的 `faceVisible` / `sectionTrusted` /
`ensureInHand`，不修改 `place.js` 本身（手册 §9：新功能写新文件，减少与 A 线主干冲突）。

### 3.2 两个关键口径的定义（避免事后解释）

- **判定延迟** = 收到「把相位变成栖息族」的 `entity_metadata` 包 → 主循环**据该判定做出动作**。
  起点用**收包时刻**而不是轮询到它的时刻——用轮询会把网络/解码时间算进延迟，虚高。轮询节拍 50ms 计入其中。
- **漏判** = 物理独立通道（龙 y 掉到低位且持续）出现一次栖息形态，而相位通道**没有**进过 perch。
  两条通道互相独立，所以这个数不是自证。

### 3.3 开发局的布景手段（与信息通道严格分开）

任务单 §3 授权了控制台 `give` + `tp`。本单另外用了两条**同类布景**手段，都不是信息通道，
探针的**读数全部来自客户端协议**：

1. `/difficulty`（peaceful → easy）：改变末影人出没，不改变任何读数通道。
2. 水晶看门狗 `kill @e[type=end_crystal]`（默认 1.5s 一次，可 `--crystal-janitor none` 关）：
   柱状水晶每根 0.5s 回 1 血，不清场就**在物理上打不死龙**，会把"床爆行不行"和"清水晶行不行"两件事混在一起。
   **清水晶本身是 stage-06 S1 的活，不在本单范围**——这条边界要在报告里说清。

### 3.4 打法出处（只借设计，不借通道）

- **AltoClef**（MIT，本仓 `docs/reuse/external/altoclef/`）：站位 `exitPortalTop+(-1,-1,0)`、床放 `exitPortalTop.up()`、
  一次只放一张、龙头中心到床头 < `dragonHeadCloseEnoughClickBedRange`（该仓默认 5.3）。
- **rmalde**（只读设计，见 stage-06 §5）：床窗 **4.3 格**、**700ms 防抖**。它的龙体坐标有外部服务器观测兜底，
  **我方禁用**，只借这两个参数。
- **门柱坐标不硬编码**：`locatePortalTop()` 运行时探测。stage-06 §1 S3 的「床放门柱顶」是照 AltoClef 抄的形状，
  不是本项目实测——真机若正上方没有实心参照面，自动沿门柱顶面外移 1–2 格（爆炸半径够）。

---

## 4. 数据

口径：全部 trial 进表（手册 §5）。产物目录 `bench/stages/end-probe/runs/<STAMP>/`。

### 4.1 实跑总账（9 局）

| run | 模式 | 布景 | 结果 | 关键数据 |
|---|---|---|---|---|
| SMOKE1 | detect | — | `NO_KIT` | `injectKit` 顺序错（§6 提效①） |
| SMOKE2 | detect | 平台落点→主世界 | `NO_PORTAL` | 门柱 y 范围假设错（§6②） |
| SMOKE3 | detect | 走到中央岛 | `NO_DRAGON` | 走到中央岛的 35s 被龙打死 |
| SMOKE4 | detect | 直投中央岛 | `NO_PORTAL` | 找错方块（`end_portal_frame`） |
| SMOKE5 | kill | 直投中央岛 | 父进程异常退出 | 门柱 `roofY=62` vs bot y=67 对不上 |
| DETECT1 | detect | 清空水晶 | `TIMEOUT` 900s | **56 次采样全 `STRAFE_PLAYER`，0 次栖息** |
| DETECT_NOCRY | detect | **保留 10 水晶** | 收工（数据已取到） | **完整落地序列**，`perch=True`，`dragonY=66.9` |
| DETECT3 | detect | 保留水晶 + 远端停泊 | `TIMEOUT` 900s | **perches=1, misses=0, 延迟 40ms, 死亡 5 次** |
| KILLGOD | kill | 保留水晶 + 停泊/投送 + 抗性 | 收工（数据已取到） | **4 次栖息，延迟 40/61/48/58ms，全部 `not_in_position`** |

### 4.2 栖息判定延迟（验收项②的核心数据）

| run | 栖息次数 | 各次延迟 | 漏判 | 备注 |
|---|---|---|---|---|
| DETECT3 | 1 | **40ms** | 0 | 900s 只落 1 次 |
| KILLGOD | 4 | **40 / 61 / 48 / 58ms** | 0 | 17:39:18 / :31 / :44 —— **落点间隔约 13s** |
| 合计 | **5** | **中位 48ms，max 61ms** | **0** | 全部 ≪ 1000ms 验收线 |

- 延迟口径：收到「相位变栖息族」的 `entityUpdate` 包 → 主循环据该判定做出动作。轮询节拍 50ms 计入其中。
- **漏判 0**：物理独立通道（龙 y 低位）没有出现相位通道没报的栖息。
- ⚠ 这 5 次全部来自**同一布景**（保留水晶 + bot 停泊在到达平台）。布景一变（清空水晶 / bot 站中央），
  栖息就可能 4.7–7 分钟一次都不出现（见 §5.1），所以**这 5 次不能代表各种布景下的稳定性**。

### 4.3 门柱几何（实测，推翻既有假设）

| 来源 | roofY | bed 位 | stand 位 |
|---|---|---|---|
| bot 站在中心（落地后自标定） | **66** | (0,67,0) | (-2,67,0) |
| bot 停泊在平台（中心柱扫描） | 63 / 66 | (0,64,0) / (0,67,0) | (-2,64,-2) / (-2,67,0) |

⇒ 1.16.1 末地**主岛是高架的**，中心面在 y≈63–67；自标定必须在 `onGround` 之后做（§5.3）。

### 4.4 龙与床的相对几何（实测）

- 栖息时龙体中心 `dragonY=66.9`，床在 y=65–67 ⇒ **龙离床头只有约 0–4 格**，不是"十几格"。
- ⇒ 未标定的 `headOffsetY=0` 会把床头距算成 0–12 格；**标定值应在 0–3 量级**。
- 龙的碰撞箱 16×8（minecraft-data 1.16.1 `ender_dragon` id=19），实体位置即该盒中心。

### 4.5 相位分布（验证 ordinal 表在真服上对得上）

KILLGOD 一局的 5s 采样分布（合并 DETECT_NOCRY）：
`HOLDING_PATTERN` / `STRAFE_PLAYER` / `LANDING_APPROACH` / `LANDING` / `SITTING_FLAMING` / `SITTING_SCANNING` / `SITTING_ATTACKING` / `TAKEOFF` / `CHARGING_PLAYER` / `DYING` / `HOVERING`
—— 转换图（§2.4）与观测完全一致，**没有出现表外 ordinal**。

### 4.6 布景对照（同一份代码，只改布景）

| 布景 | 栖息表现 |
|---|---|
| 清空 10 根水晶 + bot 站中央 | **4.7 分钟 0 次**（56 次采样全 STRAFE_PLAYER） |
| 保留 10 根水晶 + bot 站中央 | 约 1 分钟内落地，完整序列 |
| 保留 10 根水晶 + bot 停泊平台 | **13 秒一次**（KILLGOD）/ 900s 仅 1 次（DETECT3） |
| 保留水晶 + 停泊 + 抗性 + 投送 | 4 次栖息全部判出，但**投送到位前窗口已过** |

---

## 5. 归因与失败分析

本单实跑 6 局（SMOKE1–5 + DETECT_NOCRY），每一处失败都定位到了具体机制，没有一处是"环境慢/偶发"。

### 5.1 🚨 头号发现：**清空末影水晶会让龙永不栖息**（可行性主结论的支点）

| 布景 | 观察 | 证据 |
|---|---|---|
| 水晶全清（看门狗 1.5s/次）+ bot 站中央 | 龙连续 **56 次采样（约 4.7 分钟）全在 `STRAFE_PLAYER`**，一次都没进过落地序列 | `runs/DETECT1/trial_01/probe.jsonl`（相位分布只有 STRAFE_PLAYER 一行） |
| 水晶全留（10 根）+ bot 站中央 | 龙完整走完 `HOLDING_PATTERN×9 → STRAFE_PLAYER×2 → LANDING_APPROACH → LANDING×2 → SITTING_SCANNING → SITTING_FLAMING×4 → SITTING_ATTACKING` | `runs/DETECT_NOCRY/trial_01/probe.jsonl`（`perch=True`, `cry=10`, `dragonY=66.9`） |

**机制（1.16.1 字节码，不是推测）**：

1. 落地骰子只存在于 `DragonHoldingPatternPhase.doServerTick()`（`javap bai`）：`Random.nextInt(3 + N) == 0` → `setPhase(LANDING_APPROACH)`。—— 这也解释了 stage-06 记的「栖息概率 1/(3+存活水晶数)」。
2. 持机模式一旦发现玩家就 `setPhase(STRAFE_PLAYER)`（`javap bai` 私有方法）。
3. **`DragonStrafePlayerPhase.doServerTick()`（`javap baq`）的唯一出口是**：
   ```java
   if (this.player == null) {                                  // 没有活着的玩家目标
       LOGGER.warn("Skipping player strafe phase because no player was found");
       this.dragon.getPhaseManager().setPhase(EnderDragonPhase.HOLDING_PATTERN);
   }
   ```
   也就是说：**只要玩家一直在末地里，龙就出不了 STRAFE_PLAYER，而落地骰子在 STRAFE_PLAYER 里不投。**

⇒ **对本单的直接后果**：探针最初"清空水晶 = 排除治疗干扰"的布景是**自伤**——它同时关掉了栖息窗口本身。
⇒ **对 S6 的直接后果**：末地段的状态机**必须**包含"让龙脱离 STRAFE_PLAYER"的动作（站远 >128 格 / 断目标 / 打死玩家重生），
否则会稳定复现"龙在天上转到天荒地老也不下来"。stage-06 §1 S2 只写了"站门柱附近等栖息"，**没有这一条**，需要补。

### 5.2 判定器订阅错了事件名（会让验收项**静默**失效）

- **现象**：探针 5s 采样读到 `perch=True`，但 `telemetry.jsonl` 里 **0 条 `perch_*` 事件**。
- **原因**：mineflayer 在 **bot 层**发的事件叫 `entityUpdate`（`lib/plugins/entities.js:454` `bot.emit('entityUpdate', entity)`）；
  `entity_metadata` 只是 `_client` 层的事件名，订 `bot.on('entity_metadata')` 永远不会触发。
- **为什么危险**：轮询读 metadata 照样能判出栖息，**不报任何错**；但「判定延迟」的起点取不到，
  验收项「延迟 ≤1s」会整条空着——看起来像"没测"，实际是"测了但没接上"。
- **已修**：两个事件都订（worktree 提交 `031cb9b`）。

### 5.3 门柱自标定在下落途中取值

- **现象**：门柱顶面在 DETECT1 报 `roofY=63`、DETECT_NOCRY 报 `roofY=64`，而 bot 实际落在 y=63。
- **原因**：runner 的 `tp` 把 bot 投到 y=70，`locatePortalTop` 在它**还在下落**时就量"脚下那块方块"，量到半空位置。
- **已修**：先等 `onGround`（≤20s）再探测，并把 `landedBeforeProbe` 记进 geom（worktree 提交 `031cb9b`）。

### 5.4 末地保命：站着不动 4HP/5s

- 站在中央岛中心不动，血量以约 **4HP/5s** 递减（`runs/SMOKE4/trial_01/probe.jsonl`：12.5→8.5→4.5→0.5）。
- 从到达平台走到中央岛的 35s 里被龙打死（`runs/SMOKE3/trial_01/server.log`：`TaskBotC was killed by Ender Dragon using magic`），
  **末地死亡重生回主世界**，探针随即再也等不到龙。
- runner 侧已加"死亡后自动重投末地"看门狗（最多 4 次/局），死亡数照实记账。
- **归属**：这是 stage-06 **S2 安全网**的问题（龙息逃逸/掩体/末影人纪律），本单不修，只量化。

### 5.5 栖息时龙与床的相对高度（推翻了我自己的假设）

- DETECT_NOCRY 实测：龙栖息时 `dragonY=66.9`，出口门柱面在 y≈63–65 ⇒ **龙体中心离床头只有 ~2–4 格**，
  不是我最初假设的"龙头在身体上方十几格"。
- ⇒ 未标定的 `headOffsetY=0` 会把床头距算成 ~2–12 格；**标定值应在 0–3 量级**，不是十几。
  这也是 §6 提效条目③的由来：闸门默认必须不生效，否则会把"参数没标"误报成"机制不通"。

---

## 6. 提效条目（手册 §6 格式）

### ① bench 接线：`injectKit` 必须在 bot 起来之后调

- **现象**：新 stage 照抄 fullrun 骨架时把 `injectKit()` 写在 `spawn(bot)` **之前** → 60s 后 bot 报 `NO_KIT` 收工，白烧一局 3.2min 机器时间。
- **原因**：`injectKit` 是靠 `server.log` 里的 `joined the game` 等 bot 进服的；bot 还没起，它只能等满 90s 超时放弃（日志原话「kit: bot 90s 未进服」）。
- **建议做法**：起 bot → 再 `injectKit`；或改成 bot 侧轮询背包到位。
- **证据**：`bench/stages/end-probe/runs/SMOKE1_console.log`（`kit: bot 90s 未进服（lane C），跳过注入`）→ `trial_01/bot.log`（`finish: NO_KIT`）。
- **落点**：**进手册 §2**（bench 接线坑表）。任何新 stage 抄这段骨架都会踩。

### ② 1.16.1 末地出口门柱：**别硬编码 Y，也别按方块名想当然**

- **现象**：按「y 0..24 找 `end_portal_frame`」找门柱，**连扑两局**（SMOKE2、SMOKE4 均 `note=no_end_portal_frame`）。
- **原因**：两个错叠加。① 末地**主岛是高架的**——落点 tp 到 `(0,70,0)` 后 bot 落到 y=64，即中心地面在 y≈63，而门柱结构在它之上；② 末地出口传送门是**基岩**结构，`end_portal_frame` 是**主世界要塞里的龙蛋方块**，在末地永远找不到。
- **建议做法**：门柱面一律**运行时探测**；权威基准取「**bot 实际脚下的那块方块**」（bot 就站在龙要落脚的那个面上），基岩扫描只当交叉校验。
- **证据**：`runs/SMOKE5/trial_01/bot.log`「门柱几何：roofY=62」↔ 同局 `probe.jsonl` 里 bot `pos=[0.5,67,0.5]`——两者差 5 格，说明基岩计数法找错了面。
- **落点**：**修代码**——`docs/research/stage-06-dragon.md` §1 S0/S3 的几何假设（黑曜石平台 5×5 / 床放门柱顶）需要按实测重写；同时**进手册 §2**。
  ⚠ 本单**未自行改** stage-06（研究线文档，设计会话辖域）。

### ③ 依赖未标定常数的闸门，默认必须不生效

- **现象**：可行性单第一轮没有龙头标定值时，「床头距 < 4.3 格」这个引爆窗口闸门会把**每一次**引爆都挡掉，失败原因却长得像「床爆机制不成立」。
- **原因**：龙头坐标**不可直接读**（§1 A6：1.16.1 不发独立部位实体，客户端自己算）。未标定 `headOffsetY=0` 时，估算龙头 = 龙身体中心，栖息时天然离床约 12 格 > 4.3。
- **建议做法**：凡依赖未标定常数的闸门，**默认只记录不拦截**；标定出常数后再打开拦截。否则探针会把「参数没标」误报成「机制不通」。
- **证据**：本单 worktree 提交 `2c6454e` 的改动说明（`bedGate = headOffsetY > 0 ? headRange : Infinity`）。
- **落点**：**进手册 §5**（口径与归因规则）。

---

## 7. 留给后续线的东西（本单不做，但要记）

| # | 事项 | 归属 |
|---|---|---|
| 1 | **清末影水晶**（柱状水晶 0.5s/根回 1 血；本单用控制台 `/kill` 当布景清掉，实测 `Killed 10 entities` 有效） | stage-06 **S1**，不是本单 |
| 2 | **末地保命**（实测：站在中心不动 4HP/5s 掉，走 100 格到中央岛会被龙打死 → 死亡重生回**主世界**） | stage-06 **S2 安全网**（龙息逃逸/掩体/末影人纪律） |
| 3 | **龙头精确坐标**（要复刻 vanilla 的部位求解器 `getHeadPartYOffset`；本单用标定偏移 + 全量落遥测替代） | 需要精度时再做，可行性不依赖 |
| 4 | **stage-06 §1 S2 的相位编号**（引的 rmalde「0,1,4,8=降落族」与 1.16.1 ordinal 表对不上，见 §2.6） | 研究线文档，设计会话裁决 |
| 5 | **栖息窗口的稳定获取（本单头号卡点）**：需要实测「怎么把龙稳定引到出口门柱落地」——候选：站水晶柱顶 / 断视线 / 引它冲脸后撤 / 主动挨打到它进 LANDING。**本单一个都没验** | **S6 立项**（见 §8.1 复核门第 2 条） |

---

## 8. 收工核验

```
[cleanup 17:47:43] start (standalone cleanup)：stdin stop → 强杀本线残留 → 删 world → 复核
[cleanup 17:47:44]   ! :25567 pid=16432 归属活着的 runner（runner:25136）→ 疑似并行会话，不动
[cleanup 17:47:47]   verify: 本线 ports 25566,25576,8091 全空闲
                   | 其他开发线在用 25567,25577,25568（不算脏）
                   | 本线残留 java/node 0（外部 runner 在跑，含其他开发线，已排除）
                   | 空闲内存 4302MB（≥2560MB 才够下一条泳道）
[cleanup 17:47:47]   CLEAN
```

- **本线残留进程 0**：本单最后一个孤儿 java（18740，父 runner 已被我停掉）被 ROUTE-02 的
  `preflight --kill-stale` 按"心跳过期 + 无活 runner"正确清理——手册 §9 那道安全阀在起作用。
- **泳道 C 的 world 未删**：收工时泳道 C 已由 ROUTE-02 接管（runner 26168，新起服 1:48:18，
  `spike_world` 1:47:52 仍在写）。按隔离纪律**不碰别人的世界**；下局 `freshWorld` 本来也会清。
- **未合并、未 push**：`mindcraft-wt/end-probe` 分支 `aidqq/end-probe`，共享文件零改动。**停在复核门。**

### 8.1 复核门请设计会话裁决的 4 件事

1. **结论定性**：本单给的是「不可行（当前状态）」，卡点是**栖息窗口获取**，不是信号可见性。
   是否接受这个定性、是否据此下调末地段（v1 预算 155s）的信心，需要裁决。
2. **Y 的解法方向**（本单不追，供 S6 立项）：见 §7 第 5 条。**需要实跑，本单没做。**
3. **stage-06 文档要改**（§1.2 三条 + §6 提效条目②）：本单**未自行改**研究线文档，等设计会话落笔。
4. **剩余验收项**：10 次栖息面板、整条龙 5 局 ≥3 杀、easy 观察 2 局——**顺延到下一轮机时**。
   布景开关（`--god-mode` / `--park-tp` / `--tp` / `--crystal-janitor`）都已就绪，可直接复跑：

   ```powershell
   $env:MC_MINDCRAFT_ROOT='D:\AI斗蛐蛐\mindcraft-wt\end-probe'
   $env:MC_BENCH_SERVER='D:\AI斗蛐蛐\experiments\mc1161-gate\server-1161'
   $env:MC_BENCH_JAR='server-1.16.1.jar'
   node bench\stages\end-probe\run_probe.mjs --mode detect --trials 1 --stamp DETECT4 --max-perch 10 `
        --timeout-ms 1800000 --crystal-janitor none --park-tp "100 50 0" --lane-wait-s 5400
   node bench\stages\end-probe\run_probe.mjs --mode kill --trials 5 --stamp KILL5b --god-mode `
        --park-tp "100 50 0" --tp "3 70 0" --crystal-janitor none --timeout-ms 600000 --lane-wait-s 1800
   node bench\stages\end-probe\run_probe.mjs --mode easy --trials 2 --stamp EASY2 --god-mode `
        --park-tp "100 50 0" --tp "3 70 0" --crystal-janitor none --timeout-ms 600000 --lane-wait-s 1800
   ```

