> ⚠️ **更正（2026-10-02，设计会话，依据 E 线 END-01-2 的字节码复核）**：①非龙头部位伤害 = `amount/4 + min(amount,1)`（本文少写了 min）；②DATA_PHASE 初值 = HOVERING(10)，不是 STRAFE(1)；③盘旋时转去追击的条件是 `nextInt(⌊D²/512⌋+2)==0 || nextInt(存活水晶+2)==0`，D = 玩家到门柱的距离（门柱上 1/2，64 格外 1/10），目标是**玩家**；本文"降落后 64 格内有玩家 ⇒ 1/2"不准确。其余条目仍有效。

# 1.16.1 末影龙阶段转换表（独立核验）

> 研究线交付 · 2026-10-02 · **只读任务**：未开服、未启动任何进程、未改 `mindcraft/` / `bench/` / `production/`，未占用端口。
> 本单**独立**从字节码重建，未参考 E 线（END-01）的任何报告或结论；§6 的对照意见全部由本单自己的证据推出。

---

## 1. 核验对象与方法

### 1.1 二进制与映射

| 项 | 值 |
|---|---|
| jar | `experiments/cam1161/server-1161/server-1.16.1.jar` |
| **sha256** | `2782D547724BC3FFC0EF6E97B2790E75C1DF89241F9D4645B58C706F5E6C935B` |
| `pack.mcmeta` | `pack_format: 5` |
| 名称表 | `docs/research/data/mappings-1161/server-1161-mappings.txt`（4213 个类，无重名） |
| 本单产物 | `docs/research/data/mappings-1161/javap/*.txt`（18 个类的 `javap -p -c` 全文）、`resolve.ps1`、`findm.ps1` |

工作区另有 3 份该 jar（`mc1161-gate/server-1161`、`mc1161-gate/downloads`、`seed-scout/server`），**sha256 与上表逐字相同**，即同一份产物。

> ⚠️ **patch 级严谨性**：`pack_format=5` 覆盖 1.16.1–1.16.5 整个家族，单靠它无法把 patch 钉死到 1.16.1。本单的**全部数字都直接读自上面这个 sha256 的字节**（相位 id、转换条件、常数、元数据索引都没有查表、没有查记忆），所以只要实跑用的是同一份 jar，本单结论就成立。**若日后要对外声称"1.16.1 专属行为"，请另找 patch 判别式复核。**

### 1.2 复现命令

```powershell
$jar='experiments\cam1161\server-1161\server-1.16.1.jar'
foreach($c in 'bas','bat','bai','baq','bak','bal','bao','bap','ban','bar','bag','baj','bah','bae','bam','bac','cii','baf'){
  javap -p -c -classpath $jar $c | Out-File "docs\research\data\mappings-1161\javap\$c.txt" -Encoding utf8
}
# 混淆名 -> 官方名
.\docs\research\data\mappings-1161\resolve.ps1 -Names @('bai','bas','bac')
# 全 jar 扫描某个 setPhase 描述符的调用方
```

### 1.3 一个必须写下来的坑：`javap -p` 会误导

本单中途踩过一次，记录下来给后面的人省时间：

`bai.class` 的常量池里有 `bqb.a:(Laxs;DDD)Lbec;`（`javap -v` 第 146 项），但 `javap -p bqb` 的 114 个方法里**没有任何**带 `axs` 参数的方法 —— 看起来像坏包。

真相：该方法声明在**接口** `bps` = `net.minecraft.world.level.EntityGetter` 上（`javap bps` 可见 `public default bec a(axs, double, double, double);`），`bqb` = `Level` 通过 `bqc` = `LevelReader` 间接继承它。`javap -p` **只列本类声明的成员**，不含继承来的默认值方法。

**纪律**：跨类判断"某方法存不存在"时，不要用 `javap -p` 单类输出下结论，要沿着 `implements/extends` 链往上查，或直接读常量池。混淆包里字段名与方法名可以同名（如 `bac.l` 既是 `Level` 字段、又是 `Level` 取值方法），别当成重复条目删掉。

---

## 2. 相位枚举与 id（**不依赖映射表**）

`EnderDragonPhase`（混淆名 `bas`，`javap bas.txt`）是个手写的枚举替身：私有静态方法
`a(Class, String)`（`bas.txt:131-155`）用 `phases[].length` 当 id 构造，即 **id = 声明顺序**；`getById(int)`（`bas.txt:110-123`）按 `l[id]` 直查。

两个来源交叉确认，两边完全一致：

| id | 官方名（`bas` 常量池字符串） | 混淆常量 | 实例类 | 混淆类 |
|---|---|---|---|---|
| 0 | `HoldingPattern` | `bas.a` | `DragonHoldingPatternPhase` | `bai` |
| 1 | `StrafePlayer` | `bas.b` | `DragonStrafePlayerPhase` | `baq` |
| 2 | `LandingApproach` | `bas.c` | `DragonLandingApproachPhase` | `bak` |
| 3 | `Landing` | `bas.d` | `DragonLandingPhase` | `bal` |
| 4 | `Takeoff` | `bas.e` | `DragonTakeoffPhase` | `bar` |
| 5 | `SittingFlaming` | `bas.f` | `DragonSittingFlamingPhase` | `bao` |
| 6 | `SittingScanning` | `bas.g` | `DragonSittingScanningPhase` | `bap` |
| 7 | `SittingAttacking` | `bas.h` | `DragonSittingAttackingPhase` | `ban` |
| 8 | `ChargingPlayer` | `bas.i` | `DragonChargePlayerPhase` | `bag` |
| 9 | `Dying` | `bas.j` | `DragonDeathPhase` | `bah` |
| 10 | `Hover` | `bas.k` | `DragonHoverPhase` | `baj` |

**出处**：`bas.txt:157-206`（`<clinit>` 按序 `ldc` 各实例类 + 各名字符串 + `putstatic`）；官方名与混淆类的对应见映射表 28090–28114 行。

**所以客户端看到的相位数字就是 0–10 这一列，与任何外部表格无关。** 注意 0/1 是**巡航**族（盘旋 / 追击），8 是**冲撞**，不是降落族。

---

## 3. 完整转换表（每条 = 一个 `setPhase` 调用点）

穷举方式：对全 jar 4213 个 class 扫常量池描述符 `(Lbas;)V`（`setPhase` 签名），
命中且仅命中 12 个类：`bac bag bai bak bal ban bao bap baq bar bat cii`。
`bah`（Dying）、`baj`（Hover）、`baf`（AbstractDragonSittingPhase）**不含** `setPhase`。

`setPhase` 语义（`bat.txt:27-77`）：目标 == 当前相位则**直接 return**；否则 `旧相位.end()` → 换引用 → **把 id 写进 SynchedEntityData**（客户端可见）→ `新相位.begin()`。

| # | 源相位 / 位置 | 条件 | 目标 | 出处（混淆类.方法 · 字节码偏移） |
|---|---|---|---|---|
| T1 | 构造 `EnderDragonPhaseManager` | 无条件 | `Hover`(10) | `bat.<init>` · `bat.txt:19-23` |
| T2 | `EndDragonFight.createNewDragon()` | 龙在 `(0,128,0)` 生成后立即 | `HoldingPattern`(0) | `cii.o()` · `cii.txt` 偏移 `34-41` |
| T3 | `EnderDragon.readAdditionalSaveData` | 存档含 `"DragonPhase"` | `getById(NBT int)` | `bac.a(le)` · 偏移 `15-29` |
| T4 | `EnderDragon.handleEntityEvent`（**仅客户端**） | 事件 == `DATA_PHASE` 且 `level.isClientSide` | `getById(元数据 int)` | `bac.a(tq)` · 偏移 `20-43` |
| T5 | `EnderDragon.reallyHurt` | `isDeadOrDying() && !当前相位.isSitting()` | **`Dying`(9)** | `bac.f(Lanw;F)Z` · 偏移 `94-128` |
| T6 | `EnderDragon.hurt(DragonPart,…)` | 栖息态下累计伤害 **> 50**（见 §5.2） | **`Takeoff`(4)** | `bac.a(Lbaa;Lanw;F)Z` · 偏移 `131-193` |
| T7 | `DragonHoldingPatternPhase` 掷骰 | `random.nextInt(3 + getCrystalsAlive()) == 0` | **`LandingApproach`(2)** | `bai.j()` · 偏移 `70-95` |
| T8 | `DragonHoldingPatternPhase` 择敌 | 见 §4.2 | `StrafePlayer`(1) | `bai.j()` · 偏移 `166-208` → `bai.a(Lbec;)V` 偏移 `0-33` |
| T9 | `DragonHoldingPatternPhase.onCrystalDestroyed` | `player != null && !player.abilities.invulnerable` | `StrafePlayer`(1) | `bai.a(Lbab;Lfu;Lanw;Lbec;)V` · 偏移 `16-19` |
| T10 | `DragonStrafePlayerPhase` 目标为空 | `attackTarget == null` | `HoldingPattern`(0) | `baq.c()` · 偏移 `17-30` |
| T11 | `DragonStrafePlayerPhase` 火球命中 | 见 §5 | `HoldingPattern`(0) | `baq.c()` · 偏移 `617-627` |
| T12 | `DragonLandingApproachPhase` 走到头 | `currentPath != null && isDone()` | `Landing`(3) | `bak.j()` · 偏移 `221-231` |
| T13 | `DragonLandingPhase` 落到点 | `distSqr(landingPos) < 1.0`（且先 `resetFlameCount()`） | `SittingScanning`(6) | `bal.c()` · 偏移 `58-92` |
| T14 | `DragonSittingScanningPhase` 发现人 | `scanningTime > 25` 且 20 格内有人（±10 y） | `SittingAttacking`(7) | `bap.c()` · 偏移 `54-76` |
| T15 | `DragonSittingScanningPhase` 没人 | `scanningTime >= 100` 且无近人 | `Takeoff`(4) | `bap.c()` · 偏移 `411-421` |
| T16 | `DragonSittingScanningPhase` 续上 | 紧接 T15，150 格内找到人 | `ChargingPlayer`(8) | `bap.c()` · 偏移 `428-438` |
| T17 | `DragonSittingAttackingPhase` | `attackingTicks >= 40` | `SittingFlaming`(5) | `ban.c()` · 偏移 `11-26` |
| T18 | `DragonSittingFlamingPhase` 第 4 轮后 | `flameTicks >= 200 && flameCount >= 4` | `Takeoff`(4) | `bao.c()` · 偏移 `20-38` |
| T19 | `DragonSittingFlamingPhase` 前 3 轮 | `flameTicks >= 200 && flameCount < 4` | `SittingScanning`(6) | `bao.c()` · 偏移 `44-54` |
| T20 | `DragonTakeoffPhase` 回到台子 | `!END_PODIUM.closerThan(dragon.position(), 10.0)` | `HoldingPattern`(0) | `bar.c()` · 偏移 `43-70` |
| T21 | `DragonChargePlayerPhase` 无目标 | `targetLocation == null` | `HoldingPattern`(0) | `bag.c()` · 偏移 `17-28` |
| T22 | `DragonChargePlayerPhase` 蓄力满 | `chargeTicks >= 10` | `HoldingPattern`(0) | `bag.c()` · 偏移 `49-64` |

**无出口相位**：`Hover`(10)（`baj.txt` 全文无 `setPhase`）、`Dying`(9)（`bah.txt` 同）。

**必须注意 T5 的前置**：只有"当前相位**不是**栖息态"才进 `Dying`。所以在栖息/降落族里把龙打死**不会**进死亡演出（`isSitting()` 在 `baf.a()Z` 返回 `true`，`baf.txt:10-13`）。

---

## 4. 三个专项问题

### 4.1 派单问题①：进入栖息的全部路径与概率条件

**穷举结论：进入栖息（`{2,3,5,6,7}`）的唯一入口是 `HoldingPattern` 的 T7 一次掷骰。**

由 §3 的表反查：指向 2 的边只有 T7（`bai`）；指向 3 的边只有 T12（`bak`）；5/6/7 全部在栖息族内部互转。没有任何相位类之外的类（`bac` / `cii`）会跳进栖息族 —— `bac` 的四处只跳 9/4/存档值/元数据值，`cii` 一处只跳 0。

**掷骰本身**（`bai.j()` 偏移 `41-95`，复原）：

```java
int i = 0;
EndDragonFight fight = dragon.getDragonFight();
if (fight != null) i = fight.getCrystalsAlive();          // cii.c()I  → 映射 462:462 getCrystalsAlive()
if (dragon.getRandom().nextInt(i + 3) == 0) {             // 偏移 70-79
    dragon.getPhaseManager().setPhase(EnderDragonPhase.LANDING_APPROACH);
    return;
}
```

- 概率 = **1 / (3 + 存活水晶数)**。10 水晶 → 1/13 ≈ **7.7%**；水晶全清 → **1/3**。
- 顺带证实 stage-06 记的这条概率**成立**，且分母是 `getCrystalsAlive()` 而非"总数"。
- `getDragonFight() == null`（不在真实末地战斗里）时 `i=0` → 1/3。

**掷骰不是每 tick 一次。** `findNewTarget()` 的第一道门（`bai.j()` 偏移 `0-14`）是
`if (crystalDestroyed == null || crystalDestroyed.isDone())` —— 只有"当前水晶摧毁路径已走完"才重掷。
所以实际落地频率 = （路径走完的频率）× 1/(3+N)。

**`findNewTarget()` 什么时候被调**（`bai.c()` 偏移 `40-77`，逐字节还原，注意 `iflt/ifgt` 的目标是 76=掷骰入口）：

```java
double d0 = (nearestCrystal == null) ? 0.0
        : nearestCrystal.distanceToSqr(dragon.getX(), dragon.getY(), dragon.getZ());
if (d0 < 100.0D || d0 > 22500.0D || dragon.horizontalCollision || dragon.verticalCollision) {
    this.findNewTarget();
}
```

即：**离目标水晶 <10 格 或 >150 格、蹭墙、或贴地（verticalCollision）** 才重新择路。
`DragonLandingApproachPhase`（`bak.c()` 偏移 `40-69`）、`DragonChargePlayerPhase`（`bag.c()` 偏移 `97-130`）是同一份判据的三处副本。
`bac.u()` / `bac.v()` 经映射表核实为 `Entity.horizontalCollision` / `Entity.verticalCollision`（Entity 块 `boolean horizontalCollision -> u`、`boolean verticalCollision -> v`）。

**降落的落点就是出口传送门**（这是 §7 最有用的一条）：

- `bak.j()` 偏移 `25-70`、`bal.c()` 偏移 `7-27`、`bar.c()` 偏移 `26-42` 都取
  `level.getHeightmapPos(Heightmap.Types.?, EndPodiumFeature.END_PODIUM_LOCATION)`；
- `EndPodiumFeature.<clinit>`（`cks`）只有一句 `a = fu.b`，而 `fu.b` 在 `BlockPos.<clinit>` 偏移 `32-42` 是 `new BlockPos(0,0,0)`
  ⇒ **`END_PODIUM_LOCATION` = (0,0,0)**，映射表也把它写成 `END_PODIUM_LOCATION -> a`；
- `EndDragonFight.spawnExitPortal(boolean)`（`cii.a(Z)V` 偏移 `16-33`）取的是**同一个**高度图位置再 `.below()`：
  `portalLocation = level.getHeightmapPos(…, END_PODIUM_LOCATION).below()`，并校验该格是 `Blocks.END_PORTAL_FRAME`（`bvs.z`）且高于海平面。
- `EndDragonFight.findExitPortal()`（`cii.j()` 偏移 `0-27`）在 x,z ∈ [−8,8] 的区块里找 `TheEndPortalBlockEntity`（`cen`），与"门在原点附近"一致。

⇒ **龙的降落点 = 出口传送门**，而门的高度由 **(0,0) 那一列的 MOTION_BLOCKING 高度图**决定（`EndPodiumFeature` 名字也写明是"end podium"）。
`bal.c()` 的到位判据是 `distSqr(landingPos) < 1.0`（偏移 `58-60`），即**必须真的贴到门中心那一格**才进栖息。

> `cio$a.f`：按 `Heightmap.Types.<clinit>` 的显式 ordinal（`WORLD_SURFACE_WG=0→a …`）与映射表字段顺序，`f` = `MOTION_BLOCKING_NO_LEAVES`。末地没有树叶，两个 MOTION_BLOCKING 变体在此等价，不影响结论。

### 4.2 派单问题②：`StrafePlayer` 的**全部**出口

`DragonStrafePlayerPhase` 的字段只有 5 个（`baq.txt:3-13`）：
`fireballCharge(int c)`、`currentPath(Path d)`、`targetLocation(Vec3 e)`、`attackTarget(LivingEntity f)`、`holdingPatternClockwise(boolean g)`。

**没有 tick 计数器。全文 593 行里只有两处 `setPhase`：**

| 出口 | 条件 | 偏移 |
|---|---|---|
| ① `attackTarget == null` | `begin()` 把 `f` 置空；进来时没目标就**下一 tick 立刻退回**，并打 warn 日志 **`"Skipping player strafe phase because no player was found"`** | `0-30` |
| ② 火球打出 | 见 §5 | `617-627` |

`findNewTarget()`（`baq.j()`）**不换相位**，只重挑路径与 `targetLocation`。

**`setTarget` 全 jar 只有一个调用方**：扫"同时含 `baq` 与 `(Laoy;)V`"的 class → 只有 `bai.class` 与 `baq.class`（自身定义）。
`baq.setTarget(LivingEntity)` 的唯一调用点是 `bai.a(Lbec;)V`（`strafePlayerAt`），即 **`StrafePlayer` 只能由 `HoldingPattern` 赋予目标**。

⇒ 推论（可实测）：**任何非 `strafePlayerAt` 路径进入 `StrafePlayer`，下一 tick 必弹回 `HoldingPattern`(0)，且日志里必有上面那句 warn。**
`begin()` 置空 `f`（`baq.d()` 偏移 `15-19`），而 `bai.a(Lbec;)V` 是先 `setPhase` 再 `setTarget`（偏移 `0-33`）——顺序正确，所以正常路径不会踩这条。

`strafePlayerAt(player)` 的两个上游（都在 `HoldingPattern` 内）：

- **T8**：`random.nextInt(3+N) != 0`（没掷中落地）之后，再掷
  `nextInt(Mth.abs((int)d1) + 2) == 0` **或** `nextInt(N + 2) == 0`
  （`bai.j()` 偏移 `166-199`，两者是**或**关系：`ifeq 202` 跳过第二个判断）。
  `d1` 初始 64.0，若 64 格内找到玩家则 `d1 = blockpos.distSqr(player.position(), true) / 512.0`
  （`BlockPos.distSqr(Position, boolean)` 见映射 215:215），`floor` 后 ∈ [0, 0.125] ⇒ **该分支恒为 `nextInt(2) == 0`，即 1/2**。
  换句话说：**只要有玩家在 64 格内，落地掷骰没中之后就有约一半概率去抓玩家。**
- **T9**：`onCrystalDestroyed(crystal, blockpos, source, player)`，判据 `player != null && !player.abilities.invulnerable`（`Abilities.invulnerable -> a`，`bdz` 块）。即**旁观型/创造玩家打水晶不会招来龙**。

### 4.3 派单问题③：攒火球是否要求视线、多久超时

**要求视线，而且是硬闸。** `baq.c()` 偏移 `210-239`：

```java
if (this.attackTarget.distanceToSqr(this.dragon) < 4096.0D) {   // 目标在 64 格内
    if (this.dragon.canSee(this.attackTarget)) {                 // ← 视线闸，偏移 228-239
        this.fireballCharge++;                                   // 偏移 242-249
        ...
    } else {
        if (this.fireballCharge > 0) this.fireballCharge--;      // 偏移 633-650：失视线 → 每 tick 衰减 1
    }
} else {
    if (this.fireballCharge > 0) this.fireballCharge--;          // 偏移 653-667：超 64 格 → 同样衰减
}
```

- `canSee` = `Entity.canSee(Entity)`（映射 2709:2711），是真实的方块射线，**没有任何豁免**。
- 计数只在"64 格内 **且** 有视线"时 `+1`；一旦失去视线或距离超限，**每 tick −1**。
- **没有任何超时**：`StrafePlayer` 里没有 tick 计数，也没有"最多 N tick 后强制退出"的分支（`baq.txt` 全文核对过）。

**火球开火判据**（`baq.c()` 偏移 `367-387`）：

```java
if (this.fireballCharge >= 5
        && f3 > 0.0F && f3 < 10.0F) { ... 发射 → fireballCharge = 0 → setPhase(HoldingPattern) }
```

`f3`（偏移 `290-365`）= `degrees(acos(forwardVec · toTargetVec)) + 0.5F`，其中 `forwardVec` 由 `dragon.getYRot()` 构造、`toTargetVec` 是**水平**方向向量。
即：**必须瞄准玩家正前方约 9.5° 以内**才发。

⇒ 完整开火条件：**目标 ≤64 格 + 全程有视线 + 连续 ≥5 tick 有视线（中途断线会回落）+ 玩家落在龙吻前方 ±9.5°。**
凑不齐就永远攒不满 → 火球永不发射 → 相位永不退出。**这就是"能看见龙"与"龙能看见 bot"是两件事的原因。**

---

## 5. 栖息一轮的完整时序（把上面的 tick 换算成秒）

1.16.1 服务端 20 TPS。`SITTING_*` 三段全是**纯 tick 计数**，无随机：

| 相位 | 计时条件 | tick | 秒 |
|---|---|---|---|
| `SittingScanning`(6) | 20 格内有人（`TargetingConditions.range(20)`，谓词 `|目标y − 龙y| ≤ 10`） | `> 25` → 转 7 | 1.25 s |
| `SittingAttacking`(7) | 无条件 | `>= 40` → 转 5 | 2.0 s |
| `SittingFlaming`(5) | 无条件；`flameTicks == 10` 时生成 `AreaEffectCloud`（时长 200 tick，`bao.c()` 偏移 `60-66 / 261-355`） | `>= 200` → 转 6 或 4 | 10.0 s |
| `SittingScanning`(6) | 20 格内**无人** | `>= 100` → 转 4（+8 若 150 格内有人） | 5.0 s |

`flameCount` 在 `begin()` 里 **+1**（`bao.d()` 偏移 `5-12`），并在 `DragonLandingPhase` 到位时被 `resetFlameCount()` 清零（`bal.c()` 偏移 `63-79` → `bao.j()`）。

⇒ **每次降落后，龙最多栖息 4 轮 ≈ 13.25 s × 4 ≈ 53 s**，然后强制 `Takeoff`。
⇒ **想让龙多停，得有人在 20 格内且 |Δy| ≤ 10**；一旦没人 5 s 就走。

栖息期的两个额外机制（对床爆直接相关）：

- **`AbstractDragonSittingPhase.getDamageMultiplier`**（`baf.txt:15-32`）：`if (damageSource.getEntity() instanceof AbstractArrow) { setSecondsOnFire(1); return 0.0F; }` ⇒ **栖息态下箭矢伤害恒为 0**（`beg` = `AbstractArrow`）。S6 砍箭线是对的，但理由要写对。
- **非龙头部位吃 ×1.25 伤害**（`bac.a(Lbaa;…)` 偏移 `35-53`）：`if (part != this.head) amount = amount / 4.0F + amount;`。E2 测"每张床多少伤害"时必须记录命中的是不是龙头，否则数字会系统性偏 25%。

### 5.2 T6 的 50 点线：床爆设计的硬约束

`EnderDragon.hurt(EnderDragonPart, DamageSource, float)` 全文还原（`bac.txt` 该方法）：

```java
if (currentPhase.getPhase() == DYING) return false;                       // 偏移 0-19
amount = currentPhase.getDamageMultiplier(source, amount);                 // 20-34（栖息态把箭矢清零）
if (part != this.head) amount = amount / 4.0F + amount;                    // 35-53（非龙头 ×1.25）
if (amount < 0.01F) return false;                                          // 54-63

if (source.getEntity() instanceof Player || source.isExplosion()) {        // 64-78
    float before = this.getHealth();                                       // 81-85
    this.reallyHurt(source, amount);                                       // 87-93
    if (isDeadOrDying() && !currentPhase.isSitting())                      // 94-113
        setPhase(DYING);                                                   // 121-128
    if (currentPhase.isSitting()) {                                        // 131-143
        this.sittingDamageReceived = (int)((float)this.sittingDamageReceived
                                           + before - this.getHealth());     // 146-161
        if ((float)this.sittingDamageReceived > 0.25F * this.getMaxHealth()) {  // 164-178
            this.sittingDamageReceived = 0;
            setPhase(TAKEOFF);                                             // 186-193
        }
    }
    return true;
}
return false;
```

⇒ 四条对 E2 直接有用的结论：

1. `0.25F × getMaxHealth()`，而 `EnderDragon.createAttributes()`（`bac.m()` 偏移 `6`）注册 `MAX_HEALTH = 200.0` ⇒ **阈值 = 累计 50 点，严格大于**（`fcmpl` + `ifle` ⇒ 等于 50 **不**起飞）。
2. 累加器是 `sittingDamageReceived += (before - after)`，即**栖息态下累计"实际扣掉的血"**；只在 `isSitting()` 时累加（`Hover`(10) 的 `isSitting()` 也返回 true，见 `baj.txt:24-27`）。起飞时清零。
   ⇒ **单张床伤害 < 50 就能安全地攒，多打几张才起飞；一旦某一张把累计推过 50，龙当场 `Takeoff`，本轮栖息窗口结束。**
3. 闸门是 `source.getEntity() instanceof Player || source.isExplosion()`（`anw.k()` = `getEntity()`、`anw.d()` = `isExplosion()`，映射 179:179 / 134:134）。**床爆天然满足 `isExplosion()`**，所以不依赖"引爆者是不是玩家"，这条对自动化布景很友好。
4. T5 的 `Dying` 分支要求 `!isSitting()` ⇒ **在栖息态把龙打死不会进死亡演出**，也就拿不到掉落；`DYING` 相位下 `hurt(DragonPart,…)` 直接返回 false（偏移 `0-19`）。


---

## 6. 客户端可读信号（本单独立复算，未看 E 线）

1.16.1 客户端拿相位有**三条**互相印证的路径，全部出自本 jar：

1. **元数据**：`EnderDragonPhaseManager.setPhase`（`bat.txt:49-76`）每次换相位都执行
   `dragon.getScoreboardData().b(DATA_PHASE, phase.getId())`。
   **索引 15 由本单独立数 `defineId` 调用点得出**（`SynchedEntityData.defineId` 混淆名 `tt`，数 `tt.a:(Ljava/lang/Class;…)`）：

   | 类 | defineId 次数 | 占用索引 |
   |---|---|---|
   | `Entity` `aom` | 7 | 0–6 |
   | `LivingEntity` `aoy` | 7 | 7–13 |
   | `Mob` `aoz` | 1 | 14 |
   | `EnderDragon` `bac` | **1** | **15** |

   `EnderDragon` 只定义了这一个 accessor —— 它在 `bac.<clinit>`（映射 27936 行 `59:63:void <clinit>()`，全文 5 条指令：`DATA_PHASE = SynchedEntityData.defineId(EnderDragon.class, INT)`），它就是 `DATA_PHASE` ⇒ **metadata[15] = 相位 id（int，0–10）**。
   同法数 `LivingEntity.<clinit>` 的 7 次顺序（`an,e,f,g,bo,bp,bq`）得 `DATA_HEALTH_ID` = **索引 8**（`LivingEntity` 块字段序 `DATA_HEALTH_ID -> e`，且它是本类第 2 次 `defineId`）。

2. **存档**：NBT 键是**字符串 `"DragonPhase"`**，值是 int（`bac.a(le)` 偏移 `6-29`，常量池 `#877 = String DragonPhase`）。

3. **原版客户端自己就这么读**：`EnderDragon.handleEntityEvent`（`bac.a(tq)` 偏移 `20-43`）在 `isClientSide()` 时执行
   `setPhase(EnderDragonPhase.getById(scoreboardData.getInt(DATA_PHASE)))`。
   ⇒ **"读元数据 int → 查 id 表"就是原版客户端的官方做法**，我们的读法与之同构。

> ⚠️ **一个容易踩的初值坑**：`EnderDragon.defineSynchedData`（`bac.e()` 偏移 `8-17`）把 `DATA_PHASE` 的**默认值设成 `bas.b` = `STRAFE_PLAYER` = 1**，而不是管理器构造时的 `Hover`(10)。元数据只在下一次 `setPhase` 时才被覆盖。所以客户端读到的第一个值是 **1**，不是 10 —— 把它误当成"龙在追击"会得到假阳性。实战里 `createNewDragon()` 紧接着就 `setPhase(0)`，但**读数器应当对 id==1 的首个样本加冷启动闸门**。

**值域提醒**：相位 0–10 本身在 int 里是正数，**不存在符号问题**。有符号读炸的是**血量**——`metadata[8]` 的龙血量 200 若按有符号 int8 通路读会变成负数，这与相位字段是两条独立通路，不要混用判据。

---

## 7. 给 S6 的可执行结论（全部出自上表，可直接进开发单）

1. **栖息点不用猜，就是出口传送门**：落点 = `getHeightmapPos(MOTION_BLOCKING_NO_LEAVES, (0,0,0))`，门在它下面一格。布景应按"门柱 + (0,0) 列的地面高度"布置，而不是按"主岛中心"估。
2. **"让龙愿意降落"的唯一旋钮是水晶数**：落地概率 = 1/(3+存活水晶)。**清空水晶把 7.7% 抬到 33%**（约 4.3×），这是唯一在客户端可读、且不靠运气的杠杆。
3. **降落后 64 格内有玩家 ⇒ 下一轮有 1/2 概率被拉去抓玩家**（T8）。所以"先降落后立刻贴上去打床"会被打乱：想稳定吃栖息窗口，要么确保掷骰落在栖息上，要么接受落地后龙马上转 STRAFE。
4. **想续栖息就得贴住**：20 格内且 |Δy| ≤ 10 才不会在 5 s 后 `Takeoff`；一轮最多 13.25 s，整次最多 4 轮 ≈ 53 s。
5. **栖息态箭矢 0 伤害；累计伤害过 50 当场顶飞**（§5.2）。E2 测每床伤害时**必须记命中的是不是龙头**（非龙头 ×1.25），否则数字系统性偏 25%；单张床 < 50 可安全累积。床爆天然满足 `isExplosion()` 闸门，不依赖"引爆者是不是玩家"。
6. **STRAFE_PLAYER 只能由 `HoldingPattern` 喂目标**；没有视线时它**不会超时退出**，只会在 `attackTarget == null` 时弹回。若日志里出现 `"Skipping player strafe phase because no player was found"`，说明进了 `StrafePlayer` 但没人给它目标。
7. **相位 id 是 0/1 巡航、2/3 降落、5/6/7 栖息、4 起飞、8 冲撞**；判"栖息"= id ∈ {5,6,7}，判"降落中"= {2,3}。

---

## 8. 本单**没有**确定的事（留给复核门）

1. **patch 级版本**：见 §1.1 的 `pack_format` 说明。若要对外声明"1.16.1 专属"，需另找判别式。
2. **`canSee` 的射线细节**（是否穿透半砖、是否受 1.16 的碰撞形状影响）本单只确认了"它就是 `Entity.canSee`，是硬闸"，未逐层追它的射线实现。需要精确判定"什么样的掩体会断视线"时，要再往下挖 `Entity.canSee` → `clip`。
3. **各相位的实际停留时长分布**是理论值（本表 tick 计数即真值），但**相位图本身何时被掷中**是随机的，落地间隔的方差无法静态给出。
4. **`getHeightmapPos` 在 (0,0) 列的确切 Y** 依赖该列地形，需实跑一次读数（本单只读不开服）。
5. **本单未验证 `EndDragonFight.getCrystalsAlive()` 在 peaceful + kit 下的实际返回值路径**（只确认了它是 `crystalsAlive` 字段的读取）。

---

## 9. 复核门

**停在这里，等设计会话裁决。** 本单未动任何代码 / 服务器 / 端口 / 其他线的文件。

需要设计会话拍板的三件事：

1. **是否接受"栖息点 = 出口传送门、门在 (0,0) 列"这条作为 S6 布景的硬前提**（若接受，下一单可据此做站级几何勘测：只需测 (0,0) 列的地面高度与门朝向）。
2. **是否把"清空水晶换 4.3× 落地概率"写进 S6 的前置**（代价是放弃水晶阻止回血/回血水晶增益，以及龙会频繁贴脸）。
3. **E 线与本单的对照口径**：本单只给出字节码事实，**没有**对 E 线报告下判断。若要正式对照，请把 E 线的 `setPhase` 清单交给设计会话做 diff，不要由本单单方面"纠正"（AGENTS.md 的隔离纪律 + 派单要求两份独立）。

**复现入口**：`docs/research/data/mappings-1161/javap/`（18 个类的 `javap -p -c` 全文，sha256 见 §1.1），`resolve.ps1`（混淆↔官方名）、`findm.ps1`（按签名反查官方名）。
