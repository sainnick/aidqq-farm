# MC-CLOUD-03 任务单｜测试农场（泳道 Y）搭建 + 接手 F 线（S2 易物）

> 派发对象：大云端机器上的 agent（Ubuntu 24.04、32 核、123GB 内存、256GB overlay 盘、无 GPU、能上网）。复核：本地设计会话。
> 这是《AI斗蛐蛐》Minecraft 线的一部分。本机只做**无画面的 bench 测试**和 F 线开发，不做拍摄。
> 遇到颠覆性结论先停下报告；不扩大范围。

## 0. 背景

- 项目：用本地任务层（Mineflayer）在 1.16.1 vanilla 固定种子上通关 Minecraft，最终目标成绩约 10 分钟。全程零 LLM、零 key。
- 本地开发机最多同时跑 3 个测试服，小云端机（3GB）只能跑 1 个，各开发线一直在排队。**本机的定位是"测试农场"**：同时跑十几条泳道，跑正式矩阵，并且承担 F 线。
- 代码在两个私有仓库：`sainnick/aidqq-bench`（master；小云端机的 Linux 单泳道 runner 在分支 `cloud/lane-x` 的 `cloud/` 目录里）、`sainnick/aidqq-mindcraft`（`aidqq/main` 主线）。
- 必读文档在 `aidqq-bench` 的 `cloud/docs/` 下（本地文档的快照）：`MC-手册.md`（重点：§3 坑表、§4 验收协议、§5 归因规则、§7 公平口径、§9 并行与进程规则；Windows 专用的部分按 Linux 处理），以及 F 线要用的那几份（见 §2）。
- 先读 `cloud/CLOUD-01-任务单.md` 和 `cloud/CLOUD-01-报告.md`（在 `cloud/lane-x` 分支上）：环境配方、踩过的坑（Adoptium 限速 → 改用 Microsoft Build of OpenJDK 11.0.32.1；NFS 删除；TPS 公式；不要自己拍 TP 坐标），这里都适用。

## 1. P0 搭农场（先做）

1. **GitHub 认证**：`gh auth login` 设备码流程，让用户在浏览器授权；令牌不写进任何文件。
2. 克隆两个仓库。bench 在**新分支 `cloud/farm-y`** 上工作：从 `cloud/lane-x` 切出，再 `git merge master`。
3. 环境照 CLOUD-01 配方：JDK 11、vanilla 1.16.1 server jar（校验 sha1）、只装 bench 实际用到的 npm 包（本机内存充足，但清单要和小云端机一致，便于复现）。**先确认 overlay 盘在会话之间是否持久**；不持久的话，环境要能用一个脚本一键重建（`cloud/farm_setup.sh`）。
4. **多泳道 runner**：把 `cloud/run_lane.mjs` 扩展成 `cloud/run_farm.mjs`：N 条泳道并行，泳道 i 用端口 `25600+i`（RCON `25700+i`），各自独立的服务器目录、bot 名和世界。每局开服前查一次空闲内存和平均负载，资源不够就排队。只结束**自己 spawn 出来的子进程**（手册 §9.2）。
5. **并行一致性验收**：BASIC-bootstrap 用本地基线 M4B4 的 **20 个种子**（种子名单在 `stages/portal/run_portal.mjs` 的 P2C_M4B4 定义里，CLOUD-01 报告写明过），**20 局同时跑**：
   - 成功 ≥19/20（本地基线 19/20 和 20/20 都出现过）；
   - 每局 TPS 都要记录，标 LAGGED 的局数要写清楚；并发到多少条泳道开始出现 LAGGED，给出曲线（建议依次测 5 / 10 / 20 条）；
   - 零 OOM、零端口冲突、零残留进程；
   - 给出推荐的默认并发数。

## 2. P1 接手 F 线（S2 易物原型）

P0 验收通过后再开始。F 线原本计划在本地开，现在整条放到本机做。

- **先读**（都在 `cloud/docs/`）：`MC-ROUND4-派单.md` 的「F 线」节（**这就是你的任务书**，其中"泳道 C"改为本机农场泳道，"worktree 路径"改为本机的路径）、`stage-02-barter.md`（先看文首的 SSG 修订节）、`MC-RESEARCH-03.md`（实测清单 B1–B5）、`route-SCHEMA.md`、`MC-DECISION-01-路线与口径裁决报告.md` §3.2。
- **【10-02 更新】F 线已经在本地先开工了**。P1 是**接手**，不是从头开始：开工前确认 `aidqq-mindcraft` 上有分支 `aidqq/s2-barter`，并且 `aidqq-bench` 的 master 上有 `stages/barter/HANDOFF.md`（本地 F 线收尾时写）。**两样都在才开工**，否则停下告诉用户——同一时间只能有一个 F 线会话。
- **代码**：任务层用 worktree 检出已有的 `aidqq/s2-barter` 分支，在上面继续提交；bench 的 `stages/barter/` 在 `cloud/farm-y` 分支上继续（先 `git merge master`，拿到本地 F 的最新提交）。
- **主种子 = `4926685115947721762`**。route 草稿 `route/4926685115947721762.json` 在 bench master 上（`frozenAt=null`，开发期允许使用）。
- 本机泳道多，B2（N 槽并行）这类需要大量样本的实验**尽量并行跑满**，样本量可以比任务书要求的更大。
- 研究线正在本地**独立**做易物机制的字节码核验；你按自己的实验和字节码分析出结论，最后由设计会话对照两边。**读字节码前先把混淆名解析回官方类名**（Mojang 官方 mappings）。

## 3. 规则

- 只结束自己 spawn 的进程；同一时间 F 线只能有你一个会话。
- 提交只 `git add` 自己的文件；提交身份 `-c user.name="AI-DQQ farm" -c user.email="farm@aidqq.invalid"`；推送 `cloud/farm-y` 和 `aidqq/s2-barter`。
- 零 LLM、零 key；令牌只放在 gh 的凭据里。

## 4. 交付

- P0：`cloud/FARM-Y-报告.md`（环境清单、持久性结论、并发和 TPS 曲线、20 局逐局结果、推荐并发数）。**P0 完成后先推送并停一下，告诉用户 P0 结果**；用户确认后再进入 P1（如果用户事先说了"直接继续"，就不用停）。
- P1：`stages/barter/reports/S2-01.md`（按手册 §6 模板：前置问题"peaceful 下有没有猪灵"的结论、B1/B2/B4/B5 实测、N 和吞吐的曲线、12 颗珍珠的用时和金锭消耗、可行性二选一）。推送后停下，等本地复核。
