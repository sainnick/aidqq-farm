# MC-CLOUD-01 报告｜云端 Linux 测试泳道 X 试运行

> 执行：云端 agent（Debian 12 / 2 vCPU / 3GB / 无 swap）
> 日期：2026-10-02　分支：`cloud/lane-x`（基于 `master` @ `c769d09`）
> 仓库：`sainnick/aidqq-bench`（bench）＋ `sainnick/aidqq-mindcraft`（E 线任务层）

## 0. 结论

**这条泳道可以用。** 任务单 §3 的两项验收全部达标，另有一处需要本地设计会话裁决的偏离（Java 发行版）和一处对设计有影响的发现（NFS 世界目录）。

| 验收项 | 要求 | 实测 | 结论 |
|---|---|---|---|
| BASIC-bootstrap × 5 局 | ≥4/5 SUCCESS | **5/5 SUCCESS** | ✅ 达标 |
| 内存峰值 / OOM | 零 OOM | 峰值 **1148.9 MB** / 3072 MB，零 OOM | ✅ 达标 |
| TPS | <18 标 LAGGED，照样计成绩 | 19.14–20.33（中位 19.40），**0 局 LAGGED** | ✅ 达标 |
| E 线冒烟 | 证明泳道 E 线能用 | 进末地 10.7s 读到龙 HP/阶段，0 死亡 0 错误 | ✅ 达标 |
| 收工 | 无残留 | 端口释放、残留 child=0、world 已删 | ✅ 达标 |

一项**未按任务单执行**（§1.3）：Java 用的是 Microsoft Build of OpenJDK 11.0.32.1，不是 Temurin——Adoptium 在本沙箱被限速到 16–28 KB/s（详见 §7.1）。构建号与本地那台机器一致（本地路径 `jdk-11.0.32.1+1`），**同一条 11.0.32.1+1 基线**，我判断不构成口径差异，但这是我的判断，请复核时确认。

---

## 1. 环境清单

| 项 | 值 |
|---|---|
| OS | Debian GNU/Linux 12 (bookworm) |
| kernel / arch | 5.10.134-18.0.12.lifsea8 / x86_64 |
| CPU | 2 vCPU，Intel Xeon Platinum 8163 @ 2.50GHz |
| 内存 | 3072 MB（无 swap，见 §7.3） |
| 工作区 | 500G，**NFS**（`stat -f` → `nfs`，见 §7.2） |
| Node | v22.19.0（npm 10.9.3） |
| Java | Microsoft Build of OpenJDK **11.0.32.1** 2026-08-18 LTS |
| MC 服务端 | Mojang 官方 vanilla **1.16.1** server.jar，37,968,964 B<br>sha1 `a412fd69db1f81db3f511c1463fd304675244077` ✅ 与官方 version_manifest 校验一致 |
| gh | 2.102.0（本次自行安装，镜像内无 gh） |
| 服务端目录 | `/workspace/servers/laneX`，端口 25566，仅监听 127.0.0.1，`-Xms512M -Xmx1G` |

### 1.1 Node 依赖（最小集，93 包）

按任务单 §1.5 **没有**对 mindcraft 做整体 `npm install`。做法：在 `/workspace/deps` 建独立最小清单，版本对齐 `mindcraft/package.json` 的 `^` 区间，再软链到 `/workspace/node_modules` 供 `exec_bot.mjs` 的 `createRequire(<mindcraft>/main.js)` 解析——**没有改动 mindcraft 仓库的任何文件**。

```
+-- mineflayer@4.39.0            (package.json 声明 ^4.33.0)
+-- mineflayer-pathfinder@2.4.5  (^2.4.5)
+-- mineflayer-tool@1.2.0        (mindcraft/package.json 未声明；1.2.0 是最新，依赖 mineflayer ^4.0.0，与 4.39 兼容)
+-- minecraft-data@3.117.0       (^3.97.0)
+-- prismarine-item@1.18.0       (^1.15.0)
+-- prismarine-recipe@1.5.0      (任务层直接 import)
+-- vec3@0.1.10                  (^0.1.10)
```

最终清单 = 上表 7 个直接依赖 + 84 个传递 package（合计 93）。装的时候全程 `NODE_OPTIONS=--max-old-space-size=512`，`--max-old-space-size` 下 npm 正常完成，**无 OOM**。

> 说明：`mindcraft/package.json` 里没有 `mineflayer-tool`，但 `basic-bootstrap/exec_bot.mjs:91` 有 `require('mineflayer-tool')`。本地机器上它应该是另处安装的。建议本地设计会话把这一条补进 `mindcraft/package.json`，否则云端每次复现都要手工补。

---

## 2. BASIC-bootstrap × 5 局逐局结果

stage `basic-bootstrap`，零 kit，目标 `stone ×16`，MC 1.16.1。

| 局 | 种子 | 结果 | 局内耗时 | 墙钟 | rounds | craft 尝试/失败 | toolRescue | 死亡 | 挖掘 成功/尝试 | nav(ms) | mine(ms) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | P2C_M4B4-01 | **SUCCESS** | 78.2s | 220.1s | 2 | 6/0 | 1 | 0 | 19/20 | 7,134 | 26,189 |
| 2 | P2C_M4B4-02 | **SUCCESS** | 83.0s | 229.1s | 1 | 6/0 | 1 | 0 | 28/28 | 9,994 | 35,222 |
| 3 | P2C_M4B4-03 | **SUCCESS** | 62.4s | 212.7s | 1 | 6/0 | 1 | 0 | 21/21 | 1,324 | 27,310 |
| 4 | P2C_M4B4-04 | **SUCCESS** | 79.4s | 226.8s | 1 | 6/0 | 1 | 0 | 18/18 | 4,566 | 26,661 |
| 5 | P2C_M4B4-05 | **SUCCESS** | 72.0s | 219.4s | 1 | 6/0 | 1 | 0 | 26/26 | 2,091 | 30,889 |

**5/5 SUCCESS。** 五局任务树一致：`Acquire(stone ×16) → Craft(wooden_pickaxe ×1) → Acquire(log ×3)`，全部走 TOOL_MISSING → Crafting 救援路径（`toolRescues=1` 是结构性必然，不是异常），`craftFailures=0`、零死亡、零 `recover` 相位。

**种子来源（任务单要求「本地基线 M4B4 的前 5 个」）：** 种子表实际不在任务单说的 `stages/basic-bootstrap/`，而在 `stages/portal/run_portal.mjs:263-267` 的回归种子数组（`P2C_M4B4` = 主线 19/20 那批）。取数组前 5 项：`P2C_M4B4-01` … `-05`。

---

## 3. 内存峰值

采样方式：runner 侧每秒读 `/proc/<pid>/status` 的 `VmRSS`（服务端 + bot）与 `/proc/meminfo` 的 `MemTotal-MemAvailable`。

| 局 | 服务端+bot 峰值 RSS |
|---|---|
| 1 | 1,110.1 MB |
| 2 | 1,079.7 MB |
| 3 | 1,041.2 MB |
| 4 | **1,148.9 MB**（全局峰值） |
| 5 | 1,132.7 MB |
| E 线冒烟 | 1,060.6 MB |

**全局峰值 1,148.9 MB / 3,072 MB（占用 37.4%），零 OOM。** 服务端 `-Xmx1G` 的堆上限从未被触碰，剩余约 1.9 GB 足够再开 1 条泳道——但见 §8.1 的 I/O 瓶颈，**这条泳道的实际限制不是内存而是 I/O**。

---

## 4. TPS

口径按任务单 §3：world age 增量 ÷ 墙钟。`tps_tap.mjs` 以 `node --import` 预加载，在 bot 进程内旁路采样 `bot.time.time`（world age，tick）落 `world_age.jsonl`，**未修改 `exec_bot.mjs` 任何一行**。

> 公式：`TPS = Δ(worldAgeTicks) / Δ(wallSec)`。world age 单位就是 tick，1 tick = 1/20 s，所以「世界每秒推进多少 tick」直接就是 TPS。
> 量化误差：vanilla 每 20 tick 才发一次时间包，实测相邻采样增量分布 `{20:71, 0:3, 40:4}`，因此取**整局首尾两点**（误差 ±20 tick / ~1560 tick ≈ ±1.3%），不取相邻点均值。

| 局 | TPS | LAGGED(<18) | 采样点 |
|---|---|---|---|
| 1 | 19.14 | no | 79 |
| 2 | 19.40 | no | 84 |
| 3 | 19.21 | no | 63 |
| 4 | 20.06 | no | 80 |
| 5 | 20.33 | no | 73 |

**中位 19.40，0 局 LAGGED。** 服务端 `Can't keep up!` 告警 0 次。

---

## 5. E 线冒烟（`aidqq/end-probe` + `stages/end-probe/`）

用 `MC_MINDCRAFT_ROOT=/workspace/mindcraft-wt/end-probe`（worktree @ `a4f3712`），`--mode detect`，`--god-mode`，探针超时 60s。

```
[TPS 19.4 主线那局]  wall=300s  → dragonSeen=true  firstDragonAt=11,665ms  HP 200→200
                        phaseHistogram={HOLDING_PATTERN:3695, STRAFE_PLAYER:1898}
                        crystalSamples=[{t:12399, n:10, hp:200, phase:HOLDING_PATTERN}]
                        deaths=0  healthMin=20  dim=the_end  geom.found=true roofY=63  errors=[]
[TPS 17.78 短冒烟]    wall=60s   → dragonSeen=true  firstDragonAt=10,708ms  HP 200→200
                        phaseHistogram={HOLDING_PATTERN:394, STRAFE_PLAYER:511}
                        crystalSamples=[{t:11155, n:10, hp:200, phase:HOLDING_PATTERN}]
                        deaths=0  healthMin=20  dim=the_end  geom.found=true roofY=60  errors=[]
```

**泳道 X 上 E 线可用**：起服 → bot 连服 → 服务器 stdin 注入 kit（床×12）→ 控制台 `execute in minecraft:the_end run tp` 投进末地 → 10.7s 读到龙的 HP/阶段 → 门柱几何解析成功 → 0 死亡 0 错误。任务层（worktree 分支）加载、运行、落盘全链路正常。

**`status=TIMEOUT` 是 `--mode detect` 的设计终态，不是故障。** detect 模式的语义就是「连续采样到探针超时为止」，只有 kill 模式才会终结于击杀。判读时不要把它当失败。

**一个必须记下来的坑：TP 落点。** 我第一次按直觉把 TP 目标写成 `0 60 0`，bot 掉进虚空死亡 → `NO_PROGRESS_ABORT`。本地 `run_probe.mjs:71` 的默认值是 `0 70 0`，注释写明「末地主岛顶面实测 y≈66」。`cloud/run_lane.mjs` 现已对齐该默认值。**这条对本地设计会话也有价值：E 线任何新增入口都别自己拍 TP 坐标。**

**末地维度会压垮服务端。** 首次进末地触发大规模区块生成时，服务端打出 `Can't keep up! … Running 13963ms or 279 ticks behind`，TPS 掉到 **10.68**。预生成末地主岛区块、或把首次进末地的局和常规局分开排，能省掉这段抖动。

---

## 6. `_lib` 跨平台改造建议表

`stages/_lib/` 五个文件里，**平台耦合集中在 4 个函数 + 2 处路径常量**。其余 90% 是纯 Node 逻辑，直接可复用。

### 6.1 必须改（否则 Linux 上必抛错）

| 函数 | 文件:行 | Windows 写法 | 建议 |
|---|---|---|---|
| `preflight.procInfo()` | `stages/_lib/preflight.mjs:55-57` | `powershell.exe -Command "Get-CimInstance Win32_Process …"` | 抽成 `procInfo()` 后端可插：win 走 CIM，linux 走 `/proc/<pid>/stat` + `/proc/<pid>/cmdline` + `/proc/<pid>` 目录 mtime 算 ageSec。**注意 linux 上 argv 在 cmdline 里是 NUL 分隔且被截断（`/proc/pid/cmdline` 上限 32KB），解析要按 `\0` 切**。这是整个 `_lib` 里最值得先做的一块，因为它被 `liveOwnerPids`/`pidRegistry`/`killableOrphanTargets`/`ownedByLiveSession` 四层依赖。 |
| `preflight.netstatListeners()` | `stages/_lib/preflight.mjs:83-84` | `netstat -ano` | 抽成 `listeners()`：win 走 netstat，linux 优先 `ss -ltnpH`，无 iproute2 时退到 `/proc/net/tcp{,6}` 解析（本地端口是第 2 字段，hex）。**返回结构 `port -> Set(pid)` 要保持不变**，cleanup 依赖它。 |
| `preflight.killTree(pid)` | `stages/_lib/preflight.mjs:98-99` | `taskkill /PID x /T /F` | 树杀语义不同：win 的 `/T` 杀子孙，linux 没有等价系统调用。建议改成「显式遍历 `/proc/*/stat` 的 ppid 建树 → 逐个 `process.kill(pid,'SIGKILL')`」，自底向上杀。 |
| `runner_core.killTree(pid)` | `stages/_lib/runner_core.mjs:42-44` | 同上 | 与 preflight 的 killTree **是重复实现**，建议合并为一份。 |
| `line_lock.alivePids()` | `stages/_lib/line_lock.mjs:40-48` | `tasklist /NH /FO CSV` | linux 走 `/proc` 枚举数字 pid 目录即可，比 tasklist 简单得多。注意原实现对 CSV 里**带引号的 PID 字段**有专门正则，移植时不要照抄。 |

### 6.2 需要包装（逻辑可留，原语要换）

| 位置 | 文件:行 | 现状 | 建议 |
|---|---|---|---|
| 运行时探测 | `stages/_lib/preflight.mjs:243-250` | 写死 `…/node-v20.20.2-win-x64/node.exe` 和 `jdk/*/bin/java.exe` | 改成读 `MC_BENCH_JAVA` / `process.execPath`，与任务单 §2 的环境变量口径一致。**这一条改动最小、收益最大**，建议优先。 |
| lane 目录模板 | 各 stage `run_bench.mjs` 的 `JAVA` 默认值 | `'C:/Program Files/Eclipse Adoptium/jre-21.0.12.101-hotspot/bin/java.exe'` | 同上，读 `MC_BENCH_JAVA`。 |
| 端口占用判定 | `stages/portal/run_portal.mjs:92`、`micro_bench.mjs:146`、`lane_guard.mjs:28` | `netstat -ano \| findstr` / `netstat -ano` | 三处各自复制了一份 win 版，建议抽成一个共享 `portInUse()`。 |
| 强制结束 | `stages/basic-stone/run_bench.mjs:113-119` | `child.kill()` 后再 `taskkill /T /F` | 去掉 taskkill 那一行。 |
| 端口预检 | `stages/basic-stone/run_tasked_smoke.mjs:76-78, 159-160` | netstat + taskkill | 同上。 |

### 6.3 不需要改（已验证跨平台）

`freshWorld` / `bootServer` / `bootServerWithRetry` / `stopServer` / `injectKit` / `waitFreeMem` / `parseLanes` / `buildLanes` / `probeSig` / `awaitBotExit` 的无进展判据 / `cleanup.mjs` 的世界目录扫描与 heartbeat 逻辑 / `reserve.mjs` 全部——**纯 Node API，逐行可用**。`cloud/run_lane.mjs` 就是直接照 `runner_core` 的协议复刻的，没有改它们任何一个字。

> `reserve.mjs` 在本泳道完全没用到：云端只有一条线，不存在多线抢端口。这不是缺陷，是**云端泳道与本地多线开发机的模型差异**——建议 `_lib` 把「线锁 + 预约」做成可选层，别让单线环境被迫依赖 `tasklist`。

---

## 7. 与任务单的偏离、风险与发现

### 7.1 Java 发行版：MS OpenJDK 而非 Temurin（**需裁决**）

任务单 §1.3 要求 Temurin JDK 11（官方来源）。实测 Adoptium 在本沙箱被**针对性限速**：

| 源 | 实测速率 | 186 MB 预计耗时 |
|---|---|---|
| `api.adoptium.net` 单连接 | 16–28 KB/s | **2.8–3.2 小时** |
| `api.adoptium.net` 8 连接并发 | 74 KB/s 聚合 | 44 分钟 |
| `corretto.aws` | 942 KB/s | 3.5 分钟 |
| `aka.ms`（MS OpenJDK） | 1,330 KB/s | 2.5 分钟 |

因为第 2 行仍然不可接受，我改用 Microsoft Build of OpenJDK 11.0.32.1 并让 Temurin 继续后台下载；但即便如此 Adoptium 也没有在合理时间内完成，最终停用了它。**Microsoft 与 Amazon 都是 OpenJDK 官方发行渠道，但确实不是 Temurin。** 缓解因素：构建号 `11.0.32.1+1` 与本地那台机器路径里的 `jdk-11.0.32.1+1` **完全一致**，即同一条 JDK 基线。

**请复核时裁决**：若必须 Temurin，云端出网需要给 `api.adoptium.net` 放行或换源；否则建议把任务单 §1.3 改成「JDK 11（Temurin 或其他官方发行版）」，并把实测速率写进去，避免下一个云端 agent 再花 3 小时。

（`cloud/fetch_jdk.sh` 是我写的多连接分片下载器，留着给复核的人复现/改进下载路径用。）

### 7.2 工作区是 NFS，世界目录不能直接删（**影响设计**）

任务单把测试服目录放在 `<WS>/servers/laneX/`，而 `<WS>` 是 **NFS 挂载**。直接 `fs.rmSync(world, {recursive:true})` 会失败：

```
EBUSY: resource busy or locked, unlink '…/spike_world/.nfs000000000000287d0000000b'
```

`.nfsXXXX` 是 NFS 的 silly-rename 残片——文件仍被打开时，NFS 会把它改名而不是删掉。这让「每局删旧世界」这个在本地 Windows 上毫无存在感的前提，在云端变成真实故障（第一次跑 5 局时直接崩在这里）。

`run_lane.mjs` 的对策：**先原子 `rename` 把世界目录挪走**（NFS 上 rename 是元数据操作，不受句柄影响），保证本局拿到的必然是全新世界；再对挪走后的目录尽力删除，失败就留到收工阶段并如实报告。这个策略在 NFS 和本地 fs 上都成立，建议本地 `_lib` 的 `freshWorld` 也改成这个顺序。

**顺带一个性能事实：NFS 上世界生成很慢。** 首次起服要 **78–103 秒**，其中绝大部分是「Preparing spawn area」——这是 5 局里最大的时间开销（5 局墙钟 212–229s，起服占约 100s，**45%**）。若把测试服目录放到本地盘而非 NAS，起服时间应能大幅下降。这是 §8.1 建议的来源。

### 7.3 swapfile 建不了（按 §1.6 跳过并记录）

`fallocate -l 2G /swapfile` 成功、`mkswap` 成功，`swapon` 报 **`Operation not permitted`**——容器不允许。任务单 §1.6 允许「容器不允许就跳过并在报告里写明」，本条即为此记录。实际影响为零：3GB 内存下峰值只用 1.15 GB，内存从未紧张。

### 7.4 镜像缺 `ss`（任务单 §2 的偏离）

任务单要求「端口检查用 `ss`」，但**本镜像没装 iproute2**，`ss` 和 `netstat` 都不存在（`lsof` 有）。apt 源 `mirrors.cloud.aliyuncs.com` 在本沙箱不可达，装不上。

`run_lane.mjs` 的三层实现：**`ss`（装了才用）→ Node TCP bind 探测 → `lsof` 仅作诊断**。bind 探测其实比 `ss` 更权威——服务端真正要执行的就是那个 bind，`EADDRINUSE` 是服务端自己会遇到的错误。建议把任务单 §2 的措辞从「用 `ss`」改成「用 `ss` 或等价的 bind 探测」。

### 7.5 GitHub 认证与令牌

按 §1.1 走 `gh auth login` 设备码流程，**令牌没有写进任何磁盘文件**：`GH_CONFIG_DIR` 指向 `/dev/shm/gh`（64 MB tmpfs，纯内存），remote URL 保持 `https://github.com/sainnick/aidqq-bench.git` 不含凭据（认证走 credential helper），clone 后已核验 `.git/` 内无 `gho_`/`ghp_`/`github_pat_` 残留。复核完成后该目录已删除。

> 另注：本沙箱出网被 TLS 代理接管（证书 `CN=ack-agent-identity-proxy`，O=hangzhou/alibaba cloud），沙箱通过 `SSL_CERT_FILE` 显式导出了网关 CA。git 不读 `SSL_CERT_FILE`，需单独设 `GIT_SSL_CAINFO=/etc/ssl/certs/agent-identity/sandbox-gateway-ca.crt` 才能 clone——否则报证书校验失败。

---

## 8. 提效条目（≤3 条，按收益排序）

### 8.1 把测试服目录从 NAS 挪到本地盘 —— 预计每局省 90+ 秒（45%）

5 局墙钟 212–229s，其中起服 78–103s，而起服时间几乎全花在 NFS 上的区块写入（`Preparing spawn area`）。工作区 500G 只用了 1%，完全放得下服务端目录。**这是投入产出比最高的一条**：不改任何 bench 代码，只改 `MC_BENCH_SERVER` 指向。

### 8.2 `preflight.procInfo()` 后端可插 —— 一次改动解锁 4 个下游函数

`procInfo()` 是 `_lib` 里耦合最深的单点：`liveOwnerPids`、`pidRegistry`、`registeredOrphans`、`killableOrphanTargets`、`ownedByLiveSession`、`ownedByLiveDir`、`hasDeadHeartbeatOwner` **七个**函数都直接或间接调它。把它抽成 win-CIM / linux-`/proc` 双后端，Linux 侧就一次性拿到整套残留进程治理能力，而不是像本次这样只能绕开 `_lib` 整套另写 `run_lane.mjs`。

### 8.3 合并两份重复的 `killTree` + 抽出共享 `portInUse()`

`preflight.killTree`（`preflight.mjs:98`）和 `runner_core.killTree`（`runner_core.mjs:42`）是同一份 taskkill 逻辑的两份拷贝；端口判定又在 `run_portal.mjs:92`、`micro_bench.mjs:146`、`lane_guard.mjs:28` 各抄了一遍。合并成一份跨平台实现，顺带消掉「改了 A 忘了改 B」这类隐患——本次光是端口判定就发现了 3 个副本。

---

## 附：交付物

| 文件 | 说明 |
|---|---|
| `cloud/run_lane.mjs` | Linux 单泳道 runner。支持 `basic-bootstrap` / `end-probe` 两个 stage |
| `cloud/tps_tap.mjs` | world age 旁路采样（`node --import` 预加载），零侵入 |
| `cloud/fetch_jdk.sh` | 多连接分片下载器（为绕开 Adoptium 限速而写） |
| `cloud/CLOUD-01-报告.md` | 本文件 |

`stages/_lib/` 与所有既有 stage 脚本**一行未改**。

跑次原始数据留在 `cloud/runs/XBB5/`（5 局）与 `cloud/runs/XENDSMOKE/`（E 线 300s 探针）、`cloud/runs/XENDSMOKE2/`（E 线 60s 探针），含每局的 `summary.jsonl` / `result.json` / `telemetry.jsonl` / `world_age.jsonl` / `server.log` / `bot_console.log`。两次 E 线跑次的差别只有探针超时（300s vs 60s），可用来对照采样量随时间的变化。

§5 提到的第一次 TP 落点出错的跑次（`NO_PROGRESS_ABORT`）原始数据未保留——当时为重跑直接清了该目录，只剩本报告 §5 里引用的 `bot.log` 关键行。**这是我的疏漏**：现场数据应当留档，结论本身（TP 到 y=60 会掉进虚空）由 `run_probe.mjs:71` 的默认值与注释独立佐证，不依赖那次跑次。
