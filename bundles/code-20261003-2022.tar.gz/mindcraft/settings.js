const settings = {
    // ==== AI斗蛐蛐 主配置 ====
    "minecraft_version": "1.21.1",
    "host": "127.0.0.1",
    "port": 25565,
    "auth": "offline",

    // the mindserver manages all agents and hosts the UI
    "mindserver_port": 8080,
    "auto_open_ui": false,

    "base_profile": "survival",
    "profiles": [
        "./profiles/glm53.json",
        // 之后四个 AI 同场竞技时在这里加：
        // "./profiles/gpt.json", "./profiles/gemini.json", "./profiles/deepseek.json"
    ],

    "load_memory": false, // 续玩时由启动脚本通过 SETTINGS_JSON 环境变量覆盖为 true
    "init_message": null, // 自主开局，不发任何人类指令

    // [AI斗蛐蛐 patch] 开局唯一目标：只给目标，不给任何攻略/步骤
    "auto_goal": "Beat Minecraft: enter The End and defeat the Ender Dragon. From now on you are completely on your own - nobody will give you hints or orders. Survive, explore, and figure everything out by yourself.",

    // [AI斗蛐蛐 patch] 制作层状态上报（录制器/HUD/分集日志）
    "production_report_url": "http://127.0.0.1:3010/api/state",

    "only_chat_with": [],

    "speak": false,

    "chat_ingame": true, // bot 的自言自语进游戏聊天框（服务器日志可作字幕素材）
    "language": "en",
    "render_bot_view": true, // 第一视角渲染 http://localhost:3000 （录制器抓这个画面）

    "allow_insecure_coding": false,
    "allow_vision": false,
    "blocked_actions" : ["!checkBlueprint", "!checkBlueprintLevel", "!getBlueprint", "!getBlueprintLevel"],
    "code_timeout_mins": -1,
    "relevant_docs_count": -1, // 全量命令文档，绕开 embedding 依赖

    "max_messages": 20,
    "num_examples": 0, // 0 = 不做示例检索，避免调用 embedding API
    "max_commands": -1,
    "show_command_syntax": "full",
    "narrate_behavior": false, // 关闭自动行为播报（Picking up item! 之类），台词只留大事件
    "chat_bot_messages": true,

    "spawn_timeout": 60,
    "block_place_delay": 0,

    "log_all_prompts": true, // 全量决策日志（剪辑与复盘用）
};

export default settings;
