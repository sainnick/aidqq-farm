import { History } from './history.js';
import { Coder } from './coder.js';
import { VisionInterpreter } from './vision/vision_interpreter.js';
import { Prompter } from '../models/prompter.js';
import { initModes } from './modes.js';
import { initBot } from '../utils/mcdata.js';
import { containsCommand, commandExists, executeCommand, truncCommandMessage, isAction, blacklistCommands } from './commands/index.js';
import { ActionManager } from './action_manager.js';
import { NPCContoller } from './npc/controller.js';
import { MemoryBank } from './memory_bank.js';
import { SelfPrompter } from './self_prompter.js';
import convoManager from './conversation.js';
import { handleTranslation, handleEnglishTranslation } from '../utils/translator.js';
import { addBrowserViewer } from './vision/browser_viewer.js';
import { serverProxy, sendOutputToServer } from './mindserver_proxy.js';
import settings from './settings.js';
import { Task } from './tasks/tasks.js';
import { speak } from './speak.js';
import { log, validateNameFormat, handleDisconnection } from './connection_handler.js';

export class Agent {
    async start(load_mem=false, init_message=null, count_id=0) {
        this.last_sender = null;
        this.count_id = count_id;
        this._disconnectHandled = false;

        // Initialize components
        this.actions = new ActionManager(this);
        this.prompter = new Prompter(this, settings.profile);
        this.name = (this.prompter.getName() || '').trim();
        console.log(`Initializing agent ${this.name}...`);
        
        // Validate Name Format
        // connection_handler now ensures the message has [LoginGuard] prefix
        const nameCheck = validateNameFormat(this.name);
        if (!nameCheck.success) {
            log(this.name, nameCheck.msg);
            process.exit(1);
            return;
        }
        
        this.history = new History(this);
        this.coder = new Coder(this);
        this.npc = new NPCContoller(this);
        this.memory_bank = new MemoryBank();
        this.self_prompter = new SelfPrompter(this);
        // [P0-B] 决策层（DECIDER_MODE=systemone 时接管动作选择；legacy/未设 = 原 self-prompt 路径，可随时回滚）
        // [M1] DECIDER_MODE=tasked：本地任务层接管（MISSION→Task 闭环，零 LLM，见 tasks/exec/）
        this.decider_mode = (process.env.DECIDER_MODE || 'legacy').toLowerCase();
        console.log(`[P0-B] agent.start: DECIDER_MODE=${process.env.DECIDER_MODE ?? '(unset)'} -> mode=${this.decider_mode}`);
        if (this.decider_mode === 'systemone') {
            const { Decider } = await import('./decider.js');
            this.decider = new Decider(this);
        } else if (this.decider_mode === 'tasked') {
            const { parseMission } = await import('./tasks/exec/mission.js');
            const missionInput = process.env.TASKED_MISSION || settings.auto_goal;
            try {
                this.tasked_mission = parseMission(missionInput);
                log(this.name, `[M1] tasked mission: ${JSON.stringify(this.tasked_mission)}`);
            } catch (e) {
                log(this.name, `[M1] tasked mission parse failed: ${e.message}`);
                process.exit(3);
                return;
            }
        }
        convoManager.initAgent(this);
        await this.prompter.initExamples();

        // load mem first before doing task
        let save_data = null;
        if (load_mem) {
            save_data = this.history.load();
        }
        let taskStart = null;
        if (save_data) {
            taskStart = save_data.taskStart;
        } else {
            taskStart = Date.now();
        }
        this.task = new Task(this, settings.task, taskStart);
        this.blocked_actions = settings.blocked_actions.concat(this.task.blocked_actions || []);
        blacklistCommands(this.blocked_actions);

        console.log(this.name, 'logging into minecraft...');
        this.bot = initBot(this.name);
        
        // Connection Handler
        const onDisconnect = (event, reason) => {
            if (this._disconnectHandled) return;
            this._disconnectHandled = true;

            // Log and Analyze
            // handleDisconnection handles logging to console and server
            const { type } = handleDisconnection(this.name, reason);
     
            process.exit(1);
        };
        
        // Bind events
        this.bot.once('kicked', (reason) => onDisconnect('Kicked', reason));
        this.bot.once('end', (reason) => onDisconnect('Disconnected', reason));
        this.bot.on('error', (err) => {
            if (String(err).includes('Duplicate') || String(err).includes('ECONNREFUSED')) {
                 onDisconnect('Error', err);
            } else {
                 log(this.name, `[LoginGuard] Connection Error: ${String(err)}`);
            }
        });

        initModes(this);

        this.bot.on('login', () => {
            console.log(this.name, 'logged in!');
            serverProxy.login();
            
            // Set skin for profile, requires Fabric Tailor. (https://modrinth.com/mod/fabrictailor)
            if (this.prompter.profile.skin)
                this.bot.chat(`/skin set URL ${this.prompter.profile.skin.model} ${this.prompter.profile.skin.path}`);
            else
                this.bot.chat(`/skin clear`);
        });
		const spawnTimeoutDuration = settings.spawn_timeout;
        const spawnTimeout = setTimeout(() => {
            const msg = `Bot has not spawned after ${spawnTimeoutDuration} seconds. Exiting.`;
            log(this.name, msg);
            process.exit(1);
        }, spawnTimeoutDuration * 1000);
        this.bot.once('spawn', async () => {
            try {
                clearTimeout(spawnTimeout);
                addBrowserViewer(this.bot, count_id);
                console.log('Initializing vision intepreter...');
                this.vision_interpreter = new VisionInterpreter(this, settings.allow_vision);

                // wait for a bit so stats are not undefined
                await new Promise((resolve) => setTimeout(resolve, 1000));
                
                console.log(`${this.name} spawned.`);
                this.clearBotLogs();
              
                this._setupEventHandlers(save_data, init_message);
                this.startEvents();
              
                if (!load_mem) {
                    if (settings.task) {
                        this.task.initBotTask();
                        this.task.setAgentGoal();
                    }
                } else {
                    // set the goal without initializing the rest of the task
                    if (settings.task) {
                        this.task.setAgentGoal();
                    }
                }

                await new Promise((resolve) => setTimeout(resolve, 10000));
                this.checkAllPlayersPresent();

            } catch (error) {
                console.error('Error in spawn event:', error);
                process.exit(0);
            }
        });
    }

    async _setupEventHandlers(save_data, init_message) {
        const ignore_messages = [
            "Set own game mode to",
            "Set the time to",
            "Set the difficulty to",
            "Teleported ",
            "Set the weather to",
            "Gamerule "
        ];
        
        const respondFunc = async (username, message) => {
            if (message === "") return;
            if (username === this.name) return;
            if (settings.only_chat_with.length > 0 && !settings.only_chat_with.includes(username)) return;
            try {
                if (ignore_messages.some((m) => message.startsWith(m))) return;

                this.shut_up = false;

                console.log(this.name, 'received message from', username, ':', message);

                if (convoManager.isOtherAgent(username)) {
                    console.warn('received whisper from other bot??')
                }
                else {
                    let translation = await handleEnglishTranslation(message);
                    this.handleMessage(username, translation);
                }
            } catch (error) {
                console.error('Error handling message:', error);
            }
        }

		this.respondFunc = respondFunc;

        this.bot.on('whisper', respondFunc);
        
        this.bot.on('chat', (username, message) => {
            if (serverProxy.getNumOtherAgents() > 0) return;
            // only respond to open chat messages when there are no other agents
            respondFunc(username, message);
        });

        // Set up auto-eat
        this.bot.autoEat.options = {
            priority: 'foodPoints',
            startAt: 14,
            bannedFood: ["rotten_flesh", "spider_eye", "poisonous_potato", "pufferfish", "chicken"]
        };

        if (save_data?.self_prompt) {
            if (init_message) {
                this.history.add('system', init_message);
            }
            if (this.decider_mode === 'systemone' || this.decider_mode === 'tasked') {
                // [P0-B] decider 接管动作选择，不恢复旧 self-prompt 循环（否则其 ACTIVE 状态会绕过接管分支）
                // [M1] tasked 同理：任务层拥有执行闭环，self-prompt 状态一律不恢复
                log(this.name, `DECIDER_MODE=${this.decider_mode}: skipping self-prompt restore (local layer owns action selection)`);
            } else {
                await this.self_prompter.handleLoad(save_data.self_prompt, save_data.self_prompting_state);
            }
        }
        if (save_data?.last_sender) {
            this.last_sender = save_data.last_sender;
            if (convoManager.otherAgentInGame(this.last_sender)) {
                const msg_package = {
                    message: `You have restarted and this message is auto-generated. Continue the conversation with me.`,
                    start: true
                };
                convoManager.receiveFromBot(this.last_sender, msg_package);
            }
        }
        else if (init_message) {
            await this.handleMessage('system', init_message, 2);
        }
        else if (this.decider_mode !== 'tasked') {
            // [M1] tasked 模式不发开场白：执行层不打进对话史，保持纯任务闭环
            this.openChat("Hello world! I am "+this.name);
        }

        // [AI斗蛐蛐 patch] after spawn setup, autonomously start self-prompting toward the series goal.
        // No human instructions are sent afterwards; the bot drives itself via !goal loop.
        if (settings.auto_goal && !this.self_prompter.isActive()) {
            if (this.decider_mode === 'tasked') {
                // [M1] 本地任务层接管：关全部 modes（modes 经 ActionManager 抢 pathfinder/触发 LLM reprompt），
                //      以 MISSION 为唯一驱动。bot 级 death 事件由 TaskRuntime 消费（不走 handleMessage→LLM）。
                const { TaskRuntime } = await import('./tasks/exec/task_runner.js');
                const { AcquireResourceTask } = await import('./tasks/exec/acquire_resource_task.js');
                for (const m of Object.keys(this.bot.modes.getJson())) this.bot.modes.setOn(m, false);
                // [M1] kit 宽限窗（bench 协议：runner RCON 注入工具）：mission 依赖工具时最多等 20s。
                //      生产链路无 kit 注入时自然超时照常开跑——TOOL_MISSING 会结构化快速失败向上报。
                for (let i = 0; i < 20; i++) {
                    if (this.bot.inventory.items().some((it) => it.name.endsWith('pickaxe'))) break;
                    await new Promise((r) => setTimeout(r, 1000));
                }
                const invSnap = this.bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',') || '(empty)';
                log(this.name, `[M1] DECIDER_MODE=tasked: task layer takes over (mission: ${JSON.stringify(this.tasked_mission)}), all modes off, inventory=[${invSnap}]`);
                const runtime = new TaskRuntime(this.bot, {
                    mission: this.tasked_mission,
                    telemetryPath: process.env.TASKED_TELEMETRY || null,
                });
                this.taskRuntime = runtime;
                const root = new AcquireResourceTask({
                    resource: this.tasked_mission.resource,
                    count: this.tasked_mission.count,
                    timeoutMs: parseInt(process.env.TASKED_TIMEOUT_MS ?? '300000', 10),
                });
                // 终态即退（exit 2：AgentProcess 对 code>1 不重启，main.js 结束任务）
                runtime.onDone = (summary) => {
                    log(this.name, `[M1] mission end: ${summary.status} reason=${summary.failReason} dur=${Math.round(summary.durationMs / 1000)}s inv=${JSON.stringify(summary.finalInventory)}`);
                    if (process.env.TASKED_RESULT) {
                        import('fs').then(({ writeFileSync }) => {
                            writeFileSync(process.env.TASKED_RESULT, JSON.stringify(summary, null, 2));
                        }).catch((e) => console.error(e));
                    }
                    setTimeout(() => process.exit(2), 1500);
                };
                await runtime.run(root);
            } else if (this.decider_mode === 'systemone' && this.decider) {
                // [P0-B] decider 接管实时动作选择；self_prompter 代码保留不删（rollback: DECIDER_MODE=legacy）
                log(this.name, `DECIDER_MODE=systemone: decider takes over (goal: ${settings.auto_goal.slice(0, 80)}...)`);
                await this.decider.start(settings.auto_goal);
            } else {
                log(this.name, `Auto-starting self-prompting with goal: ${settings.auto_goal}`);
                await this.self_prompter.start(settings.auto_goal);
            }
        }
    }

    checkAllPlayersPresent() {
        if (!this.task || !this.task.agent_names) {
          return;
        }

        const missingPlayers = this.task.agent_names.filter(name => !this.bot.players[name]);
        if (missingPlayers.length > 0) {
            console.log(`Missing players/bots: ${missingPlayers.join(', ')}`);
            this.cleanKill('Not all required players/bots are present in the world. Exiting.', 4);
        }
    }

    requestInterrupt() {
        this.bot.interrupt_code = true;
        this.bot.stopDigging();
        this.bot.collectBlock.cancelTask();
        this.bot.pathfinder.stop();
        this.bot.pvp.stop();
    }

    clearBotLogs() {
        this.bot.output = '';
        this.bot.interrupt_code = false;
    }

    shutUp() {
        this.shut_up = true;
        if (this.self_prompter.isActive()) {
            this.self_prompter.stop(false);
        }
        if (this.decider?.isActive()) {
            this.decider.stop();
        }
        convoManager.endAllConversations();
    }

    async handleMessage(source, message, max_responses=null) {
        await this.checkTaskDone();
        if (!source || !message) {
            console.warn('Received empty message from', source);
            return false;
        }

        let used_command = false;
        if (max_responses === null) {
            max_responses = settings.max_commands === -1 ? Infinity : settings.max_commands;
        }
        if (max_responses === -1) {
            max_responses = Infinity;
        }

        const self_prompt = source === 'system' || source === this.name;
        const from_other_bot = convoManager.isOtherAgent(source);

        if (!self_prompt && !from_other_bot) { // from user, check for forced commands
            const user_command_name = containsCommand(message);
            if (user_command_name) {
                if (!commandExists(user_command_name)) {
                    this.routeResponse(source, `Command '${user_command_name}' does not exist.`);
                    return false;
                }
                this.routeResponse(source, `*${source} used ${user_command_name.substring(1)}*`);
                if (user_command_name === '!newAction') {
                    // all user-initiated commands are ignored by the bot except for this one
                    // add the preceding message to the history to give context for newAction
                    this.history.add(source, message);
                }
                let execute_res = await executeCommand(this, message);
                if (execute_res) 
                    this.routeResponse(source, execute_res);
                return true;
            }
        }

        if (from_other_bot)
            this.last_sender = source;

        // Now translate the message
        message = await handleEnglishTranslation(message);
        console.log('received message from', source, ':', message);

        const checkInterrupt = () => this.self_prompter.shouldInterrupt(self_prompt) || this.shut_up || convoManager.responseScheduledFor(source);
        
        let behavior_log = this.bot.modes.flushBehaviorLog().trim();
        if (behavior_log.length > 0) {
            const MAX_LOG = 500;
            if (behavior_log.length > MAX_LOG) {
                behavior_log = '...' + behavior_log.substring(behavior_log.length - MAX_LOG);
            }
            behavior_log = 'Recent behaviors log: \n' + behavior_log;
            await this.history.add('system', behavior_log);
        }

        // Handle other user messages
        await this.history.add(source, message);
        this.history.save();

        if (!self_prompt && this.self_prompter.isActive()) // message is from user during self-prompting
            max_responses = 1; // force only respond to this message, then let self-prompting take over
        for (let i=0; i<max_responses; i++) {
            if (checkInterrupt()) break;
            let history = this.history.getHistory();
            let res = await this.prompter.promptConvo(history);

            console.log(`${this.name} full response to ${source}: ""${res}""`);

            if (res.trim().length === 0) {
                console.warn('no response')
                break; // empty response ends loop
            }

            let command_name = containsCommand(res);

            if (command_name) { // contains query or command
                res = truncCommandMessage(res); // everything after the command is ignored
                this.history.add(this.name, res);
                
                if (!commandExists(command_name)) {
                    this.history.add('system', `Command ${command_name} does not exist.`);
                    console.warn('Agent hallucinated command:', command_name)
                    continue;
                }

                if (checkInterrupt()) break;
                this.self_prompter.handleUserPromptedCmd(self_prompt, isAction(command_name));

                if (settings.show_command_syntax === "full") {
                    this.routeResponse(source, res);
                }
                else if (settings.show_command_syntax === "shortened") {
                    // show only "used !commandname"
                    let pre_message = res.substring(0, res.indexOf(command_name)).trim();
                    let chat_message = `*used ${command_name.substring(1)}*`;
                    if (pre_message.length > 0)
                        chat_message = `${pre_message}  ${chat_message}`;
                    this.routeResponse(source, chat_message);
                }
                else {
                    // no command at all
                    let pre_message = res.substring(0, res.indexOf(command_name)).trim();
                    if (pre_message.trim().length > 0)
                        this.routeResponse(source, pre_message);
                }

                let execute_res = await executeCommand(this, res);

                console.log('Agent executed:', command_name, 'and got:', execute_res);
                used_command = true;

                if (execute_res)
                    this.history.add('system', execute_res);
                else
                    break;
            }
            else { // conversation response
                this.history.add(this.name, res);
                this.routeResponse(source, res);
                break;
            }
            
            this.history.save();
        }

        return used_command;
    }

    async routeResponse(to_player, message) {
        if (this.shut_up) return;
        let self_prompt = to_player === 'system' || to_player === this.name;
        if (self_prompt && this.last_sender) {
            // this is for when the agent is prompted by system while still in conversation
            // so it can respond to events like death but be routed back to the last sender
            to_player = this.last_sender;
        }

        if (convoManager.isOtherAgent(to_player) && convoManager.inConversation(to_player)) {
            // if we're in an ongoing conversation with the other bot, send the response to it
            convoManager.sendToBot(to_player, message);
        }
        else {
            // otherwise, use open chat
            this.openChat(message);
            // note that to_player could be another bot, but if we get here the conversation has ended
        }
    }

    async openChat(message) {
        // [AI斗蛐蛐 patch] 台词密度控制：2 分钟内最多说一句（死亡播报不受限）。
        // 四个 AI 交叉剪辑时台词太密会眼花缭乱；命令执行不受影响，只抑制闲聊广播。
        const now = Date.now();
        const important = /died|death|死/i.test(message);
        if (!important && now - (this._last_chat_t || 0) < 120000) {
            console.log('[aidouququ] speech throttled (2-min density limit)');
            return;
        }
        this._last_chat_t = now;
        let to_translate = message;
        let remaining = '';
        let command_name = containsCommand(message);
        let translate_up_to = command_name ? message.indexOf(command_name) : -1;
        if (translate_up_to != -1) { // don't translate the command
            to_translate = to_translate.substring(0, translate_up_to);
            remaining = message.substring(translate_up_to);
        }
        message = (await handleTranslation(to_translate)).trim() + " " + remaining;
        // newlines are interpreted as separate chats, which triggers spam filters. replace them with spaces
        message = message.replaceAll('\n', ' ');

        if (settings.only_chat_with.length > 0) {
            for (let username of settings.only_chat_with) {
                this.bot.whisper(username, message);
            }
        }
        else {
            if (settings.speak) {
                speak(to_translate, this.prompter.profile.speak_model);
            }
            if (settings.chat_ingame) {this.bot.chat(message);}
            sendOutputToServer(this.name, message);
        }
    }

    startEvents() {
        // Custom events
        this.bot.on('time', () => {
            if (this.bot.time.timeOfDay == 0)
            this.bot.emit('sunrise');
            else if (this.bot.time.timeOfDay == 6000)
            this.bot.emit('noon');
            else if (this.bot.time.timeOfDay == 12000)
            this.bot.emit('sunset');
            else if (this.bot.time.timeOfDay == 18000)
            this.bot.emit('midnight');
        });

        let prev_health = this.bot.health;
        this.bot.lastDamageTime = 0;
        this.bot.lastDamageTaken = 0;
        this.bot.on('health', () => {
            if (this.bot.health < prev_health) {
                this.bot.lastDamageTime = Date.now();
                this.bot.lastDamageTaken = prev_health - this.bot.health;
            }
            prev_health = this.bot.health;
        });
        // Logging callbacks
        this.bot.on('error' , (err) => {
            console.error('Error event!', err);
        });
        // Use connection handler for runtime disconnects
        this.bot.on('end', (reason) => {
            if (!this._disconnectHandled) {
                const { msg } = handleDisconnection(this.name, reason);
                this.cleanKill(msg);
            }
        });
        this.bot.on('death', () => {
            this.actions.cancelResume();
            this.actions.stop();
        });
        this.bot.on('kicked', (reason) => {
            if (!this._disconnectHandled) {
                const { msg } = handleDisconnection(this.name, reason);
                this.cleanKill(msg);
            }
        });
        this.bot.on('messagestr', async (message, _, jsonMsg) => {
            if (jsonMsg.translate && jsonMsg.translate.startsWith('death') && message.startsWith(this.name)) {
                // [M1] tasked 模式：死亡交给任务层记账，不走 handleMessage（会触发 LLM）
                if (this.decider_mode === 'tasked') {
                    console.log('Agent died (tasked mode):', message);
                    this.taskRuntime?.noteDeath(message);
                    return;
                }
                console.log('Agent died: ', message);
                let death_pos = this.bot.entity.position;
                this.memory_bank.rememberPlace('last_death_position', death_pos.x, death_pos.y, death_pos.z);
                let death_pos_text = null;
                if (death_pos) {
                    death_pos_text = `x: ${death_pos.x.toFixed(2)}, y: ${death_pos.y.toFixed(2)}, z: ${death_pos.z.toFixed(2)}`;
                }
                let dimention = this.bot.game.dimension;
                this.handleMessage('system', `You died at position ${death_pos_text || "unknown"} in the ${dimention} dimension with the final message: '${message}'. Your place of death is saved as 'last_death_position' if you want to return. Previous actions were stopped and you have respawned.`);
            }
        });
        this.bot.on('idle', () => {
            this.bot.clearControlStates();
            this.bot.pathfinder.stop(); // clear any lingering pathfinder
            this.bot.modes.unPauseAll();
            setTimeout(() => {
                if (this.isIdle()) {
                    this.actions.resumeAction();
                }
            }, 1000);
        });

        // Init NPC controller
        this.npc.init();

        // This update loop ensures that each update() is called one at a time, even if it takes longer than the interval
        const INTERVAL = 300;
        let last = Date.now();
        setTimeout(async () => {
            while (true) {
                let start = Date.now();
                await this.update(start - last);
                let remaining = INTERVAL - (Date.now() - start);
                if (remaining > 0) {
                    await new Promise((resolve) => setTimeout(resolve, remaining));
                }
                last = start;
            }
        }, INTERVAL);

        this.bot.emit('idle');
    }

    async update(delta) {
        await this.bot.modes.update();
        this.self_prompter.update(delta);
        this.reportProductionState();
        await this.autosaveMemory();
        await this.checkTaskDone();
    }

    // [AI斗蛐蛐 patch] periodic memory autosave so sudden stops lose at most ~60s of turns.
    async autosaveMemory() {
        const now = Date.now();
        if (this._last_mem_save && now - this._last_mem_save < 60000) return;
        this._last_mem_save = now;
        try { await this.history.save(); } catch (e) { /* non-fatal */ }
        // [AI斗蛐蛐 patch] autonomy watchdog: if the self-prompt loop stopped (e.g. after transient
        // API errors), restart it after a cooldown so the bot never idles forever unattended.
        // [P0-B] DECIDER_MODE=systemone 时 self_prompter 常驻 STOPPED 属正常状态，watchdog 不得拉起（否则篡权 decider）；
        //        decider 自身循环永不退出，无停摆风险。
        // [M1] tasked 同理：任务层自带终态与超时，watchdog 不得拉起 self-prompt 篡权。
        if (settings.auto_goal && !['systemone', 'tasked'].includes(this.decider_mode) && this.self_prompter.isStopped()
            && (!this._last_goal_restart || now - this._last_goal_restart > 60000)) {
            this._last_goal_restart = now;
            log(this.name, 'Autonomy watchdog: restarting self-prompting toward the goal.');
            await this.self_prompter.start(settings.auto_goal);
        }
    }

    // [AI斗蛐蛐 patch] push lightweight state to the production layer (recorder/HUD/episode logs).
    reportProductionState() {
        if (!settings.production_report_url) return;
        const now = Date.now();
        if (this._last_report && now - this._last_report < 2000) return;
        this._last_report = now;
        try {
            const turns = (this.history?.turns || []).slice(-6).map(t => ({ role: t.role, content: String(t.content).slice(0, 300) }));
            // authentic HUD feed: hotbar slots (mineflayer inventory 36..44), selected slot, held item
            const hotbar = [];
            for (let i = 36; i <= 44; i++) {
                const it = this.bot.inventory?.slots?.[i];
                hotbar.push(it ? { name: it.name, count: it.count } : null);
            }
            // 背包主体（main inventory 9..35）供 GUI 重建叠加层使用
            const mainInv = [];
            for (let i = 9; i <= 35; i++) {
                const it = this.bot.inventory?.slots?.[i];
                mainInv.push(it ? { name: it.name, count: it.count } : null);
            }
            const dig = this.bot.targetDigBlock;
            const body = JSON.stringify({
                name: this.name,
                t: now,
                health: this.bot.health,
                food: this.bot.food,
                xp: this.bot.experience?.level ?? null,
                position: this.bot.entity?.position ?? null,
                dimension: this.bot.game?.dimension ?? null,
                timeOfDay: this.bot.time?.timeOfDay ?? null,
                day: this.bot.time?.day ?? null,
                busy: !!this.actions?.executing,
                actionLabel: this.actions?.currentActionLabel || '',
                selfPrompting: !!this.self_prompter?.isActive(),
                deaths: this._death_count ?? 0,
                hotbar,
                mainInv,
                quickBarSlot: this.bot.quickBarSlot ?? 0,
                heldItem: this.bot.heldItem?.name ?? null,
                digging: dig ? { x: dig.position.x, y: dig.position.y, z: dig.position.z } : null,
                memory: this.history?.memory || '',
                turns
            });
            fetch(settings.production_report_url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body }).catch(() => {});
        } catch (e) { /* production reporting must never crash the agent */ }
        // [AI斗蛐蛐 patch] highlight the block being dug in the 3D scene (viewer primitive)
        try {
            const dig = this.bot.targetDigBlock;
            const key = dig ? dig.position.toString() : null;
            if (key !== this._dig_key) {
                this._dig_key = key;
                if (dig && this.bot.viewer?.drawBoxGrid) {
                    this.bot.viewer.drawBoxGrid('dig', dig.position, dig.position.offset(1, 1, 1), 'yellow');
                } else if (!dig) {
                    this.bot.viewer?.erase?.('dig');
                }
            }
        } catch (e) { /* viewer may not exist */ }
    }

    isIdle() {
        return !this.actions.executing;
    }
    

    cleanKill(msg='Killing agent process...', code=1) {
        this.history.add('system', msg);
        this.bot.chat(code > 1 ? 'Restarting.': 'Exiting.');
        this.history.save();
        process.exit(code);
    }
    async checkTaskDone() {
        if (this.task.data) {
            let res = this.task.isDone();
            if (res) {
                await this.history.add('system', `Task ended with score : ${res.score}`);
                await this.history.save();
                // await new Promise(resolve => setTimeout(resolve, 3000)); // Wait 3 second for save to complete
                console.log('Task finished:', res.message);
                this.killAll();
            }
        }
    }

    killAll() {
        serverProxy.shutdown();
    }
}
