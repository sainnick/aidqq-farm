// decider.js — 决策层（P0-B spike）
//
// P0-A 结论（docs/decide-bench-report-20260928.md）：百炼 systemone choice 对本任务形态 FAIL，
// 采用「本地规则门 → 通用 LLM 闭集（豆包→GLM）→ 保守 fallback」两层。
//
// 铁律（任务书 §17 异步铁律）:
//   - 规则门是同步纯函数，永远本地。
//   - LLM 调用 fire-and-forget：请求在途时当前宏继续跑；响应回来后 apply-time 二次校验
//     （候选内 + 前置可行 + confidence 阈值 + 与当前宏不同）才允许 dispatch。
//   - 不用 sleep 假异步：循环 sleep 的是「决策节拍」，宏执行在 ActionManager 自己的 promise 上。
//
// 回滚: DECIDER_MODE 不设或 =legacy → 原 self_prompter 路径原样（agent.js 分支）。
import { getCommand } from './commands/index.js';
import { bailianChoice, llmChoice } from './dm_client.js';
import { appendFileSync } from 'fs';

const FOODS = ['beef', 'cooked_beef', 'porkchop', 'cooked_porkchop', 'chicken', 'cooked_chicken', 'bread', 'apple'];
const BANNED_EAT = ['chicken']; // 生鸡在 autoEat bannedFood 同款口径（本 profile 禁生食）
const TICK_MS = 1000;           // 决策节拍（§3.3 默认 1s）
const CONF_GATE = 0.5;          // <0.5 不执行 choice（官方 don't guess 语义）

const ACTION_DOCS = {
    continue_macro: 'The current macro is still running normally; keep it running. Only valid when busy.',
    collect_wood: 'Chop trees for logs.',
    craft_basic_tools: 'Craft the next missing basic item (planks/crafting_table/wooden_pickaxe/stone tools/furnace) from materials on hand.',
    mine_stone: 'Mine stone/cobblestone.',
    mine_iron: 'Search caves and mine iron ore.',
    smelt_iron: 'Smelt raw iron into ingots (only when raw iron is on hand).',
    craft_iron_gear: 'Craft bucket / flint_and_steel / iron_pickaxe (only when enough iron ingots).',
    collect_flint: 'Mine gravel for flint.',
    hunt_and_cook: 'Hunt animals and cook meat.',
    eat_now: 'Eat food right now to restore HP or hunger. Urgent when hp <= 10.',
    retreat_and_defend: 'Move away from danger; self-defense mode handles threats.',
    other: 'None of the above fits the situation.',
};

// ---------- 状态压缩（与 decide-bench 样本同构） ----------
function snapshot(agent) {
    const bot = agent.bot;
    const inv = {};
    let misc = 0;
    for (const item of bot.inventory.items()) {
        if (ACTION_KEY_ITEMS.has(item.name)) inv[item.name] = (inv[item.name] ?? 0) + item.count;
        else misc += item.count;
    }
    if (misc) inv._misc = misc;
    // equipment（护甲/手持不计入 misc 噪声）
    return {
        hp: Math.round((bot.health ?? 20) * 10) / 10,
        food: Math.round(bot.food ?? 20),
        dimension: bot.game?.dimension ?? 'overworld',
        day: bot.time?.day ?? 0,
        timeOfDay: bot.time?.timeOfDay ?? 1000,
        pos: [Math.round(bot.entity.position.x * 10) / 10, Math.round(bot.entity.position.y * 10) / 10, Math.round(bot.entity.position.z * 10) / 10],
        busy: !!agent.actions.executing,
        current_action: agent.actions.currentActionLabel ?? '',
        inventory: inv,
    };
}

const ACTION_KEY_ITEMS = new Set(['oak_log', 'oak_planks', 'stick', 'crafting_table', 'wooden_pickaxe', 'stone_pickaxe',
    'stone_sword', 'stone_axe', 'furnace', 'coal', 'raw_iron', 'iron_ore', 'iron_ingot', 'iron_pickaxe', 'bucket',
    'water_bucket', 'flint', 'flint_and_steel', ...FOODS, 'gravel', 'cobblestone']);

const isNight = (tod) => tod > 13000 || tod < 800;
const hasFood = (inv) => FOODS.some((f) => (inv[f] ?? 0) > 0);
const edibleNow = (inv) => FOODS.filter((f) => !BANNED_EAT.includes(f) && (inv[f] ?? 0) > 0);
const oreCount = (inv) => (inv.raw_iron ?? 0) + (inv.iron_ore ?? 0);

function ironNeeded(inv) {
    let n = 0;
    if ((inv.bucket ?? 0) + (inv.water_bucket ?? 0) === 0) n += 3;
    if (!(inv.flint_and_steel ?? 0)) n += 1;
    if (!(inv.iron_pickaxe ?? 0)) n += 3;
    return n;
}

// ---------- 前置可行性（三组统一口径的 JS 版） ----------
function precondOk(choice, s) {
    const inv = s.inventory;
    switch (choice) {
        case 'continue_macro': return s.busy;
        case 'eat_now': return edibleNow(inv).length > 0;
        case 'smelt_iron': return oreCount(inv) > 0;
        case 'craft_iron_gear': return (inv.iron_ingot ?? 0) >= 1;
        case 'craft_basic_tools':
            return (inv.oak_log ?? 0) > 0 || (inv.oak_planks ?? 0) >= 1
                || ((inv.cobblestone ?? 0) >= 3 && (inv.stick ?? 0) >= 2);
        case 'place_utility': return (inv.crafting_table ?? 0) > 0 || (inv.furnace ?? 0) > 0;
        default: return true; // collect/mine/hunt/retreat/other 无硬前置
    }
}

// ---------- 规则门（bench annotate.py 的 JS 移植，唯一解输出 confident=true） ----------
export function ruleDecide(s) {
    const inv = s.inventory;
    const eat = edibleNow(inv);
    const ore = oreCount(inv);
    const need = ironNeeded(inv);
    const safe = s.hp >= 12;

    if (s.hp <= 8 && eat.length) return { action: 'eat_now', confident: true, why: 'hp<=8+food(RULE4)' };
    if (s.food <= 6 && eat.length) return { action: 'eat_now', confident: true, why: 'hunger<=6(RULE4)' };
    if (s.hp <= 8) return { action: 'retreat_and_defend', confident: true, why: 'hp<=8 no food' };
    if (s.busy && safe) return { action: 'continue_macro', confident: true, why: 'macro running' };
    if (!s.busy) {
        // 教材链（确定性缺件）
        if (!(inv.crafting_table ?? 0)) return (inv.oak_log ?? 0) >= 1
            ? { action: 'craft_basic_tools', confident: true, why: 'no table+log (J6a)' }
            : { action: 'collect_wood', confident: true, why: 'no table no log (J12)' };
        if (!(inv.wooden_pickaxe ?? 0)) return ((inv.oak_planks ?? 0) >= 5 || (inv.oak_log ?? 0) >= 1)
            ? { action: 'craft_basic_tools', confident: true, why: 'need wooden pick (J6b)' }
            : { action: 'collect_wood', confident: true, why: 'need planks (J12)' };
        if ((inv.cobblestone ?? 0) < 20) return { action: 'mine_stone', confident: true, why: '<20 stone (J11)' };
        if (!(inv.stone_pickaxe ?? 0)) return ((inv.cobblestone ?? 0) >= 3 && (inv.stick ?? 0) >= 2)
            ? { action: 'craft_basic_tools', confident: true, why: 'need stone pick (J6c)' }
            : { action: 'mine_stone', confident: true, why: 'need cobble (J11)' };
        if (!(inv.furnace ?? 0) && (inv.cobblestone ?? 0) >= 8)
            return { action: 'craft_basic_tools', confident: true, why: 'need furnace (J6d)' };
        if (need > 0) {
            if (ore > 0 && (inv.furnace ?? 0)) return { action: 'smelt_iron', confident: true, why: 'ore on hand+furace (J8)' };
            if (ore > 0) return { action: 'craft_basic_tools', confident: true, why: 'ore on hand no furnace (J6d)' };
            return { action: 'mine_iron', confident: false, why: 'iron deficit, route unknown (J13 ambiguous)' };
        }
        if (!(inv.flint_and_steel ?? 0) && (inv.flint ?? 0) >= 1 && (inv.iron_ingot ?? 0) >= 1)
            return { action: 'craft_iron_gear', confident: true, why: 'flint+ingot for F&S (J7b)' };
        // 装备齐后的自由目标 → 交给 LLM 层
        return { action: null, confident: false, why: 'free objective (ambiguous)' };
    }
    // busy 且不安全（承伤中）→ 让 LLM 判断继续还是撤
    return { action: null, confident: false, why: 'busy under risk (J10 ambiguous)' };
}

// ---------- 候选裁剪（阶段白名单；search/place 无执行宏，P0-B 不进候选） ----------
export function candidatePrune(s) {
    const inv = s.inventory;
    const always = [];
    if (edibleNow(inv).length) always.push('eat_now');
    always.push('retreat_and_defend');
    if (s.busy) always.push('continue_macro');
    always.push('other');
    let stage, cands;
    if (!(inv.wooden_pickaxe ?? 0)) {
        stage = 'wood_age';
        cands = ['collect_wood', 'craft_basic_tools', 'hunt_and_cook'];
    } else if (!(inv.stone_pickaxe ?? 0) || (inv.cobblestone ?? 0) < 20) {
        stage = 'stone_age';
        cands = ['mine_stone', 'craft_basic_tools', 'collect_flint'];
    } else if (ironNeeded(inv) > 0) {
        stage = 'iron_age';
        cands = ['mine_iron', 'collect_flint', 'hunt_and_cook'];
        if (oreCount(inv) > 0) cands.unshift('smelt_iron');
        if ((inv.iron_ingot ?? 0) >= 1 && !(inv.flint_and_steel ?? 0) && (inv.flint ?? 0) >= 1) cands.unshift('craft_iron_gear');
        if (precondOk('craft_basic_tools', s)) cands.unshift('craft_basic_tools');
    } else {
        stage = 'gear_age';
        cands = ['craft_iron_gear', 'collect_flint', 'hunt_and_cook', 'mine_stone'];
        if (precondOk('craft_basic_tools', s)) cands.unshift('craft_basic_tools');
    }
    const out = [];
    for (const a of [...cands, ...always]) {
        if (!out.includes(a) && precondOk(a, s)) out.push(a);
    }
    return { candidates: out, stage };
}

// ---------- 动作 → 具体命令参数（执行仲裁；材料门控，缺料返回 null 交给上游采集） ----------
function nextCraftTarget(inv) {
    // 教材链逐件推进；每一件都先查材料，不够则返回 null（ruleDecide 会先走采集分支）
    if (!(inv.crafting_table ?? 0)) {
        if ((inv.oak_planks ?? 0) < 4) return (inv.oak_log ?? 0) >= 1 ? ['oak_planks', 4] : null;
        return ['crafting_table', 1];
    }
    if (!(inv.wooden_pickaxe ?? 0)) {
        if ((inv.oak_planks ?? 0) < 3) return (inv.oak_log ?? 0) >= 1 ? ['oak_planks', 4] : null;
        if ((inv.stick ?? 0) < 2) return (inv.oak_planks ?? 0) >= 2 ? ['stick', 4] : null;
        return ['wooden_pickaxe', 1];
    }
    if (!(inv.stone_pickaxe ?? 0)) {
        if ((inv.cobblestone ?? 0) < 3) return null;
        if ((inv.stick ?? 0) < 2) return (inv.oak_planks ?? 0) >= 2 ? ['stick', 4] : ((inv.oak_log ?? 0) >= 1 ? ['oak_planks', 4] : null);
        return ['stone_pickaxe', 1];
    }
    if (!(inv.stone_sword ?? 0) && (inv.cobblestone ?? 0) >= 2 && (inv.stick ?? 0) >= 1) return ['stone_sword', 1];
    if (!(inv.furnace ?? 0)) {
        if ((inv.cobblestone ?? 0) < 8) return null;
        return ['furnace', 1];
    }
    return null;
}

function nextGearTarget(inv) {
    if ((inv.bucket ?? 0) + (inv.water_bucket ?? 0) === 0 && (inv.iron_ingot ?? 0) >= 3) return ['bucket', 1];
    if (!(inv.flint_and_steel ?? 0) && (inv.iron_ingot ?? 0) >= 1 && (inv.flint ?? 0) >= 1) return ['flint_and_steel', 1];
    if (!(inv.iron_pickaxe ?? 0) && (inv.iron_ingot ?? 0) >= 3) return ['iron_pickaxe', 1];
    return null;
}

function commandFor(action, s, failCounts = {}) {
    const inv = s.inventory;
    // 资源降级链: 连败 2 次 = 本地资源枯竭 -> digDown 向下找;
    //             连败 5 次 = 该区域整体枯竭(含 digDown 也失败) -> 随机换区 60-100 格再试
    const fails = (a) => failCounts[a] ?? 0;
    if (['mine_stone', 'mine_iron', 'collect_flint', 'collect_wood', 'hunt_and_cook'].includes(action) && fails(action) >= 5) {
        const ang = Math.random() * Math.PI * 2;
        const dist = 60 + Math.floor(Math.random() * 40);
        const [x, , z] = s.pos;
        return { name: '!goToCoordinates', args: [Math.round(x + Math.cos(ang) * dist), s.pos[1], Math.round(z + Math.sin(ang) * dist), 2] };
    }
    switch (action) {
        case 'collect_wood': return { name: '!collectBlocks', args: ['oak_log', 3] };
        case 'mine_stone':
            if (fails('mine_stone') >= 2) return { name: '!digDown', args: [8] };
            return { name: '!collectBlocks', args: ['cobblestone', 24] };
        case 'mine_iron':
            if (fails('mine_iron') >= 2) return { name: '!digDown', args: [12] };
            return { name: '!collectBlocks', args: ['iron_ore', 8] };
        case 'collect_flint':
            if (fails('collect_flint') >= 2) return { name: '!digDown', args: [6] };
            return { name: '!collectBlocks', args: ['gravel', 3] };
        case 'smelt_iron': return { name: '!smeltItem', args: ['iron_ingot', Math.min(8, oreCount(inv))] };
        case 'craft_basic_tools': {
            const t = nextCraftTarget(inv);
            return t ? { name: '!craftRecipe', args: t } : null;
        }
        case 'craft_iron_gear': {
            const t = nextGearTarget(inv);
            return t ? { name: '!craftRecipe', args: t } : null;
        }
        case 'hunt_and_cook': return { name: '!searchForEntity', args: ['chicken', 96] };
        case 'eat_now': {
            const foods = edibleNow(inv);
            if (!foods.length) return null;
            const cooked = foods.find((f) => f.startsWith('cooked') || f === 'bread' || f === 'apple');
            return { name: '!consume', args: [cooked ?? foods[0]] };
        }
        case 'retreat_and_defend': return { name: '!moveAway', args: [24] };
        default: return null;
    }
}

// 采集动作 -> 成功判据资源（宏结束后计数未涨 = 失败，驱动 digDown 降级链）
const RESOURCE_OF = {
    mine_stone: ['cobblestone', 'stone'],
    mine_iron: ['raw_iron', 'iron_ore', 'iron_ingot'],
    collect_flint: ['gravel', 'flint'],
    collect_wood: ['oak_log'],
    hunt_and_cook: FOODS,
};

// ---------- Decider 主类 ----------
export class Decider {
    constructor(agent) {
        this.agent = agent;
        this.active = false;
        this.inFlight = false;   // LLM 请求在途标志（去重，不叠加）
        this.lastDispatch = { action: '', t: 0 };
        this.telePath = process.env.DECIDER_TELEMETRY || 'dm_telemetry.jsonl';
        this.useBailian = process.env.DECIDER_CHANNEL === 'bailian';
        this.stats = { ticks: 0, rule_gate_pass: 0, llm_calls: 0, llm_fallback: 0, dispatches: 0, errors: 0 };
    }

    isActive() { return this.active; }

    tele(event, data) {
        try {
            appendFileSync(this.telePath, JSON.stringify({ t: Date.now(), event, ...data }) + '\n');
        } catch { /* 遥测失败不影响主循环 */ }
    }

    async start(missionText) {
        if (this.active) return;
        this.active = true;
        this.mission = (missionText ?? '').slice(0, 500);
        console.log(`[decider] started (channel=${this.useBailian ? 'bailian' : 'llm'}, telemetry=${this.telePath})`);
        this.loop();
    }

    async stop() {
        this.active = false;
        console.log(`[decider] stopped. stats=${JSON.stringify(this.stats)}`);
    }

    dispatch(action, snap, source) {
        // 防抖: 同一动作 8s 冷却 —— 但宏已实际启动过(busy 曾变 true)则视为正常续派, 不冷却
        const macroRan = this.actionStartedSinceDispatch;
        if (action === this.lastDispatch.action && !macroRan && Date.now() - this.lastDispatch.t < 8000) {
            this.sameDispatchStreak = (this.sameDispatchStreak ?? 0) + 1;
            this.tele('dispatch_debounce', { action, streak: this.sameDispatchStreak });
            // 连续 3 次被冷却 = 卡死（材料不够/宏失败循环）→ 升级为分歧，让 LLM 换思路（60s TTL 后允许规则重试）
            if (this.sameDispatchStreak >= 3 && !this.stuckAction) {
                this.stuckAction = action;
                this.stuckSince = Date.now();
            }
            return false;
        }
        this.sameDispatchStreak = 0;
        this.stuckAction = null;
        this.actionStartedSinceDispatch = false;
        this.failCounts = this.failCounts ?? {};
        const cmd = commandFor(action, snap, this.failCounts);
        if (!cmd) { this.tele('dispatch_skip', { action, source, reason: 'no_command' }); return false; }
        const command = getCommand(cmd.name);
        if (!command) { this.tele('dispatch_skip', { action, source, reason: 'unknown_command' }); return false; }
        // apply-time 二次校验（LLM 往返期间状态可能已变）
        if (!precondOk(action, this.snapshotNow())) {
            this.tele('dispatch_skip', { action, source, reason: 'precond_gone' });
            return false;
        }
        this.tele('dispatch', { action, source, command: cmd.name, args: cmd.args, hp: snap.hp, busy: snap.busy });
        this.lastDispatch = { action, t: Date.now() };
        if (cmd.name === '!goToCoordinates') {
            // 换区成功 = 重新计数（新区域资源状况未知）
            this.failCounts = {};
            this.stuckAction = null;
        }
        // 记录采集判据: 宏结束后对比资源计数
        const resKeys = RESOURCE_OF[action];
        this.pendingCheck = resKeys ? { action, t: Date.now(), inv: { ...snap.inventory } } : null;
        this.stats.dispatches++;
        command.perform(this.agent, ...cmd.args).catch((e) => {
            this.stats.errors++;
            this.tele('dispatch_error', { action, error: String(e).slice(0, 200) });
        });
        return true;
    }

    snapshotNow() { return snapshot(this.agent); }

    applyChoice(res, cands, snapAtRequest) {
        if (!res) {
            // 通道全挂: 保守回退到规则默认（不虚构）
            if (this.pendingFallback && precondOk(this.pendingFallback, this.snapshotNow()))
                this.dispatch(this.pendingFallback, this.snapshotNow(), 'rule_default_fallback');
            this.stats.llm_fallback++;
            return;
        }
        const snapNow = this.snapshotNow();
        const rejectFall = (reason) => {
            // 拒绝不能等于发呆（ep060 教训）: 回退到规则默认动作
            this.stats.llm_fallback++;
            this.tele('llm_reject', { reason, choice: res.choice, conf: res.confidence });
            if (this.pendingFallback && this.pendingFallback !== this.stuckAction
                && precondOk(this.pendingFallback, snapNow) && !snapNow.busy)
                this.dispatch(this.pendingFallback, snapNow, `fallback_after_reject(${reason})`);
        };
        if (!res.choice || res.choice === 'other') { rejectFall('other_or_null'); return; }
        if (!cands.includes(res.choice)) { rejectFall('not_in_candidates'); return; }
        const conf = res.confidence;
        if (conf !== null && conf < CONF_GATE) { rejectFall('low_confidence'); return; }
        // 与当前宏相同的动作不必打断
        if (snapNow.busy && res.choice === 'continue_macro') { this.tele('llm_keep', { choice: res.choice }); return; }
        this.dispatch(res.choice, snapNow, `llm(${res.channel},conf=${conf})`);
    }

    async loop() {
        while (this.active) {
            const t0 = Date.now();
            try {
                const snap = this.snapshotNow();
                this.stats.ticks++;
                if (snap.busy) this.actionStartedSinceDispatch = true; // 宏在跑: 下次同类续派不冷却
                // 采集成败判定: 宏结束且跑满 3s, 资源未涨 = 失败 -> failCounts++（驱动 digDown 降级）
                if (this.pendingCheck && !snap.busy && Date.now() - this.pendingCheck.t > 3000) {
                    const pc = this.pendingCheck;
                    const gained = (RESOURCE_OF[pc.action] ?? []).some((k) => (snap.inventory[k] ?? 0) > (pc.inv[k] ?? 0));
                    if (gained) this.failCounts[pc.action] = 0;
                    else {
                        this.failCounts[pc.action] = (this.failCounts[pc.action] ?? 0) + 1;
                        this.tele('collect_fail', { action: pc.action, fails: this.failCounts[pc.action] });
                    }
                    this.pendingCheck = null;
                }
                if (this.stuckAction && Date.now() - (this.stuckSince ?? 0) > 60000) {
                    this.tele('stuck_expire', { action: this.stuckAction });
                    this.stuckAction = null;
                }
                const verdict = ruleDecide(snap);
                this.tele('tick', { stage_hint: verdict.why, verdict_action: verdict.action, confident: verdict.confident, hp: snap.hp, busy: snap.busy });

                if (verdict.action === 'continue_macro') {
                    this.stats.rule_gate_pass++;
                    // 宏在跑，什么都不做 —— 连续性铁律
                } else if (verdict.confident && verdict.action) {
                    // stuck 期间规则照常派发: commandFor 的 failCounts 降级链（digDown）负责恢复；
                    // stuckAction 只让 LLM 沉默（问了也是同一答案），不造成规则侧空转
                    this.stats.rule_gate_pass++;
                    if (!snap.busy) this.dispatch(verdict.action, snap, `rule(${verdict.why})`);
                } else if (!this.inFlight && !this.stuckAction) {
                    // 真分歧 → 异步 LLM 闭集；当前状态下的宏（若有）继续跑。
                    // stuckAction 挂起期间不问 LLM（环境没变，问了也是同一答案——ep060 教训：150 次重复调用全被拒）
                    this.inFlight = true;
                    this.stats.llm_calls++;
                    const { candidates, stage } = candidatePrune(snap);
                    const criteria = {};
                    for (const c of candidates) criteria[c] = ACTION_DOCS[c];
                    // 卡死的动作不再进候选（LLM 只能在还走得通的路里选）
                    const liveCandidates = candidates.filter((c) => c !== this.stuckAction);
                    if (!liveCandidates.length || (liveCandidates.length === 1 && liveCandidates[0] === 'other')) {
                        this.inFlight = false;
                        this.tele('llm_skip', { reason: 'no_live_candidates', candidates });
                        await new Promise((r) => setTimeout(r, 3000));
                        continue;
                    }
                    const reqSnap = snap;
                    this.pendingFallback = verdict.action === this.stuckAction ? null : verdict.action;
                    const channel = this.useBailian ? bailianChoice({ ...reqSnap, mission: this.mission }, criteria)
                                                    : llmChoice({ ...reqSnap, mission: this.mission }, criteria);
                    channel.then((res) => {
                        this.tele('llm_response', { stage, candidates: liveCandidates.length, ...res });
                        this.applyChoice(res, liveCandidates, reqSnap);
                    }).catch((e) => {
                        this.stats.llm_fallback++;
                        this.tele('llm_error', { error: String(e).slice(0, 200) });
                    }).finally(() => { this.inFlight = false; });
                }
            } catch (e) {
                this.stats.errors++;
                this.tele('loop_error', { error: String(e).slice(0, 300) });
            }
            const dt = Date.now() - t0;
            await new Promise((r) => setTimeout(r, Math.max(50, TICK_MS - dt)));
        }
    }
}
