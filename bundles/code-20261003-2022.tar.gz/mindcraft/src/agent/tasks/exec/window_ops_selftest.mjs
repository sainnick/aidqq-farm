﻿// window_ops_selftest.mjs — MC-M1-TASK-09-r4 的离线用例（不开服、不占端口、不连任何东西）
//
// 本单治的是两条病，两条都**静默**，所以用例必须能证伪"修好了"，而不是只能证明"没抛错"：
//
//   ① **取料区间是坏的**：mineflayer `furnace.js:99-100` 的 `putSomething` 把
//      `sourceStart: furnace.inventoryStart, sourceEnd: furnace.inventoryEnd` 当取料区间。
//      r3 离线量到熔炉窗是 `slots=39 / inventoryStart=27 / inventoryEnd=63`
//      ⇒ 实际只覆盖窗口槽 27–38（12 格），**玩家主背包 3–26 这 24 格结构上够不着**。
//      本单改成从**服务端 window_items 的数组长度**推区间（`playerInvRange`）。
//      ⇒ 用例 ①–⑤ 就是钉这件事的：真实 prismarine-windows + 真实 1.16.1 物品工厂，
//        故意造出 r3 那种混搭区间，再断言 `playerInvRange` 仍取到**全部 36 格**。
//      ⚠ 阴性对照：旧的 `win.inventoryStart/inventoryEnd` 在同一夹具上**必须错**（用例 ④）——
//        如果哪天"坏区间"也变对了，这条用例会红，那说明 r3 的机制描述需要再更正一次。
//
//   ② **`item`（光标）字段填错**：1.16.1 服务端 ack 判据是
//      `ItemStack.matches(包里的光标, 点击后服务端光标)`（`ServerGamePacketListenerImpl.java:1180`），
//      而 mineflayer `clickWindow` 填的是 `win.slots[slot]`（`inventory.js:571/626`）。
//      ⇒ 用例 ⑥–⑫ 断言 `clickCarryConfirmed` 在**四种点击语义**下 `item` 各填什么，
//        并用**变异测试**（把 PICKUP 分支换回 `win.selectedItem`）证明这些断言真能抓住它。
//
//   ②b **r6 更正（本单主因）**：QUICK_MOVE 的返回值规则此前被写错成"返回被移动那摞"。
//      真规则（`AbstractContainerMenu.java:243` + `ItemStack.isSame`）：
//      **源格被搬空（常态）⇒ 服务端 `clicked()` 返回 EMPTY**。
//      ⇒ 旧夹具与被测代码一起编码了这个错规则，r5 实跑 `furnaceLoad 0/30`。
//      ⇒ 现在：⑥③ / ⑰ 把期望**反过来**当阳性对照，⑨ 整组改测
//        `loadIntoFurnaceSlot` 的**两次 PICKUP** 路径（r6 起不再用 QUICK_MOVE）。
//
//   ③ 2×2 网格合成的**几何闸门**：`_gridCells` 放不下必须返回 null（"需要工作台"），
//      绝不能少放几个格子凑合 —— 少放会被服务端判成配方不匹配、结果格恒空，
//      读数看起来像"合成失败"而真因是"这东西根本不该走 2×2"。用例 ⑬–⑮。
//
//   ④ 假 bot 只补**真库确实有**的字段（G 线第七轮那条纪律：假 bot 比真库宽 ⇒ 真 bug 被盖成绿灯）。
//      见 `makeFakeBot` 的字段清单与末尾的 `assertFakeBotMatchesRealLib`。
//
// 跑法：node window_ops_selftest.mjs      （退出码 0 = 全过）

import { EventEmitter } from 'events';
import { createRequire } from 'module';
import prismarineItem from 'prismarine-item';
import {
    playerInvRange, windowSlotCount, slotCountSource, countItemsInRange, findInPlayerRange,
    itemWithCount, toItem, waitServerWindowSlots, clickCarryConfirmed, quickMoveIntoFurnace,
    craftInGridConfirmed, clickFlavor, windowClickPacket, makeCursorTracker, predictClickedReturn,
    // r6 新原语：⑨ 直接测它们（别名 quickMoveIntoFurnace/OutOfFurnace 只是同签名包装，
    //   别名坏掉时必须能被抓住，所以正例不走别名）
    loadIntoFurnaceSlot, pickupStackToSlot, takeOutOfFurnaceSlot,
} from './window_ops.js';

const require = createRequire(import.meta.url);

/**
 * 安全地取一段摘要。
 * ⚠ 关键点：**实参在调用点就被求值** —— `JSON.stringify(undefined)` 返回的是
 *   `undefined`（不是字符串），所以 `JSON.stringify(x?.y).slice(0,n)` 会在断言
 *   还没来得及跑之前就抛 TypeError，**把后面所有断言一起带走**。
 *   本单第一版就是这么写的，变异测试 M1 里明明已经红了 4 条，却整体崩掉、看不到后续结果。
 */
const brief = (v, n = 140) => {
    try {
        const s = JSON.stringify(v);
        return s === undefined ? String(v) : s.slice(0, n);
    } catch { return '(取不出来)'; }
};

let pass = 0, fail = 0;
/**
 * ⚠ `extra` 必须能扛住"被测对象是 undefined/null"——本单第一版写成
 *   `brief(sent?.params, 120)`，而 `JSON.stringify(undefined)`
 *   返回的是 **`undefined` 不是字符串** ⇒ 断言失败时 `.slice` 抛异常，
 *   **把后面所有断言一起带走**（变异测试 M1 实际踩到：明明已经红了 4 条，
 *   却在第 5 条崩掉，看不到后面的结果）。
 *   ⇒ 失败路径绝不允许抛异常。
 */
const ok = (cond, name, extra = '') => {
    if (cond) { pass++; console.log(`  ✅ ${name}`); }
    else {
        fail++;
        let e = '';
        try { e = extra === '' ? '' : `  → ${String(extra).slice(0, 160)}`; } catch { e = '  → (附加信息取不出来)'; }
        console.log(`  ❌ ${name}${e}`);
    }
};
const section = (t) => console.log(`\n── ${t} ──`);
/** 让出微任务队列：被测函数里发包发生在 await 之后，读"发了什么"之前必须先让一拍 */
const tick = () => new Promise((r) => setImmediate(r));

// ─────────────────────────────────────────────────────────────────────
// 夹具：真 1.16.1 registry + 真 prismarine-windows 造的窗口（不是手搓的对象）
// ─────────────────────────────────────────────────────────────────────
const registry = require('prismarine-registry')('1.16.1');
const Item = prismarineItem(registry);
const windowsFactory = require('prismarine-windows')(registry);

/**
 * 造一扇 **r3 实测那种混搭**的窗口：槽数是熔炉的 39，但背包区间被换成坏的 {27,62}。
 * 这正是 1.16.1 上 open_window 的类型号对不上 prismarine-windows 自己那套编号时
 * `createWindow` 兜底分支造出来的东西（`prismarine-windows/index.js:76-85`）。
 */
function makeFurnaceWindowBroken() {
    const w = windowsFactory.createWindow(7, 'minecraft:furnace', 'container.furnace', undefined);
    w.id = 7;
    // 强行复现 r3 的观测值
    w.inventoryStart = 27;
    w.inventoryEnd = 63;
    w.slots = new Array(39).fill(null);
    return w;
}
/** 阴性对照夹具：区间**没坏**的熔炉窗（prismarine 自己认对了类型） */
function makeFurnaceWindowGood() {
    const w = windowsFactory.createWindow(7, 'minecraft:furnace', 'container.furnace', undefined);
    w.id = 7;
    w.slots = new Array(w.slots.length).fill(null);
    return w;
}

/**
 * 假 bot：**只补真库确实有的东西**。
 * `bot._client`（EventEmitter：真 bot 上是 minecraft-protocol 的 Client）、
 * `bot.registry`、`bot.version`、`bot.supportFeature`（真 bot 上的方法）。
 * 刻意**不补** `bot.inventory.windowSlotsRange` 之类真库没有的字段。
 */
function makeFakeBot({ version = '1.16.1' } = {}) {
    const client = new EventEmitter();
    client.written = [];
    client.write = (name, params) => { client.written.push({ name, params }); };
    return {
        _client: client,
        registry,
        version,
        supportFeature: (f) => {
            // 1.16.x 真实取值（minecraft-data 的 features）
            if (f === 'actionIdUsed' || f === 'transactionPacketExists') return true;
            if (f === 'stateIdUsed') return false;
            return false;
        },
    };
}

// ⚠⚠ **本单踩到的一个真陷阱，必须钉住**（手册 §3 已有 D 线那条同族记录：
//   "prismarine-item 在 1.16 上 `.name` 可能是 `unknown`"，这里是它的**成因**）：
//   `new Item('iron_ore', 5)` 在 1.16.1 上给出 `{name:'unknown', type:'iron_ore'}` ——
//   **`type` 是字符串，不是数字 id**！于是 `Item.toNotch()` 产出的 `itemId` 是字符串
//   `"iron_ore"`，协议要的是 VarInt 数字 ⇒ **发出去的包在真实服务端上必然是坏的**。
//   而 if 两个 undefined/两个同名字符串互相比较，断言会**假绿**。
//   ⇒ 夹具一律**按数字 id 造物品**，并且下面 ⑯ 把这个陷阱本身断言住。
const item = (name, count) => {
    const id = registry.itemsByName[name]?.id;
    if (id == null) throw new Error(`fixture: 1.16.1 没有这个物品 ${name}`);
    return new Item(id, count ?? 1);
};

/**
 * 造一条**服务端光标包**（1.16.1：windowId=-1 / slot=-1）。
 * ⚠ 这是本单最关键的一条夹具：真服上 mineflayer **把这条包丢掉**
 *   （`inventory.js:738-753`：`window.id !== packet.windowId ⇒ return`），
 *   所以 `win.selectedItem` **恒为 null**，而服务端光标是真的有东西。
 *   第一版夹具让测试自己维护 `win.selectedItem` ⇒ 天然与真服不同构
 *   ⇒ 用例全绿、真服 2×2 全灭（T09R4_IRON trial_01：4 次 cursor_lost_after_pickup
 *   与 4 次 pickup_rejected 严格交替）。**假 bot 与真服同构，是这一条的全部意义。**
 *
 * ⚠ 位置在本文件靠前处（`const` 不提升，⑨ 之前用它会撞 TDZ）。
 *   ⑨（熔炉装料）也用这一条：1.16.1 的 accepted 路径
 *   （`ServerGamePacketListenerImpl.java:1182-1185`）会 `broadcastCarriedItem()`，
 *   **只广播光标、不广播任何槽位** ⇒ 两次 PICKUP 之间的光标真值走的就是这条包。
 */
const sayCursor = (bot, it) => bot._client.emit('set_slot', {
    windowId: -1, slot: -1,
    item: it ? { present: true, itemId: it.type, itemCount: it.count } : { present: false },
});

// ─────────────────────────────────────────────────────────────────────
section('① 区间：坏夹具上 playerInvRange 仍取到全部 36 格（r3 病根）');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();

    // r3 的原始观测（钉住，防止"病根形状"被人悄悄改掉而不自知）
    ok(win.slots.length === 39, '夹具复现 r3 观测：slots.length=39', `got ${win.slots.length}`);
    ok(win.inventoryStart === 27 && win.inventoryEnd === 63,
        '夹具复现 r3 观测：inventoryStart=27 / inventoryEnd=63（坏区间）',
        `got ${win.inventoryStart}/${win.inventoryEnd}`);

    // 关键：没有服务端 window_items 快照时，退回 slots.length 推
    const r = playerInvRange(bot, win);
    ok(r.start === 3 && r.end === 39, 'playerInvRange 给出 3–39（39−36），不是 27–63',
        `got ${r?.start}-${r?.end}`);
    ok(r.start === win.slots.length - 36, '区间 = 槽数 − 36 这条原版规则');
    ok(r.hotbarStart === 30, '快捷栏起点 = 30（主背包 3..29 之后）', `got ${r.hotbarStart}`);
}

// ─────────────────────────────────────────────────────────────────────
section('② 服务端 window_items 优先于本地 slots.length');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();
    ok(playerInvRange(bot, win).via === 'prismarine_slots', '无服务端快照时来源标 prismarine_slots');

    // 服务端下发整窗：真实槽数 39
    bot._client.emit('window_items', { windowId: win.id, items: new Array(39).fill(null) });
    ok(windowSlotCount(bot, win) === 39, '服务端 window_items 记下槽数 39');
    ok(slotCountSource(bot, win) === 'window_items', '来源标成 window_items（可区分）');
    ok(playerInvRange(bot, win).via === 'window_items', '有服务端快照后 via 变成 window_items');

    // 服务端说其实有 46 格（类型认错时的真实情形）⇒ 区间必须跟着服务端走
    bot._client.emit('window_items', { windowId: win.id, items: new Array(46).fill(null) });
    const r = playerInvRange(bot, win);
    ok(r.start === 10 && r.end === 46, '服务端改口说 46 格 ⇒ 区间跟着变成 10–46（不认本地 39）',
        `got ${r?.start}-${r?.end}`);

    // 不同窗口互不污染
    const w2 = windowsFactory.createWindow(9, 'minecraft:furnace', 'x', undefined);
    w2.slots = new Array(39).fill(null);
    ok(windowSlotCount(bot, w2) === 39, '按窗口 id 分别记，不会串号');
}

// ─────────────────────────────────────────────────────────────────────
section('③ 坏区间够不着的 24 格，新区间一个不漏');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();
    // 玩家主背包：3..35（33 格）里塞满矿石，主背包最前面那几格 r3 够不着
    for (let i = 3; i <= 35; i++) win.slots[i] = item('iron_ore', 1);
    // 快捷栏 36..38
    for (let i = 36; i <= 38; i++) win.slots[i] = item('oak_log', 1);

    // 守卫：夹具造出来的物品必须是**协议形状**（否则下面所有断言都在比字符串，假绿）
    ok(win.slots[3].name === 'iron_ore' && typeof win.slots[3].type === 'number',
        '夹具守卫：物品是数字 type + 正确 name', `${win.slots[3].name}/${typeof win.slots[3].type}`);

    const range = playerInvRange(bot, win);
    // r3 的坏区间只覆盖 27..38
    const oldReachable = [];
    for (let i = win.inventoryStart; i < Math.min(win.inventoryEnd, win.slots.length); i++) {
        if (win.slots[i]) oldReachable.push(i);
    }
    ok(oldReachable.length === 12, '阴性对照：r3 坏区间只能看到 12 格', `got ${oldReachable.length}`);
    ok(countItemsInRange(bot, win, range, 'iron_ore') === 33, '新区间读到全部 33 个 iron_ore',
        `got ${countItemsInRange(bot, win, range, 'iron_ore')}`);
    ok(findInPlayerRange(win, range, 'iron_ore') === 3, '第一个 iron_ore 在槽 3（坏区间的起点是 27）');
    ok(findInPlayerRange(win, range, 'oak_log') === 36, '快捷栏的 oak_log 在 36 也够得着');
    ok(countItemsInRange(bot, win, range, 'coal') === 0, '没有的东西仍然读 0（不凭空造）');
}

// ─────────────────────────────────────────────────────────────────────
section('④ 阴性对照：区间没坏时两种口径一致（防"坏区间也变对"）');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowGood();
    ok(win.inventoryStart === 3 && win.inventoryEnd === 39,
        '夹具：prismarine 自己认对类型时区间就是 3–39', `got ${win.inventoryStart}/${win.inventoryEnd}`);
    const r = playerInvRange(bot, win);
    ok(r.start === win.inventoryStart && r.end === win.inventoryEnd,
        '区间没坏时，新口径与库口径**逐字相同**（不制造行为变化）');
    // 反向：如果哪天 r3 那个混搭区间也变对了，用例 ① 的"阴性对照"就该红——
    // 这条断言把"病根形状"钉死，防止将来静默变化。
    ok(!(makeFurnaceWindowBroken().inventoryStart === 3),
        '反向守卫：坏夹具的区间仍不等于 3（若变了说明库行为变了，要重新评估 r3 结论）');
}

// ─────────────────────────────────────────────────────────────────────
section('⑤ window 0 的区间沿用本仓既有口径');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const inv = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    inv.slots = new Array(inv.slots.length).fill(null);
    ok(inv.slots.length === 46, 'window 0 有 46 槽', `got ${inv.slots.length}`);
    const r = playerInvRange(bot, inv);
    // 1.16.1 InventoryMenu 实测（子 agent 逐行核过源码）：0=产物 1-4=网格 5-8=护甲
    // 9-35=主背包 36-44=快捷栏 45=副手
    ok(r.start === 9 && r.end === 45 && r.hotbarStart === 36, 'window 0 区间 = 9–45 / 快捷栏 36',
        `got ${r?.start}-${r?.end} / ${r?.hotbarStart}`);
    ok(r.start === inv.inventoryStart && r.end === inv.inventoryEnd,
        'window 0 上新口径与库口径一致（countItems 走的就是这个区间）');
    // ⚠ 46−36=10 是错的：window 0 的护甲+副手占了 5-8 与 45 ⇒ 用例钉住这个特例
    ok(inv.slots.length - 36 !== 9, '守卫：window 0 不能套用"槽数−36"（会是 10，差 1 格）');
}

// ─────────────────────────────────────────────────────────────────────
section('⑥ item 字段：按 1.16.1 源码填「clicked() 的返回值」（2×2 病根）');
// ─────────────────────────────────────────────────────────────────────
// 判据（`ServerGamePacketListenerImpl.java:1179-1180`）：
//   `ItemStack.matches(包里的 item, menu.clicked(slot, button, mode, player))`
// 而 `AbstractContainerMenu.b(...)` 的返回值（逐行核过 `docs/research/data/src-1161/`）：
//   `:159` 初值 `ItemStack.EMPTY`；`:256` PICKUP 只在**被点那格非空**时赋成那格的拷贝；
//   `:243` QUICK_MOVE 的 `for (… !s.isEmpty() && ItemStack.isSame(slot.getItem(), s); …)`
//     —— `ItemStack.isSame` 是 `!a.isEmpty() && !b.isEmpty() ? a.sameItem(b) : false`，
//        **只要有一边空就 false** ⇒ 源格被搬空时循环体 0 次 ⇒ 停在初值 EMPTY；
//     只有**部分搬运**（源格还剩同类）才会返回 `AbstractFurnaceMenu:102` 搬动前那摞的拷贝。
// ⇒ 规则：**item = 被点那一格的点击前内容；那格为空、或 QUICK_MOVE 把它搬空了，就报空。**
// ⚠ **不是"点击后的光标"** —— 光标是 `:254` 的 `☃x.m()`，它不参与返回值。
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('spruce_planks', 8);
    const lastPkt = () => bot._client.written.at(-1);

    // ① 整摞拿起（左键点非空格）⇒ item = 那一格的点击前内容
    let r = await clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 50 });
    ok(r.ok === false && r.unconfirmed === true, '没回执时如实判 unconfirmed（不假定成功）');
    let pkt = lastPkt();
    ok(pkt.name === 'window_click', '发的是 window_click');
    ok(pkt.params.windowId === 0 && pkt.params.slot === 10, 'windowId/slot 对得上');
    ok(pkt.params.item && pkt.params.item.itemId === win.slots[10].type, '拿起：item 填的是那一格的东西',
        brief(pkt.params.item));
    ok(typeof pkt.params.item.itemId === 'number', 'itemId 必须是**数字**（VarInt），不是物品名字符串',
        `typeof=${typeof pkt.params.item?.itemId}`);
    ok(pkt.params.item.itemCount === 8, '拿起：数量也是那一格的数量', `got ${pkt.params.item?.itemCount}`);
    ok(typeof pkt.params.action === 'number', '1.16.x 信封带 action 号');

    // ② ★★ 右键把 1 个放进**空的** 2×2 格 ⇒ item **必须是空**（`AbstractContainerMenu:159+256`
    //    那一格原本是空 ⇒ 返回值从初值 EMPTY 起、从没被赋值）
    //    ⚠ 这正是 r4 实跑 `place_rejected` 的成因：当时上报的是光标 `oak_log×5`。
    win.selectedItem = item('spruce_planks', 8);
    await clickCarryConfirmed(bot, win, { slot: 1, mouseButton: 1, mode: 0, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false,
        '★★ 放进空格：item 必须报空（不是光标、不是空格里的东西）', brief(pkt.params.item));
    ok(!('itemCount' in (pkt.params.item || {})) || pkt.params.item.itemCount === 0,
        '★★ 放进空格：不能带 itemCount（present=false 就是"什么都没有"）', brief(pkt.params.item));

    // ③ ★★ r6 更正后的**阳性对照**：QUICK_MOVE 点**会被搬空**的非空槽 ⇒ item 报**空**
    //    机制：`AbstractContainerMenu.java:243` 的
    //      `for (s = quickMoveStack(slot); !s.isEmpty() && ItemStack.isSame(slot.getItem(), s); ...)`
    //    而 `ItemStack.isSame`（同目录 `ItemStack.java`）是
    //      `!a.isEmpty() && !b.isEmpty() ? a.sameItem(b) : false` —— **只要有一边空就 false**
    //    ⇒ 循环体一次都不执行 ⇒ 返回值停在 `:159` 的初值 `ItemStack.EMPTY`。
    //    而熔炉装料**总是**把源格搬空（`AbstractFurnaceMenu:102` 先 `copy()` 再整摞搬）
    //    ⇒ 这就是 r5 实跑 0/30 的病根（上报 iron_orex3、服务端算 EMPTY ⇒ 每次被拒）。
    win.selectedItem = null;
    await clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 1, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.mode === 1, 'QUICK_MOVE 的 mode=1（先确认这一击确实是 shift，别让用例空转）');
    ok(pkt.params.item && pkt.params.item.present === false,
        '★★ QUICK_MOVE 搬空源格（常态）⇒ item 报**空**，不是那一摞（`AbstractContainerMenu:243` 的 isSame 循环 0 次）',
        brief(pkt.params.item));

    // ③b ★ 对照：**同一格**、同一个 `item` 规则，只把 mode 从 1 换成 0 ⇒ 结果相反。
    //     一击之差、两条 1.16.1 规则（`:253-256` PICKUP 返回被点格点击前内容；
    //     `:243` QUICK_MOVE 搬空即 EMPTY）—— 这就是 r6 把装料全改成 PICKUP 的全部理由。
    await clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === true && pkt.params.item.itemCount === 8,
        '★★ 同一格改用 PICKUP（mode 0）⇒ item 是那 8 个整摞（`AbstractContainerMenu:253-256`）',
        brief(pkt.params.item));

    // ④ 放回（光标整摞放进空格）⇒ 被点格为空 ⇒ item 报空
    win.selectedItem = item('spruce_planks', 6);
    await clickCarryConfirmed(bot, win, { slot: 20, mouseButton: 0, mode: 0, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false, '放回：被点是空格 ⇒ item 填空', brief(pkt.params.item));

    // ⑤ ★ 交换语义：光标**非空**时点**非空**格 ⇒ item 仍是**那一格的**内容，**不是光标**
    //    （光标非空 + 格子非空 = 交换；服务端算出的返回值 = 格子那摞）
    win.slots[20] = item('oak_log', 3);
    win.selectedItem = item('spruce_planks', 6);
    await clickCarryConfirmed(bot, win, { slot: 20, mouseButton: 0, mode: 0, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item.itemId === win.slots[20].type && pkt.params.item.itemCount === 3,
        '★ 交换：item 填被点格的 3 个原木，**不是**手上的 6 个木板', brief(pkt.params.item));

    // ⑥ QUICK_MOVE 点**空**槽 ⇒ nothing to move ⇒ 返回空
    await clickCarryConfirmed(bot, win, { slot: 25, mouseButton: 0, mode: 1, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false, 'QUICK_MOVE 点空槽：item 填空（没东西可搬）', brief(pkt.params.item));

    // ⑦ 明知搬不动（expectMove:false）⇒ 空
    await clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 1, expectMove: false, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false, 'expectMove:false ⇒ item 填空', brief(pkt.params.item));

    // ⑧ 点窗口外（THROW，slot<0）⇒ 返回空
    await clickCarryConfirmed(bot, win, { slot: -999, mouseButton: 0, mode: 0, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false, '点窗口外（THROW）：item 填空', brief(pkt.params.item));

    // ⑨ ★★ 回归锁：旧的 `carryAfter` 入参**必须被忽略**（它就是 r4 的病根写法）
    win.slots[30] = item('cobblestone', 5);
    win.selectedItem = item('oak_log', 9);
    await clickCarryConfirmed(bot, win, { slot: 30, mouseButton: 0, mode: 0, carryAfter: item('oak_log', 9), timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item.itemId === win.slots[30].type && pkt.params.item.itemCount === 5,
        '★★ carryAfter 传什么都不影响：item 一律按"被点格点击前内容"算', brief(pkt.params.item));
}

// ─────────────────────────────────────────────────────────────────────
section('⑦ 服务端拒收 / 接受 两种回执都要如实反映');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);

    // 抓 action 号：回执必须按我们发出去的那个 action 对齐，迟到的旧回执不认
    const p = clickCarryConfirmed(bot, win, { slot: 1, mouseButton: 1, mode: 0, timeoutMs: 400 });
    const sent = bot._client.written.at(-1).params;
    // 先来一条别的 action 的回执（模拟迟到/别人的）
    bot._client.emit('transaction', { windowId: 0, action: sent.action - 1, accepted: false });
    // 再来我们自己的
    bot._client.emit('transaction', { windowId: 0, action: sent.action, accepted: false });
    const rej = await p;
    ok(rej.rejected === true, 'accepted=false ⇒ rejected', JSON.stringify(rej));
    ok(rej.via === 'transaction', '判决来自 transaction 包');

    const p2 = clickCarryConfirmed(bot, win, { slot: 1, mouseButton: 1, mode: 0, timeoutMs: 400 });
    const sent2 = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sent2.action, accepted: true });
    const acc = await p2;
    ok(acc.ok === true, 'accepted=true ⇒ ok', JSON.stringify(acc));
}

// ─────────────────────────────────────────────────────────────────────
section('⑦b 被拒必须**立刻回 transaction 道歉**（否则窗口从此静默吞点击）');
// ─────────────────────────────────────────────────────────────────────
// 机制（`ServerGamePacketListenerImpl.java`）：
//   :1189 一次拒收 → `setSynched(player,false)`；
//   :1169 闸门 `bw.containerId==id && bw.isSynched(player)` ⇒ 此后本窗口的点击
//         **全部被忽略、连 ack 都不回**（客户端看到的就是"后面全没反应"）；
//   :1259-1267 `handleContainerAck` 认**同 windowId + 同 uid** 且当前 `!isSynched` ⇒ 恢复。
//   mineflayer 只对它自己队列里的 action 回 ack（`inventory.js:492-502`），
//   ⇒ **我们自己直发的包没人替我们道歉**。
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('oak_log', 6);

    // ── 阴性对照（先做）：accepted=true 时**绝不能**多发 transaction ──
    const before = bot._client.written.length;
    const pOk = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 400 });
    const sentOk = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sentOk.action, accepted: true });
    const accOk = await pOk;
    const sentTx = bot._client.written.slice(before + 1).filter((w) => w.name === 'transaction');
    ok(accOk.ok === true, '阴性对照：accepted=true ⇒ ok', brief(accOk));
    ok(sentTx.length === 0, '阴性对照：被接受时不发多余的 transaction（不刷服务端）', `发了 ${sentTx.length} 条`);

    // 上面那次被接受的"拿起"会调 acceptClick 推进模型（见 ⑧），这里把模型复位再测拒收
    win.selectedItem = null;
    win.slots[10] = item('oak_log', 6);

    // ── 正例：accepted=false ⇒ 立刻回 transaction（windowId + uid 都对齐）──
    const pRej = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 400, resyncTimeoutMs: 400 });
    const sentRej = bot._client.written.at(-1).params;
    // 服务端：先回 accepted=false，再（同一 handler 里）发整窗 window_items
    bot._client.emit('transaction', { windowId: 0, action: sentRej.action, accepted: false });
    const rej = await pRej;
    // window_items 可能在道歉之后才到（真实顺序取决于网络），这里模拟"迟到一点"
    bot._client.emit('window_items', { windowId: 0, items: new Array(46).fill(null) });
    await tick();

    const ap = bot._client.written.filter((w) => w.name === 'transaction');
    ok(ap.length === 1, '★★ 被拒后**恰好发出一条** transaction 道歉', `发了 ${ap.length} 条`);
    ok(ap[0]?.params?.windowId === win.id, '道歉的 windowId 与当前窗口一致', brief(ap[0]?.params));
    ok(ap[0]?.params?.action === sentRej.action,
        '★★ 道歉的 uid 必须等于那次拒收回执的 uid（服务端只认同 uid）',
        `道歉=${ap[0]?.params?.action} 拒收=${sentRej.action}`);
    ok(rej.rejected === true, '仍然是 rejected（道歉不改变判决，如实上报）', brief(rej));
    ok(rej.apologized === true, '返回值如实带出 apologized=true', brief(rej));
    ok(rej.sentItem != null && rej.sentItem.startsWith('oak_log'),
        '返回值带上"我上报的是什么"（排障时能直接看出是不是填错）', brief(rej.sentItem));

    // ── 窗口状态：道歉后服务端会恢复同步 ⇒ 我们下一次点击能被认 ──
    const p2 = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 400 });
    const sent2 = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sent2.action, accepted: true });
    const acc2 = await p2;
    ok(acc2.ok === true, '道歉之后下一次点击仍能被 accepted（窗口没被拖死）', brief(acc2));
}

// ─────────────────────────────────────────────────────────────────────
section('⑧ 窗口模型：accepted 才推进（客户端预测），rejected 一个字节都不动');
// ─────────────────────────────────────────────────────────────────────
// ⚠ **本条在 r5 之前是反的**，而且那个"反"是个真 bug：
//   r4 断言"1.16.x 路径一次都没调 acceptClick（模型只被服务端回包驱动）"。
//   但 `ServerGamePacketListenerImpl.java:1182-1185` 在 accepted 路径上把
//   `ignoreSlotUpdateHack` 置位，`broadcastChanges()` 的逐格广播**全被挡掉**
//   ⇒ 服务端**一条槽位更新都不发**。≤1.16 协议的前提就是客户端自己预测。
//   ⇒ 模型不推进，下一击的 `item` 就从陈旧数据出发。
//   实测代价（本单 T09R5B）：2×2 合成 30/30 全 `putback_rejected`。
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('iron_ore', 48);
    const before = win.slots.map((s) => (s ? `${s.name}x${s.count}` : '-')).join('|');

    let acceptCalls = 0;
    const realAccept = win.acceptClick.bind(win);
    win.acceptClick = (a) => { acceptCalls++; return realAccept(a); };

    // ① accepted ⇒ 必须推进模型一次
    const p = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 300 });
    const sent = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sent.action, accepted: true });
    await p;
    ok(acceptCalls === 1, '★★ accepted ⇒ 恰好调一次 acceptClick（客户端预测，协议要求）', `called ${acceptCalls}`);
    const after = win.slots.map((s) => (s ? `${s.name}x${s.count}` : '-')).join('|');
    ok(before !== after, '★★ accepted 之后模型真的动了（否则下一击必然用陈旧数据）');

    // ② rejected ⇒ 模型一个字节都不动（只道歉 + 等服务端重发整窗覆写）
    acceptCalls = 0;
    const snapshot = win.slots.map((s) => (s ? `${s.name}x${s.count}` : '-')).join('|');
    const p2 = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 300, resyncTimeoutMs: 200 });
    const sent2 = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sent2.action, accepted: false });
    const rej = await p2;
    ok(rej.rejected === true, '对照：accepted=false ⇒ rejected', brief(rej));
    ok(acceptCalls === 0, '★★ rejected ⇒ 一次都不调 acceptClick（不许拿错的预测改模型）', `called ${acceptCalls}`);
    ok(win.slots.map((s) => (s ? `${s.name}x${s.count}` : '-')).join('|') === snapshot,
        '★★ rejected ⇒ 窗口模型逐字未变');
}

// ─────────────────────────────────────────────────────────────────────
section('⑨ 熔炉装料：r6 起走**两次 PICKUP**（整条路径不再出现 QUICK_MOVE）');
// ─────────────────────────────────────────────────────────────────────
// r6 之前这一节测的是"shift 一次到位"，那条夹具把 1.16.1 的规则**编错了**：
//   `AbstractContainerMenu.java:243` 的 QUICK_MOVE 返回值走
//     `for (s = quickMoveStack(slot); !s.isEmpty() && ItemStack.isSame(slot.getItem(), s); s = ...)`
//   而 `ItemStack.isSame` = `!a.isEmpty() && !b.isEmpty() ? a.sameItem(b) : false`
//   ⇒ 源格被搬空（熔炉装料的常态）时 `isSame` 恒 false ⇒ 循环体 0 次
//   ⇒ `clicked()` 停在 `:159` 初值 `ItemStack.EMPTY`
//   ⇒ 上报那一摞必被拒（r5 实跑 `furnaceLoad 0/30`，而那一击其实**已经生效**）。
// ⇒ 现在测的是 `loadIntoFurnaceSlot` 的两次 PICKUP 路径：判据规则不含 `isSame`，
//   两击的 `item` 分别由 `:253-256`（源格非空 ⇒ 整摞）与 `:159`（目标格空 ⇒ EMPTY）决定。
{
    // ══ A. 正例：矿石在槽 3（旧坏区间 27..63 够不着），两次 PICKUP 一次到位 ══
    //
    // ⚠ 夹具与真服同构的关键：1.16.1 的 accepted 路径
    //   （`ServerGamePacketListenerImpl:1182-1185`）把 `ignoreSlotUpdateHack` 置位，
    //   `AbstractContainerMenu:105-117` 的 `broadcastChanges()` 里「记 lastSlots」与「发包」
    //   是**两步**，被抑制的只是发包那一步 ⇒ **服务端一条槽位更新都不发**。
    //   所以这里 accepted 之后**只广播光标**（`broadcastCarriedItem`），
    //   一个 `set_slot` / `window_items` 都不给 —— 这才是真服的样子。
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();
    win.slots[3] = item('iron_ore', 48);
    win.slots[30] = item('coal', 8);
    const p = loadIntoFurnaceSlot(bot, { window: win, id: win.id }, { itemName: 'iron_ore', target: 'input', timeoutMs: 400 });

    // 第 1 击：左键拿起整摞
    const c1 = await nextClick(bot, () => sayCursor(bot, item('iron_ore', 48)));
    ok(!!c1 && c1.params.slot === 3 && c1.params.mouseButton === 0 && c1.params.mode === 0,
        '★★ 第 1 击：左键(mode 0)点**源格 3**（坏区间够不着的那一格）', brief(c1?.params, 120));
    ok(!!c1 && c1.params.item && c1.params.item.itemId === item('iron_ore').type && c1.params.item.itemCount === 48,
        '★★ 第 1 击 item = 源格点击前内容（48 个整摞）：PICKUP 打非空格 ⇒ `AbstractContainerMenu:253-256`',
        brief(c1?.params?.item));
    ok(!!c1 && c1.params.item && typeof c1.params.item.itemId === 'number',
        '第 1 击 itemId 是**数字** VarInt（不是物品名字符串）', `typeof=${typeof c1?.params?.item?.itemId}`);

    // 第 2 击：左键把光标上的整摞放进**空的**输入格 0（服务端只广播"光标空了"）
    const c2 = await nextClick(bot, () => sayCursor(bot, null));
    ok(!!c2 && c2.params.slot === 0 && c2.params.mouseButton === 0 && c2.params.mode === 0,
        '★★ 第 2 击：左键(mode 0)点**输入格 0**（不是 shift 点源格）', brief(c2?.params, 120));
    ok(!!c2 && c2.params.item && c2.params.item.present === false,
        '★★ 第 2 击 item 报**空**：被点格是空的 ⇒ `:159` 初值 EMPTY 从未被 `:256` 赋值',
        brief(c2?.params?.item));

    const res = await p;
    const clicks = bot._client.written.filter((w) => w.name === 'window_click');
    ok(clicks.length === 2, '★★ 恰好两击（拿起 + 放进），不多不少', `发了 ${clicks.length} 击`);
    ok(clicks.every((w) => w.params.mode === 0),
        '★★★ 每一击都是 mode 0 —— r6 起整条装料路径**不再使用 QUICK_MOVE**（钉住这一条）',
        JSON.stringify(clicks.map((w) => w.params.mode)));
    ok(res.ok === true, '正例：矿石两次 PICKUP 进输入格判成功', brief(res, 200));
    ok(res.via === 'pickup', 'via=pickup（不是 quick_move）', `got ${res.via}`);
    ok(res.moved === 48, '一次搬 48 个（整摞）', `got ${res.moved}`);
    ok(res.src === 3 && res.dest === 0, '源是槽 3、目标是槽 0（输入格）', `src=${res.src} dest=${res.dest}`);
    ok(Array.isArray(res.verdict) && res.verdict.length === 2
        && res.verdict.every((v) => v.ok === true && v.via === 'transaction'),
        '两击都拿到服务端 transaction{accepted:true}（判据是回执，不是"没抛错"）', brief(res.verdict, 120));
    // ★★ r6B：真服上服务端那一格的包**永远不来**（见本节开头的机制），
    //   所以判据必须是「两次 ack + 客户端模型预测」，而**不能**把等不到当失败
    //   （T09R6B 实跑 30/30 报 `no_server_window_truth`，而 `data get block` 证明装料其实成功了）。
    ok(res.srv && res.srv.ok === false && res.srv.timedOut === true,
        '★★ 真服同构：服务端那一格的包**等满了也没来**（timedOut）⇒ 判据退回 ack+预测，而不是报失败',
        `srv=${brief(res.srv, 100)}`);
    ok(res.srcBefore === 48 && res.srcAfter === 0,
        '源格 48→0：模型是被 acceptClick 推进的（accepted 路径服务端不发槽位更新）',
        `before=${res.srcBefore} after=${res.srcAfter}`);
    ok(res.range && res.range[0] === 3 && res.range[1] === 39,
        '用的是新区间 3–39，不是旧的坏区间 27–63', JSON.stringify(res.range));

    // ══ B. 目标格已经是同种且够量 ⇒ already（**此前从未真正走到过这条分支**）══
    // ⚠ 旧用例只往**目标格**放煤、背包里不放 ⇒ `findInPlayerRange` 先返回 -1，
    //   在 `item_not_in_player_range` 就退出了，`wantCount` 那条分支一次都没执行过
    //   （旧断言 `r7.ok === false` 因此是**假绿**）。这里两边都放，源格找得到，才真的走到。
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        w.slots[0] = item('coal', 8);      // 输入格已有 8 个煤
        w.slots[20] = item('coal', 10);    // 背包里也有煤（源格找得到）
        const r = await quickMoveIntoFurnace(b, { window: w, id: w.id }, { itemName: 'coal', target: 'input', wantCount: 5, timeoutMs: 100 });
        ok(r.ok === true && r.already === true, '目标格已够量 ⇒ {ok:true, already:true}（上层当成功）', brief(r, 150));
        ok(r.dest === 0 && r.moved === 8, 'already 也把"已有多少"报出来', `dest=${r.dest} moved=${r.moved}`);
        ok(b._client.written.length === 0, '★★ already 时**一个包都不发**（省一次点击，也省一次被拒风险）',
            `发了 ${b._client.written.length} 个包`);
    }

    // ══ C. 区间够不着 ⇒ 响亮失败（旧坏区间 27..63 结构性够不到槽 3）══
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        const r = await quickMoveIntoFurnace(b, { window: w, id: w.id }, { itemName: 'gold_ore', target: 'input', timeoutMs: 200 });
        ok(r.ok === false && r.reason === 'item_not_in_player_range',
            '区间里没有 ⇒ 响亮报 item_not_in_player_range（不再是那句读不出所以然的 INTERNAL）', brief(r, 150));
        ok(r.range && r.range[0] === 3 && r.range[1] === 39, '失败里带新区间 3–39（r3 缺的正是这个）', JSON.stringify(r.range));
        ok(b._client.written.length === 0, '找不到源格就一个包都不发（不空点）', `发了 ${b._client.written.length} 个包`);
    }

    // ══ D. 光标非空 ⇒ 拒绝（两次 PICKUP 的第 1 击会变成**交换**而不是拿起）══
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        w.slots[3] = item('iron_ore', 48);
        w.selectedItem = item('furnace', 1);   // r3 抓到的真凶：光标上残留着刚放下的熔炉
        const r = await quickMoveIntoFurnace(b, { window: w, id: w.id }, { itemName: 'iron_ore', target: 'input', timeoutMs: 100 });
        ok(r.ok === false && r.reason === 'cursor_not_empty', '光标非空 ⇒ 拒绝并报出光标上是什么', brief(r, 160));
        ok(String(r.held).startsWith('furnace'), 'held 字段带出光标内容（r3 丢的正是这个字段）', String(r.held));
        ok(b._client.written.length === 0, '光标非空时一个包都不发（不拿熔炉去和矿石换）', `发了 ${b._client.written.length} 个包`);
    }

    // ══ E. 目标格被**别的物品**占着 ⇒ dest_other_item（旧名 dest_occupied 的语义已废弃）══
    // ⚠ 为什么改名：两次 PICKUP 之下"目标格被占"分两种——
    //   · 占着**同种**物品：合法，第 2 击是合并（`:268`），返回值仍可预测（用例 B 走的就是它）；
    //   · 占着**别的**物品：第 2 击是**交换**（`:274`），会把占位的沙子塞进玩家背包、
    //     同时把矿石放进熔炉 ⇒ 看起来"装料成功"、实际顺手搬走了一件无关物品。
    //   只有第二种必须提前判掉，所以 reason 从 dest_occupied 收窄成 dest_other_item。
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        w.slots[3] = item('iron_ore', 48);
        w.slots[0] = item('sand', 3);
        const r = await quickMoveIntoFurnace(b, { window: w, id: w.id }, { itemName: 'iron_ore', target: 'input', timeoutMs: 100 });
        ok(r.ok === false && r.reason === 'dest_other_item', '目标格被别的物品占 ⇒ dest_other_item', brief(r, 150));
        ok(r.dest === 0 && String(r.got).startsWith('sand'), '报出目标格与占位的是什么', `dest=${r.dest} got=${r.got}`);
        ok(b._client.written.length === 0, '★★ 一个包都不发：点下去就是一次静默的交换（把沙子搬进背包）',
            `发了 ${b._client.written.length} 个包`);
    }

    // ══ F. 服务端真值与客户端预测**不一致**时以真值为准（替换旧的 landed_in_other_slot）══
    // ⚠⚠ **为什么不能继续断言 `landed_in_other_slot`**（逐行核过源码，不是猜的）：
    //   那条分支判的是 `r.srv?.slots?.[otherSlot]`，而 `r.srv` 是
    //   `pickupStackToSlot` 里 `waitServerWindowSlots(bot, win, [to])` 的返回值 ——
    //   `out` 只**预置/填充 `want` 里的格**（`window_ops.js:1037-1038` 与 `:1052/1056`），
    //   `want` 就是 `[to]` 一格 ⇒ `r.srv.slots[otherSlot]` **恒为 undefined** ⇒ 分支不可达。
    //   而且两次 PICKUP 的语义下服务端**没有**"把煤放进燃料格"这种结果可等：
    //   第 2 击点的就是 0 号格，服务端要么把东西放进 0（成功），要么拒收。
    //   ⇒ 真正替代它、且**可被真实构造**的保护是这一组：
    //     ① 用例 E 的 `dest_other_item` 预检：**从根上让"落错格"不可达**（目标格被别的
    //        物品占着时一个包都不发，因为那一击会变成静默的交换）；
    //     ② 下面这条：服务端真值一旦到达，**必须压过客户端预测**（与服务端不一致时如实报）。
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        w.slots[3] = item('coal', 8);
        const pp = loadIntoFurnaceSlot(b, { window: w, id: w.id }, { itemName: 'coal', target: 'input', timeoutMs: 300 });
        await nextClick(b, () => sayCursor(b, item('coal', 8)));
        await nextClick(b, () => {
            // 服务端只给了 3 个（重同步/去歧义场景）：**与"我们预测的 8 个"不一致**
            b._client.emit('set_slot', { windowId: w.id, slot: 0, item: { present: true, itemId: item('coal').type, itemCount: 3 } });
            sayCursor(b, null);
        });
        const r = await pp;
        ok(r.srv && r.srv.via === 'set_slot' && r.srv.slots?.[0]?.count === 3,
            '★★ 服务端真值被采纳（via=set_slot），而不是被客户端预测盖掉', brief(r.srv, 130));
        ok(r.moved === 3, '★★ moved 报**服务端说的 3 个**，不是模型预测的 8 个（不谎报搬够了）',
            `got ${r.moved}`);

        // 同一个"只有 3 个"的情形 + wantCount=4 ⇒ 必须响亮说不够
        const b2 = makeFakeBot();
        const w2 = makeFurnaceWindowBroken();
        w2.slots[3] = item('coal', 8);
        const pp2 = loadIntoFurnaceSlot(b2, { window: w2, id: w2.id }, { itemName: 'coal', target: 'input', wantCount: 4, timeoutMs: 300 });
        await nextClick(b2, () => sayCursor(b2, item('coal', 8)));
        await nextClick(b2, () => b2._client.emit('set_slot', {
            windowId: w2.id, slot: 0, item: { present: true, itemId: item('coal').type, itemCount: 3 },
        }));
        const r2 = await pp2;
        ok(r2.ok === false && r2.reason === 'short_transfer' && r2.got === 3 && r2.want === 4,
            '★★ 真值 3 < wantCount 4 ⇒ short_transfer（把"搬够了"说成没搬够才是灾难）', brief(r2, 150));
    }

    // ══ G. ★★ 被拒之后必须把光标上的东西**点回原格**（新加的行为，必须有测试）══
    // ⚠ 被拒不等于没发生（r5 §3.5）：第 2 击被拒时东西**还在光标上**。如果不点回去，
    //   光标就一直挂着这一摞 —— 后续任何一次点击都会变成"交换"，而且熔炉窗口会被拖死。
    //   这条回退点击**不在 `verdict` 里**（`clicks` 只收了 v1/v2），只能从包日志看出来。
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        w.slots[3] = item('iron_ore', 48);
        const pp = loadIntoFurnaceSlot(b, { window: w, id: w.id }, { itemName: 'iron_ore', target: 'input', timeoutMs: 200 });
        await nextClick(b, () => sayCursor(b, item('iron_ore', 48)));                       // 第 1 击：拿起
        await nextClick(b, () => {                                                            // 第 2 击：放进（被拒）
            const it = new Array(39).fill(null).map(() => ({ present: false }));
            it[3] = { present: true, itemId: item('iron_ore').type, itemCount: 48 };           // 拒收路径服务端重发整窗
            b._client.emit('window_items', { windowId: w.id, items: it });
        }, { accept: false });
        const back = await nextClick(b, null);                                                 // 第 3 击：点回原格
        const r = await pp;
        const hits = b._client.written.filter((x) => x.name === 'window_click');
        ok(hits.length === 3, '★★ 被拒后**多出第 3 击**（回退），总共三击', `发了 ${hits.length} 击`);
        ok(!!back && back.params.slot === 3 && back.params.mode === 0 && back.params.mouseButton === 0,
            '★★ 第 3 击点的是**源格 3**（不是目标格、也不是乱点）', brief(back?.params, 120));
        ok(!!back && back.params.item && back.params.item.present === false,
            '★★ 第 3 击 item 报**空**：源格此刻是空的 ⇒ 服务端算的也是 `:159` 初值 EMPTY（这一击才能被 accepted）',
            brief(back?.params?.item));
        ok(r.ok === false && r.reason === 'place_rejected', '如实报 place_rejected（不把失败说成成功）', brief(r, 180));
        ok(r.cursorReturned === true, '★★ cursorReturned=true：回退那一击确实拿到了 accepted 回执', brief(r, 180));
        ok(Array.isArray(r.verdict) && r.verdict.length === 2,
            'verdict 只含被测的 2 击（回退那击不混进判决数组，否则会把它算成"成功的一击"）',
            `verdict=${Array.isArray(r.verdict) ? r.verdict.length : brief(r.verdict)}`);
        ok(!w.selectedItem, '★★ 光标真的空了（东西没被留在半路）', brief(w.selectedItem));
        ok(w.slots[3] && w.slots[3].count === 48, '★★ 东西真的回到源格 3（acceptClick 推进的模型）',
            brief(w.slots[3]));
    }

    // ══ G2. 第 2 击**根本收不到回执**（静默吞点击）⇒ 同样要回退 ══
    // 机制：`ServerGamePacketListenerImpl:1189` 一次拒收就 `setSynched(false)`，
    //   `:1169` 的闸门此后本窗口的点击**连 ack 都不回** —— 客户端看到的就是"后面全没反应"。
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        w.slots[3] = item('iron_ore', 48);
        const pp = loadIntoFurnaceSlot(b, { window: w, id: w.id }, { itemName: 'iron_ore', target: 'input', timeoutMs: 80 });
        await nextClick(b, () => sayCursor(b, item('iron_ore', 48)));
        await nextClick(b, null, { accept: null });          // 故意一个包都不回
        const back = await nextClick(b, null);
        const r = await pp;
        ok(r.ok === false && r.reason === 'place_unconfirmed', '收不到回执 ⇒ place_unconfirmed（不假定成功）', brief(r, 180));
        ok(r.cursorReturned === true && b._client.written.filter((x) => x.name === 'window_click').length === 3,
            '★★ 没回执时**同样**点回原格（"没反应"绝不能被当成"没发生"）', brief(r, 180));
    }

    // ══ H. 不可熔炼物：旧的 moved_to_hotbar_not_furnace 已从实现里删掉 ══
    // 那条 reason 只在 QUICK_MOVE 下可能出现（`AbstractFurnaceMenu:118-121` 的
    // "不是可熔炼物 ⇒ 塞回玩家背包"分支，走的是服务端 `quickMoveStack`）。
    // r6 起整条路径不再有 QUICK_MOVE ⇒ 服务端**再没有机会**做那次分流，
    // 东西只会老老实实进我们点的那一格。⇒ 把这条用例换成"钉住不再使用 QUICK_MOVE"。
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        w.slots[3] = item('dirt', 5);       // 泥土不可熔炼
        const pp = loadIntoFurnaceSlot(b, { window: w, id: w.id }, { itemName: 'dirt', target: 'input', timeoutMs: 300 });
        await nextClick(b, () => sayCursor(b, item('dirt', 5)));
        await nextClick(b, () => b._client.emit('set_slot', { windowId: w.id, slot: 0, item: { present: true, itemId: item('dirt').type, itemCount: 5 } }));
        const r = await pp;
        const hits = b._client.written.filter((x) => x.name === 'window_click');
        ok(r.ok === true && r.via === 'pickup' && r.dest === 0,
            '★★ 不可熔炼物也只走两次 PICKUP、落在我点的输入格（服务端没有 quickMoveStack 分流的机会）', brief(r, 180));
        ok(hits.length === 2 && hits.every((x) => x.params.mode === 0 && (x.params.slot === 3 || x.params.slot === 0)),
            '★★ 泥土这两击也是 mode 0、只点 3 和 0（`moved_to_hotbar_not_furnace` 已被 mode 0 取代）',
            JSON.stringify(hits.map((x) => [x.params.slot, x.params.mode])));
    }

    // ══ I. `pickupStackToSlot` 自身：预检分支（与熔炉无关的闸门，直接测原语）══
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        let r = await pickupStackToSlot(b, w, { from: 5, to: 0, timeoutMs: 60 });
        ok(r.ok === false && r.reason === 'src_empty', '源格是空的 ⇒ src_empty（不点）', brief(r, 120));
        w.slots[5] = item('iron_ore', 3);
        r = await pickupStackToSlot(b, w, { from: 5, to: 0, timeoutMs: 60, expectName: 'coal' });
        ok(r.ok === false && r.reason === 'src_wrong_item' && r.want === 'coal',
            '源格是别的物品 ⇒ src_wrong_item，并报出要什么/拿到什么', brief(r, 140));
        ok(b._client.written.length === 0, '上面两条预检都一个包都不发', `发了 ${b._client.written.length} 个包`);
    }

    // ══ J. `takeOutOfFurnaceSlot`：清炉（同签名别名 quickMoveOutOfFurnace 走的就是它）══
    {
        const b = makeFakeBot();
        const w = makeFurnaceWindowBroken();
        w.slots[0] = item('iron_ingot', 5);   // 熔炉输入格有产物要搬回背包（1.16.1 叫 iron_ingot）
        const pp = takeOutOfFurnaceSlot(b, { window: w, id: w.id }, { slot: 0, expectName: 'iron_ingot', timeoutMs: 300 });
        const t1 = await nextClick(b, () => sayCursor(b, item('iron_ingot', 5)));
        ok(!!t1 && t1.params.slot === 0 && t1.params.mode === 0,
            '★ 取件第 1 击：左键(mode 0)点熔炉那一格（不 shift）', brief(t1?.params, 120));
        const t2 = await nextClick(b, () => {
            b._client.emit('set_slot', { windowId: w.id, slot: 3, item: { present: true, itemId: item('iron_ingot').type, itemCount: 5 } });
            sayCursor(b, null);
        });
        ok(!!t2 && t2.params.mode === 0 && t2.params.slot === 3, '第 2 击：放进背包区找好的空格（槽 3）', brief(t2?.params, 120));
        const r = await pp;
        ok(r.ok === true && r.slot === 0 && r.dest === 3 && r.gained === 5,
            '★ 取件判成功并报出源/目标/增量（`no_inv_delta` 兜底没被触发）', brief(r, 180));
    }
}

// ─────────────────────────────────────────────────────────────────────
section('⑩ 服务端真值通道：两条都认，超时如实说超时');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();
    // 逐格 set_slot
    const COAL = registry.itemsByName.coal.id;
    let p = waitServerWindowSlots(bot, win, [0, 1], { timeoutMs: 300 });
    bot._client.emit('set_slot', { windowId: win.id, slot: 0, item: { present: true, itemId: COAL, itemCount: 12 } });
    let r = await p;
    ok(r.ok === true && r.via === 'set_slot', '认逐格 set_slot', brief(r, 120));
    ok(r.slots[0] && r.slots[0].name === 'coal' && r.slots[0].count === 12,
        'set_slot 内容过了物品工厂（有 name/count，不是裸 notch）', JSON.stringify(r.slots[0]?.name));
    ok(r.slots[1] === null, '只报请求的格；没收到的那格是 null（不是 undefined）',
        `typeof=${typeof r.slots[1]}`);

    // 整窗 window_items（1.16.1 实际走的就是这条）
    p = waitServerWindowSlots(bot, win, [2], { timeoutMs: 300 });
    const items = new Array(39).fill(null).map(() => ({ present: false }));
    items[2] = { present: true, itemId: 265, itemCount: 3 };
    bot._client.emit('window_items', { windowId: win.id, items });
    r = await p;
    ok(r.ok === true && r.via === 'window_items', '认整窗 window_items');
    ok(r.slotCount === 39, '整窗包顺带给出槽数（区间自证的材料）', `got ${r.slotCount}`);

    // 别的窗口的包不算
    p = waitServerWindowSlots(bot, win, [0], { timeoutMs: 120 });
    bot._client.emit('window_items', { windowId: win.id + 100, items });
    r = await p;
    ok(r.ok === false && r.timedOut === true, '别的窗口的包不被当成本窗口的真值');

    // 超时
    const t0 = Date.now();
    r = await waitServerWindowSlots(bot, win, [0], { timeoutMs: 120 });
    ok(r.ok === false && r.timedOut === true, '等不到就如实判超时（超时不是"服务端说没有"）');
    ok(Date.now() - t0 >= 100, '确实等满了才返回（有界，不是立刻放弃）');
}

/**
 * 确定性驱动器：等"下一条新发出去的 window_click"，把模型改成服务端该有的样子，
 * 再回一个 accepted 的 transaction。
 *
 * ⚠ 两个坑都是本单真踩的，写在这里免得下次重犯：
 *  ① **不能用"比长度"判新包**：`craftInGridConfirmed` 的第一次发包发生在它自己
 *     同步段里（`clickCarryConfirmed` 在第一个 await 之前就 write 了），
 *     所以调用驱动器时第一包**已经写出去了**。⇒ 游标挂在 bot 上，逐条消费。
 *  ② **服务端广播的时机不能靠猜**：`waitServerWindowSlots` 的监听器是在 await 之后
 *     才挂上的，测试侧"发完包就广播"可能早于监听器挂上 ⇒ 结果被丢掉，
 *     用例假红或假绿。⇒ 结果槽这类"必须持续存在"的服务端真值用**定时重复广播**，
 *     让时序无关。
 */
/**
 * 等"下一条新发出去的 window_click"，把模型改成服务端该有的样子，再回一个 accepted 的 transaction。
 * **等不到就返回 null，不抛异常** —— 抛异常会把"被测代码提前收手"（这在变异测试里恰恰是
 * 要观察的现象）变成"测试崩了"，既丢掉后续断言、也让报告里看不出到底哪一步坏的。
 * 调用方用 `ok(cN && …)` 断言，最后再对函数的结构化 reason 断言。
 *
 * @param accept  `true/false` = 回相应判决的 transaction；
 *                **`null` = 故意一个包都不回**（模拟"服务端静默吞点击"，
 *                即 `ServerGamePacketListenerImpl:1169` 那个 `!isSynched` 闸门）。
 *
 * ⚠ r6 新增：**只消费 `window_click`**。被拒路径会多发一条 `transaction` **道歉**包
 *   （`apologizeAndResync`），它也落在同一个 `written` 数组里；不按名字过滤的话
 *   驱动器会把道歉包当成"下一击"，后面每一次断言全部错位一格。
 */
async function nextClick(bot, apply, { accept = true } = {}) {
    if (bot.__consumed == null) bot.__consumed = 0;
    for (let i = 0; i < 120; i++) {
        // ⚠ 必须让**真实时间**过去：服务端真值是 setInterval 泵出来的，
        //   只用 setImmediate 空转（微秒级）的话泵一次都不会触发，
        //   用例会假红成 `no_server_window_truth`（本单真踩过）。
        await new Promise((r) => setTimeout(r, 2));
        if (bot._client.written.length > bot.__consumed) {
            const w = bot._client.written[bot.__consumed++];
            if (w.name !== 'window_click') continue;   // 道歉的 transaction：跳过，但游标照样前进
            if (apply) apply(w);
            if (accept === null) return w;             // 故意不回执
            bot._client.emit('transaction', { windowId: w.params.windowId, action: w.params.action, accepted: accept });
            return w;
        }
    }
    return null;
}
/** 起一个"持续广播服务端真值"的泵，返回停止函数（让广播时序与监听器挂上时刻无关） */
function pump(bot, build, ms = 15) {
    const t = setInterval(() => bot._client.emit('window_items', { windowId: 0, items: build() }), ms);
    return () => clearInterval(t);
}
/**
 * 持续广播**某一格**的 `set_slot`。
 * ⚠ 为什么结果格要用这个而不是 `pump`：实跑抓包（`runs/T09R5_DBG4`）证明，window 0 上服务端
 *   在 accepted 路径**只发结果格这一格的 set_slot**（`set_slot(0, 成品)`），
 *   网格格与背包格一个字节都不发 ⇒ 结果格判据走环形缓冲读 set_slot，不等整窗包。
 */
function pumpSlot(bot, slot, build, ms = 15) {
    const t = setInterval(() => bot._client.emit('set_slot', { windowId: 0, slot, item: build() }), ms);
    return () => clearInterval(t);
}
const emptyItems46 = () => new Array(46).fill(null).map(() => ({ present: false }));

// ─────────────────────────────────────────────────────────────────────
section('⑪ 2×2 网格合成：只 shift 点结果格，网格格只 PICKUP');
// ─────────────────────────────────────────────────────────────────────
{
    // 场景：背包 8 个云杉木板（槽 10），做 2×2 的木棍（"#" / "#" ⇒ 4 根）
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('spruce_planks', 8);
    const PL = item('spruce_planks').type;
    const broadcast = (fill) => {
        const items = new Array(46).fill(null).map(() => ({ present: false }));
        for (const [i, it] of Object.entries(fill)) items[i] = { present: true, itemId: it.type, itemCount: it.count };
        bot._client.emit('window_items', { windowId: 0, items });
    };
    const p = craftInGridConfirmed(bot, win, {
        cells: [{ x: 0, y: 0, id: PL }, { x: 1, y: 0, id: PL }], gridW: 2, gridH: 2,
        resultSlot: 0, expectName: 'stick', timeoutMs: 500,
    });

    // ── 先消费 prime() 那一击：右键点一个**空**背包槽、上报"光标是空的" ──
    // 它不改变任何模型（光标仍为空），所以 apply 传 null。
    const probe = await nextClick(bot, null);
    ok(!!probe && probe.params.mouseButton === 1 && probe.params.mode === 0
       && probe.params.slot >= 9 && probe.params.slot < 45
       && probe.params.item && probe.params.item.present === false,
       'prime 探针：右键点空背包槽 + 上报空光标（用 ack 证明起点干净）', brief(probe?.params, 130));
    // 步骤 1：左键整摞拿起槽 10
    const c1 = await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('spruce_planks', 8)); });
    ok(c1 && c1.params && c1.params.slot === 10 && c1 && c1.params && c1.params.mouseButton === 0, '第 1 步：左键拿起源物品（槽 10）', brief((c1 && c1.params), 110));
    ok(c1 && c1.params && c1.params.item.itemCount === 8 && c1 && c1.params && c1.params.item.itemId === PL, '拿起：item = 那一格的东西（id 是数字 / count 8）');

    // 步骤 2：右键把 1 个放进网格格 (0,0) = 槽 1
    const c2 = await nextClick(bot, () => { win.slots[1] = item('spruce_planks', 1); sayCursor(bot, item('spruce_planks', 7)); });
    ok(c2 && c2.params && c2.params.slot === 1 && c2 && c2.params && c2.params.mouseButton === 1, '第 2 步：右键放 1 个进网格格 (0,0)=槽 1', brief((c2 && c2.params), 110));
    ok(c2 && c2.params && c2.params.item && c2.params.item.present === false,
        '★★ 放 1 个进空网格格：item 报**空**（被点格点击前是空的 ⇒ `AbstractContainerMenu:159+256` 返回初值 EMPTY）',
        `got ${brief(c2 && c2.params && c2.params.item)}`);

    // 步骤 3：第二格 (1,0) = 槽 2，同一摞不再拿起
    const c3 = await nextClick(bot, () => { win.slots[2] = item('spruce_planks', 1); sayCursor(bot, item('spruce_planks', 6)); });
    ok(c3 && c3.params && c3.params.slot === 2 && c3 && c3.params && c3.params.mouseButton === 1, '第 3 步：第二格 (1,0)=槽 2（手上已有，不再拿起）', brief((c3 && c3.params), 110));
    ok(c3 && c3.params && c3.params.item && c3.params.item.present === false,
        '★★ 放第二个：同样是空格 ⇒ item 报空', `got ${brief(c3 && c3.params && c3.params.item)}`);

    // 步骤 4：余料放回（放整摞 ⇒ 光标清空）
    const c4 = await nextClick(bot, () => { win.slots[30] = item('spruce_planks', 6); sayCursor(bot, null); });
    ok(c4 && c4.params && c4.params.mouseButton === 0 && c4 && c4.params && c4.params.mode === 0 && c4 && c4.params && c4.params.item.present === false,
        '步骤 4：余料放回背包（item 填空 = 放完整摞后光标清空）', brief((c4 && c4.params), 110));
    ok(c4 && c4.params && c4.params.slot >= 9 && c4 && c4.params && c4.params.slot < 45, '放回目标是背包区 9..45，不是网格格', `slot=${c4 && c4.params && c4.params.slot}`);

    // 服务端算出结果：槽 0 = 4 根木棍（**只发这一格的 set_slot**，与实跑抓包同构）
    win.slots[0] = item('stick', 4);
    const stopPump = pumpSlot(bot, 0, () => ({ present: true, itemId: item('stick').type, itemCount: 4 }));

    // 步骤 5：★ **左键**拿起产物（**不用 shift**）——
    //   QUICK_MOVE 在结果格上不可预测：取走产物会触发配方重算、把新物品放回同一格，
    //   服务端 `clicked()` 的 do-while 循环会再进一轮，返回值变成"最后一轮搬的那摞"。
    //   实跑证据 bench/.../runs/T09R5_DBG5：上报 stick×4、服务端算成别的 ⇒ accepted=false。
    // apply 只负责"服务端那一侧"：确保光标是空的，让 acceptClick 执行"拿起"而不是"交换"。
    // 模型怎么变交给被测代码自己的 acceptClick（夹具手工改会抢在它前面，见步骤 6 的坑）。
    const c5 = await nextClick(bot, () => { win.selectedItem = null; });
    ok(c5 && c5.params && c5.params.slot === 0 && c5 && c5.params && c5.params.mode === 0 && c5.params.mouseButton === 0,
        '取产物：**左键**点结果格（不走 QUICK_MOVE）', brief((c5 && c5.params), 110));
    ok(c5 && c5.params && c5.params.item && c5.params.item.present === true && c5.params.item.itemCount === 4,
        '★ 取产物：PICKUP 的 item = 结果格的点击前内容（4 根木棍）',
        `got ${brief(c5 && c5.params && c5.params.item)}`);

    // 步骤 6：左键把光标上的产物放进一个**空**的背包格 ⇒ item 报空
    // ⚠ apply 传 null：这一步的模型推进由被测代码自己的 `acceptClick` 做（ack accepted 之后），
    //   夹具再手工改模型反而会**抢在 acceptClick 之前**把它清掉（第一版就踩了，
    //   症状是 `result_not_landed {slot:10, got:null}`）。
    const c6 = await nextClick(bot, null);
    stopPump();
    ok(c6 && c6.params && c6.params.slot >= 9 && c6.params.slot < 45 && c6 && c6.params && c6.params.mode === 0 && c6.params.item && c6.params.item.present === false,
        '放下：目标是背包区的空格 ⇒ item 报空', brief((c6 && c6.params), 110));
    ok(!bot._client.written.some((w) => w.params.mode === 1 && w.params.slot >= 1 && w.params.slot <= 4),
        '⚠ 绝不 shift 点网格格 1..4（1.16.1 InventoryMenu.java:126-129 会把材料倒回背包、静默清空配方）');

    const r = await p;
    ok(r.ok === true, '整条 2×2 合成判成功', brief(r, 200));
    ok(r.gained === 4 && r.took === 4, '拿到 4 根木棍（服务端真值确认过结果格）', `gained=${r.gained} took=${r.took}`);
    ok(r.viaPickup === true, '取件走的是两次 PICKUP（不是 shift）', `viaPickup=${r.viaPickup}`);
}

// ─────────────────────────────────────────────────────────────────────
section('⑫ 2×2 的失败形态都要有结构化 reason（不许"差不多就行"）');
// ─────────────────────────────────────────────────────────────────────
{
    // ① 材料不在背包里
    {
        const bot = makeFakeBot();
        const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
        win.slots = new Array(46).fill(null);
        // ⚠ 顺序：`craftInGridConfirmed` 必须**先启动**，prime() 的探针才会发出去，
        //   驱动器才吃得到它。先 `nextClick` 再调用的话那一刻探针还没发（r4 遗留的 5 条红就是这个）。
        const p1 = craftInGridConfirmed(bot, win, { cells: [{ x: 0, y: 0, id: item('spruce_planks').type }], gridW: 2, gridH: 2, timeoutMs: 150 });
        await nextClick(bot, null);   // prime 探针（不改模型）
        const r = await p1;
        ok(r.ok === false && r.reason === 'missing_ingredient', '没材料 ⇒ missing_ingredient（带 id + 区间）', brief(r, 150));
    }
    // ② 网格摆好了但服务端不认（配方不匹配）⇒ 结果格空 ⇒ no_result，且把网格内容一起报出来
    {
        const bot = makeFakeBot();
        const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
        win.slots = new Array(46).fill(null);
        win.slots[10] = item('spruce_planks', 4);
        const p = craftInGridConfirmed(bot, win, {
            cells: [{ x: 0, y: 0, id: item('spruce_planks').type }], gridW: 2, gridH: 2, expectName: 'stick', timeoutMs: 300,
        });
        // ── 先消费 prime() 那一击：右键点一个**空**背包槽、上报"光标是空的" ──
        // 它不改变任何模型（光标仍为空），所以 apply 传 null。
        // ⚠ r4 遗留：这里曾被复制粘贴成**两段**、且第二段引用了块外的 `probe`（未定义），
        //   于是断言拿错变量、用例假红。**只保留一段**。
        const probe2 = await nextClick(bot, null);
        ok(!!probe2 && probe2.params.mouseButton === 1 && probe2.params.mode === 0
           && probe2.params.slot >= 9 && probe2.params.slot < 45
           && probe2.params.item && probe2.params.item.present === false,
           'prime 探针：右键点空背包槽 + 上报空（用 ack 证明起点干净）', brief(probe2?.params, 130));
        await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('spruce_planks', 4)); });
        await nextClick(bot, () => { win.slots[1] = item('spruce_planks', 1); sayCursor(bot, item('spruce_planks', 3)); });
        await nextClick(bot, () => { win.slots[9] = item('spruce_planks', 3); sayCursor(bot, null); });
        // 结果格**恒空**（配方不匹配）—— 用泵持续广播
        const stop = pump(bot, emptyItems46);
        const r = await p;
        stop();
        ok(r.ok === false, '服务端没给货 ⇒ 如实判失败', brief(r, 150));
        ok(r.reason === 'no_result' || r.reason === 'no_server_window_truth', '失败 reason 是结构化的', `got ${r.reason}`);
        ok(r.reason !== 'no_result' || typeof r.grid === 'string',
            'no_result 会把网格内容一起报出来（能看出料摆对没有）', brief(r, 150));
    }
    // ③ 取产物被服务端拒收 ⇒ take_rejected，不假装成功
    {
        const bot = makeFakeBot();
        const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
        win.slots = new Array(46).fill(null);
        win.slots[10] = item('spruce_planks', 4);
        const p = craftInGridConfirmed(bot, win, {
            cells: [{ x: 0, y: 0, id: item('spruce_planks').type }], gridW: 2, gridH: 2, expectName: 'spruce_planks', timeoutMs: 300,
        });
        // ⚠ 必须先吃掉 prime() 的探针，否则后面每一次 nextClick 都错位一格
        //   （r4 遗留：这里漏了探针，导致"取产物那一下"拿到的是放回那一下）
        await nextClick(bot, null);
        await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('spruce_planks', 4)); });
        await nextClick(bot, () => { win.slots[1] = item('spruce_planks', 1); sayCursor(bot, item('spruce_planks', 3)); });
        await nextClick(bot, () => { win.slots[9] = item('spruce_planks', 3); sayCursor(bot, null); });
        win.slots[0] = item('spruce_planks', 1);
        // 结果格只发 set_slot（与实跑抓包同构）
        const stop = pumpSlot(bot, 0, () => ({ present: true, itemId: item('spruce_planks').type, itemCount: 1 }));
        // 下一次点击（取产物）被服务端拒收
        const c = await nextClick(bot, null, { accept: false });
        stop();
        ok(!!c && c.params.slot === 0 && c.params.mode === 0, '取产物那一下确实是左键点结果格', brief(c?.params, 110));
        const r = await p;
        ok(r.ok === false && r.reason === 'take_rejected', '产物取件被拒 ⇒ take_rejected（不报"成功"）', brief(r, 170));
    }
}

// ─────────────────────────────────────────────────────────────────────
section('⑬ 网格几何闸门：放不下必须返 null（不能少放凑合）');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);

    // 2×2 放料
    // ⚠ 同 ⑫①：必须先启动 `craftInGridConfirmed`，prime() 的探针才会发出去、驱动器才吃得到
    const p2 = craftInGridConfirmed(bot, win, { cells: [{ x: 0, y: 0, id: 1 }], gridW: 2, gridH: 2, timeoutMs: 100 });
    await nextClick(bot, null);   // prime 探针（不改模型）
    const r2 = await p2;
    ok(r2.ok === false && r2.reason === 'missing_ingredient', '2×2 能放但没料 ⇒ missing_ingredient（不是 no_result）', brief(r2, 150));

    // 3×3 配方硬塞进 2×2：这里只验"几何闸门"这个纯函数（_gridCells 在 crafting_task 里）
    const { CraftingTask } = await import('./crafting_task.js');
    const t = new CraftingTask({ item: 'iron_pickaxe' });
    const big = { inShape: [[1, 1, 1], [null, 2, null], [null, 2, null]] };
    ok(t._gridCells(big, 2, 2) === null, '3×3 配方进 2×2 ⇒ null（要工作台）');
    ok(t._gridCells(big, 3, 3) !== null, '同一配方进 3×3 ⇒ 正常摊平');
    const shapeless3 = { ingredients: [1, 2, 3] };
    const c3s = t._gridCells(shapeless3, 2, 2);
    ok(c3s !== null && c3s.length === 3, '3 原料 shapeless 放得进 2×2（4 格）⇒ 摊平 3 格', JSON.stringify(c3s));
    ok(t._gridCells({ ingredients: [1, 2, 3, 4, 5] }, 2, 2) === null, '5 原料 shapeless 放不进 2×2 ⇒ null');
}
// ─────────────────────────────────────────────────────────────────────
section('⑭ _gridCells 的真实判定（订正上一条的措辞）');
// ─────────────────────────────────────────────────────────────────────
{
    const { CraftingTask } = await import('./crafting_task.js');
    const t = new CraftingTask({ item: 'x' });
    // 2×2 shapeless：木板→工作台（1.16.1 RecipeProvider.java:656 的 "##"/"##"）
    const table = { inShape: [[1, 1], [1, 1]] };
    const c = t._gridCells(table, 2, 2);
    ok(c && c.length === 4, '木板→工作台（2×2）4 格全摊平', JSON.stringify(c));
    // 木棍：1.16.1 是 "#"/"#" = 2×1，2×2 放得下
    const stick = { inShape: [[1], [1]] };
    ok(t._gridCells(stick, 2, 2).length === 2, '木板→木棍（2×1）2 格，2×2 装得下');
    // 原木→木板：shapeless 1 原料
    const planks = { ingredients: [1] };
    ok(t._gridCells(planks, 2, 2).length === 1, '原木→木板（1 原料）1 格');
    // 3×3：熔炉 "###"/"# #"/"###"
    const furnace = { inShape: [[1, 1, 1], [1, null, 1], [1, 1, 1]] };
    ok(t._gridCells(furnace, 2, 2) === null, '熔炉（3×3）⇒ 2×2 返 null');
    ok(t._gridCells(furnace, 3, 3).length === 8, '熔炉 8 格在 3×3 摊平');
    // 空洞不能被当成物品
    const withHole = { inShape: [[1, null, 1], [1, 1, 1], [1, 1, 1]] };
    ok(t._gridCells(withHole, 3, 3).every((c2) => c2.id != null && c2.id !== -1), 'null 格不进 cells');
    // id=0 是真物品 id，不能被当成"空"
    const zeroId = { inShape: [[0]] };
    ok(t._gridCells(zeroId, 2, 2).length === 1, 'id=0 是合法物品 id（不是空）');
    // 没有任何形状信息 ⇒ null（不能当成"空配方"）
    ok(t._gridCells({}, 2, 2) === null, '既无 inShape 又无 ingredients ⇒ null');
}

// ─────────────────────────────────────────────────────────────────────
section('⑮ 假 bot 与真库的字段对齐自检（G 线纪律）');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    // 真 bot 上这几个是存在的
    for (const k of ['_client', 'registry', 'version', 'supportFeature']) {
        ok(k in bot, `假 bot 有真库确实有的字段 ${k}`);
    }
    // 刻意不补的（补了就是"假 bot 比真库宽"）
    ok(!('windowSlotsRange' in bot), '假 bot 没补真库没有的字段（避免盖掉真 bug）');
    ok(!('currentWindow' in bot), '假 bot 没偷塞 currentWindow');

    // 版本口径：1.16.x 与 1.17+ 走的是不同信封
    const b16 = makeFakeBot();
    const f16 = clickFlavor(b16);
    ok(f16.actionIdUsed === true && f16.transactionPacketExists === true && f16.stateIdUsed === false,
        '1.16.1 口径：actionId + transaction，无 stateId', JSON.stringify(f16));
    const b17 = makeFakeBot({ version: '1.17.1' });
    b17.supportFeature = (f) => (f === 'stateIdUsed');
    const f17 = clickFlavor(b17);
    ok(f17.stateIdUsed === true, '1.17+ 口径：stateId');
    const pkt17 = windowClickPacket(b17, f17, { windowId: 1, slot: 2, mouseButton: 0, mode: 0, changedSlots: [], item: null, cursorItem: null });
    ok(pkt17.params.stateId === 0 && pkt17.params.cursorItem && pkt17.params.cursorItem.present === false,
        '1.17+ 信封带 stateId + cursorItem', brief(pkt17.params, 140));
}

// ─────────────────────────────────────────────────────────────────────
section('⑯ 光标模型：服务端真值与预测不一致时必须被发现（不许悄悄采信预测）');
// ─────────────────────────────────────────────────────────────────────
// 为什么补这一组（r5 的变异测试发现的**真覆盖缺口**，不是锚点漂移）：
//   变异 9「光标不跟服务端包刷新」在 r4 记为"锚点找不到"，改好锚点后它仍然
//   **0 条断言变红** —— 因为夹具里服务端发的光标包**永远和预测一致**，
//   于是"读真值"和"不读真值"走同一条分支、行为完全等价。
//   ⇒ 只有补一条"**真值与预测不一致**"的用例，这条保护才真的存在。
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('oak_log', 6);

    const cur = await makeCursorTracker(bot, win, { timeoutMs: 300 });
    // prime：右键点空槽、上报空光标（先启动再消费，探针才发得出去）
    const pPrime = cur.prime();
    await nextClick(bot, null);
    const pr = await pPrime;
    ok(pr.ok === true, 'prime 通过（起点光标被 ack 确认为空）', brief(pr, 140));
    ok(cur.empty === true, 'prime 后模型认为光标是空的', `got ${brief(cur.item)}`);

    // 正例①：拿起 6 个原木，服务端光标**与预测一致** ⇒ 不算 mismatch
    const p1 = cur.click(10, 0, 0, item('oak_log', 6));
    await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('oak_log', 6)); });
    await p1;
    ok(cur.mismatches === 0, '一致时不计 mismatch（阳性对照）', `mismatches=${cur.mismatches}`);
    ok(cur.item && cur.item.count === 6, '光标模型 = 6 个原木', brief(cur.item));

    // ★ 反例：再点一次，预测"放 1 个后剩 5"，**服务端真值却是 3** ⇒ 必须被发现
    const p2 = cur.click(1, 1, 0, item('oak_log', 5));
    await nextClick(bot, () => { win.slots[1] = item('oak_log', 1); sayCursor(bot, item('oak_log', 3)); });
    await p2;
    ok(cur.mismatches === 1,
        '★★ 预测(5)与服务端真值(3)不一致时必须被抓住并如实累加', `mismatches=${cur.mismatches}`);
    ok(cur.item && cur.item.count === 3,
        '★★ 不一致时**以服务端真值为准**（3），不采信自己的预测（5）', brief(cur.item));

    // QUICK_MOVE 不碰光标 ⇒ 服务端光标仍是 3 ⇒ 预测 = 原值 ⇒ 不算 mismatch
    const before3 = cur.mismatches;
    const p3 = cur.click(30, 0, 1, null);
    await nextClick(bot, () => { win.slots[30] = null; sayCursor(bot, item('oak_log', 3)); });
    await p3;
    ok(cur.mismatches === before3, 'QUICK_MOVE 不改光标 ⇒ 不产生 mismatch', `mismatches=${cur.mismatches}`);
    cur.stop();
}

// ─────────────────────────────────────────────────────────────────────
section('⑰ predictClickedReturn 的纯函数口径（不依赖任何 bot）');
// ─────────────────────────────────────────────────────────────────────
{
    const w = { slots: new Array(46).fill(null) };
    w.slots[10] = item('oak_log', 6);
    ok(predictClickedReturn(w, { slot: 10, mode: 0 }) === w.slots[10], 'PICKUP 非空 ⇒ 返回那一格的对象');
    ok(predictClickedReturn(w, { slot: 20, mode: 0 }) === null, 'PICKUP 空 ⇒ 返回 null（= EMPTY）');
    ok(predictClickedReturn(w, { slot: -999, mode: 0 }) === null, 'THROW(slot<0) ⇒ null');
    ok(predictClickedReturn(w, { slot: 99, mode: 0 }) === null, '越界槽 ⇒ null（不抛）');
    // ★★ r6 更正：QUICK_MOVE 的返回值**取决于源格有没有被搬空**，不是"总是那一摞"。
    //   `AbstractContainerMenu:243` 的 `ItemStack.isSame(源格, 搬动结果)` 只要有一边空就 false
    //   ⇒ 循环体 0 次 ⇒ 返回值停在 `:159` 初值 EMPTY。熔炉装料总是搬空 ⇒ 必是 EMPTY。
    ok(predictClickedReturn(w, { slot: 10, mode: 1 }) === null,
        '★★ QUICK_MOVE 源格被搬空（sourceDrained 默认 true = 常态）⇒ null（= EMPTY），**不是**那一摞');
    ok(predictClickedReturn(w, { slot: 10, mode: 1, sourceDrained: false }) === w.slots[10],
        '★★ 对照：只有 sourceDrained:false（部分搬运、源格还剩同类）⇒ 才返回那一摞');
    ok(predictClickedReturn(w, { slot: 20, mode: 1 }) === null,
        'QUICK_MOVE 点空槽：两种 sourceDrained 都一样是 null（没东西可搬）');
    ok(predictClickedReturn(w, { slot: 10, mode: 1, expectMove: false }) === null,
        'expectMove:false 优先于 sourceDrained ⇒ null（明知搬不动）');
    ok(predictClickedReturn(w, { slot: 10, mode: 1, expectMove: false, sourceDrained: false }) === null,
        'expectMove:false + sourceDrained:false 仍然是 null（闸门先判，不被覆盖）');
}

// ─────────────────────────────────────────────────────────────────────
section('⑱ 光标与客户端模型**不一致**时，"手上已有"必须按服务端真值重算');
// ─────────────────────────────────────────────────────────────────────
/**
 * ⚠ 这组是给变异测试补的**真覆盖缺口**（不是锚点漂移），补完之前那条保护根本没被验证：
 *
 *   变异 8「光标退回 `win.selectedItem`」（window_ops.js:1631）改了之后自检**仍然 176 全绿**。
 *   原因不是锚点错，是**夹具区分不出**：`window_ops.js:1231` 每次 accepted 都自己调
 *   `win.acceptClick(...)`，而 prismarine 的 `acceptClick → mouseClick` 会顺手维护
 *   `win.selectedItem`（window_ops.js:1247-1250 自己写着这件事）⇒ 离线夹具里
 *   `win.selectedItem` 与光标模型的 `cur.item` **恒等**，换成谁都一样。
 *
 *   真实差异只出现在一处：**服务端光标包与客户端预测不一致**的时候（这正是 ⑯ 的形状）。
 *   而 ⑯ 用的是"数量不一致"（5 vs 3）—— `window_ops.js:1631` 只比 `.type`，
 *   ⇒ 数量不一致照样区分不出来。**只有类型不一致才区分得开。**
 *
 *   ⇒ 本组让服务端在放完第 1 个之后说"光标是空的"（客户端模型还自称有 7 个）：
 *     正确口径（按 `cur.item` 判）⇒ 必须回源格**重新拿起**；
 *     变异体（按 `win.selectedItem` 判）⇒ 会跳过拿起，直接把"客户端以为还在手上"的那摞
 *     放进网格格 —— 真服上紧接着就是 place_rejected / 结果格算错。
 */
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('spruce_planks', 8);   // 源摞
    win.slots[11] = item('spruce_planks', 3);   // 服务端说光标空了以后，只剩这一摞可以重新拿
    const PL = item('spruce_planks').type;
    const p = craftInGridConfirmed(bot, win, {
        cells: [{ x: 0, y: 0, id: PL }, { x: 1, y: 0, id: PL }], gridW: 2, gridH: 2,
        resultSlot: 0, expectName: 'stick', timeoutMs: 600,
    });
    // ⚠⚠ 必须**立刻**挂上拒绝处理器（不是等到下面 `await p` 那行）：
    //   变异体在"第 3 击轮询"那 240ms 里就把 `p` 拒了，而 `await p` 还没执行到 ⇒
    //   Node 默认 `unhandledRejection=throw` **直接结束整个自检进程**，
    //   统计行都印不出来 ⇒ 变异测试会把"崩了"误记成"0 条红"（本轮真踩过）。
    p.catch(() => { });

    // ⚠ 整段包在 try 里：这条用例**要能区分"崩溃"与"判错"**。
    //   变异体（按 `win.selectedItem` 判）在服务端说光标空之后会一路带着 null 光标往下走，
    //   在 `window_ops.js:1643` 的 `cur.item.count` 上抛 TypeError ⇒ 不包 try 的话
    //   整个自检进程提前退出、后面一条断言都印不出来（变异测试会把"崩了"记成"0 条红"）。
    let r = null, threw = null;
    try {
        await nextClick(bot, null);   // prime 探针（先启动再消费，探针才发得出去）
        const c1 = await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('spruce_planks', 8)); });
        ok(!!c1 && c1.params.slot === 10 && c1.params.mode === 0 && c1.params.mouseButton === 0,
            '第 1 击：左键拿起源格 10', brief(c1?.params, 110));

        // 第 2 击：右键放 1 个进网格格 (0,0)=槽 1。
        // ⚠★ 服务端光标包说**光标是空的** —— 与"我们预测的还剩 7 个"不一致。
        const c2 = await nextClick(bot, () => { win.slots[1] = item('spruce_planks', 1); sayCursor(bot, null); });
        ok(!!c2 && c2.params.slot === 1 && c2.params.mouseButton === 1,
            '第 2 击：右手放第 1 个进网格格 (0,0)=槽 1', brief(c2?.params, 110));

        // ★★ 第 3 击：服务端说光标是空的 ⇒ **必须回源格重新拿起**，不能信客户端模型
        const c3 = await nextClick(bot, () => { win.slots[11] = null; sayCursor(bot, item('spruce_planks', 3)); });
        ok(!!c3 && c3.params.slot === 11 && c3.params.mode === 0 && c3.params.mouseButton === 0,
            '★★ 服务端说光标空了 ⇒ 第 3 击是**左键重新拿起源格 11**，不是把"客户端以为还在手上"的那摞直接放进网格格',
            brief(c3?.params, 120));

        const c4 = await nextClick(bot, () => { win.slots[2] = item('spruce_planks', 1); sayCursor(bot, item('spruce_planks', 2)); });
        ok(!!c4 && c4.params.slot === 2 && c4.params.mouseButton === 1,
            '第 4 击：右手放第 2 个进网格格 (1,0)=槽 2', brief(c4?.params, 110));

        const c5 = await nextClick(bot, () => { sayCursor(bot, null); });
        ok(!!c5 && c5.params.mode === 0 && c5.params.item && c5.params.item.present === false,
            '余料放回：整摞放回背包（item 填空 ⇒ 光标清空）', brief(c5?.params, 110));

        win.slots[0] = item('stick', 4);
        const stop = pumpSlot(bot, 0, () => ({ present: true, itemId: item('stick').type, itemCount: 4 }));
        await nextClick(bot, () => { win.selectedItem = null; });   // 取产物：左键点结果格
        await nextClick(bot, null);                                  // 放进一个空的背包格
        stop();
        r = await p;
    } catch (e) {
        threw = e;
    }
    // ★ 这条独立于 `r`：抛异常本身就是被测代码的缺陷（"手上已有"必须是**重算**出来的）。
    ok(!threw, '★★ 服务端说光标空的那一步之后仍能走完（不许带着空光标继续、把 `cur.item` 当成有货）',
        threw ? `抛异常：${threw.message ?? threw}` : '');
    if (r) {
        ok(r.ok === true, '服务端一路打脸客户端模型，整条 2×2 合成**仍然**判成功（不是提前收手）', brief(r, 200));
        ok(r.cursorMismatches >= 1, '并且如实记下这次光标不一致（没有悄悄采信预测）', `mismatches=${r.cursorMismatches}`);
    }
}

// ─────────────────────────────────────────────────────────────────────
section('⑲ FARM-04 0/20 回归修复：脏网格必须被清空 + 结果格真值不等单格 set_slot');
// ─────────────────────────────────────────────────────────────────────
/**
 * 这一组钉的是 **FARM-04 全量回归 0/20 的两个病根**（本地 T11A_IRON 3/3 局逐字复现）：
 *
 *   病根 A（**级联的源头**）：`craftInGridConfirmed` 原来每条失败出口都是裸
 *     `return {ok:false,…}`，而此时 2×2 网格里**可能已经摆了料**。那些料留在格子里
 *     ⇒ 下一次进来 `if (win.slots[dst] && win.slots[dst].type === id) continue`
 *     **跳过摆料** ⇒ 服务端看不到网格变化 ⇒ 不重算配方 ⇒ 结果格永远空
 *     ⇒ `no_server_window_truth`。**一次失败毁掉后面全部。**
 *     现场铁证（T11A_IRON trial_01 `probe.jsonl`）：第一次 `craft_ok oak_planks gained=4`
 *     之后背包变成 `oak_log:1, oak_planks:1, oak_planks:1, oak_sapling:2`
 *     —— **两个各只有 1 个的木板卡在网格里**，之后每一次合成都失败。
 *
 *   病根 B（验证层）：1.16.1 上**被接受的点击之后那一格的服务端 set_slot 永不到达**
 *     （`broadcastChanges` 先记 `lastSlots` 再发包 + `ignoreSlotUpdateHack` +
 *     `ServerPlayer.java:363` 每 tick 再调时已相等）⇒ "点完等那一格的 set_slot"
 *     **结构性失效**，哪怕服务端已经执行了。⇒ 结果格真值改为**多源**
 *     （window_items 全量 → 单格 set_slot → 被 ack 验证过的模型）。
 *
 * ⚠ 判别纪律：每条用例都成对 —— "该清的必须清" **和** "本来就干净的不许乱清"。
 *   只写正向断言时，什么都不做也能全绿。
 */

// ⑲-1【病根 A·正向】进来时网格是脏的 ⇒ 必须先 shift 点清空，再摆料
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[1] = item('oak_planks', 1);      // ⚠ 上一次失败留下的脏网格（现场就是 1 个）
    win.slots[2] = item('oak_planks', 1);      // ⚠ 现场是两个各 1 个
    win.slots[10] = item('oak_log', 4);        // 本次要摆的料
    const LOG = item('oak_log').type;
    const p = craftInGridConfirmed(bot, win, {
        cells: [{ x: 0, y: 0, id: LOG }], gridW: 2, gridH: 2,
        resultSlot: 0, expectName: 'oak_planks', timeoutMs: 600,
    });
    p.catch(() => { });

    const clicks = [];
    try {
        await nextClick(bot, null);            // prime 探针
        // ★ 第 1 个**摆料之前**的点击必须是在清网格：shift（mode=1）点脏格 1 与 2
        for (let i = 0; i < 2; i++) {
            const c = await nextClick(bot, () => { win.slots[i + 1] = null; });
            clicks.push(c);
        }
    } catch { /* 后面单独断言 */ }
    ok(clicks.length >= 2
        && clicks[0].params.slot === 1 && clicks[0].params.mode === 1
        && clicks[1].params.slot === 2 && clicks[1].params.mode === 1,
        '★★ 摆料之前先 shift 点清空脏网格（mode=1 直回背包，不经光标）',
        clicks.map((c) => `${c?.params?.slot}/${c?.params?.mode}`).join(' '));
    try { await p.catch(() => { }); } catch { /* 已尽力消费 */ }
}

// ⑲-2【病根 A·反向】网格本来就干净 ⇒ **不许**多发清空点击（否则凭空制造点击/被拒）
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('oak_log', 4);
    const LOG = item('oak_log').type;
    const p = craftInGridConfirmed(bot, win, {
        cells: [{ x: 0, y: 0, id: LOG }], gridW: 2, gridH: 2,
        resultSlot: 0, expectName: 'oak_planks', timeoutMs: 600,
    });
    p.catch(() => { });
    const clicks = [];
    try {
        await nextClick(bot, null);            // prime 探针
        const c1 = await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('oak_log', 4)); });
        clicks.push(c1);
    } catch { /* 下面断言 */ }
    ok(clicks.length >= 1
        && clicks[0].params.slot === 10 && clicks[0].params.mode === 0 && clicks[0].params.mouseButton === 0,
        '网格本来就干净 ⇒ 第 1 个点击直接是"拿起源格"，**没有**多余的清空点击',
        clicks.map((c) => `${c?.params?.slot}/${c?.params?.mode}`).join(' '));
    try { await p.catch(() => { }); } catch { /* 已尽力消费 */ }
}

// ⑲-3【病根 B】服务端**不发**那一格的 set_slot（accepted 路径的常态）
//        ⇒ 结果格仍必须判成功，且 `resultVia` 如实记成模型回退而不是写死 'set_slot'
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('oak_log', 4);
    const LOG = item('oak_log').type;
    const p = craftInGridConfirmed(bot, win, {
        cells: [{ x: 0, y: 0, id: LOG }], gridW: 2, gridH: 2,
        resultSlot: 0, expectName: 'oak_planks', timeoutMs: 500,
    });
    p.catch(() => { });
    let r = null, threw = null;
    try {
        await nextClick(bot, null);                                        // prime
        await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('oak_log', 4)); });
        await nextClick(bot, () => { win.slots[1] = item('oak_log', 1); sayCursor(bot, null); });
        // ⚠⚠ **服务端一个 set_slot 都不发**（1.16.1 accepted 路径的真实形态）
        //    只把结果写进客户端模型 —— 这正是 FARM-04 判成 no_server_window_truth 的那一步。
        win.slots[0] = item('oak_planks', 4);
        await nextClick(bot, () => { win.selectedItem = null; });          // 取产物（拿）
        await nextClick(bot, null);                                         // 放进空格
        r = await p;
    } catch (e) { threw = e; }
    ok(!threw, '服务端不发那一格的 set_slot 时也不抛异常', threw ? String(threw.message ?? threw) : '');
    ok(r && r.ok === true,
        '★★ 服务端不发 set_slot、只推进模型 ⇒ 仍判成功（旧口径在这里判 no_server_window_truth）',
        brief(r, 160));
    ok(r && r.resultVia === 'model_after_ack',
        '并且 `resultVia` 如实记成 ' + "'model_after_ack'" + '（不是写死 set_slot —— 那样会让退化在遥测里看不见）',
        `resultVia=${r?.resultVia}`);
    ok(r && r.preCleared && r.preCleared.length === 0,
        '干净网格进来时 preCleared 为空（没乱清）', `preCleared=${JSON.stringify(r?.preCleared)}`);
}

// ⑲-4【病根 A·出口】失败时网格**必须被还原**（`leftovers` 如实上报，不静默）
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('oak_log', 1);      // 只够摆 1 格，但配方要 2 格 ⇒ 第 2 格 missing_ingredient
    const LOG = item('oak_log').type;
    const p = craftInGridConfirmed(bot, win, {
        cells: [{ x: 0, y: 0, id: LOG }, { x: 1, y: 0, id: LOG }], gridW: 2, gridH: 2,
        resultSlot: 0, expectName: 'oak_planks', timeoutMs: 500,
    });
    p.catch(() => { });
    let r = null;
    try {
        await nextClick(bot, null);
        // 第 1 击：左键拿起槽 10 的那 1 个原木（拿完手上 1 个）
        await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('oak_log', 1)); });
        // 第 2 击：右键把手上那 1 个放进网格格 1 ⇒ **这一格已经摆好了料**
        await nextClick(bot, () => { win.slots[1] = item('oak_log', 1); sayCursor(bot, null); });
        // 第 3 格开始：手上空了、背包也空了 ⇒ `findTypeInRange` 返回 -1
        //          ⇒ `missing_ingredient` 这条 early return 触发（网格里还留着第 2 击摆的料）
        r = await p;
    } catch { /* 断言里分开看 */ }
    ok(r && r.ok === false, '料不够时判失败（不是假装成功）', brief(r, 120));
    ok(r && r.reason === 'missing_ingredient', '失败原因如实报 missing_ingredient', `reason=${r?.reason}`);
    ok(r && Array.isArray(r.leftovers),
        '★★ 失败出口带 `leftovers` 字段：网格里剩下的东西**如实上报**而不是静默丢掉',
        `leftovers=${JSON.stringify(r?.leftovers)}`);
    ok(r && win.slots[1] === null && win.slots[2] === null,
        '★★ 失败返回前网格已被还原为空（这一条就是级联 bug 的根治点）',
        `slot1=${win.slots[1] ? `${win.slots[1].name}x${win.slots[1].count}` : null} slot2=${win.slots[2] ? `${win.slots[2].name}x${win.slots[2].count}` : null}`);
}

// ⑲-5【阴性对照】结果格**真的**是空的 ⇒ 仍然必须判失败（不许因为加了模型回退就一路放行）
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('oak_log', 1);
    const LOG = item('oak_log').type;
    const p = craftInGridConfirmed(bot, win, {
        cells: [{ x: 0, y: 0, id: LOG }], gridW: 2, gridH: 2,
        resultSlot: 0, expectName: 'oak_planks', timeoutMs: 400,
    });
    p.catch(() => { });
    let r = null;
    try {
        await nextClick(bot, null);
        await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('oak_log', 1)); });
        await nextClick(bot, () => { win.slots[1] = item('oak_log', 1); sayCursor(bot, null); });
        win.slots[0] = null;    // ★ 结果格真的是空的 —— 不给模型兜底的机会
        r = await p;
    } catch { /* 断言里分开看 */ }
    ok(r && r.ok === false, '★★ 阴性对照：结果格真的是空的 ⇒ 仍然判失败（模型回退没有变成"一路放行"）',
        brief(r, 140));
    ok(r && r.reason === 'no_result',
        '失败原因如实报 no_result（不是 no_server_window_truth —— 那条表示"读不到"）',
        `reason=${r?.reason} resultVia=${r?.resultVia}`);
}

console.log(`\n${'='.repeat(60)}`);
console.log(`window_ops_selftest: ${pass} 通过 / ${fail} 失败（共 ${pass + fail}）`);
console.log('='.repeat(60));
process.exit(fail === 0 ? 0 : 1);
