// resources.js — MC-M1-TASK-01/02 资源定义表
//
// TASK-01：stone family（教材 CH1 口径：16+ cobblestone）。
// TASK-02：新增 log family（wood 接入），证明 AcquireResourceTask 资源无关；
//          同时把「搜索枯竭后能否就地向下挖」从代码假设升级为 def 驱动字段——
//          石头埋在脚下任何地方（digdownFallback=true），原木只长在地表（false，
//          挖地三尺也挖不出树，地下 digdown 对 log 是纯浪费且危险）。
//
// 语义：blocks = find 的目标方块；drops = 采集后背包里要数的物品（stone 掉 cobblestone）；
//       tool = 传统采集工具族（null = 徒手可采，equipForBlock 不会因无工具抛 NoItem）；
//       gather = 该 family 是「可野外采集的原始资源」，配方解析器允许对它直接下发
//       Acquire 子任务（log→砍树；stone→挖石）。不在任何 family 里的物品若没有配方，
//       就是 DEPENDENCY_UNSUPPORTED——这就是「只有能确定性解决的依赖才自动解决」的闸门。

export const NATURAL_LOGS = [
    'oak_log', 'spruce_log', 'birch_log', 'jungle_log',
    'acacia_log', 'cherry_log', 'dark_oak_log', 'mangrove_log',
];

// 按版本取本版本真实存在的原木 family：1.21.1 全量 8 种，1.16.1 无 cherry/mangrove 得 6 种
//（MC-M1-TASK-03 差异清单①）。本表保持超集不动——切回 1.21.1 零改动，本函数只是把
// registry 里查不到的条目裁掉，避免死条目混进改型/统计逻辑。
export function logFamilyFor(registry) {
    return NATURAL_LOGS.filter((n) => !!registry?.itemsByName?.[n]);
}

export const RESOURCES = {
    stone: {
        // 可采集方块：stone 本体 + 天然生成的 cobblestone（如地表圆石）。
        // 故意不含 andesite/diorite/granite——它们不掉圆石，CH1 合成用不了。
        blocks: ['stone', 'cobblestone'],
        drops: ['cobblestone'],   // 背包成功判据
        tool: 'pickaxe',
        gather: true,
        digdownFallback: true,    // 搜索枯竭 → sneak 就地向下挖（石头到处都是）
        digdownMinY: -40,
    },
    log: {
        blocks: NATURAL_LOGS,     // 8 种天然原木（1.21.1；不含 stripped_，那是人工产物）
        drops: NATURAL_LOGS,      // 背包判据：任意一种原木都算（树是哪砍的算谁的）
        tool: null,               // 徒手可采
        gather: true,
        digdownFallback: false,   // 原木不在地下：搜索枯竭就是 NO_RESOURCE_FOUND，不许挖地
        digdownMinY: null,
    },
    // —— MC-M1-TASK-06（BASIC-iron）新增 ——
    iron_ore: {
        blocks: ['iron_ore'],
        drops: ['iron_ore'],      // 1.16.1 铁矿石挖了掉本体（raw_iron 是 1.17+）
        tool: 'pickaxe',          // harvestTools 版本真值：stone_pickaxe 起（wooden 不行）
        gather: true,
        digdownFallback: true,    // 搜索枯竭 → 下挖（进而不分支挖矿，见 branchMine）
        digdownMinY: 16,          // 铁任务单：挖矿带 y≈16–40 的硬下界
        branchMine: true,         // 下到带后转入分支挖矿（暴露面驱动，不透视）
        fairnessExposure: true,   // 公平口径：只采「至少一面暴露在空气」的矿；遥测记录暴露面
    },
    flint: {
        blocks: ['gravel'],       // 燧石不是方块：采集对象是沙砾
        drops: ['flint'],         // 背包判据=燧石本体（原版掉率 10%，掉沙砾=没掉燧石）
        tool: null,               // 沙砾徒手可采
        gather: true,
        digdownFallback: false,   // 沙砾在地表（滩涂/河底）和洞穴里，不靠下挖找
        digdownMinY: null,
        specialFlint: true,       // 采集语义=挖沙砾→没掉燧石→把手里的沙砾放下去再挖（FlintCollectTask）
    },
};

// —— MC-M1-TASK-06：craft 型资源（BASIC-iron 根任务）——
// item 型资源不进野外采集（gather=false、无 blocks）：MISSION「obtain 1 iron_pickaxe」
// 的根任务由执行器按 def.item 路由到 CraftingTask，依赖链由 RecipeResolver 自理。
// drops 就是物品本身（TaskRuntime.finalInventory 判据复用）。
const CRAFT_RESOURCES = {
    iron_pickaxe: { item: 'iron_pickaxe' },
    bucket: { item: 'bucket' },
    flint_and_steel: { item: 'flint_and_steel' },
};

// wood 是 log 的别名（MISSION/上层用自然语言「wood」时落到同一 family）
export function resourceDef(name) {
    const def = RESOURCES[name] ?? (name === 'wood' ? RESOURCES.log : undefined);
    if (def) return def;
    const craft = CRAFT_RESOURCES[name];
    if (craft) return { item: craft.item, blocks: [], drops: [craft.item], tool: null, gather: false, digdownFallback: false, digdownMinY: null };
    throw new Error(`UNSUPPORTED_RESOURCE: ${name}`);
}

// 物品名 → 可野外采集的 family 名（配方解析器把 ingredient 缺口落到 Acquire 子任务）
export function gatherFamilyOf(itemName) {
    for (const [name, def] of Object.entries(RESOURCES)) {
        if (def.gather && def.drops.includes(itemName)) return name;
    }
    return null;
}

export function blockIds(bot, def) {
    return def.blocks.map((n) => bot.registry.blocksByName[n]).filter(Boolean).map((b) => b.id);
}
