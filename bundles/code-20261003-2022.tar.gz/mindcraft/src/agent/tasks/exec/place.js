// place.js — MC-M1-TASK-06c：放置原语（工作台 / 熔炉 / 通用方块共用一个入口）。
//
// 为什么单独立这一层（06c §1 设计会话补充的离线归因）：铁链每局约 10 次 place_fail，328 次里
// 252 次紧跟在垂直下挖之后——bot 站在 1×1 竖井底部放台子/熔炉。旧口径（crafting_task 的
// _placeOwnTable、smelt_task、flint_collect_task 各抄了一份）只有三道过滤：目标可替换、不压自己、
// 不太远；然后 `bot.placeBlock(ref, 面)` → mineflayer 内部死等 `blockUpdate:<dest>` **5s**
// （plugins/place_block.js:13 timeout:5000），失败一次就空等 5s，连烧 10 次 → place_exhausted。
//
// 三处修复（对应补充里的「据此调整做法」第 2 条）：
//   1. 候选必须**从眼睛位置能看见那个参照面**（0.04 格步进射线，忽略参照格/目标格），并且在
//      生存够得着的 4.5 格内。旧口径只看「目标格是空气」，井底那种「隔着井壁看井壁对面」的
//      候选照样发包，服务端按客户端给的位置+面判重（1.16.1 block_place 带 location/direction，
//      服务端**不**重新做射线），于是静默拒收。
//   2. 目标格所在**区块小节必须真收到过**（`sectionMask` 位，TASK-05 立的规矩：收到 update_light
//      会先造一个全空气的空列，拿 getColumn() 非空当「区块到了」是错的）。空列里的「空气」是
//      幻影，照它去放，服务端那边是实心 → 又是静默拒收。
//   3. 竖井底部一个合格候选都没有时：**先在脚部高度挖开一格井壁当壁龛**，再把方块放进壁龛
//      （参照面用壁龛下方那块实心）。挖是能验证的动作（挖完 blockAt 变空气即服务端同意），
//      放进去之后这个壁龛会被反复复用，摊薄成本≈0。
//   + 放完不再空等 5s 事件：短轮询 `blockAt`（默认 1s）确认，没成就把这格记进 badDest 换下一个。
//
// 验收口径见任务单 P1：竖井场景每格成功率 ≥98%、失败中位 ≤1/30。

import { navTo as navToCtx } from './nav.js';
import { Vec3 } from 'vec3';

const LIQUIDS = new Set(['water', 'lava', 'flowing_water', 'flowing_lava']);

const REPLACEABLE = new Set([
    'air', 'cave_air', 'void_air', 'water', 'lava', 'flowing_water', 'flowing_lava',
    'grass', 'tall_grass', 'fern', 'snow', 'dead_bush', 'vine', 'glow_lichen', 'seagrass',
]);
const FACES = [
    { n: 'up', v: [0, 1, 0] }, { n: 'down', v: [0, -1, 0] },
    { n: 'north', v: [0, 0, -1] }, { n: 'south', v: [0, 0, 1] },
    { n: 'west', v: [-1, 0, 0] }, { n: 'east', v: [1, 0, 0] },
];
const EYE_H = 1.62;          // 生存眼高
const PLAYER_W = 0.3;        // 玩家碰撞箱半宽
const PLAYER_H = 1.8;
const DEFAULT_REACH = 4.5;   // 生存交互距离（服务端只卡 8 格，卡太松没用）
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const posKey = (p) => `${p.x},${p.y},${p.z}`;
/** bot.blockAt 只吃 Vec3（prismarine-world world.js:229 `block.position = pos.floored()`）。
 *  传普通对象会抛 "pos.floored is not a function"——MP_FX1 踩过，整个 fixed impl 全程 impl_threw。 */
const V = (x, y, z) => new Vec3(x, y, z);
const blockAt = (bot, p) => bot.blockAt(p instanceof Vec3 ? p : V(p.x, p.y, p.z));

function withTimeout(promise, ms, label) {
    return new Promise((resolve, reject) => {
        const t = setTimeout(() => reject(new Error(label)), ms);
        promise.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); });
    });
}

export const isSolidBlock = (b) => !!b && b.boundingBox === 'block' && !LIQUIDS.has(b.name);
export const isReplaceable = (b) => !b || REPLACEABLE.has(b.name);

/** 眼睛位置 */
export function eyeOf(bot) {
    const p = bot.entity.position;
    return { x: p.x, y: p.y + EYE_H, z: p.z };
}

/** 目标格所在小节是否真收到过区块数据（防 update_light 造的空列幻影空气；TASK-05 §3） */
export function sectionTrusted(bot, x, y, z) {
    let col = null;
    try { col = bot.world.getColumn(x >> 4, z >> 4); } catch { return false; }
    if (!col) return false;
    const mask = col.sectionMask;
    if (typeof mask !== 'number') return true;   // 拿不到就当可信（别因为读不到就全拒）
    return (mask & (1 << ((y >> 4) & 0x1f))) !== 0;
}

/** 目标格的碰撞箱是否与 bot 自己（或别的实体）相交——服务端会静默拒收 */
export function blockedByEntity(bot, dest) {
    const bx0 = dest.x, bx1 = dest.x + 1, by0 = dest.y, by1 = dest.y + 1, bz0 = dest.z, bz1 = dest.z + 1;
    const p = bot.entity.position;
    if (bx1 > p.x - PLAYER_W && bx0 < p.x + PLAYER_W && by1 > p.y && by0 < p.y + PLAYER_H && bz1 > p.z - PLAYER_W && bz0 < p.z + PLAYER_W) {
        return 'self_bbox';
    }
    for (const e of Object.values(bot.entities)) {
        if (!e || e === bot.entity || e.position == null) continue;
        if (e.name === 'item' || e.name === 'experience_orb') continue;  // ItemEntity.canBeCollidedWith=false
        if (e.position == null || e.position.distanceTo(p) > 6) continue;
        const w = (e.width ?? 0.6) / 2, h = e.height ?? 1.8;
        if (bx1 > e.position.x - w && bx0 < e.position.x + w && by1 > e.position.y && by0 < e.position.y + h
            && bz1 > e.position.z - w && bz0 < e.position.z + w) return `entity:${e.name}`;
    }
    return null;
}

/** 参照面（ref 与 dest 之间那层面）上离眼睛最近的那个点——服务端的射线/朝向都指着它 */
function facePoint(ref, v, toward) {
    const [vx, vy, vz] = v;
    if (vy === 1) return { x: clamp(toward.x, ref.x + 0.05, ref.x + 0.95), y: ref.y + 1, z: clamp(toward.z, ref.z + 0.05, ref.z + 0.95) };
    if (vy === -1) return { x: clamp(toward.x, ref.x + 0.05, ref.x + 0.95), y: ref.y, z: clamp(toward.z, ref.z + 0.05, ref.z + 0.95) };
    if (vx === 1) return { x: ref.x + 1, y: clamp(toward.y, ref.y + 0.05, ref.y + 0.95), z: clamp(toward.z, ref.z + 0.05, ref.z + 0.95) };
    if (vx === -1) return { x: ref.x, y: clamp(toward.y, ref.y + 0.05, ref.y + 0.95), z: clamp(toward.z, ref.z + 0.05, ref.z + 0.95) };
    if (vz === 1) return { x: clamp(toward.x, ref.x + 0.05, ref.x + 0.95), y: clamp(toward.y, ref.y + 0.05, ref.y + 0.95), z: ref.z + 1 };
    return { x: clamp(toward.x, ref.x + 0.05, ref.x + 0.95), y: clamp(toward.y, ref.y + 0.05, ref.y + 0.95), z: ref.z };
}
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

/**
 * 参照面从眼睛位置能不能看见（0.04 格步进；忽略参照格与目标格本身）。
 * 这是 06c 新增的关键过滤：旧口径没有它，井底会挑中「隔着井壁」的候选，服务端静默拒收。
 */
export function faceVisible(bot, refPos, v, destPos) {
    const eye = eyeOf(bot);
    const P = facePoint(refPos, v, eye);
    const dx = P.x - eye.x, dy = P.y - eye.y, dz = P.z - eye.z;
    const dist = Math.hypot(dx, dy, dz);
    if (dist > DEFAULT_REACH + 0.001) return { ok: false, why: 'too_far', dist, P };
    if (dist < 0.05) return { ok: false, why: 'degenerate', dist, P };
    const steps = Math.ceil(dist / 0.04);
    const skip = new Set([posKey(refPos), posKey(destPos)]);
    for (let i = 1; i < steps; i++) {
        const t = i / steps;
        const x = Math.floor(eye.x + dx * t), y = Math.floor(eye.y + dy * t), z = Math.floor(eye.z + dz * t);
        const k = `${x},${y},${z}`;
        if (skip.has(k)) continue;
        const b = blockAt(bot, { x, y, z });
        if (isSolidBlock(b)) return { ok: false, why: 'occluded', at: [x, y, z], dist, P };
    }
    return { ok: true, dist, P };
}

/** 扫描候选：每个合格候选 = 目标空气 + 不压实体 + 实心参照面 + 参照面可见 + 够得着 + 小节可信 */
export function scanCandidates(bot, { dy = [-1, 0, 1, 2], r = 2, badDests = new Set(), stats = null } = {}) {
    const feet = { x: Math.floor(bot.entity.position.x), y: Math.floor(bot.entity.position.y), z: Math.floor(bot.entity.position.z) };
    const bump = (k) => { if (stats) stats[k] = (stats[k] ?? 0) + 1; };
    const out = [];
    for (const d of dy) {
        for (let dx = -r; dx <= r; dx++) {
            for (let dz = -r; dz <= r; dz++) {
                const refPos = { x: feet.x + dx, y: feet.y + d, z: feet.z + dz };
                const ref = blockAt(bot, refPos);
                if (!isSolidBlock(ref)) { bump('ref_not_solid'); continue; }
                for (const f of FACES) {
                    const dest = { x: refPos.x + f.v[0], y: refPos.y + f.v[1], z: refPos.z + f.v[2] };
                    if (badDests.has(posKey(dest))) { bump('bad_dest'); continue; }
                    if (!isReplaceable(blockAt(bot, dest))) { bump('dest_not_replaceable'); continue; }
                    if (!sectionTrusted(bot, dest.x, dest.y, dest.z)) { bump('untrusted_section'); continue; }
                    const ent = blockedByEntity(bot, dest);
                    if (ent) { bump(ent.startsWith('self') ? 'self_bbox' : 'entity'); continue; }
                    const vis = faceVisible(bot, refPos, f.v, dest);
                    if (!vis.ok) { bump(vis.why); continue; }
                    out.push({
                        refPos, refBlock: ref, face: f.v, faceName: f.n, dest, dist: vis.dist, P: vis.P,
                        // 排序偏好：脚边/脚下优先、头顶太高的往后排——放完还得能走到跟前用
                        // （工作台放太高的话 _findTable 虽然够得着，但真局里操作别扭）。
                        order: vis.dist + (d < 0 ? 0.6 : 0) + (dx === 0 && dz === 0 ? 1.5 : 0)
                            + (dest.y >= feet.y + 2 ? 0.8 : 0),
                    });
                }
            }
        }
    }
    out.sort((a, b) => a.order - b.order);
    return out;
}

/** 手持校验 + 一次重试（SEED-02 移交 bug 的核心补丁：equip 的窗口点击可能被静默丢弃） */
export async function ensureInHand(bot, item, trace = {}) {
    for (let i = 0; i < 2; i++) {
        if (bot.heldItem?.name === item) return true;
        const it = bot.inventory.items().find((x) => x.name === item);
        if (!it) { trace.holdNoItem = (trace.holdNoItem ?? 0) + 1; return false; }
        try { await withTimeout(bot.equip(it, 'hand'), 5000, 'equip_timeout'); } catch { trace.holdEquipFail = (trace.holdEquipFail ?? 0) + 1; }
        await sleep(300);
    }
    trace.holdMismatch = bot.heldItem?.name ?? null;
    return bot.heldItem?.name === item;
}

/** 发一次放置，然后短轮询 blockAt 确认（不再空等 5s 的 blockUpdate 事件） */
async function placeAndConfirm(bot, cand, item, confirmMs, trace) {
    const t0 = Date.now();
    let settled = false;
    // 不 await bot.placeBlock：它内部死等 blockUpdate 5s；我们自己用方块状态判成败。
    Promise.resolve(bot.placeBlock(cand.refBlock, { x: cand.face[0], y: cand.face[1], z: cand.face[2] }))
        .then(() => { settled = true; })
        .catch((e) => { trace.lastError = String(e && e.message ? e.message : e).slice(0, 120); settled = true; });
    const step = 80;
    for (let t = 0; t <= confirmMs; t += step) {
        const b = blockAt(bot, cand.dest);
        if (b && b.name === item) {
            return { ok: true, ms: Date.now() - t0, waitedMs: t };
        }
        if (settled && t >= 200) break;   // mineflayer 立刻报错（手持没了之类）就不必等满
        await sleep(step);
    }
    const after = blockAt(bot, cand.dest);
    return { ok: false, ms: Date.now() - t0, settled, after: after?.name ?? null };
}

/**
 * 在脚部高度挖开一格井壁当壁龛（06c 修法 3）。挖完这格就是服务端认可的真空气，
 * 于是「参照面 = 壁龛下方那块实心顶面」的放置立刻可判可见。
 * @returns {Promise<{ok:boolean, pos?:object, ms?:number, why?:string}>}
 */
export async function digNiche(bot, { telemetry, digTimeoutMs = 9000 } = {}) {
    const feet = { x: Math.floor(bot.entity.position.x), y: Math.floor(bot.entity.position.y), z: Math.floor(bot.entity.position.z) };
    // 优先脚下高度（dy=0）的四面井壁，其次头顶一格（dy=+1）；不挖脚下那一格（会掉下去）
    const order = [
        [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1],
        [1, 1, 0], [-1, 1, 0], [0, 1, 1], [0, 1, -1],
    ];
    for (const [dx, dy, dz] of order) {
        const pos = { x: feet.x + dx, y: feet.y + dy, z: feet.z + dz };
        const b = blockAt(bot, pos);
        if (!isSolidBlock(b)) continue;
        if (!sectionTrusted(bot, pos.x, pos.y, pos.z)) continue;
        // 壁龛正下方/正上方必须有支撑面可当参照面（下方那块最好挖不到）
        const below = blockAt(bot, { x: pos.x, y: pos.y - 1, z: pos.z });
        const t0 = Date.now();
        try { await withTimeout(bot.dig(b), digTimeoutMs, 'niche_dig_timeout'); }
        catch (e) {
            telemetry?.('niche_dig_fail', { pos: [pos.x, pos.y, pos.z], error: String(e && e.message ? e.message : e).slice(0, 80) });
            continue;
        }
        const now = blockAt(bot, pos);
        if (!isReplaceable(now)) continue;   // 服务端没真挖开（幻影），换一格
        const ms = Date.now() - t0;
        telemetry?.('niche_dug', { pos: [pos.x, pos.y, pos.z], ms, below: below?.name ?? null });
        return { ok: true, pos, ms };
    }
    telemetry?.('niche_dig_fail', { pos: null, why: 'no_diggable_wall' });
    return { ok: false, why: 'no_diggable_wall' };
}

/**
 * 放一个方块。成功返回放置后的 block，失败返回 null（reason/detail 里有归因）。
 * @param {*} bot
 * @param {string} item 方块名（crafting_table / furnace / cobblestone …）
 * @param {{telemetry?:Function, maxTries?:number, rounds?:number, allowNiche?:boolean,
 *          confirmMs?:number, moveIfStuck?:boolean, ctx?:object, GoalNear?:any, label?:string}} [opts]
 */
export async function placeItem(bot, item, opts = {}) {
    const {
        telemetry, maxTries = 8, rounds = 2, allowNiche = true,
        confirmMs = 1000, moveIfStuck = true, ctx = null, GoalNear, label = item,
    } = opts;
    const navTo = ctx ? navToCtx : null;
    const t0 = Date.now();
    const trace = { rejected: {}, tried: 0, niche: null, rounds: 0, holdRetry: 0, moved: 0, attempts: [] };
    const badDests = new Set();
    if (!(await ensureInHand(bot, item, trace))) {
        return { ok: false, reason: 'hold_fail', tried: 0, detail: trace };
    }

    for (let round = 0; round < rounds; round++) {
        trace.rounds++;
        if (round > 0) {
            // 候选一个都没有且有地方挪（头顶两格是空的）→ 挪 1–2 格再扫；井底挪不动就跳过
            const head = blockAt(bot, { x: Math.floor(bot.entity.position.x), y: Math.floor(bot.entity.position.y) + 2, z: Math.floor(bot.entity.position.z) });
            if (moveIfStuck && navTo && GoalNear && isReplaceable(head)) {
                const ang = Math.random() * Math.PI * 2;
                const from = bot.entity.position.floored();
                const to = { x: Math.round(from.x + Math.cos(ang) * 2), y: from.y, z: Math.round(from.z + Math.sin(ang) * 2) };
                try { await navTo(ctx, new GoalNear(to.x, to.y, to.z, 1), { timeoutMs: 8000, label: 'place_walk' }); } catch { /* 挪不动就算了 */ }
                await sleep(250);
                trace.moved++;
            }
        }
        const cands = scanCandidates(bot, { badDests, stats: trace.rejected });
        for (const cand of cands) {
            if (trace.tried >= maxTries) break;
            trace.tried++;
            // 每发一次之前复核一次手持（06b 的 equip 脱耦会连烧）
            if (!(await ensureInHand(bot, item, trace))) {
                return { ok: false, reason: 'hold_fail', tried: trace.tried, detail: { ...trace, dest: [cand.dest.x, cand.dest.y, cand.dest.z] } };
            }
            trace.holdRetry++;
            const r = await placeAndConfirm(bot, cand, item, confirmMs, trace);
            trace.attempts.push({ dest: [cand.dest.x, cand.dest.y, cand.dest.z], face: cand.faceName, ok: r.ok, ms: r.ms });
            if (r.ok) {
                const placed = blockAt(bot, cand.dest);
                telemetry?.('place_ok', { pos: [cand.dest.x, cand.dest.y, cand.dest.z], face: cand.faceName, dist: +cand.dist.toFixed(2), tried: trace.tried, ms: r.ms, item, label });
                return { ok: true, dest: cand.dest, ref: cand.refPos, refName: cand.refBlock.name, face: cand.faceName, block: placed, tried: trace.tried, detail: { ...trace, ms: Date.now() - t0 } };
            }
            badDests.add(posKey(cand.dest));
            telemetry?.('place_fail', {
                pos: [cand.dest.x, cand.dest.y, cand.dest.z], ref: [cand.refPos.x, cand.refPos.y, cand.refPos.z],
                refName: cand.refBlock.name, face: cand.faceName, dist: +cand.dist.toFixed(2),
                after: r.after, ms: r.ms, item, label, why: r.after && r.after !== 'air' ? 'server_has_block' : 'no_block_appeared',
            });
        }
        if (trace.tried >= maxTries) break;
        // 一个合格候选都没有（竖井底部的典型形态）→ 挖一格壁龛再试
        if (allowNiche && !trace.niche) {
            const n = await digNiche(bot, { telemetry: (e, p) => telemetry?.(e, { ...p, item, label }) });
            trace.niche = n.ok ? { pos: [n.pos.x, n.pos.y, n.pos.z], ms: n.ms } : { ok: false, why: n.why };
            if (n.ok) continue;
        }
    }
    const reason = trace.tried === 0
        ? (trace.niche ? 'no_candidate_after_niche' : 'no_candidate')
        : 'place_fail';
    telemetry?.('place_exhausted', { item, label, tried: trace.tried, rejected: trace.rejected, niche: trace.niche });
    return { ok: false, reason, tried: trace.tried, detail: { ...trace, ms: Date.now() - t0 } };
}
