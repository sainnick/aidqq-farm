// find_resource_task.js — MC-M1-TASK-01 Task: FindResource
//
// 正式吸收 REUSE SPIKE 已验证的搜索机制（experiments/exec-reuse-spike/spike_bot.cjs searchPhase/
// relocatePhase 产品化；思想来源见任务书 §4）：
//   - chunk/blob 扩展搜索：expanding radius 32→64→128（AltoClef SearchChunksExploreTask 思想，MIT）
//   - wander fallback：扫不到就短距离游走换观测点再扫
//   - 已搜索区域记账：同一 bucket 从同一半径重复扫过就跳过，防原地刷
//   - blacklist / recently failed positions：ctx.run.blacklist 全 run 共享
//   - 搜索失败后的换区：relocate 64-96 格 GoalXZ，清记账重扫
//   - 本地纵向直检（任务书新增要求）：脚下/邻近纵向有 stone 直接返回本地目标，
//     禁止「眼前就有石头却开始远征」
//
// 对象内候选队列：一次扫描的候选分次消费，Acquire 重入搜索时不重扫（canStart→tick 即出队）。

import { ExecTask, FailReason, sleep, posKey } from './task.js';
import { resourceDef, blockIds } from './resources.js';
import { navTo, stopNav } from './nav.js';
import { digWithVerify } from './collect_resource_task.js';   // 阶梯上挖复用同一挖-验口径（MC-M1-TASK-06d P2-1）
import pf from 'mineflayer-pathfinder';
import { Vec3 } from 'vec3';

const bucketOf = (pos) => `${Math.floor(pos.x / 32)},${Math.floor(pos.z / 32)}`;
const DIRS4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];

export class FindResourceTask extends ExecTask {
    constructor(opts = {}) {
        super('FindResourceTask', { timeoutMs: opts.timeoutMs ?? 240000 });
        this.resource = opts.resource ?? 'stone';
        this.scanRadii = opts.scanRadii ?? [32, 64, 128];
        this.localRadius = opts.localRadius ?? 12;
        this.maxWanders = opts.maxWanders ?? 3;
        this.maxRelocates = opts.maxRelocates ?? 2;
        this.relocateRange = opts.relocateRange ?? [64, 96];
        this.wanderRange = opts.wanderRange ?? [16, 32];
        this.navTimeoutMs = opts.navTimeoutMs ?? 60000;
        // 空扫描早退：连续 N 次 wander 后候选仍为 0 → 直接 FAIL（dev10-t3：无裸露石的出生点
        // 烧满 wander+relocate 才轮到父任务的 digdown，挖下去明明更快）。
        // MC-M1-TASK-04 修复①：digdownFallback 资源（石类）由 Acquire 传 0——扫描半径内没有
        // 可达裸露候选时直接转 digdown，不先游走；无兜底资源（原木）保持满预算换区。
        this.emptyExitAfterWanders = opts.emptyExitAfterWanders ?? 3;
        this.roundCandidates = 0;
        this._tierFound = 0;       // 本扫描轮（32/64/128 一整轮）累计候选数
        this._lastTierFound = 0;   // 上一整轮的候选数（0 = 最近一轮全空/全被拉黑）
        this.candidateQueue = [];      // [{pos, dist}] 最近优先
        this.scannedAreas = new Map(); // bucket → 已扫过的最大半径
        this.phase = 'idle';
        this.scanIdx = 0;
        this.wanderCount = 0;
        this.relocatesUsed = 0;
        this.candidatesSeen = 0;
        this._skipPhase = false;       // soft stuck 恢复标记：本阶段放弃、推进下一阶段
        this._forcedExplore = false;   // forceExplore 标志（穿越 restart，喂给 onRestart）
        this._navGoalPos = null;       // 当前导航目标点（进度签名用）
        // MC-M1-TASK-06d P2-1：地下找原木。原木没有 digdown 兜底，而 06c P2b t03 的失败链是
        //   bot 在 y44 洞里、候选原木全在 y56–77（头顶 12–33 格）→ `p.y-feet.y<=4` 过滤全空 →
        //   退化分支把够不到的树干丢给 Collect → 20 次 collect_nav 25s 超时 → NO_PROGRESS_ABORT。
        // 对策（任务单指定的修法）：**人在地下、候选全在头顶时先回到地面再找**，不在地下空转。
        // 预算按「要爬多高」估：y41 起步、树在 y69 → 要爬 ~25 格，实测 1 格 ~2.5s（挖+走），
        // 90s 只够爬三分之一（P2SMOKE3 42s 爬了 6 格）。给 180s，并靠上面的「够得着」判据提前收。
        this.surfaceBudgetMs = opts.surfaceBudgetMs ?? 180000;
        this.surfaceGainMin = opts.surfaceGainMin ?? 6;      // 上升这么多格算「出去了」
        // walkout 只试 1 次、每次 12s：它是「运气好就省事」的路子（沿原路走回挖上来的阶梯），
        // 走不通（死胡同/竖井）就是纯烧预算。**主力是 digup 阶梯上挖**，1 tick 1 格、稳定可预期。
        this.surfaceWalkTries = opts.surfaceWalkTries ?? 1;
        this.surfaceYMax = opts.surfaceYMax ?? 55;           // 高于此高度认为本就在地表附近，不触发
        this.surfaceMinRock = opts.surfaceMinRock ?? 10;    // 头顶以上实心块少于此 = 已经在露天，不触发
        this._surfaceDone = false;   // 本轮搜索是否已尝试过出地表（每轮只花一次预算）
        this._surfacePending = [];   // 出不去时的兜底候选（= 退化到今天的行为，不倒退）
        this._surfaceState = null;
        this._surfaceFromY = 0;
        this._surfaceDeadline = 0;
        this._surfaceWalkTriesUsed = 0;
        this._surfaceSteps = 0;
    }

    onRestart() {
        // 重入搜索：round 级状态清零；候选队列/区域记账保留（没扫过的区域仍是有效知识）
        this.phase = 'idle';
        if (this._forcedExplore) {
            // forceExplore 标志要穿越 restart（restart 由 Acquire 重入时调用）：
            // 队列已清、直接跳到 wander（scan 各桶已被记账，会自然走到 wander/relocate）
            this._forcedExplore = false;
            this.scanIdx = this.scanRadii.length;
        } else {
            this.scanIdx = 0;
        }
        this.wanderCount = 0;
        this.relocatesUsed = 0;
        this._skipPhase = false;
        this.roundCandidates = 0;
        this._tierFound = 0;
        this._lastTierFound = 0;
        this._surfaceDone = false;   // 新一轮搜索重新给一次出地表预算
        this._surfaceState = null;
        this._surfacePending = [];
    }

    /**
     * 强制换观测点（Acquire 采集连败时调用）：清空候选队列（里面是反复采不到的死目标）
     * 并让下一次重入直接进 wander→relocate 流程。dev8 教训：隔水望林时队列只会反复喂出
     * 够不到的候选，靠 dry 轮数烧完就 NO_PROGRESS，永远轮不到 wander/relocate。
     */
    forceExplore() {
        this.candidateQueue = [];
        this._forcedExplore = true;
    }

    canStart(ctx) {
        return !!ctx.bot?.entity?.position;
    }

    progressSignature(ctx) {
        // 导航中的目标距离计入签名：接近 wander/relocate 目标点 = 搜索在推进
        let dist = 0;
        if (this._navGoalPos && ctx.bot?.entity?.position) {
            dist = Math.round(ctx.bot.entity.position.distanceTo(this._navGoalPos));
        }
        return `${this.phase}|q${this.candidateQueue.length}|r${this.scanIdx}|w${this.wanderCount}|m${this.relocatesUsed}|s${this._surfaceSteps}|d${dist}`;
    }

    getProgress(ctx) {
        return {
            phase: this.phase,
            queued: this.candidateQueue.length,
            radiusTier: this.scanIdx,
            radius: this.scanIdx < this.scanRadii.length ? this.scanRadii[this.scanIdx] : null,
            wanders: this.wanderCount,
            relocates: this.relocatesUsed,
            candidatesSeen: this.candidatesSeen,
        };
    }

    // soft stuck：放弃当前阶段（多半是导航卡住），推进到下一阶段
    async onStuck(kind, ctx) {
        if (kind !== 'soft') return;
        stopNav(ctx.bot);
        this._skipPhase = true;
        ctx.run.counters.phaseMs.recover += 0;
    }

    async tick(ctx) {
        const bot = ctx.bot;
        const def = resourceDef(this.resource);
        const t0 = Date.now();
        if (this._skipPhase) { this._skipPhase = false; this._advancePhase(ctx, 'soft_stuck_skip'); return; }

        switch (this.phase) {
            case 'idle': {
                // 出队时跳过黑名单成员（M3B1-10 教训：nav 失败拉黑扩围后，队列里同 blob
                // 的死候选若不跳过，会逐个烧 25s 导航超时）
                while (this.candidateQueue.length) {
                    const c = this.candidateQueue.shift();
                    if (!ctx.run.blacklist.has(posKey(c.pos))) {
                        this._succeed({ target: c.pos, source: 'queue' });
                        return;
                    }
                }
                this.phase = 'local';
                return;
            }
            case 'local': {
                // 纵向直检：脚下 1..6 格有 stone 系 → 本地目标 + vertical 标记。
                // 埋着的石头够不着（reach 4.5 从眼睛算），正确的本地动作是 digdown 而非远征，
                // Acquire 见 vertical=true 直接进 digdown 阶段。
                const vDepth = this._localVertical(ctx, def);
                if (vDepth >= 0) {
                    this._succeed({ target: bot.entity.position.floored(), source: 'local_vertical', vertical: true, depth: vDepth });
                    return;
                }
                const target = this._localNear(ctx, def);
                if (target) {
                    this._succeed({ target, source: 'local_near' });
                    return;
                }
                this.phase = 'scan';
                this.scanIdx = 0;
                return;
            }
            case 'scan': {
                if (this.scanIdx >= this.scanRadii.length) {
                    // 一整轮（32/64/128）扫完：记录本轮候选总量，进入 wander。
                    // MC-M1-TASK-04 根因修复：这里原来写 `this.wanderCount = 0`——每次
                    // 扫描轮收尾都把 wanderCount 清零，emptyExitAfterWanders 和 maxWanders
                    // 永远达不到（M3B1-08 连续 17 次 wander n 恒为 1、150s 烧到超时；B2R5
                    // 的「0 换区」同根因）。空扫描早退与 wander→relocate 阶梯由此恢复工作。
                    this._lastTierFound = this._tierFound;
                    this._tierFound = 0;
                    this.phase = 'wander';
                    return;
                }
                const r = this.scanRadii[this.scanIdx];
                const bucket = bucketOf(bot.entity.position);
                const scanned = this.scannedAreas.get(bucket) ?? 0;
                if (scanned >= r) { this.scanIdx++; return; } // 记账：这里已经扫过这么远
                const found = this._scanRadius(ctx, def, r);
                this.scannedAreas.set(bucket, Math.max(scanned, r));
                ctx.run.counters.searches++;
                ctx.run.counters.maxSearchRadius = Math.max(ctx.run.counters.maxSearchRadius, r);
                this.roundCandidates += found.length;
                this._tierFound += found.length;
                if (found.length) {
                    // MC-M1-TASK-06d P2-1：地下 + 候选全在头顶 → 先出地表，别把够不到的树干丢给 Collect
                    if (!def.digdownFallback && !this._surfaceDone && this._shouldExitSurface(ctx, found)) {
                        this._surfacePending = found;
                        this._surfaceFromY = bot.entity.position.floored().y;
                        this._surfaceDeadline = Date.now() + this.surfaceBudgetMs;
                        this._surfaceWalkTriesUsed = 0;
                        this._surfaceSteps = 0;
                        this._surfaceState = 'walkout';
                        this.phase = 'surface';
                        ctx.telemetry('surface_exit_start', {
                            y: this._surfaceFromY, found: found.length,
                            rock: this._overheadSolid(ctx),
                            lowest: Math.min(...found.map((p) => p.y)), highest: Math.max(...found.map((p) => p.y)),
                        });
                        return;
                    }
                    this.candidateQueue = this._orderCandidates(ctx, def, found).slice(0, 5)
                        .map((p) => ({ pos: p, dist: bot.entity.position.distanceTo(p) }));
                    const c = this.candidateQueue.shift();
                    this._succeed({ target: c.pos, source: `scan${r}` });
                    return;
                }
                this.scanIdx++;
                return;
            }
            case 'surface': {
                await this._tickSurface(ctx, def);
                return;
            }
            case 'wander': {
                // 空扫描早退（先于换区判定）：当前观测点没有任何可用候选（从没见过，或上一整轮
                // 扫到的候选已被拉黑耗尽且重扫仍为 0）时，烧满 wander+relocate 没有意义，快速
                // FAIL 让父任务走它的兜底（石类 = digdown；原木 = relocate 满预算后如实失败）
                const noneAvailable = this.roundCandidates === 0
                    || (this.candidateQueue.length === 0 && this._lastTierFound === 0);
                if (noneAvailable && this.wanderCount >= this.emptyExitAfterWanders) {
                    this._fail(FailReason.NO_RESOURCE_FOUND, {
                        searches: ctx.run.counters.searches,
                        wanders: this.wanderCount,
                        relocates: this.relocatesUsed,
                        emptyExit: true,
                        blacklist: ctx.run.blacklist.size,
                    });
                    return;
                }
                if (this.wanderCount >= this.maxWanders) { this.phase = 'relocate'; return; }
                this.wanderCount++;
                const [rMin, rMax] = this.wanderRange;
                const ang = Math.random() * Math.PI * 2;
                const dist = rMin + Math.floor(Math.random() * (rMax - rMin));
                const from = bot.entity.position.floored();
                const to = new Vec3(Math.round(from.x + Math.cos(ang) * dist), from.y, Math.round(from.z + Math.sin(ang) * dist));
                ctx.telemetry('wander', { to: [to.x, to.y, to.z], n: this.wanderCount });
                this._navGoalPos = to;
                // GoalNear 只约束水平到达（高度自适应），到达半径 4
                await navTo(ctx, new pf.goals.GoalNear(to.x, to.y, to.z, 4), { timeoutMs: 30000, label: 'wander' });
                this._navGoalPos = null;
                this.phase = 'scan'; // 游走后从最小半径重扫（观测点变了）
                this.scanIdx = 0;
                return;
            }
            case 'relocate': {
                if (this.relocatesUsed >= this.maxRelocates) {
                    this._fail(FailReason.NO_RESOURCE_FOUND, {
                        searches: ctx.run.counters.searches,
                        wanders: this.wanderCount,
                        relocates: this.relocatesUsed,
                        blacklist: ctx.run.blacklist.size,
                    });
                    return;
                }
                this.relocatesUsed++;
                const [rMin, rMax] = this.relocateRange;
                const ang = Math.random() * Math.PI * 2;
                const dist = rMin + Math.floor(Math.random() * (rMax - rMin));
                const from = bot.entity.position.floored();
                const tx = Math.round(from.x + Math.cos(ang) * dist);
                const tz = Math.round(from.z + Math.sin(ang) * dist);
                ctx.telemetry('relocate', { to: [tx, tz], n: this.relocatesUsed });
                ctx.run.counters.relocates++;
                this._navGoalPos = new Vec3(tx, from.y, tz);
                // GoalXZ 语义（AltoClef GetToXZTask 对应物）：只约束水平，高度自适应
                const ok = await navTo(ctx, new pf.goals.GoalXZ(tx, tz), { timeoutMs: this.navTimeoutMs + 15000, label: 'relocate' });
                this._navGoalPos = null;
                // 换区成功与否都清记账重扫（新区域资源状况未知）；位移过近则短暂等待让 chunk 加载
                this.scannedAreas.clear();
                this.scanIdx = 0;
                this.wanderCount = 0;
                this.roundCandidates = 0; // 新区域重新计候选
                this.phase = 'scan';
                if (bot.entity.position.distanceTo(from) < 16) await sleep(2000);
                return;
            }
            default:
                this._fail(FailReason.INTERNAL, { error: `unknown phase ${this.phase}` });
        }
    }

    // 阶段推进表：wander→relocate→(耗尽)FAILED
    _advancePhase(ctx, why) {
        ctx.telemetry('find_phase_skip', { phase: this.phase, why });
        if (this.phase === 'local' || this.phase === 'scan') { this.phase = 'scan'; this.scanIdx = Math.min(this.scanIdx + 1, this.scanRadii.length); }
        else if (this.phase === 'surface') { this._surfaceDone = true; this.phase = 'scan'; this.scanIdx = 0; }
        else if (this.phase === 'wander') { this.phase = 'relocate'; }
        else if (this.phase === 'relocate') { this.relocatesUsed = this.maxRelocates; } // 下一 tick 直接 FAILED
    }

    // ---------- 出地表（MC-M1-TASK-06d P2-1）----------
    /** 够得着的候选（与 _orderCandidates 的口径一致：高于脚部 +4 的站地上挖不到） */
    _reachableNow(ctx, found) {
        const feet = ctx.bot.entity.position.floored();
        return found.filter((p) => p.y - feet.y <= 4);
    }

    /**
     * 头顶以上的**实心块总数**（允许中间夹空气，向上最多看 64 格）。
     *
     * ⚠ 第一版写的是「头上一格是不是实心」，在**隧道**里永远判错——隧道顶上就是空气，
     *   于是 `>= 4 格实心` 这条永远不成立，新相位一次都没触发（实测：kit 把人塞进 y41 的
     *   隧道后跑 `obtain 4 log`，3 次 search 全部走了旧的退化分支，surface_* 事件 0 条）。
     *   「人在不在地下」要看的是**离天还有多厚的岩层**，不是「头顶有没有空气」。
     */
    _overheadSolid(ctx, max = 64) {
        const bot = ctx.bot;
        const feet = bot.entity.position.floored();
        let n = 0;
        for (let k = 1; k <= max; k++) {
            const b = bot.blockAt(feet.offset(0, k, 0));
            if (!b) break;                                  // 区块没加载 → 到此为止
            if (b.name === 'air' || b.name === 'cave_air' || b.name === 'void_air') continue;
            n++;
        }
        return n;
    }

    /**
     * 触发条件（三条同时成立，缺一不可，否则会误伤地表/山顶场景）：
     *   ① 没有一个候选够得着（否则就是普通的「走过去挖」）；
     *   ② 人在地下：feet.y < surfaceYMax 且**头顶以上实心块 ≥10**（离天还有十格以上岩层）；
     *   ③ 本轮搜索还没为出地表花过预算（_surfaceDone）。
     */
    _shouldExitSurface(ctx, found) {
        const bot = ctx.bot;
        const feet = bot.entity.position.floored();
        if (this._reachableNow(ctx, found).length) return false;
        if (feet.y >= this.surfaceYMax) return false;
        if (this._overheadSolid(ctx) < this.surfaceMinRock) return false;
        return true;
    }

    /**
     * 出地表相位。两段：
     *   walkout —— GoalXZ 只约束水平，pathfinder 会自己爬楼梯（=「沿原路返回」）；
     *   digup   —— 走不通就在脚下阶梯上挖（digdown 的镜像），1 tick 升 1 格。
     * 两种都不成（超预算/卡死）就**兜底回今天的行为**：把原候选丢给 Collect（_surfacePending），
     * 所以最坏情况不比修之前差。
     */
    async _tickSurface(ctx, def) {
        // ⚠ 这是一段**全新的实验性分支**（挖/导航/水位/悬空判据都可能抛），绝不能让它把整个
        //   搜索打成 INTERNAL——P2SMOKE2 就是这么废掉的：surface_exit_stage 之后 256ms 就
        //   `FindResourceTask RUNNING→FAILED reason=INTERNAL`，而任务层没留下任何异常原文。
        //   现在：整个 body 包 try/catch，抛错就记 `surface_tick_error`（带 message + 栈顶三行）
        //   并走兜底（把原候选交回 Collect），最坏情况 = 修之前的行为。
        try {
            await this._surfaceBody(ctx, def);
        } catch (e) {
            ctx.telemetry('surface_tick_error', {
                error: String(e && e.message ? e.message : e).slice(0, 160),
                where: String(e && e.stack ? e.stack : '').split('\n').slice(1, 4).map((l) => l.trim().slice(0, 90)).join(' <- '),
                state: this._surfaceState, y: this._surfaceFromY, steps: this._surfaceSteps,
            });
            this._surfaceGiveUp(ctx, 'exception');
        }
    }

    async _surfaceBody(ctx, def) {
        const bot = ctx.bot;
        const y0 = this._surfaceFromY;
        const gained = bot.entity.position.floored().y - y0;
        // 成功判据不是「爬够了 N 格」，而是**「原来够不着的候选现在够得着了」**。
        // 第一版写死 gained>=6 就收工，P2SMOKE3 里 bot 从 y40 爬到 y46 触发 surface_exit_ok，
        // 而原木在 y69–70（还差 23 格）——白爬一趟又退回退化分支。爬升只是手段，够得着才是目的。
        const pending = this._surfacePending ?? [];
        const reachableNow = pending.length ? this._reachableNow(ctx, pending).length > 0 : false;
        if (gained >= this.surfaceGainMin && (reachableNow || gained >= this.surfaceYMax - y0)) {
            this._surfaceDone = true;
            this._surfaceState = null;
            this._surfacePending = [];
            // 观测点变了：清扫描记账，从最小半径重扫（站起来就能看见树）
            this.scannedAreas.clear();
            this.scanIdx = 0;
            this.wanderCount = 0;
            this.roundCandidates = 0;
            this.phase = 'scan';
            ctx.telemetry('surface_exit_ok', {
                fromY: y0, toY: bot.entity.position.floored().y, gained, steps: this._surfaceSteps,
                reachableNow, pending: pending.length, ms: this.surfaceBudgetMs - (this._surfaceDeadline - Date.now()),
            });
            return;
        }
        if (Date.now() > this._surfaceDeadline) { this._surfaceGiveUp(ctx, 'budget'); return; }

        if (this._surfaceState === 'walkout') {
            this._surfaceWalkTriesUsed++;
            if (this._surfaceWalkTriesUsed > this.surfaceWalkTries) {
                this._surfaceState = 'digup';
                ctx.telemetry('surface_exit_stage', { stage: 'digup', fromY: y0 });
                return;
            }
            const from = bot.entity.position.floored();
            const ang = Math.random() * Math.PI * 2;
            const dist = 20 + Math.floor(Math.random() * 9);
            const tx = Math.round(from.x + Math.cos(ang) * dist);
            const tz = Math.round(from.z + Math.sin(ang) * dist);
            ctx.telemetry('surface_walkout', { to: [tx, tz], n: this._surfaceWalkTriesUsed, fromY: y0 });
            this._navGoalPos = new Vec3(tx, from.y, tz);
            await navTo(ctx, new pf.goals.GoalXZ(tx, tz), { timeoutMs: 12000, label: 'surface_walkout' });
            this._navGoalPos = null;
            return;
        }

        // ---- 阶梯上挖：挖「斜上前方」一格 → 走进去（1 tick 升 1 格）----
        const feet = bot.entity.position.floored();
        const below = bot.blockAt(feet.offset(0, -1, 0));
        if (below && (below.name === 'air' || below.name === 'cave_air' || below.name === 'void_air')) {
            // 悬空（站在坑沿/半空）：先让物理落定；落不了就让 pathfinder 踩下去
            if (!bot.entity.onGround) return;
            this._surfaceGiveUp(ctx, 'no_ground');
            return;
        }
        if (bot.entity.isInWater) { this._surfaceGiveUp(ctx, 'in_water'); return; }
        const order = DIRS4.map((d, i) => ({ d, i: (i + Math.floor(Math.random() * 4)) % 4 })).sort((a, b) => a.i - b.i);
        const air = (b) => !b || b.name === 'air' || b.name === 'cave_air' || b.name === 'void_air';
        /**
         * 挖一格。**必须等上一次挖掘真正落定**：`digWithVerify` 走的是 time_optimistic
         * （bot.digTime+600ms 就判成功不等回包），而垂直向上挖时 bot 还在转视角、挖得比
         * 横向慢，600ms 的余量经常不够 → 上一次 dig 还在后台跑，这一次 bot.dig 一进去就
         * 被 mineflayer 的 digging 插件 stopDigging() 打到 `Digging aborted`
         * （P2LOG trial_01 原文：`at bot.stopDigging (digging.js:189) <- at EventEmitter.dig
         * (digging.js:127) <- at processTicksAndRejections`）。抛出来就把整个 tick 带走。
         */
        const digOne = async (block, label) => {
            const t0w = Date.now();
            while (bot.targetDigBlock && Date.now() - t0w < 4000) await sleep(100);
            if (bot.targetDigBlock) { ctx.telemetry('surface_digup_stuck_dig', { y: feet.y, label }); return false; }
            try {
                return await digWithVerify(ctx, block, { blocks: [], drops: [] });
            } catch (e) {
                // 单独兜住：一次挖失败只换方向，不许把整个 surface 相位带走
                ctx.telemetry('surface_digup_dig_error', { y: feet.y, label, error: String(e && e.message ? e.message : e).slice(0, 120) });
                return { ok: false, reason: FailReason.DIG_FAILED, error: String(e && e.message ? e.message : e).slice(0, 80) };
            }
        };
        for (const { d } of order) {
            const step = feet.offset(d[0], 1, d[1]);        // 要踩上去的那格（+1）
            const headroom = feet.offset(d[0], 2, d[1]);     // 站上去以后头所在的那格（+2）
            const sBlk = bot.blockAt(step);
            const hBlk = bot.blockAt(headroom);
            if (!sBlk || !hBlk) continue;
            // ① 头顶实心就先挖开（否则 1 格高的洞里连站都站不上去）
            if (!air(hBlk)) {
                const r1 = await digOne(hBlk, 'head');
                if (!r1?.ok) {
                    if (r1?.reason === FailReason.TOOL_MISSING) { this._surfaceGiveUp(ctx, 'tool_missing'); return; }
                    continue;
                }
                ctx.telemetry('surface_digup_head', { y: feet.y, block: hBlk.name });
            }
            // ② 脚下那一格还实心（隧道只有 1 格高）就再挖一格
            if (!air(bot.blockAt(step))) {
                const r2 = await digOne(bot.blockAt(step), 'step');
                if (!r2?.ok) {
                    if (r2?.reason === FailReason.TOOL_MISSING) { this._surfaceGiveUp(ctx, 'tool_missing'); return; }
                    continue;
                }
                ctx.telemetry('surface_digup_step', { y: feet.y, block: sBlk.name });
            }
            this._surfaceSteps++;
            await navTo(ctx, new pf.goals.GoalBlock(step.x, step.y, step.z), { timeoutMs: 6000, label: 'surface_digup' });
            return;
        }
        this._surfaceGiveUp(ctx, 'no_direction');
    }

    /** 出不去：兜底回修之前的行为（把原候选交给 Collect），并记一笔，别让整个 run 死在这。 */
    _surfaceGiveUp(ctx, why) {
        const bot = ctx.bot;
        const def = resourceDef(this.resource);
        const pending = this._surfacePending ?? [];
        this._surfaceDone = true;
        this._surfaceState = null;
        this.phase = 'scan';
        this.scannedAreas.clear();
        this.scanIdx = 0;
        this.wanderCount = 0;
        this.roundCandidates = 0;
        ctx.telemetry('surface_exit_giveup', { why, fromY: this._surfaceFromY, toY: bot.entity.position.floored().y, steps: this._surfaceSteps, pending: pending.length });
        if (pending.length) {
            this.candidateQueue = this._orderCandidates(ctx, def, pending).slice(0, 5)
                .map((p) => ({ pos: p, dist: bot.entity.position.distanceTo(p) }));
            const c = this.candidateQueue.shift();
            this._succeed({ target: c.pos, source: 'surface_giveup', giveup: why });
        }
    }

    // 纵向直检：脚下 1..6 格内有未黑名单的 stone 系 → 返回深度（无则 -1）
    _localVertical(ctx, def) {
        const bot = ctx.bot;
        const feet = bot.entity.position.floored();
        for (let k = 1; k <= 6; k++) {
            const p = feet.offset(0, -k, 0);
            const blk = bot.blockAt(p);
            if (blk && def.blocks.includes(blk.name) && !ctx.run.blacklist.has(posKey(p))) {
                ctx.telemetry('find_local_vertical', { depth: k, block: blk.name });
                return k;
            }
        }
        return -1;
    }

    // 邻近直检：小半径已加载区块内最近未黑名单候选
    _localNear(ctx, def) {
        const bot = ctx.bot;
        const ids = blockIds(bot, def);
        const near = bot.findBlocks({ matching: ids, maxDistance: this.localRadius, count: 32 })
            .filter((p) => !ctx.run.blacklist.has(posKey(p)))
            .filter((p) => this._exposed(ctx, p));
        if (near.length) {
            const picked = this._orderCandidates(ctx, def, near)[0];
            ctx.telemetry('find_local_near', { count: near.length, r: this.localRadius });
            return picked;
        }
        return null;
    }

    _scanRadius(ctx, def, radius) {
        const bot = ctx.bot;
        const ids = blockIds(bot, def);
        const found = bot.findBlocks({ matching: ids, maxDistance: radius, count: 256 })
            .filter((p) => !ctx.run.blacklist.has(posKey(p)))
            .filter((p) => this._exposed(ctx, p));
        const ordered = this._orderCandidates(ctx, def, found);
        this.candidatesSeen += ordered.length;
        ctx.run.counters.blockCandidates += ordered.length;
        ctx.telemetry('search', { radius, found: ordered.length });
        return ordered;
    }

    // 候选排序/过滤（MC-M1-TASK-04 选做④，B2R5-20 遥测：山顶出生点原木在头顶够不着）：
    //  - 石类（有 digdown 兜底）：按距离近先——横向够得着就别舍近求远；
    //  - 原木类：高于脚部 +4 的直接跳过（站地上挖不到的树干）；剩余候选按
    //    「最近一棵树的最低一段主干」排序——先锁定最近的树，再取它最低的原木段
    //    （主干自下而上逐段挖，底部段永远可达，也避免远树低段抢在近树前面）。
    _orderCandidates(ctx, def, found) {
        const bot = ctx.bot;
        if (!def.digdownFallback) {
            const feet = bot.entity.position.floored();
            const reachable = found.filter((p) => p.y - feet.y <= 4);
            if (!reachable.length) {
                // 地下死角兜底（TASK-06 smoke7 实证）：铁矿挖完人已在 y≈45 洞里，树全在头顶
                // ——reachable 过滤全空会让 wander/relocate 盲找 150s+ 必败。退化为取最低的
                // 几段树干导航（爬坡/绕出洞，树总比没有强）；地表场景不受影响（reachable 非空）。
                return found.sort((a, b) => (a.y - b.y)
                    || (bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b))).slice(0, 8);
            }
            const anchor = reachable.reduce((a, b) => (bot.entity.position.distanceTo(a) <= bot.entity.position.distanceTo(b) ? a : b));
            const tree = reachable.filter((p) => {
                const dx = p.x - anchor.x, dz = p.z - anchor.z;
                return dx * dx + dz * dz <= 25; // 水平 ≤5 格视为同一棵树
            });
            tree.sort((a, b) => (a.y - b.y) || (bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b)));
            const rest = reachable.filter((p) => !tree.includes(p))
                .sort((a, b) => (a.y - b.y) || (bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b)));
            return [...tree, ...rest];
        }
        return found.sort((a, b) => bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b));
    }

    // 候选裸露判定：顶面或任一水平邻是空气。B2R1-t6 教训：findBlocks 是方块数据扫描，
    // 沙漠/埋层里会把「方块数据里的石头」全算成候选——导航 NoPath、采集 target_dead，
    // 候选质量归零。埋着的石头是 digdown 纵向探针的正业，不进水平搜索。
    _exposed(ctx, pos) {
        const bot = ctx.bot;
        const checks = [pos.offset(0, 1, 0), pos.offset(1, 0, 0), pos.offset(-1, 0, 0), pos.offset(0, 0, 1), pos.offset(0, 0, -1)];
        for (const c of checks) {
            const b = bot.blockAt(c);
            if (!b) return false; // 邻块未加载 → 保守判非裸露
            if (b.name === 'air' || b.name === 'cave_air') return true;
        }
        return false;
    }
}
