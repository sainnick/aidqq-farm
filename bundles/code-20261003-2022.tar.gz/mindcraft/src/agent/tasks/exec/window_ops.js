// window_ops.js — MC-M1-TASK-09：窗口操作「每一步等服务端确认」
//
// 本文件要治的病（ROUND3-A 报告 §9.1，三个症状一个根因）：
//   ① 工作台 3×3 合成偶发拿不到成品、不抛错、材料没少（1.16.1 上 wooden_pickaxe 24/30）；
//   ② 熔炉取产物后产物「下落不明」，`smelt_ok` 恒为 0；
//   ③ 2×2 背包合成 `Server rejected transaction for clicking on slot 0`（M4B4 回归 24 次）。
//
// 根因不是配方、不是材料、也不是「背包同步慢」，而是**窗口模型被客户端单方面改写、
// 后续点击却按被改写后的模型发包**。三处都落在 mineflayer 4.38 的复合动作上：
//   - craft.js `grabResult()`：先 `window.updateSlot(0, new Item(result))` **凭空造出产物槽**，
//     再 `await bot.putAway(0)`。这一行 updateSlot 是**直接写模型**（不是服务端回包），
//     于是随后那次点击携带的 `item` 字段是伪造值；服务端自己的结果槽若是空的/不同的，
//     就会拒收或不按客户端预期生效，而客户端已经把模型改了 ⇒ 两边永久分叉。
//   - furnace.js `takeOutput()` = `putAway(2)`，同样是「点一下 + putSelectedItemRange + 等回包」
//     的复合动作，中途任何一环被服务端拒绝，客户端模型都已经改过了。
//   - 2×2 通道走 window 0，光标/产物槽状态更容易与实际不符，于是被服务端明确拒绝（这个是
//     **响亮**地失败：transaction accepted=false ⇒ clickWindow 抛异常）。
//
// 本文件的口径（**每一步等服务端确认**）：
//   - 绝不主动写窗口模型（不调 `window.updateSlot`），模型只允许被服务端回包驱动；
//   - 每次点击都拿到**服务端对这一次点击的判决**才继续：
//       · 1.16.x：有 `transaction{windowId,action,accepted}` —— 判决按 **action 号**对齐，
//         等我们**自己发出去的那个 action** 的回执，不接受任何"客户端自说自话的通过"；
//       · 任何版本 / `requiresConfirmation=false` 的窗口（1.16.1 的箱子就是这种，见下）：
//         退化为「等**服务端** `set_slot` 覆盖到被点的那一格」，等不到就判 unverified（不猜）。
//   - 光标（carried item）的真值从**原始 `set_slot` 包 slot=-1** 读，不读 `win.selectedItem`
//     （1.16.1 上 mineflayer 不会用服务端包的 slot=-1 去更新 selectedItem，见 `readCursorTruth`）。
//
// ── 两条 1.16.1 的实测事实（本单离线核实，证据见 docs/MC-M1-TASK-09.md §2）──
//  (A) **`slot` 类型的 `{present,…}` 容器不是 1.16 专属**：minecraft-data 的 `types.slot` 在
//      1.16 / 1.16.1 / 1.16.2 / 1.17 / 1.17.1 / 1.18.2 上**逐字相同**，而
//      `prismarine-item@1.18` 的 `toNotch()` 本来就返回 `{present:false}` /
//      `{present:true,itemId,itemCount}` —— 即**它对所有版本都是对的**。
//      ⇒ ROUND3-A §3.2.7「1.16.1 的 window_click 里 Slot 是 {present,…}，1.17+ 才是裸 NBT，
//        toNotch() 的形状对不上」这个归因**不成立**；`SizeOf error … reading 'present'` 那个
//        报错只是**症状落在最后一个被读的字段上**，不是形状问题（见下）。
//  (B) 真正随版本变的是**包封（envelope）**，不是 Slot：
//        1.16.1 `window_click` = {windowId:u8, slot:i16, mouseButton:i8, action:i16, mode:i8, item:slot}
//        1.17.1 `window_click` = {windowId:u8, stateId:varint, slot:i16, mouseButton:i8, mode:varint,
//                                  changedSlots:[{location,item}], cursorItem:slot}
//      自研的 `_tableCraft` 只写了 1.17+ 那一种信封，且**字段名对不上** ⇒ protodef 按字段名取值时
//      `action` 与 `item` 都是 undefined，读到 `item`（匿名 slot 容器）时去取 `undefined.present`
//      才炸。因为这个 slot 是**匿名容器**，`e.field` 也是 undefined，报错文本里连字段名都没有 ——
//      所以看起来像"Slot 形状问题"，实际是"少写了两个字段"。
//      ⇒ `_tableCraft` 在 1.16.1 上**可以启用**，只要按版本选信封（`windowClickPacket`）。

import { sleep, countItems } from './task.js';
import { createRequire } from 'module';
import prismarineItem from 'prismarine-item';

const require = createRequire(import.meta.url);

const ITEM_FACTORY_KEY = Symbol.for('aidqq.windowOps.itemFactory');
/** 服务端 set_slot 包里的 slot 是 `{present,itemId,itemCount}`，不是 prismarine 的 Item。
 *  必须过一次 `Item.fromNotch` 才有 name/count/type —— 否则 `expectName` 比对恒不成立、
 *  `findDestSlot` 恒找不到格子（自检 ⑦a 实测：took 读成 undefined 就是漏了这一步）。 */
export function toItem(bot, notch) {
    if (!notch) return null;
    if (notch.item === undefined && typeof notch.count === 'number' && typeof notch.type === 'number') return notch; // 已是 Item
    if (typeof notch.present === 'undefined' && notch.itemId === undefined) return null;
    if (!bot[ITEM_FACTORY_KEY]) bot[ITEM_FACTORY_KEY] = prismarineItem(bot.registry);
    try { return bot[ITEM_FACTORY_KEY].fromNotch(notch) ?? null; } catch { return null; }
}

// ── 版本判定（1.16.x 与 1.17+ 是唯一的分界：stateIdUsed / transactionPacketExists）──
export function clickFlavor(bot) {
    return {
        // ≤1.16.5：window_click 带 action 号，服务端用 transaction 包回执 accepted
        actionIdUsed: !!bot.supportFeature('actionIdUsed'),
        // ≤1.16.5：服务端会发 transaction；1.17+ 改为 stateId 校验
        transactionPacketExists: !!bot.supportFeature('transactionPacketExists'),
        // 1.17+：window_click 带 stateId + changedSlots + cursorItem
        stateIdUsed: !!bot.supportFeature('stateIdUsed'),
    };
}

// ── action 号（1.16.x）：必须**相对服务端已见到的最大 action 单调递增** ──
// 协议注释原话：Action number = "Assigned by the Client. This number must
// incrementally increase per click." 1.16.1 的服务端会拒收不递增的点击。
//
// 踩过的坑（实服 T09_SMOKE）：本模块原先用自己的计数器从 1 起步，于是同一台 bot 上
// mineflayer 自己（`bot.clickWindow`）已经推进过的 action 号被本模块"倒退"覆盖，
// **每一次点击都被服务端 accepted=false 拒收**（telemetry: table_craft_click_rejected
// {slot:37, rejected:true, via:'transaction'}，3/3 全灭）。
// 而 mineflayer 的计数器是 inventory.js 的模块私有变量，**读不到**。
// ⇒ 改成**从服务端回执里反推**：`transaction` 包会把 action 号原样送回来，
//    每次都拿它更新 max，下一个点击发 max+1。这样无论 mineflayer 自己点过多少次，
//    本模块发出的号都严格大于服务端见过的所有号。
const ACTION_KEY = Symbol.for('aidqq.windowOps.actionId');
function state(bot) {
    if (!bot[ACTION_KEY]) {
        bot[ACTION_KEY] = { maxAction: 0, onTx: null };
        const st = bot[ACTION_KEY];
        st.onTx = (p) => {
            if (p && typeof p.action === 'number' && p.action > st.maxAction) st.maxAction = p.action;
        };
        bot._client.on('transaction', st.onTx);
    }
    return bot[ACTION_KEY];
}
function nextActionId(bot) {
    const st = state(bot);
    st.maxAction = st.maxAction === 32767 ? 1 : st.maxAction + 1;
    return st.maxAction;
}

// 1.17+ 的 stateId：mineflayer 在 inventory.js 里自己维护（`stateId` 模块变量），
// 外部拿不到；这里自己跟一份，按**窗口 ID** 跟踪（这正是 _tableCraft 想要的语义：
// bot.craft 用全局单变量，会被玩家背包 offhand 的 set_slot 污染）。
const STATE_KEY = Symbol.for('aidqq.windowOps.stateId');
function stateIdFor(bot, windowId) {
    if (!bot[STATE_KEY]) {
        bot[STATE_KEY] = { map: new Map(), listen: false };
        const st = bot[STATE_KEY];
        const onSync = (p) => { if (p && typeof p.stateId === 'number') st.map.set(p.windowId, p.stateId); };
        bot._client.on('window_items', onSync);
        bot._client.on('set_slot', onSync);
    }
    const st = bot[STATE_KEY];
    return st.map.get(windowId) ?? 0;
}

/** 协议要的 slot 形状是 `{present,itemId,itemCount,nbtData}`。传 prismarine 的 Item 进去，
 *  protodef 读 `present` 得到 undefined ⇒ 编码成 **present=false（"光标是空的"）**，
 *  包照样编出来、不报任何错，但语义是错的：1.16.1 服务端按"你声称光标是空的"去校验，
 *  于是 accepted=false 拒收（实服证据 bench micro-craft/runs/T09_PDIFF：
 *  mineflayer 16 字节 accepted:true vs 本模块 9 字节 accepted:false，同一次点击）。
 *  已在离线自检里加断言（自检 ⑨），别再退化回去。 */
export function toNotchSlot(bot, item) {
    if (item == null) return { present: false };
    if (typeof item.present === 'boolean') return item;   // 已经是协议形状，原样透传
    if (item.itemId !== undefined) return item;           // 同上
    if (!bot[ITEM_FACTORY_KEY]) bot[ITEM_FACTORY_KEY] = prismarineItem(bot.registry);
    return bot[ITEM_FACTORY_KEY].toNotch(item);
}

/**
 * 按目标协议版本组装 window_click 包。
 * 这是 `_tableCraft` 在 1.16.1 上发不出包的真修法（**不是**改 Slot 形状，见文件头 (A)(B)）。
 * `item` / `cursorItem` / `changedSlots[].item` 一律在这里过 `toNotchSlot`，
 * 调用方不需要（也不该）自己记得转换。
 */
export function windowClickPacket(bot, flavor, { windowId, slot, mouseButton = 0, mode = 0, changedSlots, item, cursorItem }) {
    if (flavor.stateIdUsed) {
        return {
            name: 'window_click',
            params: {
                windowId, stateId: stateIdFor(bot, windowId), slot, mouseButton, mode,
                changedSlots: (changedSlots ?? []).map((c) => ({ location: c.location, item: toNotchSlot(bot, c.item) })),
                cursorItem: toNotchSlot(bot, cursorItem),
            },
        };
    }
    // ≤1.16.5：action 号 + 携带物品（不是 cursorItem）
    return {
        name: 'window_click',
        params: {
            windowId, slot, mouseButton, action: nextActionId(bot), mode,
            item: toNotchSlot(bot, item),
        },
    };
}

/** 序列化一个 window_click（离线自检与实服调试共用；失败信息带字段名便于定位） */
export function encodeWindowClick(bot, params) {
    const flavor = clickFlavor(bot);
    const pkt = windowClickPacket(bot, flavor, params);
    try {
        const { createSerializer } = require('minecraft-protocol');
        const s = createSerializer({ state: 'play', isServer: false, version: bot.version });
        return { ok: true, packet: pkt, bytes: s.createPacketBuffer(pkt).length };
    } catch (e) {
        return { ok: false, packet: pkt, error: String(e && e.message ? e.message : e).slice(0, 200) };
    }
}

/**
 * 等**服务端**对某一格的一次 set_slot。
 * 注意：这里只认原始包（`bot._client.on('set_slot')`）—— 本地 `window.updateSlot()`
 * 走的是 `window.emit`，不是这个事件，所以「客户端自己改模型」骗不过它。
 */
export function waitServerSlot(bot, windowId, slot, timeoutMs = 1200) {
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => { if (!done) { done = true; bot._client.removeListener('set_slot', h); clearTimeout(timer); resolve(v); } };
        const h = (p) => {
            if (p.windowId === windowId && p.slot === slot) finish({ ok: true, slot, item: toItem(bot, p.item) });
        };
        const timer = setTimeout(() => finish({ ok: false, slot, timedOut: true }), timeoutMs);
        bot._client.on('set_slot', h);
    });
}

/**
 * 等**服务端**的 transaction 回执，按我们发出的 action 号对齐。
 * 只有 1.16.x 有这个包（transactionPacketExists）。返回 {accepted} 或超时。
 */
export function waitServerTransaction(bot, windowId, actionId, timeoutMs = 1500) {
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => { if (!done) { done = true; bot._client.removeListener('transaction', h); clearTimeout(timer); resolve(v); } };
        const h = (p) => {
            if (p.windowId !== windowId) return;
            if (p.action !== actionId) return;   // 迟到/别人的回执一律不认
            finish({ ok: true, accepted: !!p.accepted, action: p.action });
        };
        const timer = setTimeout(() => finish({ ok: false, timedOut: true, action: actionId }), timeoutMs);
        bot._client.on('transaction', h);
    });
}

/**
 * 光标（carried item）的**服务端真值**判据。
 *
 * ── MC-M1-TASK-10 订正 TASK-09 §4.5 的否定结论 ──
 * TASK-09 写的是「1.16.x 的协议里根本没有光标这个字段 ⇒ 服务端永远不会告诉客户端
 * 光标里是什么 ⇒ 等服务端确认光标物理上不可能」。**这条不成立**，本单用协议表 +
 * 1.16.1 官方反编译源码双向核实：
 *
 *  ① 协议层（minecraft-data pc/1.16.1 protocol.json）：
 *       packet_set_slot = [{windowId: **i8**}, {slot: i16}, {item: slot}]
 *     `windowId` 是**有符号** i8，所以服务端的 -1 在线上一字节 0xFF 就是 -1，
 *     客户端 protodef 解出来仍然是 **-1**（不是 255）。
 *     TASK-09 犯的错是**判据**：它等 `set_slot(windowId === 当前窗口id, slot === -1)`，
 *     而服务端发光标用的 windowId 是 **-1**（不是窗口 id）⇒ 那个谓词**永远不可能命中**。
 *     「等不到包」是判据写错的观测结果，**不是包没来**（手册 §5：超时不是证据）。
 *
 *  ② 服务端确实会主动发（ServerPlayer.java:947 / :962）：
 *       broadcastCarriedItem() → new ClientboundContainerSetSlotPacket(-1, -1, this.bt.m())
 *       窗口全量同步后也会跟一条同形的包
 *     即 **windowId=-1 且 slot=-1 的那条 set_slot 就是光标真值**，1.16.1 与 1.17+ 一致。
 *
 *  ③ 为什么 mineflayer 读不到：`inventory.js:738-753` 的 set_slot 处理器按 windowId 派发，
 *     `packet.windowId === 0 ? bot.inventory : bot.currentWindow` 之后还有
 *     `window.id !== packet.windowId ⇒ return` —— windowId=-1 落进这个 return，
 *     **包被丢掉**。所以本地 `win.selectedItem` 永远拿不到服务端校正。
 *     ⇒ 要服务端的光标真值，只能自己听原始包（本文件的 tap / readCursorTruth）。
 *
 * 注意：服务端**只在光标内容变化时**才发这条包（broadcastCarriedItem 由回执路径和
 * broadcastChanges 触发）。所以「没等到光标包」≠「光标是空的」，也不该当成失败判据；
 * 它只在**我们期望光标变化**时才是有效证据。
 */
export const CURSOR_WINDOW_ID = -1;
export const CURSOR_SLOT = -1;
export function isCursorPacket(p) {
    return !!p && p.windowId === CURSOR_WINDOW_ID && p.slot === CURSOR_SLOT;
}

/** 槽位签名（type:count），用来判"服务端那一格有没有真的变" */
export function slotSig(it) {
    return it ? `${it.type}:${it.count}` : null;
}

/** 背包区（win.inventoryStart … win.inventoryEnd）逐格签名快照 */
export function inventorySignature(win) {
    const sig = {};
    if (!win || win.id == null) return sig;
    for (let i = win.inventoryStart; i < win.inventoryEnd; i++) sig[i] = slotSig(win.slots[i]);
    return sig;
}

export function readCursorTruth(bot, windowId, { timeoutMs = 0, from } = {}) {
    // from: 已经收到的包里回放（毫秒时间戳），用于「点击后已经收到过 -1 更新」的情况。
    // ⚠ windowId 参数**只保留签名兼容**，不再参与匹配：服务端光标包的 windowId 是 -1，
    //   与当前窗口 id 无关（见上）。老代码拿它做等值比较，导致 1.16.1 上永远等不到。
    if (from) {
        for (let i = from.length - 1; i >= 0; i--) {
            if (isCursorPacket(from[i])) return { ok: true, item: toItem(bot, from[i].item), fromPacket: true };
        }
        return { ok: false, item: null, fromPacket: false };
    }
    if (timeoutMs <= 0) return { ok: false, item: null, fromPacket: false };
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => { if (!done) { done = true; bot._client.removeListener('set_slot', h); clearTimeout(timer); resolve(v); } };
        const h = (p) => { if (isCursorPacket(p)) finish({ ok: true, item: toItem(bot, p.item), fromPacket: true }); };
        const timer = setTimeout(() => finish({ ok: false, item: null, fromPacket: false }), timeoutMs);
        bot._client.on('set_slot', h);
    });
}

/**
 * 抓 `set_slot` 原始包的环形缓冲（用于点击前后回放，确认光标真值与背包槽真值）。
 *
 * ⚠ TASK-10 订正：老版本这里第一行就是 `if (p.windowId !== windowId) return;` ——
 *   那会把 windowId=-1 的**光标包**全部过滤掉（服务端发光标用的 windowId 是 -1，
 *   不是窗口 id），于是"光标真值"这条通道永远是空的。现在**照单全收**，
 *   由 `cursorTruth()` / `slotTruth()` 各自按正确的谓词去挑。
 *   windowId 参数只用于 `slotTruth` 的默认过滤。
 */
export function makeSlotTap(bot, windowId = null, capacity = 64) {
    const buf = [];
    const push = (p) => {
        const rec = { at: Date.now(), windowId: p.windowId, slot: p.slot, item: p.item ?? null };
        buf.push(rec);
        if (buf.length > capacity) buf.shift();
        return rec;
    };
    const h = (p) => { push(p); };
    bot._client.on('set_slot', h);
    // 命中缓冲里**最近**一条；没有就真的**等**一条新的（不是立刻返回空——
    // 服务端的回包本来就是异步的，「刚点完就查」必然查不到）
    const find = (pred, ms) => {
        for (let i = buf.length - 1; i >= 0; i--) {
            if (pred(buf[i])) return { hit: buf[i] };
        }
        if (!(ms > 0)) return { hit: null };
        return new Promise((resolve) => {
            let done = false;
            const finish = (v) => { if (!done) { done = true; bot._client.removeListener('set_slot', w); clearTimeout(t); resolve(v); } };
            const w = (p) => {
                if (p.windowId !== windowId) return;
                const rec = push(p);
                if (pred(rec)) finish({ hit: rec });
            };
            const t = setTimeout(() => finish({ hit: null }), ms);
            bot._client.on('set_slot', w);
        });
    };
    return {
        packets: buf,
        since: (ms) => buf.filter((p) => p.at >= Date.now() - ms),
        /** 光标真值：只认服务端 set_slot 的 (-1,-1) 那一条（与窗口 id 无关） */
        async cursorTruth(ms = 2000) {
            const { hit } = await find(isCursorPacket, ms);
            return hit ? { ok: true, item: toItem(bot, hit.item), fromPacket: true } : { ok: false, item: null, fromPacket: false };
        },
        /** 某格的最新服务端真值（默认只看本窗口） */
        async slotTruth(slot, ms = 2000, winId = windowId) {
            const { hit } = await find((p) => p.slot === slot && (winId == null || p.windowId === winId), ms);
            return hit ? { ok: true, item: toItem(bot, hit.item) } : { ok: false, timedOut: true };
        },
        stop: () => bot._client.removeListener('set_slot', h),
    };
}

/**
 * MC-M1-TASK-11：**整窗 `window_items` 真值**（FARM-04 0/20 回归修复的第二条读通道）。
 *
 * 为什么需要（与 `makeSlotTap` 的分工）：
 *   `makeSlotTap` 抓的是**单格** `set_slot`。1.16.1 上**被接受的点击之后那一格永不发包**
 *   （`broadcastChanges` 先记 `lastSlots` 再发，点击路径被 `ignoreSlotUpdateHack` 抑制，
 *   `ServerPlayer.java:363` 每 tick 再调时 `lastSlots` 已等于新状态）
 *   ⇒ "点完等那一格的 set_slot"结构性失效，**哪怕服务端已经执行了**。
 *   `window_items`（`ClientboundContainerSetContentPacket`）是**整窗**同步，
 *   服务端在需要时（例如开窗、状态不同步后重同步）会整窗发一次 ⇒ 它是能拿到全量真值的通道。
 *
 * 与 `makeSlotTap` 同样遵守手册 §5「绝不把"未知"折成"没事"」：
 * **没抓到包就是没抓到**，返回 `{ok:false}`，由调用方决定回退到哪一级，**不在这里猜**。
 *
 * @param bot    mineflayer bot
 * @param windowId 只接受本窗口的整窗包（服务端重同步别的窗口时不该串味）
 * @param capacity 环形缓冲深度
 */
export function makeWholeWindowTap(bot, windowId = null, capacity = 8) {
    const buf = [];
    const h = (p) => {
        // 1.16.1 `window_items` = `{windowId, items:array}`；1.17+ 多一个 stateId，这里都不关心
        if (!p || !Array.isArray(p.items)) return;
        if (windowId != null && p.windowId !== windowId) return;
        buf.push({ at: Date.now(), windowId: p.windowId, items: p.items });
        if (buf.length > capacity) buf.shift();
    };
    bot._client.on('window_items', h);
    const find = (ms) => {
        // 缓冲里最近一条先看一眼（整窗包可能早在放料期间就到了）
        for (let i = buf.length - 1; i >= 0; i--) return { hit: buf[i] };
        if (!(ms > 0)) return { hit: null };
        return new Promise((resolve) => {
            let done = false;
            const finish = (v) => { if (!done) { done = true; bot._client.removeListener('window_items', w); clearTimeout(t); resolve(v); } };
            const w = (p) => {
                if (!p || !Array.isArray(p.items)) return;
                if (windowId != null && p.windowId !== windowId) return;
                const rec = { at: Date.now(), windowId: p.windowId, items: p.items };
                buf.push(rec);
                if (buf.length > capacity) buf.shift();
                finish({ hit: rec });
            };
            const t = setTimeout(() => finish({ hit: null }), ms);
            bot._client.on('window_items', w);
        });
    };
    return {
        packets: buf,
        /** 某格的整窗真值；没抓到包 = `{ok:false}`（**不返回"应该是空的"**） */
        async slotTruth(slot, ms = 1000) {
            const { hit } = await find(ms);
            if (!hit) return { ok: false, timedOut: true };
            const raw = hit.items[slot];
            return { ok: true, item: raw ? toItem(bot, raw) : null, empty: !raw, at: hit.at, whole: true };
        },
        stop: () => bot._client.removeListener('window_items', h),
    };
}

/**
 * 一步一确认的窗口点击。
 *
 * 语义（这是整个文件的核心）：
 *   发包 → **等服务端对这一次点击的判决** → 把判决带回来。
 *   - `requiresConfirmation` 的窗口（1.16.1 的 inventory/crafting_table/furnace）：
 *     走 `bot.clickWindow`，它内部已经按 action 号等真实 `transaction` 包，
 *     被拒会抛 —— 我们把那个异常**结构化**成 {accepted:false}，不当未知异常吞掉。
 *   - `requiresConfirmation=false` 的窗口（**1.16.1 的箱子**就是这样：
 *     `prismarine-windows` 对 `minecraft:container` 把 requireConfirmation 设成 false，
 *     于是 mineflayer **自己给自己发 accepted=true**、不等服务端）：不能信模型，
 *     改为「直发包 + 等服务端 set_slot 覆盖被点的那一格」。
 *   - 1.17+：没有 transaction 包，按 stateId 走，等服务端 set_slot 覆盖被点的那一格。
 *
 * 返回 {accepted, via, cursor, slot}；`accepted===false` 或 `unconfirmed===true` 都**不是**成功。
 */
export async function clickConfirmed(bot, win, { slot, mouseButton = 0, mode = 0, timeoutMs = 1500, expectSlotChange = true } = {}) {
    const flavor = clickFlavor(bot);
    const needsConfirmation = win.requiresConfirmation !== false;
    const tap = makeSlotTap(bot, win.id);

    try {
        if (flavor.transactionPacketExists && needsConfirmation) {
            // mineflayer 自己的 clickWindow：按 action 号等真实 transaction，被拒抛异常
            try {
                await bot.clickWindow(slot, mouseButton, mode);
            } catch (e) {
                const msg = String(e && e.message ? e.message : e);
                const rejected = /Server rejected transaction/.test(msg);
                return { accepted: false, rejected, via: 'transaction', error: msg.slice(0, 160), slot };
            }
            return { accepted: true, via: 'transaction', slot };
        }

        // 直发 + 等服务端覆盖该格（1.16.1 箱子 / 1.17+）
        const flavorNow = clickFlavor(bot);
        // ⚠ 必须在等回执**之前**把这一格的内容拍下来：服务端的 `set_slot` 一到，
        //   `win.slots[slot]` 就已经是新值了，到时候再拿它去 acceptClick 就等于
        //   "按结果算原因"，整步预测全错（自检 ⑧ 就是这么红的）。
        const beforeItem = win.slots[slot] ?? null;
        const pkt = windowClickPacket(bot, flavorNow, {
            windowId: win.id, slot, mouseButton, mode,
            changedSlots: [],
            item: beforeItem,
            cursorItem: win.selectedItem ?? null,
        });
        const action = pkt.params.action;
        // 只在「这个窗口本来就要 transaction 回执」时才等它。
        // requiresConfirmation=false 的窗口（1.16.1 的箱子）**按定义就收不到** transaction
        // ——mineflayer 对这类窗口是自说自话地 accepted=true。等一个永远不会来的包，
        // 只会把「等 set_slot」这一步整体推迟到包已经错过之后（自检 ⑧ 的真实教训）。
        const wantTx = flavorNow.transactionPacketExists && needsConfirmation;
        const ackP = wantTx ? waitServerTransaction(bot, win.id, action, timeoutMs) : Promise.resolve(null);
        bot._client.write(pkt.name, pkt.params);
        const ack = await ackP;
        if (ack && ack.ok && ack.accepted === false) {
            return { accepted: false, rejected: true, via: 'transaction', slot };
        }
        if (expectSlotChange) {
            const s = await waitServerSlot(bot, win.id, slot, timeoutMs);
            if (!s.ok) return { accepted: null, unconfirmed: true, via: 'set_slot', slot };
            // 服务端已确认这一格（`win.slots[slot]` 也已被 mineflayer 的 set_slot 处理器
            // 按服务端的值更新过，**不要**再拿它去 acceptClick 预测——那是"按结果算原因"）。
            // 1.16.x 唯一缺的是**光标**：线上没有 carriedItem 字段，服务端不会告诉���。
            // 光标为空 + 服务端把这一格清空 + 发包前这一格有东西 ⇒ 光标现在就是那样东西。
            // 这是**由服务端确认推导**出来的，不是凭空预测。
            if (!hasCarriedItemWire(bot) && beforeItem && !win.selectedItem && !s.item) {
                win.selectedItem = beforeItem;
            }
            return { accepted: true, via: 'set_slot', slot, item: s.item };
        }
        return { accepted: ack ? ack.accepted : null, via: 'set_slot', slot };
    } finally {
        tap.stop();
    }
}

/**
 * 直发一次 window_click，**等服务端判决之后**再决定要不要动本地模型。
 *
 * 这是 `_tableCraft` 的地基，也是「每一步等服务端确认」的字面实现：
 *   - 1.16.x：发出去时带 action 号 ⇒ 等 `transaction{action:我们那个, accepted}`。
 *     **accepted=true 才调 `win.acceptClick(...)`**（把服务端认可的预测写回本地模型，
 *     这正是 mineflayer `confirmTransaction.onAccepted` 干的事）；accepted=false 或超时
 *     ⇒ **一个字节都不改模型**，直接如实返回。
 *   - 1.17+：包里必须带 changedSlots（协议要求客户端上报预测），所以照样先 acceptClick 算差分，
 *     但随后**等服务端 set_slot 覆盖被点的那一格**再返回；没等到就是 unconfirmed。
 *
 * 关键区别（vs 旧 `_tableCraft`）：旧代码是「先 acceptClick 改模型 → 再发包 → 最多等 350ms 就走」，
 * 服务端还没说话本地就已经假定成功了；这里把顺序倒过来。
 */
export async function clickRawConfirmed(bot, win, { slot, mouseButton = 0, mode = 0, timeoutMs = 900 } = {}) {
    const flavor = clickFlavor(bot);
    const before = win.slots[slot] ?? null;
    const beforeCursor = win.selectedItem ?? null;
    const beforeSig = win.slots.map((s) => (s ? `${s.type}:${s.count}` : null));

    // 1.17+ 的 changedSlots 是协议要求（客户端预测上报），必须在写包前算出来
    let changedSlots = [];
    if (flavor.stateIdUsed) {
        win.acceptClick({ slot, mouseButton, mode, item: before });
        win.slots.forEach((s, i) => {
            const k = s ? `${s.type}:${s.count}` : null;
            if (k !== beforeSig[i]) changedSlots.push({ location: i, item: s });
        });
    }

    const pkt = windowClickPacket(bot, flavor, {
        windowId: win.id, slot, mouseButton, mode,
        changedSlots,
        item: before,
        cursorItem: beforeCursor,
    });
    const action = pkt.params.action;
    const ackP = flavor.transactionPacketExists
        ? waitServerTransaction(bot, win.id, action, timeoutMs)
        : waitServerSlot(bot, win.id, slot, timeoutMs).then((s) => (s.ok ? { ok: true, via: 'set_slot' } : { ok: false, timedOut: true }));

    bot._client.write(pkt.name, pkt.params);
    const ack = await ackP;

    if (flavor.transactionPacketExists) {
        if (!ack || !ack.ok) return { ok: false, unconfirmed: true, via: 'transaction', action, maxAction: state(bot).maxAction, timedOut: !!ack?.timedOut };
        if (ack.accepted === false) return { ok: false, rejected: true, via: 'transaction', action, maxAction: state(bot).maxAction };
        // 服务端认可 ⇒ 才把预测落到本地模型（与 mineflayer 的 onAccepted 同款）
        win.acceptClick({ slot, mouseButton, mode, id: action, windowId: win.id, item: before });
        return { ok: true, via: 'transaction', action };
    }
    if (!ack || !ack.ok) return { ok: false, unconfirmed: true, via: 'set_slot', slot, timedOut: !!ack?.timedOut };
    return { ok: true, via: 'set_slot', slot };
}

/**
 * 窗口开着的时候，**背包里的东西在 `win.slots[win.inventoryStart … win.inventoryEnd]`**，
 * 而不在 `bot.inventory` 里 —— mineflayer 的 `set_slot` 处理器按 windowId 派发
 * （inventory.js：`packet.windowId === 0 ? bot.inventory : bot.currentWindow`），
 * 所以工作台/熔炉/箱子开着时，服务端放进背包的物品只落在**那扇窗口**的镜像区。
 * ⇒ 用 `countItems(bot, …)` 判"到手没有"在窗口开着期间恒读到 0，
 *   这正是 06c 记的"背包同步慢、smeltOk 恒 0"里**真正属于本单的那一半**。
 * 本函数是窗口感知版计数，两种情形都读对。
 */
export function countItemsWindowAware(bot, name, win = null) {
    const w = win ?? bot.currentWindow;
    const inWin = (w && w.id !== 0)
        ? w.slots.slice(w.inventoryStart, w.inventoryEnd).filter((s) => s && s.name === name).reduce((s, i) => s + i.count, 0)
        : 0;
    return Math.max(countItems(bot, [name]), inWin);
}

/** 找一个能放下的背包槽（同型可堆叠优先，其次空槽）；找不到返回 -1 */
export function findDestSlot(win, item) {
    if (!item) return -1;
    for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
        const s = win.slots[i];
        if (s && s.type === item.type && s.count < s.stackSize) return i;
    }
    for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
        if (!win.slots[i]) return i;
    }
    return -1;
}

/**
 * 「自己一步步点」取产物/取输出格 —— 本文件的主原语。
 *
 * 替换掉 mineflayer 的 `putAway(2)` / `grabResult()` 这类**复合动作**：
 *   1) 点结果格 → **等服务端判决**（1.16.x：transaction 按 action 号；否则：等该格 set_slot）
 *   2) **从服务端包**确认光标上真的有东西（不是 `selectedItem` 的客户端预测）
 *   3) 点背包目标格 → 同样等服务端判决
 *   4) 最后按**背包增量**再确认一次（手册 §3 的老规矩，兜底）
 *
 * opts.expectName：期望拿到的物品名（服务端真值比对，不符即判失败，绝不"差不多就行"）
 * 返回 {ok, took, gained, reason, verdict}
 */
/**
 * 1.16.x 的协议里**根本没有光标（carried item）这个字段**。
 * 证据（本单 dump 的 minecraft-data 定义）：
 *   1.16.1 `window_items` = `{windowId:u8, items:array}`      ← **没有 carriedItem**
 *   1.17.1 `window_items` = `{windowId, stateId, items, carriedItem}`  ← 1.17 才加
 *   两个版本的 `set_slot` 都只有 `{windowId, slot, item}`，没有"光标"专用的槽位定义。
 * ⇒ 在 1.16.1 上，**光标的内容永远不会被服务端单独告知**，`set_slot(-1)` 不会来。
 *   实服证据 T09_FURN3：点击输出格被 accepted、输出格 `set_slot` 清零，
 *   但 `cursorTruth()` 永远等不到 slot=-1 ⇒ 取件 0/30。
 * ⇒ 所以 1.16.x 的"逐步确认"里，**光标这一步在物理上无法独立确认**，
 *   最强的可得确认是三件事的合取：
 *     ① 那一次点击被服务端 `transaction{accepted:true}` 认可；
 *     ② 目标格（背包格）拿到了**服务端 `set_slot`**；
 *     ③ 窗口感知的背包增量真的到账。
 *   光标读本地 `win.selectedItem` —— 在 1.16.x 且 `requiresConfirmation=true` 的窗口上，
 *   它是被 `confirmTransaction.onAccepted`（服务端 accepted 之后）赋值的，
 *   **不是纯客户端预测**，可以当作中间量用；但**不能**当作最终判据。
 * 1.17+ 有 carriedItem，才走严格的 `set_slot(-1)` 确认。
 */
export function hasCarriedItemWire(bot) {
    // stateIdUsed = 1.17+；1.16.x（actionIdUsed）为 false
    return !clickFlavor(bot).actionIdUsed;
}

export async function takeFromSlotConfirmed(bot, win, slot, opts = {}) {
    const { timeoutMs = 2000, expectName = null, invBefore = null, itemName = null } = opts;
    const flavor = clickFlavor(bot);
    const strictCursor = hasCarriedItemWire(bot);
    const tap = makeSlotTap(bot, win.id, 96);

    // 起点：光标必须为空，否则这一步是「交换」而不是「拿起」（ROUND3-A §5 的真凶）
    if (win.selectedItem) {
        return { ok: false, reason: 'cursor_not_empty', held: `${win.selectedItem.name}x${win.selectedItem.count}` };
    }
    const before = itemName ? countItemsWindowAware(bot, itemName, win) : (invBefore ?? null);

    try {
        // ── 步骤 1：点结果格，等服务端判决 ──
        const v1 = await clickConfirmed(bot, win, { slot, mouseButton: 0, mode: 0, timeoutMs });
        if (v1.accepted === false) return { ok: false, reason: 'server_rejected', verdict: v1 };
        if (v1.unconfirmed) return { ok: false, reason: 'no_server_ack', verdict: v1 };

        // ── 步骤 2：确认"产物到手了" ──
        let cursorItem = null;
        let cursorHow = null;
        if (strictCursor) {
            // 1.17+：光标有线上表示，只认服务端 set_slot(-1)
            const cur = await tap.cursorTruth(timeoutMs);
            if (!cur.ok) return { ok: false, reason: 'cursor_empty_from_server', verdict: v1 };
            cursorItem = cur.item;
            cursorHow = 'set_slot(-1)';
        } else {
            // 1.16.x：线上没有光标字段，只能用"被 accepted 之后才被赋值的"本地 selectedItem
            cursorItem = win.selectedItem ?? null;
            cursorHow = 'selectedItem(after accepted)';
            if (!cursorItem) return { ok: false, reason: 'no_cursor_after_accept', verdict: v1 };
        }
        if (expectName && cursorItem.name !== expectName) {
            return { ok: false, reason: 'cursor_wrong_item', got: cursorItem.name, want: expectName };
        }

        // ── 步骤 3：点背包目标格，再等一次服务端判决 ──
        const dest = findDestSlot(win, cursorItem);
        if (dest < 0) return { ok: false, reason: 'inventory_full', got: `${cursorItem.name}x${cursorItem.count}` };
        const v2 = await clickConfirmed(bot, win, { slot: dest, mouseButton: 0, mode: 0, timeoutMs });
        if (v2.accepted === false) return { ok: false, reason: 'server_rejected_dest', verdict: v2, took: cursorItem.count };
        if (v2.unconfirmed) return { ok: false, reason: 'no_server_ack_dest', verdict: v2, took: cursorItem.count };

        // ── 步骤 4：窗口感知的背包增量兜底（1.16.x 上这才是最终判据）──
        let gained = 0;
        if (itemName) {
            const dl = Date.now() + timeoutMs;
            gained = countItemsWindowAware(bot, itemName, win) - before;
            while (gained <= 0 && Date.now() < dl) { await sleep(120); gained = countItemsWindowAware(bot, itemName, win) - before; }
            if (gained <= 0) {
                return { ok: false, reason: 'no_inv_delta', took: cursorItem.count, dest, verdict: [v1, v2] };
            }
        }
        return { ok: true, took: cursorItem.count, gained: Math.max(0, gained), dest, cursorHow, verdict: [v1, v2], flavor };
    } finally {
        tap.stop();
    }
}

/**
 * 发一次 window_click，`item` 字段填**光标**（协议里这一位叫 carried item）。
 *
 * ── 为什么不能直接用 `bot.clickWindow` 发 QUICK_MOVE ──
 * 1.16.1 服务端回执的判据是 `ItemStack.matches(包的carried, 点击后服务端光标)`
 * （`ServerGamePacketListenerImpl.handleContainerClick` :1180）。
 * 对 QUICK_MOVE，`AbstractContainerMenu.b(...)` 那个分支**从头到尾没有给返回值赋过非空**，
 * 最后 `return itemstack`（:400）返回的是**初始值 EMPTY** ⇒ 服务端认定"点击后光标是空的"。
 * 而 mineflayer 的 `clickWindow` 把 `item` 填成**被点那一格里的东西**（`click.item = window.slots[slot]`，
 * inventory.js:571/626）——shift 点输出格时那就是**产物本身**。
 * 于是 `matches(产物, 空)` = false ⇒ **服务端回 accepted=false** 并整窗重发，
 * 一次 shift 点击都别想成功。（这就是"用 mineflayer 原生 API 做 shift 取件"在 1.16.1 上的死结。）
 *
 * 对 PICKUP 恰好相反：点输出格时"格里的东西"正好等于"点击后光标里的东西"，所以那个错填
 * 一直蒙对了——这正是 TASK-09 里两次点击都 accepted、产物却没进背包的嫌疑点之一。
 *
 * ⇒ 本函数把 `item` 填成**当前光标**（`win.selectedItem`），这才是协议要的东西。
 * 仍然按 action 号等服务端真回执，accepted 之后才 `acceptClick` 落本地模型。
 */
export async function clickCursorClaimConfirmed(bot, win, { slot, mouseButton = 0, mode = 0, timeoutMs = 1200, applyLocal = true } = {}) {
    const flavor = clickFlavor(bot);
    const cursor = win.selectedItem ?? null;
    const before = win.slots[slot] ?? null;

    let changedSlots = [];
    if (flavor.stateIdUsed) {
        // 1.17+：包里必须带 changedSlots（客户端预测上报）——先拍签名再算差分
        const sig0 = win.slots.map(slotSig);
        win.acceptClick({ slot, mouseButton, mode, item: before });
        win.slots.forEach((s, i) => { if (slotSig(s) !== sig0[i]) changedSlots.push({ location: i, item: s }); });
    }

    const pkt = windowClickPacket(bot, flavor, {
        windowId: win.id, slot, mouseButton, mode, changedSlots,
        item: cursor,                 // ← 光标，不是被点那一格
        cursorItem: cursor,
    });
    const action = pkt.params.action;
    const ackP = flavor.transactionPacketExists
        ? waitServerTransaction(bot, win.id, action, timeoutMs)
        : waitServerSlot(bot, win.id, slot, timeoutMs).then((s) => (s.ok ? { ok: true, via: 'set_slot' } : { ok: false, timedOut: true }));

    bot._client.write(pkt.name, pkt.params);
    const ack = await ackP;

    if (flavor.transactionPacketExists) {
        if (!ack || !ack.ok) return { ok: false, unconfirmed: true, via: 'transaction', action, timedOut: !!ack?.timedOut };
        if (ack.accepted === false) return { ok: false, rejected: true, via: 'transaction', action };
        if (applyLocal) win.acceptClick({ slot, mouseButton, mode, id: action, windowId: win.id, item: before });
        return { ok: true, via: 'transaction', action };
    }
    if (!ack || !ack.ok) return { ok: false, unconfirmed: true, via: 'set_slot', slot, timedOut: !!ack?.timedOut };
    return { ok: true, via: 'set_slot', slot };
}

/**
 * 等**服务端**确认「产物进了背包的哪一格」。
 *
 * ⚠ TASK-10：这里**必须同时认两条服务端通道**，只等 `set_slot` 永远等不到。
 * 1.16.1 一次被 accepted 的点击，服务端走的是
 *   `ServerPlayer.handleContainerClick` :1181-1185：
 *       send(Ack(true)); ignoreSlotUpdateHack = **true**; menu.broadcastChanges(); broadcastCarriedItem(); = false
 * 而 `broadcastChanges()` = `ServerPlayer.a(menu, menu.getItems())`（:941-948）发的是
 *   **整窗 `window_items`（ClientboundContainerSetContentPacket） + 一条 set_slot(-1,-1) 光标包**；
 * 逐格 `set_slot`（`ServerPlayer.a(menu,int,ItemStack)` :929-939）被 `ignoreSlotUpdateHack` **整个抑制**。
 * ⇒ 点击被 accepted 之后，客户端能拿到的服务端真值是**整窗数组**，不是逐格包。
 *   只等逐格 set_slot 的判据在这条路径上是**结构性等不到**（又一个"超时不是证据"的坑）。
 *
 * 返回 {ok, slot, item, via}：
 *   via='window_items' —— 从整窗数组里找出与点击前签名不同、且装着期望物品的那一格；
 *   via='set_slot'     —— 服务端确实逐格发了（别的路径/别的版本）。
 */
export function waitServerInventoryUpdate(bot, win, { timeoutMs = 2000, beforeSig = null, expectName = null } = {}) {
    const invSig = (items) => {
        const sig = {};
        for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
            const it = items?.[i] ? toItem(bot, items[i]) : (win.slots[i] ?? null);
            sig[i] = slotSig(it);
        }
        return sig;
    };
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => { if (!done) { done = true; bot._client.removeListener('set_slot', h1); bot._client.removeListener('window_items', h2); clearTimeout(timer); resolve(v); } };
        const accept = (it, slot, via) => {
            if (!it) return;
            if (expectName && it.name && it.name !== expectName) return;
            if (beforeSig && beforeSig[slot] === slotSig(it)) return;   // 与点击前一样 ⇒ 不是这次点击带来的
            finish({ ok: true, slot, item: it, via });
        };
        const h1 = (p) => {
            if (p.windowId !== win.id || isCursorPacket(p)) return;
            if (!(p.slot >= win.inventoryStart && p.slot < win.inventoryEnd)) return;
            accept(toItem(bot, p.item), p.slot, 'set_slot');
        };
        const h2 = (p) => {
            if (p.windowId !== win.id || !p.items) return;
            const sig = invSig(p.items);
            for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
                if (beforeSig && beforeSig[i] === sig[i]) continue;      // 没变
                const it = toItem(bot, p.items[i]);
                if (it) { accept(it, i, 'window_items'); return; }
            }
        };
        const timer = setTimeout(() => finish({ ok: false, timedOut: true }), timeoutMs);
        bot._client.on('set_slot', h1);
        bot._client.on('window_items', h2);
    });
}

/**
 * ── MC-M1-TASK-10：熔炉取产物改 **shift 点击（mode=1 / QUICK_MOVE）** ──
 *
 * 为什么换掉"点输出格 → 再点背包格"那两步：
 *   那条路**必然经过光标**。1.16.1 服务端 `AbstractFurnaceMenu.b(Player,int)`
 *   （quickMoveStack，:97-143）对 index==2 有**专门分支**：
 *       if (index == 2) { if (!this.moveItemStack(itemstack, 3, 39, true)) return EMPTY; slot.remove(itemstack); }
 *   ——**整摞直接进背包槽 3..39，光标全程不参与**。这条路径上"产物停在光标"这个失效模式
 *   结构上不存在，也就不需要去和"客户端/服务端光标是否分叉"搏斗。
 *
 * 判据（**每一步都要服务端真值**，不接受"点了就当成功"）：
 *   ① 那一次 shift 点击拿到服务端 `transaction{accepted:true}`（1.16.x 唯一真回执）；
 *   ② 背包区出现**服务端** set_slot（`waitServerInventoryUpdate`）——不是客户端模型自说自话；
 *   ③ 窗口感知的背包增量真的到账；
 *   ④ **产物不经光标**：从点击到增量到账这段时间内，服务端光标包（-1,-1）里没有出现产物。
 *      这条是本原语与旧原语的结构性区别，作为不变量一起断言。
 * 返回 {ok, took, gained, dest, cursorUntouched, verdict, reason}
 */
export async function takeFurnaceOutputQuickMove(bot, furnace, opts = {}) {
    const { timeoutMs = 2500, expectName = null, itemName = null } = opts;
    const win = furnace.window ?? furnace;
    if (!win || win.id == null) return { ok: false, reason: 'no_furnace_window' };

    // 服务端真值先问一遍：输出格到底有没有东西（不信客户端模型的 outputItem）
    const out = win.slots[2];
    if (!out || out.count <= 0) return { ok: false, reason: 'output_empty' };
    const outName = out.name ?? null;
    if (expectName && outName && outName !== expectName) {
        return { ok: false, reason: 'output_wrong_item', got: outName, want: expectName };
    }
    const item = itemName ?? outName;

    // 起点：光标必须为空。shift 点击在光标非空时语义完全不同（会把光标物丢出去/交换）。
    if (win.selectedItem) {
        return { ok: false, reason: 'cursor_not_empty', held: `${win.selectedItem.name}x${win.selectedItem.count}` };
    }

    // 背包放不下就别点。服务端 `AbstractFurnaceMenu.b(Player,int)` 对 index==2 是
    // 「先 moveItemStack(3,39)，失败就原样返回 EMPTY」⇒ 输出格**不会被清空**，
    // 也就是说点下去不会有任何副作用，但会留下一条读不出所以然的失败。
    // 这里提前判掉，理由写成人能看懂的 `inventory_full`（06c 的 `destination full` 同族）。
    if (item) {
        let room = false;
        for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
            const s = win.slots[i];
            if (!s) { room = true; break; }
            if (s.name === outName && s.count < s.stackSize) { room = true; break; }
        }
        if (!room) return { ok: false, reason: 'inventory_full', want: item };
    }

    const before = item ? countItemsWindowAware(bot, item, win) : null;
    const beforeSig = inventorySignature(win);
    const tap = makeSlotTap(bot, win.id, 128);

    try {
        const clickAt = Date.now();
        // ⚠⚠ 判据②的监听器必须在**点击之前**挂上。
        //   服务端在 accepted 路径里是「先发 Ack、再 broadcastChanges（整窗 window_items）」，
        //   两个包通常在同一个 TCP 段里到达 ⇒ 等 clickCursorClaimConfirmed 的回执 resolve
        //   **之后**再挂监听，整窗包早就被 mineflayer 派发掉了。
        //   实测证据：① 那轮 quickMove 的 dest 全是 null（而 gained>0 所以没判失败）
        //   ——判据② 整条是死代码，服了但没证据。
        const srvP = waitServerInventoryUpdate(bot, win, { timeoutMs, beforeSig, expectName: item });
        // ① shift 点击输出格；`item` 填光标（空）——见 clickCursorClaimConfirmed 的注释
        const v = await clickCursorClaimConfirmed(bot, win, { slot: 2, mouseButton: 0, mode: 1, timeoutMs });
        if (!v.ok) return { ok: false, reason: v.rejected ? 'server_rejected' : 'no_server_ack', verdict: v };

        // ② 服务端确认产物进了背包的哪一格（1.16.1 上是整窗 window_items，不是逐格 set_slot）
        const srv = await srvP;
        // ③ 窗口感知的背包增量
        let gained = 0;
        if (item) {
            const dl = Date.now() + timeoutMs;
            gained = countItemsWindowAware(bot, item, win) - before;
            while (gained <= 0 && Date.now() < dl) { await sleep(100); gained = countItemsWindowAware(bot, item, win) - before; }
        }
        // ④ 不变量：这段时间里光标**没有**拿到产物
        const cursorPackets = tap.since(Date.now() - clickAt).filter(isCursorPacket);
        const cursorGotProduct = cursorPackets.some((p) => {
            const it = toItem(bot, p.item);
            return it && (it.name === item || (item == null && it.name));
        });
        if (cursorGotProduct) {
            return { ok: false, reason: 'cursor_got_product', cursor: cursorPackets.map((p) => slotSig(toItem(bot, p.item))), srv, gained };
        }
        if (!srv.ok && gained <= 0) {
            return { ok: false, reason: 'no_server_inv_slot', gained, verdict: v, cursorPackets: cursorPackets.length };
        }
        if (item && gained <= 0) return { ok: false, reason: 'no_inv_delta', gained, srv, verdict: v };
        return {
            ok: true, took: srv.item?.count ?? out.count, gained: Math.max(0, gained),
            dest: srv.slot ?? null, destVia: srv.via ?? null,
            cursorUntouched: true, cursorPackets: cursorPackets.length,
            srv, verdict: v,
        };
    } finally {
        tap.stop();
    }
}

/**
 * 熔炉取产物的**生产入口**。MC-M1-TASK-10 起主用 shift 点击（不经光标），
 * 失败时才回退到"点输出格 → 点背包格"那两步（仍保留，用于对照与诊断）。
 *
 * 回退只在**服务端明确拒收**（rejected / no_server_ack）时发生——那说明这条炉子/
 * 这一局的窗口状态本身有问题，再点一次不会更好；而 `no_inv_delta` 这类
 * "点了但没到账"的情况**不回退**（重复点击只会让光标状态更乱，正是要治的病）。
 */
export async function takeFurnaceOutputConfirmed(bot, furnace, opts = {}) {
    const win = furnace.window ?? furnace;
    if (!win || win.id == null) return { ok: false, reason: 'no_furnace_window' };
    const out = win.slots[2];
    if (!out || out.count <= 0) return { ok: false, reason: 'output_empty' };

    const via = opts.via ?? 'auto';
    if (via === 'pickup' || via === 'two-step') {
        return takeFromSlotConfirmed(bot, win, 2, { ...opts, expectName: opts.expectName ?? null });
    }

    const quick = await takeFurnaceOutputQuickMove(bot, furnace, opts);
    if (quick.ok || via === 'quickmove') return quick;

    // 只有"服务端拒收"才值得换协议再试一次
    if (quick.reason !== 'server_rejected' && quick.reason !== 'no_server_ack') return quick;
    const two = await takeFromSlotConfirmed(bot, win, 2, { ...opts, expectName: opts.expectName ?? null });
    if (two.ok) return { ...two, fellBackFrom: 'quickmove', quickReason: quick.reason };
    return { ...two, quickAttempt: quick };
}

/**
 * 开箱取物（1.16.1 的箱子是 `requiresConfirmation=false` 的那一类，必须走服务端确认）。
 * items: [{name?, type?}]；只取匹配项，逐格取、逐格确认。
 * 返回 {ok, taken:[{name,count}], failed:[{slot,reason}]}
 */
export async function withdrawFromContainerConfirmed(bot, container, match, opts = {}) {
    const { timeoutMs = 2000, maxSlots = 27 } = opts;
    const win = container.window ?? container;
    if (!win || win.id == null) return { ok: false, taken: [], failed: [{ slot: -1, reason: 'no_window' }] };
    const taken = [], failed = [];
    // 逐格扫容器区（inventoryStart 之前都是容器自己的格子）
    for (let slot = 0; slot < win.inventoryStart && slot < maxSlots; slot++) {
        const s = win.slots[slot];
        if (!s) continue;
        if (!match(s)) continue;
        const name = s.name;
        const before = countItems(bot, [name]);
        const r = await takeFromSlotConfirmed(bot, win, slot, { timeoutMs, expectName: name, itemName: name });
        if (r.ok) taken.push({ name, count: r.took, slot });
        else failed.push({ slot, name, reason: r.reason, verdict: r.verdict ?? null });
    }
    return { ok: failed.length === 0, taken, failed };
}

// ═══════════════════════════════ MC-M1-TASK-09-r4 ═══════════════════════════════
//
// r3 钉死的病根是"**取料区间**"，但病根的**形状**在这一单被更正了一次，两处都要写清楚：
//
// ① r3 的机制描述是"1.16.1 open_window 没有 slotCount ⇒ prismarine-windows 套默认
//    `{27,62}`"。**这个机制描述不完整**：离线实测（window_ops_selftest 用例 ①）
//    `createWindow(id,'minecraft:furnace',title,undefined)` 给出的是
//    `slots=39 / inventoryStart=3 / inventoryEnd=39` —— **完全正确**。区间坏掉不是因为
//    "认不出窗口类型"，而是 mineflayer 把**协议里的 `inventoryType` 数字**原样传进去，
//    而 prismarine-windows 的 `windowByType` 用的是**它自己编的一套号**
//    （village&pillage 分支：inventory=0 / generic_9x1=1 / … / crafting=12 / furnace=14），
//    1.16.1 服务端发的是**另一套号**（手册 §3 已记：3×3 工作台服务端实发 11）。
//    ⇒ 号对不上时 `winData` 查不到 → 走 `createWindow` 的兜底分支，
//      `inventory: {start: slotCount, …}` 用上了**未定义的 slotCount** 或默认值，
//      于是出现 r3 观测到的 `slots=39 / inventoryStart=27 / inventoryEnd=63` 这种
//      "槽数对、区间错"的**混搭**（27..38 恰好落在真背包区 3..38 里 ⇒ 取件通道一直蒙对，
//      取料通道丢掉 3..26 共 24 格）。
//
// ② 所以本单**不再猜窗口类型**，改成从**服务端 window_items 的数组长度**推区间：
//    1.16.1 一次被 accepted 的点击，服务端走
//    `ServerPlayer.handleContainerClick :1181-1185`（send Ack → ignoreSlotUpdateHack=true
//    → menu.broadcastChanges() → broadcastCarriedItem()），
//    `broadcastChanges()` 发的是**整窗 `window_items`**（逐格 set_slot 被抑制）。
//    ⇒ 数组长度 = 菜单真实槽数，**与 prismarine-windows 认没认对类型完全无关**。
//
// ③ `clickCarryConfirmed`：发包时 `item` 字段填 **`menu.clicked()` 的返回值**，
//    也就是**被点那一格的点击前内容**（空格 ⇒ `{present:false}`）—— 见 `predictClickedReturn`。
//    ⚠ r4 在这条上写的是"填点击后服务端光标应有的值"，**那是错的**：光标是 `☃x.m()`，
//    它不参与返回值；`AbstractContainerMenu.java:159` 的初值是 `ItemStack.EMPTY`，
//    `:256` 只在**被点那格非空**时才赋成那格的拷贝。
//    ⇒ r4 实跑 9 条 `craft_no_gain` 里的 `place_rejected` 就是这么来的：
//      右键把 1 个原木放进**空的** 2×2 格，正确值是空，上报的是光标 `oak_log×5`。
//    这也是 06c 基线 `Server rejected transaction for clicking on slot 0, on window with id 0`
//    的机制来源。
//
// ④ 一次被拒必须**立刻回 transaction 道歉**（`ServerGamePacketListenerImpl.java:1189`
//    的 `setSynched(false)` 会让 `:1169` 的闸门从此静默吞掉本窗口的所有点击）——
//    见 `apologizeAndResync`。
//
// 口径：**每一步等服务端确认，且一个字节都不主动写窗口模型**（1.16.x 路径不调
// `win.acceptClick`）—— 服务端 accepted 之后必然广播整窗，mineflayer 的处理器会把
// 服务端的值写进模型，模型因此**只被服务端回包驱动**。

const SLOTCOUNT_KEY = Symbol.for('aidqq.windowOps.slotCount');
function slotCountState(bot) {
    if (!bot[SLOTCOUNT_KEY]) {
        bot[SLOTCOUNT_KEY] = { byWindow: new Map() };
        const st = bot[SLOTCOUNT_KEY];
        bot._client.on('window_items', (p) => {
            if (p && typeof p.windowId === 'number' && Array.isArray(p.items)) st.byWindow.set(p.windowId, p.items.length);
        });
    }
    return bot[SLOTCOUNT_KEY];
}

/** 窗口真实槽数：服务端 window_items 优先；没有快照才退回 prismarine 的 slots.length */
export function windowSlotCount(bot, win) {
    if (!win) return 0;
    const st = slotCountState(bot);
    const srv = st.byWindow.get(win.id);
    if (typeof srv === 'number' && srv > 0) return srv;
    return win.slots?.length ?? 0;
}

/** 该窗口槽数的来源，遥测用（要能区分"服务端量到的"和"库猜的"） */
export function slotCountSource(bot, win) {
    if (!win) return 'no_window';
    return slotCountState(bot).byWindow.has(win.id) ? 'window_items' : 'prismarine_slots';
}

/**
 * 玩家背包在窗口里的槽区间。**本单起，任何代码都不许再直接读 `win.inventoryStart/End`。**
 *
 *   - window 0（`bot.inventory`，玩家自己的 2×2 菜单）：主背包 9…35 + 快捷栏 36…44。
 *     这与本仓既有口径一致（`countItems(bot,…)` 走 `bot.inventory.items()`，
 *     几百局 craft_ok / acquire 都建立在它上面），不重新定义。
 *   - 其它容器菜单：原版一律"玩家的 36 格在最后" ⇒ start = 槽数 − 36。
 *     熔炉 39 ⇒ 3…38；工作台 46 ⇒ 10…45；箱子 63 ⇒ 27…62。
 */
export function playerInvRange(bot, win) {
    if (!win) return null;
    if (win.id === 0) return { start: 9, end: 45, hotbarStart: 36, via: 'window0' };
    const n = windowSlotCount(bot, win);
    if (!n || n < 36) return null;
    const start = n - 36;
    return { start, end: n, hotbarStart: start + 27, via: slotCountSource(bot, win) };
}

/** 区间内按名字计数（窗口感知，且区间是本单自己的口径，不吃 prismarine 的坏区间） */
export function countItemsInRange(bot, win, range, name) {
    if (!win || !range) return 0;
    let n = 0;
    for (let i = range.start; i < range.end; i++) {
        const s = win.slots[i];
        if (s && s.name === name) n += s.count;
    }
    return n;
}

/** 玩家背包区里第一个装着 `name` 的槽；找不到返 -1 */
export function findInPlayerRange(win, range, name) {
    if (!win || !range) return -1;
    for (let i = range.start; i < range.end; i++) {
        const s = win.slots[i];
        if (s && s.name === name) return i;
    }
    return -1;
}

function itemFactory(bot) {
    if (!bot[ITEM_FACTORY_KEY]) bot[ITEM_FACTORY_KEY] = prismarineItem(bot.registry);
    return bot[ITEM_FACTORY_KEY];
}

/** 造一个"同物不同数量"的物品（预测点击后服务端光标内容用） */
export function itemWithCount(bot, it, count) {
    if (!it) return null;
    if (count <= 0) return null;
    // ⚠ prismarine-item@1.16.1 返回的是**类**，必须 `new`；写成函数调用会抛
    //   "Class constructor Item cannot be invoked without 'new'"（离线自检 ③ 抓到的）
    const Factory = itemFactory(bot);
    return new Factory(it.type, count, it.metadata ?? 0, it.nbt);
}

/**
 * 等**服务端**给这几格的权威内容。
 * 两条通道都认（1.16.1 被 accepted 的点击只发整窗 `window_items`，
 * 逐格 `set_slot` 会被 `ignoreSlotUpdateHack` 抑制 —— 见 TASK-10 的注释）：
 *   - `set_slot`（命中请求的任一格，且已凑齐请求的格数时才提前收口）
 *   - `window_items`（整窗，一次给全）
 * ⚠ **监听器必须在点击之前挂上**（window_ops.js:762-767 的实服教训）。
 */
/**
 * 等"服务端把这一窗口的模型刷新了"——**整窗 `window_items` 或任意一格 `set_slot` 都算**。
 *
 * ⚠⚠ 为什么不能只等 `window_items`（本单实跑 T09R5B/C 抓到的真 bug）：
 *   抓包原文（`runs/T09R5_DBG`）：window 0 上一次被 accepted 的点击之后，
 *   **服务端一条 `window_items` 都不发**，模型是靠**逐格 `set_slot`** 更新的
 *   （实测时间轴：action 2/3/4 三次 accepted 之后 0 条 window_items，
 *     直到第 5 次被拒，才出现 1 条 `window_items n=46` —— 那是拒收路径发的）。
 *   ⇒ 任何"等整窗包来刷新模型"的写法，在 **window 0（玩家自己的 2×2 菜单）上永远等不到**，
 *     于是模型停在上一击之前，下一击的 `item` 预测就用陈旧数据 ⇒ 被拒。
 *   这正是 T09R5B 那 30/30 `putback_rejected` 的成因（详见 `clickCarryConfirmed` 的注释）。
 *
 *   顺带更正 r4 的一条说法：r4 注释写"1.16.1 被 accepted 的点击必发整窗 `window_items`"
 *   —— **对容器窗口成立，对 window 0 不成立**。
 *
 * @returns {ok:true, via:'window_items'|'set_slot'} 或 {ok:false, timedOut:true}
 */
export function waitServerWindowSync(bot, win, { timeoutMs = 2000 } = {}) {
    let done = false, cancel = () => {};
    const p = new Promise((resolve) => {
        const finish = (v) => {
            if (done) return;
            done = true;
            bot._client.removeListener('set_slot', h1);
            bot._client.removeListener('window_items', h2);
            clearTimeout(timer);
            resolve(v);
        };
        cancel = () => finish({ ok: false, cancelled: true });
        // 光标包（windowId = -1）不是窗口模型，别把它当刷新
        const h1 = (p) => { if (p.windowId === win.id) finish({ ok: true, via: 'set_slot', slot: p.slot }); };
        const h2 = (p) => { if (p.windowId === win.id && Array.isArray(p.items)) finish({ ok: true, via: 'window_items', slotCount: p.items.length }); };
        const timer = setTimeout(() => finish({ ok: false, timedOut: true }), timeoutMs);
        bot._client.on('set_slot', h1);
        bot._client.on('window_items', h2);
    });
    p.cancel = () => { try { cancel(); } catch { /* 忽略 */ } };
    return p;
}

export function waitServerWindowSlots(bot, win, slots, { timeoutMs = 2000 } = {}) {
    const want = Array.from(new Set(slots));
    const wantSet = new Set(want);
    // 预置为 null（不是 undefined）：**"服务端说这一格是空的"与"服务端没说过"必须能分开**
    // —— 后者看返回值的 `ok`/`timedOut`。留 undefined 会让 `out[s] ?? null` 这类写法
    // 把两种情况折算成同一个"空"，这正是手册 §5 点名的"把未知折算成否"。
    const out = {};
    for (const s of want) out[s] = null;
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => {
            if (done) return;
            done = true;
            bot._client.removeListener('set_slot', h1);
            bot._client.removeListener('window_items', h2);
            clearTimeout(timer);
            resolve(v);
        };
        const h1 = (p) => {
            if (p.windowId !== win.id || !wantSet.has(p.slot)) return;
            out[p.slot] = toItem(bot, p.item);
            if (want.every((s) => s in out)) finish({ ok: true, via: 'set_slot', slots: out });
        };
        const h2 = (p) => {
            if (p.windowId !== win.id || !Array.isArray(p.items)) return;
            for (const s of want) out[s] = p.items[s] ? toItem(bot, p.items[s]) : null;
            finish({ ok: true, via: 'window_items', slots: out, slotCount: p.items.length });
        };
        const timer = setTimeout(() => finish({ ok: false, timedOut: true, slots: out }), timeoutMs);
        bot._client.on('set_slot', h1);
        bot._client.on('window_items', h2);
    });
}

/**
 * ── 预测 1.16.1 服务端 `menu.clicked(...)` 的**返回值**（`item` 字段必须等于它）──
 *
 * 判据在 `ServerGamePacketListenerImpl.java:1179-1180`：
 *   `ItemStack ☃ = bw.a(slot, button, mode, player);  if (ItemStack.matches(pkt.f(), ☃))`
 * 比的是**包里的 `item` 字段**与 **`clicked()` 的返回值**。
 *
 * 源码依据（`AbstractContainerMenu.java`，逐行核过）：
 *  · `:159` `ItemStack ☃ = ItemStack.EMPTY;` ——— 返回值的**初值就是空**；
 *  · `:221` 只有 `(button==0 || button==1)` 的 PICKUP / QUICK_MOVE 会给它赋非空值；
 *  · `:246-257` **PICKUP**：`if (!slotItem.isEmpty()) ☃ = slotItem.copy();`
 *    ⇒ 返回**被点那一格点击前的内容**；格子原本为空则 `☃` 从未被赋值 ⇒ **返回空**；
 *  · `:233-245` **QUICK_MOVE**：`for (s = quickMoveStack(slot); !s.isEmpty() && isSame(槽内容,s); s = quickMoveStack(slot)) ☃ = s.copy();`
 *    ⇒ 返回**被移动那摞的拷贝**。而各菜单的 `quickMoveStack` 返回的是**搬动前那摞的整份拷贝**
 *    （`InventoryMenu.quickMoveStack` 对 index==0 直接 `return itemstack1`；
 *      `AbstractFurnaceMenu.b(Player,int):102` 先 `☃ = ☃xx.copy()` 再搬），
 *    搬动量为 0 时 `AbstractFurnaceMenu:135 if (☃xx.getCount() == ☃.getCount()) return EMPTY`
 *    ⇒ **"没搬动"一律返回空**。
 *
 * ⇒ 规则压成一句：**`item` = 被点那一格的点击前内容；那一格为空、或这次没搬动东西，就报空。**
 *
 * ⚠⚠ **这和"点击后的光标"是两个不同的东西。** r3/r4 一直把 `item` 填成"点击后光标应有值"，
 *   那填的是**光标**，而 1.16.1 的 `window_click` 只有一个 item 字段、服务端只拿它跟
 *   `clicked()` 的返回值比 ⇒ **填光标必被拒**。这正是 r4 实跑 `place_rejected` 的成因：
 *   右键把 1 个原木放进空的 2×2 格，正确值是 `{present:false}`（空），而当时上报的是
 *   `oak_log×5`（光标）。
 *   ⇒ 本函数**取代**了旧的 `carryAfter` 入参：调用方不再有"填什么"的选择权。
 *
 * @param win    窗口（其 `slots` 由**服务端回包**驱动 —— 1.16.x 路径一个字节都不写本地模型）
 * @param slot   被点的槽（负数 = 点窗口外，THROW ⇒ 返回空）
 * @param mode   0 = PICKUP（左/右键），1 = QUICK_MOVE（shift）
 * @param expectMove  QUICK_MOVE 时是否预期真的搬动了东西（false ⇒ 返回空）
 * @param sourceDrained  QUICK_MOVE 后**被点格是否已被搬空**（默认 true = 常态）
 *
 * 🚨🚨 **r6 更正：QUICK_MOVE（shift）的返回值规则此前写错了，这一行就是 r5 实跑 0/30 的病根。**
 *
 *   源码：`AbstractContainerMenu.java:243`
 *     `for (ItemStack s = quickMoveStack(slot); !s.isEmpty() && ItemStack.isSame(slot.getItem(), s); s = quickMoveStack(slot)) ☃ = s.copy();`
 *   而 1.16.1 的 `ItemStack.isSame`（同目录 `ItemStack.java`，本单逐行核过）是：
 *     `if (a == b) return true; else return !a.isEmpty() && !b.isEmpty() ? a.sameItem(b) : false;`
 *     `sameItem(other)` = `!this.isEmpty() && this.getItem() == other.getItem()` —— **只比物品种类**。
 *   ⇒ **只要有一边为空，`isSame` 就是 false，循环体一次都不执行，`☃` 停在初值 EMPTY。**
 *   而熔炉的 `quickMoveStack`（`AbstractFurnaceMenu:102`）返回的是**搬动前那摞的整份拷贝**。
 *   所以 shift 点一个会**被搬空**的源格时：服务端算出的 `clicked()` 返回值是 **EMPTY**，
 *   **不是**那一摞本身。
 *   ⇒ r5 报的 `sentItem="iron_orex3"`（整摞）与服务端的 EMPTY 不符 ⇒ **每一次都被拒**（0/30）。
 *   ⚠ 那一击**已经生效了**（`clicked()` 先执行再比对，r5 §3.5 自己记过这条）——所以历史上
 *   "装料 0/30" 与"矿石其实进了炉子"是同时成立的。
 *   ⇒ 只有**部分搬运**（源格还剩同类物品）才会返回那一摞的拷贝。
 *   ⇒ **本项目不再用 QUICK_MOVE 搬运**：一律改走两次 PICKUP（`pickupStackToSlot`），
 *     PICKUP 的返回值规则不含 `isSame`，完全可预测。
 */
export function predictClickedReturn(win, { slot, mode = 0, expectMove = true, sourceDrained = true } = {}) {
    if (typeof slot !== 'number' || slot < 0) return null;   // THROW / 越界 ⇒ EMPTY
    if (mode === 1) {
        if (!expectMove) return null;                        // 明知搬不动 ⇒ EMPTY
        return sourceDrained ? null : (win.slots[slot] ?? null);  // 见上面 r6 更正
    }
    return win.slots[slot] ?? null;                          // 空格 ⇒ null（即 EMPTY）
}

/**
 * ── 一次被拒之后**立刻道歉**（1.16.1 源码的硬要求，r5 新增）──
 *
 * `ServerGamePacketListenerImpl.java:1186-1189`：一旦不 matches，服务端
 * `expectedAcks.put(id, uid)` + 回 `accepted=false` + **`setSynched(player,false)`**。
 * 而 `:1169` 的闸门是
 *   `if (bw.containerId == pkt.containerId && bw.isSynched(player)) { … }`
 * ⇒ 窗口一旦"不同步"，**这个窗口之后的所有点击都被直接忽略、连 ack 都不回**。
 * 客户端表现就是"后面全是 no ack / no_server_window_truth"，而**没有报错**——
 * 这正是 r4 实跑里 4 条 `no_server_window_truth` 的机制来源。
 *
 * 谁来道歉：mineflayer 只对**它自己队列里**的 action 回 `ServerboundContainerAckPacket`
 * （`inventory.js:492-502` 对队列外的 action 直接 return）⇒ **我们自己直发的包没人替我们道歉**。
 * 唯一解法是客户端自己回一个：`:1259-1267 handleContainerAck` 认
 * **同 windowId + 同 uid**（且当前 `!isSynched`）就 `setSynched(true)`。
 * 协议里它在 1.16.1 就叫 **`transaction`**（`{windowId:i8, action:i16, accepted:bool}`），
 * 与回执是同一个包、反向。⚠ 服务端**不读** `accepted` 字段，只看 windowId + uid ⇒ 填 true。
 *
 * 顺序很要紧：拒收路径**自己也会**发一条整窗 `window_items`（`:1190-1197`），而且它和
 * ack 在同一个 handler 里连发 ⇒ 监听器必须在**发点击包之前**就挂好，否则这条重同步会被错过。
 * 所以本函数接收的是**提前挂好的** `syncP`，不自己挂监听。
 *
 * @param uid    拒收回执里的 action 号（= 服务端记进 `expectedAcks` 的那个 uid）
 */
export async function apologizeAndResync(bot, win, uid, syncP, { timeoutMs = 900 } = {}) {
    let apologized = false;
    try {
        bot._client.write('transaction', { windowId: win.id, action: uid, accepted: true });
        apologized = true;
    } catch { /* 写不出去就如实记 false，不假装成功 */ }
    const srv = syncP ? await syncP : null;
    return { apologized, resynced: !!srv?.ok, srv };
}

/**
 * 发一次 window_click，`item` 字段填**服务端 `clicked()` 将会返回的那一格点击前内容**
 * （由 `predictClickedReturn` 算，**调用方不再有填错的机会**），等**服务端 transaction 回执**。
 *
 * 两条口径（都是本单实跑 + 1.16.1 源码核出来的，别再改回去）：
 *  · **accepted=true ⇒ 必须 `win.acceptClick(...)` 推进本地模型。**
 *    服务端在这条路径上被 `ignoreSlotUpdateHack` 挡掉了全部槽位广播
 *    （`ServerGamePacketListenerImpl:1182-1185`），**一条都不发** ——
 *    ≤1.16 协议的前提就是客户端自己预测。r4 写的"1.16.x 路径一个字节都不写模型"是**错的**，
 *    代价是下一击从陈旧模型出发，实测 30/30 `putback_rejected`。
 *  · **accepted=false ⇒ 一个字节都不改模型，立刻回 `transaction` 道歉**并按
 *    服务端重发的整窗 `window_items` 覆写模型（见 `apologizeAndResync`）——
 *    否则这扇窗口会因 `setSynched(false)` 从此静默吞掉所有点击。
 */
export async function clickCarryConfirmed(bot, win, { slot, mouseButton = 0, mode = 0, expectMove = true, timeoutMs = 1200, resyncTimeoutMs = 400 } = {}) {
    const flavor = clickFlavor(bot);
    const itemForPacket = predictClickedReturn(win, { slot, mode, expectMove });
    let changedSlots = [];
    if (flavor.stateIdUsed) {
        // 1.17+：协议要求客户端上报预测差分（1.16.x 不需要，也不会走到这里）
        const sig0 = win.slots.map(slotSig);
        win.acceptClick({ slot, mouseButton, mode, item: itemForPacket });
        win.slots.forEach((s, i) => { if (slotSig(s) !== sig0[i]) changedSlots.push({ location: i, item: s }); });
        changedSlots.push({ location: -1, item: win.selectedItem ?? null });
    }
    const pkt = windowClickPacket(bot, flavor, {
        windowId: win.id, slot, mouseButton, mode, changedSlots,
        item: itemForPacket,                   // ← clicked() 的返回值，**不是光标**
        cursorItem: win.selectedItem ?? null,
    });
    const action = pkt.params.action;
    const ackP = flavor.transactionPacketExists
        ? waitServerTransaction(bot, win.id, action, timeoutMs)
        : waitServerSlot(bot, win.id, slot, timeoutMs).then((s) => (s.ok ? { ok: true, accepted: true } : { ok: false, timedOut: true }));
    // ★ 必须在 write **之前**挂：① 拒收路径的整窗 window_items 与 ack 同一 handler 连发；
    //   ② 被接受路径在 **window 0 上只发逐格 set_slot**（见 waitServerWindowSync 的注释）。
    const syncP = waitServerWindowSync(bot, win, { timeoutMs: resyncTimeoutMs });
    bot._client.write(pkt.name, pkt.params);
    const ack = await ackP;
    if (!ack || !ack.ok) return { ok: false, unconfirmed: true, via: 'transaction', action, timedOut: !!ack?.timedOut };
    // ★★★ 本单最贵的一条（实跑 T09R5B/C/DBG2 三轮抓包钉死）★★★
    //
    // **服务端在 accepted 路径上"故意不发"任何槽位更新**，所以客户端**必须自己预测**。
    // 抓包原文（`bench/stages/micro-craft/runs/T09R5_DBG2`）：action 2/3/4 三次 accepted 之后，
    // 服务端**一条 `window_items`、一条 `set_slot` 都没有**（只有第 5 次被拒时才来 1 条
    // `window_items n=46`）。机制在源码里：
    //   `ServerGamePacketListenerImpl.java:1182-1185`
    //     `ignoreSlotUpdateHack = true; bw.broadcastChanges(); broadcastCarriedItem(); ... = false;`
    //   而 `AbstractContainerMenu.broadcastSlotChange` 正是被这个 hack 挡掉的
    //   ⇒ 协议（≤1.16 的 `ServerboundContainerClickPacket`）的设计前提就是
    //      **客户端按自己的预测推进模型，服务端只校验你上报的返回值**。
    //
    // ⇒ 所以 accepted 之后**必须调 `win.acceptClick(...)`**（与 mineflayer
    //   `confirmTransaction.onAccepted` 同一件事）。r4 的"1.16.x 路径一个字节都不写模型"
    //   在这里是个**真 bug**：模型停在上一击之前，下一击的 `item` 就用陈旧数据算 ——
    //   实测后果是 30/30 全 `putback_rejected`（源槽早已被拿空，模型里还显示 4 个，
    //   被 putback 选成"同型有余量"的目标，报 `item=4` 而服务端那边是空的 ⇒ 返回 EMPTY ⇒ 拒）。
    //
    // 这个循环是自洽的：**ack accepted ⇔ 我们对返回值的预测正确 ⇒ acceptClick 复现的就是
    // 服务端的真实状态 ⇒ 下一击从真值出发**。一旦预测错了，服务端拒收、我们道歉、
    // 服务端把整窗真值重发一遍覆盖掉我们的预测（`window_items` ⇒ mineflayer 覆写模型）。
    if (ack.accepted === false) {
        syncP.cancel?.();
        const ap = await apologizeAndResync(bot, win, action, syncP, { timeoutMs: resyncTimeoutMs });
        return {
            ok: false, rejected: true, via: 'transaction', action,
            apologized: ap.apologized, resynced: ap.resynced,
            sentItem: itemForPacket ? `${itemForPacket.name}x${itemForPacket.count}` : null,
        };
    }
    // 被接受 ⇒ 把这一击的预测落到本地模型（**这一步就是让下一击有真值可依**）
    win.acceptClick({ slot, mouseButton, mode, id: action, windowId: win.id, item: itemForPacket });
    syncP.cancel?.();
    return { ok: true, via: 'transaction', action, predicted: true };
}

/**
 * ── 通用「两次 PICKUP」搬运：把 `from` 格的东西搬到 `to` 格 ──
 *
 * 为什么不用 shift（QUICK_MOVE）：见 `predictClickedReturn` 的 **r6 更正** —— 1.16.1 上
 * QUICK_MOVE 的返回值取决于「源格有没有被搬空」，而熔炉装料**恰好总是搬空**（一整摞进去），
 * ⇒ 服务端算 EMPTY ⇒ 报整摞必被拒（r5 实跑 0/30）。
 * PICKUP 的两条返回值规则（`AbstractContainerMenu.doClick` 的 PICKUP 分支）**不含 `isSame`**：
 *   · 被点格**有东西** → 返回该格点击前内容（`:253-256`）
 *   · 被点格**空**     → 返回值从未被赋值 ⇒ EMPTY（`:159` 初值）
 * ⇒ 左键拿起（有东西 ⇒ 返回整摞）／左键放进空槽（空 ⇒ 返回 EMPTY），两击都完全可预测。
 *
 * ⚠ 光标状态：**accepted 之后 `win.acceptClick(...)` 会让 prismarine 本地维护 `selectedItem`**
 *   （`prismarine-windows/lib/Window.js` 的 `acceptClick → mouseClick` 里有 `this.selectedItem = …`）
 *   —— 这正是 r4 那句「`selectedItem` 恒 null」的**前提被 r5 §3.3 修掉之后**才成立的。
 *   所以这里可以（也必须）用它判「光标非空」，否则第一步会变成**交换**而不是拿起。
 *
 * @param placeCount  >0 且小于光标数量 ⇒ 改用右键逐个放（`:261` 每次只放 1）
 * @returns {ok, from, to, moved, via, srv, verdict:[v1,v2…], reason?}
 */
export async function pickupStackToSlot(bot, win, { from, to, placeCount = 0, timeoutMs = 1500, expectName = null, resyncTimeoutMs = 400 } = {}) {
    if (!win || win.id == null) return { ok: false, reason: 'no_window' };
    if (typeof from !== 'number' || typeof to !== 'number') return { ok: false, reason: 'bad_slot', from, to };
    const src = win.slots[from] ?? null;
    if (!src) return { ok: false, reason: 'src_empty', from };
    if (expectName && src.name !== expectName) return { ok: false, reason: 'src_wrong_item', from, got: `${src.name}x${src.count}`, want: expectName };
    if (win.selectedItem) return { ok: false, reason: 'cursor_not_empty', held: `${win.selectedItem.name}x${win.selectedItem.count}`, from };

    // ── 第 1 击：左键拿起整摞 ──
    const v1 = await clickCarryConfirmed(bot, win, { slot: from, mouseButton: 0, mode: 0, timeoutMs, resyncTimeoutMs });
    if (!v1.ok) return { ok: false, reason: v1.rejected ? 'pickup_rejected' : 'pickup_unconfirmed', stage: 1, verdict: v1 };
    const cursor = win.selectedItem ?? null;
    if (!cursor) return { ok: false, reason: 'cursor_empty_after_accept', stage: 1, verdict: v1 };
    if (expectName && cursor.name !== expectName) return { ok: false, reason: 'cursor_wrong_item', stage: 1, got: `${cursor.name}x${cursor.count}`, want: expectName };

    // ── 第 2 击（可能多击）：放进目标格，判据是**服务端那一格的真值** ──
    // ⚠ 监听器必须在发包之前挂（拒收路径的整窗包与 ack 同一 handler 连发）
    const destP = waitServerWindowSlots(bot, win, [to], { timeoutMs });
    const useEach = placeCount > 0 && placeCount < cursor.count;
    const clicks = [v1];
    if (!useEach) {
        // 左键放进（空槽 ⇒ 服务端 clicked() 返回 EMPTY，正好是 predictClickedReturn 的默认分支）
        const v2 = await clickCarryConfirmed(bot, win, { slot: to, mouseButton: 0, mode: 0, timeoutMs, resyncTimeoutMs });
        clicks.push(v2);
        if (!v2.ok) {
            // ⚠ 被拒不等于没发生（r5 §3.5）：把光标上的东西点回原处，别让它落在半路
            const back = await clickCarryConfirmed(bot, win, { slot: from, mouseButton: 0, mode: 0, timeoutMs, resyncTimeoutMs });
            return { ok: false, reason: v2.rejected ? 'place_rejected' : 'place_unconfirmed', stage: 2, cursorReturned: back.ok, verdict: clicks };
        }
    } else {
        for (let i = 0; i < placeCount; i++) {
            const v = await clickCarryConfirmed(bot, win, { slot: to, mouseButton: 1, mode: 0, timeoutMs, resyncTimeoutMs });
            clicks.push(v);
            if (!v.ok) return { ok: false, reason: v.rejected ? 'place_rejected' : 'place_unconfirmed', stage: `2.${i}`, verdict: clicks };
        }
    }

    // ── 判据：两次 ack（服务端权威地确认 `clicked()` 的返回值与我们的预测一致）
    //    + 模型预测。⚠⚠ **服务端那一格的 set_slot 在这里结构性地等不到**，不能当硬判据。
    //
    //   实测（本单 T09R6B，30/30）：装料**服务端真值已经成功**（`data get block` 回
    //   `{Slot:0b, id:"minecraft:iron_ore", Count:1b}`，两击都 accepted），但判据 30/30 报
    //   `no_server_window_truth`。
    //
    //   机制（源码）：
    //   · `ServerGamePacketListenerImpl.java:1182-1185`
    //       `ignoreSlotUpdateHack = true; bw.broadcastChanges(); broadcastCarriedItem(); … = false;`
    //   · `AbstractContainerMenu.java:105-117` 的 `broadcastChanges()`：
    //       `if (!ItemStack.matches(lastSlots[i], slots[i].e())) { lastSlots.set(i, copy);  ← 先记
    //         for (listener : containerListeners) listener.slotChanged(...) }`             ← 再发
    //     **「记」和「发」是两步**：被抑制的只是发包那一步，`lastSlots` 已经更新了。
    //   · `ServerPlayer.java:363` 每 tick 会再调一次 `broadcastChanges()`，但那时
    //     `lastSlots` 已经等于新状态 ⇒ **再也不会发**。
    //   ⇒ 被接受的点击之后，那一格的服务端包**永远不会来**。
    //
    //   所以：给服务端包一个**短窗口**（到了就用它，它是更强的证据），到点就走
    //   `ack + 客户端模型预测`。prismarine 的 `acceptClick` 复现的是原版 `Slot.click` 的语义，
    //   而 ack accepted ⇔ 服务端算出的 `clicked()` 与我们上报的一致 ⇒ 这条循环是自洽的。
    const srv = await Promise.race([destP, sleep(Math.min(500, timeoutMs)).then(() => null)]);
    const srvSlot = srv?.slots?.[to] ?? null;
    const predicted = win.slots[to] ?? null;
    const truth = srvSlot ?? predicted;
    const truthVia = srvSlot ? srv.via : (predicted ? 'ack+prediction' : 'ack_only');
    if (truth && expectName && truth.name !== expectName) {
        return { ok: false, reason: 'dest_wrong_item', got: `${truth.name}x${truth.count}`, want: expectName, srv: srv ?? null, truthVia, verdict: clicks };
    }
    // ⚠ `ack_only` 为什么不冒充服务端确认（不把判据冒装成证据）：
    //   本单实跑（T09R6B/C）证明 prismarine 的 `acceptClick` 在真服这条路上
    //   **不总**把目标格填进模型（离线复现：真库 `mouseClick` 路径是对的，
    //   但真服上模型仍为空）。所以 `ack+prediction` 那一层不是稳的。
    //   而 ack 本身是**强**证据：accepted ⇔ 服务端 `clicked()` 的返回值与我们预测完全一致
    //   （`ServerGamePacketListenerImpl:1180` 的 `ItemStack.matches`），
    //   即服务端**确实**执行了「从我们点名的源格拿起、放进我们点名的目标格」。
    //   剩下的唯一风险是「我们点名的下标不是服务端那个槽」，而这一条已由**服务端真值对账**
    //   独立排除（`data merge block` 写标记物 → 读回本地窗口下标：
    //   T09R6C 实测 `srv0→local0 / srv1→local1`，服务端读回 true）。
    //   ⇒ 三条证据合起来可以判成功，但**判据来源如实标成 `ack_only`**。
    if (!truth && !clicks.every((c) => c && c.ok)) {
        return { ok: false, reason: 'dest_still_empty', from, to, srv: srv ?? null, verdict: clicks };
    }
    const leftover = win.selectedItem ? `${win.selectedItem.name}x${win.selectedItem.count}` : null;
    return { ok: true, from, to, moved: truth?.count ?? null, landed: !!truth, truthVia, leftover, via: truthVia, slotCount: srv?.slotCount ?? null, srv: srv ?? null, verdict: clicks };
}

/**
 * 熔炉**装料 / 加燃料**：把背包里的 `itemName` 搬进输入格(0) / 燃料格(1)。
 *
 * 判据（**全部服务端真值**）：两次点击都拿到 `transaction{accepted:true}`，
 * 且服务端那一格的内容符合预期（`waitServerWindowSlots`）。
 * 「源槽少了」只作参考不作判据（1.16 accepted 路径不发槽位更新，模型靠 acceptClick 预测）。
 *
 * @returns {ok, src, dest, moved, via, slotCount, reason?, srv?, verdict?}
 */
export async function loadIntoFurnaceSlot(bot, furnace, { itemName, target = 'input', timeoutMs = 2000, wantCount = 0, placeCount = 0 } = {}) {
    const win = furnace.window ?? furnace;
    if (!win || win.id == null) return { ok: false, reason: 'no_furnace_window' };
    const destSlot = target === 'fuel' ? 1 : 0;
    const otherSlot = destSlot === 0 ? 1 : 0;
    if (win.selectedItem) return { ok: false, reason: 'cursor_not_empty', held: `${win.selectedItem.name}x${win.selectedItem.count}` };

    const range = playerInvRange(bot, win);
    if (!range) return { ok: false, reason: 'player_range_unknown', slotCount: windowSlotCount(bot, win) };
    const src = findInPlayerRange(win, range, itemName);
    if (src < 0) {
        // ★ 自证闸门：区间若是坏的（旧代码的 27..63 丢掉 24 格），这里响亮地失败，
        //   而不是像 putInput 那样抛一句读不出所以然的 "Can't find … in slots [27 - 63]"。
        return { ok: false, reason: 'item_not_in_player_range', item: itemName, range: [range.start, range.end], rangeVia: range.via, slotCount: windowSlotCount(bot, win) };
    }
    const destBefore = win.slots[destSlot] ?? null;
    if (destBefore && destBefore.name !== itemName) {
        return { ok: false, reason: 'dest_other_item', dest: destSlot, got: `${destBefore.name}x${destBefore.count}` };
    }
    const have = destBefore ? destBefore.count : 0;
    const srcBefore = countItemsInRange(bot, win, range, itemName);
    if (wantCount > 0 && have >= wantCount) {
        return { ok: true, already: true, dest: destSlot, moved: have, src, srcBefore, range: [range.start, range.end] };
    }

    const r = await pickupStackToSlot(bot, win, { from: src, to: destSlot, placeCount, timeoutMs, expectName: itemName });
    if (!r.ok) return { ...r, src, item: itemName, target, dest: destSlot, range: [range.start, range.end], rangeVia: range.via, slotCount: windowSlotCount(bot, win) };

    // ⚠ 矿石落进燃料格 / 燃料落进输入格都要报出来（1.16.1 AbstractFurnaceMenu:109-124 会分流）
    const other = r.srv?.slots?.[otherSlot] ?? null;
    if (other && other.name === itemName) {
        return { ok: false, reason: 'landed_in_other_slot', otherSlot, got: `${other.name}x${other.count}`, srv: r.srv, verdict: r.verdict };
    }
    if (wantCount > 0 && r.moved < wantCount) {
        return { ok: false, reason: 'short_transfer', got: r.moved, want: wantCount, srv: r.srv, verdict: r.verdict };
    }
    const srcAfter = countItemsInRange(bot, win, range, itemName);
    return {
        ok: true, via: 'pickup', src, dest: destSlot, moved: r.moved, leftover: r.leftover ?? null,
        slotCount: r.slotCount ?? null, srcBefore, srcAfter, range: [range.start, range.end], rangeVia: range.via, srv: r.srv, verdict: r.verdict,
    };
}

/**
 * 熔炉**清炉 / 取产物**：把熔炉自己某一格的东西搬回背包（两次 PICKUP，不用 shift）。
 *
 * 换掉 `furnace.takeInput()` / `takeFuel()`：它们内部是 `bot.putAway(slot)`，
 * 而 `putAway` 用的也是 `window.inventoryStart/inventoryEnd`（`inventory.js:660-662`）
 * ⇒ 同一个坏区间，把残余物丢在炉里（挖炉时内容物散落）。
 */
export async function takeOutOfFurnaceSlot(bot, furnace, { slot = 0, timeoutMs = 2000, expectName = null, count: wantTotal = 0 } = {}) {
    const win = furnace.window ?? furnace;
    if (!win || win.id == null) return { ok: false, reason: 'no_furnace_window' };
    const cur = win.slots[slot] ?? null;
    if (!cur) return { ok: false, reason: 'slot_empty', slot };
    if (expectName && cur.name !== expectName) return { ok: false, reason: 'slot_wrong_item', slot, got: `${cur.name}x${cur.count}`, want: expectName };
    if (win.selectedItem) return { ok: false, reason: 'cursor_not_empty', held: `${cur.name}x${win.selectedItem.count}`, slot };

    const range = playerInvRange(bot, win);
    if (!range) return { ok: false, reason: 'player_range_unknown' };
    let dest = -1;
    for (let i = range.start; i < range.end; i++) { if (!win.slots[i]) { dest = i; break; } }
    if (dest < 0) {
        // 背包全满 ⇒ 退而求其次：并进一个同类未满的格子（doClick:268 的合并分支，返回值仍可预测）
        for (let i = range.start; i < range.end; i++) {
            const t = win.slots[i];
            if (t && t.name === cur.name && t.count < t.stackSize) { dest = i; break; }
        }
    }
    if (dest < 0) return { ok: false, reason: 'inventory_full', want: `${cur.name}x${cur.count}` };
    const before = countItemsInRange(bot, win, range, cur.name);

    const r = await pickupStackToSlot(bot, win, { from: slot, to: dest, timeoutMs, expectName: cur.name });
    if (!r.ok) return { ...r, slot };

    // 背包增量兜底（1.16 上这才是最终判据）
    let gained = countItemsInRange(bot, win, range, cur.name) - before;
    const dl = Date.now() + timeoutMs;
    while (gained <= 0 && Date.now() < dl) { await sleep(100); gained = countItemsInRange(bot, win, range, cur.name) - before; }
    if (gained <= 0) return { ok: false, reason: 'no_inv_delta', gained, srv: r.srv, verdict: r.verdict };
    if (wantTotal > 0 && gained < wantTotal) return { ok: false, reason: 'short_take', gained, want: wantTotal, srv: r.srv, verdict: r.verdict };
    return { ok: true, slot, dest, gained, via: r.via, srv: r.srv, verdict: r.verdict };
}

/**
 * 熔炉装料 / 加燃料（**历史名**，保留调用方 —— `smelt_task.js` 用的就是它）。
 *
 * ⚠ r6：实现已从 shift 点击换成**两次 PICKUP**。病根在 1.16.1 的返回值规则上 ——
 *   shift 点一个会被搬空的源格时，`AbstractContainerMenu.doClick:243` 的
 *   `ItemStack.isSame(slot.getItem(), s)` 必然 false（一边空了就 false）⇒
 *   `clicked()` 返回 **EMPTY**，而我们上报的是那一摞 ⇒ **每一次都被拒**（r5 实跑 0/30）。
 *   ⚠ 而那一击**已经生效**（`clicked()` 先执行再比对）⇒ 历史上「装料 0/30」
 *     与「矿石其实进了炉子」同时成立，判据才一直对不上。
 *   名字不改，避免动 `smelt_task.js` 的调用面。
 */
export async function quickMoveIntoFurnace(bot, furnace, { itemName, target = 'input', timeoutMs = 2500, wantCount = 0, placeCount = 0 } = {}) {
    return loadIntoFurnaceSlot(bot, furnace, { itemName, target, timeoutMs, wantCount, placeCount });
}

/**
 * 熔炉**清炉 / 取件**（**历史名**，保留调用方）。r6 起也是两次 PICKUP。
 */
export async function quickMoveOutOfFurnace(bot, furnace, { slot = 0, timeoutMs = 2000, expectName = null, count = 0 } = {}) {
    return takeOutOfFurnaceSlot(bot, furnace, { slot, timeoutMs, expectName, count });
}

/**
 * ── 光标（carried item）的**服务端真值**跟踪器 ──
 *
 * ## 为什么不能用 `win.selectedItem`（本单实跑 T09R4_IRON trial_01 实测出来的）
 *
 * 1.16.1 上 mineflayer **把服务端的光标包丢掉**：`inventory.js:738-753` 的 set_slot 处理器
 * `window.id !== packet.windowId ⇒ return`，而服务端发光标用的 windowId 是 **-1**
 * ⇒ `win.selectedItem` 永远拿不到服务端校正。
 * 更要紧的是**第二条**：mineflayer 只在**它自己**的点击路径上给 `selectedItem` 赋值
 * （`confirmTransaction` → `onAccepted` → `window.acceptClick`，`inventory.js:520-525`），
 * 而 `confirmTransaction` 对**不在自己队列里的 action** 会直接 return
 * （`inventory.js:492-502`：找不到就自己回一个 ack 然后 return，**不碰模型**）。
 * ⇒ **任何自研直发包的点击，mineflayer 都不会更新 `selectedItem`** ⇒ 它恒为 `null`。
 *
 * 那个恒 null 会怎么炸：**4 次 `cursor_lost_after_pickup` 与 4 次 `pickup_rejected`
 * 严格交替，一条不多一条不少**：
 *   · 第一次点"拿起"：服务端 accepted、光标上真的有东西，但本地 `selectedItem` 仍是 null
 *     ⇒ 下一步前置检查判 `cursor_lost_after_pickup`（**误报**，东西其实在手上）；
 *   · 下一轮重来：模型说光标空、服务端说光标里有 N 个木板 ⇒ 那次"拿起"实际是**交换**，
 *     服务端算出的光标与我上报的点击前格子内容不符 ⇒ `accepted=false` ⇒ `pickup_rejected`；
 *   · 两种 reason 交替，**离线自检全绿也照样全灭**（自检的假 bot 由测试自己维护
 *     `selectedItem`，天然与真服不同构 —— 这正是"假 bot 比真库宽"的又一次现形）。
 *
 * ## 正确口径
 * 光标**只从服务端原始包读**（`set_slot` windowId=-1 / slot=-1，见 `isCursorPacket`），
 * 且**每点一次就用服务端真值刷新**。服务端只在光标**变化时**才发这个包，
 * 所以"没等到包"= "没变化"（与预测一致），**不是失败**。
 * 预测与真值不一致时**以真值为准**继续，并如实累加 `mismatches`。
 */
export async function makeCursorTracker(bot, win, { timeoutMs = 900 } = {}) {
    const tap = makeSlotTap(bot, win.id, 128);
    const state = { item: null, source: 'assumed_empty', mismatches: 0, updates: 0, lastVia: null, packets: 0, void: false };
    const range = playerInvRange(bot, win);

    /** 读一次服务端光标真值（有界）。⚠ 实测：本服在 accepted 路径上**不发**这个包。 */
    const readTruth = async (ms = timeoutMs) => {
        const t = await tap.cursorTruth(ms);
        if (t.ok) {
            state.item = t.item ?? null; state.source = 'set_slot(-1)';
            state.updates++; state.packets++;
        }
        state.lastVia = t.ok ? 'set_slot(-1)' : 'no_packet';
        return t;
    };

    return {
        get item() { return state.item; },
        get empty() { return !state.item; },
        get source() { return state.source; },
        get mismatches() { return state.mismatches; },
        get updates() { return state.updates; },
        get lastVia() { return state.lastVia; },
        get packets() { return state.packets; },

        /**
         * 起点：**用一次无害点击把"光标是空的"从假设变成被 ack 验证过的事实**。
         *
         * 为什么需要它（实跑 T09R4B_IRON trial_01 原文）：
         *   `craft_no_gain reason=pickup_cursor_mismatch cursor=null cursorSource=assumed_empty`
         *   —— 一次被 accepted 的"拿起"之后，**服务端一条光标包都没发**（mineflayer 丢掉 −1 包
         *   之外，1.16.1 服务端在 accepted 路径上本来就不发：`ServerPlayer.handleContainerClick`
         *   把 `ignoreSlotUpdateHack` 置 true 再 `broadcastChanges()/broadcastCarriedItem()`，
         *   而 `broadcastCarriedItem()` 正是被这个 hack 挡掉的）。
         *   ⇒ "光标有没有东西"**只能由 ack 反推**：服务端比较的正是
         *   `ItemStack.matches(我上报的 carryAfter, 点击后的真实光标)`，
         *   **accepted=true ⇔ 我的 carryAfter 预测正确**。ack 就是那个 oracle。
         *
         * 探针本身是无害的：右键点一个**空**背包槽、上报"光标是空的"。
         *   · 光标真为空 ⇒ 服务端无事发生 ⇒ accepted=true（我们顺带拿到"起点为空"的证明）；
         *   · 光标非空  ⇒ 服务端会把光标那一摞分一半进那个槽，结果光标非空
         *                  ⇒ matches(null, 非空) = false ⇒ accepted=false ⇒ 我们**如实知道**起点不干净。
         */
        async prime() {
            if (!range) return { ok: false, reason: 'player_range_unknown' };
            let emptySlot = -1;
            for (let i = range.start; i < range.end; i++) { if (!win.slots[i]) { emptySlot = i; break; } }
            if (emptySlot < 0) return { ok: false, reason: 'no_empty_slot_for_probe' };
            const t = await tap.cursorTruth(120);   // 先看有没有历史包
            if (t.ok) { state.item = t.item ?? null; state.source = 'set_slot(-1)'; state.packets++; }
            const v = await clickCarryConfirmed(bot, win, { slot: emptySlot, mouseButton: 1, mode: 0, timeoutMs: Math.min(timeoutMs, 700) });
            if (v.rejected) return { ok: false, reason: 'cursor_not_empty', probeSlot: emptySlot };
            if (v.unconfirmed) return { ok: false, reason: 'probe_unconfirmed', probeSlot: emptySlot, verdict: v };
            state.source = state.packets ? 'set_slot(-1)+ack' : 'ack_verified';
            state.lastVia = 'probe_ack';
            return { ok: true, emptySlot, via: state.source };
        },

        /**
         * 发一次点击 + 等判决 + **按 ack 更新光标模型**。
         *
         * ⚠ `cursorAfter` 是**点击后的光标**（本地模型用），**不是包里的 `item`**。
         *   包里的 `item` 由 `predictClickedReturn` 从"被点那格的点击前内容"算，两者不是一回事。
         *
         * accepted=true ⇒ 服务端认可 ⇒ 光标 = 我们预测的值（**这是被验证过的**，不是猜的）。
         * accepted=false ⇒ **已经回过 transaction 道歉**（窗口不会从此静默），
         *   但本地光标模型就此作废（此后不再信任），如实上报。
         */
        async click(slot, mouseButton, mode, cursorAfter) {
            const before = state.item;
            const v = await clickCarryConfirmed(bot, win, { slot, mouseButton, mode, timeoutMs });
            if (!v.ok) { state.void = true; return v; }
            const expect = (mode === 1)
                ? (before ?? null)                       // QUICK_MOVE 不碰光标
                : (mouseButton === 1
                    ? (before && before.count > 1 ? itemWithCount(bot, before, before.count - 1) : null)
                    : (cursorAfter ?? null));
            // accepted=true 已经证明 expect 与服务端光标一致；若有真值包则以包为准
            const t = await readTruth(140);
            if (!t.ok) {
                state.item = expect;
                state.lastVia = 'ack_predicted';
            } else if (slotSig(t.item) !== slotSig(expect)) {
                state.mismatches++;
            }
            return v;
        },
        stop: () => tap.stop(),
        _state: state,
    };
}

/**
 * 网格合成（2×2 背包专用；3×3 工作台那条已实测 29/30，本单不碰）。
 *
 * 换掉 `bot.craft` 的两个理由：
 *  ① `bot.craft` 的 `grabResult()` 先 `window.updateSlot(0, new Item(result))`
 *     **凭空造出产物槽**再点走（`craft.js:136-138`）—— "不抛错、材料没少、成品下落不明"的病根；
 *  ② 它放料时**不等服务端判决**就按客户端预测往下走（`inventory.js:571/626` 算完差分立刻发包），
 *     而 1.16.1 服务端会拿包里的 `item` 跟 `menu.clicked()` 的**返回值**比
 *     （`ServerGamePacketListenerImpl.java:1179-1180`）—— 而那个返回值是
 *     **"被点那一格点击前的内容"**（`AbstractContainerMenu.java:256`），
 *     **不是**"点击后的光标"（`:254` 的 `☃x.m()` 才是光标，但它不参与返回值）。
 *     ⇒ 右键把 1 个原木放进**空的** 2×2 格时，正确值是 `{present:false}`（空）；
 *     填光标（`oak_log×5`）必被拒 —— 这正是 r4 实跑 `place_rejected` 的成因。
 *     现在由 `predictClickedReturn` 统一算，调用方没有填错的机会。
 *
 * 取产物用 **shift 点击槽 0**：1.16.1 `InventoryMenu.quickMoveStack` 对 index==0 是
 * `moveItemStackTo(stack, 9, 45, true)`（`InventoryMenu.java:120-125`）
 * ⇒ 产物**直接进玩家背包、全程不碰光标**，因此不受光标模型分叉影响。
 * ⚠ 反过来**绝不能** shift 点击网格格 1..4：`InventoryMenu.java:126-129` 会把材料
 * 倒回玩家背包 9..44、静默清空已摆好的配方。本函数因此只 shift 点 `resultSlot`。
 *
 * cells: [{x, y, id}]（id = item type）
 * 返回 {ok, took, gained, reason?, cursor?, cursorSource?, cursorMismatches?}
 */
export async function craftInGridConfirmed(bot, win, { cells, gridW = 2, gridH = 2, resultSlot = 0, expectName = null, timeoutMs = 1500 } = {}) {
    if (!win || win.id == null) return { ok: false, reason: 'no_window' };
    const range = playerInvRange(bot, win);
    if (!range) return { ok: false, reason: 'player_range_unknown' };
    const cellSlot = (x, y) => resultSlot + 1 + x + gridW * y;
    const describe = (c) => (c ? `${c.name}x${c.count}` : null);

    // ★ 光标模型由 ack 验证（见 makeCursorTracker 的注释：本服 accepted 路径不发光标包）
    const cur = await makeCursorTracker(bot, win, { timeoutMs: Math.min(timeoutMs, 900) });
    // ★★ **结果格的服务端真值必须在放料之前就开始抓**（本单实跑 T09R5_DBG4 抓包钉死）：
    //   window 0 上，服务端在 accepted 路径**只发"结果格"这一格的 set_slot**
    //   （网格变化 ⇒ 配方重算 ⇒ `set_slot(0, 成品)`），网格格本身一个字节都不发；
    //   而且这一条**发生在放料那几下点击期间**（实测 +168ms / +325ms 各一条），
    //   远早于"放完料再挂监听" ⇒ 后挂的监听器**永远等不到**（实测 `no_server_window_truth`）。
    //   ⇒ 用环形缓冲（makeSlotTap）全程照单全收，读的时候取**最后一条**。
    const tap = makeSlotTap(bot, win.id, 128);
    // `slotTruth` 先查环形缓冲，**查不到才等**（有界）—— 既能吃到放料期间已经到达的那条，
    // 又不会因为"结果格更新还没到"就立刻判 no_server_window_truth。
    const srvSlot = (s) => tap.slotTruth(s, Math.min(timeoutMs, 600), win.id);

    // ═══ MC-M1-TASK-11（FARM-04 0/20 回归修复）：结果格真值改为**多源**，不等单格 set_slot ═══
    //
    // 【现象】服务端合成**确实成功**（FARM-04 十局都有 `craft_ok gained=1..4` 的实证），
    //   验证层却读成 `no_result` / `no_server_window_truth` ⇒ `craft_fail` ⇒
    //   `tool_rescue_fail` ⇒ 顶层 `TOOL_MISSING`。本地 T11A_IRON 3/3 局逐字复现同一条时序。
    //
    // 【病根】1.16.1 上**被接受的点击之后，那一格的服务端 set_slot 永不到达**
    //   （`broadcastChanges()` 先 `lastSlots.set(...)` 再发包；点击路径被
    //   `ignoreSlotUpdateHack` 抑制；`ServerPlayer.java:363` 每 tick 再调时
    //   `lastSlots` 已等于新状态 ⇒ 不再发）。r6 §2.3 已查实，本单把它变成了**判据**。
    //   ⇒ **任何"点完等那一格的 set_slot"的写法在 1.16.1 上结构性失效**，
    //     哪怕那一击服务端已经执行了。
    //
    // 【修法】结果格真值按下列顺序取，**每一级都记进 `resultVia`**，不再单点依赖：
    //   ① `window_items` **全量**回读（服务端整窗同步，最权威；抓 `window_items` 包而非单格 set_slot）
    //   ② 环形缓冲里那一格的 `set_slot`（旧通道，保留：有时确实会来）
    //   ③ **客户端模型 `win.slots[resultSlot]`** —— 本服 accepted 路径不发格更新，
    //      但 mineflayer 的 `acceptClick` **会按 ack 验证过的预测推进模型**，
    //      所以模型在这一格上是**被 ack 验证过的**读数，不是凭空捏造。
    //   ④ 都没有 ⇒ 如实报 `no_server_window_truth`（**不猜**）。
    //
    // ⚠ **最终判据仍然是背包增量**（调用方 `countItemsWindowAware` 前后相减），
    //   本函数只负责"结果格上有什么"。**动作成功 ≠ 收益到手**这条不变。
    const wholeWindowTruth = makeWholeWindowTap(bot, win.id);
    const srvResultTruth = async (slot) => {
        // ① 整窗回读
        const whole = await wholeWindowTruth.slotTruth(slot, Math.min(timeoutMs, 500));
        if (whole.ok) return { ok: true, item: whole.item, via: 'window_items' };
        // ② 单格 set_slot（缓冲优先）
        const one = await srvSlot(slot);
        if (one.ok) return { ok: true, item: one.item, via: 'set_slot' };
        // ③ 模型（已被 ack 验证过的预测推进）
        //    ⚠ **"读到模型、模型说这一格是空的"也是一次成功读取** —— 必须与
        //    "完全读不到"（`no_server_window_truth`）**分开**（手册 §5：
        //    绝不把"未知"折成"没事"，反过来也不能把"确知为空"折成"读不到"）。
        //    所以这里返回 `ok:true, item:null` ⇒ 上游判 `no_result`（确知没有产物），
        //    而不是 `no_server_window_truth`（读不到，性质完全不同、排查方向也不同）。
        const m = win.slots[slot];
        if (m === undefined) return { ok: false, timedOut: true, via: 'none' };   // 这一格根本不在模型里 = 真读不到
        return { ok: true, item: m && typeof m.name === 'string' ? m : null, via: 'model_after_ack' };
    };
    try {
        const p0 = await cur.prime();
        if (!p0.ok) {
            // 起点光标不干净：如实报出（含探针那一击的槽号），不自动清理
            return {
                ok: false, reason: p0.reason, probeSlot: p0.probeSlot ?? null,
                cursor: describe(cur.item), cursorSource: cur.source, verdict: p0.verdict ?? null,
            };
        }

        // ═══ MC-M1-TASK-11（FARM-04 0/20 回归修复）：**开摆料之前先把网格清空** ═══
        //
        // 【现象】本地 T11A_IRON trial_01 的 `probe.jsonl` 抓到的铁证：
        //   第一次 `craft_ok oak_planks gained=4` 之后，背包变成
        //   `oak_log:1, oak_planks:1, oak_planks:1, oak_sapling:2`
        //   —— **两个各只有 1 个的木板**卡在 2×2 网格格里没清掉。
        //   之后每一次合成都 `missing_ingredient` / `no_result` / `no_server_window_truth`。
        //
        // 【为什么这是级联的源头，而不是"一次偶发"】
        //   下面摆料循环里有一个 **early return**（`missing_ingredient`、
        //   `pickup_rejected`、`putback_rejected` …）：它在**已经往网格里放了料之后**返回，
        //   **没有把网格还原**。而本函数下一次进来时，那一格"已经是该物品" ⇒
        //   `if (win.slots[dst] && win.slots[dst].type === id) continue;` **跳过摆料**
        //   ⇒ 服务端看不到网格变化 ⇒ 不重算配方 ⇒ 结果格永远空
        //   ⇒ `no_server_window_truth`。**一次失败毁掉后面全部**。
        //   （与 `acceptClick` 不模拟配方消耗是同一个病根的另一面。）
        //
        // 【修法】进来先**无条件清空网格**：shift 点每一格 —— 1.16.1
        // `InventoryMenu.java:126-129` 对 index 1..4 的 quickMoveStack 就是
        // `moveItemStackTo(stack, 9, 45, true)`，材料**退回玩家背包**。
        // ⚠ 清空只在**本次还没摆料**时做，所以不存在"把刚摆好的配方自己吃掉"的问题；
        //   摆料后的清理由下面成功路径的 `gridCleared` 负责（那条不动）。
        const preCleared = [];
        for (let k = 1; k <= gridW * gridH; k++) {
            const s = resultSlot + k;
            const it = win.slots[s];
            if (!it) continue;
            preCleared.push(`${s}:${it.name}x${it.count}`);
            try {
                // shift（mode=1）点这一格 ⇒ 材料直接回背包，不经光标
                await clickCarryConfirmed(bot, win, { slot: s, mouseButton: 0, mode: 1, expectMove: true, timeoutMs: Math.min(timeoutMs, 800) });
            } catch { /* 清不掉就如实留在 gridCleared 字段里，不静默 */ }
            win.slots[s] = null;   // 客户端不模拟 quickMove，本地先归零（与服务端同向）
        }
        if (preCleared.length) {
            // ⚠ 这一条是本单最重要的新遥测：**"进来时网格是脏的"本身就是回归信号**
            win.slots[resultSlot] = null;
        }

        /**
         * 失败出口：**先清空网格再返回**。
         *
         * 这是本单级联 bug 的**根治点**：原来每一条 early return 都是裸 `return {ok:false,…}`，
         * 而此时网格里**可能已经摆了料**。那些料留在 2×2 里 ⇒ 下一次进来
         * `if (win.slots[dst] && …) continue` 跳过摆料 ⇒ 服务端不重算配方
         * ⇒ 结果格永远空 ⇒ `no_server_window_truth`。**一次失败毁掉后面全部。**
         * （本地 T11A_IRON trial_01 的 `oak_planks:1, oak_planks:1` 就是这么卡住的。）
         *
         * ⚠ 绝不用"把'未知'折成'没事'"那套：清不掉就**如实**把 leftovers 报上去。
         */
        const fail = async (reason, extra = {}) => {
            const leftovers = [];
            for (let k = 1; k <= gridW * gridH; k++) {
                const s = resultSlot + k;
                const it = win.slots[s];
                if (!it) continue;
                leftovers.push(`${s}:${it.name}x${it.count}`);
                try {
                    await clickCarryConfirmed(bot, win, { slot: s, mouseButton: 0, mode: 1, expectMove: true, timeoutMs: Math.min(timeoutMs, 600) });
                } catch { /* 清不掉就留在 leftovers 里，不静默 */ }
                win.slots[s] = null;
            }
            return { ok: false, reason, preCleared, leftovers, ...extra };
        };

        for (const { x, y, id } of cells) {
            const dst = cellSlot(x, y);
            if (win.slots[dst] && win.slots[dst].type === id) continue;   // 这一格已经是该物品
            if (!cur.item || cur.item.type !== id) {
                const src = findTypeInRange(win, range, id);
                if (src < 0) return await fail('missing_ingredient', { id, range: [range.start, range.end] });
                const held = win.slots[src];
                // ① 整摞拿起：点击后光标 = 那一格的东西
                const r1 = await cur.click(src, 0, 0, held);
                if (!r1.ok) return await fail(r1.rejected ? 'pickup_rejected' : 'pickup_no_ack', { verdict: r1, slot: src, cursor: describe(cur.item) });
                if (!cur.item || cur.item.type !== id) {
                    return await fail('pickup_cursor_mismatch', { id, want: id, got: describe(cur.item), cursorSource: cur.source, cursorMismatches: cur.mismatches });
                }
            }
            // ② 右键往网格格放 1 个：点击后光标 = 手上那摞 − 1
            const after = itemWithCount(bot, cur.item, cur.item.count - 1);
            const r2 = await cur.click(dst, 1, 0, after);
            if (!r2.ok) return await fail(r2.rejected ? 'place_rejected' : 'place_no_ack', { verdict: r2, slot: dst, cursor: describe(cur.item) });
        }

        // 手上余料放回（放整摞 ⇒ 光标清空）
        if (!cur.empty) {
            const held = cur.item;
            let dest = -1;
            for (let i = range.start; i < range.end; i++) {
                const t = win.slots[i];
                if (t && t.type === held.type && t.count < t.stackSize) { dest = i; break; }
            }
            if (dest < 0) for (let i = range.start; i < range.end; i++) { if (!win.slots[i]) { dest = i; break; } }
            if (dest < 0) {
                return await fail('no_slot_for_leftover', { cursor: describe(held), range: [range.start, range.end] });
            }
            const r = await cur.click(dest, 0, 0, null);
            if (!r.ok) return await fail(r.rejected ? 'putback_rejected' : 'putback_no_ack', { verdict: r, slot: dest, cursor: describe(cur.item) });
        }

        // 结果格真值：**多源**（MC-M1-TASK-11 / FARM-04 回归修复），不再单点依赖单格 set_slot。
        // 顺序：window_items 全量 → 单格 set_slot（缓冲）→ 模型（已被 ack 验证）。
        const srv = await srvResultTruth(resultSlot);
        const res = srv.ok ? srv.item : null;
        if (!res) {
            return await fail(srv.ok ? 'no_result' : 'no_server_window_truth', {
                resultVia: srv.via ?? 'none',
                grid: win.slots.slice(resultSlot + 1, resultSlot + 1 + gridW * gridH).map((s) => (s ? `${s.name}x${s.count}` : '-')).join(' '),
                cursor: describe(cur.item), cursorSource: cur.source, cursorMismatches: cur.mismatches,
            });
        }
        if (expectName && res.name !== expectName) {
            return await fail('result_wrong_item', { got: `${res.name}x${res.count}`, want: expectName, resultVia: srv.via });
        }
        // 取产物：shift 点结果格，直接进背包、不经光标
        const before = countItemsInRange(bot, win, range, res.name);
        // ── 取产物：改成 **两次 PICKUP**（左键拿起 → 左键放进空格），不用 shift/QUICK_MOVE ──
        //
        // ⚠⚠ 为什么不能用 shift（实跑 T09R5_DBG5 抓包钉死，本单第二个真 bug）：
        //   `AbstractContainerMenu.clicked()` 的 QUICK_MOVE 分支是一个 **do-while 循环**：
        //     `for (stack = quickMoveStack(slot); !stack.isEmpty() && isSame(槽内容, stack); stack = quickMoveStack(slot)) ☃ = stack.copy();`
        //   而**取走合成产物会触发配方重算，把一个新物品放回同一个槽**。
        //   抓包原文（take 的同一毫秒内，服务端连发两条）：
        //     `set_slot(0, 305:1)`（oak_pressure_plate —— 网格里只剩 1 块木板时它就是压力板）
        //     `set_slot(0, EMPTY)`
        //   ⇒ 循环第二轮的 `quickMoveStack` 拿到的是**那个新物品**，`isSame` 失败退出，
        //   而 `☃` 已经被覆盖成**最后一轮搬的那摞** ⇒ 返回值既不是产物、也不可预测。
        //   实测：我们上报 `stick×4`、服务端算出来是别的东西 ⇒ `accepted=false`。
        //   ⚠ 而且**这一击其实已经生效了**（`clicked()` 是先执行、再比对返回值）：
        //   抓包里 4 根木棍确实进了背包槽 44 —— **被拒不等于没发生**，只等于"你报错了"。
        //
        //   改用两次 PICKUP 后，两击的返回值都**完全可预测**（按 `predictClickedReturn`）：
        //     ① 左键点非空的结果格 ⇒ 返回该格的点击前内容（产物整摞）；
        //     ② 左键点一个**空**的背包格 ⇒ 返回 EMPTY。
        const take1 = await clickCarryConfirmed(bot, win, { slot: resultSlot, mouseButton: 0, mode: 0, expectMove: true, timeoutMs });
        if (!take1.ok) return await fail(take1.rejected ? 'take_rejected' : 'take_no_ack', { verdict: take1, got: `${res.name}x${res.count}` });
        // 放下：找一个**空**的背包格（服务端口径：主背包 9…35 + 快捷栏 36…44）
        let drop = -1;
        for (let i = range.start; i < range.end; i++) { if (!win.slots[i]) { drop = i; break; } }
        if (drop < 0) {
            // 没空位就如实报出来（产物此时还拿在光标上），不假装成功、也不静默丢掉
            return await fail('no_slot_for_result', { got: `${res.name}x${res.count}`, held: describe(win.selectedItem), range: [range.start, range.end] });
        }
        const take2 = await clickCarryConfirmed(bot, win, { slot: drop, mouseButton: 0, mode: 0, expectMove: true, timeoutMs });
        if (!take2.ok) return await fail(take2.rejected ? 'take_put_rejected' : 'take_put_no_ack', { verdict: take2, got: `${res.name}x${res.count}`, slot: drop });
        // 判据：产物落进**那一格**。两击的 ack 都 accepted ⇒ 服务端确实执行了；
        //   模型由 acceptClick 推进（预测已被 ack 验证过），所以这里读模型是可信的。
        const landed = win.slots[drop];
        if (!landed || landed.name !== res.name) {
            return await fail('result_not_landed', { slot: drop, got: landed ? `${landed.name}x${landed.count}` : null, want: res.name, verdict: take2 });
        }
        // ⚠⚠ **取件之后必须自己把网格"吃掉"**（本单实跑 T09R5F 抓到的第三个坑）：
        //   服务端 `ResultSlot.checkTakeAchievements` 在给出产物时会**从每个非空网格格里扣掉材料**，
        //   但 accepted 路径**不给网格格发任何更新**（ignoreSlotUpdateHack），
        //   而客户端的 `acceptClick` **不模拟配方消耗** ⇒ 模型里网格还是满的。
        //   ⇒ 下一次调用 `craftInGridConfirmed` 会看到"这一格已经是该物品"而**跳过摆料**，
        //   服务端也就不会重算配方、不发 `set_slot(0, 产物)` ⇒ 假失败 `no_server_window_truth`
        //   （实跑：第 1 次成功、第 2 次起全灭）。
        //   这里按"每格扣 1"扣掉：1.16.1 的实现就是对每个非空网格格 `removeItem(i, 1)`。
        const gridCleared = [];
        for (let k = 1; k <= gridW * gridH; k++) {
            const s = resultSlot + k;
            const it = win.slots[s];
            if (!it) continue;
            const left = it.count - 1;
            if (left <= 0) { win.slots[s] = null; gridCleared.push(`${s}:0`); }
            else { it.count = left; gridCleared.push(`${s}:${left}`); }
        }
        win.slots[resultSlot] = null;   // 产物已被取走（客户端不模拟重算，清掉避免读到陈旧成品）
        return {
            ok: true, took: res.count, gained: landed.count, dest: drop,
            // ⚠ `resultVia` 如实记**这一次的产物是从哪一级读到的**（TASK-11）。
            //   写死 `'set_slot'` 是 r6 的一个假陈述：本服 accepted 路径**根本不发**那一格，
            //   读到的绝大多数是 `model_after_ack`。写死会让"验证层退化了"这件事在遥测里看不见。
            resultVia: srv.via ?? 'unknown',
            takeVia: 'ack+prediction', viaPickup: true, gridCleared, preCleared,
            cursorSource: cur.source, cursorMismatches: cur.mismatches, cursorUpdates: cur.updates,
        };
    } finally {
        cur.stop();
        tap.stop();
        wholeWindowTruth.stop();
    }
}


function findTypeInRange(win, range, typeId) {
    for (let i = range.start; i < range.end; i++) {
        const s = win.slots[i];
        if (s && s.type === typeId) return i;
    }
    return -1;
}

/** 关窗并等服务端真的把窗口关掉（避免下一次开窗复用到分叉窗口） */
export async function closeWindowConfirmed(bot, win, timeoutMs = 1200) {
    if (!win) return true;
    if (bot.currentWindow && bot.currentWindow.id !== win.id) return true;
    const p = new Promise((resolve) => {
        const h = (w) => { if (!w || w.id === win.id) { bot.removeListener('windowClose', h); clearTimeout(t); resolve(true); } };
        const t = setTimeout(() => { bot.removeListener('windowClose', h); resolve(false); }, timeoutMs);
        bot.on('windowClose', h);
    });
    try { bot.closeWindow(win); } catch { /* 忽略 */ }
    return p;
}
