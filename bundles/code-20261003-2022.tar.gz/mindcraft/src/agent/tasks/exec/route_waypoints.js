// route_waypoints.js — MC-M1-TASK-11：**按路点走**（DECISION-02 §1「背作业路线 L0 精确坐标」）
//
// ── 为什么有这个文件 ─────────────────────────────────────────────────────────
// `nav.js` 的 `navTo(ctx, goal, opts)` **只吃单个 goal**（一个 `pf.goals.Goal*`），
// 而 route v2 的 `legs[].waypoints` 是**一串路点**（SCHEMA §5：相邻路点 ≤32 格）。
// 派单原话："`navTo` 只吃单个 goal，新写路点版放新文件" —— 所以本文件是**新增**的，
// `nav.js` 一字未改（B 线 r16/r19 都在 `nav.js` 上有活成果，不去碰它）。
//
// ── 口径（必须与 C 线参考读取器逐字一致）────────────────────────────────────
// 读 route 走 `bench/route/lib/route_v2.mjs` 的口径（SCHEMA §5）：
//   · `stand`   = **脚下那格**（不是身体格）
//   · `waypoints` = **身体格**（bot 站上去时脚所在的那一格，两者差 1）
// ⚠ 这条最容易搞错：`stand` 与 `waypoints` 不是同一个坐标系。route v2 自己的
//   `S0_iron.exact.targets[].standFor` 字段就是**身体格**（`standDist` 相对它算），
//   而 `exact.stand[]` 是脚下格 —— 本文件两个都用，并各自用对的口径。
//
// ── 三条硬纪律（都是本项目已经踩过的坑）────────────────────────────────────
//  ① **绝不把"没读到"折成"不需要处理"**（手册 §5）。`bot.blockAt` 在**区块未加载**时返回
//     `null`（不抛异常），而 `null?.name → Set.has(...)` 一律是 `false`
//     ⇒ 目标格"读不到"和"那里没有目标"会长得一模一样。判据一律三态：
//     `d dug / s skipped(已不是目标) / u unknown(读失败)`，**分开记**，不合并。
//  ② **动作成功 ≠ 收益到手**。挖完只说明方块没了；掉落物可能弹开 2 格外。
//     每次挖完都记 `invDelta`，"方块变 air" 与 "背包增加" 分成两个字段。
//  ③ **站位与目标要在该轴上至少差 1 格**（手册 §3：站位压在方块边界上时服务端射线打相邻格）。
//     导航到 target 时用 `GoalNear(…, 1)` 而不是精确 `GoalBlockTo`，并且**站位候选
//     逐个报告否决理由**（B 线 r16 的教训：兜底不许把目标换成一个已知不可达的东西）。

import fs from 'fs';
import path from 'path';
import { Vec3 } from 'vec3';
import pf from 'mineflayer-pathfinder';
import { navTo } from './nav.js';
import { digWithVerify } from './collect_resource_task.js';
import { countItems } from './task.js';

const LIQUIDS = new Set(['lava', 'flowing_lava', 'water', 'flowing_water']);
const AIR_NAMES = new Set(['air', 'cave_air', 'void_air']);

/** route v2 里 `what` 的取值（SCHEMA §5 的 examples）；S0 段实测只有 `dig`。 */
const DIG_WHATS = new Set(['dig']);

// ---------------------------------------------------------------------------
// 读 route
// ---------------------------------------------------------------------------

/**
 * 读 route v2 文件。**永不 throw**（手册 §5：绝不把"未知"折成"没事"）。
 * @returns {{ok:boolean, reason:string|null, doc:object|null, stations:object[], legs:object[]}}
 *   `ok=false` 时 `reason` 是稳定的机器可判码，调用方**必须**显式处理，
 *   不许 `if (!r.ok) return []` 就当"这一站没有目标"。
 */
export function loadRouteFile(file) {
    if (!file) return { ok: false, reason: 'NO_ROUTE_FILE', doc: null, stations: [], legs: [] };
    let raw;
    try { raw = fs.readFileSync(path.resolve(file), 'utf8'); }
    catch (e) { return { ok: false, reason: `UNREADABLE:${String(e).slice(0, 80)}`, doc: null, stations: [], legs: [] }; }
    let doc;
    try { doc = JSON.parse(raw); }
    catch (e) { return { ok: false, reason: `BAD_JSON:${String(e).slice(0, 80)}`, doc: null, stations: [], legs: [] }; }
    if (!doc || typeof doc !== 'object' || Array.isArray(doc)) {
        return { ok: false, reason: 'NOT_OBJECT', doc: null, stations: [], legs: [] };
    }
    // ⚠ **不静默接受 v1**。v1 没有 `exact` 块，任务层拿到 `stations[].exact === undefined`
    //   而"v1 文件"与"v2 文件但这一站没预勘"在调用方眼里一样 —— 那正是"没找到目标 =
    //   不需要处理"那个错的入口。schema 不对就是不对。
    if (doc.schema !== 'aidqq-route/2') {
        return { ok: false, reason: `SCHEMA:${JSON.stringify(doc.schema ?? null)}`, doc, stations: [], legs: [] };
    }
    return {
        ok: true, reason: null, doc,
        stations: Array.isArray(doc.stations) ? doc.stations : [],
        legs: Array.isArray(doc.legs) ? doc.legs : [],
    };
}

const isTriple = (p) => Array.isArray(p) && p.length === 3 && p.every(Number.isInteger);

/** 取一站的 `exact`（**判别式**：absent 与 present-but-empty 必须能分开）。 */
export function readExact(route, stationId) {
    const st = (route?.stations ?? []).find((s) => s && s.id === stationId);
    if (!st) return { present: false, reason: 'STATION_NOT_FOUND', stand: null, targets: null, hazards: null };
    const e = st.exact;
    if (!e || typeof e !== 'object' || Array.isArray(e)) {
        return { present: false, reason: 'NO_EXACT_BLOCK', stand: null, targets: null, hazards: null };
    }
    const stand = Array.isArray(e.stand) ? e.stand.filter(isTriple) : [];
    const targets = Array.isArray(e.targets) ? e.targets.filter((t) => t && isTriple(t.xyz)) : [];
    const hazards = Array.isArray(e.hazards) ? e.hazards.filter(isTriple) : [];
    return { present: true, reason: null, stand, targets, hazards };
}

/** 取 from→to 那条 leg 的路点（**身体格**）。找不到返回 `null`，不是 `[]`。 */
export function legWaypoints(route, from, to) {
    const leg = (route?.legs ?? []).find((l) => l && l.from === from && l.to === to);
    if (!leg || !Array.isArray(leg.waypoints)) return null;
    return { dim: leg.dim ?? null, notes: leg.notes ?? null, waypoints: leg.waypoints.filter(isTriple) };
}

// ---------------------------------------------------------------------------
// 目标规划（纯函数，可离线单测）
// ---------------------------------------------------------------------------

/**
 * 把 `exact.targets` 变成"按 order 排好的挖掘计划"。
 * ⚠ **只做形状与排序，不做任何"这块还有没有必要挖"的判断** ——
 *   那是运行期对着服务端真值判的（`planDigTargets` 是纯函数，拿不到 bot）。
 * @returns {{plan:Array, skippedNoOrder:number}} 每项 {order, xyz, tool, standFor, standDist, airFaces}
 */
export function planDigTargets(exact) {
    const src = Array.isArray(exact?.targets) ? exact.targets : [];
    const withOrder = src.filter((t) => t && Number.isInteger(t.order));
    const plan = withOrder
        .slice()
        .sort((a, b) => (a.order - b.order) || (a.xyz[1] - b.xyz[1]) || (a.xyz[0] - b.xyz[0]) || (a.xyz[2] - b.xyz[2]));
    return { plan, skippedNoOrder: src.length - withOrder.length };
}

/**
 * 站位候选排序：route 给的 `standFor`（身体格）优先，其后是 `exact.stand`（脚下格 → 站上去身体格是 y+1）。
 * 返回**全部**候选及理由，不做取舍 —— 取舍是运行期对着真值的事（纪律③）。
 * @returns {Array<{body:number[], from:string, why:string}>}
 */
export function standCandidates(exact, target) {
    const out = [];
    const t = target?.xyz;
    if (Array.isArray(target?.standFor) && isTriple(target.standFor)) {
        out.push({ body: target.standFor.slice(), from: 'target.standFor', why: 'route 直接给的这一块的工作站位（身体格）' });
    }
    for (const s of (Array.isArray(exact?.stand) ? exact.stand : [])) {
        if (!isTriple(s)) continue;
        out.push({
            body: [s[0], s[1] + 1, s[2]],   // 脚下格 → 身体格高一格
            from: 'exact.stand',
            why: `作业站位脚下格 ${JSON.stringify(s)}（身体格 y+1）`,
        });
    }
    if (t) {
        // 兜底：目标正上方（挖头顶那一格时站旁边）
        for (const off of [[0, 1, 0], [0, 2, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]) {
            out.push({ body: [t[0] + off[0], t[1] + off[1], t[2] + off[2]], from: 'target.neighbour', why: `目标邻格偏移 ${JSON.stringify(off)}` });
        }
    }
    // 去重（按 body），保持顺序
    const seen = new Set();
    return out.filter((c) => { const k = c.body.join(','); if (seen.has(k)) return false; seen.add(k); return true; });
}

/** 3D 欧氏距离（route_v2.mjs `waypointDistance` 同口径）。形状不对返回 NaN。 */
export function dist3(a, b) {
    if (!isTriple(a) || !isTriple(b)) return NaN;
    return Math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2);
}

// ---------------------------------------------------------------------------
// 运行期：按路点走 + 按 exact 目标挖
// ---------------------------------------------------------------------------

/**
 * 逐个路点走完一条 leg。**路点是几何点**（`evidenceLevel=geometry`），
 * 交给 pathfinder 逐点走，**允许挖**（不设 allowDig=false）。
 *
 * @param {object} ctx 任务上下文（`ctx.bot` / `ctx.telemetry` / `ctx.run`）
 * @param {Array<number[]>} waypoints 身体格路点
 * @param {object} opts {label, timeoutMs, legs}
 * @returns {Promise<{ok:boolean, reached:number, total:number, at:number[]|null, failedAt:number}>}
 */
export async function navWaypoints(ctx, waypoints, opts = {}) {
    const bot = ctx.bot;
    const label = opts.label ?? 'legs';
    const timeoutMs = opts.timeoutMs ?? 45000;
    const total = Array.isArray(waypoints) ? waypoints.length : 0;
    if (!total) {
        ctx.telemetry('nav_waypoints_empty', { label });
        return { ok: false, reached: 0, total: 0, at: null, failedAt: -1 };
    }
    for (let i = 0; i < total; i++) {
        const w = waypoints[i];
        // 已在这一格（±1）就不走 —— 手册 §4 记过的 r14 教训：`legs` 上限按"实际移动"计，
        // 站在原地反复重算是热循环的来源。
        const here = bot.entity?.position?.floored();
        if (here && here.x === w[0] && here.y === w[1] && here.z === w[2]) {
            ctx.telemetry('nav_waypoint_skip', { label, i, total, at: w, why: 'already_here' });
            continue;
        }
        // GoalNear(radius=1)：站位与目标在该轴上至少差 1 格（手册 §3）
        const goal = new pf.goals.GoalNear(w[0], w[1], w[2], 1);
        const ok = await navTo(ctx, goal, { label: `${label}#${i + 1}/${total}`, timeoutMs, lavaGuard: true });
        if (!ok) {
            const p = bot.entity?.position?.floored();
            ctx.telemetry('nav_waypoints_fail', { label, i, total, wp: w, bot: p ? [p.x, p.y, p.z] : null });
            return { ok: false, reached: i, total, at: p ? [p.x, p.y, p.z] : null, failedAt: i };
        }
    }
    const p = bot.entity?.position?.floored();
    ctx.telemetry('nav_waypoints_done', { label, total, at: p ? [p.x, p.y, p.z] : null });
    return { ok: true, reached: total, total, at: p ? [p.x, p.y, p.z] : null, failedAt: -1 };
}

/**
 * 按 `exact.targets` 逐个挖（不再扫描找资源）。
 *
 * 每一格的判据是**三态**（纪律①），并且"方块没了"与"东西到手了"**分成两个字段**（纪律②）：
 *   `readState`: 'target' | 'gone'(已不是目标，跳过) | 'unknown'(读失败，**不算** gone)
 *   `invDelta` / `dropSeen`: 收益是否真的到手
 *
 * @returns {Promise<{dug:number, gone:number, unknown:number, failed:number, gained:number, items:object}>}
 */
export async function digExactTargets(ctx, exact, opts = {}) {
    const bot = ctx.bot;
    const label = opts.label ?? 'exact';
    const res = { dug: 0, gone: 0, unknown: 0, failed: 0, gained: 0, items: {} };
    const { plan, skippedNoOrder } = planDigTargets(exact);
    if (skippedNoOrder) ctx.telemetry('dig_exact_no_order', { label, skipped: skippedNoOrder });
    if (!plan.length) {
        // ⚠ 绝不等价成"不需要挖"：分不清是"这一站没目标"还是"目标没 order"
        ctx.telemetry('dig_exact_empty', { label, hasExact: !!exact, targets: Array.isArray(exact?.targets) ? exact.targets.length : null });
        return res;
    }
    for (let i = 0; i < plan.length; i++) {
        const t = plan[i];
        const pos = new Vec3(t.xyz[0], t.xyz[1], t.xyz[2]);
        const b = bot.blockAt(pos);
        // —— 三态判据（纪律①）——
        if (b == null) {
            res.unknown++;
            ctx.telemetry('dig_exact_unknown', { label, i, pos: t.xyz, why: 'blockAt null（区块未加载 或 读失败）—— 不计为 gone' });
            continue;
        }
        if (AIR_NAMES.has(b.name)) {
            res.gone++;
            ctx.telemetry('dig_exact_already_gone', { label, i, pos: t.xyz });
            continue;
        }
        // 站位：逐候选尝试，每个候选都记否决理由（纪律③）
        const cands = standCandidates(exact, t);
        const foot = bot.entity?.position?.floored();
        let staged = false;
        for (const c of cands) {
            const d = foot ? dist3([foot.x, foot.y, foot.z], c.body) : NaN;
            // 已经站在候选位（≤2 格）就不用再导航
            if (d <= 2) { staged = true; ctx.telemetry('dig_exact_stand', { label, i, pos: t.xyz, at: c.body, from: c.from, how: 'near' }); break; }
            const goal = new pf.goals.GoalNear(c.body[0], c.body[1], c.body[2], 1);
            const ok = await navTo(ctx, goal, { label: `${label}#${i + 1}@stand`, timeoutMs: opts.standTimeoutMs ?? 20000 });
            ctx.telemetry('dig_exact_stand_try', { label, i, pos: t.xyz, cand: c.body, from: c.from, ok, dist: Number.isFinite(d) ? +d.toFixed(2) : null });
            if (ok) { staged = true; break; }
        }
        if (!staged) {
            res.failed++;
            ctx.telemetry('dig_exact_no_stand', { label, i, pos: t.xyz, cands: cands.length });
            continue;
        }
        // 挖：三通道验证沿用 collect_resource_task 的 digWithVerify（同一口径）
        const def = { blocks: [b.name], drops: opts.drops ?? [] };
        const invBefore = opts.drops?.length ? countItems(bot, opts.drops) : 0;
        const r = await digWithVerify(ctx, b, def);
        if (!r.ok) {
            res.failed++;
            ctx.telemetry('dig_exact_fail', { label, i, pos: t.xyz, block: b.name, reason: r.reason ?? null, error: r.error ?? null });
            continue;
        }
        res.dug++;
        // —— 收益到手与否，与"方块没了"分开记（纪律②）——
        let invDelta = 0;
        if (opts.drops?.length) {
            const dl = Date.now() + 1200;
            while (Date.now() < dl) {
                invDelta = countItems(bot, opts.drops) - invBefore;
                if (invDelta > 0) break;
                await new Promise((r2) => setTimeout(r2, 120));
            }
        }
        res.gained += invDelta;
        ctx.telemetry('dig_exact_ok', {
            label, i, pos: t.xyz, block: b.name, how: r.how ?? null, invDelta,
            // 方块是否真的变成空气（与"挖成功"分开）
            nowAir: AIR_NAMES.has(bot.blockAt(pos)?.name ?? ''),
        });
    }
    ctx.telemetry('dig_exact_done', { label, ...res, items: res.items });
    return res;
}

export default { loadRouteFile, readExact, legWaypoints, planDigTargets, standCandidates, dist3, navWaypoints, digExactTargets };
