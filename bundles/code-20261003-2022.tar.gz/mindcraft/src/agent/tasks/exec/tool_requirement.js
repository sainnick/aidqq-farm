// tool_requirement.js — MC-M1-TASK-02 工具缺失解析器
//
// 任务书 §5：TASK-01 里 TOOL_MISSING 只是终止错误；本轮升级为「可递归解决的依赖」：
//   Resource Task → TOOL_MISSING → 问本解析器 → 得到可确定性合成的工具 →
//   CraftingTask 子任务 → 成功 → 恢复原 Resource Task。
//
// 「确定性可解决」的判据（严格口径）：候选工具取自 minecraft-data 的 block.harvestTools
// （版本真值，不是手写表），按工具等级从低到高逐个过 RecipeResolver.plan 空库存试解析——
// 全链路（工具→木板→木棍→工作台→采集 family）都能落地的才算可解决。任何一环落不了地
// （如铁镐需要 cobblestone 之外还差熔炼体系时）→ 返回 null → 上层保持 FAILED(TOOL_MISSING)。
// 未来 BASIC-iron 把 cobblestone/熔炉接入后，这里会自动解锁石镐/铁镐，无需改本文件。

import { RecipeResolver } from './recipe_resolver.js';

const TIER_ORDER = ['wooden', 'golden', 'stone', 'iron', 'diamond', 'netherite'];

function tierRank(toolName) {
    const m = TIER_ORDER.findIndex((t) => toolName.startsWith(`${t}_`));
    return m === -1 ? TIER_ORDER.length : m;
}

/**
 * 给定采不动的目标方块名，返回「最便宜且可确定性合成」的工具物品名；不可解决返回 null。
 * 徒手可采的方块（无 harvestTools）直接返回 null——那不是工具问题。
 */
export function resolveSolvableTool(bot, blockName) {
    const reg = bot.registry;
    const block = reg.blocksByName[blockName];
    if (!block || !block.harvestTools) return null;
    const candidates = Object.keys(block.harvestTools)
        .map((id) => reg.items[id]?.name)
        .filter(Boolean)
        .sort((a, b) => tierRank(a) - tierRank(b));
    let resolver;
    try { resolver = RecipeResolver.forBot(bot); } catch { return null; }
    for (const tool of candidates) {
        try {
            const plan = resolver.plan(tool, 1, {}, [], {});
            if (!plan.error) return tool;
        } catch { /* 单个候选解析异常 → 试下一个 */ }
    }
    return null;
}
