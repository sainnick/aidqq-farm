// task.js — MC-M1-TASK-01 本地任务层：Task 基类与生命周期状态机
//
// 上一级 tasks/tasks.js 是 Mindcraft 原生的 benchmark Task（settings 驱动的目标注入），
// 与本执行层无关；本目录（exec/）是 MISSION→TASK→COMPOSITE→PRIMITIVE 四层中的 TASK 层
// 正式落地（架构见 docs/reuse/execution-architecture.md）。
//
// 设计铁律（MC-M1-TASK-01 任务书）：
//   - Task 自己管理执行生命周期，decider/上层不再手工拼 find→walk→dig 序列。
//   - 所有 trial 必须明确进入 SUCCESS/FAILED/TIMEOUT/ABORTED，禁止永远 RUNNING。
//   - failure reason 必须结构化（FailReason），禁止只有一句 "task failed"。
//   - 本层零 LLM：不 import dm_client/decider，执行闭环完全本地。
//
// 来源（MC-EXEC-REUSE-01 license matrix）：
//   - Task 生命周期与状态语义：PORT 自 AltoClef（MIT）TaskSystem 思想，思想级移植非逐行复制。
//   - 机制底料：experiments/exec-reuse-spike（本线 REUSE SPIKE，4/4 PASS）已验证逻辑产品化。

export const TaskStatus = {
    READY: 'READY',
    RUNNING: 'RUNNING',
    SUCCESS: 'SUCCESS',
    FAILED: 'FAILED',
    TIMEOUT: 'TIMEOUT',
    ABORTED: 'ABORTED',
};

export const TERMINAL = new Set([TaskStatus.SUCCESS, TaskStatus.FAILED, TaskStatus.TIMEOUT, TaskStatus.ABORTED]);

// 结构化失败原因（任务书 §12 口径，向上汇报禁止裸 "failed"）
export const FailReason = {
    NO_RESOURCE_FOUND: 'NO_RESOURCE_FOUND',   // 搜索+换区+就地挖掘全部枯竭
    NAVIGATION_FAILED: 'NAVIGATION_FAILED',   // pathfinder 无法到达/超时
    DIG_FAILED: 'DIG_FAILED',                 // 挖掘未通过验证（方块没变/没进包/没掉落）
    NO_PROGRESS: 'NO_PROGRESS',               // hard stuck：多轮恢复仍无任务进展
    TOOL_MISSING: 'TOOL_MISSING',             // 没有可采集目标方块的工具
    UNSAFE_TARGET: 'UNSAFE_TARGET',           // 液体/坠落/落方块守卫拒绝
    TIMEOUT: 'TIMEOUT',
    DEATH: 'DEATH',
    PRECONDITION: 'PRECONDITION',             // canStart 不满足（如世界未就绪）
    UNSUPPORTED_RESOURCE: 'UNSUPPORTED_RESOURCE',
    ABORTED: 'ABORTED',                       // 外部中止（runtime 强制）
    INTERNAL: 'INTERNAL',
    // —— MC-M1-TASK-02 新增（任务书 §7 口径）——
    RECIPE_NOT_FOUND: 'RECIPE_NOT_FOUND',           // 目标物品无配方（或版本数据缺失）
    DEPENDENCY_CYCLE: 'DEPENDENCY_CYCLE',           // 依赖链 A→B→A，守卫拦截
    CRAFT_FAILED: 'CRAFT_FAILED',                     // 合成动作执行后库存未验证通过
    MISSING_STATION: 'MISSING_STATION',             // 需要 3x3 工作台但无处获取/放置
    PLACEMENT_FAILED: 'PLACEMENT_FAILED',           // 工作台放置未通过方块验证
    DEPENDENCY_FAILED: 'DEPENDENCY_FAILED',         // 子依赖任务失败（detail.childReason 带结构化原因）
    DEPENDENCY_UNSUPPORTED: 'DEPENDENCY_UNSUPPORTED', // 依赖既不可采集也无配方（闸门：不自动解决）
    DEPENDENCY_TOO_DEEP: 'DEPENDENCY_TOO_DEEP',     // 嵌套深度超限
    DEPENDENCY_BUDGET: 'DEPENDENCY_BUDGET',         // 同一依赖连续失败超预算（防无限重试）
    // —— MC-M1-TASK-06 新增（BASIC-iron）——
    FUEL_MISSING: 'FUEL_MISSING',                   // 熔炼无可用燃料（煤/木板/原木全无）
    SMELT_FAILED: 'SMELT_FAILED',                   // 熔炼会话后库存增量验证未达标
    FURNACE_UNAVAILABLE: 'FURNACE_UNAVAILABLE',     // 无现成熔炉且放不出（手里也没炉子）
};

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function countItems(bot, names) {
    return bot.inventory.items()
        .filter((i) => names.includes(i.name))
        .reduce((s, i) => s + i.count, 0);
}

export function posKey(pos) {
    return `${pos.x},${pos.y},${pos.z}`;
}

/**
 * ExecTask：所有执行层任务的基类。
 * 子类实现 canStart/tick/getProgress/progressSignature + 可选 onStart/onStuck/cleanup。
 * 状态只能经 _succeed/_fail/_timeout/_abort 迁移，保证终态唯一、可追溯。
 */
export class ExecTask {
    constructor(id, opts = {}) {
        this.id = id;
        this.status = TaskStatus.READY;
        this.failReason = null;
        this.result = {};             // 任务产物（找到的目标、挖到几块等）
        this.timeoutMs = opts.timeoutMs ?? 120000;
        this._startedAt = 0;
        this._finishedAt = 0;
        this.transitions = [];        // [{from,to,reason,t}]
    }

    canStart(ctx) { return true; }
    async onStart(ctx) {}
    async tick(ctx) {}
    async cleanup(ctx) {}
    async onSuccess(ctx) {}
    async onFailure(ctx, reason) {}

    // 任务进度指标（给报告/调试看，人类可读）
    getProgress(ctx) { return {}; }
    // 进度签名：变化即代表任务有实质推进（ProgressChecker 用。注意：纯位移不算，
    // 必须绑定任务语义——目标距离、已挖块数、搜索半径推进等）
    progressSignature(ctx) { return ''; }

    isComplete() { return TERMINAL.has(this.status); }
    elapsed() { return (this._finishedAt || Date.now()) - this._startedAt; }
    timedOut() { return this._startedAt > 0 && Date.now() - this._startedAt > this.timeoutMs; }

    // 重新进入搜索/采集时复用实例：清 round 级状态，保留积累状态（候选队列/黑名单语义由子类定义）
    restart() {
        this.status = TaskStatus.READY;
        this.failReason = null;
        this.result = {};
        this._startedAt = 0;
        this._finishedAt = 0;
        this.onRestart?.();
    }

    _transition(to, reason) {
        const from = this.status;
        this.status = to;
        const rec = { from, to, reason: reason ?? null, t: Date.now() };
        this.transitions.push(rec);
        ctxTelemetry(this, 'task_transition', { task: this.id, ...rec });
        return rec;
    }

    _succeed(result = {}) {
        if (this.isComplete()) return;
        this._finishedAt = Date.now();
        Object.assign(this.result, result);
        this._transition(TaskStatus.SUCCESS);
    }

    _fail(reason, detail = {}) {
        if (this.isComplete()) return;
        this._finishedAt = Date.now();
        this.failReason = reason;
        Object.assign(this.result, detail);
        this._transition(TaskStatus.FAILED, reason);
    }

    _timeout(detail = {}) {
        if (this.isComplete()) return;
        this._finishedAt = Date.now();
        this.failReason = FailReason.TIMEOUT;
        Object.assign(this.result, detail);
        this._transition(TaskStatus.TIMEOUT, FailReason.TIMEOUT);
    }

    _abort(reason) {
        if (this.isComplete()) return;
        this._finishedAt = Date.now();
        this.failReason = FailReason.ABORTED;
        this.result.abortCause = reason ?? null;
        this._transition(TaskStatus.ABORTED, FailReason.ABORTED);
    }
}

// ctx 上的遥测是可选的（子任务单测时可无 ctx）
function ctxTelemetry(task, event, data) {
    task._ctx?.telemetry?.(event, data);
}
