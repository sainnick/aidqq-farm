// acquire_resource_task.js — MC-M1-TASK-01/02 Task: AcquireResource（复合任务）
//
// 统一表达「我要 N 个某种资源」。TASK-01 支持 stone family；TASK-02 接入 log family
// 并验证资源无关性（一切资源特化假设已下沉到 resources.js 定义表）。
// 本地闭环（任务书 §4 铁律）：搜索 → 导航 → 采集 → 检查 → 重入，全程不询问 LLM。
//
// 编排策略（spike runLoop 的 task 化 + TASK-02 工具救援）：
//   inventory 满足 ─────────────────────────────→ SUCCESS
//   Find（本地直检→扩展扫描→wander→relocate）
//     ├─ found → Collect(target)：挖到 → 重入 Find；连续空手 → digdown（仅 digdownFallback 资源）
//     └─ 搜索枯竭 → digdown（石头类兜底）/ 直接 FAILED（原木类：地下没有树）
//   digdown 有产出 → 重入 Find；连续无产出 → FAILED(NO_RESOURCE_FOUND)
//
//   任何阶段 TOOL_MISSING（目标方块本身采不动）→ 任务书 §5 升级：不再直接 FAILED，
//   问 ToolRequirement Resolver → 可确定性合成的工具 → runChild(CraftingTask) 子任务
//   → 成功 → 恢复本任务（重入 Find，背包已有多余材料不浪费）；失败 → FAILED(TOOL_MISSING)
//   带子任务结构化原因。真正无法解决的（无配方/依赖不支持）仍然快速失败，不空转。

import { ExecTask, FailReason, countItems } from './task.js';
import { resourceDef } from './resources.js';
import { resolveSolvableTool } from './tool_requirement.js';
import { runChild } from './task_stack.js';
import { FindResourceTask } from './find_resource_task.js';
import { CollectResourceTask } from './collect_resource_task.js';
import { FlintCollectTask } from './flint_collect_task.js';
import { CraftingTask } from './crafting_task.js';
import { driveTask } from './task_runner.js';
import { navTo } from './nav.js';
import pf from 'mineflayer-pathfinder';

export class AcquireResourceTask extends ExecTask {
    constructor(opts = {}) {
        // TASK-02：根任务从零 bootstrap 时（无 kit），整条木器链长于 TASK-01 的纯采集，
        // 默认超时放宽到 420s；bench/上层仍可显式覆盖。
        super('AcquireResourceTask', {
            // MC-M1-TASK-06b：sideQuest（清尾找沙砾+重埋循环 ~1-2min）与主资源共用本步骤，
            // 超时自动 +120s；无 sideQuest 的采集保持原口径（回归线不受影响）
            timeoutMs: (opts.timeoutMs ?? 420000) + (opts.sideQuest ? 120000 : 0),
        });
        this.resource = opts.resource ?? 'stone';
        this.count = opts.count ?? 16;
        this.def = resourceDef(this.resource);
        // MC-M1-TASK-06b：sideQuest（搭车资源，如 flint 搭 iron_ore 的地下窗口）。规划层
        // 把 flint 计数并进 iron_ore 的 acquire 步骤（recipe_resolver._frontloadAcquires），
        // 分支挖矿的地下阶段顺手采暴露沙砾；主资源达标而 sideQuest 未达时进入有界清尾。
        this.sideQuest = opts.sideQuest ?? null;
        this.sideDef = this.sideQuest ? resourceDef(this.sideQuest.resource) : null;
        this.findTimeoutMs = opts.findTimeoutMs ?? 150000;
        this.collectTimeoutMs = opts.collectTimeoutMs ?? 90000;
        this.digdownTimeoutMs = opts.digdownTimeoutMs ?? 120000;
        this.toolRescueTimeoutMs = opts.toolRescueTimeoutMs ?? 300000;
        this.relocateBudget = opts.relocateBudget ?? 8;
        this.maxDryRounds = opts.maxDryRounds ?? 4;
        this.sideRoundsMax = opts.sideRoundsMax ?? 3;

        this.find = new FindResourceTask({
            resource: this.resource,
            timeoutMs: this.findTimeoutMs,
            // MC-M1-TASK-04 修复①（M3B1-08：34s 拿镐 → 155s 游走 → 189s 才开始往下挖）：
            // digdownFallback 资源（石类）空扫描早退 = 0——扫描半径内没有可达的裸露候选时
            // 直接转入 digdown，不先游走；游走/换区只作为往下挖失败后的兜底（首挖之后由
            // _enterDigdown 放宽到 1）。无兜底资源（原木）必须禁用（Infinity）：B2R4-t16 教训，
            // 无树区域的活路是 relocate，早退会在 wander 阶段直接 FAIL，把换区整条路堵死。
            emptyExitAfterWanders: this.def.digdownFallback ? 0 : Infinity,
            // 无地下兜底的资源（原木）换区距离加宽：树可能离出生点很远（B2R2-t5/t14）
            relocateRange: this.def.digdownFallback ? undefined : [96, 160],
        });
        // MC-M1-TASK-06：燧石 family（挖沙砾→10% 掉燧石→重埋重挖循环）用专用采集器；
        // 铁矿 family 下挖用 branch 模式（先复用 digdown 步进器下到 y≤40 矿带，再分支掘进）。
        // 两者对外接口（result.mined / failReason / target / restart）与 CollectResourceTask 一致，
        // acquire 的 phase 编排零改动。
        this.collect = this.def.specialFlint
            ? new FlintCollectTask({ resource: this.resource, count: this.count, timeoutMs: Math.max(this.collectTimeoutMs, 240000) })
            : new CollectResourceTask({ resource: this.resource, count: this.count, timeoutMs: this.collectTimeoutMs });
        this.digdown = this.def.branchMine
            ? new CollectResourceTask({ resource: this.resource, count: this.count, branch: true, timeoutMs: this.digdownTimeoutMs, digdownMinY: this.def.digdownMinY ?? 16, sideQuest: this.sideQuest })
            : new CollectResourceTask({ resource: this.resource, count: this.count, digdown: true, timeoutMs: this.digdownTimeoutMs });
        // MC-M1-TASK-06b 迭代 3：清尾用「完整能力嵌套采集」（_tickSideQuest 里现场
        // new AcquireResourceTask(flint)，全半径扫描 + wander/relocate 阶梯 + 铲子 +
        // 重埋循环，150s 有界）——DEV1 的缩水自定义 Find 在地表铁矿路线的局 4 轮全空
        //（无分支顺手囤沙砾时没有真实找沙砾能力）。
        this.phase = 'idle';
        this.rounds = 0;
        this.dry = 0;
        this.digdownDry = 0;
        this._digdownEntered = false;  // 修复①：是否已进入过 digdown（决定空扫描早退档位）
        this._sideRounds = 0;          // 06b：清尾轮次（有界）
        this.rescueBlock = null;   // 触发工具救援的目标方块名
        this._activeChild = null;  // 救援子任务签名桥接
    }

    countMet(ctx) { return this.mainMet(ctx) && this.sideMet(ctx); }
    mainMet(ctx) { return countItems(ctx.bot, this.def.drops) >= this.count; }
    sideMet(ctx) {
        if (!this.sideQuest) return true;
        return countItems(ctx.bot, this.sideDef.drops) >= this.sideQuest.count;
    }

    // 进入 digdown 的唯一入口（MC-M1-TASK-04 修复①）：首次进挖后把 find 的空扫描早退
    // 放宽到 1 次 wander——「游走和换区只作为往下挖失败后的兜底」，兜底路径需要 wander→
    // relocate 阶梯活着（水平挪走找新的下挖点），不能再秒退。
    _enterDigdown(ctx) {
        this.digdown.restart();
        if (!this._digdownEntered) {
            this._digdownEntered = true;
            this.find.emptyExitAfterWanders = 1;
        }
        ctx.telemetry('acquire_digdown_entry', { rounds: this.rounds, y: Math.floor(ctx.bot.entity?.position?.y ?? 0) });
        this.phase = 'digdown';
    }

    progressSignature(ctx) {
        let subSig = '';
        const sub = this.phase === 'find' ? this.find
            : this.phase === 'collect' ? this.collect
                : this.phase === 'digdown' ? this.digdown
                    : this.phase === 'sidequest' ? (this._sideSub ?? null)
                        : this._activeChild;
        try { if (sub) subSig = sub.progressSignature(ctx); } catch {}
        const sqSig = this.sideQuest ? `|sq${countItems(ctx.bot, this.sideDef.drops)}` : '';
        return `${this.phase}|r${this.rounds}|${subSig}${sqSig}`;
    }

    getProgress(ctx) {
        return {
            phase: this.phase,
            rounds: this.rounds,
            dry: this.dry,
            relocateBudget: this.relocateBudget,
            inv: countItems(ctx.bot, this.def.drops),
        };
    }

    async tick(ctx) {
        if (this.countMet(ctx)) {
            this._succeed({ rounds: this.rounds, finalCount: countItems(ctx.bot, this.def.drops) });
            return;
        }
        // MC-M1-TASK-06b：主资源已够而 sideQuest 未够 → 有界清尾（地下窗口没顺手凑齐的
        // 沙砾在这里补）。清尾预算尽仍未够 → 带着缺口放行（result.sideQuestUnmet 记账，
        // 上游合成步骤缺料会走它自己的 replan 通道）。
        if (this.mainMet(ctx) && !this.sideMet(ctx) && this.phase !== 'sidequest') {
            this.phase = 'sidequest';
            ctx.telemetry('sidequest_phase', {
                resource: this.sideQuest.resource, need: this.sideQuest.count,
                have: countItems(ctx.bot, this.sideDef.drops), y: Math.floor(ctx.bot.entity?.position?.y ?? 0),
            });
            return;
        }
        switch (this.phase) {
            case 'idle':
                ctx.telemetry('acquire_start', { resource: this.resource, count: this.count });
                // 主动前置救援（B2R2-t5/t14 教训）：资源需要工具而包里没有时，在「还在地面、
                // 树就在眼前」的现在就把整条合成链做完，杜绝「挖下坑才发现缺工具」的死刑局
                if (this._needsToolRescueUpfront(ctx)) {
                    this.rescueBlock = this.def.blocks[0];
                    this.phase = 'tool_rescue';
                    return;
                }
                this.phase = 'find';
                return;
            case 'find': {
                this.find.maxRelocates = Math.max(0, Math.min(2, this.relocateBudget));
                this.find.restart();
                await driveTask(this.find, ctx, { tickMs: 200 });
                this.relocateBudget = Math.max(0, this.relocateBudget - this.find.relocatesUsed);
                if (this.find.status === 'SUCCESS') {
                    if (this.find.result.vertical) {
                        // 纵向探针命中：资源在脚下但埋着，够不着 → 就地挖（远征无意义）。
                        // 仅对 digdownFallback 资源有意义（原木永远不在脚下地下）。
                        ctx.telemetry('acquire_vertical_shortcut', { depth: this.find.result.depth });
                        this._enterDigdown(ctx);
                    } else {
                        this.collect.target = this.find.result.target;
                        this.collect.restart();
                        this.phase = 'collect';
                    }
                } else if (this.def.digdownFallback) {
                    // 搜索枯竭/超时 → 就地阶梯下挖兜底（MC-M1-TASK-04 修复①：不游走，直接挖）
                    this._enterDigdown(ctx);
                    return;
                } else {
                    this._fail(FailReason.NO_RESOURCE_FOUND, {
                        rounds: this.rounds,
                        searches: ctx.run.counters.searches,
                        relocates: 8 - this.relocateBudget,
                        blacklist: ctx.run.blacklist.size,
                    });
                }
                return;
            }
            case 'collect': {
                this.collect.restart();
                await driveTask(this.collect, ctx, { tickMs: 200 });
                this.rounds++;
                if (this.countMet(ctx)) { this._succeed({ rounds: this.rounds }); return; }
                if (this.collect.failReason === FailReason.TOOL_MISSING) {
                    this.rescueBlock = this.collect.result.blockName ?? this.def.blocks[0];
                    this.phase = 'tool_rescue';
                    return;
                }
                if ((this.collect.result.mined ?? 0) > 0) {
                    this.dry = 0;
                    this.phase = 'find'; // 不足 → 自动重入搜索（不询问 LLM）
                    return;
                }
                // MC-M1-TASK-04 修复③：导航失败不是「采不到」而是「够不到」——候选连同
                // 半径 4 格同类已在 Collect 内拉黑（nav_blacklist_expand 遥测），不消耗
                // dry round，立即换下一个候选；队列耗尽后由 find 的 wander/relocate 兜底
                if (this.collect.failReason === FailReason.NAVIGATION_FAILED) {
                    ctx.telemetry('acquire_nav_skip', { rounds: this.rounds, blacklist: ctx.run.blacklist.size });
                    this.phase = 'find';
                    return;
                }
                this.dry++;
                ctx.telemetry('acquire_dry_round', {
                    dry: this.dry,
                    source: this.collect.result.targetDead ? 'target_dead' : 'no_gain',
                    failReason: this.collect.failReason,
                });
                if (this.dry >= this.maxDryRounds) { this._fail(FailReason.NO_PROGRESS, { rounds: this.rounds, dry: this.dry }); return; }
                if (this.dry >= 2) {
                    if (this.def.digdownFallback) {
                        this.phase = 'digdown';
                    } else {
                        // 无地下兜底的资源（原木）：连续采不到多半是「够不到的死候选」（隔水/高差），
                        // 强制换观测点（清队列→wander→relocate），别在 dry 轮数上烧到 NO_PROGRESS
                        this.find.forceExplore();
                        this.phase = 'find';
                    }
                    return;
                }
                this.phase = 'find';
                return;
            }
            case 'digdown': {
                this.digdown.restart();
                await driveTask(this.digdown, ctx, { tickMs: 200 });
                this.rounds++;
                if (this.countMet(ctx)) { this._succeed({ rounds: this.rounds }); return; }
                if (this.digdown.failReason === FailReason.TOOL_MISSING) {
                    this.rescueBlock = this.digdown.result.blockName ?? this.def.blocks[0];
                    this.phase = 'tool_rescue';
                    return;
                }
                if ((this.digdown.result.mined ?? 0) > 0) {
                    this.dry = 0;
                    this.digdownDry = 0;
                    this.phase = 'find';
                    return;
                }
                this.digdownDry++;
                ctx.telemetry('acquire_digdown_dry', { digdownDry: this.digdownDry });
                if (this.digdownDry >= 2) {
                    // digdown 连续空手（如沙漠：埋石 + 落沙守卫拒挖）≠ 全图没资源——
                    // 还有换区预算就强制换观测点再来（每轮扣 2 单位，仍有界）；预算尽才真失败
                    if (this.relocateBudget > 2) {
                        this.relocateBudget -= 2;
                        this.digdownDry = 1;
                        this.find.forceExplore();
                        this.phase = 'find';
                        ctx.telemetry('acquire_digdown_explore', { relocateBudget: this.relocateBudget });
                        return;
                    }
                    this._fail(FailReason.NO_RESOURCE_FOUND, {
                        rounds: this.rounds,
                        relocates: 8 - this.relocateBudget,
                        blacklist: ctx.run.blacklist.size,
                    });
                    return;
                }
                this.phase = 'find'; // find 或还有 wander/relocate 预算，换个区域再搜
                return;
            }
            case 'tool_rescue': return this._tickToolRescue(ctx);
            case 'sidequest': return this._tickSideQuest(ctx);
            default:
                this._fail(FailReason.INTERNAL, { error: `unknown phase ${this.phase}` });
        }
    }

    // ---------- sideQuest 清尾（MC-M1-TASK-06b）----------
    // 主资源达标但 flint 仍缺：Find(收紧半径) → FlintCollect（天然沙砾→重埋重挖，铲子先行）。
    // 轮次有界（sideRoundsMax，默认 3）；预算尽仍未够 → SUCCEED 带 sideQuestUnmet（不硬失败：
    // 铁镐/铁锭本身已经到手，缺 flint 的下游合成由 replan 自己再要一次）。
    async _tickSideQuest(ctx) {
        const sq = this.sideQuest;
        if (this.sideMet(ctx)) { this._succeed({ rounds: this.rounds, finalCount: countItems(ctx.bot, this.def.drops) }); return; }
        this._sideRounds++;
        if (this._sideRounds > this.sideRoundsMax) {
            ctx.telemetry('sidequest_unmet', {
                resource: sq.resource, need: sq.count, have: countItems(ctx.bot, this.sideDef.drops),
                rounds: this._sideRounds,
            });
            this._succeed({ rounds: this.rounds, finalCount: countItems(ctx.bot, this.def.drops), sideQuestUnmet: true });
            return;
        }
        // MC-M1-TASK-06b 迭代 2：清尾前先出地表。铁链收尾时人通常还在矿带（y≈40）地下，
        // 沙砾=地表滩涂/河床资源，地下扫描恒空——GoalXZ 只约束水平，pathfinder 会自行
        // 爬出地表；顺路捡到的掉落物在下一行 countMet 兜住。
        const bot = ctx.bot;
        if (bot.entity.position.y < 55 && countItems(bot, ['gravel', 'flint']) < 3) {
            const from = bot.entity.position.floored();
            const ang = Math.random() * Math.PI * 2;
            const tx = Math.round(from.x + Math.cos(ang) * 24);
            const tz = Math.round(from.z + Math.sin(ang) * 24);
            ctx.telemetry('sidequest_surface_exit', { fromY: from.y, tx, tz });
            await navTo(ctx, new pf.goals.GoalXZ(tx, tz), { timeoutMs: 45000, label: 'sidequest_surface' });
            if (this.sideMet(ctx)) {
                ctx.telemetry('sidequest_ok', { have: countItems(ctx.bot, this.sideDef.drops), via: 'surface_exit' });
                this._succeed({ rounds: this.rounds, finalCount: countItems(ctx.bot, this.def.drops) });
                return;
            }
        }
        // 迭代 3：完整能力嵌套采集（同 def.specialFlint 路由到 FlintCollectTask，含铲子
        // 先行 + 重埋循环 + wander/relocate 阶梯）。超时 150s 有界；超时/枯竭即清尾失败，
        // 下一轮再来（总轮次 sideRoundsMax 封顶）。
        // 签名桥：_sideSub 必须指向【工厂里实际创建】的子任务——迭代 3 曾误指已删除的
        // sideAcquire 字段（undefined），父签名在嵌套采集整个 150s 期间冻结，被父级
        // ProgressChecker 75s 硬窗误杀（DEV3 t2/t3 hard_stuck 刷屏实证）。
        const child = await runChild(ctx, `acquire:${sq.resource}`, `Acquire(${sq.resource} +${sq.count - countItems(ctx.bot, this.sideDef.drops)})`,
            () => {
                const t = new AcquireResourceTask({ resource: sq.resource, count: sq.count, timeoutMs: 150000 });
                this._sideSub = t;
                this._activeChild = t;
                return t;
            }, { tickMs: 200 });
        this._sideSub = null;
        this._activeChild = null;
        if (this.sideMet(ctx)) {
            ctx.telemetry('sidequest_ok', { have: countItems(ctx.bot, this.sideDef.drops), childStatus: child.status });
            this._succeed({ rounds: this.rounds, finalCount: countItems(ctx.bot, this.def.drops) });
            return;
        }
        ctx.telemetry('sidequest_round_fail', { round: this._sideRounds, childStatus: child.status, childReason: child.failReason ?? null });
        this.phase = 'sidequest'; // 下一轮（入口按 sideRoundsMax 封顶后 unmet 放行）
    }

    // 前置救援判据：def 需要工具（harvestTools 存在=徒手不行）且包里没有任何合格工具
    // 且 Resolver 能确定性地合成 → 立刻救援。有 kit（TASK-01 协议）时 owned=true 不触发。
    _needsToolRescueUpfront(ctx) {
        if (!this.def.tool) return false;
        try {
            const block = ctx.bot.registry.blocksByName[this.def.blocks[0]];
            if (!block?.harvestTools) return false;
            const owned = ctx.bot.inventory.items().some((it) => block.harvestTools[it.type]);
            if (owned) return false;
            return !!resolveSolvableTool(ctx.bot, this.def.blocks[0]);
        } catch { return false; }
    }

    // ---------- 工具救援（任务书 §5：缺工具从失败原因升级为可递归解决的依赖） ----------
    async _tickToolRescue(ctx) {
        const blockName = this.rescueBlock;
        // 只有能确定性解决的工具才自动补（resolver 会过一遍空库存全链路试解析）
        const tool = resolveSolvableTool(ctx.bot, blockName);
        if (!tool) {
            this._fail(FailReason.TOOL_MISSING, { unresolvable: true, blockName });
            return;
        }
        if (countItems(ctx.bot, [tool]) > 0) {
            // 包里有工具却 equip 失败：不是缺工具，重试采集由 collect/digdown 的正常循环处理；
            // 到这里说明反复失败，如实上报（不靠无脑造第二把）
            this._fail(FailReason.TOOL_MISSING, { toolPresent: true, tool, blockName });
            return;
        }
        ctx.run.counters.toolRescues++;
        ctx.telemetry('tool_rescue_start', { resource: this.resource, blockName, tool });
        const child = await runChild(ctx, `craft:${tool}`, `Craft(${tool} ×1)`,
            () => {
                const t = new CraftingTask({ item: tool, count: 1, timeoutMs: this.toolRescueTimeoutMs });
                this._activeChild = t;
                return t;
            }, { tickMs: 200 });
        this._activeChild = null;
        if (child.status === 'SUCCESS') {
            ctx.run.counters.depResolutions++;
            ctx.telemetry('tool_rescue_ok', { tool, rounds: this.rounds });
            this.collect.target = null;   // 旧目标已无效，重入 Find
            this.digdownDry = 0;
            this.phase = 'find';          // 恢复原 Resource Task（背包里合成的多余材料仍在）
        } else {
            ctx.run.counters.depResolutionFailures++;
            ctx.telemetry('tool_rescue_fail', { tool, childReason: child.failReason });
            this._fail(FailReason.TOOL_MISSING, {
                rescueTool: tool,
                childReason: child.failReason,
                blockName,
            });
        }
    }
}
