// flint_collect_task.js — MC-M1-TASK-06 Task: FlintCollect（燧石采集，沙砾→燧石特化）
//
// 1.16.1 真值：挖沙砾 10% 掉燧石、90% 掉沙砾本体。任务单口径：挖沙砾，没掉燧石就把
// 放下的沙砾重新挖一次，直到拿到燧石。本任务实现这个循环：
//   nav 到 Find 给的沙砾目标 → 挖 5.5 格内天然沙砾 → 有燧石即成功；
//   天然沙砾耗尽 → 把背包里的沙砾放到脚边安全格再挖掉（重埋重挖，期望 ~10 次出燧石）；
//   天然沙砾和背包沙砾都耗尽 → NO_RESOURCE_FOUND（上层重入 Find/换区）。
//
// 对外接口与 CollectResourceTask 一致（result.mined / failReason / target / restart），
// acquire 的 phase 编排零改动。挖掘/验证/拾取复用 collect_resource_task 的 digWithVerify
// 与 pickupDrops（同一验证口径）。

import { ExecTask, FailReason, sleep, countItems, posKey } from './task.js';
import { resourceDef, blockIds } from './resources.js';
import { navTo, stopNav } from './nav.js';
import { placeItem } from './place.js';
import { digWithVerify, pickupDrops } from './collect_resource_task.js';
import { runChild } from './task_stack.js';
import { CraftingTask } from './crafting_task.js';
import pf from 'mineflayer-pathfinder';
import { Vec3 } from 'vec3';

const LIQUIDS = new Set(['lava', 'water']);
const REPLACEABLE = new Set(['air', 'cave_air', 'void_air', 'water', 'grass', 'tall_grass', 'fern', 'snow', 'dead_bush']);
const SHOVELS = ['wooden_shovel', 'stone_shovel', 'iron_shovel'];

const MAX_TOTAL_DIGS = 80;   // 总挖掘上限（0.9^80 ≈ 0.02%，纯保险，正常靠超时/无料退出）
const NAV_BLACKLIST_RADIUS = 4;  // 同 collect_resource_task.js:31：导航失败候选的拉黑扩围半径

export class FlintCollectTask extends ExecTask {
    constructor(opts = {}) {
        super('FlintCollectTask', { timeoutMs: opts.timeoutMs ?? 240000 });
        this.resource = opts.resource ?? 'flint';
        this.target = opts.target ?? null;
        this.count = opts.count ?? 1;
        this.navTimeoutMs = opts.navTimeoutMs ?? 25000;
        // MC-M1-TASK-06b：重埋循环上限参数化。10% 掉率下 40 轮全空手的概率 = 0.9^40 ≈ 1.5%
        //（任务单 §1-4 要求的推导口径）；40 轮 × 快循环 ~2.5s ≈ 100s，在 flint 链预算内。
        this.maxRedigs = opts.maxRedigs ?? 40;
        this.shovelFirst = opts.shovelFirst ?? true; // 进重埋循环前先补一把铲子（任务单 §1-3）
        this.phase = 'idle';
        this.mined = 0;
        this.redigs = 0;
        this.verifyFails = 0;
        this.redigMsTotal = 0;
    }

    onRestart() {
        this.phase = 'idle';
        this.mined = 0;
        this.redigs = 0;
        this.verifyFails = 0;
        // redigMsTotal 保留累计（供 result 汇报每轮中位）
    }

    canStart(ctx) { return !!this.target && !!ctx.bot?.entity?.position; }

    countMet(ctx) { return countItems(ctx.bot, resourceDef(this.resource).drops) >= this.count; }

    progressSignature(ctx) {
        const dist = this.target && ctx.bot?.entity?.position ? Math.round(ctx.bot.entity.position.distanceTo(this.target)) : 0;
        return `fl|${this.phase}|${this.mined}|r${this.redigs}|i${countItems(ctx.bot, ['flint'])}|d${dist}`;
    }

    getProgress(ctx) {
        return { phase: this.phase, mined: this.mined, redigs: this.redigs, flint: countItems(ctx.bot, ['flint']) };
    }

    async onStuck(kind, ctx) {
        if (kind !== 'soft') return;
        stopNav(ctx.bot);
        try { ctx.bot.stopDigging(); } catch {}
        if (this.phase === 'nav') {
            this._fail(FailReason.NAVIGATION_FAILED, { mined: this.mined, stuck: 'nav' });
        } else {
            this._skipAction = true; // 挖掘/放置中卡住：放弃本拍动作，下拍换候选
        }
    }

    async tick(ctx) {
        const bot = ctx.bot;
        const def = resourceDef(this.resource);
        if (this.countMet(ctx)) { this._succeed(this._result(ctx)); return; }
        if (this.mined + this.redigs >= MAX_TOTAL_DIGS) {
            this._fail(FailReason.NO_PROGRESS, { mined: this.mined, redigs: this.redigs, digsCap: MAX_TOTAL_DIGS });
            return;
        }
        if (this.redigs >= this.maxRedigs) {
            // MC-M1-TASK-06b：重埋循环预算独立于总挖掘数（天然沙砾挖掘不占预算——
            // 原 redigs 计数把天然挖掘也算进去，成片沙砾多时白吃预算）
            this._fail(FailReason.NO_PROGRESS, { mined: this.mined, redigs: this.redigs, redigsCap: this.maxRedigs });
            return;
        }
        if (this._skipAction) { this._skipAction = false; return; }

        switch (this.phase) {
            case 'idle': this.phase = 'nav'; return;
            case 'nav': {
                const ok = await navTo(ctx, new pf.goals.GoalNear(this.target.x, this.target.y, this.target.z, 3),
                    { timeoutMs: this.navTimeoutMs, label: 'flint_nav' });
                if (!ok) {
                    // MC-M1-TASK-06c（P2a 实证）：走到不着的沙砾目标 = 白等 25s，而**原口径不把
                    // 目标拉黑**——上层 Acquire 收到 NAVIGATION_FAILED 会退回 find（acquire_resource_task.js:210），
                    // 但 find 又挑中同一块 → 连续 8 次 flint_nav 超时（200s）把整局烧成 TIMEOUT。
                    // 证据：P2A_KIT trial_03 / trial_12 两次失败都是这条链（place 侧全绿：place_fail=0）。
                    // 修法与 CollectResourceTask 的 TASK-04 修复③ 同一套语义（该处本来就拉黑，
                    // FlintCollect 当初漏抄了）：拉黑目标本体 + 半径 4 格同类，逼上层换目标。
                    this._blacklistCandidate(ctx, this.target, 'flint_nav_fail');
                    this._fail(FailReason.NAVIGATION_FAILED, { target: [this.target.x, this.target.y, this.target.z], mined: this.mined });
                    return;
                }
                this.phase = 'mine';
                return;
            }
            case 'mine': {
                // 1) 5.5 格内天然沙砾（先挖光身边成片的，再重埋——任务单 §1-2）
                const gravelId = bot.registry.blocksByName['gravel']?.id;
                const near = gravelId != null
                    ? bot.findBlocks({ matching: [gravelId], maxDistance: 5.5, count: 24 })
                        .filter((p) => !ctx.run.blacklist.has(posKey(p)))
                        .sort((a, b) => bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b))
                    : [];
                if (near.length) {
                    const pos = near[0];
                    const block = bot.blockAt(pos);
                    if (!block || block.name !== 'gravel') { ctx.run.blacklist.add(posKey(pos)); return; }
                    if (!this._safeToDig(ctx, block)) { ctx.run.blacklist.add(posKey(pos)); return; }
                    await this._digNatural(ctx, block, def);
                    return;
                }
                // 2) 天然沙砾没了 → 重埋重挖（任务单口径）。没沙砾可埋 → 失败交上层重新找
                if (countItems(bot, ['gravel']) < 1) {
                    this._fail(FailReason.NO_RESOURCE_FOUND, { mined: this.mined, redigs: this.redigs });
                    return;
                }
                // 首次进重埋循环前补铲子（有材料就合，失败退化徒手继续——不因铲子死整链）
                if (this.shovelFirst && !this._shovelSettled) {
                    this._shovelSettled = true;
                    await this._ensureShovel(ctx);
                    if (this.countMet(ctx)) { this._succeed(this._result(ctx)); return; }
                }
                const tRound = Date.now();
                const placed = await this._placeGravelNearby(ctx);
                if (!placed) {
                    // 放不下去（四周全堵）：挪 2-4 格再试一轮（有界），还不行交上层
                    this._placeRetries = (this._placeRetries ?? 0) + 1;
                    if (this._placeRetries > 3) {
                        this._fail(FailReason.NO_PROGRESS, { mined: this.mined, redigs: this.redigs, why: 'no_place_spot' });
                        return;
                    }
                    const ang = Math.random() * Math.PI * 2;
                    const from = bot.entity.position.floored();
                    const to = new Vec3(Math.round(from.x + Math.cos(ang) * 3), from.y, Math.round(from.z + Math.sin(ang) * 3));
                    await navTo(ctx, new pf.goals.GoalNear(to.x, to.y, to.z, 1), { timeoutMs: 8000, label: 'flint_move' });
                    return;
                }
                this._placeRetries = 0;
                await this._digPlaced(ctx, placed, def);
                ctx.run.counters.flintPlaceRedigs++;
                // 每轮耗时遥测（BENCH-v2/TASK-06b 验收口径：重埋循环每轮中位 ≤2.5s）
                const ms = Date.now() - tRound;
                this.redigMsTotal += ms;
                ctx.telemetry('flint_redig_round', { ms, n: this.redigs, shovel: this._hasShovel(ctx) });
                return;
            }
            default:
                this._fail(FailReason.INTERNAL, { error: `unknown phase ${this.phase}` });
        }
    }

    _result(ctx) {
        return {
            mined: this.mined, redigs: this.redigs,
            redigMedianMs: this.redigs ? Math.round(this.redigMsTotal / this.redigs) : null,
        };
    }

    // 导航失败候选拉黑（与 CollectResourceTask._blacklistCandidate 同语义，radius=4 扩围）。
    // 见 tick() 的 'nav' 分支注释：没有它，上层 find 会无限重挑同一块走不到的沙砾。
    _blacklistCandidate(ctx, center, why) {
        if (!center) return 0;
        const bot = ctx.bot;
        let expanded = 0;
        try {
            const ids = blockIds(bot, resourceDef(this.resource));
            const around = bot.findBlocks({ matching: ids, maxDistance: NAV_BLACKLIST_RADIUS, count: 64, point: center });
            for (const p of around) {
                if (!ctx.run.blacklist.has(posKey(p))) { ctx.run.blacklist.add(posKey(p)); expanded++; }
            }
        } catch { /* 周边区块未加载时只拉黑候选本体 */ }
        ctx.run.blacklist.add(posKey(center));
        ctx.telemetry('nav_blacklist_expand', {
            why, task: 'FlintCollect', target: [center.x, center.y, center.z], radius: NAV_BLACKLIST_RADIUS, expanded,
        });
        return expanded;
    }

    _hasShovel(ctx) {
        return ctx.bot.inventory.items().some((i) => SHOVELS.includes(i.name));
    }

    // 有材料就合一把木铲（木镐链的木板/木棍此时一般都在包里）；失败不致命，退化徒手
    async _ensureShovel(ctx) {
        const bot = ctx.bot;
        if (this._hasShovel(ctx)) return true;
        ctx.telemetry('flint_shovel_craft_start', {});
        try {
            const child = await runChild(ctx, 'craft:wooden_shovel', 'Craft(wooden_shovel ×1)',
                () => new CraftingTask({ item: 'wooden_shovel', count: 1, timeoutMs: 90000, gatherTimeoutMs: 60000 }),
                { tickMs: 200 });
            const ok = child.status === 'SUCCESS';
            ctx.telemetry(ok ? 'flint_shovel_ok' : 'flint_shovel_skip', { reason: child.failReason ?? null });
            return ok;
        } catch (e) {
            ctx.telemetry('flint_shovel_skip', { error: String(e).slice(0, 100) });
            return false;
        }
    }

    // 重埋后的快速拾取：掉落物就在脚边，轮询背包增量（≤1.2s）——旧 pickupDrops 对每个
    // 掉落物 GoalFollow 最多 4s，是 9.5s/轮的主要构造成本
    async _fastPickup(ctx) {
        const names = ['flint', 'gravel'];
        const before = countItems(ctx.bot, names);
        const dl = Date.now() + 1200;
        while (Date.now() < dl) {
            if (countItems(ctx.bot, names) > before) return;
            await sleep(120);
        }
        // 兜底：还在地上就定向抓一次（有界 2.5s）
        await pickupDrops(ctx);
    }

    async _digNatural(ctx, block, def) {
        const res = await digWithVerify(ctx, block, def);
        if (res.ok) {
            this.mined++;
            this.verifyFails = 0;
            await sleep(250);
            await pickupDrops(ctx);
        } else if (res.reason === FailReason.TOOL_MISSING) {
            this._fail(FailReason.TOOL_MISSING, { mined: this.mined, blockName: block.name });
        } else {
            ctx.run.blacklist.add(posKey(block.position));
            this.verifyFails++;
            if (this.verifyFails >= 4) this._fail(FailReason.DIG_FAILED, { mined: this.mined, verifyFails: this.verifyFails });
        }
    }

    // 重埋重挖专用：挖掘 + 快拾取（不 GoalFollow），计时归 flint_redig_round 遥测
    async _digPlaced(ctx, block, def) {
        const res = await digWithVerify(ctx, block, def);
        if (res.ok) {
            this.mined++;
            this.redigs++;
            this.verifyFails = 0;
            await this._fastPickup(ctx);
        } else if (res.reason === FailReason.TOOL_MISSING) {
            this._fail(FailReason.TOOL_MISSING, { mined: this.mined, blockName: block.name });
        } else {
            ctx.run.blacklist.add(posKey(block.position));
            this.verifyFails++;
            if (this.verifyFails >= 4) this._fail(FailReason.DIG_FAILED, { mined: this.mined, verifyFails: this.verifyFails });
        }
    }

    _safeToDig(ctx, block) {
        const bot = ctx.bot;
        const p = block.position;
        // MC-M1-TASK-06b 补底面（同 TASK-06 smoke6 的 _safeToDig 家族修复）：沙砾脚下
        // 是岩浆/悬空深腔时挖穿坠落的场面对重埋循环同样成立
        for (const c of [p.offset(1, 0, 0), p.offset(-1, 0, 0), p.offset(0, 0, 1), p.offset(0, 0, -1), p.offset(0, 1, 0), p.offset(0, -1, 0)]) {
            const b = bot.blockAt(c);
            if (b && LIQUIDS.has(b.name)) return false;
        }
        return true;
    }

    // 在脚边找安全格放一块背包里的沙砾（MC-M1-TASK-06c：改用共享放置原语 place.js）
    async _placeGravelNearby(ctx) {
        const bot = ctx.bot;
        const gravelItem = bot.inventory.items().find((i) => i.name === 'gravel');
        if (!gravelItem) return null;
        // 重埋循环是延迟敏感的：maxTries=2、confirmMs=600、放不下就快速失败返回 null（外层会换策略）。
        // 旧口径在这里是 Promise.race(placeBlock, 5s)——放不成功就白等 5s，06b 的「每轮 ≤2.5s」线就是这么破的。
        const r = await placeItem(bot, 'gravel', {
            telemetry: ctx.telemetry, ctx, GoalNear: pf.goals.GoalNear, label: 'flint_rebury',
            maxTries: 2, rounds: 1, confirmMs: 600, allowNiche: false, moveIfStuck: false,
        });
        if (r.ok) {
            ctx.run.counters.flintPlaceRedigs++;
            ctx.telemetry('flint_place_redig', { pos: [r.dest.x, r.dest.y, r.dest.z], n: this.redigs });
            return r.block;
        }
        if (r.reason === 'hold_fail') { ctx.telemetry('flint_hold_fail', {}); return null; }
        return null;
    }
}
