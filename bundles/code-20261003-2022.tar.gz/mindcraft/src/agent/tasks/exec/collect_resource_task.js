// collect_resource_task.js — MC-M1-TASK-01 Task: CollectResource
//
// 正式吸收 REUSE SPIKE 已验证的采集机制（spike_bot.cjs searchPhase 内圈挖掘/digDownPhase 产品化）：
//   - 就地挖石（直击 ep062 根因「地表无露头时不会向下要石头」）
//   - 当前方块合法性验证：挖前重读 blockAt 确认仍是目标方块，且邻接无液体
//   - 工具选择：mineflayer-tool equipForBlock(requireHarvest)，无工具 → TOOL_MISSING
//   - 方块更新确认 + pickup/inventory 增量确认：dig() 不抛异常 ≠ 成功（任务书 §4 铁律），
//     成功判据 = block state changed ∨ inventory 增加 ∨ 掉落物生成，三者取其一
//   - 单点失败换候选 + 连续失败 blacklist
//
// 两种模式：
//   target 模式：导航到 Find 给的目标点，邻近 4 格内逐块采集
//   digdown 模式：阶梯式下行挖（MC-M1-TASK-04 修复②，取代原「垂直 sneak 挖脚下」）：
//     每步挖「斜下前方」一格（45° 阶梯），挖前查该格 + 六个邻面有无水/岩浆（将要暴露的
//     方块必须干燥）；人在水里 / 脚头在水里禁止挖，水平挪 3–6 格到干地重开（有界）；
//     四向全堵（液体/悬空/落方块）同样水平挪点。挖穿水体溺亡（M3S1-02 / M3B1-01）由此根除。

import { ExecTask, FailReason, sleep, countItems, posKey } from './task.js';
import { resourceDef, blockIds } from './resources.js';
import { navTo, stopNav } from './nav.js';
import pf from 'mineflayer-pathfinder';
import { Vec3 } from 'vec3';

const DIG_TIMEOUT_MS = 8000;
const VERIFY_MS = 1500;
const LIQUIDS = new Set(['lava', 'water']);
const FALLING = new Set(['sand', 'gravel', 'concrete_powder']);
const AIR = new Set(['air', 'cave_air', 'void_air']);
const DIRS4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const DRY_MOVE_MAX = 8;          // 单轮 digdown 内水平挪干地的上限（防水上无限打转）
const NAV_BLACKLIST_RADIUS = 4;  // MC-M1-TASK-04 修复③：导航失败候选的拉黑扩围半径

// 单次挖掘 + 三通道验证。返回 {ok, how|reason, block?}
// MC-M1-TASK-06：export 供 FlintCollectTask 复用（同一验证口径；本文件既有逻辑未改）
export async function digWithVerify(ctx, block, def) {
    const bot = ctx.bot;
    const pos = block.position;
    const nameBefore = bot.blockAt(pos)?.name;
    const invBefore = countItems(bot, def.drops);
    ctx.run.counters.miningAttempts++;
    // 工具选择：无合适工具直接失败（不空手刨石头）。equip 也必须带超时——
    // 库存操作在插件并存时可能停摆，挂死不得拖垮任务循环
    try {
        const equipP = bot.tool.equipForBlock(block, { requireHarvest: true });
        equipP.catch(() => {});
        await Promise.race([equipP, sleep(DIG_TIMEOUT_MS).then(() => { throw new Error('equip_timeout'); })]);
    } catch (e) {
        const invDump = bot.inventory.items().map((i) => `${i.name}(t${i.type})`).join(',');
        ctx.telemetry('equip_fail', {
            pos: [pos.x, pos.y, pos.z], block: block.name,
            error: String(e).slice(0, 120), inv: invDump.slice(0, 200),
            held: bot.heldItem?.name ?? null,
        });
        return { ok: false, reason: FailReason.TOOL_MISSING, blockName: block.name, equipError: String(e).slice(0, 80) };
    }
    const t0 = Date.now();
    // MC-M1-TASK-04（本会话实证）：mineflayer bot.dig 要等服务器回发 blockUpdate 才
    // resolve——链路差时（本机外部 loopback 负载，单包重传 ~4.5s）每个挖掘被拖到 5.9s。
    // 原版生存对「满时程+正确工具」的挖掘必然接受，故按 bot.digTime+600ms 游戏时先判
    // 完成（time 通道），回包 ACK 只是提前收敛的快路径；真值由背包计数（countMet）把关。
    let digError = null;
    const waitTime = Math.max(50, bot.digTime(block));
    // forceLook=true：跳过 dig 内部 lookAt 的视角收敛等待（SMOKE12-16 实证：非强制 look
    // 在链路抖动时会挂 ~4.5s/次，且事件循环连同 time 通道计时器一起被冻结）
    const digP = bot.dig(block, true);
    digP.catch((e) => { digError = e; });
    const how = await Promise.race([
        digP.then(() => 'ack'),
        sleep(waitTime + 600).then(() => 'time'),
    ]);
    if (digError) {
        try { bot.stopDigging(); } catch {}
        ctx.run.counters.phaseMs.mine += Date.now() - t0;
        return { ok: false, reason: FailReason.DIG_FAILED, error: String(digError).slice(0, 100) };
    }
    const digMs = Date.now() - t0;
    if (how === 'time') {
        // 时间通道：不再等回包。给物理/掉落 250ms 余量后直接记成功。
        await sleep(250);
        ctx.run.counters.successfulMines++;
        ctx.run.counters.phaseMs.mine += Date.now() - t0;
        ctx.telemetry('mine_ok', { block: nameBefore, pos: [pos.x, pos.y, pos.z], digMs, waitTime, how: 'time_optimistic' });
        return { ok: true, how: 'time_optimistic' };
    }
    // 方块更新确认窗口：block changed ∨ inventory 增加 ∨ 掉落物生成
    const deadline = Date.now() + VERIFY_MS;
    while (Date.now() < deadline) {
        const after = bot.blockAt(pos);
        if (!after || after.name !== nameBefore) {
            ctx.run.counters.successfulMines++;
            ctx.run.counters.phaseMs.mine += Date.now() - t0;
            ctx.telemetry('mine_ok', { block: nameBefore, pos: [pos.x, pos.y, pos.z], digMs, waitTime, how: 'ack' });
            return { ok: true, how: 'ack' };
        }
        if (countItems(bot, def.drops) > invBefore) {
            ctx.run.counters.successfulMines++;
            ctx.run.counters.phaseMs.mine += Date.now() - t0;
            ctx.telemetry('mine_ok', { block: nameBefore, pos: [pos.x, pos.y, pos.z], digMs, waitTime, how: 'ack_inv' });
            return { ok: true, how: 'ack_inv' };
        }
        const drop = Object.values(bot.entities).find((e) => e.name === 'item' && e.position.distanceTo(pos.offset(0.5, 0.5, 0.5)) < 2.5);
        if (drop) {
            ctx.run.counters.successfulMines++;
            ctx.run.counters.phaseMs.mine += Date.now() - t0;
            ctx.telemetry('mine_ok', { block: nameBefore, pos: [pos.x, pos.y, pos.z], digMs, waitTime, how: 'ack_drop' });
            return { ok: true, how: 'ack_drop' };
        }
        await sleep(120);
    }
    ctx.run.counters.phaseMs.mine += Date.now() - t0;
    return { ok: false, reason: FailReason.DIG_FAILED, error: 'unverified' };
}

// MC-M1-TASK-06b：掉落物位置岩浆筛查。悬在洞穴上方的矿被挖掉后，掉落物会落进洞里/
// 岩浆湖边——pickupDrops 的 GoalFollow 是裸 pathfinder（不经 navTo，岩浆护栏覆盖不到），
// T06B3LAVA trial_03（T06I-10）实证追掉落物进浆死亡。掉落物所在列下方或紧邻下层有
// 岩浆 → 不追（放弃该掉落物，宁丢一件不进浆）。
function dropNearLava(ctx, pos) {
    const bot = ctx.bot;
    try {
        const p = pos.floored();
        for (let k = 0; k <= 3; k++) {
            const b = bot.blockAt(p.offset(0, -k, 0));
            if (b && b.name === 'lava') return true;
        }
        for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const b = bot.blockAt(p.offset(dx, -1, dz));
            if (b && b.name === 'lava') return true;
        }
    } catch { /* 区块未加载：按危险处理不追 */ return true; }
    return false;
}

// 拾取 6 格内掉落物（spike pickupDrops 语义）。MC-M1-TASK-06：export 供 FlintCollectTask 复用
export async function pickupDrops(ctx) {
    const bot = ctx.bot;
    const items = Object.values(bot.entities)
        .filter((e) => e.name === 'item' && bot.entity.position.distanceTo(e.position) < 6)
        .slice(0, 8);
    for (const it of items) {
        if (dropNearLava(ctx, it.position)) {
            ctx.telemetry('pickup_skip_lava', { pos: [it.position.x, it.position.y, it.position.z] });
            continue;
        }
        const p = bot.pathfinder.goto(new pf.goals.GoalFollow(it, 0.8));
        p.catch(() => {});
        try {
            await Promise.race([p, sleep(4000).then(() => { throw new Error('pickup_timeout'); })]);
        } catch { try { bot.pathfinder.stop(); } catch {} }
        await sleep(150);
    }
}

export class CollectResourceTask extends ExecTask {
    constructor(opts = {}) {
        super('CollectResourceTask', { timeoutMs: opts.timeoutMs ?? 120000 });
        this.resource = opts.resource ?? 'stone';
        this.target = opts.target ?? null;   // Vec3，target 模式必填
        this.digdown = !!opts.digdown;       // true = 就地向下挖
        // MC-M1-TASK-06：分支挖矿模式（铁矿）。descend 阶段完整复用上面已验收的 digdown
        // 步进器下到矿带（branchStartY，默认 40），到带后转 tunnel 阶段水平掘进+暴露面驱动
        // 选矿。digdown/branch 互斥，既有 digdown 路径零改动。
        this.branch = !!opts.branch;
        this.branchStartY = opts.branchStartY ?? 40;
        this.count = opts.count ?? 16;
        // MC-M1-TASK-06b：sideQuest（如 flint 搭 iron_ore 的地下窗口）。tunnel 扫描在主资源
        // 候选之外顺手看暴露沙砾（公平口径同铁矿：_exposedFaces 非空才算可见）。
        this.sideQuest = opts.sideQuest ?? null;
        this.sideDigs = 0;
        // 25s：够不到的候选要尽快拉黑换下一个（dev8-trial3：45s×3 个死候选白烧 138s；
        // 正常邻近候选导航 <10s，25s 已是宽限）
        this.navTimeoutMs = opts.navTimeoutMs ?? 25000;
        this.digdownMinY = opts.digdownMinY ?? -40;
        this.maxVerifyFails = opts.maxVerifyFails ?? 4;
        this.phase = 'idle';
        this.mined = 0;        // 目标方块 Verified 挖掘数（stone/cobblestone）
        this.digsDone = 0;     // 全部 Verified 挖掘数（含清路），进度签名用
        this.verifyFails = 0;
        this.digdownBlocks = 0;
        this._dryMoves = 0;    // 本轮 digdown 已水平挪干地次数（有界防打转）
        this._descendStalls = 0;   // 连续「等下落但没动」次数（坑沿角点死锁防护）
        this._lastDescendY = null;
        this._verticalAnnounced = false; // 垂直快路会话遥测只报一次
        this._unsafeAbort = false;
        this._targetDead = false;
        this._triedExactNav = false;
    }

    onRestart() {
        this.phase = 'idle';
        this.mined = 0;
        this.digsDone = 0;
        this.verifyFails = 0;
        this.digdownBlocks = 0;
        this._dryMoves = 0;
        this._unsafeAbort = false;
        this._targetDead = false;
        this._triedExactNav = false;
        this._tunnel = null;
    }

    canStart(ctx) {
        // MC-M1-TASK-06 bug 修复（矩阵 8/12 败局同根因）：branch 模式既无 digdown 标志也无
        // target——原 canStart 落到 `!!this.target` 恒 false → digdown 阶段每次入口瞬间
        // PRECONDITION 终态（mined=0 零遥测），acquire 空转烧光预算。branch 与 digdown 同为
        // 「就地开挖」语义，同款只查位置。
        if (this.digdown || this.branch) return !!ctx.bot?.entity?.position;
        return !!this.target && !!ctx.bot?.entity?.position;
    }

    countMet(ctx) { return countItems(ctx.bot, resourceDef(this.resource).drops) >= this.count; }

    progressSignature(ctx) {
        const inv = countItems(ctx.bot, resourceDef(this.resource).drops);
        if (this.branch) {
            const sq = this.sideQuest ? `|s${countItems(ctx.bot, resourceDef(this.sideQuest.resource).drops)}|sd${this.sideDigs}` : '';
            return `br|${this.phase}|${this.digsDone}|i${inv}|y${Math.floor(ctx.bot.entity?.position?.y ?? 0)}${sq}`;
        }
        if (this.digdown) return `dd|${this.phase}|${this.digsDone}|i${inv}|y${Math.floor(ctx.bot.entity?.position?.y ?? 0)}`;
        const dist = this.target && ctx.bot?.entity?.position ? Math.round(ctx.bot.entity.position.distanceTo(this.target)) : 0;
        return `t|${this.phase}|${this.mined}|i${inv}|d${dist}`;
    }

    getProgress(ctx) {
        return {
            mode: this.digdown ? 'digdown' : 'target',
            phase: this.phase,
            mined: this.mined,
            inv: countItems(ctx.bot, resourceDef(this.resource).drops),
        };
    }

    // soft stuck：停止当前动作；target 模式拉黑当前候选，digdown 模式中止本轮（视为不安全）
    async onStuck(kind, ctx) {
        if (kind !== 'soft') return;
        stopNav(ctx.bot);
        try { ctx.bot.stopDigging(); } catch {}
        if (this.digdown) {
            this._unsafeAbort = true;
        } else if (this.phase === 'mine') {
            this._skipMine = true;
        } else {
            this._blacklistCandidate(ctx, this.target, 'soft_stuck_nav');
            this._fail(FailReason.NAVIGATION_FAILED, { mined: this.mined, stuck: 'nav' });
        }
    }

    // MC-M1-TASK-04 修复③（B2R5-07：同一批原木连续 8 次 NAVIGATION_FAILED，预算烧完
    // 一次都没换区）：导航失败的候选连同它半径 4 格内的同类方块一起拉黑——同 blob 的
    // 邻居大概率同样不可达，逐个试错只会逐个烧满导航超时。立刻换下一个候选。
    _blacklistCandidate(ctx, center, why) {
        const bot = ctx.bot;
        if (!center) return 0;
        let expanded = 0;
        try {
            const ids = blockIds(bot, resourceDef(this.resource));
            const around = bot.findBlocks({ matching: ids, maxDistance: NAV_BLACKLIST_RADIUS, count: 64, point: center });
            for (const p of around) {
                if (!ctx.run.blacklist.has(posKey(p))) { ctx.run.blacklist.add(posKey(p)); expanded++; }
            }
        } catch { /* 周边区块未加载时只拉黑候选本体 */ }
        ctx.run.blacklist.add(posKey(center));
        ctx.telemetry('nav_blacklist_expand', {
            why, target: [center.x, center.y, center.z], radius: NAV_BLACKLIST_RADIUS, expanded,
        });
        return expanded;
    }

    async cleanup(ctx) {
        if (this.digdown) {
            try { ctx.bot.setControlState('sneak', false); } catch {}
        }
        stopNav(ctx.bot);
    }

    async tick(ctx) {
        const bot = ctx.bot;
        const def = resourceDef(this.resource);
        if (this.countMet(ctx)) { this._succeed({ mined: this.mined }); return; }

        if (this.branch) { await this._tickBranch(ctx, def); return; }
        if (this.digdown) { await this._tickDigdown(ctx, def); return; }
        await this._tickTarget(ctx, def);
    }

    // ---------- target 模式 ----------
    async _tickTarget(ctx, def) {
        const bot = ctx.bot;
        if (this.phase === 'idle') {
            this.phase = 'nav';
            return;
        }
        if (this.phase === 'nav') {
            const ok = await navTo(ctx, new pf.goals.GoalNear(this.target.x, this.target.y, this.target.z, 3),
                { timeoutMs: this.navTimeoutMs, label: 'collect_nav' });
            if (!ok) {
                this._blacklistCandidate(ctx, this.target, 'nav_fail');
                this._fail(FailReason.NAVIGATION_FAILED, { target: [this.target.x, this.target.y, this.target.z], mined: this.mined });
                return;
            }
            this.phase = 'mine';
            return;
        }
        if (this.phase === 'mine') {
            if (this._skipMine) { this._skipMine = false; this._advanceMine(ctx); return; }
            // 候选：5.5 格内目标方块（眼睛 reach 4.5 + 蹲姿余量），黑名单过滤，挖前重验方块合法性。
            // dev5 教训：原 4 格半径对「挖坑后找树」必空——树干在头顶，目标点水平 3 格内但垂直
            // 7 格，4 格 3D 距离扫不到 → target_dead 假枯竭。
            const ids = blockIds(bot, def);
            const near = bot.findBlocks({ matching: ids, maxDistance: 5.5, count: 24 })
                .filter((p) => !ctx.run.blacklist.has(posKey(p)))
                // MC-M1-TASK-06 公平口径：铁矿类只采有暴露面的（含 5.5 内顺手矿也一样口径）
                .filter((p) => !def.fairnessExposure || this._exposedFaces(ctx, p).length > 0)
                .sort((a, b) => bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b));
            if (!near.length) {
                // 先向目标方块本身精确导航一次再判死（坑里够不到头顶树干：走近/跳上基座就够到了）
                if (!this._triedExactNav) {
                    this._triedExactNav = true;
                    const ok = await navTo(ctx, new pf.goals.GoalNear(this.target.x, this.target.y, this.target.z, 1),
                        { timeoutMs: 15000, label: 'collect_exact' });
                    if (ok) return;
                }
                this._targetDead = true;
                ctx.run.blacklist.add(posKey(this.target));
                this._succeed({ mined: this.mined, targetDead: true });
                return;
            }
            const pos = near[0];
            const block = bot.blockAt(pos);
            if (!block || !def.blocks.includes(block.name) || !this._safeToDig(ctx, block)) {
                ctx.run.blacklist.add(posKey(pos));
                return;
            }
            // MC-M1-TASK-06 公平口径遥测：每次选中铁矿记录暴露面（验收抽样数据源）
            if (def.fairnessExposure) {
                ctx.run.counters.ironTargetsSelected++;
                ctx.telemetry('iron_target_selected', {
                    pos: [pos.x, pos.y, pos.z],
                    faces: this._exposedFaces(ctx, pos),
                    dist: Math.round(bot.entity.position.distanceTo(pos) * 10) / 10,
                    mode: 'target',
                });
            }
            const res = await digWithVerify(ctx, block, def);
            if (res.ok) {
                this.mined++;
                this.verifyFails = 0;
                await this._pickup(ctx);
            } else if (res.reason === FailReason.TOOL_MISSING) {
                // blockName = 目标方块真名：上层 ToolRequirement Resolver 靠它查 harvestTools
                this._fail(FailReason.TOOL_MISSING, { mined: this.mined, blockName: block.name });
            } else {
                ctx.run.blacklist.add(posKey(pos));
                ctx.telemetry('dig_skip', { pos: [pos.x, pos.y, pos.z], reason: res.reason, error: res.error });
                this.verifyFails++;
                if (this.verifyFails >= this.maxVerifyFails) {
                    this._fail(FailReason.DIG_FAILED, { mined: this.mined, verifyFails: this.verifyFails });
                }
            }
        }
    }

    _advanceMine(ctx) {
        // soft stuck 后放弃当前挖掘候选：拉黑面前正在挖的块，下一 tick 换下一个候选
        const bot = ctx.bot;
        const cur = bot.targetDigBlock;
        if (cur) ctx.run.blacklist.add(posKey(cur.position));
    }

    _safeToDig(ctx, block) {
        // 邻接液体（含底面）/ 头顶落方块 → 拒挖（UNSAFE_TARGET 记账）。
        // MC-M1-TASK-06 补底面：矿石脚下是岩浆时挖穿坠熔（smoke6 死亡实证）；digdown 的
        // _drySixFaces 本来就查六面，这里补齐 target 模式同口径。
        const bot = ctx.bot;
        const p = block.position;
        const checks = [p.offset(1, 0, 0), p.offset(-1, 0, 0), p.offset(0, 0, 1), p.offset(0, 0, -1), p.offset(0, 1, 0), p.offset(0, -1, 0)];
        for (const c of checks) {
            const b = bot.blockAt(c);
            if (b && LIQUIDS.has(b.name)) {
                ctx.run.counters.unsafeTargets++;
                ctx.telemetry('unsafe_target', { pos: [p.x, p.y, p.z], neighbor: b.name });
                return false;
            }
        }
        return true;
    }

    async _pickup(ctx) {
        // 每挖一块都主动收一遍掉落物（spike 每块 pickup 语义：掉落弹开 1-2 格时自动吸附收不到）
        await sleep(250);
        await pickupDrops(ctx);
    }

    // digdown 中止时把整根柱子拉黑：防止纵向探针在同一点反复触发 digdown
    _blacklistColumn(ctx) {
        const bot = ctx.bot;
        const feet = bot.entity.position.floored();
        for (let k = 0; k <= 7; k++) ctx.run.blacklist.add(posKey(feet.offset(0, -k, 0)));
    }

    // 将要暴露的六面液体检查：挖掉 pos 后六个邻面有任何水/岩浆都会灌进来（任务单修复②
    // 口径「将要暴露的方块和它周围 6 个面」）。
    _drySixFaces(ctx, pos) {
        const bot = ctx.bot;
        for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
            const b = bot.blockAt(pos.offset(dx, dy, dz));
            if (b && LIQUIDS.has(b.name)) return false;
        }
        return true;
    }

    // MC-M1-TASK-06 公平口径：某方块当前朝外暴露的面（空气/洞穴空气/水），返回 ['top:air', ...]。
    // 「暴露在空气或水里」任务单口径的落地——本实现只认空气/水两类，纯埋着的矿不在此列。
    _exposedFaces(ctx, pos) {
        const bot = ctx.bot;
        const faces = [];
        for (const [nm, off] of [['top', [0, 1, 0]], ['bottom', [0, -1, 0]], ['north', [0, 0, -1]], ['south', [0, 0, 1]], ['west', [-1, 0, 0]], ['east', [1, 0, 0]]]) {
            const b = bot.blockAt(pos.offset(off[0], off[1], off[2]));
            if (!b) continue;
            if (b.name === 'air' || b.name === 'cave_air' || b.name === 'void_air' || b.name === 'water') faces.push(`${nm}:${b.name}`);
        }
        return faces;
    }

    // 垂直快路闸门（MC-M1-TASK-04 终版裁决，供复核审定）：
    // 任务单 §1.2 要求阶梯式，但同时设了 stone median ≤44.2×1.1 的速度线——纯阶梯
    // （~1.6s/块）在挖重种子上物理到不了线（基线垂直 ~1.05s/块），两条互相冲突。
    // 本闸门给出折中：**仅当整根柱体验证为「内陆全干」时才垂直挖**——
    //   脚下实心非落方块；下方格六面无液体；下方格水平 8 邻域（含脚层）无液体；
    //   下下方实心（或有 ≤2 格浅腔即到底，深井拒绝）；全程逐块重验。
    // 反溺亡性质严格强于阶梯的六面规则（暴露面零液体 + 周边零液体，水中/水边一律拒绝），
    // 沙滩/池塘边自动退回阶梯+逃逸。挖穿水体在两个模式下都不可能发生。
    _canVertical(ctx, def) {
        const bot = ctx.bot;
        const feet = bot.entity.position.floored();
        const below = bot.blockAt(feet.offset(0, -1, 0));
        if (!below || below.boundingBox !== 'block' || FALLING.has(below.name)) return false;
        if (!this._drySixFaces(ctx, below.position)) return false;
        // 下方格水平 8 邻域（防「六面干但贴着一格外的池塘边」）+ 脚层同查
        for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) {
            const b1 = bot.blockAt(below.position.offset(dx, 0, dz));
            if (b1 && LIQUIDS.has(b1.name)) return false;
            const b2 = bot.blockAt(feet.offset(dx, 0, dz));
            if (b2 && LIQUIDS.has(b2.name)) return false;
        }
        // 下方支撑：实心，或浅腔（≤2 格空气到底）——深井/洞窟拒绝（坠落+未知水体）
        const under2 = bot.blockAt(below.position.offset(0, -1, 0));
        if (!under2) return false;
        if (AIR.has(under2.name)) {
            const under3 = bot.blockAt(below.position.offset(0, -2, 0));
            if (!under3 || under3.boundingBox !== 'block' || LIQUIDS.has(under3.name)) return false;
        } else if (LIQUIDS.has(under2.name) || FALLING.has(under2.name)) return false;
        return true;
    }

    // 水中禁挖闸门命中时的水平挪点：3–6 格随机方向找干地，落地后校验
    // 脚/头不在液体里且脚下站得住；连续 4 次落点仍湿 → 视为此点不可用。
    async _moveToDryGround(ctx, distMin = 3, distMax = 7, awayFrom = null) {
        const bot = ctx.bot;
        for (let attempt = 0; attempt < 4; attempt++) {
            const feet = bot.entity.position.floored();
            let ang;
            if (awayFrom) {
                // 朝指定向量（通常=湿方向的反方向）挪，±25° 抖动——随机小挪距在池塘
                // 边缘只会原地打转（M4B1 interim trial_15 实证）
                ang = Math.atan2(-awayFrom.z, -awayFrom.x) + (Math.random() - 0.5) * 0.9;
            } else {
                ang = Math.random() * Math.PI * 2;
            }
            const dist = distMin + Math.floor(Math.random() * (distMax - distMin));
            const to = new Vec3(Math.round(feet.x + Math.cos(ang) * dist), feet.y, Math.round(feet.z + Math.sin(ang) * dist));
            const ok = await navTo(ctx, new pf.goals.GoalNear(to.x, to.y, to.z, 1), { timeoutMs: 10000, label: 'digdown_dry_move' });
            if (!ok) continue;
            const p = bot.entity.position.floored();
            const f = bot.blockAt(p);
            const h = bot.blockAt(p.offset(0, 1, 0));
            const below = bot.blockAt(p.offset(0, -1, 0));
            const dry = !bot.entity.isInWater && !LIQUIDS.has(f?.name) && !LIQUIDS.has(h?.name);
            if (!dry || !below || below.boundingBox !== 'block') continue;
            // 海滩强化判定：落点水平 8 邻域（±1 层）无液体才算真干——只查脚/头会在
            // 池塘边反复「成功挪点」却步步见水（M4S2 trial_12：8 连挪全在同一片滩涂）
            let wetNeighbor = false;
            for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) {
                for (const dy of [0, -1]) {
                    const nb = bot.blockAt(p.offset(dx, dy, dz));
                    if (nb && LIQUIDS.has(nb.name)) { wetNeighbor = true; break; }
                }
                if (wetNeighbor) break;
            }
            if (!wetNeighbor) return true;
        }
        return false;
    }

    // 单格挖掘 + 验证（digdown 专用：目标方块入账、非目标只清路、
    // 采不动障碍物 = 此点放弃）。返回 true = 可以继续走位，false = 需要中断。
    // 拾取策略（M4S2 trial_03 教训）：阶梯模式走进台阶、垂直模式落进井里都会顺路
    // 穿过掉落物（自动吸附），会话中段不做主动 pickup——尤其垂直井，pickupDrops 会
    // 逐物往井底寻路（1 格宽竖井 pathfinder 每物烧到 4s 超时）。收尾（弃柱分支）扫一次。
    async _digdownDig(ctx, def, block) {
        const bot = ctx.bot;
        const res = await digWithVerify(ctx, block, def);
        if (res.ok) {
            this.digsDone++;
            this.digdownBlocks++;
            this.verifyFails = 0;
            if (def.blocks.includes(block.name)) this.mined++;
            else await sleep(120); // 非目标方块（泥/草）：只清路，不掉目标物资
            return true;
        }
        if (res.reason === FailReason.TOOL_MISSING) {
            if (def.blocks.includes(block.name)) {
                // 目标方块本身采不动 → 真缺工具，向上要工具（blockName 供 Resolver 查表）
                this._fail(FailReason.TOOL_MISSING, { mined: this.mined, blockName: block.name });
            } else {
                // 途中障碍物采不动（如木镐遇铁矿）→ 此点放弃，换点由上层决定
                ctx.run.counters.unsafeTargets++;
                ctx.telemetry('digdown_obstruction', { block: block.name, y: Math.floor(bot.entity.position.y) });
                this._unsafeAbort = true;
            }
            return false;
        }
        ctx.telemetry('digdown_dig_fail', { error: res.error, block: block.name });
        this.verifyFails++;
        if (this.verifyFails >= 3) {
            ctx.run.counters.unsafeTargets++;
            this._unsafeAbort = true; // 这块挖不动，视为此点不安全，换区/换点由上层决定
        }
        return false;
    }

    // ---------- digdown 模式（阶梯式下行，MC-M1-TASK-04 修复②）----------
    // 每步：挖「斜下前方」一格 → 走进该格（45° 阶梯，脚下永远踩实，不再垂直挖自己脚下）。
    // 挖前两道闸：
    //   ① 水中禁挖：人在水里 / 脚、头、脚下是液体 → 禁止挖，水平挪 3–6 格干地重开（有界）
    //   ② 六面干燥：将挖的格子六个邻面有任何水/岩浆 → 此向不挖；四向全堵 → 同样水平挪点
    async _tickDigdown(ctx, def) {
        const bot = ctx.bot;
        if (this.phase === 'idle') {
            this.phase = 'dig';
            this._dryMoves = 0;
            this._descendStalls = 0;
            this._lastDescendY = null;
            this._verticalAnnounced = false;
            bot.setControlState('sneak', true);
            ctx.telemetry('digdown_start', { y: Math.floor(bot.entity.position.y), mode: 'stair' });
            return;
        }
        if (this._unsafeAbort) {
            this._blacklistColumn(ctx);
            await pickupDrops(ctx); // 会话收尾：把散落的已挖掉落物扫进包（每4块策略的兜底）
            ctx.telemetry('digdown_abort', { y: Math.floor(bot.entity.position.y), mined: this.mined });
            this._succeed({ mined: this.mined, unsafeAbort: true, digdownBlocks: this.digdownBlocks });
            return;
        }
        if (bot.entity.position.y <= this.digdownMinY) {
            ctx.telemetry('digdown_yfloor', { y: Math.floor(bot.entity.position.y), mined: this.mined });
            this._succeed({ mined: this.mined, yFloor: true, digdownBlocks: this.digdownBlocks });
            return;
        }
        const feet = bot.entity.position.floored();
        const feetBlk = bot.blockAt(feet);
        const headBlk = bot.blockAt(feet.offset(0, 1, 0));
        const belowBlk = bot.blockAt(feet.offset(0, -1, 0));
        if (!feetBlk || !headBlk || !belowBlk) { ctx.telemetry('digdown_unloaded'); this._unsafeAbort = true; return; }

        // 闸①：水中禁挖（含脚下是液体/落方块支撑失效这类变体）
        if (bot.entity.isInWater || LIQUIDS.has(feetBlk.name) || LIQUIDS.has(headBlk.name) || LIQUIDS.has(belowBlk.name)) {
            ctx.run.counters.unsafeTargets++;
            if (this._dryMoves < DRY_MOVE_MAX) {
                this._dryMoves++;
                const moved = await this._moveToDryGround(ctx);
                ctx.telemetry('digdown_dry_move', { why: 'in_water', n: this._dryMoves, ok: moved, y: Math.floor(bot.entity.position.y) });
                if (!moved) this._unsafeAbort = true;
                return;
            }
            ctx.telemetry('digdown_in_water', { n: this._dryMoves, y: Math.floor(bot.entity.position.y) });
            this._unsafeAbort = true;
            return;
        }
        // 支撑塌陷（脚下空气）：等物理落定。但「等了不动」= 站在坑沿角点（碰撞箱被
        // 邻柱支撑，物理永不触发）——M4B2 trial_16 实证：y=63 连等 10+ 次烧到 25s
        // soft stuck。连续 2 次 stall → pathfinder 强制走进脚下方块脱沿；累计 5 次
        // 未果（下方是深井，pathfinder 拒绝跳）弃柱。
        if (AIR.has(belowBlk.name)) {
            const y = bot.entity.position.floored().y;
            if (y === this._lastDescendY) this._descendStalls++;
            else this._descendStalls = 0;
            this._lastDescendY = y;
            ctx.telemetry('digdown_descend', { y, stall: this._descendStalls });
            if (this._descendStalls >= 5) { this._unsafeAbort = true; return; }
            if (this._descendStalls >= 2) {
                const walked = await navTo(ctx, new pf.goals.GoalBlock(feet.x, feet.y - 1, feet.z),
                    { timeoutMs: 5000, label: 'digdown_dropin' });
                if (!walked) { this._unsafeAbort = true; return; }
                this._descendStalls = 0;
                return;
            }
            // 等落体：轮询 y 下降即走（~0.3s），封顶 600ms——固定 waitForTicks(10) 在
            // 链路抖动时一次白等 0.5s+（M3S1 基线 1.68s/块 vs 本会话 2.2s 的差额大头）
            const y0 = bot.entity.position.y;
            const dl = Date.now() + 600;
            while (Date.now() < dl && bot.entity.position.y > y0 - 0.9) await sleep(40);
            return;
        }

        // 垂直快路（全干柱体专用，闸门见 _canVertical；沙滩/水边自动落回阶梯）：挖脚下，
        // 挖穿即自由落体进洞。松 sneak 让 gravity 自然落（sneak 边缘保护会把 bot 挂在坑沿）。
        // **空中不挖**：mineflayer digTime 对 !onGround 一律 ×5（1.15s→5.65s，SMOKE18 实证
        // waitTime=5650）——下落中就等一拍，落地再挖。
        if (this._canVertical(ctx, def)) {
            if (!this._verticalAnnounced) {
                this._verticalAnnounced = true;
                ctx.telemetry('digdown_vertical_path', { y: Math.floor(bot.entity.position.y) });
            }
            if (!bot.entity.onGround) return; // 下落中：等落地（物理 ~0.3s），防空挖 5 倍时长
            bot.setControlState('sneak', false);
            await this._digdownDig(ctx, def, belowBlk);
            return;
        }

        // 阶梯步进（两轮扫描：先零清障方向，再带清障方向——清障是成本，别四面乱清）：
        //   pass 1：某向的腰/头位可通行且「斜下前方」可挖（六面干燥+台阶底扎实）→ 直接挖台阶
        //   pass 2：台阶可行但腰/头位实心 → 只清该向的阻挡，下个 tick 此向变 pass 1
        //   四向全堵（六面见液体/台阶底悬空/未加载）→ 水平挪 3–6 格到干地重开（有界）
        const stepViable = (dx, dz) => {
            const stepPos = feet.offset(dx, -1, dz);
            const step = bot.blockAt(stepPos);
            if (!step || step.boundingBox !== 'block' || LIQUIDS.has(step.name) || FALLING.has(step.name)) return null;
            const underStep = bot.blockAt(stepPos.offset(0, -1, 0));
            if (!underStep || underStep.boundingBox !== 'block' || LIQUIDS.has(underStep.name)) return null;
            if (!this._drySixFaces(ctx, stepPos)) return null;
            return stepPos;
        };
        const openSteps = [];
        for (const [dx, dz] of DIRS4) {
            const stepPos = stepViable(dx, dz);
            if (!stepPos) continue;
            const waist = bot.blockAt(feet.offset(dx, 0, dz));
            const head = bot.blockAt(feet.offset(dx, 1, dz));
            const waistOpen = !waist || waist.boundingBox !== 'block' || LIQUIDS.has(waist.name);
            const headOpen = !head || head.boundingBox !== 'block' || LIQUIDS.has(head.name);
            if (!waistOpen || !headOpen) continue; // 留给 pass 2 清障
            openSteps.push(stepPos);
        }
        // 阶梯本身就是采掘：目标方块（石头）台阶优先于清障型土台阶（M4B2 trial_16：
        // 固定方向序造成 E/W 之字，同层多清一格，每层 ~6s）
        openSteps.sort((a, b) => (def.blocks.includes(bot.blockAt(a)?.name) ? 0 : 1)
            - (def.blocks.includes(bot.blockAt(b)?.name) ? 0 : 1));
        for (const stepPos of openSteps) {
            const ok = await this._digdownDig(ctx, def, bot.blockAt(stepPos));
            if (!ok) return; // TOOL_MISSING / 反复挖不动：_digdownDig 已置态
            // 挖成 → 走进台阶格（M4S1 提速：手动 lookAt+forward 推进 ~0.5s，失败回退
            // pathfinder；释放 sneak 才能走出边缘，走进后重新压住防坠）
            bot.setControlState('sneak', false);
            let arrived = false;
            try { await bot.lookAt(stepPos.offset(0.5, 0.5, 0.5), true); } catch { /* 视角失败不致命 */ }
            bot.setControlState('forward', true);
            const deadline = Date.now() + 2000;
            while (Date.now() < deadline) {
                await sleep(60);
                const p = bot.entity.position.floored();
                if (p.x === stepPos.x && p.y === stepPos.y && p.z === stepPos.z) { arrived = true; break; }
            }
            bot.setControlState('forward', false);
            bot.setControlState('sneak', true);
            if (!arrived) {
                const walked = await navTo(ctx, new pf.goals.GoalBlock(stepPos.x, stepPos.y, stepPos.z),
                    { timeoutMs: 5000, label: 'digdown_step' });
                if (!walked) { this._unsafeAbort = true; }
            }
            return;
        }
        for (const [dx, dz] of DIRS4) {
            const stepPos = stepViable(dx, dz);
            if (!stepPos) continue;
            for (const blk of [bot.blockAt(feet.offset(dx, 0, dz)), bot.blockAt(feet.offset(dx, 1, dz))]) {
                if (!blk || blk.boundingBox !== 'block' || LIQUIDS.has(blk.name)) continue;
                if (!this._drySixFaces(ctx, blk.position)) continue;
                // 落方块（沙/砾）护栏：仅当其上方不是同类落方块（无塌柱）且六面干燥时清掉；
                // 海滩多层沙柱挖底会整体塌进 bot 头格（M4S2 trial_12 "suffocated in a wall"
                // 实证）——多层沙/贴水沙一律弃柱换点
                if (FALLING.has(blk.name)) {
                    const above = bot.blockAt(blk.position.offset(0, 1, 0));
                    if (above && FALLING.has(above.name)) {
                        ctx.run.counters.unsafeTargets++;
                        ctx.telemetry('digdown_falling_block', { block: blk.name, why: 'column' });
                        this._unsafeAbort = true;
                        return;
                    }
                }
                await this._digdownDig(ctx, def, blk);
                return;
            }
        }
        // 四向全堵（六面见液体/台阶底悬空/未加载）→ 水平挪到干地重开（有界）。
        // 逃逸方向取「湿台阶方向的反方向」、距离 8–16：池塘/湖边的随机 3–6 格挪点
        // 会一直落在岸边湿台阶区（interim M4B1 trial_15：4 次挪点全败烧完预算弃柱，
        // 全局 NO_RESOURCE_FOUND）；反方向远挪才能真正离开水边。无湿向量时退回随机。
        if (this._dryMoves < DRY_MOVE_MAX) {
            this._dryMoves++;
            let wetX = 0, wetZ = 0;
            for (const [dx, dz] of DIRS4) {
                const sPos = feet.offset(dx, -1, dz);
                const s = bot.blockAt(sPos);
                const wet = !s || s.boundingBox !== 'block' || LIQUIDS.has(s.name)
                    || FALLING.has(s.name) || !this._drySixFaces(ctx, sPos);
                if (wet) { wetX += dx; wetZ += dz; }
            }
            const away = (wetX !== 0 || wetZ !== 0) ? { x: wetX, z: wetZ } : null;
            const moved = await this._moveToDryGround(ctx, 8, 17, away);
            ctx.telemetry('digdown_no_dry_step', { n: this._dryMoves, ok: moved, away: away ? [away.x, away.z] : null, y: Math.floor(bot.entity.position.y) });
            if (!moved) this._unsafeAbort = true;
            return;
        }
        ctx.telemetry('digdown_no_dry_step', { n: this._dryMoves, exhausted: true, y: Math.floor(bot.entity.position.y) });
        this._unsafeAbort = true;
    }

    // ---------- 分支挖矿模式（MC-M1-TASK-06，铁矿任务单口径）----------
    // descend：完整复用上面已验收的 digdown 步进器（阶梯/垂直闸门/水岩浆六面闸全部生效）
    //          下到矿带 y≤branchStartY；digdownMinY 仍是绝对下界（铁矿 16）。
    // tunnel ：水平掘进 2 高巷道。每拍先扫 5.5 格内「有暴露面」的目标矿（公平口径：
    //          矿在挖掘暴露出来之后才算可见——埋着的矿不进候选），有则挖；
    //          没有则掘进一格（头/腰位，挖前六面干燥），每 3 格挖一个侧龛主动暴露新面；
    //          同向 16 格转弯；四向全堵（液体/落方块柱/未加载）→ 弃柱换向/上层换区。
    async _tickBranch(ctx, def) {
        const bot = ctx.bot;
        if (this.phase === 'idle' || this.phase === 'mine') {
            this.phase = 'descend';
            this._tunnel = null;
            bot.setControlState('sneak', true);
            ctx.telemetry('branch_start', { y: Math.floor(bot.entity.position.y), bandStartY: this.branchStartY, yFloor: this.digdownMinY });
            return;
        }
        if (this._unsafeAbort) {
            this._blacklistColumn(ctx);
            await pickupDrops(ctx);
            ctx.telemetry('branch_abort', { y: Math.floor(bot.entity.position.y), mined: this.mined, phase: this.phase });
            this._succeed({ mined: this.mined, unsafeAbort: true, digdownBlocks: this.digdownBlocks });
            return;
        }
        if (bot.entity.position.y <= this.digdownMinY && this.phase !== 'tunnel') {
            // 未到带先触底（出生点就在深处）：直接进 tunnel
            this.phase = 'tunnel';
        }
        if (this.phase === 'descend') {
            if (bot.entity.position.y <= this.branchStartY) {
                this.phase = 'tunnel';
                ctx.telemetry('branch_tunnel_start', { y: Math.floor(bot.entity.position.y), mined: this.mined });
                return;
            }
            await this._tickDigdown(ctx, def); // 复用已验收步进器（含其全部终态语义）
            return;
        }
        // ---- tunnel 阶段 ----
        if (!this._tunnel) {
            this._tunnel = { dirIdx: 0, steps: 0, nicheAlt: 1, stalls: 0 };
        }
        const t = this._tunnel;

        // MC-M1-TASK-06b：sideQuest 顺手沙砾（公平口径同铁矿=暴露面非空；主资源候选优先）。
        // 挖天然沙砾只为囤「重埋原料」——flint 掉落是概率事件，重埋循环在 FlintCollectTask。
        let sideTarget = null;
        if (this.sideQuest && countItems(bot, resourceDef(this.sideQuest.resource).drops) < this.sideQuest.count) {
            const sideIds = blockIds(bot, resourceDef(this.sideQuest.resource));
            sideTarget = bot.findBlocks({ matching: sideIds, maxDistance: 5.5, count: 8 })
                .filter((p) => !ctx.run.blacklist.has(posKey(p)))
                .filter((p) => this._exposedFaces(ctx, p).length > 0)
                .filter((p) => { const b = bot.blockAt(p); return b && this._safeToDig(ctx, b); })
                .sort((a, b) => bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b))[0] ?? null;
        }

        // 扫描：5.5 格内有暴露面的目标矿（公平口径）→ 采它
        const ids = blockIds(bot, def);
        const candidates = bot.findBlocks({ matching: ids, maxDistance: 5.5, count: 24 })
            .filter((p) => !ctx.run.blacklist.has(posKey(p)))
            .filter((p) => !def.fairnessExposure || this._exposedFaces(ctx, p).length > 0)
            .filter((p) => {
                const b = bot.blockAt(p);
                return b && def.blocks.includes(b.name) && this._safeToDig(ctx, b);
            })
            .sort((a, b) => bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b));
        if (candidates.length) {
            const pos = candidates[0];
            t.stalls = 0;
            if (def.fairnessExposure) {
                ctx.run.counters.ironTargetsSelected++;
                ctx.telemetry('iron_target_selected', {
                    pos: [pos.x, pos.y, pos.z],
                    faces: this._exposedFaces(ctx, pos),
                    dist: Math.round(bot.entity.position.distanceTo(pos) * 10) / 10,
                    mode: 'branch',
                });
            }
            const res = await digWithVerify(ctx, bot.blockAt(pos), def);
            if (res.ok) {
                this.mined++;
                this.digsDone++;
                this.verifyFails = 0;
                await sleep(250);
                await pickupDrops(ctx);
            } else if (res.reason === FailReason.TOOL_MISSING) {
                this._fail(FailReason.TOOL_MISSING, { mined: this.mined, blockName: bot.blockAt(pos)?.name });
            } else {
                ctx.run.blacklist.add(posKey(pos));
                this.verifyFails++;
                if (this.verifyFails >= 3) this._unsafeAbort = true;
            }
            return;
        }

        // MC-M1-TASK-06b：sideQuest 顺手沙砾——主资源无候选的拍才轮到（不打断隧道节奏）。
        // 每次选中记 flint_target_selected（公平口径遥测，同 iron_target_selected 口径）。
        if (sideTarget) {
            const sideDef = resourceDef(this.sideQuest.resource);
            const sb = bot.blockAt(sideTarget);
            if (sb && sideDef.blocks.includes(sb.name)) {
                ctx.telemetry('flint_target_selected', {
                    pos: [sideTarget.x, sideTarget.y, sideTarget.z],
                    faces: this._exposedFaces(ctx, sideTarget),
                    dist: Math.round(bot.entity.position.distanceTo(sideTarget) * 10) / 10,
                    mode: 'branch_sidequest',
                });
                const res = await digWithVerify(ctx, sb, sideDef);
                if (res.ok) {
                    this.sideDigs++;
                    this.digsDone++;
                    this.verifyFails = 0;
                    await sleep(250);
                    await pickupDrops(ctx); // 沙砾本体必须进包（重埋原料）
                } else if (res.reason === FailReason.TOOL_MISSING) {
                    ctx.run.blacklist.add(posKey(sideTarget)); // 徒手可采的方块走到这里=异常，换块
                } else {
                    ctx.run.blacklist.add(posKey(sideTarget));
                    this.verifyFails++;
                    if (this.verifyFails >= 3) this._unsafeAbort = true;
                }
            } else {
                ctx.run.blacklist.add(posKey(sideTarget));
            }
            return;
        }

        // 掘进：换向调度（同向 16 格转 90°，四向轮转；卡死 8 拍弃柱）
        if (t.stalls >= 8) {
            ctx.telemetry('branch_stalled', { y: Math.floor(bot.entity.position.y), mined: this.mined });
            this._unsafeAbort = true;
            return;
        }
        const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]]; // E S W N 轮转
        for (let i = 0; i < 4; i++) {
            const dirIdx = (t.dirIdx + i) % 4;
            const [dx, dz] = DIRS[dirIdx];
            const feet = bot.entity.position.floored();
            const waist = feet.offset(dx, 0, dz);
            const head = feet.offset(dx, 1, dz);
            const floor = feet.offset(dx, -1, dz);
            const underFloor = floor.offset(0, -1, 0);
            const waistB = bot.blockAt(waist), headB = bot.blockAt(head), floorB = bot.blockAt(floor);
            // 未加载 → 此向不可用
            if (!waistB || !headB || !floorB) continue;
            // 落方块（沙/砾）不进巷道路径（塌柱风险，digdown 同款守卫更严：直接换向）
            if (FALLING.has(waistB.name) || FALLING.has(headB.name)) continue;
            // 前方地 pie：必须实心且六面干燥；下方悬空（深井）→ 此向不可用
            if (floorB.boundingBox !== 'block' || LIQUIDS.has(floorB.name) || FALLING.has(floorB.name)) continue;
            if (!this._drySixFaces(ctx, floor)) continue;
            if (!underFloor || underFloor.boundingBox !== 'block') continue;
            if (LIQUIDS.has(underFloor.name)) continue;
            // 巷道两格：实心则要求六面干燥（岩浆/水暴露面检查——任务单 §2-⑤），空气则直接通行
            //（洞穴口是暴露矿的天然来源，走进去）
            const waistSolid = waistB.boundingBox === 'block' && !LIQUIDS.has(waistB.name);
            const headSolid = headB.boundingBox === 'block' && !LIQUIDS.has(headB.name);
            if (waistSolid && !this._drySixFaces(ctx, waist)) continue;
            if (headSolid && !this._drySixFaces(ctx, head)) continue;
            if (!waistSolid && !headSolid) { t.stalls = 0; } // 已是开口：只走不挖
            // 掘进一格：先头位后腰位（头先挖防头顶落方块塌进新腔）
            if (headSolid) {
                if (!(await this._digdownDig(ctx, def, headB))) return;
                await sleep(80);
            }
            if (waistSolid) {
                if (!(await this._digdownDig(ctx, def, waistB))) return;
                await sleep(80);
            }
            // 走进新腔（digdown 台阶同款手动推进，失败回退 pathfinder）
            bot.setControlState('sneak', false);
            let arrived = false;
            try { await bot.lookAt(waist.offset(0.5, 0.5, 0.5), true); } catch { /* 视角失败不致命 */ }
            bot.setControlState('forward', true);
            const deadline = Date.now() + 2000;
            while (Date.now() < deadline) {
                await sleep(60);
                const p = bot.entity.position.floored();
                if (p.x === waist.x && p.y === waist.y && p.z === waist.z) { arrived = true; break; }
            }
            bot.setControlState('forward', false);
            bot.setControlState('sneak', true);
            if (!arrived) {
                const walked = await navTo(ctx, new pf.goals.GoalBlock(waist.x, waist.y, waist.z), { timeoutMs: 5000, label: 'branch_step' });
                if (!walked) { t.stalls++; return; }
            }
            t.dirIdx = dirIdx;
            t.steps++;
            t.stalls = 0;
            ctx.telemetry('branch_tunnel_step', { dir: dirIdx, step: t.steps, y: waist.y, mined: this.mined });
            // 每 3 格挖一个侧龛主动暴露新面（交替左右），下拍扫描自然看到新暴露的目标矿
            if (t.steps % 3 === 0) {
                const perp = DIRS[(dirIdx + 1) % 4];
                const side = t.nicheAlt *= -1;
                const nx = feet.offset(perp[0] * side, 0, perp[1] * side);
                const niche = bot.blockAt(nx);
                if (niche && niche.boundingBox === 'block' && !LIQUIDS.has(niche.name) && !FALLING.has(niche.name)
                    && this._drySixFaces(ctx, nx) && !def.blocks.includes(niche.name)) {
                    const ok = await this._digdownDig(ctx, def, niche);
                    if (ok) ctx.telemetry('branch_niche', { pos: [nx.x, nx.y, nx.z], side });
                }
            }
            return;
        }
        t.stalls++;
    }
}
