// recipe_resolver.js — MC-M1-TASK-02 最小配方依赖解析器
//
// 任务书 §3 铁律：不硬编码科技树。数据全部来自 bot.registry（minecraft-data 按
// bot 协议版本实例化）+ prismarine-recipe（mineflayer bot.craft 的同源数据，
// 保证「规划说的」和「执行能做的」是同一套配方）。速通科技树之外（炼药/红石/
// 最优规划）不做框架。
//
// 核心 API：
//   recipeVariants(name) → 该物品全部配方变体（含 delta：一次合成的净库存变化，
//                          requiresTable：是否需要 3x3 工作台）
//   plan(name, count, inv, chain, opts) → 扁平有序步骤表或结构化错误。
//     纯函数：对库存快照做「模拟推演」——采集步骤按 family 全量入账（乐观近似，
//     执行时按真实库存选变体，失配走有界 replan），合成步骤按 delta 精确增减。
//     步骤形态：{kind:'acquire', resource, count} | {kind:'craft', item, target, station}
//
// 关键设计：同物多variant（8 种原木→8 种木板；木板→木棍 12 变体……）。规划器不在
// 规划期钉死变体，而是：缺口计算选「缺得最少」的变体；执行期 CraftingTask 用
// bot.recipesFor 的库存校验现场挑「当前背包够料」的变体。异型原木混包因此天然可解。
//
// 依赖闸门：ingredient 缺口 → gatherFamilyOf 命中 → Acquire 子任务；
//          有配方 → 递归 plan；两者皆无 → DEPENDENCY_UNSUPPORTED（不自动解决）。
// 守卫：chain 重复项 → DEPENDENCY_CYCLE；递归深度 8 → DEPENDENCY_TOO_DEEP；
//       单步迭代上限防活锁 → PLAN_STUCK。

import prismarineRecipe from 'prismarine-recipe';
import { gatherFamilyOf, RESOURCES } from './resources.js';

const MAX_CHAIN_DEPTH = 8;
const MAX_PLAN_ITERS = 12;

// —— MC-M1-TASK-06（BASIC-iron）：熔炼真值表 ——
// minecraft-data / prismarine-recipe 都不含熔炼数据（已核实 1.16.1 只有合成 recipes），
// 此表为 1.16.1 jar 的熔炉真值（矿石直出锭；「粗金属 raw_iron」是 1.17+ 机制，见 gate）。
// 燃料不进 delta 的计划主账：执行期 SmeltTask 按「煤 > 木板 > 原木」优先级自选
//（原版燃烧值：煤 8 项/个、木板 1.5 项/个、原木 1.5 项/个）。计划期为保底按木板预留——
// delta 里 -1 木板/锭（比真实 1.5 项/锭多备 50%，浪费 ≤1 块木板，换执行期燃料弹性）。
export const SMELT_RECIPES = {
    iron_ingot: { input: 'iron_ore', outPerOp: 1 },
};

// 熔炼表只在「前 1.17 世界」生效：1.17+ 矿石掉 raw_iron（需高炉配方不同），本表不适用。
function smeltingApplies(registry) {
    return registry?.itemsByName?.['raw_iron'] === undefined
        && registry?.itemsByName?.['iron_ingot'] !== undefined;
}

export class RecipeResolver {
    constructor(registry) {
        this.reg = registry;
        this.Recipe = prismarineRecipe(registry).Recipe;
        this._cache = new Map();
        this.smelt = smeltingApplies(registry) ? SMELT_RECIPES : null;
    }

    static forBot(bot) { return new RecipeResolver(bot.registry); }

    /** 全部配方变体（标准化字段）。无配方返回 []。 */
    recipeVariants(itemName) {
        if (this._cache.has(itemName)) return this._cache.get(itemName);
        const item = this.reg.itemsByName[itemName];
        let variants = [];
        if (item) {
            try {
                variants = this.Recipe.find(item.id, null).map((v) => ({
                    result: v.result,
                    delta: v.delta ?? [],
                    requiresTable: !!v.requiresTable,
                }));
            } catch { variants = []; }
            // 熔炼物品（1.16.x：铁矿石直出铁锭）：用熔炼变体【替换】合成变体。
            // 原合成变体（铁矿块↔锭、粒↔锭）在 1.16.1 数据里互为依赖，会触发
            // DEPENDENCY_CYCLE（iron_ingot→iron_nugget→iron_ingot，空库存认证实测），
            // 且对「从矿石开始」的铁链全是死路——熔炼才是这条链的真来源。
            const smeltDef = this.smelt?.[itemName];
            if (smeltDef) {
                const inId = this.reg.itemsByName[smeltDef.input]?.id;
                const planksId = this.reg.itemsByName['oak_planks']?.id;
                const delta = [];
                if (inId != null) delta.push({ id: inId, count: -1 });
                if (planksId != null) delta.push({ id: planksId, count: -1 }); // 燃料保底预留（木板）
                delta.push({ id: item.id, count: smeltDef.outPerOp });
                variants = [{ result: { id: item.id, count: smeltDef.outPerOp }, delta, requiresTable: false, smelt: true }];
            }
        }
        this._cache.set(itemName, variants);
        return variants;
    }

    _itemName(id) { return this.reg.items[id]?.name ?? null; }

    /** 变体在模拟库存下最多能做几次（ingredient 全部覆盖时的最小值） */
    _opsCoverable(sim, v) {
        let ops = Infinity;
        for (const d of v.delta) {
            if (d.count >= 0) continue;
            const have = sim[this._itemName(d.id)] ?? 0;
            ops = Math.min(ops, Math.floor(have / -d.count));
        }
        return ops === Infinity ? 0 : ops;
    }

    _applyCraft(sim, v, ops) {
        for (const d of v.delta) {
            const name = this._itemName(d.id);
            if (!name) continue;
            sim[name] = (sim[name] ?? 0) + d.count * ops;
        }
    }

    /**
     * 生成「做出 count 个 itemName」的扁平步骤表。
     * @param inv    库存快照 {itemName: count}
     * @param chain  递归链（cycle/depth 守卫）
     * @param opts   {tableNearby} — 身边已有工作台时不必再合成一个
     */
    plan(itemName, count, inv, chain = [], opts = {}) {
        if (chain.includes(itemName)) return { error: 'DEPENDENCY_CYCLE', item: itemName };
        if (chain.length >= MAX_CHAIN_DEPTH) return { error: 'DEPENDENCY_TOO_DEEP', item: itemName };
        const variants = this.recipeVariants(itemName);
        if (!variants.length) return { error: 'RECIPE_NOT_FOUND', item: itemName };

        const steps = [];
        const sim = { ...inv };
        const needsTable = variants.some((v) => v.requiresTable);

        // 需要 3x3 工作台且包里没有、身边也没有 → 先把工作台本身排进计划（工作台配方 2x2，
        // 永不再嵌套 station，递归深度 +1 到顶）
        if (needsTable && (sim['crafting_table'] ?? 0) < 1 && !opts.tableNearby) {
            const sub = this.plan('crafting_table', 1, sim, [...chain, itemName], opts);
            if (sub.error) return { error: sub.error, item: 'crafting_table', for: itemName };
            for (const s of sub.steps) { steps.push(s); this._applyExecution(sim, s); }
        }

        let remain = count - (sim[itemName] ?? 0);
        let guard = 0;
        while (remain > 0 && guard++ < MAX_PLAN_ITERS) {
            // 优先挑当前模拟库存下能直接开工的变体（覆盖次数最多者优先）
            let best = null, bestOps = 0;
            for (const v of variants) {
                const ops = this._opsCoverable(sim, v);
                if (ops > bestOps) { best = v; bestOps = ops; }
            }
            if (best) {
                const ops = Math.min(bestOps, Math.ceil(remain / best.result.count));
                // 熔炼步骤需要熔炉：身边/包里都没有时先排一个（8 圆石，需 3x3 工作台）——
                // 与工作台 ensure 同款「先于该步骤入模拟账」语义
                if (best.smelt && (sim['furnace'] ?? 0) < 1) {
                    const fsub = this.plan('furnace', 1, sim, [...chain, itemName], opts);
                    if (fsub.error) return { error: fsub.error, item: 'furnace', for: itemName };
                    for (const s of fsub.steps) { steps.push(s); this._applyExecution(sim, s); }
                }
                steps.push({
                    kind: best.smelt ? 'smelt' : 'craft', item: itemName,
                    target: (sim[itemName] ?? 0) + best.result.count * ops,
                    station: best.requiresTable,
                    delta: best.delta, ops,   // 供父计划回放模拟账（精确增减）
                });
                this._applyCraft(sim, best, ops);
                remain -= best.result.count * ops;
                continue;
            }
            // 没有变体能开工 → 找缺口最小的变体补料（异型材料下避免多砍树）
            const opsTarget = Math.ceil(remain / variants[0].result.count);
            let pick = null, pickMissing = Infinity;
            for (const v of variants) {
                let missing = 0, unknown = false;
                for (const d of v.delta) {
                    if (d.count >= 0) continue;
                    const name = this._itemName(d.id);
                    if (!name) { unknown = true; break; }
                    const need = -d.count * opsTarget;
                    missing += Math.max(0, need - (sim[name] ?? 0));
                }
                if (!unknown && missing < pickMissing) { pick = v; pickMissing = missing; }
            }
            if (!pick) return { error: 'DEPENDENCY_UNSUPPORTED', item: itemName };
            let progressed = false;
            for (const d of pick.delta) {
                if (d.count >= 0) continue;
                const ingName = this._itemName(d.id);
                if (!ingName) return { error: 'DEPENDENCY_UNSUPPORTED', item: d.id, for: itemName };
                const need = -d.count * opsTarget;
                const have = sim[ingName] ?? 0;
                if (have >= need) continue;
                const family = gatherFamilyOf(ingName);
                if (family) {
                    steps.push({ kind: 'acquire', resource: family, count: need - have });
                    // 模拟账只在规范型（drops[0]）入账：family 采集不保证树种，多型入账会制造
                    // 「幻影原木」让后续合成消耗不存在的类型（dev1 教训）；执行期真实树种由
                    // 木板改型规则兜底
                    const canonical = RESOURCES[family].drops[0];
                    sim[canonical] = (sim[canonical] ?? 0) + (need - have);
                    progressed = true;
                } else if (ingName.endsWith('_planks')) {
                    // 木板身份流体（dev1 教训；TASK-06 补「转账冲抵」）：缺口按 canonical 记账，
                    // 但库存里任何类型木板都可顶。smoke4 实证的假进展死循环：库存 dark_oak_planks×5
                    // 时改型子计划 remain≤0 返回空步骤，父层误判 progressed → PLAN_STUCK。
                    // 修法：先把已有其他型木板「转账」进 canonical（语义=拿现有木板顶缺口，
                    // 执行期熔炉/合成吃的本来就是任意木板）；真不够再走原木改型。
                    const poolTotal = Object.entries(sim).reduce((a, [n, c]) => a + (n.endsWith('_planks') && n !== ingName && typeof c === 'number' ? c : 0), 0);
                    const credit = Math.min(poolTotal, need - (sim[ingName] ?? 0));
                    if (credit > 0) {
                        let left = credit;
                        for (const n of Object.keys(sim)) {
                            if (!n.endsWith('_planks') || n === ingName || left <= 0) continue;
                            const take = Math.min(sim[n] ?? 0, left);
                            sim[n] -= take;
                            left -= take;
                        }
                        sim[ingName] = (sim[ingName] ?? 0) + credit;
                        progressed = true;
                        continue;
                    }
                    // 木板身份流体（dev1 教训）：砍到哪种树做哪种木板。规划期按 sim 里的
                    // 原木类型落地（没有则乐观取 family 规范型），执行器有同样的改型规则
                    //（crafting_task._craftStep），两边语义一致。
                    const logType = RESOURCES.log.drops.find((l) => (sim[l] ?? 0) > 0) ?? RESOURCES.log.drops[0];
                    const concrete = logType.replace('_log', '') + '_planks';
                    const sub = this.plan(concrete, need, sim, [...chain, itemName], opts);
                    if (sub.error) return { error: sub.error, item: concrete, for: itemName };
                    // 空步骤守卫（TASK-06）：子计划认为该型木板已够（remain≤0）时没有可执行
                    // 步骤——必须把这次冲抵实际转账进 sim，否则父层假进展空转到 PLAN_STUCK
                    if (!sub.steps.length) {
                        sim[ingName] = (sim[ingName] ?? 0) + need;
                        sim[concrete] = Math.max(0, (sim[concrete] ?? 0) - need);
                        progressed = true;
                        continue;
                    }
                    for (const s of sub.steps) { steps.push(s); this._applyExecution(sim, s); }
                    progressed = true;
                } else {
                    // 传 need 而非缺口：子计划内部会用 sim 计算真正的 remain（已有量自动抵扣），
                    // 「缺口再被 sim 存量吃掉」导致的空步骤假僵局由此消除
                    const sub = this.plan(ingName, need, sim, [...chain, itemName], opts);
                    if (sub.error) return { error: sub.error, item: ingName, for: itemName };
                    for (const s of sub.steps) { steps.push(s); this._applyExecution(sim, s); }
                    progressed = true;
                }
            }
            if (!progressed) return { error: 'PLAN_STUCK', item: itemName };
        }
        if (remain > 0) return { error: 'PLAN_STUCK', item: itemName };
        return { steps: this._frontloadAcquires(steps), station: needsTable };
    }

    // MC-M1-TASK-06（BASIC-iron 实测教训）：gap-fill 会让同一 family 的 acquire 拆散在计划
    // 中后段（铁链 3 次 Acquire(log×1)——挖完铁矿人已在洞里，回头找树每趟 150s+）。
    // 后处理：同类 acquire 前置集中（按资源首次出现序合并计数），craft/smelt 保持原相对序。
    // 模拟账不变（acquire 总量入账一致），单 acquire 计划（wooden_pickaxe 等）是 no-op，
    // 只有铁链这类多段采集计划受影响。
    //
    // MC-M1-TASK-06b：flint 并进 iron_ore 的地下窗口（任务单 §1-1「燧石跟着地下阶段走」）。
    // flint 独立 acquire 排在铁链尾声——bot 已回地表/炉边才开始找沙砾，T06F2-03 实证
    // 256-538s 地表 search/wander/relocate 零收获。合并后 flint 作为 iron_ore 步骤的
    // sideQuest 下发，分支挖矿的地下阶段顺手采暴露沙砾；本变换只动步骤表，模拟账不变
    //（flint 的入账在 plan() 主循环里已完成）。宿主不在（如库存已有铁矿）时保留独立
    // flint acquire 走原地表路径。
    static SIDE_QUEST_HOSTS = { flint: 'iron_ore' };

    _frontloadAcquires(steps) {
        const acqTotals = new Map();      // resource → 合计 count（保持首次出现序）
        const rest = [];
        for (const s of steps) {
            if (s.kind === 'acquire') {
                acqTotals.set(s.resource, (acqTotals.get(s.resource) ?? 0) + s.count);
            } else {
                rest.push(s);
            }
        }
        // 原木安全余量（TASK-06 smoke7 实证）：嵌套工具救援链共享同一物理背包，其木板/木棍
        // 合成会先吃掉根计划前置采集的原木——根计划在合成段短缺 1 块木板，被迫在地下
        // 重新找树（每趟 150s+，预算死）。+2 原木（=8 木板）覆盖典型双层嵌套消耗。
        // 【只在含熔炼步骤的铁链类计划生效】——bootstrap 木器/石器链保持 TASK-02 原口径
        //（回归线 M4B4 P90 不许劣化，不能给旧链加采集量）。
        if (acqTotals.has('log') && steps.some((s) => s.kind === 'smelt')) {
            acqTotals.set('log', acqTotals.get('log') + 2);
        }
        // sideQuest 合并（06b）：side 资源搭宿主资源同窗口采集
        const sideQuests = new Map();
        for (const [side, host] of Object.entries(RecipeResolver.SIDE_QUEST_HOSTS)) {
            if (acqTotals.has(side) && acqTotals.has(host)) {
                sideQuests.set(host, { resource: side, count: acqTotals.get(side) });
                acqTotals.delete(side);
            }
        }
        if (!acqTotals.size) return steps;
        return [...[...acqTotals.entries()].map(([resource, count]) => ({
            kind: 'acquire', resource, count,
            ...(sideQuests.has(resource) ? { sideQuest: sideQuests.get(resource) } : {}),
        })), ...rest];
    }

    /** 执行步骤入模拟账（acquire：family 规范型入账；craft/smelt：按 delta×ops 精确增减） */
    _applyExecution(sim, s) {
        if (s.kind === 'acquire') {
            const canonical = RESOURCES[s.resource].drops[0];
            sim[canonical] = (sim[canonical] ?? 0) + s.count;
        } else if ((s.kind === 'craft' || s.kind === 'smelt') && Array.isArray(s.delta) && s.ops) {
            for (const d of s.delta) {
                const name = this._itemName(d.id);
                if (name) sim[name] = (sim[name] ?? 0) + d.count * s.ops;
            }
        } else if (s.kind === 'craft') {
            sim[s.item] = Math.max(sim[s.item] ?? 0, s.target ?? 0);
        }
    }
}
