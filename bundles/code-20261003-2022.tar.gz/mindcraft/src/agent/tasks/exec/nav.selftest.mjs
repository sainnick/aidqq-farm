// nav.selftest.mjs — nav.js 的**离线**单测（不开服、不占端口、不占泳道）
//
// ★ 合并单 M-01：从 B 线 `aidqq/s1-portal` 摘入 `retreatFromLava` 的
//   `dx=dz=0` 空操作修复时，连带摘入 B 的对应离线用例。
//   **只摘本单范围内的断言（用例 1–7）**；B 的 r14 放行名单（用例 8–14）
//   与 r15 假想站位（用例 15–19）留在 B 分支，随整分支点火后再合。
//   原文见 `mindcraft-wt/s1-portal/src/agent/tasks/exec/nav.selftest.mjs`。
//
// 为什么必须有（r8 的教训）：
//   `retreatFromLava` 的 `dx=dz=0` 空操作分支**已经造成过一次真实的岩浆死亡**
//   （P8R8_SMOKE3 server.log：`tried to swim in lava`；telemetry：
//   `nav_lava_retreat to === bot`）。它是安全硬线，却直到实跑才暴露 ——
//   因为当时**没有任何离线用例**覆盖这个分支。
//   ⇒ 凡是"出错会死人"的分支，都必须有一道离线断言。
//
// 跑法：node nav.selftest.mjs     （退出码 0 = 全过）

import { Vec3 } from 'vec3';
import { nearestSafeSpot, retreatFromLava } from './nav.js';
import minecraftData from 'minecraft-data';

let pass = 0, fail = 0;
const ok = (cond, name, extra = '') => {
    if (cond) { pass++; console.log(`  ✅ ${name}`); }
    else { fail++; console.log(`  ❌ ${name}${extra ? '  → ' + extra : ''}`); }
};

/** 造一个假 bot：给定一张「坐标 → 方块名」表，blockAt 从表里查 */
function fakeBot(map) {
    return { blockAt: (p) => {
        const k = `${Math.floor(p.x)},${Math.floor(p.y)},${Math.floor(p.z)}`;
        const name = map[k];
        if (name === undefined) return null;
        // 空气 = boundingBox 'empty'；实心 = 'block'
        const SOLID = new Set(['stone', 'cobblestone', 'obsidian', 'dirt', 'planks', 'sand', 'gravel']);
        return { name, boundingBox: SOLID.has(name) ? 'block' : 'empty' };
    } };
}

console.log('=== nav.selftest：retreatFromLava 的 dx=dz=0 分支（M-01）===\n');

// —— 用例 1：正悬于岩浆上方，四周 8 格里有 3 个安全落脚点 ⇒ 应挑**最近**的那个 ——
//   bot 在 (0,70,0)；岩浆在脚下 (0,69,0)。安全点：(1,70,0) 与 (0,70,1) 都安全。
{
    const map = {
        '0,69,0': 'lava',            // 脚下的岩浆
        '1,69,0': 'stone',           // 东边可站
        '0,69,1': 'stone',           // 北边可站
        '-1,69,0': 'stone',
    };
    const spot = nearestSafeSpot(fakeBot(map), new Vec3(0, 70, 0));
    ok(!!spot, '用例1：找到了安全落脚点', '返回 null');
    ok(spot && (spot.x === 1 || spot.x === -1 || spot.z === 1), '用例1：落点与 bot 相邻', JSON.stringify(spot));
}

// —— 用例 2：原 bug 的核心场景 —— 撤离目标**不能等于当前格** ——
//   旧实现 dx=dz=0 ⇒ len||1 ⇒ tx,tz === p.x,p.z ⇒ 目标=当前格（空操作）。
{
    const map = { '0,69,0': 'lava', '1,69,0': 'stone', '0,69,1': 'stone' };
    const p = new Vec3(0, 70, 0);
    const spot = nearestSafeSpot(fakeBot(map), p);
    const moved = spot && (spot.x !== p.x || spot.z !== p.z);
    ok(moved, '用例2：撤离目标 ≠ 当前格（不再是空操作）', `spot=${JSON.stringify(spot)}`);
}

// —— 用例 3：**不能**选到脚下就是岩浆/液体的格子 ——
//   (1,69,0) 若是 lava，bot 站上去等于没撤。
{
    const map = {
        '0,69,0': 'lava',
        '1,69,0': 'lava',            // ← 陷阱：头是空气但脚下是岩浆
        '0,69,1': 'stone',           // 唯一安全
    };
    const spot = nearestSafeSpot(fakeBot(map), new Vec3(0, 70, 0));
    ok(spot && spot.x === 0 && spot.z === 1, '用例3：跳过"脚下是岩浆"的格，选中唯一安全格', JSON.stringify(spot));
}

// —— 用例 4：**不能**选到头泡在液体里的格子 ——
{
    const map = {
        '0,69,0': 'lava',
        '1,70,0': 'water',           // ← 陷阱：脚下实心，但头在水里
        '1,69,0': 'stone',
        '0,69,1': 'stone',
    };
    const spot = nearestSafeSpot(fakeBot(map), new Vec3(0, 70, 0));
    ok(spot && !(spot.x === 1 && spot.z === 0), '用例4：跳过"头泡水"的格', JSON.stringify(spot));
}

// —— 用例 5：**不能**选到悬空（脚下不是实心块）的格子 ——
{
    const map = {
        '0,69,0': 'lava',
        '1,69,0': 'air',             // ← 陷阱：脚下悬空 = 会掉下去
        '0,69,1': 'stone',
    };
    const spot = nearestSafeSpot(fakeBot(map), new Vec3(0, 70, 0));
    ok(spot && spot.x === 0 && spot.z === 1, '用例5：跳过"脚下悬空"的格', JSON.stringify(spot));
}

// —— 用例 6：周围全不安全 ⇒ 返回 null（调用方会退化成"垂直上跳"）——
{
    const map = { '0,69,0': 'lava' };   // 周围什么都没有
    const spot = nearestSafeSpot(fakeBot(map), new Vec3(0, 70, 0));
    ok(spot === null, '用例6：无安全落脚点时返回 null（而不是随便挑一格）', JSON.stringify(spot));
}

// —— 用例 7：**不能**退回岩浆所在的那一格（dx=dz=0 的退化方向）——
{
    const map = { '0,69,0': 'lava', '1,69,0': 'stone', '0,69,1': 'stone' };
    const spot = nearestSafeSpot(fakeBot(map), new Vec3(0, 70, 0));
    ok(spot && (spot.x !== 0 || spot.z !== 0), '用例7：不会退回岩浆那一格', JSON.stringify(spot));
}

// ══════════════════════════════════════════════════════════════
// ★ M-01 追加（B 线没有的部分）：把**调用点** `retreatFromLava` 本身也钉住。
//
// 为什么必须加：上面 7 条只测 `nearestSafeSpot` 这个**辅助函数**。
// 如果有人把 `retreatFromLava` 回退成修复前那两行
// （`const len = Math.hypot(dx,dz) || 1` + 直接 `tx/tz`），
// `nearestSafeSpot` 仍然在那儿、上面 7 条**照样全绿** —— 而实服上就是那次岩浆死亡。
// ⇒ 离线的绿灯必须能抓住"调用点又变回空操作"这件事。
// 判据用 `nav_lava_retreat` 遥测里的 `how` 字段：它只存在于修复后的实现。
// ══════════════════════════════════════════════════════════════
console.log('=== nav.selftest：retreatFromLava 调用点（M-01 追加）===\n');

/** 造一个够 `new pf.Movements(bot)` 用的假 bot：它会读 bot.registry.blocksByName 等 */
function pathfinderBot(map, pos) {
    const b = fakeBot(map);
    b.registry = minecraftData('1.16.1');
    b.entity = {
        position: new Vec3(pos[0] + 0.5, pos[1], pos[2] + 0.5),
        velocity: new Vec3(0, 0, 0),
        isInLava: false,
    };
    b.goals = [];
    b.pathfinder = {
        setMovements: () => {},
        setGoal: (g) => b.goals.push(g),
        goto: () => Promise.resolve(),      // 立刻到 ⇒ 不吃那 3s 的 sleep
        stop: () => {},
    };
    b.clearControlStates = () => {};
    return b;
}

// —— 用例 8：★ 原 bug 的现场复现 —— bot 正悬于岩浆正上方，撤离**必须给出一个方向** ——
{
    const map = { '0,69,0': 'lava', '1,69,0': 'stone', '0,69,1': 'stone' };
    const bot = pathfinderBot(map, [0, 70, 0]);
    const events = [];
    const ctx = { bot, telemetry: (e, d) => events.push([e, d]) };
    await retreatFromLava(ctx, [0, 69, 0]);         // lavaAt = 脚下的岩浆 ⇒ dx=dz=0
    const ev = events.find((e) => e[0] === 'nav_lava_retreat');
    ok(!!ev, '用例8：撤离动作落了一条 nav_lava_retreat 遥测', JSON.stringify(events));
    ok(ev && ev[1].how === 'nearest_spot',
        '用例8：how = nearest_spot（走的是新分支，不是 away）', ev ? JSON.stringify(ev[1]) : '无遥测');
    const to = ev && ev[1].to;
    ok(!!to && (to[0] !== 0 || to[2] !== 0),
        '用例8：★撤离目标 ≠ 当前格（修复前这里是空操作、目标=当前格）', JSON.stringify(to));
    ok(!!to && (to[0] === 1 || to[2] === 1 || to[0] === -1),
        '用例8：目标落在周围 8 格的安全落脚点上', JSON.stringify(to));
}

// —— 用例 9：周围 8 格全不安全 ⇒ 退化成"垂直上跳"，**仍然不能是当前格原地不动** ——
{
    const map = { '0,69,0': 'lava' };
    const bot = pathfinderBot(map, [0, 70, 0]);
    const events = [];
    const ctx = { bot, telemetry: (e, d) => events.push([e, d]) };
    await retreatFromLava(ctx, [0, 69, 0]);
    const ev = events.find((e) => e[0] === 'nav_lava_retreat');
    ok(!!ev && ev[1].how === 'hop_up_no_spot',
        '用例9：无安全落脚点 ⇒ how = hop_up_no_spot', ev ? JSON.stringify(ev[1]) : '无遥测');
    const g = bot.goals[0];
    ok(!!g && g.y === 71, '用例9：目标 y = 脚下+1（向上跳，不是待在原层）', g ? `y=${g.y}` : '没设目标');
}

// —— 用例 10：**已在浆里** ⇒ 不撤（这条是原有行为，钉住别被顺手改坏）——
{
    const map = { '0,70,0': 'lava' };
    const bot = pathfinderBot(map, [0, 70, 0]);
    const events = [];
    const ctx = { bot, telemetry: (e, d) => events.push([e, d]) };
    await retreatFromLava(ctx, [0, 69, 0]);
    ok(bot.goals.length === 0, '用例10：已经在岩浆里 ⇒ 不发起撤离导航', `设了 ${bot.goals.length} 个目标`);
    ok(events.length === 0, '用例10：也不落 nav_lava_retreat 遥测', JSON.stringify(events));
}

// —— 用例 11：★ 反向验收 —— 修好之后的实现必须**不再**产生 away/原地不动 的组合 ——
//   场景：岩浆在正北 1 格（dx=0, dz=-1 ⇒ len=1，不是退化分支）⇒ 走 away，
//   且目标必须在岩浆的反方向（南侧），离岩浆越来越远。
{
    const map = { '0,69,-1': 'lava', '0,69,1': 'stone', '1,69,0': 'stone', '-1,69,0': 'stone' };
    const bot = pathfinderBot(map, [0, 70, 0]);
    const events = [];
    const ctx = { bot, telemetry: (e, d) => events.push([e, d]) };
    await retreatFromLava(ctx, [0, 69, -1]);
    const ev = events.find((e) => e[0] === 'nav_lava_retreat');
    ok(!!ev && ev[1].how === 'away', '用例11：有明确反方向时仍走 away（老路径没被改坏）', ev ? JSON.stringify(ev[1]) : '无遥测');
    const to = ev && ev[1].to;
    ok(!!to && to[2] > 0, '用例11：目标在岩浆反方向（z 增大 = 远离 z=-1 的岩浆）', JSON.stringify(to));
    ok(!!ev && ev[1].len === 1, '用例11：遥测带 len（没有再被 ||1 吞成 1 而看不出真实距离）', ev ? String(ev[1].len) : '无');
}

console.log(`\n=== ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail === 0 ? 0 : 2);

