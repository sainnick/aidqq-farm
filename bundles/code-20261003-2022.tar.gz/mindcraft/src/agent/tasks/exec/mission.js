// mission.js — MC-M1-TASK-01/02 MISSION 解析
//
// 上层（benchmark runner / 未来豆包 planner / 人工）下发 MISSION，本地解析成任务参数。
// 支持两种注入格式：
//   JSON:  {"resource":"stone","count":16}
//   文本:  "obtain 16 stone" / "obtain stone" / "obtain 3 log"（缺省 count=16，教材 CH1 口径）
// 支持资源 = resources.js 定义表（TASK-02 起 stone + log/wood）；其他直接拒绝。
// 注意（任务书 §14）：豆包只允许下达到这一层（MISSION），科技树依赖由本地任务层自理。

import { resourceDef } from './resources.js';

export const DEFAULT_COUNT = 16; // coach_pack CH1: "16+ cobblestone"

export function parseMission(input) {
    if (input == null || String(input).trim() === '') {
        throw new Error('MISSION_EMPTY');
    }
    const raw = String(input).trim();
    let mission;
    if (raw.startsWith('{')) {
        const obj = JSON.parse(raw);
        mission = { resource: obj.resource, count: obj.count ?? DEFAULT_COUNT };
    } else {
        const m = raw.match(/obtain\s+(?:(\d+)\s+)?([a-z_]+)/i);
        if (!m) throw new Error(`MISSION_UNPARSEABLE: ${raw.slice(0, 120)}`);
        mission = { resource: m[2].toLowerCase(), count: m[1] ? parseInt(m[1], 10) : DEFAULT_COUNT };
    }
    if (!mission.resource) throw new Error('MISSION_NO_RESOURCE');
    resourceDef(mission.resource); // 不支持的资源这里直接抛 UNSUPPORTED_RESOURCE
    if (!(mission.count > 0) || mission.count > 576) throw new Error('MISSION_BAD_COUNT');
    return { resource: mission.resource, count: mission.count, raw: raw.slice(0, 200) };
}
