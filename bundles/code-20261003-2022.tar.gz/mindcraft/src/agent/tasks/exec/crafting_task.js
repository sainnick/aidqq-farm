﻿// crafting_task.js — MC-M1-TASK-02 Task: Crafting（合成任务）
//
// 职责不是「调一次 bot.craft()」（任务书 §2）：给定目标物品与数量，自动判断缺料，
// 按 RecipeResolver 的扁平计划递归满足最低必要依赖（缺原木→Acquire 子任务），
// 再完成合成。全程本地闭环，不询问 LLM。
//
// 阶段机：
//   plan    → 解析计划（resolver.plan；失败 = RECIPE_NOT_FOUND / DEPENDENCY_CYCLE /
//             DEPENDENCY_UNSUPPORTED / DEPENDENCY_TOO_DEEP，全部结构化直报）
//   gather  → 按序执行步骤：acquire → runChild(AcquireResourceTask)；
//             craft → 选变体（bot.recipesFor 的库存校验=「当前背包够料」真值）→ 合成。
//             需 3x3 的配方先 ensureStation（就近工作台导航 / 无则放置包里的）
//   reclaim → 若本任务自己放了工作台 → 挖回背包（材料循环利用；best-effort 不影响成败）
//
// 失配自愈：规划是库存快照上的推演，执行会漂移（异型原木、死亡清包）。craft 缺料 /
// acquire 子任务失败 → 有界 replan（重新解析计划，默认 6 次；每次 replan 前置的
// acquire 必然净增材料，故必然收敛）。replan 耗尽 → CRAFT_FAILED / DEPENDENCY_FAILED。
//
// 工作台生命周期（任务书 §8）：合成→找安全邻近格→放置→方块级验证（没放成功绝不
// 继续 craft：验证不过换格重试，耗尽=PLACEMENT_FAILED）→打开 craft→完成→回收。
//
// 来源：AltoClef（MIT）CraftTask / RecipeTask 的「目标物→递归补料」思想级 PORT；
// 配方数据与执行通道 = prismarine-recipe + mineflayer craft（同源，无第二套配方表）。

import { ExecTask, FailReason, sleep, countItems, posKey } from './task.js';
import { runChild } from './task_stack.js';
import { RecipeResolver } from './recipe_resolver.js';
import { RESOURCES, logFamilyFor } from './resources.js';
import { AcquireResourceTask } from './acquire_resource_task.js';
import { SmeltTask } from './smelt_task.js';
import { navTo, stopNav } from './nav.js';
import { placeItem } from './place.js';
import {
    clickFlavor, windowClickPacket, clickRawConfirmed, takeFromSlotConfirmed, closeWindowConfirmed, countItemsWindowAware,
    craftInGridConfirmed, playerInvRange, windowSlotCount,
} from './window_ops.js';
import pf from 'mineflayer-pathfinder';
import prismarineItem from 'prismarine-item';
import { Vec3 } from 'vec3';

const RESOURCES_LOGS = RESOURCES.log.drops;   // 木板改型用的原木清单（超集；按版本过滤见 _logFamilyFor）

const AIR = new Set(['air', 'cave_air', 'void_air']);
const LIQUIDS = new Set(['lava', 'water']);
const REPLACEABLE = new Set(['air', 'cave_air', 'void_air', 'water', 'grass', 'tall_grass', 'fern', 'snow', 'dead_bush']);

/** `_tableCraft` 内部：某一步点击被服务端拒收 / 无回执 ⇒ 中止本次合成（不当未知异常吞） */
class WindowClickRejected extends Error {
    constructor(verdict) { super(`window_click not confirmed: ${JSON.stringify(verdict)}`); this.verdict = verdict; }
}

function withTimeout(p, ms, tag) {
    return Promise.race([p, sleep(ms).then(() => { throw new Error(tag ?? 'timeout'); })]);
}

// MC-M1-TASK-09 订正：原先这里按「1.17+ 才有 stateId」把 `_tableCraft` gate 在 1.17+，
// 注释里的理由是「1.16.x 协议无 stateId，直发包不成立」。实测（window_ops_selftest ①②）
// 不成立：1.16.1 也有 action 号回执通道（transaction 包），且随版本变的是**包封**不是 Slot 形状。
// 现在 `_tableCraft` 按版本选信封（window_ops.windowClickPacket），两个版本都能用。
// 这个函数保留下来只用于**记录当前走哪条通道**（诊断用），不再 gate 任何东西。
function supportsWindowStateId(registry) {
    const m = /^1\.(\d+)/.exec(String(registry?.version?.majorVersion ?? ''));
    return m ? Number(m[1]) >= 17 : true;
}

function inventorySnapshot(bot) {
    const inv = {};
    for (const it of bot.inventory.items()) inv[it.name] = (inv[it.name] ?? 0) + it.count;
    return inv;
}

export class CraftingTask extends ExecTask {
    constructor(opts = {}) {
        super('CraftingTask', { timeoutMs: opts.timeoutMs ?? 240000 });
        this.item = opts.item;                    // 目标物品名，如 'wooden_pickaxe'
        this.count = opts.count ?? 1;
        this.replanBudgetMax = opts.replanBudget ?? 6;
        // MC-M1-TASK-06d P1：重试预算 2→3。数据依据：06c P2B_FRESH trial_01 一局里
        // craft_fail(craft_promise_rejected) 15 次 vs craft_ok 8 次；单次尝试约 20% 概率
        // 「没到手」，3 次连败概率 0.8%，4 次 0.16%。给到 3 次是拿 1 次重试换 ~60% 的残差下降。
        this.craftRetries = opts.craftRetries ?? 3;
        this.reclaimTable = opts.reclaimTable ?? true;
        this.gatherTimeoutMs = opts.gatherTimeoutMs ?? 200000;  // 单个 acquire 步骤（换区加宽+恢复 relocate 后需更久）
        this.craftTimeoutMs = opts.craftTimeoutMs ?? 8000;      // 单次 bot.craft 基础超时（+每 op 4s）
        // MC-M1-TASK-09：合成通道。'bot'（**默认**，mineflayer 原生；2×2 走它 =
        // `ad1cc67` 的口径，FARM-02 在那条链上 20/20 SUCCESS）/
        // 'self'（自己一步步点+每步等服务端判决）/ 'table'（自研 _tableCraft）/
        // 'grid2x2'（自研 `craftInGridConfirmed`，**TASK-11 起不再是生产默认**，
        //   离线自检 ⑪⑲ 仍全测它，留作继续打磨的入口）。诊断用可显式指定。
        this.craftChannel = opts.craftChannel ?? 'bot';
        this.stationSearchRadius = opts.stationSearchRadius ?? 24;
        this.resolver = opts.resolver ?? null;

        this.phase = 'plan';
        this.steps = [];
        this.stepIdx = 0;
        this.replans = 0;
        this._sub = '';                // 子状态（进度签名用）
        this._activeChild = null;      // 子任务签名桥接
        this._placedTablePos = null;   // 本任务放置的工作台（reclaim 依据）
        this._ignoredTables = new Set(); // 导航到不了的外部工作台，本次任务内不再尝试
        this._reclaimDone = false;
    }

    countMet(ctx) { return countItems(ctx.bot, [this.item]) >= this.count; }

    progressSignature(ctx) {
        let childSig = '';
        try { childSig = this._activeChild ? String(this._activeChild.progressSignature(ctx)) : ''; } catch { childSig = ''; }
        return `${this.phase}|s${this.stepIdx}|${this._sub}|i${countItems(ctx.bot, [this.item])}|${childSig}`;
    }

    getProgress(ctx) {
        return {
            phase: this.phase,
            step: `${this.stepIdx}/${this.steps.length}`,
            replans: this.replans,
            inv: countItems(ctx.bot, [this.item]),
        };
    }

    async onStuck(kind, ctx) {
        if (kind !== 'soft') return;
        stopNav(ctx.bot);
        try { ctx.bot.stopDigging(); } catch {}
    }

    async cleanup(ctx) {
        stopNav(ctx.bot);
        try {
            if (ctx.bot.currentWindow && String(ctx.bot.currentWindow.type).includes('crafting')) {
                ctx.bot.closeWindow(ctx.bot.currentWindow);
            }
        } catch { /* 无窗口时忽略 */ }
    }

    async tick(ctx) {
        const bot = ctx.bot;
        try { this.resolver ??= RecipeResolver.forBot(bot); } catch (e) {
            this._fail(FailReason.INTERNAL, { error: `resolver_init: ${String(e).slice(0, 120)}` });
            return;
        }
        if (this.countMet(ctx)) { this.phase = 'reclaim'; }
        switch (this.phase) {
            case 'plan': return this._tickPlan(ctx);
            case 'gather': return this._tickGather(ctx);
            case 'reclaim': return this._tickReclaim(ctx);
            default: this._fail(FailReason.INTERNAL, { error: `unknown phase ${this.phase}` });
        }
    }

    // ---------- plan ----------
    _tickPlan(ctx) {
        ctx.run.counters.recipeResolves++;
        const bot = ctx.bot;
        const tableNearby = !!this._findTable(ctx, this.stationSearchRadius);
        const plan = this.resolver.plan(this.item, this.count, inventorySnapshot(bot), [], { tableNearby });
        if (plan.error) {
            ctx.telemetry('craft_plan_fail', { item: this.item, count: this.count, planError: plan.error, step: plan.item ?? null });
            const map = {
                DEPENDENCY_CYCLE: FailReason.DEPENDENCY_CYCLE,
                DEPENDENCY_TOO_DEEP: FailReason.DEPENDENCY_TOO_DEEP,
                DEPENDENCY_UNSUPPORTED: FailReason.DEPENDENCY_UNSUPPORTED,
                RECIPE_NOT_FOUND: FailReason.RECIPE_NOT_FOUND,
            };
            this._fail(map[plan.error] ?? FailReason.CRAFT_FAILED, { item: this.item, planError: plan.error, step: plan.item ?? null });
            return;
        }
        this.steps = plan.steps;
        this.stepIdx = 0;
        ctx.telemetry('craft_plan', {
            item: this.item, count: this.count,
            steps: plan.steps.map((s) => s.kind === 'acquire'
                ? `Acquire(${s.resource}×${s.count}${s.sideQuest ? `+${s.sideQuest.resource}×${s.sideQuest.count}` : ''})`
                : s.kind === 'smelt'
                    ? `Smelt(${s.item}→${s.target})`
                    : `Craft(${s.item}→${s.target}${s.station ? ',table' : ''})`).join(' > '),
        });
        this.phase = 'gather';
    }

    _replanOrFail(ctx, why, detail = {}, failReason = FailReason.CRAFT_FAILED) {
        this.replans++;
        ctx.run.counters.replans++;
        ctx.telemetry('craft_replan', { item: this.item, n: this.replans, why, ...detail });
        if (this.replans > this.replanBudgetMax) {
            this._fail(failReason, { item: this.item, replans: this.replans, why, ...detail });
            return;
        }
        this.phase = 'plan';
    }

    // ---------- gather ----------
    async _tickGather(ctx) {
        if (this.stepIdx >= this.steps.length) { this.phase = 'reclaim'; return; }
        const step = this.steps[this.stepIdx];
        if (step.kind === 'acquire') {
            this._sub = `acquire:${step.resource}`;
            // MC-M1-TASK-06 bug 修复（smoke3 实证，TASK-02 起潜伏）：resolver 的 acquire.count
            // 是【增量】（缺口 = need - 已有），而 AcquireResourceTask.count 是【绝对判据】
            // （手里 ≥ count 即成功）。库存有零头时（如 2/3 圆石）子任务瞬间 SUCCESS 什么都不
            // 挖 → replan 永远报缺 1 → 死循环烧光预算。修法：子任务目标 = 计划时基数 + 增量，
            // 净增量与计划账严格一致（死亡清包后 base=0，自然回退为全量采集）。
            const base = countItems(ctx.bot, RESOURCES[step.resource].drops);
            const child = await runChild(ctx, `acquire:${step.resource}`, `Acquire(${step.resource} +${step.count})`,
                () => {
                    // MC-M1-TASK-06b：sideQuest 透传（规划层把 flint 并进 iron_ore 的地下窗口，
                    // step.sideQuest 由 recipe_resolver._frontloadAcquires 产出；无则 undefined）
                    const t = new AcquireResourceTask({
                        resource: step.resource, count: base + step.count, timeoutMs: this.gatherTimeoutMs,
                        sideQuest: step.sideQuest ?? null,
                    });
                    this._activeChild = t;
                    return t;
                }, { tickMs: 200 });
            this._activeChild = null;
            this._sub = '';
            if (child.status === 'SUCCESS') { this.stepIdx++; return; }
            // 守卫拒绝（预算/环/深度）不是「这步没做好」而是「上层已裁定此依赖不可再试」，
            // replan 解决不了——立即上抛，不白烧 replan 预算（dev5：预算锁死后空转 5 轮 replan）
            if (child.failReason === FailReason.DEPENDENCY_BUDGET
                || child.failReason === FailReason.DEPENDENCY_CYCLE
                || child.failReason === FailReason.DEPENDENCY_TOO_DEEP) {
                this._fail(FailReason.DEPENDENCY_FAILED, { step: step.resource, childReason: child.failReason, guarded: true });
                return;
            }
            this._replanOrFail(ctx, 'gather_failed', { step: step.resource, childReason: child.failReason }, FailReason.DEPENDENCY_FAILED);
            return;
        }
        // MC-M1-TASK-06：熔炼步骤（计划器的 smelt 变体）→ SmeltTask 子任务。
        // 失败语义与 acquire 同款：守卫类立即上抛，其余有界 replan（计划器会补料/补炉）。
        if (step.kind === 'smelt') {
            this._sub = `smelt:${step.item}`;
            const child = await runChild(ctx, `smelt:${step.item}`, `Smelt(${step.item} →${step.target})`,
                () => {
                    const t = new SmeltTask({ item: step.item, target: step.target, timeoutMs: Math.min(this.gatherTimeoutMs, 300000) });
                    this._activeChild = t;
                    return t;
                }, { tickMs: 200 });
            this._activeChild = null;
            this._sub = '';
            if (child.status === 'SUCCESS') { this.stepIdx++; return; }
            if (child.failReason === FailReason.DEPENDENCY_BUDGET
                || child.failReason === FailReason.DEPENDENCY_CYCLE
                || child.failReason === FailReason.DEPENDENCY_TOO_DEEP) {
                this._fail(FailReason.DEPENDENCY_FAILED, { step: `smelt:${step.item}`, childReason: child.failReason, guarded: true });
                return;
            }
            this._replanOrFail(ctx, 'smelt_failed', { step: step.item, childReason: child.failReason }, FailReason.SMELT_FAILED);
            return;
        }
        // craft 步骤
        this._replanCause = null;
        const res = await this._craftStep(ctx, step);
        if (res === 'ok') { this.stepIdx++; this._sub = ''; return; }
        if (res === 'replan') {
            // ── MC-M1-TASK-09-r4：给 `craft_replan` 补一个**显式 cause** ──
            // 旧口径下 `_craftStep` 的 4 条性质完全不同的返回路径**全部**塌成
            // `why:"craft_shortfall"`：工作台没了(:277) / 配不出配方(:293) /
            // 连 1 次 op 的料都不够(:301) / **合成了但服务端没给货**(:328)。
            // ⇒「replan 是因为缺物资」与「replan 是因为窗口操作失败」在遥测上**不可区分**，
            // 而本单的验收线恰恰是「craft_replan 只因物资」——没有 cause 就没法验。
            // 取值：station_unavailable / no_recipe / insufficient_ops / no_gain / unknown
            const cause = this._replanCause ?? 'unknown';
            this._replanOrFail(ctx, 'craft_shortfall', { step: step.item, cause, craftRetries: this._replanCraftRetries ?? 0 });
        }
        // 'fail'：_craftStep 内部已结构化失败
    }

    // ---------- craft 步骤执行 ----------
    async _craftStep(ctx, step) {
        const bot = ctx.bot;
        const reg = bot.registry;
        const variantsOf = this.resolver.recipeVariants(step.item);
        if (!variantsOf.length) { this._fail(FailReason.RECIPE_NOT_FOUND, { item: step.item }); return 'fail'; }
        let craftRetries = 0;
        let iter = 0;

        while (countItems(bot, [step.item]) < step.target && iter++ < 8) {
            // 每轮重算：木板改型会换 item；变体按当前真实库存选（recipesFor 自带库存校验，
            // 空数组 = 当前背包不够料）
            const variants = this.resolver.recipeVariants(step.item);
            const itemId = reg.itemsByName[step.item]?.id;
            if (itemId == null || !variants.length) { this._fail(FailReason.RECIPE_NOT_FOUND, { item: step.item }); return 'fail'; }
            const yieldPerCraft = variants[0].result.count;
            const needsTable = variants.some((v) => v.requiresTable);

            let recipes = bot.recipesFor(itemId, null, yieldPerCraft, null);
            let tableBlock = null;
            if (!recipes.length && needsTable) {
                tableBlock = await this._ensureStation(ctx);
                if (!tableBlock) { this._replanCause = 'station_unavailable'; return 'replan'; } // 工作台没了/放不出 → 重新规划
                recipes = bot.recipesFor(itemId, null, yieldPerCraft, tableBlock);
            }
            // 木板改型（木板身份流体）：计划钉的木板类型与实际砍到的树种不符 →
            // 按背包里的原木改型，target 折算掉旧型已有量（dev1 教训：不改型 =
            // 永远合不出来的死结，replan 预算被白白烧光）
            if (!recipes.length && step.item.endsWith('_planks')) {
                const logName = logFamilyFor(bot.registry).find((l) => countItems(bot, [l]) > 0);
                const concrete = logName ? logName.replace('_log', '') + '_planks' : null;
                if (concrete && concrete !== step.item && reg.itemsByName[concrete]) {
                    ctx.telemetry('craft_planks_retype', { from: step.item, to: concrete });
                    step.target = Math.max(step.target - countItems(bot, [step.item]), yieldPerCraft);
                    step.item = concrete;
                    continue;
                }
            }
            if (!recipes.length) { this._replanCause = 'no_recipe'; return 'replan'; } // 缺料 → 重新规划（有界）
            const recipe = recipes[0];
            const remaining = step.target - countItems(bot, [step.item]);
            // 每次 bot.craft 只做 1 个 op：mineflayer 合成是客户端预测式（updateSlot 伪造结果
            // + putAway），多 op 连发时服务器会拒绝后续 op 而客户端仍报成功（dev2 实测：
            // 3 次 craft_ok 只有 1 把真镐）。单 op + 每次新鲜窗口（craft() 结束即关窗重开）
            // + 下面的增量验证，才拿得到服务器真值。
            const ops = 1;
            if (this._maxOpsForRecipe(bot, recipe) < 1 || remaining < 1) { this._replanCause = 'insufficient_ops'; return 'replan'; }

            ctx.run.counters.craftAttempts++;
            this._sub = `crafting:${step.item}`;
            const before = countItems(bot, [step.item]);
            const ok = await this._doCraft(ctx, recipe, ops, tableBlock);
            await sleep(350); // 服务器同步窗口：客户端预测的假结果会被纠正回来
            const gained = countItems(bot, [step.item]) - before;
            this._sub = '';
            if (!ok || gained < ops) {
                ctx.run.counters.craftFailures++;
                craftRetries++;
                ctx.telemetry(ok ? 'craft_unverified' : 'craft_fail', {
                    item: step.item, craftRetries, gained, error: ok ? null : 'craft_promise_rejected',
                });
                if (craftRetries > this.craftRetries) {
                    this._fail(FailReason.CRAFT_FAILED, { item: step.item, craftRetries });
                    return 'fail';
                }
                await sleep(600);
            } else {
                // r4：补 `viaTable` / `grid`。旧口径只有 {item, gained, inv}，
                // **无法从遥测判定某次成功走的是 2×2 还是 3×3**（只能靠 item 猜）——
                // 而"2×2 通道是否修好"正是本单要验的东西。
                ctx.telemetry('craft_ok', {
                    item: step.item, gained, inv: countItems(bot, [step.item]),
                    viaTable: !!tableBlock, grid: tableBlock ? 3 : 2,
                });
            }
            await sleep(250);
        }
        await sleep(400); // 终判前再结算一次，防幽灵库存通过验收
        if (countItems(bot, [step.item]) >= step.target) return 'ok';
        // 循环跑完仍没到量：合成**执行过**但服务端没给货 ⇒ 这是窗口层的失败形态，
        // 与上面三条"真的缺料/缺台"性质不同，必须单独归类（否则验收线
        // 「craft_replan 只因物资」无法判定）。
        this._replanCause = 'no_gain';
        this._replanCraftRetries = craftRetries;
        return 'replan';
    }

    /**
     * 把 recipe 的网格摊平成 `[{x, y, id}]`；**放不进 gridW×gridH 就返回 null**。
     * 返回 null 是有意义的信号（"这个配方需要工作台"），不能退化成"少放几个格子"——
     * 少放会被服务端判成配方不匹配，结果格恒空，读数看起来像"合成失败"，
     * 而真因是"这东西根本不该走 2×2"。
     */
    _gridCells(recipe, gridW, gridH) {
        const cells = [];
        if (recipe.inShape) {
            if (recipe.inShape.length > gridH) return null;
            for (let y = 0; y < recipe.inShape.length; y++) {
                if (recipe.inShape[y].length > gridW) return null;
                for (let x = 0; x < recipe.inShape[y].length; x++) {
                    const ing = recipe.inShape[y][x];
                    const id = ing && typeof ing === 'object' ? ing.id : ing;
                    if (id != null && id !== -1) cells.push({ x, y, id });
                }
            }
            return cells;
        }
        if (recipe.ingredients) {
            if (recipe.ingredients.length > gridW * gridH) return null;
            recipe.ingredients.forEach((ing, i) => {
                const id = ing && typeof ing === 'object' ? ing.id : ing;
                if (id != null && id !== -1) cells.push({ x: i % gridW, y: Math.floor(i / gridW), id });
            });
            return cells;
        }
        return null;
    }

    _maxOpsForRecipe(bot, recipe) {
        let ops = Infinity;
        for (const d of recipe.delta) {
            if (d.count >= 0) continue;
            const name = bot.registry.items[d.id]?.name;
            const have = name ? bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0) : 0;
            ops = Math.min(ops, Math.floor(have / -d.count));
        }
        return ops === Infinity ? 0 : ops;
    }

    async _doCraft(ctx, recipe, ops, tableBlock) {
        const bot = ctx.bot;
        const timeoutMs = this.craftTimeoutMs + ops * 4000;
        // MC-M1-TASK-09：合成通道的选择。三条通道都改成"每一步等服务端确认"，
        // 但确认强度不同，按可靠性排序：
        //   1. `self`（默认，3×3 工作台）：自己一步步点，每步等**服务端对那一次点击的判决**。
        //      **不再调用 bot.craft** —— 它收尾的 grabResult() 会先 window.updateSlot(0, …)
        //      凭空造出产物槽再点走，那一行就是 1.16.1 上「不抛错、材料没少、没拿到成品」
        //      的病根（ROUND3-A §3.2.4，本单 §3 复现数据）。实测 29/30（三个配方各 30）。
        //   2. `grid2x2`（**r4 起**）：2×2 背包通道（window 0）改走 window_ops 的自研
        //      `craftInGridConfirmed`，**不再调用 bot.craft**。
        //      ── 更正本段上一轮的结论 ──
        //      上一轮（r2/r3）这里写的是"2×2 保留 bot.craft，本单试过自研直发通道 0/30
        //      （`self_craft_click_rejected {slot:1, mouseButton:1}`），差异在 window 0，
        //      按 §4.8 不扩大范围"。**那条"差异在 window 0"的判断是错的**：
        //      `_selfCraft` 用的 `clickRawConfirmed` 发包时 `item` 填 `win.slots[slot]`
        //      （window_ops.js:428-449），而 1.16.1 服务端 ack 判据是
        //      `ItemStack.matches(包里的光标, 点击后服务端光标)`
        //      （`ServerGamePacketListenerImpl.java:1180`）——
        //      **右键往网格格放 1 个时那一格通常是空的**，于是上报"光标是空的"，
        //      与服务端光标不符 ⇒ `accepted=false`。
        //      这个偏差**与窗口是不是 window 0 无关**，工作台上同样存在；3×3 之所以 29/30
        //      是因为它走的是 `_tableCraft`/别的时序，不是因为原语对。
        //      本单把"点击后服务端光标"由调用方按点击语义**显式预测**出来
        //      （拿起=那格的东西 / 放1个=手上−1 / 放回=空 / QUICK_MOVE=不变），
        //      并按**服务端 window_items** 判结果格与取件。手册 §5「裁决里对代码行为的描述
        //      不是证据，代码才是」——这条正是被描述性文字带偏的实例。
        //   3. `table`：自研 _tableCraft（3×3 工作台），1.16.1 与 1.17+ 都能用，实测 30/30。
        //
        // ── MC-M1-TASK-11（FARM-04 0/20 回归修复）：**默认通道已回退到 `ad1cc67`** ──
        //   `ad1cc67` 的分派口径是：有工作台 → `_tableCraft`；**没有工作台（2×2）→ `bot.craft`**。
        //   本单照抄那一条，理由与证据见下面 `channel === 'grid2x2'` 那段注释。
        //   `craftChannel='grid2x2'` 仍可显式打开自研原语（离线自检 ⑪⑲ 全测它）。
        const channel = this.craftChannel ?? 'bot';
        const useSelf = channel === 'self' && !!tableBlock;
        this._closeCraftWindow(bot);
        try {
            if (channel !== 'bot' && tableBlock && channel !== 'inv2x2') {
                const r = await withTimeout(this._tableCraft(ctx, tableBlock, recipe), 30000, 'table_craft_timeout');
                return !!r;
            }
            if (useSelf) {
                const itemName = bot.registry.items[recipe.result.id]?.name ?? null;
                const before = countItemsWindowAware(bot, itemName);
                const r = await withTimeout(
                    this._selfCraft(ctx, tableBlock, recipe, { itemName }),
                    this.craftTimeoutMs + ops * 6000,
                    'self_craft_timeout',
                );
                // TASK-09 判据：**窗口感知**的背包增量。窗口开着时物品落在窗口的镜像区，
                // `countItems(bot,…)` 读 0（06c「背包同步慢」的真正那半边），
                // 所以这里先信窗口内的服务端真值，再补一次 bot.inventory 的有界轮询。
                let got = r.gained ?? 0;
                if (got < ops) {
                    const dl = Date.now() + 1500;
                    while (got < ops && Date.now() < dl) { await sleep(120); got = countItemsWindowAware(bot, itemName) - before; }
                }
                if (!r.ok || got < ops) {
                    ctx.telemetry('craft_no_gain', { item: itemName ?? null, gained: got, expected: ops, viaTable: !!tableBlock, reason: r.reason ?? null });
                    this._closeCraftWindow(bot);
                    return false;
                }
                return true;
            }
            // ═══ MC-M1-TASK-09-r4：2×2 背包通道改走 window_ops 的自研原语 ═══
            // 旧通道（`bot.craft(recipe, ops, null)`）在 1.16.1 上有两处结构性问题：
            //   ① 放料时 `item` 字段填的是**被点那一格**（`inventory.js:571/626`），而服务端
            //      ack 判据是 `ItemStack.matches(包里的光标, 点击后服务端光标)`
            //      （`ServerGamePacketListenerImpl.java:1180`）⇒ 右键往 2×2 格里放 1 个时
            //      填错光标 ⇒ `accepted=false` ⇒ 这就是 06c 基线里
            //      `Server rejected transaction for clicking on slot 0, on window with id 0`
            //      那 12 条 `craft_error` 的来源（全部集中在 trial_06）。
            //   ② `grabResult()` 先 `window.updateSlot(0, new Item(result))` **凭空造出产物槽**
            //      再点走（`craft.js:136-138`）——"不抛错、材料没少、成品下落不明"的病根。
            // 新原语 `craftInGridConfirmed`（window_ops.js）：
            //   · 每一步发包时 `item` 填**点击后服务端光标应有的内容**（拿起=那格的东西；
            //     放 1 个=手上那摞−1；放回=空），并且**一个字节都不主动写窗口模型**；
            //   · 每一步等**服务端 transaction** 判决，被拒/无回执立刻中止并如实上报；
            //   · 结果格按**服务端 window_items** 读（不伪造），取产物用 shift 点槽 0 ——
            //     1.16.1 `InventoryMenu.java:120-125` 对 index==0 是
            //     `moveItemStackTo(stack, 9, 45, true)`，产物**直接进背包、全程不碰光标**
            //     （本项目里光标模型是 mineflayer 猜的，见 window_ops.js 的 readCursorTruth）。
            // ⚠ **绝不** shift 点网格格 1..4：`InventoryMenu.java:126-129` 会把材料倒回
            //   玩家背包、静默清空已摆好的配方。函数内部只 shift 点 resultSlot。
            // 2×2 能做的配方只有三个（1.16.1 `RecipeProvider.java` 一手证据）：
            //   原木→木板(1×1) / 木板→木棍(2×1) / 木板→工作台(2×2)；
            //   熔炉/铁镐/箱子都是 3×3，**必须**有工作台。超出 2×2 就交回上层 replan。
            const itemName = bot.registry.items[recipe.result.id]?.name ?? null;
            // ═══ MC-M1-TASK-11（FARM-04 0/20 回归）：2×2 **生产通道回退到 `bot.craft`** ═══
            //
            // 【为什么回退】派单原话："1 小时修不好就把生产路径验证逻辑回退到 ad1cc67，
            //   主干先恢复能用。" 本单的自研原语 `craftInGridConfirmed` 修了两个真病根
            //   （脏网格级联 + 结果格不等单格 set_slot，离线 196/196、变异 23/23），
            //   但**真服 M4B4 仍 0/5**（`T11C_M4B4_FIX`）：失败从"读不到产物"前移/后移到
            //   `pickup_rejected` / `take_put_rejected` / `putback_rejected`
            //   —— 症状换了、**整链成功率没变** ⇒ 按"整链优先"（手册 §4.9），
            //   **先让主干能用**，自研原语保留在 `craftChannel='grid2x2'` 后面继续磨。
            //
            // 【口径依据】`ad1cc67` 的 2×2 走的是 mineflayer 原生 `bot.craft`
            //   （`git show ad1cc67:…` 第 392 行），**FARM-02 在它上面 20/20 SUCCESS**。
            //   那条链是当前唯一有实跑证据的 2×2 通道。
            //
            // ⚠ 回退**只动 2×2**。3×3 工作台仍走 `_tableCraft`（29/30、30/30 有据），
            //   熔炼走 smelt_task，两条都不在本次回退范围内。
            // ⚠ 原语**不是删掉**：`craftChannel='grid2x2'` 仍可显式打开（离线自检 ⑪⑲ 全测它）。
            if (channel === 'grid2x2' && !tableBlock) {
                const cells = this._gridCells(recipe, 2, 2);
                if (!cells) {
                    ctx.telemetry('craft_needs_table', { item: itemName, grid: 2, reason: 'recipe_too_large' });
                    this._closeCraftWindow(bot);
                    return false;
                }
                const before = countItemsWindowAware(bot, itemName);
                let got = 0;
                try {
                    const r = await withTimeout(
                        craftInGridConfirmed(bot, bot.inventory, { cells, gridW: 2, gridH: 2, resultSlot: 0, expectName: itemName, timeoutMs: 1500 }),
                        this.craftTimeoutMs + ops * 6000,
                        'grid2x2_craft_timeout',
                    );
                    got = r.gained ?? 0;
                    if (got < ops) {
                        const dl = Date.now() + 1500;
                        while (got < ops && Date.now() < dl) { await sleep(120); got = countItemsWindowAware(bot, itemName) - before; }
                    }
                    if (!r.ok || got < ops) {
                        ctx.telemetry('craft_no_gain', {
                            item: itemName, gained: got, expected: ops, viaTable: false,
                            reason: r.reason ?? null, grid: 2,
                            // r4：光标三字段。**这是本单实跑踩到的那个坑的判别手**：
                            // 1.16.1 上 mineflayer 丢掉服务端光标包 ⇒ win.selectedItem 恒 null，
                            // 而自研直发包又不经过 mineflayer 的 confirmTransaction.onAccepted
                            // ⇒ 靠 selectedItem 判断光标必然误判（cursor_lost_after_pickup）
                            // ⇒ 下一轮那次"拿起"实际变成交换 ⇒ pickup_rejected。
                            cursor: r.cursor ?? null, cursorSource: r.cursorSource ?? null, cursorMismatches: r.cursorMismatches ?? null,
                            slotCount: windowSlotCount(bot, bot.inventory),
                            playerRange: (() => { const g = playerInvRange(bot, bot.inventory); return g ? `${g.start}-${g.end}#${g.via}` : null; })(),
                        });
                        return false;
                    }
                    return true;
                } catch (e) {
                    ctx.telemetry('craft_error', { error: String(e && e.message ? e.message : e).slice(0, 140), viaTable: false, grid: 2 });
                    this._closeCraftWindow(bot);
                    return false;
                }
            }
            const before = itemName ? countItemsWindowAware(bot, itemName) : 0;
            await withTimeout(bot.craft(recipe, ops, tableBlock), timeoutMs, 'craft_timeout');
            if (!itemName) return true;
            // ① 有界轮询等背包增量（服务端 set_slot / 拾取同步都可能慢半拍；窗口感知）
            const got = await this._waitCraftGain(bot, itemName, before, ops);
            if (got >= ops) return true;
            ctx.telemetry('craft_no_gain', { item: itemName, gained: got, expected: ops, viaTable: !!tableBlock });
            // ② 没到手：关窗（下次用新窗口），并把窗口同步问题写进遥测而不是让它静默过去
            this._closeCraftWindow(bot);
            return false;
        } catch (e) {
            ctx.telemetry('craft_error', { error: String(e && e.message ? e.message : e).slice(0, 140), viaTable: !!tableBlock });
            // 超时/抛错弃单后关掉残留合成窗口，防下次 craft 复用死窗口
            this._closeCraftWindow(bot);
            return false;
        }
    }

    /**
     * 自己一步步点的合成（2×2 背包与 3×3 工作台共用一条逻辑，差别只在网格尺寸）。
     *
     * 与 `bot.craft` 的**唯一**本质差别，也是本单的全部意义：
     *   备料 → 每步等服务端判决；把余料放回 → 等判决；
     *   取产物 → **先读服务端 set_slot 确认过的结果格**，再 `takeFromSlotConfirmed` 逐步确认取件。
     * 全程**不写窗口模型**（不调 window.updateSlot），模型只被服务端回包驱动。
     */
    async _selfCraft(ctx, tableBlock, recipe, { itemName }) {
        const bot = ctx.bot;
        const viaTable = !!tableBlock;
        const w = tableBlock ? await this._openCraftingWindow(bot, tableBlock) : bot.inventory;
        if (!w) { ctx.telemetry('self_craft_no_window', { viaTable }); return { ok: false, reason: 'no_window' }; }
        const gridW = viaTable ? 3 : 2, gridH = viaTable ? 3 : 2;
        const cellSlot = (x, y) => 1 + x + gridW * y;

        try {
            const click = async (slot, mouseButton, mode) => {
                const r = await clickRawConfirmed(bot, w, { slot, mouseButton, mode, timeoutMs: 1200 });
                if (!r.ok) {
                    ctx.telemetry('self_craft_click_rejected', { slot, mouseButton, via: r.via, action: r.action ?? null, maxAction: r.maxAction ?? null, rejected: !!r.rejected, unconfirmed: !!r.unconfirmed });
                    throw new WindowClickRejected(r);
                }
                return r;
            };
            // 备料格
            const cells = [];
            if (recipe.inShape) {
                for (let y = 0; y < recipe.inShape.length && y < gridH; y++) {
                    for (let x = 0; x < recipe.inShape[y].length && x < gridW; x++) {
                        const ing = recipe.inShape[y][x];
                        const id = ing && typeof ing === 'object' ? ing.id : ing;
                        if (id != null && id !== -1) cells.push({ x, y, id });
                    }
                }
            } else if (recipe.ingredients) {
                recipe.ingredients.forEach((ing, i) => {
                    const id = ing && typeof ing === 'object' ? ing.id : ing;
                    if (id != null && id !== -1) cells.push({ x: i % gridW, y: Math.floor(i / gridW), id });
                });
            }
            const findSrc = (typeId) => w.slots.findIndex((s, i) => s && s.type === typeId && i >= w.inventoryStart);
            for (const { x, y, id } of cells) {
                if (!w.selectedItem || w.selectedItem.type !== id) {
                    const src = findSrc(id);
                    if (src < 0) { ctx.telemetry('self_craft_missing_ingredient', { id, viaTable }); return { ok: false, reason: 'missing_ingredient' }; }
                    await click(src, 0, 0);
                }
                await click(cellSlot(x, y), 1, 0);
            }
            // 手上余料放回
            if (w.selectedItem) {
                const cur = w.selectedItem;
                let dest = w.slots.findIndex((s, si) => si >= w.inventoryStart && s && s.type === cur.type && s.count < s.stackSize);
                if (dest < 0) dest = w.slots.findIndex((s, si) => si >= w.inventoryStart && !s);
                if (dest >= 0) await click(dest, 0, 0);
            }
            await sleep(120);
            // 取产物：结果格是**服务端确认过的**（slot 0），不伪造
            if (!w.slots[0]) {
                ctx.telemetry('self_craft_no_result', { viaTable, grid: w.slots.slice(1, 1 + gridW * gridH).map((s) => s?.name ?? null).join(',') });
                return { ok: false, reason: 'no_result' };
            }
            const got = await takeFromSlotConfirmed(bot, w, 0, { timeoutMs: 1500, expectName: itemName });
            if (!got.ok) {
                ctx.telemetry('self_craft_take_fail', { reason: got.reason, viaTable, got: got.got ?? null, want: itemName });
                return { ok: false, reason: got.reason };
            }
            return { ok: true, took: got.took, gained: got.gained, dest: got.dest };
        } catch (e) {
            if (e instanceof WindowClickRejected) return { ok: false, reason: 'click_rejected' };
            throw e;
        } finally {
            if (viaTable) { try { await closeWindowConfirmed(bot, w); } catch { /* 忽略 */ } }
        }
    }

    /** 打开工作台窗口并等首个 window_items 同步完成 */
    async _openCraftingWindow(bot, tableBlock) {
        const w0 = bot.currentWindow;
        if (w0 && String(w0.type).includes('crafting')) { try { await closeWindowConfirmed(bot, w0); } catch { /* 忽略 */ } }
        bot.activateBlock(tableBlock);
        const w = await new Promise((res) => {
            const h = (win) => { bot.removeListener('windowOpen', h); res(win); };
            bot.on('windowOpen', h);
            setTimeout(() => { bot.removeListener('windowOpen', h); res(null); }, 5000);
        });
        if (!w || !String(w.type).includes('crafting')) return null;
        await sleep(250);
        return w;
    }

    /**
     * 关掉当前**合成类**窗口，并等服务端真的把窗口关掉再返回。
     * 为什么要等服务端：1.16.1 上 `bot.closeWindow()` 只是**单方面**把
     * `bot.currentWindow` 置空；服务端可能还挂着上一扇窗，下一次 `activateBlock`
     * 就会和它抢同一个窗口 id。实测症状：紧接上一条通道之后的**第一次**点击必被拒
     * （微基准里每个 cell 的 i=0，`doCraft_false`）。
     */
    async _closeCraftWindow(bot) {
        const w = bot.currentWindow;
        if (w && String(w.type).includes('crafting')) {
            try { await closeWindowConfirmed(bot, w); } catch { /* 忽略 */ }
            // 服务端 close_window 到了之后再给一拍，让窗口 id 真正释放
            await sleep(120);
        }
    }

    /** 有界轮询等背包增量：手册 §3「按背包增量验证」。返回实际增到的数量。 */
    async _waitCraftGain(bot, itemName, before, expect, timeoutMs = 1800) {
        const deadline = Date.now() + timeoutMs;
        let got = countItemsWindowAware(bot, itemName) - before;
        while (got < expect && Date.now() < deadline) {
            await sleep(120);
            got = countItemsWindowAware(bot, itemName) - before;
        }
        return got;
    }

    /**
     * 自研 3x3 工作台合成（单次 op）。
     * 与 mineflayer craft 的本质差别：stateId 按【窗口 ID】精确跟踪（bot.craft 用全局
     * 单变量，会被背包 offhand set_slot 污染 → Paper 丢点击），且**每次点击都等服务端
     * 判决之后**再动本地模型（`clickRawConfirmed`）。
     *
     * MC-M1-TASK-09：**这个方法现在在 1.16.1 上也能用了**。此前它被 `supportsWindowStateId`
     * gate 在 1.17+，理由写的是「1.16.x 协议无 stateId，直发包不成立」，实测报
     * `SizeOf error … reading 'present'`。本单离线核实（window_ops_selftest ①②）后**订正**：
     *   - `slot` 类型的 `{present,…}` 容器在 1.16~1.18.2 **逐字相同**，`prismarine-item` 的
     *     `toNotch()` 对所有版本都已经是这个形状 ⇒ **Slot 形状从来不是问题**；
     *   - 真正随版本变的是**包封**：1.16.1 要 `{windowId,slot,mouseButton,action,mode,item}`，
     *     1.17.1+ 要 `{windowId,stateId,slot,mouseButton,mode,changedSlots,cursorItem}`。
     *     旧代码只写后一种，protodef 按字段名取值时 `action`/`item` 都是 undefined，
     *     报错恰好落在最后读的匿名 `slot` 容器上（`e.field` 也是 undefined，所以连字段名都没打）——
     *     **症状长得像 Slot 形状问题，病根是少写了两个字段。**
     * 现在由 `windowClickPacket` 按版本选信封，`supportsWindowStateId` 不再 gate 它。
     */
    async _tableCraft(ctx, tableBlock, recipe) {
        const bot = ctx.bot;
        const w0 = bot.currentWindow;
        if (w0 && String(w0.type).includes('crafting')) { try { await closeWindowConfirmed(bot, w0); } catch { /* 忽略 */ } }
        bot.activateBlock(tableBlock);
        const w = await new Promise((res) => {
            const h = (win) => { bot.removeListener('windowOpen', h); res(win); };
            bot.on('windowOpen', h);
            setTimeout(() => { bot.removeListener('windowOpen', h); res(null); }, 5000);
        });
        if (!w || !String(w.type).includes('crafting')) {
            ctx.telemetry('table_craft_no_window', { type: w?.type ?? null });
            return false;
        }
        await sleep(250); // 等首个 window_items（初始同步）
        try {
            // 每一步都等服务端判决；被拒/无回执就如实中止，绝不接着往下点
            const click = async (slot, mouseButton, mode) => {
                const r = await clickRawConfirmed(bot, w, { slot, mouseButton, mode, timeoutMs: 1200 });
                if (!r.ok) {
                    ctx.telemetry('table_craft_click_rejected', {
                        slot, mouseButton, via: r.via, action: r.action ?? null, maxAction: r.maxAction ?? null,
                        rejected: !!r.rejected, unconfirmed: !!r.unconfirmed,
                    });
                    throw new WindowClickRejected(r);
                }
                return r;
            };
            const findSrc = (typeId) => w.slots.findIndex((s, i) => s && s.type === typeId && i >= w.inventoryStart);
            // 备料：inShape 逐格放（右键放一个）；源不在手上先左键整组拿起
            const cells = [];
            if (recipe.inShape) {
                for (let y = 0; y < recipe.inShape.length; y++) {
                    for (let x = 0; x < recipe.inShape[y].length; x++) {
                        const ing = recipe.inShape[y][x];
                        const id = ing && typeof ing === 'object' ? ing.id : ing;
                        if (id != null && id !== -1) cells.push({ x, y, id });
                    }
                }
            } else if (recipe.ingredients) {
                recipe.ingredients.forEach((ing, i) => {
                    const id = ing && typeof ing === 'object' ? ing.id : ing;
                    if (id != null && id !== -1) cells.push({ x: i % 3, y: Math.floor(i / 3), id });
                });
            }
            for (const { x, y, id } of cells) {
                if (!w.selectedItem || w.selectedItem.type !== id) {
                    const src = findSrc(id);
                    if (src < 0) { ctx.telemetry('table_craft_missing_ingredient', { id }); return false; }
                    await click(src, 0, 0);
                }
                await click(1 + x + 3 * y, 1, 0);
            }
            // 手上余料放回（优先同型可堆叠槽，其次空槽；没地方就留着不 swap——swap 会拿进别的物品）
            if (w.selectedItem) {
                const cur = w.selectedItem;
                let dest = w.slots.findIndex((s, si) => si >= w.inventoryStart && s && s.type === cur.type && s.count < s.stackSize);
                if (dest < 0) dest = w.slots.findIndex((s, si) => si >= w.inventoryStart && !s);
                if (dest >= 0) await click(dest, 0, 0);
            }
            await sleep(150);
            // 抓结果：这里**不再伪造产物槽**（旧写法是 window.updateSlot(0, new Item(result))，
            // 那正是 ROUND3-A 静默丢件的病根）。改为读服务端 set_slot 确认过的结果格，
            // 再走 takeFromSlotConfirmed 的逐步确认取件。
            if (!w.slots[0]) { ctx.telemetry('table_craft_no_result', { grid: w.slots.slice(1, 10).map((s) => s?.name ?? null).join(',') }); return false; }
            const got = await takeFromSlotConfirmed(bot, w, 0, {
                timeoutMs: 1500, expectName: bot.registry.items[recipe.result.id]?.name ?? null,
            });
            if (!got.ok) {
                // r4：补回 `held`。旧写法把 window_ops 返回的 `held` 字段**丢掉了**，
                // 事件里只剩 `got:null,want:null` —— 而 `held` 恰恰是唯一能解释
                // "光标上到底是什么"（06d 抓到的真凶就是 held="furnacex1"）的那个字段。
                // 丢字段的那一行让 06c/06d 三次诊断都只能停在"不知道"上。
                ctx.telemetry('table_craft_take_fail', { reason: got.reason, got: got.got ?? null, want: got.want ?? null, held: got.held ?? null, dest: got.dest ?? null });
                return false;
            }
            return true;
        } catch (e) {
            if (!(e instanceof WindowClickRejected)) throw e;
            return false;
        } finally {
            try { await closeWindowConfirmed(bot, w); } catch { /* 忽略 */ }
        }
    }

    // ---------- 工作台生命周期（任务书 §8） ----------
    _findTable(ctx, radius) {
        const bot = ctx.bot;
        const id = bot.registry.blocksByName['crafting_table']?.id;
        if (id == null) return null;
        const found = bot.findBlocks({ matching: [id], maxDistance: radius, count: 8 })
            .filter((p) => !this._ignoredTables.has(posKey(p)))
            .sort((a, b) => bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b));
        return found.length ? bot.blockAt(found[0]) : null;
    }

    /** 返回可达的工作台 Block；拿不到则自己放一个；都失败返回 null（不抛） */
    async _ensureStation(ctx) {
        const bot = ctx.bot;
        let t = this._findTable(ctx, 4.0);
        if (!t) {
            t = this._findTable(ctx, this.stationSearchRadius);
            if (t) {
                ctx.telemetry('station_nav', { pos: [t.position.x, t.position.y, t.position.z] });
                const ok = await navTo(ctx, new pf.goals.GoalNear(t.position.x, t.position.y, t.position.z, 2),
                    { timeoutMs: 25000, label: 'to_table' });
                const near = this._findTable(ctx, 4.0);
                if (!ok || !near) {
                    // 到不了的外部台子不再试；包里有台子就自己放
                    this._ignoredTables.add(posKey(t.position));
                    return this._placeOwnTable(ctx);
                }
                return near;
            }
            return this._placeOwnTable(ctx);
        }
        return t;
    }

    async _placeOwnTable(ctx) {
        const bot = ctx.bot;
        // MC-M1-TASK-06c：整段换成共享放置原语 place.js（旧口径的扫描+8s 等 blockUpdate 已删）。
        // 旧 bug 留档：① 手持脱耦 → placeBlock 连烧 10 次 "must be holding an item" 判死任务；
        // ② 井底（垂直下挖后）挑中的参照面被井壁挡住 / 目标格其实是井壁实心格 → 服务端静默拒收，
        //    每次空等 5s，连烧 10 次 place_exhausted（06c §1：铁链每局约 10 次 place_fail 的来源）。
        // 修法见 place.js：小节可信 + 参照面从眼睛可见 + 够得着 + 不压实体，井底再挖一格壁龛，
        // 放完用 ≤1s 短轮询 blockAt 确认。失败仍不判死任务，交还上层 replan（行为不变）。
        const r = await placeItem(bot, 'crafting_table', {
            telemetry: ctx.telemetry, ctx, GoalNear: pf.goals.GoalNear, label: 'table',
            maxTries: 10, rounds: 3, confirmMs: 1000,
        });
        if (r.ok) {
            this._placedTablePos = new Vec3(r.dest.x, r.dest.y, r.dest.z);
            ctx.run.counters.tablePlacements++;
            return r.block;
        }
        if (r.reason === 'hold_fail') {
            ctx.telemetry('station_hold_fail', { item: this.item, invTable: countItems(bot, ['crafting_table']) });
            return null;
        }
        // 放置耗尽：不再 _fail(PLACEMENT_FAILED) 判死任务——交还 replan 自愈
        //（replan 预算有界；下一轮 _ensureStation 会重找台位/重放）
        ctx.run.counters.tablePlacementFailures++;
        return null;
    }

    // 手持校验 + 一次重试（SEED-02 移交 bug 的核心补丁）：equip 的窗口点击可能被静默
    // 丢弃（解析成功 ≠ 手里真的有台），placeBlock 前必须确认 heldItem 就是工作台。
    async _ensureTableInHand(ctx) {
        const bot = ctx.bot;
        for (let i = 0; i < 2; i++) {
            if (bot.heldItem?.name === 'crafting_table') return true;
            const item = bot.inventory.items().find((it) => it.name === 'crafting_table');
            if (!item) return false;
            try { await withTimeout(bot.equip(item, 'hand'), 5000, 'equip_timeout'); } catch { /* 重试一次 */ }
            await sleep(300);
        }
        return bot.heldItem?.name === 'crafting_table';
    }

    // ---------- reclaim（回收自己放的工作台，材料循环；best-effort） ----------
    async _tickReclaim(ctx) {
        const bot = ctx.bot;
        const inv = countItems(bot, [this.item]);
        const pos = this._placedTablePos;
        if (!pos || !this.reclaimTable || this._reclaimDone) {
            this._succeed({ item: this.item, count: inv, tablePlaced: !!this._placedTablePos });
            return;
        }
        this._reclaimDone = true;
        const block = bot.blockAt(pos);
        if (!block || block.name !== 'crafting_table') { this._succeed({ item: this.item, count: inv }); return; }
        try {
            if (bot.entity.position.distanceTo(pos) > 3.5) {
                const ok = await navTo(ctx, new pf.goals.GoalNear(pos.x, pos.y, pos.z, 2), { timeoutMs: 15000, label: 'reclaim_nav' });
                if (!ok) { this._succeed({ item: this.item, count: inv, reclaim: 'nav_fail' }); return; }
            }
            const before = countItems(bot, ['crafting_table']);
            await withTimeout(bot.dig(bot.blockAt(pos)), 8000, 'dig_timeout');
            // 挖完等拾取：掉落物不一定会自动碰到身上，没进包就主动走过去（dev2：400ms 干等
            // 拿不到，台子掉地上没捡回来）
            for (let w = 0; w < 5 && countItems(bot, ['crafting_table']) <= before; w++) {
                await sleep(300);
                if (w === 1) {
                    const drop = Object.values(bot.entities)
                        .find((e) => e.name === 'item' && e.position.distanceTo(bot.entity.position) < 3.5);
                    if (drop) {
                        const p = bot.pathfinder.goto(new pf.goals.GoalFollow(drop, 0.8));
                        p.catch(() => {});
                        await Promise.race([p, sleep(2500)]);
                        try { bot.pathfinder.stop(); } catch {}
                    }
                }
            }
            const after = countItems(bot, ['crafting_table']);
            ctx.telemetry(after > before ? 'table_reclaimed' : 'table_reclaim_fail', { pos: [pos.x, pos.y, pos.z] });
        } catch (e) {
            ctx.telemetry('table_reclaim_fail', { error: String(e && e.message ? e.message : e).slice(0, 100) });
        }
        this._succeed({ item: this.item, count: countItems(bot, [this.item]) });
    }
}
