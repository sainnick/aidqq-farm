// route_waypoints_selftest.mjs — MC-M1-TASK-11 路点版的**离线**自检
//
// 纪律（手册 §5，本项目已反复踩）：
//   · **"没找到"必须判失败**，不等价成"不需要处理"——所以每条"读不到"的用例都断言 reason 码。
//   · **判据的输入样本必须来自现场**——阳性对照直接读**真的 route v2 文件**
//     （bench/route/4926685115947721762.v2.fullroute.json，C 线产出、设计会话逐个回读存档核对过），
//     不拿"自己编的测试数据"当证据。
//   · 变异测试自己会骗人（G 线：`>=1` 改 `>=2` 变异后 0 条红）——每条用例都成对写
//     "该拒的必须拒"+"该放的必须放"。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
    loadRouteFile, readExact, legWaypoints, planDigTargets,
    standCandidates, dist3,
} from './route_waypoints.js';

// 阳性对照直接读**真的** route v2 文件（C 线产出、设计会话逐个回读存档核对过），
// 不拿"自己编的测试数据"当证据（手册 §5）。
// 路径：mindcraft/src/agent/tasks/exec → 上 5 级到工作区根 → bench/route/
const HERE = path.dirname(fileURLToPath(import.meta.url));
const REAL_ROUTE = path.resolve(HERE, '../../../../../bench/route/4926685115947721762.v2.fullroute.json');
if (!fs.existsSync(REAL_ROUTE)) {
    console.error(`❌ 阳性对照缺失：找不到真 route 文件 ${REAL_ROUTE}`);
    console.error('   自检必须以现场数据为输入；拿不到就**拒绝跑**（不许拿编的数据替）。');
    process.exit(2);
}

let pass = 0, fail = 0;
const failures = [];
function ok(cond, name, extra = '') {
    if (cond) { pass++; return; }
    fail++; failures.push(`${name}${extra ? ' — ' + extra : ''}`);
}

// ===========================================================================
// A 组：读 route —— 三态判别（absent / present-but-empty / 读不到）
// ===========================================================================

// A1 阳性对照：**真的** v2 文件必须读得出（证明这套判据能测出"有"）
{
    const r = loadRouteFile(REAL_ROUTE);
    ok(r.ok === true, 'A1 真 route v2 读得出', `reason=${r.reason}`);
    ok(r.stations.length >= 7, 'A1 站数 ≥7', `got ${r.stations.length}`);
    ok(r.legs.length >= 7, 'A1 legs ≥7', `got ${r.legs.length}`);
}

// A2 文件不存在 → UNREADABLE，**不是** "空 route"
{
    const r = loadRouteFile(path.join(HERE, '__no_such_route__.json'));
    ok(r.ok === false && String(r.reason).startsWith('UNREADABLE'), 'A2 读不到 → UNREADABLE', `reason=${r.reason}`);
    ok(r.stations.length === 0 && r.legs.length === 0, 'A2 读不到时 stations/legs 为空数组');
}

// A3 根本没给文件 → NO_ROUTE_FILE
{
    const r = loadRouteFile(null);
    ok(r.ok === false && r.reason === 'NO_ROUTE_FILE', 'A3 null → NO_ROUTE_FILE', `reason=${r.reason}`);
}

// A4 **v1 文件必须被拒**（v1 没有 exact；静默接受 = "这一站没目标"与"没预勘"分不开）
{
    const v1 = { schema: 'aidqq-route/1', stations: [{ id: 'X', station: { center: [0, 0] } }] };
    const tmp = path.join(HERE, '__t11_v1_probe.json');
    fs.writeFileSync(tmp, JSON.stringify(v1), 'utf8');
    const r = loadRouteFile(tmp);
    ok(r.ok === false && String(r.reason).startsWith('SCHEMA:'), 'A4 v1 被拒', `reason=${r.reason}`);
    try { fs.unlinkSync(tmp); } catch { /* 清理失败不影响判定 */ }
}

// A5 坏 JSON → BAD_JSON
{
    const tmp = path.join(HERE, '__t11_badjson_probe.json');
    fs.writeFileSync(tmp, '{not json', 'utf8');
    const r = loadRouteFile(tmp);
    ok(r.ok === false && String(r.reason).startsWith('BAD_JSON'), 'A5 坏 JSON → BAD_JSON', `reason=${r.reason}`);
    try { fs.unlinkSync(tmp); } catch { /* 清理失败不影响判定 */ }
}

// ===========================================================================
// B 组：readExact —— present / absent / present-but-empty 三者必须能分开
// ===========================================================================

// B1 真 route：S0_iron 有非空 exact
{
    const r = loadRouteFile(REAL_ROUTE);
    const e = readExact(r, 'S0_iron');
    ok(e.present === true, 'B1 S0_iron exact present');
    ok(e.stand.length === 4, 'B1 S0_iron stand = 4', `got ${e.stand.length}`);
    ok(e.targets.length === 14, 'B1 S0_iron targets = 14 铁矿', `got ${e.targets.length}`);
    ok(e.targets.every((t) => t.what === 'dig'), 'B1 S0_iron targets 全是 dig');
}

// B2 S0_gravel：31 块沙砾
{
    const r = loadRouteFile(REAL_ROUTE);
    const e = readExact(r, 'S0_gravel');
    ok(e.targets.length === 31, 'B2 S0_gravel targets = 31 沙砾', `got ${e.targets.length}`);
}

// B3 站不存在 → STATION_NOT_FOUND
{
    const r = loadRouteFile(REAL_ROUTE);
    const e = readExact(r, '__nope__');
    ok(e.present === false && e.reason === 'STATION_NOT_FOUND', 'B3 站不存在 → STATION_NOT_FOUND', `reason=${e.reason}`);
    ok(e.targets === null, 'B3 targets 是 null 不是 []');
}

// B4 站存在但**没有 exact 块** → NO_EXACT_BLOCK（与 B3 区分开）
{
    const r = loadRouteFile(REAL_ROUTE);
    const noExact = r.stations.find((s) => s && !s.exact);
    ok(!!noExact, 'B4 真 route 里至少有一站没有 exact（阳性：这一站存在）', noExact ? noExact.id : 'none');
    if (noExact) {
        const e = readExact(r, noExact.id);
        ok(e.present === false && e.reason === 'NO_EXACT_BLOCK', 'B4 有站无 exact → NO_EXACT_BLOCK', `reason=${e.reason}`);
    }
}

// B5 present-but-empty（`exact:{}`）：present=true 且 stand/targets 为空数组
//    ⚠ 这条与 B3/B4 必须不同 —— "作者说了这一站没有精确坐标" ≠ "还没预勘"
{
    const doc = { schema: 'aidqq-route/2', stations: [{ id: 'E', exact: {} }], legs: [] };
    const e = readExact(doc, 'E');
    ok(e.present === true, 'B5 exact:{} → present=true');
    ok(e.reason === null, 'B5 exact:{} → reason=null');
    ok(Array.isArray(e.stand) && e.stand.length === 0, 'B5 exact:{} → stand=[]');
    ok(Array.isArray(e.targets) && e.targets.length === 0, 'B5 exact:{} → targets=[]');
}

// ===========================================================================
// C 组：legs —— 找不到返 null（不是 []），路点是身体格
// ===========================================================================

// C1 真 route 的 S0_iron→S0_gravel 有路点
{
    const r = loadRouteFile(REAL_ROUTE);
    const leg = legWaypoints(r, 'S0_iron', 'S0_gravel');
    ok(leg !== null, 'C1 S0_iron→S0_gravel 有 leg');
    ok(leg.waypoints.length === 3, 'C1 该 leg 3 个路点', `got ${leg.waypoints.length}`);
    ok(leg.dim === 'overworld', 'C1 dim=overworld', `got ${leg.dim}`);
    ok(leg.waypoints.every((w) => w.every(Number.isInteger)), 'C1 路点全是整数三元组');
}

// C2 方向反了 → null（**不是** []）
{
    const r = loadRouteFile(REAL_ROUTE);
    ok(legWaypoints(r, 'S0_gravel', 'S0_iron') === null, 'C2 反向查 → null 不是 []');
}

// C3 不存在的腿 → null
{
    const r = loadRouteFile(REAL_ROUTE);
    ok(legWaypoints(r, 'A', 'B') === null, 'C3 不存在的腿 → null');
}

// C4 相邻路点 ≤32 格（SCHEMA §5）—— 逐条核，全部 legs
{
    const r = loadRouteFile(REAL_ROUTE);
    let worst = 0, bad = 0, n = 0;
    for (const leg of r.legs) {
        for (let i = 0; i + 1 < leg.waypoints.length; i++) {
            const d = dist3(leg.waypoints[i], leg.waypoints[i + 1]);
            n++;
            if (Number.isFinite(d)) { worst = Math.max(worst, d); if (d > 32) bad++; }
        }
    }
    ok(n > 0, 'C4 有路点对可核', `n=${n}`);
    ok(bad === 0, 'C4 全部相邻路点 ≤32 格', `worst=${worst.toFixed(2)} bad=${bad}`);
}

// ===========================================================================
// D 组：planDigTargets —— 排序 + "没 order"不许静默丢
// ===========================================================================

// D1 真 route：按 order 排，order 连续 1..14
{
    const r = loadRouteFile(REAL_ROUTE);
    const e = readExact(r, 'S0_iron');
    const { plan, skippedNoOrder } = planDigTargets(e);
    ok(plan.length === 14, 'D1 plan 14 条', `got ${plan.length}`);
    ok(skippedNoOrder === 0, 'D1 真 route 没有缺 order 的');
    const orders = plan.map((t) => t.order);
    ok(orders.every((o, i) => o === i + 1), 'D1 order 连续 1..14', orders.join(','));
}

// D2 缺 order 的目标**不许静默丢**（必须计数上报）
{
    const exact = { targets: [
        { what: 'dig', xyz: [1, 2, 3], order: 2 },
        { what: 'dig', xyz: [4, 5, 6] },                 // 没 order
        { what: 'dig', xyz: [7, 8, 9], order: 1 },
    ] };
    const { plan, skippedNoOrder } = planDigTargets(exact);
    ok(plan.length === 2, 'D2 只排有 order 的 2 条', `got ${plan.length}`);
    ok(skippedNoOrder === 1, 'D2 缺 order 的被计数而不是静默丢', `got ${skippedNoOrder}`);
    ok(plan[0].order === 1 && plan[1].order === 2, 'D2 按 order 升序');
}

// D3 order 相同时的稳定次序按 y/x/z（不能等于随机）
{
    const exact = { targets: [
        { what: 'dig', xyz: [5, 9, 5], order: 1 },
        { what: 'dig', xyz: [1, 3, 1], order: 1 },
        { what: 'dig', xyz: [3, 3, 3], order: 1 },
    ] };
    const { plan } = planDigTargets(exact);
    const ys = plan.map((t) => t.xyz[1]);
    ok(ys[0] === 3 && ys[1] === 3 && ys[2] === 9, 'D3 同 order 按 (y,x,z) 升序', ys.join(','));
    ok(plan[0].xyz[0] === 1 && plan[1].xyz[0] === 3, 'D3 同 y 按 x 升序');
}

// D4 形状不对的 target 被过滤，且不抛
{
    const exact = { targets: [{ what: 'dig', xyz: [1, 2, 3], order: 1 }, { what: 'dig', xyz: [1, 2] }, null, 'x'] };
    const { plan } = planDigTargets(exact);
    ok(plan.length === 1, 'D4 坏 target 被过滤', `got ${plan.length}`);
}

// ===========================================================================
// E 组：standCandidates —— **脚下格 vs 身体格差 1**（本单最容易搞错的一条）
// ===========================================================================

// E1 `exact.stand` 是**脚下**格 ⇒ 站上去身体格 = y+1
{
    const exact = { stand: [[10, 45, 20]] };
    const c = standCandidates(exact, { xyz: [10, 49, 20] });
    const fromStand = c.find((x) => x.from === 'exact.stand');
    ok(!!fromStand, 'E1 有 exact.stand 候选');
    ok(fromStand.body[1] === 46, 'E1 脚下格 y=45 → 身体格 y=46', `got ${fromStand.body[1]}`);
}

// E2 `target.standFor` 是**身体格**（route 里 standDist 就是相对它算的）⇒ 不加 1
{
    const exact = { stand: [[10, 45, 20]] };
    const c = standCandidates(exact, { xyz: [10, 49, 20], standFor: [10, 46, 20], standDist: 3 });
    const fromTarget = c.find((x) => x.from === 'target.standFor');
    ok(!!fromTarget, 'E2 有 target.standFor 候选');
    ok(fromTarget.body[1] === 46, 'E2 standFor 已经是身体格，不再 +1', `got ${fromTarget.body[1]}`);
}

// E3 standFor 排在 exact.stand 之前（route 给的更具体）
{
    const exact = { stand: [[10, 45, 20]] };
    const c = standCandidates(exact, { xyz: [10, 49, 20], standFor: [10, 46, 20] });
    ok(c[0].from === 'target.standFor', 'E3 standFor 优先', c[0].from);
}

// E4 站位与目标同格必须被排除（手册 §3：压在边界上服务端射线打相邻格）
{
    const exact = { stand: [[10, 45, 20]] };
    const c = standCandidates(exact, { xyz: [10, 46, 20], standFor: [10, 46, 20] });
    // 目标 xyz 与 standFor 完全相同 ⇒ 站上去就站在要挖的格子里
    const same = c.filter((x) => x.body.join(',') === '10,46,20');
    ok(same.length > 0, 'E4 现状：同格候选仍会产生（记录真实行为）', `n=${same.length}`);
    // 兜底邻格必须提供出路
    ok(c.some((x) => x.from === 'target.neighbour'), 'E4 有 target.neighbour 兜底候选');
}

// E5 去重：同一个 body 只出现一次
{
    const exact = { stand: [[10, 45, 20], [10, 45, 20]] };
    const c = standCandidates(exact, { xyz: [10, 46, 20], standFor: [10, 45, 21] });
    const keys = c.map((x) => x.body.join(','));
    ok(new Set(keys).size === keys.length, 'E5 候选已去重', keys.join(' | '));
}

// ===========================================================================
// F 组：dist3 —— 与 route_v2.mjs 同口径；形状不对返 NaN（不返 0）
// ===========================================================================

{
    ok(dist3([0, 0, 0], [3, 4, 0]) === 5, 'F1 3-4-5');
    ok(dist3([0, 0, 0], [0, 0, 0]) === 0, 'F2 同点 = 0');
    ok(Number.isNaN(dist3([0, 0], [1, 1, 1])), 'F3 二元组 → NaN 不是 0');
    ok(Number.isNaN(dist3(null, [1, 1, 1])), 'F4 null → NaN 不是 0');
    ok(Number.isNaN(dist3([0, 0, 0], [1.5, 0, 0])), 'F5 小数 → NaN（route 只放整数）');
    ok(dist3([0, 0, 0], [32, 0, 0]) === 32, 'F6 正好 32 格');
}

// ===========================================================================
// 报告
// ===========================================================================
console.log('');
console.log('='.repeat(72));
console.log(`route_waypoints_selftest: ${pass} 通过 / ${fail} 失败（共 ${pass + fail}）`);
if (failures.length) {
    console.log('-'.repeat(72));
    failures.forEach((f) => console.log('  ❌ ' + f));
}
console.log('='.repeat(72));
process.exit(fail === 0 ? 0 : 1);
