// task_metrics_selftest.mjs — MC-M1-TASK-09-r3 ②③ 的离线用例（不开服、不占端口）
//
// 验两件事，都是"指标自己骗自己"的同族：
//
// ② `progress_checker.js` 的 `idleMs` 必须在 `isComplete()` **之后**才累加。
//    旧写法在 `isComplete()` 判断之前累加 ⇒ **任务已经完结之后**的收尾时间
//    （defense/收尾阶段、最后一次 await）全被算成"站定不动且没在挖"。
//    实证（研究线 pace-audit）：S0 局 `idleMs=178.9s > durationMs=167.1s`（107%）。
//    ⚠ 口径变更 ⇒ **改前改后的 idle 数不可直接比**。
//
// ③ `metrics.deaths` 必须在**死亡事件到达时**自增，而不是在任务循环里轮询到时自增。
//    旧写法 `task_runner.js:101-102`：`if (ctx.takeDeath()) { counters.deaths++ ... }`
//    —— 死亡若发生在一次长 await（挖矿 42s / 导航 25s）里，要等下一拍才被消费；
//    若那一拍根本没走到（任务刚完结 / 循环已退），这次死亡就**永远不计**。
//    实证（B 线 r15）：47 个 trial 实死 4 次，计数器只记 1 次。
//    ⇒ 同一族的第二个症状：`task_on_death` 遥测**迟到**十几秒（那一拍才发），
//    所以它现在必须带 `deathAt`（死亡真实时刻）与 `delayMs`（迟到多久），
//    否则"死亡时刻取 server.log"这条口径在遥测侧无法自证。
//
// 跑法：node task_metrics_selftest.mjs      （退出码 0 = 全过）

import { Vec3 } from 'vec3';
import { ProgressChecker } from './progress_checker.js';
import { ExecTask, TaskStatus } from './task.js';
import { TaskRuntime, driveTask, makeCtx, makeRunState } from './task_runner.js';

let pass = 0, fail = 0;
const ok = (cond, name, extra = '') => {
    if (cond) { pass++; console.log(`  ✅ ${name}`); }
    else { fail++; console.log(`  ❌ ${name}${extra ? '  → ' + extra : ''}`); }
};
/** idleMs 是按真实 `Date.now()` 差值累的，回拨时刻会带来 1–2ms 的执行抖动 ⇒ 用容差比。 */
const near = (got, want, tol = 60) => Math.abs(got - want) <= tol;

/** 造一个不会动的假 bot（不动 ⇒ `lastPosMoved()` 为 false ⇒ 会计入 idle） */
const stillBot = (digging = false) => ({
    entity: { position: new Vec3(10, 64, 10) },
    targetDigBlock: digging ? { name: 'stone' } : null,
});
/** 会动的假 bot：每次 `move()` 把坐标挪 1 格（≥ moveDist 阈值） */
const movingBot = (digging = false) => {
    const b = stillBot(digging);
    b._p = new Vec3(10, 64, 10);
    b.entity.position = b._p;
    b.move = (n = 1) => { b.entity.position = new Vec3(10 + n, 64, 10); };
    return b;
};

function makeCheckerCtx(task, bot) {
    const tele = [];
    const ctx = { bot, run: makeRunState(), telemetry: (e, d) => tele.push({ event: e, ...d }) };
    return { ctx, tele };
}
/**
 * 假装"这一拍间隔了 dtMs，且这段时间 bot 一直不动"。
 * ⚠ 只回拨 `_lastTickAt` 是不够的：`idleMs` 的判据是 `lastPosMoved()` =
 * `now - lastMoveAt < tickMs*2`，`lastMoveAt` 是 `reset()` 时的真实时刻
 * ⇒ 只伪造 dt 会让 `lastPosMoved` 恒为 true、idleMs 恒 0，
 * **用例 2 会在未修复的代码上假通过**。两个时刻必须一起回拨。
 */
function tick(checker, ctx, dtMs) {
    const now = Date.now();
    checker._lastTickAt = now - dtMs;
    checker.lastMoveAt = now - dtMs;
    checker.update(ctx);
}

console.log('=== task_metrics 离线自检（MC-M1-TASK-09-r3 ②③）===\n');

// ═══════════════ ② idleMs 必须在 isComplete() 之后累加 ═══════════════
console.log('--- ② progress_checker.idleMs ---');

class ProbeTask extends ExecTask {
    constructor(complete) { super('ProbeTask'); this._complete = complete; this.n = 0; }
    isComplete() { return this._complete; }
    progressSignature() { return `sig${this.n}`; }
    async tick() { this.n++; }
}

// —— 用例 1：任务**未完结**且 bot 不动 ⇒ idleMs 必须照常累加（老行为不能被改坏）——
{
    const task = new ProbeTask(false);
    const { ctx } = makeCheckerCtx(task, stillBot(false));
    const c = new ProgressChecker(task, ctx, { tickMs: 500 });
    tick(c, ctx, 5000);
    tick(c, ctx, 5000);
    ok(near(ctx.run.counters.idleMs, 10000), '用例1：未完结 + 站定不动 ⇒ idleMs 累加 2×5000ms',
        String(ctx.run.counters.idleMs));
}

// —— 用例 2：★ 任务**已完结** ⇒ 收尾时间不再计入 idle（这就是本单要修的那条）——
{
    const task = new ProbeTask(true);
    const { ctx } = makeCheckerCtx(task, stillBot(false));
    const c = new ProgressChecker(task, ctx, { tickMs: 500 });
    tick(c, ctx, 5000);
    tick(c, ctx, 5000);
    tick(c, ctx, 5000);
    ok(ctx.run.counters.idleMs === 0, '用例2：★已完结 ⇒ idleMs 恒为 0（收尾时间不算 idle）',
        String(ctx.run.counters.idleMs));
}

// —— 用例 3：★ 口径自证：idleMs **不得超过**任务实际未完结期间的时间 ——
//   复现 pace-audit 的病灶形态：idleMs > durationMs（107%）。这里做等价的结构性检查。
{
    const task = new ProbeTask(false);
    const { ctx } = makeCheckerCtx(task, stillBot(false));
    const c = new ProgressChecker(task, ctx, { tickMs: 500 });
    tick(c, ctx, 5000);
    task._complete = true;                       // 中途完结
    tick(c, ctx, 5000);
    tick(c, ctx, 5000);
    ok(near(ctx.run.counters.idleMs, 5000),
        '用例3：完结前 5s 计入、完结后 10s 不计入 ⇒ idleMs=5000', String(ctx.run.counters.idleMs));
}

// —— 用例 4：正在挖 ⇒ 本来就不计 idle（这条与 isComplete 无关，钉住别被顺手改坏）——
{
    const task = new ProbeTask(false);
    const { ctx } = makeCheckerCtx(task, stillBot(true));
    const c = new ProgressChecker(task, ctx, { tickMs: 500 });
    tick(c, ctx, 5000);
    ok(ctx.run.counters.idleMs === 0, '用例4：正在挖 ⇒ 不计 idle', String(ctx.run.counters.idleMs));
}

// —— 用例 5：★ 完结**不**影响移动维度的更新（`lastMoveAt` 仍要刷新）——
//   否则任务完结后若又被 restart()（ExecTask.restart 存在），移动判据会带着一个
//   冻结了几分钟的 lastMoveAt 复活，第一拍就误报"物理卡住"。
{
    const task = new ProbeTask(true);
    const bot = movingBot(false);
    const { ctx } = makeCheckerCtx(task, bot);
    const c = new ProgressChecker(task, ctx, { tickMs: 500 });
    c.update(ctx);                             // 第一拍只初始化 lastPos（此时还没有"移动"可言）
    // ⚠ 不要拿 `before = c.lastMoveAt` 再比 `>` —— `lastMoveAt` 是在 `update()` 里按
    //   真实 `Date.now()` 刷的，两拍落在同一毫秒时它**纹丝不动**，断言会随机红。
    //   这里改成人为把 lastMoveAt 压到极旧值，比较就与毫秒竞态无关了。
    c.lastMoveAt = 1;
    c._lastTickAt = Date.now() - 5000;         // 拍间隔 5s
    bot.move(1);                               // 但这 5s 里 bot 走了 1 格（≥ moveDist 0.1）
    c.update(ctx);
    ok(c.lastMoveAt > 1, '用例5：已完结期间移动维度仍在刷新（restart 后不会一上来就误报卡住）',
        `lastMoveAt=${c.lastMoveAt}`);
    ok(ctx.run.counters.idleMs === 0, '用例5b：完结 + 在动 ⇒ 不计 idle', String(ctx.run.counters.idleMs));
}

// ═══════════════ ③ deaths 必须在死亡到达时自增 ═══════════════
console.log('\n--- ③ task_runner.deaths / task_on_death ---');

function runtimeWithCtx() {
    const tele = [];
    const rt = new TaskRuntime(stillBot(false), { mission: { resource: 'iron_ingot', count: 1 } });
    rt.telemetry = (event, data = {}) => tele.push({ event, ...data });
    const ctx = makeCtx(stillBot(false), { telemetry: rt.telemetry, run: makeRunState() });
    rt._ctx = ctx;
    return { rt, ctx, tele };
}

// —— 用例 6：★ 死亡到达即计数，**完全不需要**任务循环来轮询 ——
//   这就是"47 局实死 4 次只记 1 次"的根因：旧写法靠 `ctx.takeDeath()` 轮询。
{
    const { rt, ctx } = runtimeWithCtx();
    rt.noteDeath('lava');
    ok(ctx.run.counters.deaths === 1, '用例6：★noteDeath 一落，deaths 立刻 =1（不靠轮询）',
        String(ctx.run.counters.deaths));
    ok(ctx.deathEvents.length === 1, '用例6：deathEvents 仍留 1 条给任务层消费',
        String(ctx.deathEvents.length));
}

// —— 用例 7：★ 轮询消费时**不得**二次自增（防止"两处都加"这种改法）——
{
    const { rt, ctx } = runtimeWithCtx();
    rt.noteDeath('lava');
    const d = ctx.takeDeath();
    ok(!!d, '用例7：takeDeath 取得到该事件', JSON.stringify(d));
    ok(ctx.run.counters.deaths === 1, '用例7：★消费之后 deaths 仍是 1（没有双计）',
        String(ctx.run.counters.deaths));
}

// —— 用例 8：连续两次死亡 ⇒ 2；原因字段不丢 ——
{
    const { rt, ctx } = runtimeWithCtx();
    rt.noteDeath('lava');
    rt.noteDeath('fell');
    ok(ctx.run.counters.deaths === 2, '用例8：两次死亡 ⇒ deaths=2', String(ctx.run.counters.deaths));
    const reasons = ctx.deathEvents.map((e) => e.reason).sort();
    ok(JSON.stringify(reasons) === JSON.stringify(['fell', 'lava']), '用例8：reason 字段原样保留',
        JSON.stringify(reasons));
}

// —— 用例 9：★ 死亡事件自带时刻 `t`（`task_on_death` 的 delayMs 要靠它算）——
{
    const { rt, ctx } = runtimeWithCtx();
    const t0 = Date.now();
    rt.noteDeath('lava');
    const d = ctx.deathEvents[0];
    ok(typeof d.t === 'number' && d.t >= t0, '用例9：deathEvents[i].t 是数字且就是死亡到达时刻',
        JSON.stringify(d));
}

// —— 用例 10：★ `task_on_death` 遥测必须带 deathAt / delayMs ——
//   场景照 B/D 线给的证据：死亡发生在一次长 await 里，任务循环**13 秒后**才轮到它。
{
    const tele = [];
    const run = makeRunState();
    const ctx = makeCtx(stillBot(false), { telemetry: (e, d) => tele.push({ event: e, ...d }), run });
    ctx.deathEvents.push({ t: Date.now() - 13000, reason: 'lava' });   // 13 秒前就死了
    class Quick extends ExecTask {
        async tick() { this._transition(TaskStatus.SUCCESS, 'done'); }
    }
    const task = new Quick('Quick');
    await driveTask(task, ctx, { tickMs: 1 });
    const ev = tele.find((e) => e.event === 'task_on_death');
    ok(!!ev, '用例10：发出了 task_on_death', JSON.stringify(tele.map((e) => e.event)));
    ok(!!ev && typeof ev.deathAt === 'number', '用例10：★task_on_death 带 deathAt（死亡真实时刻）',
        JSON.stringify(ev));
    ok(!!ev && typeof ev.delayMs === 'number' && ev.delayMs >= 13000,
        '用例10：★task_on_death 带 delayMs 且 ≥13s（迟到多久自己会报）', JSON.stringify(ev));
    ok(!!ev && ev.task === 'Quick', '用例10：仍然带 task 名（老字段没丢）', JSON.stringify(ev));
}

console.log(`\n=== ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail === 0 ? 0 : 2);
