// dm_client.js — 决策通道客户端（P0-B）
//
// 通道:
//   bailianChoice — 百炼 decision-model-preview (systemone choice)。P0-A decide-bench 判 FAIL
//                   (bench/docs/decide-bench-report-20260928.md) 后默认停用，代码保留供回切实验。
//   llmChoice     — 通用 LLM 闭集选择（方舟 coding 端点；豆包主通道 → GLM fallback）。
//
// 铁律: 两个通道都是纯异步 fetch，绝不阻塞当前宏；失败一律 resolve null，由 decider 走保守 fallback。
import { getKey } from '../utils/keys.js';
import { readFileSync } from 'fs';
import { homedir } from 'os';
import { join } from 'path';

const BAILIAN_ENDPOINT = 'https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1/systemone';
const ARK_MESSAGES = 'https://ark.cn-beijing.volces.com/api/coding/v1/messages';
// LLM 通道链（依次尝试）: 豆包(方舟coding) → step5-preview(阶跃step_plan, 豆包配额耗尽时的替补) → GLM(方舟coding)
const LLM_CHANNELS = [
    { label: 'doubao', model: 'doubao-seed-2-1-turbo-260628', url: ARK_MESSAGES, proto: 'anthropic', keyName: 'ANTHROPIC_API_KEY' },
    { label: 'step5', model: 'step-5-preview', url: 'https://api.stepfun.com/step_plan/v1/chat/completions', proto: 'openai', keyName: '__step_plan__' },
    { label: 'glm', model: 'glm-5.3-flash', url: ARK_MESSAGES, proto: 'anthropic', keyName: 'ANTHROPIC_API_KEY' },
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function bailianKey() {
    if (process.env.BAILIAN_KEY) return process.env.BAILIAN_KEY.trim();
    try {
        const cfg = JSON.parse(readFileSync(join(homedir(), '.zcode', 'v2', 'provider_config.json'), 'utf-8'));
        const find = (o) => {
            if (typeof o === 'string') return o.startsWith('sk-sp-') ? o : null;
            if (Array.isArray(o)) { for (const v of o) { const r = find(v); if (r) return r; } return null; }
            if (o && typeof o === 'object') { for (const v of Object.values(o)) { const r = find(v); if (r) return r; } return null; }
            return null;
        };
        return find(cfg);
    } catch { return null; }
}

async function postJSON(url, payload, headers, timeoutMs) {
    const t0 = Date.now();
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...headers },
            body: JSON.stringify(payload),
            signal: ctrl.signal,
        });
        const e2e = Date.now() - t0;
        if (!res.ok) {
            const body = await res.text().catch(() => '');
            const err = new Error(`HTTP ${res.code || res.status}: ${body.slice(0, 200)}`);
            err.status = res.status;
            throw err;
        }
        return { json: await res.json(), e2e_ms: e2e };
    } finally {
        clearTimeout(timer);
    }
}

// ---- 通道 1: 百炼 systemone choice（默认停用；criteria = {name: description}）----
export async function bailianChoice(state, criteria, { timeoutMs = 15000 } = {}) {
    const key = bailianKey();
    if (!key) return null;
    const payload = {
        model: 'decision-model-preview',
        state,
        questions: {
            act: {
                type: 'choice',
                instructions: 'Pick exactly ONE next action from the criteria for this Minecraft speedrun bot. If truly none fits, pick other.',
                criteria,
            },
        },
    };
    for (let i = 0; i < 3; i++) {
        try {
            const { json, e2e_ms } = await postJSON(BAILIAN_ENDPOINT, payload,
                { Authorization: `Bearer ${key}` }, timeoutMs);
            const ans = json?.answers?.act ?? {};
            return {
                choice: ans.choice ?? null,
                confidence: ans.confidence ?? null,
                probabilities: ans.probabilities ?? null,
                latency_ms: json.latency_ms ?? null,
                e2e_ms,
                input_tokens: json?.usage?.input_tokens ?? null,
                channel: 'bailian',
            };
        } catch (e) {
            if ((e.status === 429 || e.status === 529) && i < 2) { await sleep(2000 + 2000 * i); continue; }
            console.warn(`[dm_client] bailian failed: ${e.message}`);
            return null;
        }
    }
    return null;
}

function stepPlanKey() {
    // 阶跃 step_plan 订阅通道 key：与 provider_config.json 同源解析（不落盘不回显）
    try {
        const cfg = JSON.parse(readFileSync(join(homedir(), '.zcode', 'v2', 'provider_config.json'), 'utf-8'));
        const rules = cfg?.config?.providerConfigRules?.providerRules ?? [];
        for (const r of rules) {
            const api = r?.config?.api ?? {};
            if (String(api.baseUrl ?? '').includes('api.stepfun.com')) {
                const key = r?.config?.access?.apiKey;
                if (key) return key;
            }
        }
    } catch { /* fallthrough */ }
    return null;
}

function channelKey(ch) {
    if (ch.keyName === '__step_plan__') return stepPlanKey();
    try { return getKey(ch.keyName); } catch { return null; }
}

// ---- 通道 2: 通用 LLM 闭集选择（豆包 → step5 → GLM）----
const LLM_PROMPT = `You are the macro-boundary decision maker of a Minecraft speedrun bot.
Pick exactly ONE next action from the closed set below. If truly none fits, pick "other".
Consider: current macro continuity (do not interrupt a working macro), survival first at low HP, then the chapter goal.
Respond ONLY with minified JSON: {"choice":"...","confidence":<0.0-1.0>,"reason":"<=15 words"}

ACTIONS:
{actions}

STATE:
{state}`;

export async function llmChoice(state, criteria, { timeoutMs = 25000 } = {}) {
    const body = LLM_PROMPT
        .replace('{actions}', Object.entries(criteria).map(([n, d]) => `- ${n}: ${d}`).join('\n'))
        .replace('{state}', JSON.stringify(state));
    for (const ch of LLM_CHANNELS) {
        const key = channelKey(ch);
        if (!key) continue;
        const payload = ch.proto === 'openai'
            ? { model: ch.model, max_tokens: 200, messages: [{ role: 'user', content: body }] }
            : { model: ch.model, max_tokens: 200, messages: [{ role: 'user', content: body }] };
        const headers = ch.proto === 'openai'
            ? { Authorization: `Bearer ${key}` }
            : { 'x-api-key': key, 'anthropic-version': '2023-06-01' };
        for (let i = 0; i < 2; i++) {
            try {
                const { json, e2e_ms } = await postJSON(ch.url, payload, headers, timeoutMs);
                const text = ch.proto === 'openai'
                    ? (json?.choices?.[0]?.message?.content ?? '')
                    : (json?.content ?? []).map((b) => b.text ?? '').join('');
                let parsed = null;
                try {
                    parsed = JSON.parse(String(text).trim().replace(/^```(json)?/, '').replace(/```$/, '').trim());
                } catch { /* fallthrough */ }
                if (!parsed || !parsed.choice) {
                    // 宽松兜底: 在回复文本里找候选名
                    for (const name of Object.keys(criteria)) {
                        if (String(text).includes(name)) { parsed = { choice: name, confidence: null, reason: 'fallback-parse' }; break; }
                    }
                }
                if (!parsed) break;
                return {
                    choice: parsed.choice,
                    confidence: typeof parsed.confidence === 'number' ? parsed.confidence : null,
                    reason: parsed.reason ?? '',
                    latency_ms: null,
                    e2e_ms,
                    input_tokens: ch.proto === 'openai'
                        ? (json?.usage?.prompt_tokens ?? null)
                        : (json?.usage?.input_tokens ?? null),
                    channel: `llm:${ch.label}`,
                };
            } catch (e) {
                if ((e.status === 429 || e.status === 529) && i < 1) { await sleep(3000); continue; }
                console.warn(`[dm_client] llm ${ch.label} failed: ${e.message}`);
                break; // 换下一个通道
            }
        }
    }
    return null;
}
