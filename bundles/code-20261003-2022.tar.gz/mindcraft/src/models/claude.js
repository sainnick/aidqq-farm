import Anthropic from '@anthropic-ai/sdk';
import { strictFormat } from '../utils/text.js';
import { getKey } from '../utils/keys.js';

export class Claude {
    static prefix = 'anthropic';
    constructor(model_name, url, params) {
        this.model_name = model_name;
        this.params = params || {};

        let config = {};
        if (url)
            config.baseURL = url;
        
        config.apiKey = getKey('ANTHROPIC_API_KEY');

        this.anthropic = new Anthropic(config);
    }

    async sendRequest(turns, systemMessage) {
        const messages = strictFormat(turns);
        let res = null;
        try {
            console.log(`Awaiting anthropic response from ${this.model_name}...`)
            if (!this.params.max_tokens) {
                if (this.params.thinking?.budget_tokens) {
                    this.params.max_tokens = this.params.thinking.budget_tokens + 1000;
                    // max_tokens must be greater than thinking.budget_tokens
                } else {
                    this.params.max_tokens = 4096;
                }
            }
            const resp = await (async () => {
                // [AI斗蛐蛐 patch] rate-limit backoff retry (429 / 火山限频)，避免烧掉一次决策
                let attempts = 0;
                for (;;) {
                    try {
                        const r = await this.anthropic.messages.create({
                            model: this.model_name || "claude-sonnet-4-6",
                            system: systemMessage,
                            messages: messages,
                            ...(this.params || {})
                        });
                        // [AI斗蛐蛐 patch] 空响应重试：模型偶发返回纯空白文本，原样重问
                        // 而不是烧掉一轮决策；最多重问 2 次，仍空则交还上层原有逻辑
                        const t = r.content.find(c => c.type === 'text');
                        if (attempts < 2 && t && typeof t.text === 'string' && t.text.trim().length === 0) {
                            attempts++;
                            console.log(`[aidouququ] empty response, re-ask ${attempts}/2...`);
                            await new Promise(resolve => setTimeout(resolve, 2000));
                            continue;
                        }
                        return r;
                    } catch (e) {
                        const rateLimited = e?.status === 429 || /rate.?limit|1302|throttl/i.test(e?.message || '');
                        if (rateLimited && attempts < 10) {
                            const wait = Math.min(45000, 8000 * (attempts + 1));
                            console.log(`[aidouququ] rate limited, retry ${attempts + 1}/10 after ${wait / 1000}s...`);
                            await new Promise(r => setTimeout(r, wait));
                            attempts++;
                        } else {
                            throw e;
                        }
                    }
                }
            })();

            console.log('Received.')
            // get first content of type text
            const textContent = resp.content.find(content => content.type === 'text');
            if (textContent) {
                res = textContent.text;
            } else {
                console.warn('No text content found in the response.');
                res = 'No response from Claude.';
            }
        }
        catch (err) {
            if (err.message.includes("does not support image input")) {
                res = "Vision is only supported by certain models.";
            } else {
                res = "My brain disconnected, try again.";
            }
            console.log(err);
        }
        return res;
    }

    async sendVisionRequest(turns, systemMessage, imageBuffer) {
        const imageMessages = [...turns];
        imageMessages.push({
            role: "user",
            content: [
                {
                    type: "text",
                    text: systemMessage
                },
                {
                    type: "image",
                    source: {
                        type: "base64",
                        media_type: "image/jpeg",
                        data: imageBuffer.toString('base64')
                    }
                }
            ]
        });

        return this.sendRequest(imageMessages, systemMessage);
    }

    async embed(text) {
        throw new Error('Embeddings are not supported by Claude.');
    }
}
