// threat_table.js — MC-M1-TASK-07（G 线 / S0 BASIC-survival）：威胁登记表
//
// 设计依据：docs/research/stage-00-survival.md §1.1（主世界）/§1.2（下界）/§1.3（感知架构）。
//
// 本文件是**纯数据 + 纯判据**：不 import bot、不读方块、不开服 ⇒ 可以完全离线单测
// （bench/stages/basic-survival/selftest_defense.mjs 的 T1/T2 组）。
//
// 两条口径纪律：
//   1. 参数带出处与「未核验」标记。设计文档里标【未核验】的常数原样保留标记，
//      本单不做二选一定版（那要实跑，农场就绪后再做）——但**代码里必须能一眼看出
//      哪些数是可调的**：`unverified: true` 的字段不允许被下游当权威值用。
//   2. 下界威胁表**只登记不实现**（任务单 §1 末句）。保留在表里是为了 S2/S3 直接复用，
//      判定入口 `isHostile()` 按维度分开：下界条目不会在主世界触发。

/** 威胁级（设计 §1.3 的三档分级）。数值即档位序，便于取 max。 */
export const THREAT_LEVEL = {
    MONITORED: 1,   // 只标记（遥测 + 导航回避代价），不打断任务树
    ENGAGED: 2,     // 中断任务树，派发处置任务
    EMERGENCY: 3,   // 立即中断（不等下个 500ms 扫描周期）
};

/** 分级门限（格）。设计 §1.3 + 任务单硬要求 3（只对看得见的实体反应）。 */
export const THREAT_RANGE = {
    emergency: 6,    // < 6 且 LOS → EMERGENCY
    engaged: 12,     // < 12 且 LOS → ENGAGED
    monitored: 24,   // < 24        → MONITORED
    // 迟滞（设计 §1.3）：进入用 engaged、退出用 engagedExit，避免在 12 格边界反复升降
    // 导致 dispatch 风暴（TASK-02 P0 教训）。
    engagedExit: 16,
};

/** 同威胁重派冷却（ms，设计 §1.3）。 */
export const THREAT_COOLDOWN_MS = 3000;

/** 苦力怕常数〔wiki·Creeper，已核〕：3 格内起爆（需全程视线）/ fuse 1.5s / 拉开 7 格取消引爆。 */
export const CREEPER = {
    fuseTicks: 30,
    fuseMs: 1500,
    detonateRange: 3,      // 玩家进入此距离且有视线 → 开始膨胀
    defuseRange: 7,       // 玩家拉开到此距离外 → 取消引爆
    trackRange: 16,       // 跟踪半径
    blastPower: 3,
    maxDamageEasy: 22.5,  // 〔wiki·Creeper〕Easy 中心最大伤
    // 膨胀是**可见的**：1.16.1 里 creep 的 width 普通态 0.6、膨胀态 1.3
    // 〔wiki·Creeper / EntityType 尺寸〕。⚠ **该判据在 1.16.1 客户端实测不可用**：
    //   微基准 MIC_CREEPER_SMOKE 三局实测 98s 内 width 恒为 0.6，而 creep 照常 fuse 并炸
    //   （见 docs/MC-M1-TASK-07.md §4.7 bug#9）。保留数值只作历史记录，**不再用于判定**。
    fusedHalfWidth: 0.95,
    baseHalfWidth: 0.6,
    stillSpeed: 0.12,     // 速度低于此值算"站住不动"（fuse 期间不再移动）
    // —— 替代判据：实体元数据（设计会话 10-02 夜给的计数链）——
    //   Entity 0–6 / LivingEntity 7–13 / Mob 14 ⇒ CreepEntity 的第一个索引是 **15**，
    //   对应 `DATA_ID_SWELL_DIR`（-1/0 不膨胀，1 膨胀）。⚠ 索引是**待阳性对照的假设**：
    //   `analyzeFuseTrace()` 从实测轨迹里反推到底是哪个索引在变，对上了才用它做判定。
    fuseMetaIndex: 15,
    // 撤退几何（设计会话 10-02 夜裁决 2：先改再测，不测"现状"）：
    //   defuseRange 7 是 wiki 的取消引爆距离（判据），但**落点要留余量**：目标 ≥9 格，
    //   到位判据用**实际水平距离 ≥7.5**（不以 navTo 的返回为准），没到就继续撤。
    //   理由：navTo 用 GoalNear(...,1) 允许差 1 格停 ⇒ 按 7 格选点、实际只能到 ~6.6，
    //   而 creep 只要进 3 格就开始 fuse（MIC_CREEPER_SMOKE 三局 10 点血）。
    retreatTargetRange: 9,
    safeRangeCheck: 7.5,
};

/** 末影人常数〔wiki·Enderman，已核；Goal 家族〔映射〕EndermanLookForPlayerGoal / EndermanFreezeWhenLookedAt〕。 */
export const ENDERMAN = {
    aggroRange: 64,       // 64 格内注视眼睛 5t 激怒
    aggroTicks: 5,
    height: 2.9,          // 碰撞箱 2.9 格 ⇒ 需要 2 格高掩体才躲得掉
    teleRange: 4,         // < 4 格对视 → 触发传送（贴脸反而会被传走）
    damageEasy: 4.5,
    // 设计 §1.4：lookAt 前的夹角闸门。**10° → 15°（第八轮，几何推导见报告 §4.17）**。
    //   模型（平地同高）：bot 眼位 = 站位 y + 1.62；末影人眼位 = 站位 y + 2.9×0.9 ⇒ Δy = 0.99。
    //   平视（pitch=0）时夹角 deg = atan(0.99 / d_水平)，**deg 随 d 递减**。
    //   阳性对照：d=6 ⇒ atan(0.99/6) = 9.3695°，与第六轮真服实测 deg=9.37° 吻合到 0.005°。
    //   下限推导：4–16 格全程不漏判 ⇒ θ ≥ 13.90°（d=4 最严，deg=13.90）；
    //   再加 `bot.look` 的灵敏度量化步长 0.15° Notchian（逐轴残差 ≤0.075°、角误差 ≤0.11°）
    //   ⇒ 下限 14.01° ⇒ 取 **15°**，留约 1° 余量（覆盖末影人位置/height 元数据抖动）。
    // ⚠⚠ **先决条件（已满足）**：lookVector 的 y/z 符号必须先修好（第七轮 e034c09）。
    //   符号没修时 z 反号会让"末影人在**背后**"也算成在盯 ⇒ 守卫拦下 lookAt、
    //   退路只压俯仰不动 yaw ⇒ **永久闩锁**（64 格内末影人大致在前方时所有 lookAt 全被吞）。
    //   T15 有"退路之后必须能重新进入守卫"的回归锁，闩锁一旦复活立刻红。
    // ⚠ **已知残留缺口（留给设计会话，本轮不自行扩大范围）**：平视且 d ≤ 0.99/tan15° = 3.70 格时
    //   deg ≥ 15° 仍判"不盯"。这是"θ 单值"模型的固有代价（近端反而更宽松）。
    gazeGuardDeg: 15,
};

/** 武器优先级（设计 §2.1；AltoClef MobDefenseChain SWORDS 同序）。 */
export const WEAPON_PRIORITY = [
    'iron_sword', 'stone_sword', 'wooden_sword',
    'iron_axe', 'stone_axe', 'wooden_axe',
];

/** 攻击冷却出手门限（设计 §2.1：AltoClef 同款「冷却 ≥0.99 才攻击」）。 */
export const ATTACK_COOLDOWN_GATE = 0.99;

/** 近战接战距离（格，设计 §2.1「LOS 且 <3.2 格中最近者」）。 */
export const MELEE_RANGE = 3.2;

/** 撤退线血量（格/点）：hp<8 停手撤退（设计 §2.1，与 stage-03/rmalde 同口径）。 */
export const RETREAT_HP = 8;

/** 脱离距离（格）：撤退后要真的脱身到这个距离（设计 §2.3/§3.4）。 */
export const DISENGAGE_RANGE = 24;

/**
 * 主世界威胁表（设计 §1.1，排序：苦力怕>骷髅>僵尸>蜘蛛>溺尸>末影人）。
 * level   = 该威胁**静态最高级**（实际分级还要叠加距离/视线，见 classify()）
 * action  = 默认处置键，对应 defense/responses.js 里的实现
 */
export const OVERWORLD_THREATS = {
    creeper: {
        name: 'creeper', display: '苦力怕', level: THREAT_LEVEL.EMERGENCY,
        action: 'creeper',
        params: CREEPER,
        // 「永不允许 <6 格停留」＝静态 EMERGENCY；实测中 3 格内且有视线是最危险
        neverLingerUnder: 6,
        note: '已膨胀→立即后撤至 7 格外或贴脸击杀（击退打断），按血量二选一',
    },
    skeleton: {
        name: 'skeleton', display: '骷髅', level: THREAT_LEVEL.ENGAGED,
        action: 'skeleton',
        // 侦测/射速未核验；AltoClef 经验 annoyingRange=18
        annoyingRange: 18, unverified: ['detectRange', 'fireRate'],
        note: '掩体优先：断视线→盾掩护直线拉近→近战；无盾无掩体不接战',
    },
    zombie: {
        name: 'zombie', display: '僵尸', level: THREAT_LEVEL.ENGAGED,
        action: 'melee',
        unverified: ['damageEasy'],
        note: '近战常规（MeleeTick），背靠墙防击退；日光燃烧自清',
    },
    zombie_villager: {
        name: 'zombie_villager', display: '僵尸村民', level: THREAT_LEVEL.ENGAGED,
        action: 'melee', note: '与 zombie 同处置（近战常规）',
    },
    spider: {
        name: 'spider', display: '蜘蛛', level: THREAT_LEVEL.MONITORED,
        action: 'melee',
        note: '白天光照高时中立；easy 下普通蜘蛛无毒。开阔地近战，避免狭窄通道交战',
    },
    drowned: {
        name: 'drowned', display: '溺尸', level: THREAT_LEVEL.MONITORED,
        action: 'melee',
        note: '不在水里决战：岸边等它靠岸或绕行',
    },
    enderman: {
        name: 'enderman', display: '末影人', level: THREAT_LEVEL.MONITORED,
        action: 'gaze', params: ENDERMAN,
        note: '不注视（见 gaze_guard.js）；被激怒→钻 2 格高掩体或入水；不主动接战',
    },
};

/**
 * 下界威胁表（设计 §1.2）——**只登记，不实现**（任务单 §1 末句）。
 * `implemented: false` 是硬标记：classify() 永远不会把它们派发出去，
 * S2/S3 接手时把对应 action 实现掉并改标记即可。
 */
export const NETHER_THREATS = {
    ghast: { name: 'ghast', display: '恶魂', level: THREAT_LEVEL.ENGAGED, action: 'ghast', implemented: false, unverified: ['detectRange'], note: '火球可盾挡；断视线优先、盾朝火球方向、不追击' },
    blaze: { name: 'blaze', display: '烈焰人', level: THREAT_LEVEL.ENGAGED, action: 'melee', implemented: false, note: '复用 MeleeTick + stage-03 扩展（近战 3.2 格/举盾挡三连/平台纪律）' },
    magma_cube: { name: 'magma_cube', display: '岩浆怪', level: THREAT_LEVEL.MONITORED, action: 'melee', implemented: false, unverified: ['splitOnDeath'], note: '同近战模式；窄道不打大体型' },
    hoglin: { name: 'hoglin', display: '疣猪兽', level: THREAT_LEVEL.EMERGENCY, action: 'avoid', implemented: false, note: '保持 ≥8 格绕行；不进绯红森林；被顶飞走 stage-06 坠落预案' },
    piglin: { name: 'piglin', display: '猪灵', level: THREAT_LEVEL.MONITORED, action: 'piglin', implemented: false, note: '≥1 件金装即中立；无金装时 ≥15 格绕行；开箱/挖金前置「确认 24 格无猪灵」' },
    zombified_piglin: { name: 'zombified_piglin', display: '僵尸猪灵', level: THREAT_LEVEL.ENGAGED, action: 'melee', implemented: false, note: '愤怒时成群（3~4 只一组攻击），按多只围攻走卡口逐只打' },
    piglin_brute: { name: 'piglin_brute', display: '猪灵蛮兵', level: THREAT_LEVEL.EMERGENCY, action: 'avoid', implemented: false, note: '不会中立化；无金装时一律绕行' },
};

/** 维度 → 威胁表。1.16.1 的 dimension id：0 主世界 / -1 下界 / 1 末地。 */
export const DIMENSION_TABLES = {
    overworld: OVERWORLD_THREATS,
    nether: NETHER_THREATS,
};

/** 把 mineflayer 的 dimension id 映射到表名。未知维度按主世界表（保守：更严）。 */
export function tableForDimension(dimensionId) {
    if (dimensionId === -1) return { name: 'nether', table: NETHER_THREATS };
    if (dimensionId === 1) return { name: 'end', table: OVERWORLD_THREATS }; // 末地复用表（龙/末影人条目本单不派发）
    return { name: 'overworld', table: OVERWORLD_THREATS };
}

/** 该实体名在本维度是否是"我们要管"的敌对实体。 */
export function isHostile(name, dimensionId = 0) {
    const { table } = tableForDimension(dimensionId);
    return Object.prototype.hasOwnProperty.call(table, name);
}

/** 已实现处置动作的条目（implemented !== false）。 */
export function actionable(name, dimensionId = 0) {
    const { table } = tableForDimension(dimensionId);
    const def = table[name];
    return !!def && def.implemented !== false;
}

export function threatDef(name, dimensionId = 0) {
    const { table } = tableForDimension(dimensionId);
    return table[name] ?? null;
}

/**
 * 分级：距离 + 视线 + 威胁静态级 → 最终档位。
 *
 * @param {object} p
 * @param {number} p.distance  bot 眼位 → 实体眼位（格）
 * @param {boolean} p.los      是否有视线（设计 §1.3 体素射线判据）
 * @param {boolean} [p.fusing]  苦力怕已膨胀（决定是否抢占最高优先级）
 * @param {number} [p.dimensionId]
 * @param {object} [opts]
 * @param {boolean} [opts.losStrict=true]  公平口径（任务单硬要求 3）：true = 无视线
 *        的实体一律不产生任何反应（连 MONITORED 都不登记）。默认开。
 * @param {number} [opts.engagedExit]       迟滞退出阈值（默认 THREAT_RANGE.engagedExit）
 * @returns {{level:number, reason:string}|null} null = 不构成威胁
 */
export function classify({ distance, los, fusing = false, dimensionId = 0 }, opts = {}) {
    const losStrict = opts.losStrict !== false;
    const engagedExit = opts.engagedExit ?? THREAT_RANGE.engagedExit;
    // 苦力怕 fuse 加权（AltoClef getCreeperSafety 思想：膨胀中的苦力怕在排序里跳最高）
    if (fusing && distance <= CREEPER.defuseRange && los) {
        return { level: THREAT_LEVEL.EMERGENCY, reason: 'creeper_fusing' };
    }
    if (losStrict && !los) {
        // 无视线：按公平口径不反应。仍返回 MONITORED 只在 opts.losStrict=false 时发生。
        return { level: THREAT_LEVEL.MONITORED, reason: 'no_los' };
    }
    if (distance < THREAT_RANGE.emergency) {
        return { level: THREAT_LEVEL.EMERGENCY, reason: 'too_close' };
    }
    // 迟滞：已在 ENGAGED 的实体，退出要退到 engagedExit 之外
    const engagedGate = opts.engagedExitApplied ? engagedExit : THREAT_RANGE.engaged;
    if (distance < engagedGate) {
        return { level: THREAT_LEVEL.ENGAGED, reason: 'in_engaged_range' };
    }
    if (distance < THREAT_RANGE.monitored) {
        return { level: THREAT_LEVEL.MONITORED, reason: 'in_monitored_range' };
    }
    return null;
}

/**
 * 苦力怕"已膨胀"判据（设计 §1.3 备选：3 格内 + 速度≈0 + 包围盒变大）。
 * 1.16.1 的 creeper metadata 膨胀位**未核验**，本单用可离线验证的视觉量：
 * 包围盒半宽（bot.entity 暴露 width/height，膨胀时 0.6→1.3）。
 */
export function creeperFusing(entity, now = Date.now()) {
    if (!entity) return false;
    const w = Number(entity.width ?? CREEPER.baseHalfWidth);
    const speed = Math.hypot(entity.velocity?.x ?? 0, entity.velocity?.z ?? 0);
    const still = speed < CREEPER.stillSpeed;
    // fuse 开始于"玩家 3 格内 + 有视线"，此刻 creep 一般已站定；两个条件都满足才判，
    // 避免"远处一只站着的苦力怕"被误报成正在爆炸（那会让 500ms 扫描一直 EMERGENCY）。
    return (w * 2 >= CREEPER.fusedHalfWidth * 2) && still && !!entity.__inFuseRange;
}

/**
 * 从实测元数据轨迹里**反推**到底是哪个索引在膨胀时变化（阳性对照，纯函数、可离线单测）。
 *
 * 为什么需要它：设计给的"metadata[15]"是**按 E 线龙相位的计数链推算的假设**
 * （Entity 0–6 / LivingEntity 7–13 / Mob 14 ⇒ CreepEntity 首索引 15）。假设必须被数据验证：
 * 若真机上变化的是别的索引，照抄 15 就会得到一个"永远读到 0"的假判据 ——
 * 和 width 判据一样静默。
 *
 * @param {Array<{meta:Array<number|null>, dist:number, ms:number}>} trace 时间序采样
 * @returns {{changed:Array, best:object|null, hypothesis15:boolean}}
 *   changed: 每个"在 creep 消失前发生变化"的索引（含首次变化时刻与当时距离）
 *   best:    变化最像 fuse 的那个（首次变化时距离最小 ⇒ 最可能是"进 3 格开始膨胀"）
 *   hypothesis15: 设计给的 15 号假设是否被数据支持
 */
export function analyzeFuseTrace(trace) {
    const rows = (trace || []).filter((r) => Array.isArray(r?.meta));
    if (rows.length < 2) return { changed: [], best: null, hypothesis15: false, samples: rows.length };
    const first = rows[0].meta;
    const len = Math.max(...rows.map((r) => r.meta.length));
    const changed = [];
    for (let i = 0; i < len; i++) {
        const v0 = first[i] ?? null;
        let flip = null;
        for (let k = 1; k < rows.length; k++) {
            const v = rows[k].meta[i] ?? null;
            if (v !== v0) { flip = { index: i, from: v0, to: v, atMs: rows[k].ms, dist: rows[k].dist }; break; }
        }
        if (flip) changed.push(flip);
    }
    // "最像 fuse" = 首次变化时 creep 离 bot 最近的那个（进 3 格才开始膨胀 ⇒ 距离小）
    const best = changed.length
        ? changed.slice().sort((a, b) => (a.dist ?? 999) - (b.dist ?? 999))[0]
        : null;
    const h15 = changed.find((c) => c.index === CREEPER.fuseMetaIndex) || null;
    return {
        samples: rows.length, changed, best,
        hypothesis15: !!h15,
        hypothesis15Detail: h15,
        note: '宽度判据在 1.16.1 客户端实测不变，故只能用元数据；索引以本函数反推为准',
    };
}

/** creep 膨胀的**元数据**判据（阳性对照通过后启用；未通过时恒 false，绝不当成"没膨胀"）。 */
export function creeperFusingMeta(entity) {
    const md = entity?.metadata;
    if (!Array.isArray(md) || md.length <= CREEPER.fuseMetaIndex) return null;
    return Number(md[CREEPER.fuseMetaIndex]) === 1;
}

/**
 * creep 膨胀判据**总入口**（三处调用点统一走它，避免各处各写一套）：
 *   1. **元数据 [15] 优先**（SWELL_DIR：-1/0 不膨胀、1 膨胀）。
 *      阳性对照实测（MIC_FUSEPROBE，1.16.1 客户端）：creep 走到 **2.92 格**那一刻
 *      15 号由 -1 翻成 1；同一时刻 14 号也变（4→0）。**width 全程恒 0.6** ⇒ 宽判据不可用。
 *   2. 读不到元数据 ⇒ 返回 false（= 未知时**不**当成"已膨胀"），
 *      由 `classify` 的 **<6 格 EMERGENCY 兜底**接手，不会漏也不会误判。
 * ⚠ 这里刻意不接"width 兜底"：实测它恒 0.6，接上等于给一个永远为假的信号，
 *   会让人以为"有兜底"而放松对元数据缺失的处理。
 */
export function creeperFusingNow(entity) {
    const meta = creeperFusingMeta(entity);
    if (meta != null) return meta;
    return false;
}

/** 从 creep 的包围盒反推是否已膨胀（**1.16.1 实测不可用**，保留仅供历史对照）。 */
export function creeperLooksFused(entity) {
    if (!entity) return false;
    return Number(entity.width ?? 0) >= CREEPER.fusedHalfWidth;
}
