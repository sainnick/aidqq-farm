// progress_checker.js — MC-M1-TASK-01 双维度进度检查器
//
// PORT 自 AltoClef MovementProgressChecker（MIT）思想：位移阈值 + 任务进度双阈值。
// 关键修正（任务书 §5）：bot 在动 ≠ 任务有进展。游走/换区长距离移动会让
// 「只看位移」的 watchdog 永远以为有进展——所以软卡死判定以【任务进度签名】为主维度，
// 位移只作为辅助信号（物理卡墙）。
//
//   movement progress：坐标变化（辅助维度）
//   task progress    ：progressSignature 变化（背包数/候选数/搜索半径/已挖块数/到目标距离）主维度
//
//   soft stuck：有动作但任务指标长期不涨（或物理卡住）→ 消费方自行恢复：清局部状态/换目标/扩搜索
//   hard stuck：连续多轮恢复仍无进展 → 任务 FAILED(NO_PROGRESS)，向上返回原因，禁止死循环

import { sleep } from './task.js';

export class ProgressChecker {
    constructor(task, ctx, opts = {}) {
        this.task = task;
        this.ctx = ctx;
        this.tickMs = opts.tickMs ?? 500;
        this.moveDist = opts.moveDist ?? 0.1;        // 位移阈值（格）
        this.moveWindowMs = opts.moveWindowMs ?? 10000;  // 完全没动的观察窗
        this.taskWindowMs = opts.taskWindowMs ?? 25000;  // 任务签名冻结观察窗（主判据）
        this.hardWindowMs = opts.hardWindowMs ?? 75000;  // 任务签名冻结超时 → 直接 hard
        this.maxRecoveries = opts.maxRecoveries ?? 4;    // 软恢复次数上限
        this.reset();
    }

    reset() {
        this.lastPos = null;
        this.lastMoveAt = Date.now();
        this.lastSig = null;
        this.lastProgressAt = Date.now();
        this.lastRecoveryAt = null;
        this.recoveries = 0;
        this.softPending = false;
        this.hardFired = false;
        this._lastTickAt = Date.now();
    }

    update(ctx) {
        const now = Date.now();
        const dt = now - this._lastTickAt;
        this._lastTickAt = now;
        const counters = ctx.run.counters;
        const bot = ctx.bot;

        // —— movement 维度 ——
        const pos = bot.entity?.position;
        if (pos) {
            if (!this.lastPos) this.lastPos = pos.clone();
            else if (pos.distanceTo(this.lastPos) >= this.moveDist) {
                this.lastPos = pos.clone();
                this.lastMoveAt = now;
            }
        }
        // idle 统计：没动且没在挖
        if (pos && (!this.lastPosMoved(now)) && !bot.targetDigBlock) counters.idleMs += dt;

        // —— task 维度（主判据）——
        let sig = '';
        try { sig = String(this.task.progressSignature(ctx)); } catch { sig = ''; }
        if (sig !== this.lastSig) {
            const firstSig = this.lastSig === null;
            this.lastSig = sig;
            this.lastProgressAt = now;
            this.recoveries = 0;
            this.lastRecoveryAt = null;
            this.softPending = false;
            if (!firstSig) counters.taskProgressSteps++;
        }

        // —— 判定（只在任务未完结时打标）——
        if (this.task.isComplete()) return;
        const frozenFor = now - this.lastProgressAt;
        const idleFor = now - this.lastMoveAt;

        if (frozenFor > this.hardWindowMs
            || (this.recoveries >= this.maxRecoveries && this.lastRecoveryAt && now - this.lastRecoveryAt > this.taskWindowMs)) {
            this.hardFired = true;
            counters.hardStuck++;
            ctx.telemetry('hard_stuck', { task: this.task.id, frozenFor, recoveries: this.recoveries });
            return;
        }
        const graceOver = this.lastRecoveryAt === null || now - this.lastRecoveryAt > this.taskWindowMs;
        if (!this.softPending && graceOver) {
            // 触发 A（主）：任务签名冻结超窗——哪怕 bot 在动（游走/绕圈）也算卡死
            // 触发 B（辅）：物理卡住——位移与任务双停
            if (frozenFor > this.taskWindowMs || (idleFor > this.moveWindowMs && frozenFor > this.moveWindowMs)) {
                this.softPending = true;
                counters.softStuckEvents++;
                ctx.telemetry('soft_stuck', { task: this.task.id, frozenFor, idleFor, recoveries: this.recoveries });
            }
        }
    }

    lastPosMoved(now) { return now - this.lastMoveAt < this.tickMs * 2; }

    // —— 消费接口（driver / 任务通过 ctx.stuck 调用）——
    // 有待处理的 soft stuck 信号？消费即记账一次恢复（恢复后给一个窗口的宽限）
    consumeSoftStuck() {
        if (!this.softPending) return false;
        this.softPending = false;
        this.recoveries++;
        this.lastRecoveryAt = Date.now();
        this.lastMoveAt = Date.now(); // 恢复动作（走两步）不应立刻再触发物理卡死
        this.ctx.run.counters.recoveries++;
        return true;
    }

    hardStuck() { return this.hardFired; }
}

// 独立采样器：task.tick 可能长时间 await（导航/挖掘），检查必须异步于任务循环
export async function runChecker(checker, ctx) {
    while (!checker._stopped) {
        await sleep(checker.tickMs);
        try { checker.update(ctx); } catch { /* 采样失败不影响任务 */ }
    }
}
