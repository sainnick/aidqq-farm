// nav.js — MC-M1-TASK-01 导航原语（PRIMITIVE 层）
//
// 全部导航必带超时：pathfinder 挂死不得拖垮任务循环（spike 教训 + 任务书 §9 死循环=0）。
// 超时后必须 pathfinder.stop()，让被抛弃的 goto promise 尽快收敛（防孤儿拒绝崩进程）。
//
// MC-M1-TASK-06b：导航岩浆护栏。T06I2 t10/t13 两例 "tried to swim in lava" 离线归因同根因：
// pathfinder 不避岩浆（RESEARCH-01 生态结论 #141），两局都死在 navTo 寻路途中（t10 死于
// 接近洞沿悬空铁矿标的途中，t13 死于 collect_nav 25s 寻路途中，与 nav_fail 相差 0.5s）。
// await 导航期间 5Hz 采样：相邻（同层/下一层）出现岩浆、脚下 1 格是岩浆、或前方悬空且
// 2..4 格下方是岩浆 → 立即停导航判失败。宁绕路不进浆；上层按普通 nav 失败拉黑/换候选。
// 只在 navTo 生效——已验收的下挖步进器（自有六面闸）与分支掘进（手动推进）不经此处。

import pf from 'mineflayer-pathfinder';
import { sleep } from './task.js';

const LAVAguard_DIRS4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];

function lavaNear(ctx) {
    const bot = ctx.bot;
    const p = bot.entity?.position?.floored();
    if (!p) return null;
    // 运动方向感知（MC-M1-TASK-06b 迭代 2）：同层邻块岩浆只有在运动方向上才算逼近
    //（走近才拦，侧翼路过不拦）——v1 的「四邻 ANY 命中即拦」会把岩浆湖区侧翼的合法
    // 逃生导航也全拦死（T06B3DEV1b T06F-02 实证：矿带落点被岩浆湖环抱时 wander 全被
    // 护栏否决 → tunnel 原地 stall 死循环 → NO_RESOURCE_FOUND）。层下邻块（dy=-1，
    // 跨步会踏进）与脚下悬空下看岩浆（坠落向）无条件拦截。
    const v = bot.entity?.velocity;
    const moving = !!v && (Math.abs(v.x) + Math.abs(v.z)) > 0.05;
    const inDirection = (q) => {
        if (!moving) return false;
        const dx = q.x - p.x, dz = q.z - p.z;
        return dx * v.x + dz * v.z > 0;
    };
    const lavaAt = (q, strict) => {
        try {
            const b = bot.blockAt(q);
            if (!b || b.name !== 'lava') return null;
            if (strict && !inDirection(q)) return null;
            return [q.x, q.y, q.z];
        } catch { return null; }
    };
    for (const [dx, dz] of LAVAguard_DIRS4) {
        const hit = lavaAt(p.offset(dx, -1, dz), false);       // 层下邻块：无条件
        if (hit) return hit;
    }
    for (const [dx, dz] of LAVAguard_DIRS4) {
        const hit = lavaAt(p.offset(dx, 0, dz), true);         // 同层邻块：仅运动方向
        if (hit) return hit;
    }
    // 前方悬空（走洞沿/悬崖）→ 往下看 2..4 格有没有岩浆湖（t10 场景：标的底面就是洞穴）
    try {
        const below = bot.blockAt(p.offset(0, -1, 0));
        if (below && below.boundingBox !== 'block') {
            for (let k = 2; k <= 4; k++) {
                const hit = lavaAt(p.offset(0, -k, 0), false);
                if (hit) return hit;
            }
        }
    } catch { /* 区块未加载时保守放行 */ }
    return null;
}

// MC-M1-TASK-06b 迭代 2：护栏撤离。急停挡不住已带速度的 bot（DEV2 T06F-03 实证：
// 连续 3 次 guard 拦截后 bot 仍凭惯性/滑落进浆死亡）——命中后立刻向岩浆反方向
// 撤 3-5 格（无护栏短导航，best-effort 3s；已在浆里则放弃）。
async function retreatFromLava(ctx, lavaAt) {
    const bot = ctx.bot;
    try {
        const p = bot.entity.position.floored();
        if (bot.blockAt(p)?.name === 'lava' || bot.entity.isInLava) return; // 已进浆：撤无可撤
        const dx = p.x - lavaAt[0], dz = p.z - lavaAt[2];
        const len = Math.hypot(dx, dz) || 1;
        const tx = Math.round(p.x + (dx / len) * 4);
        const tz = Math.round(p.z + (dz / len) * 4);
        bot.pathfinder.setMovements(new pf.Movements(bot));
        const goal = new pf.goals.GoalNear(tx, p.y, tz, 2);
        bot.pathfinder.setGoal(goal);
        await Promise.race([
            bot.pathfinder.goto(goal).catch(() => {}),
            sleep(3000),
        ]);
        try { bot.pathfinder.stop(); bot.clearControlStates(); } catch { /* 忽略 */ }
        ctx.telemetry('nav_lava_retreat', { lavaAt, to: [tx, p.y, tz] });
    } catch { /* 撤离失败不影响返回 false 的主流程 */ }
}

export async function navTo(ctx, goal, opts = {}) {
    const bot = ctx.bot;
    const label = opts.label ?? 'nav';
    const timeoutMs = opts.timeoutMs ?? 60000;
    const lavaGuard = opts.lavaGuard !== false; // 默认开；确知安全的短挪可用 false 关
    const t0 = Date.now();
    ctx.run.counters.navAttempts++;
    bot.pathfinder.setMovements(new pf.Movements(bot));
    bot.pathfinder.setGoal(goal);
    const gotoP = bot.pathfinder.goto(goal);
    gotoP.catch(() => {}); // 超时/护栏弃单后拒绝不再冒泡
    try {
        let guardDone = false;
        let lavaAt = null;
        const guardP = lavaGuard
            ? (async () => {
                while (!guardDone) {
                    await sleep(200);
                    if (guardDone) return 'never';
                    lavaAt = lavaNear(ctx);
                    if (lavaAt) {
                        ctx.telemetry('nav_lava_guard', {
                            label, lavaAt,
                            bot: (() => { const q = bot.entity.position.floored(); return [q.x, q.y, q.z]; })(),
                        });
                        try { bot.pathfinder.stop(); bot.clearControlStates(); } catch { /* 忽略 */ }
                        guardDone = true;
                        return 'lava';
                    }
                }
                return 'never';
            })().catch(() => 'never')
            : null;
        const winner = await Promise.race([
            gotoP.then(() => 'ok'),
            sleep(timeoutMs).then(() => 'timeout'),
            ...(guardP ? [guardP] : []),
        ]);
        guardDone = true;
        if (winner === 'ok') {
            ctx.run.counters.phaseMs.nav += Date.now() - t0;
            return true;
        }
        if (winner === 'lava') {
            // 撤离串行在返回前：调用方拿到 false 后会立刻发起下一拍导航，
            // 不能让撤离和它抢 pathfinder（DEV2 T06F-03 惯性进浆的补充修复）
            await retreatFromLava(ctx, lavaAt);
        } else {
            try { bot.pathfinder.stop(); bot.clearControlStates(); } catch { /* 忽略 */ }
        }
        ctx.run.counters.navFailures++;
        ctx.run.counters.phaseMs.nav += Date.now() - t0;
        ctx.telemetry('nav_fail', { label, error: winner === 'lava' ? 'lava_guard' : 'nav_timeout', lavaAt, ms: Date.now() - t0 });
        return false;
    } catch (e) {
        bot.pathfinder.stop();
        ctx.run.counters.navFailures++;
        ctx.run.counters.phaseMs.nav += Date.now() - t0;
        ctx.telemetry('nav_fail', { label, error: String(e).slice(0, 120), ms: Date.now() - t0 });
        return false;
    }
}

export function stopNav(bot) {
    try { bot.pathfinder.stop(); bot.clearControlStates(); } catch { /* 未加载时忽略 */ }
}
