// crafting_task.js — MC-M1-TASK-02 Task: Crafting（合成任务）
//
// 职责不是「调一次 bot.craft()」（任务书 §2）：给定目标物品与数量，自动判断缺料，
// 按 RecipeResolver 的扁平计划递归满足最低必要依赖（缺原木→Acquire 子任务），
// 再完成合成。全程本地闭环，不询问 LLM。
//
// 阶段机：
//   plan    → 解析计划（resolver.plan；失败 = RECIPE_NOT_FOUND / DEPENDENCY_CYCLE /
//             DEPENDENCY_UNSUPPORTED / DEPENDENCY_TOO_DEEP，全部结构化直报）
//   gather  → 按序执行步骤：acquire → runChild(AcquireResourceTask)；
//             craft → 选变体（bot.recipesFor 的库存校验=「当前背包够料」真值）→ 合成。
//             需 3x3 的配方先 ensureStation（就近工作台导航 / 无则放置包里的）
//   reclaim → 若本任务自己放了工作台 → 挖回背包（材料循环利用；best-effort 不影响成败）
//
// 失配自愈：规划是库存快照上的推演，执行会漂移（异型原木、死亡清包）。craft 缺料 /
// acquire 子任务失败 → 有界 replan（重新解析计划，默认 6 次；每次 replan 前置的
// acquire 必然净增材料，故必然收敛）。replan 耗尽 → CRAFT_FAILED / DEPENDENCY_FAILED。
//
// 工作台生命周期（任务书 §8）：合成→找安全邻近格→放置→方块级验证（没放成功绝不
// 继续 craft：验证不过换格重试，耗尽=PLACEMENT_FAILED）→打开 craft→完成→回收。
//
// 来源：AltoClef（MIT）CraftTask / RecipeTask 的「目标物→递归补料」思想级 PORT；
// 配方数据与执行通道 = prismarine-recipe + mineflayer craft（同源，无第二套配方表）。

import { ExecTask, FailReason, sleep, countItems, posKey } from './task.js';
import { runChild } from './task_stack.js';
import { RecipeResolver } from './recipe_resolver.js';
import { RESOURCES, logFamilyFor } from './resources.js';
import { AcquireResourceTask } from './acquire_resource_task.js';
import { SmeltTask } from './smelt_task.js';
import { navTo, stopNav } from './nav.js';
import { placeItem } from './place.js';
import pf from 'mineflayer-pathfinder';
import prismarineItem from 'prismarine-item';
import { Vec3 } from 'vec3';

const RESOURCES_LOGS = RESOURCES.log.drops;   // 木板改型用的原木清单（超集；按版本过滤见 _logFamilyFor）

const AIR = new Set(['air', 'cave_air', 'void_air']);
const LIQUIDS = new Set(['lava', 'water']);
const REPLACEABLE = new Set(['air', 'cave_air', 'void_air', 'water', 'grass', 'tall_grass', 'fern', 'snow', 'dead_bush']);

function withTimeout(p, ms, tag) {
    return Promise.race([p, sleep(ms).then(() => { throw new Error(tag ?? 'timeout'); })]);
}

// 1.17+ 的 window_click 带 stateId（_tableCraft 靠它做窗口状态跟踪）；1.16.x 协议无
// stateId（走 actionId/transaction 对账），_tableCraft 的直发包语义不成立 → 回退 bot.craft
//（mineflayer 在 1.16 上的经典稳定路径，MC-M1-TASK-03 G2 探针实证后定案）。
// 未知版本按 1.21 处理（保持 TASK-02 已验证行为）。
function supportsWindowStateId(registry) {
    const m = /^1\.(\d+)/.exec(String(registry?.version?.majorVersion ?? ''));
    return m ? Number(m[1]) >= 17 : true;
}

function inventorySnapshot(bot) {
    const inv = {};
    for (const it of bot.inventory.items()) inv[it.name] = (inv[it.name] ?? 0) + it.count;
    return inv;
}

export class CraftingTask extends ExecTask {
    constructor(opts = {}) {
        super('CraftingTask', { timeoutMs: opts.timeoutMs ?? 240000 });
        this.item = opts.item;                    // 目标物品名，如 'wooden_pickaxe'
        this.count = opts.count ?? 1;
        this.replanBudgetMax = opts.replanBudget ?? 6;
        // MC-M1-TASK-06d P1：重试预算 2→3。数据依据：06c P2B_FRESH trial_01 一局里
        // craft_fail(craft_promise_rejected) 15 次 vs craft_ok 8 次；单次尝试约 20% 概率
        // 「没到手」，3 次连败概率 0.8%，4 次 0.16%。给到 3 次是拿 1 次重试换 ~60% 的残差下降。
        this.craftRetries = opts.craftRetries ?? 3;
        this.reclaimTable = opts.reclaimTable ?? true;
        this.gatherTimeoutMs = opts.gatherTimeoutMs ?? 200000;  // 单个 acquire 步骤（换区加宽+恢复 relocate 后需更久）
        this.craftTimeoutMs = opts.craftTimeoutMs ?? 8000;      // 单次 bot.craft 基础超时（+每 op 4s）
        this.stationSearchRadius = opts.stationSearchRadius ?? 24;
        this.resolver = opts.resolver ?? null;

        this.phase = 'plan';
        this.steps = [];
        this.stepIdx = 0;
        this.replans = 0;
        this._sub = '';                // 子状态（进度签名用）
        this._activeChild = null;      // 子任务签名桥接
        this._placedTablePos = null;   // 本任务放置的工作台（reclaim 依据）
        this._ignoredTables = new Set(); // 导航到不了的外部工作台，本次任务内不再尝试
        this._reclaimDone = false;
    }

    countMet(ctx) { return countItems(ctx.bot, [this.item]) >= this.count; }

    progressSignature(ctx) {
        let childSig = '';
        try { childSig = this._activeChild ? String(this._activeChild.progressSignature(ctx)) : ''; } catch { childSig = ''; }
        return `${this.phase}|s${this.stepIdx}|${this._sub}|i${countItems(ctx.bot, [this.item])}|${childSig}`;
    }

    getProgress(ctx) {
        return {
            phase: this.phase,
            step: `${this.stepIdx}/${this.steps.length}`,
            replans: this.replans,
            inv: countItems(ctx.bot, [this.item]),
        };
    }

    async onStuck(kind, ctx) {
        if (kind !== 'soft') return;
        stopNav(ctx.bot);
        try { ctx.bot.stopDigging(); } catch {}
    }

    async cleanup(ctx) {
        stopNav(ctx.bot);
        try {
            if (ctx.bot.currentWindow && String(ctx.bot.currentWindow.type).includes('crafting')) {
                ctx.bot.closeWindow(ctx.bot.currentWindow);
            }
        } catch { /* 无窗口时忽略 */ }
    }

    async tick(ctx) {
        const bot = ctx.bot;
        try { this.resolver ??= RecipeResolver.forBot(bot); } catch (e) {
            this._fail(FailReason.INTERNAL, { error: `resolver_init: ${String(e).slice(0, 120)}` });
            return;
        }
        if (this.countMet(ctx)) { this.phase = 'reclaim'; }
        switch (this.phase) {
            case 'plan': return this._tickPlan(ctx);
            case 'gather': return this._tickGather(ctx);
            case 'reclaim': return this._tickReclaim(ctx);
            default: this._fail(FailReason.INTERNAL, { error: `unknown phase ${this.phase}` });
        }
    }

    // ---------- plan ----------
    _tickPlan(ctx) {
        ctx.run.counters.recipeResolves++;
        const bot = ctx.bot;
        const tableNearby = !!this._findTable(ctx, this.stationSearchRadius);
        const plan = this.resolver.plan(this.item, this.count, inventorySnapshot(bot), [], { tableNearby });
        if (plan.error) {
            ctx.telemetry('craft_plan_fail', { item: this.item, count: this.count, planError: plan.error, step: plan.item ?? null });
            const map = {
                DEPENDENCY_CYCLE: FailReason.DEPENDENCY_CYCLE,
                DEPENDENCY_TOO_DEEP: FailReason.DEPENDENCY_TOO_DEEP,
                DEPENDENCY_UNSUPPORTED: FailReason.DEPENDENCY_UNSUPPORTED,
                RECIPE_NOT_FOUND: FailReason.RECIPE_NOT_FOUND,
            };
            this._fail(map[plan.error] ?? FailReason.CRAFT_FAILED, { item: this.item, planError: plan.error, step: plan.item ?? null });
            return;
        }
        this.steps = plan.steps;
        this.stepIdx = 0;
        ctx.telemetry('craft_plan', {
            item: this.item, count: this.count,
            steps: plan.steps.map((s) => s.kind === 'acquire'
                ? `Acquire(${s.resource}×${s.count}${s.sideQuest ? `+${s.sideQuest.resource}×${s.sideQuest.count}` : ''})`
                : s.kind === 'smelt'
                    ? `Smelt(${s.item}→${s.target})`
                    : `Craft(${s.item}→${s.target}${s.station ? ',table' : ''})`).join(' > '),
        });
        this.phase = 'gather';
    }

    _replanOrFail(ctx, why, detail = {}, failReason = FailReason.CRAFT_FAILED) {
        this.replans++;
        ctx.run.counters.replans++;
        ctx.telemetry('craft_replan', { item: this.item, n: this.replans, why, ...detail });
        if (this.replans > this.replanBudgetMax) {
            this._fail(failReason, { item: this.item, replans: this.replans, why, ...detail });
            return;
        }
        this.phase = 'plan';
    }

    // ---------- gather ----------
    async _tickGather(ctx) {
        if (this.stepIdx >= this.steps.length) { this.phase = 'reclaim'; return; }
        const step = this.steps[this.stepIdx];
        if (step.kind === 'acquire') {
            this._sub = `acquire:${step.resource}`;
            // MC-M1-TASK-06 bug 修复（smoke3 实证，TASK-02 起潜伏）：resolver 的 acquire.count
            // 是【增量】（缺口 = need - 已有），而 AcquireResourceTask.count 是【绝对判据】
            // （手里 ≥ count 即成功）。库存有零头时（如 2/3 圆石）子任务瞬间 SUCCESS 什么都不
            // 挖 → replan 永远报缺 1 → 死循环烧光预算。修法：子任务目标 = 计划时基数 + 增量，
            // 净增量与计划账严格一致（死亡清包后 base=0，自然回退为全量采集）。
            const base = countItems(ctx.bot, RESOURCES[step.resource].drops);
            const child = await runChild(ctx, `acquire:${step.resource}`, `Acquire(${step.resource} +${step.count})`,
                () => {
                    // MC-M1-TASK-06b：sideQuest 透传（规划层把 flint 并进 iron_ore 的地下窗口，
                    // step.sideQuest 由 recipe_resolver._frontloadAcquires 产出；无则 undefined）
                    const t = new AcquireResourceTask({
                        resource: step.resource, count: base + step.count, timeoutMs: this.gatherTimeoutMs,
                        sideQuest: step.sideQuest ?? null,
                    });
                    this._activeChild = t;
                    return t;
                }, { tickMs: 200 });
            this._activeChild = null;
            this._sub = '';
            if (child.status === 'SUCCESS') { this.stepIdx++; return; }
            // 守卫拒绝（预算/环/深度）不是「这步没做好」而是「上层已裁定此依赖不可再试」，
            // replan 解决不了——立即上抛，不白烧 replan 预算（dev5：预算锁死后空转 5 轮 replan）
            if (child.failReason === FailReason.DEPENDENCY_BUDGET
                || child.failReason === FailReason.DEPENDENCY_CYCLE
                || child.failReason === FailReason.DEPENDENCY_TOO_DEEP) {
                this._fail(FailReason.DEPENDENCY_FAILED, { step: step.resource, childReason: child.failReason, guarded: true });
                return;
            }
            this._replanOrFail(ctx, 'gather_failed', { step: step.resource, childReason: child.failReason }, FailReason.DEPENDENCY_FAILED);
            return;
        }
        // MC-M1-TASK-06：熔炼步骤（计划器的 smelt 变体）→ SmeltTask 子任务。
        // 失败语义与 acquire 同款：守卫类立即上抛，其余有界 replan（计划器会补料/补炉）。
        if (step.kind === 'smelt') {
            this._sub = `smelt:${step.item}`;
            const child = await runChild(ctx, `smelt:${step.item}`, `Smelt(${step.item} →${step.target})`,
                () => {
                    const t = new SmeltTask({ item: step.item, target: step.target, timeoutMs: Math.min(this.gatherTimeoutMs, 300000) });
                    this._activeChild = t;
                    return t;
                }, { tickMs: 200 });
            this._activeChild = null;
            this._sub = '';
            if (child.status === 'SUCCESS') { this.stepIdx++; return; }
            if (child.failReason === FailReason.DEPENDENCY_BUDGET
                || child.failReason === FailReason.DEPENDENCY_CYCLE
                || child.failReason === FailReason.DEPENDENCY_TOO_DEEP) {
                this._fail(FailReason.DEPENDENCY_FAILED, { step: `smelt:${step.item}`, childReason: child.failReason, guarded: true });
                return;
            }
            this._replanOrFail(ctx, 'smelt_failed', { step: step.item, childReason: child.failReason }, FailReason.SMELT_FAILED);
            return;
        }
        // craft 步骤
        const res = await this._craftStep(ctx, step);
        if (res === 'ok') { this.stepIdx++; this._sub = ''; return; }
        if (res === 'replan') this._replanOrFail(ctx, 'craft_shortfall', { step: step.item });
        // 'fail'：_craftStep 内部已结构化失败
    }

    // ---------- craft 步骤执行 ----------
    async _craftStep(ctx, step) {
        const bot = ctx.bot;
        const reg = bot.registry;
        const variantsOf = this.resolver.recipeVariants(step.item);
        if (!variantsOf.length) { this._fail(FailReason.RECIPE_NOT_FOUND, { item: step.item }); return 'fail'; }
        let craftRetries = 0;
        let iter = 0;

        while (countItems(bot, [step.item]) < step.target && iter++ < 8) {
            // 每轮重算：木板改型会换 item；变体按当前真实库存选（recipesFor 自带库存校验，
            // 空数组 = 当前背包不够料）
            const variants = this.resolver.recipeVariants(step.item);
            const itemId = reg.itemsByName[step.item]?.id;
            if (itemId == null || !variants.length) { this._fail(FailReason.RECIPE_NOT_FOUND, { item: step.item }); return 'fail'; }
            const yieldPerCraft = variants[0].result.count;
            const needsTable = variants.some((v) => v.requiresTable);

            let recipes = bot.recipesFor(itemId, null, yieldPerCraft, null);
            let tableBlock = null;
            if (!recipes.length && needsTable) {
                tableBlock = await this._ensureStation(ctx);
                if (!tableBlock) return 'replan'; // 工作台没了/放不出 → 重新规划
                recipes = bot.recipesFor(itemId, null, yieldPerCraft, tableBlock);
            }
            // 木板改型（木板身份流体）：计划钉的木板类型与实际砍到的树种不符 →
            // 按背包里的原木改型，target 折算掉旧型已有量（dev1 教训：不改型 =
            // 永远合不出来的死结，replan 预算被白白烧光）
            if (!recipes.length && step.item.endsWith('_planks')) {
                const logName = logFamilyFor(bot.registry).find((l) => countItems(bot, [l]) > 0);
                const concrete = logName ? logName.replace('_log', '') + '_planks' : null;
                if (concrete && concrete !== step.item && reg.itemsByName[concrete]) {
                    ctx.telemetry('craft_planks_retype', { from: step.item, to: concrete });
                    step.target = Math.max(step.target - countItems(bot, [step.item]), yieldPerCraft);
                    step.item = concrete;
                    continue;
                }
            }
            if (!recipes.length) return 'replan'; // 缺料 → 重新规划（有界）
            const recipe = recipes[0];
            const remaining = step.target - countItems(bot, [step.item]);
            // 每次 bot.craft 只做 1 个 op：mineflayer 合成是客户端预测式（updateSlot 伪造结果
            // + putAway），多 op 连发时服务器会拒绝后续 op 而客户端仍报成功（dev2 实测：
            // 3 次 craft_ok 只有 1 把真镐）。单 op + 每次新鲜窗口（craft() 结束即关窗重开）
            // + 下面的增量验证，才拿得到服务器真值。
            const ops = 1;
            if (this._maxOpsForRecipe(bot, recipe) < 1 || remaining < 1) return 'replan';

            ctx.run.counters.craftAttempts++;
            this._sub = `crafting:${step.item}`;
            const before = countItems(bot, [step.item]);
            const ok = await this._doCraft(ctx, recipe, ops, tableBlock);
            await sleep(350); // 服务器同步窗口：客户端预测的假结果会被纠正回来
            const gained = countItems(bot, [step.item]) - before;
            this._sub = '';
            if (!ok || gained < ops) {
                ctx.run.counters.craftFailures++;
                craftRetries++;
                ctx.telemetry(ok ? 'craft_unverified' : 'craft_fail', {
                    item: step.item, craftRetries, gained, error: ok ? null : 'craft_promise_rejected',
                });
                if (craftRetries > this.craftRetries) {
                    this._fail(FailReason.CRAFT_FAILED, { item: step.item, craftRetries });
                    return 'fail';
                }
                await sleep(600);
            } else {
                ctx.telemetry('craft_ok', { item: step.item, gained, inv: countItems(bot, [step.item]) });
            }
            await sleep(250);
        }
        await sleep(400); // 终判前再结算一次，防幽灵库存通过验收
        if (countItems(bot, [step.item]) >= step.target) return 'ok';
        return 'replan';
    }

    _maxOpsForRecipe(bot, recipe) {
        let ops = Infinity;
        for (const d of recipe.delta) {
            if (d.count >= 0) continue;
            const name = bot.registry.items[d.id]?.name;
            const have = name ? bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0) : 0;
            ops = Math.min(ops, Math.floor(have / -d.count));
        }
        return ops === Infinity ? 0 : ops;
    }

    async _doCraft(ctx, recipe, ops, tableBlock) {
        const bot = ctx.bot;
        const timeoutMs = this.craftTimeoutMs + ops * 4000;
        // MC-M1-TASK-06d P1（工作台 3×3 静默丢件）。根因不在配方也不在材料，在
        // **mineflayer 4.38 的 craft() 收尾 grabResult()**：
        //     window.updateSlot(0, new Item(result))   ← 客户端「伪造」产物槽
        //     await bot.putAway(0)                     ← 再点一下 0 号槽拿走
        // 产物不是等服务端算出来的，中途也没有任何服务端回包把关。服务端合成格一旦和客户端
        // 以为的不一致，0 号槽就是空的，那一点就是个空点——**不抛错、背包无增量、材料没少**。
        // 实测（1.16.1，一条泳道一台服，8 格 × 30 次）：wooden_pickaxe 走工作台 30 次只有
        // 24 次拿到（06d 同一格 21/30），同批 stone_pickaxe/table 与 stick/table 都 30/30。
        // 两条修法（本单授权「仅限这一处」）：
        //   ① **按背包增量确认**，不把 craft() 的 resolve 当真值（手册 §3 的老规矩）；
        //   ② 没拿到就**关窗**，让下一次尝试用一扇全新的窗口——mineflayer 的 windowCraftingTable
        //      是模块级缓存，复用一扇和服务端已经分叉的窗口就是下一次丢件的温床。
        // 注：任务层自研的 _tableCraft（1.17+ 走它）在 1.16.1 上**发不出包**——
        //   protodef 报 `SizeOf error for undefined ... reading 'present'`：1.16.1 的 window_click
        //   里 Slot 是 {present,...} 容器，1.17+ 才是裸 NBT，toNotch() 的形状对不上。
        //   要在 1.16.1 上用自研通道，得按目标协议版本造 Slot——已记为技术债，不在本单。
        this._closeCraftWindow(bot);
        try {
            // 3x3 工作台合成通道按协议版本选择：
            //  - 1.17+：自研通道（mineflayer bot.craft 的全局 stateId 会被玩家背包的 offhand
            //    同步污染，Paper 校验 stateId 不匹配就静默丢点击——dev3/dev4 探针实证）；
            //  - 1.16.x：bot.craft 经典路径（协议无 stateId，_tableCraft 直发包不成立）。
            //  - 2x2 背包合成（window 0）两个版本都保持 bot.craft。
            if (tableBlock && supportsWindowStateId(bot.registry)) {
                const r = await withTimeout(this._tableCraft(ctx, tableBlock, recipe), 25000, 'table_craft_timeout');
                return !!r;
            }
            const itemName = bot.registry.items[recipe.result.id]?.name ?? null;
            const before = itemName ? countItems(bot, [itemName]) : 0;
            await withTimeout(bot.craft(recipe, ops, tableBlock), timeoutMs, 'craft_timeout');
            if (!itemName) return true;
            // ① 有界轮询等背包增量（服务端 set_slot / 拾取同步都可能慢半拍）
            const got = await this._waitCraftGain(bot, itemName, before, ops);
            if (got >= ops) return true;
            ctx.telemetry('craft_no_gain', { item: itemName, gained: got, expected: ops, viaTable: !!tableBlock });
            // ② 没到手：关窗（下次用新窗口），并把窗口同步问题写进遥测而不是让它静默过去
            this._closeCraftWindow(bot);
            return false;
        } catch (e) {
            ctx.telemetry('craft_error', { error: String(e && e.message ? e.message : e).slice(0, 140), viaTable: !!tableBlock });
            // 超时/抛错弃单后关掉残留合成窗口，防下次 craft 复用死窗口
            this._closeCraftWindow(bot);
            return false;
        }
    }

    /** 关掉当前打开的合成窗口（只关合成类，不碰熔炉/箱子——那些是别的任务的现场） */
    _closeCraftWindow(bot) {
        try {
            const w = bot.currentWindow;
            if (w && String(w.type).includes('crafting')) bot.closeWindow(w);
        } catch { /* 忽略 */ }
    }

    /** 有界轮询等背包增量：手册 §3「按背包增量验证」。返回实际增到的数量。 */
    async _waitCraftGain(bot, itemName, before, expect, timeoutMs = 1800) {
        const deadline = Date.now() + timeoutMs;
        let got = countItems(bot, [itemName]) - before;
        while (got < expect && Date.now() < deadline) {
            await sleep(120);
            got = countItems(bot, [itemName]) - before;
        }
        return got;
    }

    /**
     * 自研 3x3 工作台合成（单次 op）。
     * 与 mineflayer craft 的本质差别：stateId 按【窗口 ID】精确跟踪（bot.craft 用全局
     * 单变量，会被背包 offhand set_slot 污染 → Paper 丢点击），且每次点击等服务器
     * 回显再点下一个（防客户端预测与服务端状态分叉）。
     */
    async _tableCraft(ctx, tableBlock, recipe) {
        const bot = ctx.bot;
        const Item = prismarineItem(bot.registry);
        const w0 = bot.currentWindow;
        if (w0 && String(w0.type).includes('crafting')) { try { bot.closeWindow(w0); } catch { /* 忽略 */ } }
        bot.activateBlock(tableBlock);
        const w = await new Promise((res) => {
            const h = (win) => { bot.removeListener('windowOpen', h); res(win); };
            bot.on('windowOpen', h);
            setTimeout(() => { bot.removeListener('windowOpen', h); res(null); }, 5000);
        });
        if (!w || !String(w.type).includes('crafting')) {
            ctx.telemetry('table_craft_no_window', { type: w?.type ?? null });
            return false;
        }
        await sleep(250); // 等首个 window_items（初始同步）
        const session = { stateId: null };
        const onSync = (p) => { if (p.windowId === w.id) session.stateId = p.stateId; };
        bot._client.on('window_items', onSync);
        bot._client.on('set_slot', onSync);
        const waitSync = () => new Promise((res) => {
            let done = false;
            const h = (p) => {
                if (done || p.windowId !== w.id) return;
                done = true;
                bot._client.removeListener('window_items', h);
                bot._client.removeListener('set_slot', h);
                setTimeout(res, 60);
            };
            bot._client.on('window_items', h);
            bot._client.on('set_slot', h);
            setTimeout(() => { if (!done) { done = true; bot._client.removeListener('window_items', h); bot._client.removeListener('set_slot', h); res(); } }, 350);
        });
        try {
            // 直发 window_click：stateId 取本窗口最新值；changedSlots = acceptClick 预测差分
            const click = async (slot, mouseButton, mode) => {
                const before = w.slots.map((s) => (s ? `${s.type}:${s.count}` : null));
                w.acceptClick({ slot, mouseButton, mode, item: slot >= 0 ? w.slots[slot] : null });
                const changedSlots = [];
                w.slots.forEach((s, i) => {
                    const k = s ? `${s.type}:${s.count}` : null;
                    if (k !== before[i]) changedSlots.push({ location: i, item: Item.toNotch(s) });
                });
                bot._client.write('window_click', {
                    windowId: w.id,
                    stateId: session.stateId ?? 0,
                    slot, mouseButton, mode, changedSlots,
                    cursorItem: Item.toNotch(w.selectedItem),
                });
                await waitSync();
            };
            const findSrc = (typeId) => w.slots.findIndex((s, i) => s && s.type === typeId && i >= w.inventoryStart);
            // 备料：inShape 逐格放（右键放一个）；源不在手上先左键整组拿起
            const cells = [];
            if (recipe.inShape) {
                for (let y = 0; y < recipe.inShape.length; y++) {
                    for (let x = 0; x < recipe.inShape[y].length; x++) {
                        const ing = recipe.inShape[y][x];
                        const id = ing && typeof ing === 'object' ? ing.id : ing;
                        if (id != null && id !== -1) cells.push({ x, y, id });
                    }
                }
            } else if (recipe.ingredients) {
                recipe.ingredients.forEach((ing, i) => {
                    const id = ing && typeof ing === 'object' ? ing.id : ing;
                    if (id != null && id !== -1) cells.push({ x: i % 3, y: Math.floor(i / 3), id });
                });
            }
            for (const { x, y, id } of cells) {
                if (!w.selectedItem || w.selectedItem.type !== id) {
                    const src = findSrc(id);
                    if (src < 0) { ctx.telemetry('table_craft_missing_ingredient', { id }); return false; }
                    await click(src, 0, 0);
                }
                await click(1 + x + 3 * y, 1, 0);
            }
            // 手上余料放回（优先同型可堆叠槽，其次空槽；没地方就留着不 swap——swap 会拿进别的物品）
            if (w.selectedItem) {
                const cur = w.selectedItem;
                let dest = w.slots.findIndex((s, si) => si >= w.inventoryStart && s && s.type === cur.type && s.count < s.stackSize);
                if (dest < 0) dest = w.slots.findIndex((s, si) => si >= w.inventoryStart && !s);
                if (dest >= 0) await click(dest, 0, 0);
            }
            await sleep(150);
            // 抓结果：左键 s0（服务端真实结果位）→ 放进背包
            if (!w.slots[0]) { ctx.telemetry('table_craft_no_result', { grid: w.slots.slice(1, 10).map((s) => s?.name ?? null).join(',') }); return false; }
            await click(0, 0, 0);
            if (!w.selectedItem) { ctx.telemetry('table_craft_grab_fail', {}); return false; }
            const cur = w.selectedItem;
            let dest = w.slots.findIndex((s, si) => si >= w.inventoryStart && s && s.type === cur.type && s.count < s.stackSize);
            if (dest < 0) dest = w.slots.findIndex((s, si) => si >= w.inventoryStart && !s);
            if (dest < 0) { ctx.telemetry('table_craft_inventory_full', {}); return false; }
            await click(dest, 0, 0);
            return true;
        } finally {
            bot._client.removeListener('window_items', onSync);
            bot._client.removeListener('set_slot', onSync);
            try { bot.closeWindow(w); } catch { /* 忽略 */ }
        }
    }

    // ---------- 工作台生命周期（任务书 §8） ----------
    _findTable(ctx, radius) {
        const bot = ctx.bot;
        const id = bot.registry.blocksByName['crafting_table']?.id;
        if (id == null) return null;
        const found = bot.findBlocks({ matching: [id], maxDistance: radius, count: 8 })
            .filter((p) => !this._ignoredTables.has(posKey(p)))
            .sort((a, b) => bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b));
        return found.length ? bot.blockAt(found[0]) : null;
    }

    /** 返回可达的工作台 Block；拿不到则自己放一个；都失败返回 null（不抛） */
    async _ensureStation(ctx) {
        const bot = ctx.bot;
        let t = this._findTable(ctx, 4.0);
        if (!t) {
            t = this._findTable(ctx, this.stationSearchRadius);
            if (t) {
                ctx.telemetry('station_nav', { pos: [t.position.x, t.position.y, t.position.z] });
                const ok = await navTo(ctx, new pf.goals.GoalNear(t.position.x, t.position.y, t.position.z, 2),
                    { timeoutMs: 25000, label: 'to_table' });
                const near = this._findTable(ctx, 4.0);
                if (!ok || !near) {
                    // 到不了的外部台子不再试；包里有台子就自己放
                    this._ignoredTables.add(posKey(t.position));
                    return this._placeOwnTable(ctx);
                }
                return near;
            }
            return this._placeOwnTable(ctx);
        }
        return t;
    }

    async _placeOwnTable(ctx) {
        const bot = ctx.bot;
        // MC-M1-TASK-06c：整段换成共享放置原语 place.js（旧口径的扫描+8s 等 blockUpdate 已删）。
        // 旧 bug 留档：① 手持脱耦 → placeBlock 连烧 10 次 "must be holding an item" 判死任务；
        // ② 井底（垂直下挖后）挑中的参照面被井壁挡住 / 目标格其实是井壁实心格 → 服务端静默拒收，
        //    每次空等 5s，连烧 10 次 place_exhausted（06c §1：铁链每局约 10 次 place_fail 的来源）。
        // 修法见 place.js：小节可信 + 参照面从眼睛可见 + 够得着 + 不压实体，井底再挖一格壁龛，
        // 放完用 ≤1s 短轮询 blockAt 确认。失败仍不判死任务，交还上层 replan（行为不变）。
        const r = await placeItem(bot, 'crafting_table', {
            telemetry: ctx.telemetry, ctx, GoalNear: pf.goals.GoalNear, label: 'table',
            maxTries: 10, rounds: 3, confirmMs: 1000,
        });
        if (r.ok) {
            this._placedTablePos = new Vec3(r.dest.x, r.dest.y, r.dest.z);
            ctx.run.counters.tablePlacements++;
            return r.block;
        }
        if (r.reason === 'hold_fail') {
            ctx.telemetry('station_hold_fail', { item: this.item, invTable: countItems(bot, ['crafting_table']) });
            return null;
        }
        // 放置耗尽：不再 _fail(PLACEMENT_FAILED) 判死任务——交还 replan 自愈
        //（replan 预算有界；下一轮 _ensureStation 会重找台位/重放）
        ctx.run.counters.tablePlacementFailures++;
        return null;
    }

    // 手持校验 + 一次重试（SEED-02 移交 bug 的核心补丁）：equip 的窗口点击可能被静默
    // 丢弃（解析成功 ≠ 手里真的有台），placeBlock 前必须确认 heldItem 就是工作台。
    async _ensureTableInHand(ctx) {
        const bot = ctx.bot;
        for (let i = 0; i < 2; i++) {
            if (bot.heldItem?.name === 'crafting_table') return true;
            const item = bot.inventory.items().find((it) => it.name === 'crafting_table');
            if (!item) return false;
            try { await withTimeout(bot.equip(item, 'hand'), 5000, 'equip_timeout'); } catch { /* 重试一次 */ }
            await sleep(300);
        }
        return bot.heldItem?.name === 'crafting_table';
    }

    // ---------- reclaim（回收自己放的工作台，材料循环；best-effort） ----------
    async _tickReclaim(ctx) {
        const bot = ctx.bot;
        const inv = countItems(bot, [this.item]);
        const pos = this._placedTablePos;
        if (!pos || !this.reclaimTable || this._reclaimDone) {
            this._succeed({ item: this.item, count: inv, tablePlaced: !!this._placedTablePos });
            return;
        }
        this._reclaimDone = true;
        const block = bot.blockAt(pos);
        if (!block || block.name !== 'crafting_table') { this._succeed({ item: this.item, count: inv }); return; }
        try {
            if (bot.entity.position.distanceTo(pos) > 3.5) {
                const ok = await navTo(ctx, new pf.goals.GoalNear(pos.x, pos.y, pos.z, 2), { timeoutMs: 15000, label: 'reclaim_nav' });
                if (!ok) { this._succeed({ item: this.item, count: inv, reclaim: 'nav_fail' }); return; }
            }
            const before = countItems(bot, ['crafting_table']);
            await withTimeout(bot.dig(bot.blockAt(pos)), 8000, 'dig_timeout');
            // 挖完等拾取：掉落物不一定会自动碰到身上，没进包就主动走过去（dev2：400ms 干等
            // 拿不到，台子掉地上没捡回来）
            for (let w = 0; w < 5 && countItems(bot, ['crafting_table']) <= before; w++) {
                await sleep(300);
                if (w === 1) {
                    const drop = Object.values(bot.entities)
                        .find((e) => e.name === 'item' && e.position.distanceTo(bot.entity.position) < 3.5);
                    if (drop) {
                        const p = bot.pathfinder.goto(new pf.goals.GoalFollow(drop, 0.8));
                        p.catch(() => {});
                        await Promise.race([p, sleep(2500)]);
                        try { bot.pathfinder.stop(); } catch {}
                    }
                }
            }
            const after = countItems(bot, ['crafting_table']);
            ctx.telemetry(after > before ? 'table_reclaimed' : 'table_reclaim_fail', { pos: [pos.x, pos.y, pos.z] });
        } catch (e) {
            ctx.telemetry('table_reclaim_fail', { error: String(e && e.message ? e.message : e).slice(0, 100) });
        }
        this._succeed({ item: this.item, count: countItems(bot, [this.item]) });
    }
}
