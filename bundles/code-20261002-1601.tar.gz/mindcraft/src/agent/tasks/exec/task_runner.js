// task_runner.js — MC-M1-TASK-01 任务执行器（Task Runtime）
//
// driveTask：统一的任务驱动循环（根任务由 TaskRuntime 用，子任务由父任务用）。
// 职责：生命周期推进 / 超时强制 / 死亡事件分发 / 双维度卡死检测（ProgressChecker）/
//       状态迁移遥测。保证任何任务必然进入终态（任务书 §9：禁止永远 RUNNING）。
//
// TaskRuntime：一次 MISSION 的执行容器。bot 级事件（死亡/踢出）→ ctx 分发；
// 终态汇总（结构化 failure reason + 全量计数器）交给 onDone 回调。
// 零 LLM：本文件与 dm_client/decider 无任何 import 关系。

import { ExecTask, TaskStatus, FailReason, sleep } from './task.js';
import { ProgressChecker, runChecker } from './progress_checker.js';
import { TaskStack } from './task_stack.js';
import { resourceDef } from './resources.js';
import { appendFileSync, mkdirSync } from 'fs';
import { dirname } from 'path';

export function makeRunState() {
    return {
        blacklist: new Set(),   // "x,y,z" 最近失败位置（全 run 共享，参照 AltoClef MineOrCollectTask blacklist 语义）
        counters: {
            searches: 0, maxSearchRadius: 0, blockCandidates: 0,
            navAttempts: 0, navFailures: 0,
            miningAttempts: 0, successfulMines: 0,
            relocates: 0, unsafeTargets: 0,
            recoveries: 0, softStuckEvents: 0, hardStuck: 0,
            deaths: 0, taskProgressSteps: 0, idleMs: 0,
            phaseMs: { search: 0, nav: 0, mine: 0, recover: 0 },
            // —— MC-M1-TASK-02 新增 ——
            childTasks: 0, maxDepth: 0,          // 任务栈规模
            recipeResolves: 0, replans: 0,       // 配方解析 / 失配重规划
            depResolutions: 0, depResolutionFailures: 0, // 依赖自主解决率（任务书 §13）
            toolRescues: 0,                      // TOOL_MISSING → Crafting 救援次数
            craftAttempts: 0, craftFailures: 0,  // 合成动作
            tablePlacements: 0, tablePlacementFailures: 0,
            // —— MC-M1-TASK-06 新增 ——
            furnacePlacements: 0, furnacePlacementFailures: 0,  // 熔炉放置
            smeltOk: 0, smeltFailures: 0,                        // 熔炼取出/验证
            flintPlaceRedigs: 0,                                 // 沙砾重埋重挖次数
            ironTargetsSelected: 0,                              // 选中的铁矿石目标数（公平口径遥测伴随计数）
        },
    };
}

export function makeCtx(bot, { telemetry = () => {}, run = makeRunState(), stackMaxDepth } = {}) {
    return {
        bot,
        run,
        telemetry,
        stack: new TaskStack(stackMaxDepth != null ? { maxDepth: stackMaxDepth } : {}),   // MC-M1-TASK-02 父子任务机制（守卫/预算/trace）
        activeChain: [],          // 活跃任务链（driveTask 推入/弹出；祖先超时强制用）
        deathEvents: [],
        stuckEvents: [],   // [{taskId, at}] 软卡死信号（由 ProgressChecker 投递）
        takeDeath() { return this.deathEvents.shift() ?? null; },
        takeStuck(taskId) {
            const i = this.stuckEvents.findIndex((e) => e.taskId === taskId);
            if (i === -1) return null;
            return this.stuckEvents.splice(i, 1)[0];
        },
    };
}

/**
 * 驱动一个任务到终态并返回该任务。
 * @param task ExecTask 实例
 * @param ctx  makeCtx 产物
 * @param opts { tickMs, checker: ProgressChecker options, parent }
 */
export async function driveTask(task, ctx, opts = {}) {
    task._ctx = ctx;
    let canStart = true;
    try { canStart = await task.canStart(ctx); } catch { canStart = false; }
    if (!canStart) {
        task._fail(FailReason.PRECONDITION);
        await task.cleanup(ctx);
        return task;
    }
    task._transition(TaskStatus.RUNNING, 'start');
    task._startedAt = Date.now();
    try { await task.onStart(ctx); } catch (e) {
        task._fail(FailReason.INTERNAL, { error: String(e).slice(0, 200) });
        await task.cleanup(ctx);
        return task;
    }

    const checker = new ProgressChecker(task, ctx, opts.checker);
    const sampler = runChecker(checker, ctx);
    ctx.activeChain?.push(task);
    try {
        while (!task.isComplete()) {
            // 超时强制（含祖先链）：B2R2-t6/t13 教训——嵌套 tick 会无限推迟祖先的超时检查
            //（祖先的检查只在它自己的 tick 间隙跑，而 tick 内 await 子任务可以任意长）。
            // 任一链上任务到期：是自己则 TIMEOUT，是祖先则 ABORT 放行让链回卷，逐层收口。
            const expired = ctx.activeChain?.find((t) => t.timedOut());
            if (expired) {
                if (expired === task) task._timeout({ elapsedMs: task.elapsed() });
                else task._abort(`ancestor_timeout:${expired.id}`);
                ctx.telemetry('ancestor_timeout_unroll', { task: task.id, expired: expired.id });
                break;
            }
            if (ctx.takeDeath()) {
                ctx.run.counters.deaths++;
                ctx.telemetry('task_on_death', { task: task.id });
                try { await task.onDeath?.(ctx); } catch (e) { ctx.telemetry('on_death_error', { task: task.id, error: String(e).slice(0, 120) }); }
            }
            try {
                await task.tick(ctx);
            } catch (e) {
                task._fail(FailReason.INTERNAL, { error: String(e).slice(0, 250) });
                break;
            }
            if (ctx.takeStuck(task.id)) {
                try { await task.onStuck?.('soft', ctx); } catch (e) { ctx.telemetry('stuck_recover_error', { task: task.id, error: String(e).slice(0, 120) }); }
            }
            if (checker.hardStuck()) {
                task._fail(FailReason.NO_PROGRESS, {
                    lastSignature: checker.lastSig,
                    recoveries: checker.recoveries,
                    frozenMs: Date.now() - checker.lastProgressAt,
                });
                break;
            }
            await sleep(opts.tickMs ?? 250);
        }
    } finally {
        const ci = ctx.activeChain ? ctx.activeChain.indexOf(task) : -1;
        if (ci >= 0) ctx.activeChain.splice(ci, 1);
        checker._stopped = true;
        try { await task.cleanup(ctx); } catch { /* 清理失败不影响终态 */ }
    }
    if (!task.isComplete()) task._abort('drive_exit');
    if (task.status === TaskStatus.SUCCESS) {
        try { await task.onSuccess(ctx); } catch (e) { ctx.telemetry('on_success_error', { task: task.id, error: String(e).slice(0, 120) }); }
    } else {
        try { await task.onFailure(ctx, task.failReason); } catch (e) { ctx.telemetry('on_failure_error', { task: task.id, error: String(e).slice(0, 120) }); }
    }
    return task;
}

/**
 * TaskRuntime：一次 MISSION 的执行容器（benchmark runner / DECIDER_MODE=tasked 共用）。
 */
export class TaskRuntime {
    /**
     * @param bot       mineflayer bot 实例（可后置 setBot）
     * @param opts      { mission, telemetryPath?, onDone(summary), tickMs }
     */
    constructor(bot, opts = {}) {
        this.bot = bot;
        this.mission = opts.mission;   // parseMission 产物 {resource, count}
        this.onDone = opts.onDone ?? (() => {});
        this.tickMs = opts.tickMs ?? 250;
        this.telePath = opts.telemetryPath ?? null;
        this.stackMaxDepth = opts.stackMaxDepth ?? null;  // MC-M1-TASK-06：铁链嵌套深（默认仍 6 不变）
        this.summary = null;
        this._startedAt = 0;
    }

    setBot(bot) { this.bot = bot; }

    telemetry(event, data = {}) {
        const rec = JSON.stringify({ t: Date.now(), event, ...data });
        try { console.log(`[task-layer] ${rec}`); } catch {}
        if (this.telePath) {
            try {
                if (!this._dirReady) {
                    mkdirSync(dirname(this.telePath), { recursive: true });
                    this._dirReady = true;
                }
                appendFileSync(this.telePath, rec + '\n');
            } catch { /* 遥测失败不影响主循环 */ }
        }
    }

    noteDeath(reason) {
        if (!this._ctx) return;
        this._ctx.deathEvents.push({ t: Date.now(), reason: reason ?? null });
        // 死亡清背包：依赖失败预算的历史归因作废，换纪元重新计（task_stack 语义）
        this._ctx.stack?.noteDeath();
    }

    /** 执行根任务直至终态，resolve 汇总 summary。 */
    async run(rootTask) {
        if (this.telePath) {
            try { mkdirSync(dirname(this.telePath), { recursive: true }); } catch {}
        }
        this._ctx = makeCtx(this.bot, { telemetry: (e, d) => this.telemetry(e, d), stackMaxDepth: this.stackMaxDepth });
        this._startedAt = Date.now();
        this.telemetry('mission_start', { mission: this.mission });
        // 根任务进任务树（trace 根节点；根不走守卫/预算——它就是 MISSION 本身）
        const rootKey = `acquire:${this.mission?.resource ?? 'unknown'}`;
        const rootLabel = `Acquire(${this.mission?.resource ?? '?'} ×${this.mission?.count ?? '?'})`;
        const onDeath = (reason) => this.noteDeath(reason);
        this.bot?.on?.('death', onDeath);
        try {
            await this._ctx.stack.runRoot(this._ctx, rootKey, rootLabel, () => rootTask, { tickMs: this.tickMs });
        } finally {
            this.bot?.removeListener?.('death', onDeath);
        }
        const c = this._ctx.run.counters;
        this.summary = {
            mission: this.mission,
            status: rootTask.status,
            failReason: rootTask.failReason,
            detail: rootTask.result,
            startedAt: this._startedAt,
            finishedAt: Date.now(),
            durationMs: Date.now() - this._startedAt,
            finalInventory: { [resourceKey(this.mission)]: countFinal(this.bot, this.mission) },
            transitions: rootTask.transitions.length,
            metrics: c,
            blacklistSize: this._ctx.run.blacklist.size,
            taskTree: this._ctx.stack.renderTrace(),   // 任务书 §15：每局一棵任务调用树
        };
        this.telemetry('mission_end', { ...this.summary, taskTree: undefined });
        try { await this.onDone(this.summary); } catch (e) { console.error('[task-layer] onDone error', e); }
        return this.summary;
    }
}

function resourceKey(mission) {
    // 资源无关（TASK-02）：成功物资 = 资源定义的 drops（stone→cobblestone；log→任意原木）
    try { return resourceDef(mission?.resource).drops.join('|'); }
    catch { return mission?.resource ?? 'unknown'; }
}
function countFinal(bot, mission) {
    try {
        const names = resourceDef(mission?.resource).drops;
        return bot.inventory.items().filter((i) => names.includes(i.name)).reduce((s, i) => s + i.count, 0);
    } catch { return 0; }
}
