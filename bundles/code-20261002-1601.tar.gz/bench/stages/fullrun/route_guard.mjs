// route_guard.mjs — MC-ROUTE-02：编排器侧的 route 守卫
//
// 本单**不实现**任务层的 `route_loader`（那是开发线 B 的活，SCHEMA §1 的三条校验都在那边：
// sha 校验、丢弃 scout、8 格粗化 + radius≥16 兜底）。本文件只做编排器该做的四件事，
// 全部是"编排器自己的账"，不碰任务层：
//
//   1. **文件选择 + 结构校验**：读 route 文件，校验 schema / 站序 / 站区字段。
//   2. **sha256 记录与复验**：开跑记一次；**每个段开始前**与整局结束时各复验一次。
//      任何一次对不上 → 整局判 `VOID`（SCHEMA §3：run 中 route 文件被修改 = 该局作废）。
//   3. **草稿闸门**：`frozenAt === null` 是草稿，SCHEMA 规定只能用于开发局；
//      正式矩阵/拍摄局必须显式 `--allow-draft` 才放行，默认拒。
//   4. **黑名单跨段台账**（任务单 §3 定的语义：预算按段重置、黑名单跨段保留）：
//      预算按段重置是任务层**现有**行为（FULLRUN-01 已实证：每次 TaskRuntime.run() 新建
//      TaskStack，budgets/blacklist/deathEpoch 都不跨段）。
//      「黑名单跨段保留」当前**没有注入通道**——黑名单是 ctx.run.blacklist，任务层未开放外部
//      runState 注入。所以本单把每段实测到的失败目标收集成**跨段台账**（从遥测
//      `nav_blacklist_expand{target,why,radius,expanded}` 解析），随 splits.json 落盘，
//      供设计会话排期任务层钩子时直接用。台账只读不改，不影响本局行为。

import fs from 'fs';
import crypto from 'crypto';
import path from 'path';

const STATION_ID_RE = /^[A-Za-z0-9_]{1,64}$/;
/** MISSION 形态白名单：只允许 `do station <id>`，从形态上杜绝坐标混进 MISSION */
const MISSION_RE = /^do station ([A-Za-z0-9_]{1,64})$/;

export class RouteError extends Error {
    constructor(code, msg) { super(`${code}: ${msg}`); this.code = code; }
}

export function sha256Of(text) {
    return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
}

/** 读 + 结构校验（不校验 hash：那是冻结态的事） */
export function readRouteFile(file) {
    if (!fs.existsSync(file)) throw new RouteError('ROUTE_FILE_MISSING', file);
    const raw = fs.readFileSync(file, 'utf8');
    let doc;
    try { doc = JSON.parse(raw); } catch (e) { throw new RouteError('ROUTE_BAD_JSON', `${file}: ${String(e).slice(0, 120)}`); }
    const v = [];
    if (doc.schema !== 'aidqq-route/1') v.push(`schema=${doc.schema}（期望 aidqq-route/1）`);
    if (!Array.isArray(doc.stations) || !doc.stations.length) v.push('stations 为空');
    for (const s of doc.stations ?? []) {
        if (!STATION_ID_RE.test(s.id ?? '')) v.push(`站 id 非法：${s.id}`);
        if (!Number.isInteger(s.seq)) v.push(`${s.id} seq 非整数`);
        if (!s.station || !Array.isArray(s.station.center) || s.station.center.length !== 2) v.push(`${s.id} station.center 非法`);
        else if (!s.station.center.every(Number.isInteger) || s.station.center.some((c) => c % 8 !== 0)) {
            // SCHEMA §1 说加载器会把 center 对齐到 8 格作兜底；这里**再加一道**：文件本身就必须
            // 已经是粗粒度的。否则有人把精确坐标写进 station，加载器虽会兜底，但"误写"已经发生。
            v.push(`${s.id} center=${JSON.stringify(s.station.center)} 未对齐 8 格网格（站级数据必须是粗粒度）`);
        }
        if (!Number.isInteger(s.station?.radius) || s.station.radius < 16) v.push(`${s.id} radius=${s.station?.radius} < 16（SCHEMA 硬下限）`);
        if (!Array.isArray(s.station?.lookFor) || !s.station.lookFor.length) v.push(`${s.id} lookFor 为空（运行时无法做到达确认）`);
    }
    const seqs = (doc.stations ?? []).map((s) => s.seq);
    if (seqs.length && (Math.min(...seqs) !== 1 || seqs.length !== new Set(seqs).size)) v.push('seq 必须是从 1 起的不重复整数');
    return { file, raw, sha256: sha256Of(raw), doc, violations: v };
}

/** 开局闸门：草稿 / 冻结态 / sha 一致性 */
export function checkRouteIntegrity(file, { allowDraft = false, requireFrozen = false } = {}) {
    const r = readRouteFile(file);
    const out = { file, sha256: r.sha256, frozenAt: r.doc.frozenAt ?? null, frozen: !!r.doc.frozenAt, sha256File: r.doc.sha256File ?? null, violations: [...r.violations], ok: true, reason: null };

    if (out.violations.length) { out.ok = false; out.reason = `SCHEMA_VIOLATIONS: ${out.violations.join(' | ')}`; return out; }

    if (!out.frozen) {
        if (requireFrozen || !allowDraft) {
            out.ok = false;
            out.reason = `ROUTE_IS_DRAFT: frozenAt=null（草稿只能用于开发局；正式矩阵/拍摄局必须用冻结版）。`
                + `开发局请显式 --allow-draft`;
            return out;
        }
    } else {
        // 冻结态：与 <seed>.sha256 旁挂文件比对
        const side = r.doc.sha256File ? path.join(path.dirname(file), r.doc.sha256File) : null;
        if (side && fs.existsSync(side)) {
            const frozen = fs.readFileSync(side, 'utf8').trim().split(/\s+/)[0];
            if (frozen !== r.sha256) {
                out.ok = false;
                out.reason = `ROUTE_HASH_MISMATCH: 文件 sha=${r.sha256.slice(0, 16)}… 冻结值 sha=${String(frozen).slice(0, 16)}…`;
                return out;
            }
        } else if (requireFrozen) {
            out.ok = false;
            out.reason = `ROUTE_SIDECAR_MISSING: 冻结态必须有 ${r.doc.sha256File ?? '<seed>.sha256'}`;
            return out;
        }
    }
    return out;
}

export class RouteGuard {
    /**
     * @param {string} file route 文件路径
     * @param {{allowDraft?:boolean, requireFrozen?:boolean, onViolation?:(r:object)=>void}} opt
     */
    constructor(file, opt = {}) {
        this.file = file;
        this.opt = opt;
        this.started = checkRouteIntegrity(file, opt);
        this.voided = !this.started.ok;
        this.voidReason = this.started.reason;
        this.ledger = [];          // 跨段黑名单台账（只读观测，不注入任务层）
        this.checks = [{ at: 'start', ...this.started }];
    }
    get sha256() { return this.started.sha256; }
    get stations() { return (this.started.violations.length ? [] : this.started.doc.stations) ?? []; }

    /** 段开始前复验：文件被改过 → 整局作废 */
    verify(where) {
        let now;
        try { now = checkRouteIntegrity(this.file, this.opt); }
        catch (e) { now = { ok: false, reason: `ROUTE_READ_FAIL: ${e.message}`, sha256: null, violations: [] }; }
        const changed = !this.voided && now.sha256 !== this.started.sha256;
        const rec = {
            at: where, sha256: now.sha256, same: now.sha256 === this.started.sha256,
            ok: now.ok && !changed, changed,
            reason: changed ? `ROUTE_CHANGED_MID_RUN: 开局 sha=${String(this.started.sha256).slice(0, 16)}… 现在 sha=${String(now.sha256).slice(0, 16)}… → 该局作废` : now.reason,
        };
        this.checks.push(rec);
        if (!rec.ok) { this.voided = true; this.voidReason = rec.reason; }
        return rec;
    }

    /**
     * 吸收一段的遥测，提取实测失败目标 → 跨段黑名单台账。
     * 事件形如 nav_blacklist_expand{why,target:"x y z",radius,expanded}
     */
    absorbSegmentTelemetry(telemetryPath, { dim = 'overworld' } = {}) {
        if (!fs.existsSync(telemetryPath)) return { added: 0, ledger: this.ledger };
        let added = 0;
        for (const line of fs.readFileSync(telemetryPath, 'utf8').split('\n')) {
            if (!line.trim()) continue;
            let e; try { e = JSON.parse(line); } catch { continue; }
            if (e.event !== 'nav_blacklist_expand' || !e.target) continue;
            const [x, y, z] = String(e.target).split(/\s+/).map(Number);
            if (![x, y, z].every(Number.isFinite)) continue;
            const key = `${x},${y},${z}`;
            if (this.ledger.some((r) => r.key === key)) continue;
            this.ledger.push({ key, x, y, z, dim, why: e.why ?? null, radius: e.radius ?? null, expanded: e.expanded ?? null, at: e.t ?? null });
            added++;
        }
        return { added, ledger: this.ledger };
    }

    /**
     * 测试专用：模拟「外部在 run 中改了 route 文件」。
     * 改一个字节（把某站的 radius 从 32 改成 33，仍是合法 JSON），用来在真实 bot 路径上
     * 触发 verify() 的作废判定——干跑时每段耗时 ~0ms，人手改文件根本抢不到窗口，
     * 所以把"被改"这一步自动化；判定逻辑与外部修改完全同一条路径（重新读文件 + 比 sha）。
     * 离线等价验证见 route_selftest.mjs 第 3 组（那里是真·外部改文件）。
     */
    simulateExternalEdit() {
        try {
            const doc = JSON.parse(fs.readFileSync(this.file, 'utf8'));
            const st = doc.stations?.[0];
            if (!st) return null;
            const before = st.station.radius;
            st.station.radius = before + 1; // 只动一个字符
            fs.writeFileSync(this.file, JSON.stringify(doc, null, 2) + '\n');
            return { field: 'stations[0].station.radius', before, after: st.station.radius };
        } catch (e) {
            return { error: String(e).slice(0, 120) };
        }
    }

    report() {
        return {
            file: this.file,
            sha256AtStart: this.started.sha256,
            frozen: this.started.frozen,
            frozenAt: this.started.frozenAt,
            voided: this.voided,
            voidReason: this.voidReason,
            checks: this.checks,
            blacklistLedgerSize: this.ledger.length,
            blacklistLedger: this.ledger,
            blacklistPolicy: '预算按段重置（任务层现有行为，已实证）；黑名单跨段保留 = 台账已建，注入通道待任务层钩子（本单不改任务层）',
        };
    }
}

/** MISSION 形态自检：站 id 序列里**不允许出现任何坐标**（手册 §7 / SCHEMA §3） */
export function assertStationOnlyMissions(missions) {
    for (const m of missions) {
        const hit = MISSION_RE.exec(m.raw);
        if (!hit) throw new RouteError('MISSION_NOT_STATION_FORM', `序列项不是 "do station <id>"：${m.raw}`);
        if (/\d/.test(hit[1]) && !/^S\d/.test(hit[1])) throw new RouteError('STATION_ID_HAS_DIGITS', `站 id 含数字且不像 S 编号：${hit[1]}`);
    }
    return true;
}
