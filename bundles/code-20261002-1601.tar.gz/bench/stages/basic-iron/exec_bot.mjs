// exec_bot.mjs — MC-M1-TASK-06 BASIC-iron benchmark 执行机器人（standalone）
//
// 协议同 BASIC-bootstrap（零 kit 零 RCON 零 LLM），差别只有两点：
//   1. --resource 指定 MISSION 物品（默认 iron_pickaxe），MISSION 文本一字不改：
//      "obtain 1 iron_pickaxe" / "obtain 1 bucket" / "obtain 1 flint_and_steel"
//   2. 根任务按资源类型路由：craft 型（gather=false，BASIC-iron 三件套）→ CraftingTask
//      递归自理整条链（木器→石镐→铁矿→熔炉→熔炼→成品）；gather 型仍走 AcquireResourceTask
//
// 零 LLM 是结构性保证：不加载 prompter/history/self-prompt/dm_client（同 TASK-01/02）。
//
// 用法：node exec_bot.mjs --trial 1 --seed <seed> --out <runDir> [--port 25566]
//       [--username TaskBot] [--resource iron_pickaxe] [--timeout-ms 540000] [--mc-version 1.16.1]
//       [--probe-ms 10000]  MC-BENCH-v2：runner 级进度探针周期（0 = 关）
//
// MC-BENCH-v2 探针（probe.jsonl，runner 读它做无进展硬中止）：每 probe-ms 落一行
// {t, inv, pos, digging, furnace, tree}。签名语义：
//   tree  = 任务树结构+状态（时长字符剥掉——运行期节点显示 '...' 会污染签名）
//   inv   = 背包全量（排序字符串）
//   pos   = 0.1 格精度坐标（导航/游走期持续推进）
//   digging = 是否在挖（下挖步进器保活通道）
//   furnace = 熔炉窗口的燃料/进度秒数（熔炼等待期保活通道——smoke5 的合法长等待）

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const MINDCRAFT = path.join(ROOT, 'mindcraft');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));

function arg(name, dflt) {
    const i = process.argv.indexOf(`--${name}`);
    return i >= 0 ? process.argv[i + 1] : dflt;
}

const TRIAL = parseInt(arg('trial', '0'), 10);
const SEED = arg('seed', 'unknown');
const OUT_DIR = arg('out', path.dirname(fileURLToPath(import.meta.url)));
const PORT = parseInt(arg('port', '25566'), 10);
const USERNAME = arg('username', 'TaskBot');
const RESOURCE = arg('resource', 'iron_pickaxe');
const TIMEOUT_MS = parseInt(arg('timeout-ms', '540000'), 10);
const MC_VERSION = arg('mc-version', '1.16.1');
const TELEMETRY = path.join(OUT_DIR, 'telemetry.jsonl');
const RESULT = path.join(OUT_DIR, 'result.json');
const LOG = path.join(OUT_DIR, 'bot.log');
const PROBE = path.join(OUT_DIR, 'probe.jsonl');
const PROBE_MS = parseInt(arg('probe-ms', '10000'), 10);

fs.mkdirSync(OUT_DIR, { recursive: true });
const logLine = (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(LOG, line + '\n'); } catch {}
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let finished = false;
let _spawned = false; // MC-BENCH-v2：连接期失败快速退出的判据（spawn 前的 error 才致命）

// —— MC-BENCH-v2：runner 级进度探针（只读观测，不触碰任务层）——
let _runtime = null;
let _probeTimer = null;
function probeTree(rt) {
    try {
        const trace = rt?._ctx?.stack?.renderTrace?.() ?? '';
        return trace.replace(/\[[^\]]*\]/g, '[]'); // 状态保留、时长剥除（'...'/‘12.3s’ 都不稳）
    } catch { return ''; }
}
function startProbe(bot) {
    if (!(PROBE_MS > 0)) return;
    try { fs.rmSync(PROBE, { force: true }); } catch { /* 忽略 */ }
    _probeTimer = setInterval(() => {
        try {
            const invParts = bot.inventory.items()
                .map((i) => `${i.name}:${i.count}`).sort();
            const p = bot.entity?.position;
            const w = bot.currentWindow;
            const furnace = w && String(w.type).includes('furnace')
                ? { f: Math.round(w.fuelSeconds ?? 0), p: Math.round(w.progressSeconds ?? 0) }
                : null;
            fs.appendFileSync(PROBE, JSON.stringify({
                t: Date.now(), event: 'bench_probe',
                inv: invParts.join(','),
                pos: p ? [+p.x.toFixed(1), +p.y.toFixed(1), +p.z.toFixed(1)] : null,
                digging: !!bot.targetDigBlock,
                furnace,
                tree: probeTree(_runtime),
            }) + '\n');
        } catch { /* 探针失败不影响试局 */ }
    }, PROBE_MS);
    _probeTimer.unref?.();
}

async function main() {
    const mineflayer = require('mineflayer');
    const pf = require('mineflayer-pathfinder');
    const toolPlugin = require('mineflayer-tool').plugin;
    const { TaskRuntime } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/task_runner.js')).href);
    const { AcquireResourceTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/acquire_resource_task.js')).href);
    const { CraftingTask } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/crafting_task.js')).href);
    const { parseMission } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/mission.js')).href);
    const { resourceDef } = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/resources.js')).href);

    const bot = mineflayer.createBot({ host: '127.0.0.1', port: PORT, username: USERNAME, version: MC_VERSION });
    bot.loadPlugin(pf.pathfinder);
    bot.loadPlugin(toolPlugin);

    const hardKill = setTimeout(() => {
        logLine('HARD_TIMEOUT: runner watchdog fired, exiting without result');
        finish({ status: 'RUNNER_TIMEOUT' }, 1);
    }, TIMEOUT_MS + 60000);

    bot.on('kicked', (r) => { logLine(`kicked: ${r}`); if (!finished) finish({ status: 'KICKED', reason: String(r) }, 1); });
    // MC-BENCH-v2：连接期（spawn 之前）失败快速退出——本机 loopback 抖动族（TASK-04 实证）
    // 会让 connect ETIMEDOUT 后进程挂着不退，runner 只能等硬超时；快速退出让 runner 的
    // NO_RESULT 重试（15s 冷却）立即接手
    bot.on('error', (e) => {
        logLine(`bot_error: ${String(e).slice(0, 200)}`);
        if (!finished && !_spawned) finish({ status: 'CONNECT_FAIL', reason: String(e).slice(0, 120) }, 1);
    });
    // 死亡 → 重生。零 rekit：任务层通过依赖预算死亡纪元重置后重建装备链
    bot.on('death', () => { logLine('death event: respawning in 800ms'); setTimeout(() => { try { bot.respawn(); } catch {} }, 800); });

    bot.once('spawn', async () => {
        _spawned = true;
        try {
            await sleep(4000); // 世界落定（TASK-01 同款）
            const spawnPos = bot.entity.position.floored();
            const invSnap = bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',') || '(empty)';
            logLine(`spawn: seed=${SEED} pos=[${spawnPos.x},${spawnPos.y},${spawnPos.z}] inventory=[${invSnap}]`);
            logLine('protocol: NO KIT, NO LLM (iron chain must be self-sufficient)');
            // MISSION 一字不改（任务单 §1 口径）。MC-M1-TASK-06d P2-1：数量改由 --target 给
            // （原来写死 `obtain 1`，run_bench 一直在传 --target 却被忽略——验收单要的
            //  「obtain 4 log」跑出来其实是 obtain 1 log，面板测的不是指定工况）。
            // 不传 --target 时仍是 1，与改前逐字一致。
            const missionCount = Math.max(1, parseInt(arg('target', '1'), 10) || 1);
            const mission = parseMission(`obtain ${missionCount} ${RESOURCE}`);
            logLine(`start: mission=${JSON.stringify(mission)}`);
            const def = resourceDef(mission.resource);
            const runtime = new TaskRuntime(bot, { mission, telemetryPath: TELEMETRY, stackMaxDepth: 8 });
            _runtime = runtime;
            startProbe(bot);
            // craft 型资源（BASIC-iron 三件套）根任务 = CraftingTask 递归自理整条链；
            // gather 型资源保持 AcquireResourceTask（本 bench 不会走到，防御性保留）
            const root = def.gather === false
                ? new CraftingTask({ item: def.item, count: mission.count, timeoutMs: TIMEOUT_MS, gatherTimeoutMs: 420000 })
                : new AcquireResourceTask({ resource: mission.resource, count: mission.count, timeoutMs: TIMEOUT_MS });
            const summary = await runtime.run(root);
            const fullInv = {};
            for (const it of bot.inventory.items()) fullInv[it.name] = (fullInv[it.name] ?? 0) + it.count;
            logLine(`end: ${summary.status} reason=${summary.failReason} dur=${(summary.durationMs / 1000).toFixed(1)}s inv=${JSON.stringify(summary.finalInventory)}`);
            if (summary.taskTree) logLine(`task tree:\n${summary.taskTree}`);
            finish({ ...summary, spawnPos: [spawnPos.x, spawnPos.y, spawnPos.z], fullInventory: fullInv }, summary.status === 'SUCCESS' ? 0 : 1);
        } catch (e) {
            logLine(`fatal: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`);
            finish({ status: 'FAILED', failReason: 'INTERNAL', error: String(e).slice(0, 300) }, 1);
        }
    });

    function finish(summary, code) {
        if (finished) return;
        finished = true;
        clearTimeout(hardKill);
        if (_probeTimer) clearInterval(_probeTimer);
        try {
            fs.writeFileSync(RESULT, JSON.stringify({ trial: TRIAL, seed: SEED, resource: RESOURCE, kit: 'none', ...summary }, null, 2));
        } catch (e) { logLine(`result write fail: ${e.message}`); }
        setTimeout(() => {
            try { bot.quit(); } catch {}
            process.exit(code);
        }, 1200);
    }
}

main().catch((e) => { logLine(`boot fail: ${String(e && e.stack ? e.stack : e).slice(0, 500)}`); process.exit(1); });
