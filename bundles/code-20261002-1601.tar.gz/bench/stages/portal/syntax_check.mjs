// syntax_check.mjs — 加载本单改过的任务层文件，确认 import 链与语法都通（秒级，不开服）
//
// 为什么要单独一步：r5 改了 4 个文件（liquid.js / patch_cell.js / chest_loot.js /
// portal_stage_task.js），其中 patch_cell.js 用了**动态 import**（`await import('./liquid.js')`），
// 静态检查看不出来；portal_stage_task.js 又有 900 行、import 链很长。
// 手册 §5「微基准自检清单」的第一条就是「等回包落定再开测」——同理，
// 改完代码先花 5 秒确认能加载，再花 15 分钟起服跑冒烟。
//
// 用法：node syntax_check.mjs

import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const EXEC = path.join(MINDCRAFT, 'src/agent/tasks/exec');

const FILES = [
    'liquid.js', 'chest_loot.js', 'patch_cell.js', 'portal_stage_task.js',
    // 依赖链上的既有关键文件，顺带确认没被我改坏
    'nether.js', 'route_loader.js', 'station_nav.js', 'place_at.js', 'place.js', 'nav.js',
];

let fail = 0;
for (const f of FILES) {
    const p = path.join(EXEC, f);
    if (!fs.existsSync(p)) { console.log(`SKIP  ${f}（不存在）`); continue; }
    try {
        const mod = await import(pathToFileURL(p).href);
        const names = Object.keys(mod);
        console.log(`OK    ${f}  (${names.length} exports: ${names.slice(0, 6).join(', ')}${names.length > 6 ? ' …' : ''})`);
    } catch (e) {
        fail++;
        console.log(`FAIL  ${f}: ${String(e?.message ?? e).slice(0, 300)}`);
        if (e?.stack) console.log(String(e.stack).split('\n').slice(0, 4).map((l) => `        ${l}`).join('\n'));
    }
}

// 关键导出存在性断言（r5 踩过 spillHeldBucket 不存在的坑，这里固化）
const MUST = {
    'liquid.js': ['scoopLiquidAt', 'placeLiquidAt', 'castObsidianAt', 'liquidSourceInfo', 'spillHeldBucket', 'isLavaSource'],
    'chest_loot.js': ['findChestsNear', 'lootChest', 'lootChestNear'],
    'patch_cell.js': ['patchOneCell', 'castCellByHauling', 'standableBeside', 'findQualifiedLavaNear', 'findQualifiedWaterNear', 'safeLandingSpot', 'walkNear'],
    'nether.js': ['frameCells', 'interiorCells', 'checkFrame', 'ignitePortal', 'enterPortal', 'returnViaPortal', 'arrivalProtocol', 'AnchorStore'],
    'portal_stage_task.js': ['PortalStageTask'],
};
console.log('');
for (const [f, names] of Object.entries(MUST)) {
    try {
        const mod = await import(pathToFileURL(path.join(EXEC, f)).href);
        const miss = names.filter((n) => typeof mod[n] === 'undefined');
        if (miss.length) { fail++; console.log(`MISS  ${f}: 缺导出 ${miss.join(', ')}`); }
        else console.log(`EXPORT ${f}: ${names.length} 个关键导出齐全`);
    } catch { /* 上面已报过 */ }
}

// —— 静态检查：文件里用到、但既没 import 也没在本文件定义的标识符 ——
// r6 实测教训：删掉一个私有辅助函数时**顺手删了它用到的 import**（countItems），
//   `import` 语句本身语法合法，模块能加载（syntax_check 上一轮是绿的），
//   一直跑到微基准真调用那一行才炸 `ReferenceError: countItems is not defined`。
//   所以这里补一道**名字级**的静态检查：扫出所有 `xxx(` 形式的调用，
//   对照「本文件 import 进来的 + 本文件 function/const 定义的 + 全局白名单」。
console.log('');
console.log('=== 静态引用检查（未定义标识符）===');
const GLOBALS = new Set([
    'console', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval', 'process',
    'Math', 'JSON', 'Object', 'Array', 'Number', 'String', 'Boolean', 'Promise', 'Map', 'Set',
    'Error', 'TypeError', 'Symbol', 'Date', 'RegExp', 'Infinity', 'NaN', 'undefined', 'isNaN', 'parseInt', 'parseFloat',
    'await', 'if', 'for', 'while', 'switch', 'catch', 'return', 'typeof', 'new', 'import', 'function', 'async', 'of', 'in',
    'Float', 'BigInt', 'WeakMap', 'WeakSet', 'structuredClone', 'encodeURIComponent', 'decodeURIComponent',
]);
// 同目录其它文件导出的名字（跨文件调用通常经 import，这里只兜底同名私有函数）
const LOCAL = new Set();
try {
    for (const f of fs.readdirSync(EXEC)) {
        if (!f.endsWith('.js')) continue;
        const src = fs.readFileSync(path.join(EXEC, f), 'utf8');
        for (const m of src.matchAll(/export\s+(?:async\s+)?function\s+(\w+)/g)) LOCAL.add(m[1]);
        for (const m of src.matchAll(/export\s+(?:const|let|var|class)\s+(\w+)/g)) LOCAL.add(m[1]);
    }
} catch { /* 忽略 */ }

for (const f of FILES) {
    const p = path.join(EXEC, f);
    if (!fs.existsSync(p)) continue;
    const src = fs.readFileSync(p, 'utf8');
    // 本文件可见的名字
    const known = new Set(GLOBALS);
    for (const m of src.matchAll(/import\s+[^;]*?from\s+'[^']+';/g)) {
        for (const n of m[0].matchAll(/(\w+)\s*(?:,|})/g)) known.add(n[1]);
        for (const n of m[0].matchAll(/\{\s*([^}]+)\}/g)) {
            for (const part of n[1].split(',')) known.add((part.split(/\s+as\s+/).pop() ?? part).trim());
        }
        const def = m[0].match(/import\s+(\w+)/);
        if (def) known.add(def[1]);
    }
    for (const m of src.matchAll(/(?:async\s+)?function\s+(\w+)/g)) known.add(m[1]);
    for (const m of src.matchAll(/(?:const|let|var)\s+(\w+)/g)) known.add(m[1]);
    for (const m of src.matchAll(/class\s+(\w+)/g)) known.add(m[1]);
    // ★ 类方法名（`  methodName(` 缩进形式）：它们是定义，不是"未定义的调用"。
    //   不加这条会把 constructor/tick/record/flush/… 全判成未定义，淹没真问题。
    for (const m of src.matchAll(/^[ \t]+(?:async\s+|static\s+|get\s+|set\s+)*([a-zA-Z_$][\w$]*)\s*\([^)]*\)\s*\{/gm)) known.add(m[1]);
    // 解构赋值的参数（含默认值），如 `{ ctx, GoalNear, telemetry, label = 'x' } = opts`
    for (const m of src.matchAll(/(?:const|let|var)\s*\{([^}]*)\}\s*=/g)) {
        for (const part of m[1].split(',')) {
            const n = part.split(':').pop().split('=')[0].trim();
            if (n) known.add(n);
        }
    }
    for (const m of src.matchAll(/(?:const|let|var)\s*\{([^}]+)\}\s*=/g)) {
        for (const part of m[1].split(',')) known.add((part.split(':').pop() ?? part).split('=')[0].trim());
    }
    // 函数参数（回调形参：reject/resolve/direction/P…）
    for (const m of src.matchAll(/\(([^()]*)\)\s*(?:=>|\{)/g)) {
        for (const part of m[1].split(',')) {
            const n = part.split('=')[0].trim().replace(/^\.\.\./, '');
            if (n && /^[a-zA-Z_$][\w$]*$/.test(n)) known.add(n);
        }
    }
    for (const m of src.matchAll(/([a-zA-Z_$][\w$]*)\s*(?:=>|\{)/g)) {
        // 箭头函数的单参数形式
        if (m[1] !== 'if' && m[1] !== 'for' && m[1] !== 'while' && m[1] !== 'switch' && m[1] !== 'catch') known.add(m[1]);
    }
    // 调用点：`name(`
    // ★ 只查**小写开头**的名字：JS 里类方法（constructor/tick/record/flush…）与
    //   回调形参（reject/resolve/P/direction…）都是非小写开头的，查它们全是误报。
    //   小写开头又紧跟 `(` 的，才是"本文件里真正在调用的标识符"。
    const called = new Set();
    for (const m of src.matchAll(/(?<![.\w$])([a-z_$][\w$]*)\s*\(/g)) called.add(m[1]);
    const KEYWORDS = /^(if|for|while|switch|catch|typeof|function|await|new|import|do|else|try|return|void|delete|in|of|instanceof|super)$/;
    // ★ 已确认的误报豁免（都是**对象方法调用**或 mineflayer API，不是本文件缺失的定义）：
    //   getProperties/activateBlock/placeBlock/openContainer… = bot/块对象上的方法
    //   block_place/uniform                            = 只出现在**注释里**的包名/参数名
    //   containerItems/distanceTo/getColumn            = window/Vec3/column 上的方法
    //   _fail                                          = 继承自 ExecTask 基类
    const WHITELIST = new Set([
        'getProperties', 'activateBlock', 'activateItem', 'placeBlock', 'openContainer', 'openChest',
        'openBlock', 'block_place', 'uniform', 'containerItems', 'distanceTo', 'getColumn',
        'equip', 'equipForBlock', 'dig', 'stopDigging', 'lookAt', 'look', 'findBlocks', 'blockAt',
        'setControlState', 'respawn', 'quit', 'write', 'end', 'flush', 'take', 'close', 'pressKey',
        // r6 补：direction（openContainer 的默认参数名，只在解构里出现）、_fail（继承自 ExecTask 基类）
        'direction', '_fail', '_succeed', 'canStart', 'progressSignature',
    ]);
    const unknown = [...called].filter((n) => !known.has(n) && !LOCAL.has(n) && !KEYWORDS.test(n) && !WHITELIST.has(n));
    if (unknown.length) {
        fail++;
        console.log(`UNDEF ${f}: 疑似未定义 ${unknown.join(', ')}`);
    }
}

console.log('');
console.log(fail === 0 ? '=== 全部通过 ===' : `=== ${fail} 项失败 ===`);
process.exit(fail === 0 ? 0 : 2);
