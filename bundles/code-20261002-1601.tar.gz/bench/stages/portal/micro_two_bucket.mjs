// micro_two_bucket.mjs — 两桶打法的**完整循环**微基准（ROUND3 主种子定案）
//
// 为什么必须单独做微基准（手册 §4 第 2 条）：
//   两桶打法是一串**有顺序依赖**的动作 —— 舀浆 → 倒浆 → 验源块 → 倒水 → **舀回水**。
//   任何一步静默失败（1.16.1 的液体交互全是静默的：服务端日志零异常），
//   后面每一步都会跟着错，而真链上表现为"补格反复失败"，极难归因。
//   所以要在**受控场景**里把整串跑通 n 次，确认 ≥95%。
//
// 场景（server 权威布景，固定坐标）：
//   门框 = 4×5 最小框，缺 1 格（底行一格是空气）
//   目标缺格正下方 1 格处放**岩浆源**（模拟"缺格旁边就有岩浆"）
//   另备一只岩浆源在几格外，模拟"需要走过去舀"
//   桶 = 1 空桶 + 1 水桶（两桶打法的初始状态）
//
// 判据（每轮独立计数）：
//   ① 舀到岩浆          ② 倒进缺格且**是源块**  ③ 倒水后那格变 **obsidian**
//   ④ **水被舀回桶里**   ← 这一条是整套打法的命根子（不舀回来，第二格就没水了）
//   ⑤ 全程**岩浆死亡 0**
//
// 用法：node micro_two_bucket.mjs --stamp P8R6_MICRO --n 10

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import fs from 'fs';
import {
    argOf, waitFreeMem, freshWorld, bootServerWithRetry, stopServer, log,
} from '../_lib/runner_core.mjs';
import { installRunnerHooks } from '../_lib/cleanup.mjs';
import { waitLane, laneStatus } from './lane_guard.mjs';
// ★ r7：改用 srv_rpc 的**回执通道**发命令（与 SEED-03 / r5 的 micro_bench 同一套）。
//   之前直接 `server.child.stdin.write()` 有两个问题：
//     ① 连发几百条会被服务端静默丢弃（P8_PROBE2 记录过这个坑）；
//     ② 拿不到回执，没法判断命令到底成没成。
import { makeRpc, serveRpc } from './srv_rpc.mjs';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const { Vec3 } = require('vec3');
const mineflayer = require('mineflayer');
const pf = require('mineflayer-pathfinder');

const SERVER_TEMPLATE = process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments/mc1161-gate/server-1161');
const JAVA = process.env.MC_BENCH_JAVA || path.join(ROOT, 'experiments/mc1161-gate/jdk/jdk-11.0.32.1+1/bin/java.exe');
const JAR_NAME = process.env.MC_BENCH_JAR || 'server-1.16.1.jar';
const MC_VERSION = '1.16.1';
const STAMP = argOf(process.argv, 'stamp', 'P8R6_MICRO');
const N = parseInt(argOf(process.argv, 'n', '10'), 10);
const MIN_FREE_MB = parseInt(argOf(process.argv, 'min-free-mb', '2560'), 10);
const SEED = argOf(process.argv, 'seed', `${STAMP}-S`);

const LANE_B = {
    idx: 1, name: 'B', dir: `${SERVER_TEMPLATE}_laneB`,
    serverPort: 25567, rconPort: 25577, username: 'MicroBotB', rconPass: 'spike-rcon',
    jarPath: path.join(`${SERVER_TEMPLATE}_laneB`, JAR_NAME), java: JAVA,
};
const RUNS_DIR = path.join(BENCH_DIR, 'runs', STAMP);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(RUNS_DIR, { recursive: true });

let server = null; let bot = null;
let rpc = null;            // r7：回执通道（见文件头 import 注释）
let rpcStop = null;
const RPC_DIR = path.join(RUNS_DIR, 'rpc');
const SERVER_LOG = path.join(RUNS_DIR, 'server.log');
// 统一出口：命令一律经 rpc 发（有回执），不再直写 stdin。
// ⚠ `makeRpc` 产出的 `call(dir, id, cmd)` —— **第一个参数是 rpc 对象自己**（它内部
//   用 `dir.reqDir`/`dir.doneDir`），不是 rpc 目录路径。传路径会一路 undefined，
//   结果所有命令**静默超时**、一条都没发出去（表现：server.log 全零）。
//   正确用法见 `micro_bench.mjs`：`await rpc.call(rpc, rpc.nextId('m'), cmd, {...})`。
const cmd = async (c) => {
    if (!rpc) { try { server.child.stdin.write(`${c}\n`); } catch { /* 忽略 */ } return; }
    try { await rpc.call(rpc, rpc.nextId('m'), c, { timeoutMs: 15000 }); } catch { /* 忽略 */ }
};
// 布景专用：同 cmd，但布景量大、不等回执（避免几百条串行等 ack 拖到分钟级）
const setb = (x, y, z, name) => cmd(`setblock ${x} ${y} ${z} minecraft:${name}`);
const bname = (x, y, z) => { try { return bot?.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; } };

// —— 布景（单一真源：坐标只在这里定义一次，见手册 §5「场景坐标只能有一个真源」）——
const SCENE = {
    // 门框 origin（缺 1 格：底行中间那格），4 宽沿 x、5 高
    frame: { x: 100, y: 70, z: 100, axis: 'x' },
    // 缺格 = 底行第 2 格（挖掉它，制造"要补的空气格"）
    missing: [101, 70, 100],
    // 岩浆源：放在缺格**下方 1 格的洞里**（模拟门边小岩浆池），另有一个在 6 格外
    // ★ r7 修正的**污染根因**：r6 把岩浆源放在【缺格正下方 1 格】(101,69,100)。
    //   被测原语往缺格倒水时，水顺着缺格流下去**把岩浆冲走**（实测第 2 轮那格变成 water），
    //   场景被上一轮改写 ⇒ 后面每轮都在测一个不一样的场景（8 轮布景校验失败）。
    //   正确做法（与 r5 的 scene.mjs 同思路）：**源块放在几格外的独立坑里**，
    //   四周是石头（源块不水平铺开），让"供给几何"与"被测几何"解耦。
    lavaSource: [107, 69, 100],
    lavaPit: { x0: 105, y0: 68, z0: 98, x1: 108, y1: 69, z1: 102 },
    // bot 站位（安全、不在液体里；与缺格在 z 上差 2 格——scene.mjs 的布局铁律）
    stand: [99, 71, 102],
    // 站在岩浆源旁舀浆的位置：源块 (107,69,100) **正东 1 格**的池边石头上（真人站池边舀浆），
    // 与源块在 z 上差 1 格（scene.mjs 布局铁律：避免客户端/服务端半格偏差跨格）
    standLava: [108.5, 70, 101.0],
};
const BOT = [SCENE.frame.x - 6, SCENE.frame.y + 8, SCENE.frame.z];

/**
 * 布景前置：确保布景区区块已就绪。
 *
 * ★★★ r7 三处修正（每处都是我自己踩的）：
 *   ① 「1.16.1 没有 /forceload」是**错的**。`/forceload` 1.14 就有；jar 里找不到
 *      `ForceloadCommand.class` 是因为 **jar 是混淆的**（手册 §3 新规则）。
 *      SEED-03 R1/R3 与 C 线的 `bench/route/tools/` 一直在 1.16.1 vanilla 上用它。
 *   ② 参数形式：`forceload add` 在 1.16.1 要**四个**（方块坐标 x1 z1 x2 z2）。
 *      我写两参数 → 服务器回显 "Marked chunk [0, 0]"，什么都没加载。
 *      正确写法见 `bench/route/tools/scan.mjs` 的 forceload()。
 *   ③ ★ 判据**不能用客户端 `bname()`**：客户端要等区块同步到本地，
 *      而服务端 setblock 早就成功了 —— 于是"服务端已就绪、客户端还没数据"会被误判成未就绪，
 *      死循环 60 次（P8R7_MICRO4：服务端 Changed=172，客户端 bname 永远 null）。
 *      SEED-03 R3 的判据是**读服务端回执**（r3_fill.mjs：「区块已到」= fill 不再返回 not loaded，
 *      比 chunkColumnLoad 事件更严格 —— 后者会被空 section 骗过）。
 *      这里用 srv_rpc 的 ack（命令已写进 stdin 并被服务端消化）作为等价判据。
 */
async function ensureChunksLoaded() {
    const S = SCENE;
    const x1 = S.frame.x - 10, z1 = S.frame.z - 10, x2 = S.frame.x + 10, z2 = S.frame.z + 10;
    const probeId = () => `chunkprobe_${Date.now().toString(36)}`;
    // ① forceload（四参数，方块坐标）
    const flId = probeId();
    await rpc.call(rpc, flId, `forceload add ${x1} ${z1} ${x2} ${z2}`, { timeoutMs: 15000 }).catch(() => null);
    await sleep(800);

    // ② 轮询探针：用 rpc 发 setblock，**等 ack**（= 服务端已处理完）。
    //    区块未加载时服务端会回 "That position is not loaded"；加载后就正常执行。
    //    ack 只能证明"命令写进 stdin"，所以再叠加一个**服务端真值查询**做二次确认：
    //    `execute if block <探针> <方块> run say <标记>`，标记出现在 server.log 才算就绪。
    const PROBE_X = S.frame.x, PROBE_Y = S.frame.y - 1, PROBE_Z = S.frame.z;
    const PROBES = ['stone', 'cobblestone', 'dirt', 'sand', 'gravel'];
    for (let i = 0; i < 40; i++) {
        const blk = PROBES[i % PROBES.length];
        const id = probeId();
        await rpc.call(rpc, id, `setblock ${PROBE_X} ${PROBE_Y} ${PROBE_Z} minecraft:${blk}`, { timeoutMs: 15000 }).catch(() => null);
        await sleep(300);
        // 服务端真值确认：让服务端自己说这一格是什么
        const marker = `@@CHUNKOK_${i}_${blk}`;
        const mid = probeId();
        await rpc.call(rpc, mid, `execute if block ${PROBE_X} ${PROBE_Y} ${PROBE_Z} minecraft:${blk} run say ${marker}`, { timeoutMs: 10000 }).catch(() => null);
        await sleep(350);
        try {
            if (fs.readFileSync(SERVER_LOG, 'utf8').includes(marker)) {
                return { ok: true, rounds: i + 1, probe: blk };
            }
        } catch { /* 日志还没生成 */ }
        await sleep(200);
    }
    return { ok: false, rounds: 40 };
}

function buildScene() {
    // 铺一块石台
    for (let dx = -8; dx <= 8; dx++) {
        for (let dz = -8; dz <= 8; dz++) {
            setb(SCENE.frame.x + dx, SCENE.frame.y - 1, SCENE.frame.z + dz, 'stone');
        }
    }
    // 门框：4 宽 × 5 高，只缺 missing 那一格
    for (let u = 0; u < 4; u++) {
        setb(SCENE.frame.x + u, SCENE.frame.y, SCENE.frame.z, u === 1 ? 'air' : 'obsidian');   // 底行缺 u=1
        setb(SCENE.frame.x + u, SCENE.frame.y + 4, SCENE.frame.z, 'obsidian');                  // 顶行
    }
    for (let dy = 1; dy <= 3; dy++) {
        setb(SCENE.frame.x, SCENE.frame.y + dy, SCENE.frame.z, 'obsidian');
        setb(SCENE.frame.x + 3, SCENE.frame.y + dy, SCENE.frame.z, 'obsidian');
    }
    // 内部 2×3 必须是空气（点火前提）
    for (let u = 1; u <= 2; u++) {
        for (let dy = 1; dy <= 3; dy++) setb(SCENE.frame.x + u, SCENE.frame.y + dy, SCENE.frame.z, 'air');
    }
    // ★ r7 修正（**这才是 scoop 失败的真根因**）：我把岩浆坑**四周全用石头封死**，
    //   结果 pathfinder 压根走不进去 —— standableBeside 选出的站位在坑外，
    //   navTo 反复失败，bot 停在 2.6 格外（实测眼睛 (109.59,70.62,100.5)，
    //   源块在 (107,69,100)，差 2.6 格），射线**什么也没打中**（rayHit=null）。
    //   真实世界里舀岩浆的池子**边缘是可站立的**（r5 的 scene.mjs 就是这么布的：
    //   源块在 (205,70,198)，站位 (204.5,70,200) 踩在平台上，与源块斜前方相邻）。
    //   正确做法：源块放在坑的**一角**，紧邻一块可站立的实心边缘 —— 模拟真人站在池边舀。
    const P = SCENE.lavaPit;
    for (let x = P.x0; x <= P.x1; x++) {
        for (let z = P.z0; z <= P.z1; z++) {
            for (let y = P.y0; y <= P.y1; y++) {
                // 坑底一律石头（承托源块，不让岩浆往下漏）
                if (y === P.y1) { setb(x, y, z, 'stone'); continue; }
                // 源块那一格及其西侧（防水平铺开）保留空气；其余填石头封住
                const isSrc = (x === SCENE.lavaSource[0] && z === SCENE.lavaSource[2]);
                const keepWest = (x === SCENE.lavaSource[0] - 1 && Math.abs(z - SCENE.lavaSource[2]) <= 1);
                if (isSrc || keepWest) setb(x, y, z, 'air');
                else setb(x, y, z, 'stone');
            }
        }
    }
    setb(...SCENE.lavaSource, 'lava');
    // ★ 池边可站立的边缘：源块正东 1 格、坑外一格，踩实心石头（真人站池边舀浆的姿势）
    setb(SCENE.lavaSource[0] + 1, SCENE.lavaSource[1], SCENE.lavaSource[2], 'stone');
    // 站位实心（stand 与 standLava 各垫一块）
    for (const s of [SCENE.stand, [SCENE.standLava[0], SCENE.standLava[1], SCENE.standLava[2]]]) {
        setb(Math.floor(s[0]), Math.floor(s[1]) - 1, Math.floor(s[2]), 'stone');
        setb(Math.floor(s[0]), Math.floor(s[1]), Math.floor(s[2]), 'air');
    }
}

async function main() {
    const st = await waitLane(LANE_B, { maxMs: 15 * 60 * 1000, pollMs: 15000, onWait: (s) => log(`泳道 B 不可用（${s.why}）`) });
    if (!st.usable) { console.error(`[micro] 等不到泳道 B（${st.why}）`); process.exit(1); }
    await waitFreeMem(MIN_FREE_MB * 1048576, log);
    if (!laneStatus(LANE_B).usable) { console.error('[micro] 泳道 B 被占'); process.exit(1); }

    freshWorld(LANE_B, SEED);
    server = await bootServerWithRetry(LANE_B, RUNS_DIR, '1G', log);
    LANE_B.serverChild = server.child;
    log(`[micro] server up in ${(server.bootMs / 1000).toFixed(0)}s`);
    // ★ r7：起 rpc 回执通道（与 r5 的 micro_bench 同一套），此后所有命令经它发
    rpc = makeRpc(RPC_DIR);
    const served = serveRpc({ reqDir: rpc.reqDir, doneDir: rpc.doneDir, serverChild: server.child, log });
    rpcStop = served.stop;

    const EX = (f) => import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec', f)).href);
    const liquid = await EX('liquid.js');
    const pc = await EX('patch_cell.js');
    log('[micro] 生产原语已加载');

    bot = mineflayer.createBot({ host: '127.0.0.1', port: LANE_B.serverPort, username: LANE_B.username, version: MC_VERSION });
    await new Promise((res, rej) => {
        bot.once('spawn', res); bot.once('error', rej);
        setTimeout(() => rej(new Error('spawn timeout 120s')), 120000);
    });
    bot.loadPlugin(pf.pathfinder);
    await sleep(3000);
    await cmd(`op ${LANE_B.username}`);

    let deaths = 0;
    bot.on('death', () => { deaths++; log('[micro] ☠️ died'); });

    const rows = [];
    for (let i = 1; i <= N; i++) {
        // —— 每轮重置：只清背包 + 重建场景，**绝不 `kill` bot** ——
        // ★★★ r7 修正：r6 用 `kill` 做轮次重置，结果**第 2 轮起 bot 再也没起来**。
        //   server.log 证据（P8R7_MICRO3）：10 次 `Killed MicroBotB`，但
        //   **没有一次 respawn / 二次 joined the game** ⇒ bot 卡在死亡界面，
        //   后续 give/tp/forceload 全部落空（give 计数 = 0），
        //   表现出来是"区块永远不就绪"（轮询 60 次全失败）。
        //   正确做法照 r5 验证过 30/30 的 micro_bench/micro_bot：
        //   **`clear` 背包 + `fill` 清扫区 + 重建场景**，bot 全程活着。
        //
        // ★★ r7 再修一处（**岩浆死亡的直接原因**）：tp 必须放在轮次**最前面**。
        //   出生点是 `(-235,68,-248)`，布景在 `(100,70,100)` —— **相距 470 格**。
        //   去掉 kill 之后 bot 一直待在出生点那片地形上，而 `clear`/`buildScene` 要花好几秒，
        //   这段时间它仍在游荡 —— P8R7_MICRO6 实测就在这段窗口里
        //   `tried to swim in lava`（server.log：`No chunks were marked` 之后 1 秒）。
        //   **岩浆死亡 0 是硬线，所以"先把 bot 拉到场景边、再做一切事"是本微基准的强制顺序。**
        await cmd(`tp ${LANE_B.username} ${SCENE.stand[0]} ${SCENE.stand[1] + 1} ${SCENE.stand[2]}`);
        await sleep(1200);
        await cmd(`clear ${LANE_B.username}`);
        await sleep(500);
        // 区块就绪：forceload(四参数) + 轮询探针（r7 修正，见 ensureChunksLoaded 注释）
        const chunks = await ensureChunksLoaded();
        if (!chunks.ok) {
            log(`[micro] 第 ${i} 轮区块没就绪（轮询 ${chunks.rounds} 次），跳过`);
            rows.push({ i, event: '_scene_fail', d: { chunksLoaded: false, rounds: chunks.rounds } });
            continue;
        }
        buildScene();
        await sleep(1200);
        // ★ 布景**必须校验**：手册 §5 明确「/fill 失败时不会打出成功日志，所以要检查返回文本，
        //   不能只看『没报错』」。这里读回执：缺格必须是 air、缺格下方必须是 lava，
        //   站位脚下必须是 stone。任一不符就地报布景失败，别让失败一路漏到断言里。
        const sceneOk = {
            missingIsAir: bname(...SCENE.missing) === 'air',
            // r7：岩浆源在**独立坑**里，缺格下方必须仍是实心石头（不能有岩浆，否则倒水会冲场景）
            belowMissingSolid: bname(SCENE.missing[0], SCENE.missing[1] - 1, SCENE.missing[2]) === 'stone',
            lavaSourceOk: bname(...SCENE.lavaSource) === 'lava',
            lavaEnclosed: bname(SCENE.lavaSource[0] + 1, SCENE.lavaSource[1], SCENE.lavaSource[2]) === 'stone',
            standBelow: bname(SCENE.stand[0], SCENE.stand[1] - 1, SCENE.stand[2]) === 'stone',
            // ★ r7 新增：**池边站位必须存在且脚下实心**。
            //   上一版把岩浆坑四周全封死，pathfinder 走不进去，bot 停在 2.6 格外，
            //   射线 rayHit=null → scoop_fail。根因是布景，但**光看"源块在不在"查不出来**
            //   （布景校验全过），必须显式校验站位。
            standLavaOk: bname(Math.floor(SCENE.standLava[0]), Math.floor(SCENE.standLava[1]), Math.floor(SCENE.standLava[2])) === 'air',
            standLavaBelow: bname(Math.floor(SCENE.standLava[0]), Math.floor(SCENE.standLava[1]) - 1, Math.floor(SCENE.standLava[2])) === 'stone',
        };
        if (!Object.values(sceneOk).every(Boolean)) {
            log(`[micro] 第 ${i} 轮**布景失败** ${JSON.stringify(sceneOk)} —— 场景没建起来，结果不可信`);
            rows.push({ i, event: '_scene_fail', d: sceneOk });
            continue;
        }
        // 两桶打法的初始状态：**一只水桶 + 一只空桶**（复现"路上已装好水"）
        // （背包已在轮次开头 clear 过，这里不再重复 clear —— 两次 clear 相邻会互相抵消 give）
        await cmd(`give ${LANE_B.username} minecraft:water_bucket 1`);
        await sleep(400);
        await cmd(`give ${LANE_B.username} minecraft:bucket 1`);
        await sleep(400);
        await cmd(`give ${LANE_B.username} minecraft:stone_pickaxe 1`);
        await sleep(800);
        // 安全落点（★不能直接落到场景中心，可能掉进岩浆洞）
        await cmd(`tp ${LANE_B.username} ${SCENE.stand[0]} ${SCENE.stand[1] + 1} ${SCENE.stand[2]}`);
        await sleep(3000);
        if (bot.entity?.position) {
            // ★ 等落地。第一版没等，每轮测完的 bot 还悬在 tp 的下落途中 → 被判死
            //   （"☠️ died" 每轮都出现，但那是我自己 kill 的，不是测试失败；
            //   真正的问题是死后的 bot 状态不确定，give 的物品可能掉在死亡点）。
            for (let k = 0; k < 30; k++) { if (bot.entity.position.onGround) break; await sleep(200); }
            await sleep(400);
            // 确认真的站在地上、且不在液体里
            const p = bot.entity.position.floored();
            const feet = bname(p.x, p.y, p.z);
            if (feet === 'lava' || feet === 'water') {
                log(`[micro] 第 ${i} 轮落点在液体里（${feet}），重试一次 tp`);
                await cmd(`tp ${LANE_B.username} ${SCENE.stand[0]} ${SCENE.stand[1] + 1} ${SCENE.stand[2]}`);
                await sleep(2000);
            }
        }
        // 复核 kit 是否真的到手（give 偶发失败时不能带着空背包去测）
        const kitNow = {
            water: bot.inventory.items().filter((x) => x.name === 'water_bucket').length,
            empty: bot.inventory.items().filter((x) => x.name === 'bucket').length,
        };
        if (kitNow.water < 1 || kitNow.empty < 1) {
            log(`[micro] 第 ${i} 轮 kit 不到 ${JSON.stringify(kitNow)}，补发`);
            if (kitNow.water < 1) { await cmd(`give ${LANE_B.username} minecraft:water_bucket 1`); await sleep(500); }
            if (kitNow.empty < 1) { await cmd(`give ${LANE_B.username} minecraft:bucket 1`); await sleep(500); }
        }

        const before = {
            missing: bname(...SCENE.missing),
            water: bot.inventory.items().filter((x) => x.name === 'water_bucket').length,
            empty: bot.inventory.items().filter((x) => x.name === 'bucket').length,
        };
        const deathsBefore = deaths;
        const t0 = Date.now();

        // —— 跑完整循环（生产代码 castCellByHauling，两桶打法版）——
        // ⚠ ctx 必须带 `run.counters`：生产代码的 navTo 会写 `ctx.run.counters.navAttempts`
        //   / `navFailures` / `phaseMs.nav`（见 nav.js:93/127/138/144）。
        //   第一版只给了 {bot, telemetry}，于是 navTo 立刻抛 "Cannot read properties of
        //   undefined (reading 'navAttempts')" → 被 catch 吞掉 → 9~187ms 就
        //   `approach_fail:not_close_enough`。**看起来像"走不过去"，其实是 ctx 不完整。**
        //   —— 这正是手册 §5「先证伪工具」的又一次：先怀疑自己的 harness，再怀疑原语。
        const counters = { navAttempts: 0, navFailures: 0, phaseMs: { nav: 0, search: 0, mine: 0, recover: 0 } };
        const fakeCtx = {
            bot,
            run: { counters },
            telemetry: (e, d) => { if (e.startsWith('patch_') || e.startsWith('water_') || e.startsWith('nav_')) rows.push({ i, event: e, d }); },
        };
        const r = await pc.castCellByHauling(bot, new Vec3(...SCENE.missing), {
            ctx: fakeCtx, GoalNear: pf.goals.GoalNear,
            telemetry: (e, d) => {
                // ★ r7：把 liquid_scoop_* / liquid_act_* 也收进 rows —— 里面有**瞄准点遥测**
                //   （射线的 eye / 方向 / 视线实际打到的方块 / 是否与预期一致），
                //   这是定位 scoop_fail 唯一缺的信息。
                if (e.startsWith('patch_') || e.startsWith('water_') || e === 'cast_ok' || e === 'cast_fail'
                    || e.startsWith('nav_') || e.startsWith('liquid_')) {
                    rows.push({ i, event: e, d });
                }
            },
            label: `micro${i}`,
        });
        const ms = Date.now() - t0;

        const after = {
            cell: bname(...SCENE.missing),
            water: bot.inventory.items().filter((x) => x.name === 'water_bucket').length,
            empty: bot.inventory.items().filter((x) => x.name === 'bucket').length,
            lavaBucket: bot.inventory.items().filter((x) => x.name === 'lava_bucket').length,
        };
        const tele = rows.filter((x) => x.i === i);
        const rec = {
            i, before, after, result: r, ms,
            // 五个判据分别记，别只看总成功
            c1_scooped: tele.some((x) => x.event === 'patch_scoop_ok'),
            c2_poured_source: tele.some((x) => x.event === 'patch_pour_ok'),
            c3_cast_obsidian: after.cell === 'obsidian',
            c4_water_recovered: after.water >= 1,        // ★ 命根子
            c5_no_lava_death: deaths === deathsBefore,
            ok: r.ok && after.cell === 'obsidian' && after.water >= 1,
        };
        log(`[micro] ${i}/${N} ${rec.ok ? '✅' : '❌'} cell=${after.cell} 水桶=${after.water} 空桶=${after.empty} `
            + `| scoop=${rec.c1_scooped} pour=${rec.c2_poured_source} cast=${rec.c3_cast_obsidian} 舀回水=${rec.c4_water_recovered} 无死亡=${rec.c5_no_lava_death} (${ms}ms) ${r.reason ?? ''}`);
        rows.push({ i, event: '_round', d: rec });
    }

    let lavaDeaths = 0;
    try {
        const txt = fs.readFileSync(path.join(RUNS_DIR, 'server.log'), 'utf8');
        lavaDeaths = (txt.match(/tried to swim in lava/g) ?? []).length;
    } catch { /* 忽略 */ }

    const rounds = rows.filter((x) => x.event === '_round').map((x) => x.d);
    const sceneFails = rows.filter((x) => x.event === '_scene_fail').length;
    const stat = (k) => rounds.filter((r) => r[k]).length;
    const summary = {
        stamp: STAMP, seed: SEED, n: rounds.length, sceneFails,
        pass: rounds.filter((r) => r.ok).length,
        c1_scooped: stat('c1_scooped'),
        c2_poured_source: stat('c2_poured_source'),
        c3_cast_obsidian: stat('c3_cast_obsidian'),
        c4_water_recovered: stat('c4_water_recovered'),
        c5_no_lava_death: stat('c5_no_lava_death'),
        lavaDeaths, botDeaths: deaths,
        medianMs: rounds.map((r) => r.ms).sort((a, b) => a - b)[Math.floor(rounds.length / 2)] ?? null,
        rounds,
    };
    fs.writeFileSync(path.join(RUNS_DIR, 'micro_two_bucket.json'), JSON.stringify(summary, null, 2));

    const rate = (k) => (rounds.length ? `${stat(k)}/${rounds.length} = ${(stat(k) / rounds.length * 100).toFixed(0)}%` : '-');
    const md = [
        `# 两桶打法微基准（${STAMP}）`, '',
        `- 种子 \`${SEED}\`；轮次 ${rounds.length}；判定 阈值 **≥95%**`,
        sceneFails ? `- ⚠ **布景失败轮次 = ${sceneFails}**（场景没建起来，这些轮次不计入）` : '- 布景校验全部通过',
        '',
        '| 判据 | 结果 | 门槛 |', '|---|---|---|',
        `| 整体成功 | **${summary.pass}/${rounds.length} = ${(summary.pass / Math.max(1, rounds.length) * 100).toFixed(0)}%** | ≥95% |`,
        `| ① 舀到岩浆 | ${rate('c1_scooped')} | — |`,
        `| ② 倒进缺格且是源块 | ${rate('c2_poured_source')} | — |`,
        `| ③ 倒水后变 obsidian | ${rate('c3_cast_obsidian')} | — |`,
        `| ④ **水舀回桶里** | ${rate('c4_water_recovered')} | — |`,
        `| ⑤ 岩浆死亡 0 | ${rate('c5_no_lava_death')} | **0 容忍** |`,
        '',
        `- **岩浆死亡总数 = ${lavaDeaths}**（server.log 权威）｜bot death 事件 = ${deaths}`,
        `- 中位耗时 ${summary.medianMs}ms`, '',
        '## 逐轮', '',
        '| 轮 | 缺格之前 | 缺格之后 | 水桶 | 空桶 | 结果 | reason | ms |', '|---|---|---|---|---|---|---|---|',
        ...rounds.map((r) => `| ${r.i} | ${r.before.missing} | **${r.after.cell}** | ${r.after.water} | ${r.after.empty} | ${r.ok ? '✅' : '❌'} | ${r.result?.reason ?? '-'} | ${r.ms} |`),
        '', '## 瞄准点遥测（r7 新增，定位 scoop_fail 的关键）', '',
        '| 轮 | 事件 | 眼睛位置 | 想点的方块 | 视线实际打到 | 方块名 | 与预期一致 |',
        '|---|---|---|---|---|---|---|',
        ...rows.filter((x) => x.event === 'liquid_scoop_fail' || x.event === 'liquid_scoop_ok' || x.event === 'liquid_act_fail')
            .map((x) => {
                const a = x.d?.aim;
                if (!a) return `| ${x.i} | ${x.event} | - | - | - | - | - |`;
                return `| ${x.i} | ${x.event} | ${(a.eye ?? []).join(',')} | ${(a.wantRef ?? []).join(',')} | `
                    + `${a.rayHit ? (a.rayHit.at ?? []).join(',') : 'null'} | ${a.rayHit?.name ?? '-'} | ${a.hitMatchesWant ? '✅' : '❌'} |`;
            }).slice(0, 24),
    ].join('\n');
    fs.writeFileSync(path.join(RUNS_DIR, 'micro_two_bucket.md'), md);
    console.log(md);

    try { bot.quit(); } catch { /* 忽略 */ }
    await sleep(1000);
    await stopServer(LANE_B, server);
    const allOk = rounds.length > 0 && summary.pass / rounds.length >= 0.95 && lavaDeaths === 0;
    log(`=== 两桶打法微基准：${summary.pass}/${rounds.length}，岩浆死亡 ${lavaDeaths} ===`);
    process.exit(allOk ? 0 : 2);
}

installRunnerHooks(LANE_B);
main().catch(async (e) => {
    console.error(e);
    try { if (bot) bot.quit(); } catch { /* 忽略 */ }
    try { if (server) await stopServer(LANE_B, server); } catch { /* 忽略 */ }
    process.exit(1);
});
