// cleanup.mjs — MC-M1-TASK-06c P0：收工清理（手册 §1）。run 结束与异常退出时由 runner_core
// 自动调用，也可单独跑：node bench/stages/_lib/cleanup.mjs [--keep-world] [--json] [--lane A] [--label 说明]
//
// 做四件事，最后输出一段可以直接贴进报告的摘要：
//   1. 给**本进程起过并登记在册**的各泳道服务器进程通过 **stdin 控制台**发 stop（手册 §2：RCON 会
//      毒化服务进程，一律用 stdin），等进程退出；超时只强杀登记过的那些；
//   2. 删掉各泳道的 world（level-name 三件套 + bench 固定世界名），**只在本次指定的泳道范围内**；--keep-world 跳过；
//   3. 复核：本次在管的端口是否已释放、**登记表里**是否还有残留 pid；
//   4. 非空闲 → 退出码 1（DIRTY）。
//
// ⚠ ROUND3 派单 P0-1（手册 §9.2）：**处置只看 `.lane-owners` 台账，不看命令行**。
//   台账 = 「某个 runner 亲手起过、且当时还活着的 pid」。不在台账里的进程 = 别的开发线的，
//   **只报告、不处置**。旧口径「命令行匹配 bench/stages 就算残留」已删除——它连着三次误杀
//   （06c 杀 B 线 micro_bench、ROUTE-02 两次杀 E 线 run_probe）。宁可漏清，不可误杀。

import fs from 'fs';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { ROOT, LANE_PORTS, LANE_LETTERS, TASKED_SMOKE_PORT, MEM_PER_LANE_MB, netstatListeners, procInfo, killTree, ownerHeartbeat, ownerHeartbeatClear, liveOwnerPids, ownedByLiveSession, pidRegistry, killableOrphanTargets } from './preflight.mjs';

const LIB_DIR = path.dirname(fileURLToPath(import.meta.url));
export const log = (msg) => console.log(`[cleanup ${new Date().toISOString().slice(11, 19)}] ${msg}`);

// ---- 在跑泳道注册表（runner_core 起服后登记，cleanup 据此发 stdin stop）----
// 同时维护「泳道归属心跳 + 进程登记台账」：每 3s 刷新 experiments/mc1161-gate/.lane-owners/<lane>.json，
// 里面记 { runnerPid, sessionId, children:[pid,...] }——**children 就是这个 runner 亲手起过的 pid**。
// 手册 §9.2：只有台账里的 pid 才允许被结束。
const live = []; // { child, lane, runDir, ownerFile, isServer }
let beatTimer = null;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 按服务器目录分组写心跳：同一泳道的 java + bot 合成一条记录（children = 本 runner 亲手起的活 pid） */
function beatAll() {
    const groups = new Map();
    for (const rec of live) {
        if (!rec.lane?.dir) continue;
        const g = groups.get(rec.lane.dir) ?? { lane: rec.lane, children: [] };
        if (rec.child?.pid && rec.child.exitCode === null) g.children.push(rec.child.pid);
        groups.set(rec.lane.dir, g);
    }
    for (const [dir, g] of groups) {
        const p = ownerHeartbeat(dir, { lane: g.lane?.name, port: g.lane?.serverPort, serverDir: dir, children: g.children });
        for (const rec of live) if (rec.lane?.dir === dir) rec.ownerFile = p;
    }
    for (const rec of live) {
        if (rec.lane?.dir && !groups.has(rec.lane.dir)) unbeat(rec);
    }
    if (groups.size && !beatTimer) beatTimer = setInterval(beatAll, 3000);
    if (!groups.size && beatTimer) { clearInterval(beatTimer); beatTimer = null; }
}
function unbeat(rec) {
    if (rec.ownerFile) { ownerHeartbeatClear(rec.lane?.dir); rec.ownerFile = null; }
}
/** 起服方调用：登记一个子进程（java 服务器 / mineflayer bot 都算），并把它写进台账 */
export function registerChild(child, lane, runDir) {
    const rec = { child, lane, runDir, at: Date.now(), ownerFile: null, isServer: true };
    live.push(rec);
    beatAll();
    const drop = () => { const i = live.indexOf(rec); if (i >= 0) live.splice(i, 1); beatAll(); unbeat(rec); };
    child.once('exit', drop);
    return rec;
}
/** runner_core 起 bot 时调用：登记进同一张台账（它没有 stdin，但它是本 runner 起的进程，必须可被回收） */
export function registerProc(child, lane, runDir) {
    const rec = { child, lane, runDir, at: Date.now(), ownerFile: null, isServer: false };
    live.push(rec);
    beatAll();
    const drop = () => { const i = live.indexOf(rec); if (i >= 0) live.splice(i, 1); beatAll(); unbeat(rec); };
    child.once('exit', drop);
    return rec;
}
export function unregisterChild(rec) {
    const i = live.indexOf(rec); if (i >= 0) live.splice(i, 1);
    beatAll();
    if (!live.length) unbeat(rec);
}
export function liveChildren() { return [...live]; }

// ---- 泳道目录 ----
// 默认只认「本线当前 bench 模板 + 自动派生的 _laneB/_laneC」（env MC_BENCH_SERVER 或 1.16.1 闸门目录），
// 避免误删同一台机器上其他历史测试服目录里的世界；--all-lanes 才扫 experiments/ 下所有命中契约端口的目录。
// 另外只删 maxAgeHours 内有改动的 world（历史遗留世界不动）。
export function defaultTemplateDir() {
    return process.env.MC_BENCH_SERVER || path.join(ROOT, 'experiments', 'mc1161-gate', 'server-1161');
}

export function laneDirs({ allLanes = false } = {}) {
    const SUFFIX = ['', 'B', 'C', 'D', 'E'];
    const tpl = defaultTemplateDir();
    if (!allLanes) {
        return SUFFIX.map((s) => (s ? `${tpl}_lane${s}` : tpl))
            .filter((dir) => fs.existsSync(path.join(dir, 'server.properties')))
            .map((dir) => ({ dir, port: Number(/^server-port=(\d+)$/m.exec(fs.readFileSync(path.join(dir, 'server.properties'), 'utf8'))?.[1] ?? 0) }));
    }
    const want = new Set([25566, 25567, 25568]);
    const expDir = path.join(ROOT, 'experiments');
    const found = [];
    const walk = (dir, depth) => {
        if (depth > 3 || !fs.existsSync(dir)) return;
        for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
            if (!e.isDirectory()) continue;
            const p = path.join(dir, e.name);
            const sp = path.join(p, 'server.properties');
            if (fs.existsSync(sp)) {
                const m = /^server-port=(\d+)$/m.exec(fs.readFileSync(sp, 'utf8'));
                if (m && want.has(Number(m[1]))) found.push({ dir: p, port: Number(m[1]) });
            }
            if (depth < 2 && !/(world|logs|crash-reports|jdk|data|downloads)/.test(e.name)) walk(p, depth + 1);
        }
    };
    walk(expDir, 0);
    return found.sort((a, b) => a.port - b.port);
}

const BENCH_WORLD_NAMES = ['spike_world', 'probe_world'];
export function worldDirsOfLane(laneDir, { maxAgeHours = 12 } = {}) {
    const sp = path.join(laneDir, 'server.properties');
    let levelName = null;
    try { levelName = /^level-name=(.+)$/m.exec(fs.readFileSync(sp, 'utf8'))?.[1]?.trim() ?? null; } catch { /* 忽略 */ }
    const names = new Set();
    for (const base of [levelName, ...BENCH_WORLD_NAMES].filter(Boolean)) names.add(base);
    const out = [];
    for (const n of names) for (const suffix of ['', '_nether', '_the_end']) {
        const p = path.join(laneDir, n + suffix);
        if (!fs.existsSync(p)) continue;
        let ageH = 0;
        try { ageH = (Date.now() - fs.statSync(p).mtimeMs) / 3600000; } catch { /* 忽略 */ }
        if (maxAgeHours > 0 && ageH > maxAgeHours) continue; // 历史遗留世界不动
        out.push(p);
    }
    return out;
}

/**
 * @param {{children?:Array, killStale?:boolean, rmWorlds?:boolean, stopTimeoutMs?:number,
 *          logFn?:Function, label?:string, dirs?:Array}} [opt]
 */
export async function cleanup(opt = {}) {
    const say = opt.logFn ?? log;
    const { killStale = true, rmWorlds = true, stopTimeoutMs = 20000 } = opt;
    const lines = [];
    const push = (s) => { lines.push(s); say(s); };
    push(`start${opt.label ? ` (${opt.label})` : ''}：stdin stop → 强杀本线残留 → 删 world → 复核`);

    // 1) 在跑泳道：stdin stop
    const children = opt.children ?? live;
    let stopped = 0, forced = 0;
    for (const rec of children) {
        const child = rec.child ?? rec;
        const name = rec.lane?.name ?? '?';
        if (!rec.isServer) { push(`  lane ${name}: bot pid=${child.pid}（已登记，稍后按台账回收）`); continue; }
        const t0 = Date.now();
        try { if (child.stdin && !child.stdin.destroyed) child.stdin.write('stop\n'); } catch { /* 已断 */ }
        while (child.exitCode === null && Date.now() - t0 < stopTimeoutMs) await sleep(250);
        if (child.exitCode === null) {
            killTree(child.pid); forced++; push(`  lane ${name}: stdin stop ${Math.round(stopTimeoutMs / 1000)}s 未退 → 强杀**本 runner 自己起的** pid=${child.pid}`);
        } else { stopped++; push(`  lane ${name}: stdin stop → exit=${child.exitCode} in ${((Date.now() - t0) / 1000).toFixed(1)}s`); }
    }
    if (!children.length) push('  无登记在跑泳道（本进程没起服或已跑完）');

    // 2) 进程复核与残留回收 —— **处置只看 pid 台账**（ROUND3 P0-1）
    //    台账 = `.lane-owners/<serverDir>.json` 的 children[]，由本 runner 起服时登记。
    //    不在台账里的进程（别的开发线的自定义 bench 脚本、非本机的、用户自己起的）**一条都不动**。
    const procs = procInfo();
    const procsById = new Map(procs.map((p) => [p.pid, p]));
    const listeners = netstatListeners();
    const ports = [...LANE_PORTS.flat(), TASKED_SMOKE_PORT];
    const myPids = new Set(live.map((r) => r.child?.pid).filter(Boolean));
    let killed = 0;
    for (const pid of myPids) {                       // 自己起的、还活着的：先收干净
        const rec = live.find((r) => r.child?.pid === pid);
        if (rec?.child?.exitCode !== null) continue;
        if (killStale) { killTree(pid); killed++; push(`  残留：kill 本 runner 登记的 pid=${pid} lane=${rec?.lane?.name}`); }
    }
    // 台账里、登记它的 runner 已死的孤儿 —— 这才是「上一轮跑崩留下的」，--kill-stale 只碰这些
    for (const r of killableOrphanTargets(pidRegistry(new Set(procs.map((p) => p.pid))), { excludePids: myPids })) {
        const p = procsById.get(r.pid);
        if (killStale) { killTree(r.pid); killed++; push(`  残留：kill 登记孤儿 pid=${r.pid} lane=${r.lane}（runner ${r.runnerPid} 已死）${String(p?.cmd ?? '').slice(0, 90)}`); }
        else push(`  X 登记孤儿 pid=${r.pid} lane=${r.lane}（runner ${r.runnerPid} 已死，--kill-stale 才清）`);
    }
    // 台账外的一切 java/node：只报告
    const reg = pidRegistry(new Set(procs.map((p) => p.pid)));
    const unowned = procs.filter((p) => !reg.has(p.pid) && !myPids.has(p.pid) && p.pid !== process.pid
        && /(-jar|bench[/\\]stages|mc1161-gate|run_tasked_smoke)/.test(p.cmd.replace(/\\/g, '/')));
    for (const p of unowned) {
        const live0 = ownedByLiveSession(p, procsById, liveOwnerPids(new Set(procs.map((x) => x.pid))));
        push(`  ? pid=${p.pid} ${p.name} ${live0 ? `活 runner ${live0} 的后代` : '无台账归属'} → **不是本 runner 起的，只报告不处置**: ${String(p.cmd).slice(0, 90)}`);
    }

    // 3) 删各泳道 world
    //    ⚠ 06d P0 安全收口：**只在本次指定的泳道范围内删**。旧口径 `opt.dirs ?? laneDirs()` 在
    //    独立调用（CLI/无参）时默认返回**全部三条泳道** → 本线收工会去删别的开发线的 world
    //    （实测：线 B/C 的服在跑，只因文件被锁才 EPERM 挡住；它们一停就会被删）。
    //    现在的规则：opt.dirs 优先；否则按 --lane / --lanes 过滤；都没给则**只处理本进程起过的
    //    泳道**，再没有就一条都不删。
    const scopedPorts = new Set();
    for (const n of (opt.laneNames ?? [])) {
        const i = LANE_LETTERS.indexOf(String(n).toUpperCase());
        if (i >= 0) { scopedPorts.add(LANE_PORTS[i][0]); scopedPorts.add(LANE_PORTS[i][1]); }
    }
    if (opt.lanes) for (let i = 0; i < opt.lanes; i++) { scopedPorts.add(LANE_PORTS[i][0]); scopedPorts.add(LANE_PORTS[i][1]); }
    for (const rec of live) {
        if (rec.lane?.serverPort) { scopedPorts.add(rec.lane.serverPort); scopedPorts.add(rec.lane.rconPort); }
    }
    const allDirs = opt.dirs ?? laneDirs({ allLanes: opt.allLanes });
    const dirs = opt.dirs
        ? allDirs
        : (scopedPorts.size
            ? allDirs.filter((d) => scopedPorts.has(d.port))
            : (live.length ? [] : [{ dir: defaultTemplateDir(), port: LANE_PORTS[0][0] }]));   // 独立 CLI 默认只管 A
    if (!opt.dirs && !scopedPorts.size && !live.length) {
        push('  world：独立调用且未指定 --lane/--lanes → 只处理泳道 A（不碰其他开发线的世界）');
    }
    let removed = 0;
    const removedList = [];
    if (rmWorlds) {
        for (const d of dirs) {
            for (const w of worldDirsOfLane(d.dir, { maxAgeHours: opt.maxAgeHours ?? 12 })) {
                try {
                    fs.rmSync(w, { recursive: true, force: true });
                    removed++; removedList.push(path.relative(ROOT, w).replace(/\\/g, '/'));
                } catch (e) { push(`  X world 删除失败 ${w}: ${String(e).slice(0, 80)}`); }
            }
        }
        push(`  world：删除 ${removed} 个目录（${dirs.length} 条泳道目录：${dirs.map((d) => `${path.basename(d.dir)}:${d.port}`).join(' ')}）`);
    } else push('  world：--keep-world 跳过删除');

    await new Promise((r) => setTimeout(r, 1200));

    // 4) 复核
    //    手册 §9.2：**别的开发线正在用的端口/进程不算「脏」**。只把「我这次在管的泳道端口仍被占」
    //    和「我登记过的 pid 还活着」算脏。
    const l2 = netstatListeners();
    const procs2 = procInfo();
    const alives2 = new Set(procs2.map((x) => x.pid));
    const reg2 = pidRegistry(alives2);
    const managedPorts = (opt.dirs ?? dirs ?? []).map((d) => Number(d.port)).filter((n) => Number.isFinite(n) && n > 0);
    // MC-M1-TASK-06d P0：--lane A,C 按名定「本线」；--lanes N 保留兼容。
    const namedPorts = (opt.laneNames ?? []).flatMap((n) => {
        const i = LANE_LETTERS.indexOf(String(n).toUpperCase());
        return i < 0 ? [] : LANE_PORTS[i];
    });
    const myPorts = managedPorts.length
        ? [...managedPorts, ...managedPorts.map((p) => p + 10), TASKED_SMOKE_PORT]
        : (namedPorts.length
            ? [...namedPorts, TASKED_SMOKE_PORT]
            : [...LANE_PORTS.slice(0, (opt.lanes ?? LANE_PORTS.length)).flat(), TASKED_SMOKE_PORT]);
    const foreignBusy = [...LANE_PORTS.flat(), TASKED_SMOKE_PORT]
        .filter((pt) => !myPorts.includes(pt))
        .filter((pt) => (l2[String(pt)] ?? []).length);
    const busy = myPorts.filter((pt) => (l2[String(pt)] ?? []).length);
    // 台账归属分类：我的活进程 / 别人的活进程 / 登记孤儿 / 无台账
    const mineAlive = procs2.filter((p) => myPids.has(p.pid));
    const foreignAlive = procs2.filter((p) => reg2.has(p.pid) && !myPids.has(p.pid) && reg2.get(p.pid).runnerAlive);
    const orphanAlive = killableOrphanTargets(reg2, { excludePids: myPids });
    const unowned2 = procs2.filter((p) => !reg2.has(p.pid) && !myPids.has(p.pid) && p.pid !== process.pid
        && /(-jar|bench[/\\]stages)/.test(p.cmd.replace(/\\/g, '/')));
    const freeMB = Math.round(os.freemem() / 1048576);
    push(`  verify: 本线 ports ${busy.length ? `仍占用 ${busy.join(',')}` : `${myPorts.join(',')} 全空闲`}`
        + `${foreignBusy.length ? ` | 其他开发线在用 ${foreignBusy.join(',')}（不算脏）` : ''}`
        + ` | 本 runner 登记的进程残留 ${mineAlive.length + orphanAlive.length}`
        + `${foreignAlive.length ? `（别的开发线在跑 ${foreignAlive.length}，已排除）` : ''}`
        + `${unowned2.length ? `（无台账归属 ${unowned2.length}，只报告不处置）` : ''}`
        + ` | 空闲内存 ${freeMB}MB（≥${MEM_PER_LANE_MB}MB 才够下一条泳道）`);
    const dirty = busy.length > 0 || mineAlive.length > 0 || orphanAlive.length > 0;
    push(dirty ? '  DIRTY' : '  CLEAN');

    const summary = dirty ? 'DIRTY' : 'CLEAN';
    return {
        ok: !dirty, summary, lines, stopped, forced, killed, removed, busyPorts: busy,
        oursLeft: mineAlive.length + orphanAlive.length, othersRunning: foreignAlive.length,
        unowned: unowned2.length, foreignBusy, worlds: removedList,
    };
}

// ---- 同步收工（process.on('exit') 兜底：异常退出时至少把**自己登记过的**进程停掉）----
// 手册 §9.2：这里也只碰 live[] 里的 pid —— 那些一定是本 runner 亲手起的。
export function cleanupSync() {
    const dirs = new Set();
    for (const rec of live) {
        const child = rec.child;
        try { if (child.stdin && !child.stdin.destroyed) child.stdin.write('stop\n'); } catch { /* 忽略 */ }
        try { killTree(child.pid); } catch { /* 忽略 */ }
        if (rec.lane?.dir) dirs.add(rec.lane.dir);
    }
    for (const d of dirs) { try { ownerHeartbeatClear(d); } catch { /* 忽略 */ } }
    live.length = 0;
    if (beatTimer) { clearInterval(beatTimer); beatTimer = null; }
}

let hooksInstalled = false;
/** runner_core 调用：异常退出/SIGINT 兜底强杀本线在跑泳道（正常收工走 cleanup()）。
 *  onExit：额外收尾回调（runner_core 用它在退出时释放线锁）。 */
export function installRunnerHooks(getLabel, onExit) {
    if (hooksInstalled) return;
    hooksInstalled = true;
    const wrap = () => { try { cleanupSync(); } catch { /* 忽略 */ } try { onExit?.(); } catch { /* 忽略 */ } };
    process.on('exit', wrap);
    for (const sig of ['SIGINT', 'SIGTERM']) {
        process.on(sig, () => { log(`收到 ${sig}${getLabel ? `（${getLabel()}）` : ''}：强杀在跑泳道后退出`); wrap(); process.exit(130); });
    }
    process.on('uncaughtException', (e) => { log(`uncaught: ${String(e && e.stack ? e.stack : e).slice(0, 300)}`); wrap(); process.exit(1); });
}

const isCli = process.argv[1] && path.resolve(process.argv[1]).endsWith('cleanup.mjs');
if (isCli) {
    const has = (n) => process.argv.includes(`--${n}`);
    const val = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
    const res = await cleanup({
        killStale: true,
        rmWorlds: !has('keep-world'),
        allLanes: has('all-lanes'),
        lanes: has('lanes') ? Number(val('lanes', '3')) : undefined,
        laneNames: has('lane') ? val('lane', '').split(',').map((s) => s.trim().toUpperCase()).filter(Boolean) : undefined,
        maxAgeHours: Number(val('max-age-h', '12')),
        label: val('label', 'standalone cleanup'),
    });
    if (has('json')) console.log(JSON.stringify(res, null, 2));
    process.exit(res.ok ? 0 : 1);
}
void LIB_DIR;
