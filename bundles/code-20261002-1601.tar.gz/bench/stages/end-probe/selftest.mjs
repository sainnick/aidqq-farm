// selftest.mjs — MC-END-01 离线自测（不开服、不占内存，几秒内跑完）
//
// 存在理由（FULLRUN-01 的做法）：协议解析这类纯函数最容易在**接线之前**就悄悄错——
// 尤其本单有两个坑是有符号 byte（血量 200 读成 -56）和一张 ordinal 表（相位名对不上就分错族）。
// 这两样错了，跑到实服上表现为「血量曲线反向」「栖息永远判不出来」，而现场归因要烧一整局。
// 所以先把它们钉死，再去占泳道。

import { pathToFileURL } from 'url';
import path from 'path';
import { fileURLToPath } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
const MINDCRAFT = path.resolve(process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt/end-probe'));
const sig = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/dragon_signal.js')).href);

let pass = 0, fail = 0;
const failures = [];
function ok(cond, name, detail) {
    if (cond) { pass++; return; }
    fail++;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
}
const eq = (a, b, name) => ok(a === b, name, `got ${JSON.stringify(a)} want ${JSON.stringify(b)}`);

// ---- 1. 血量字节（文件头 (B)：200 必须归一成 200，不能是 -56）----
eq(sig.readHealthByte(-56), 200, 'health -56 → 200（prismarine 有符号读法）');
eq(sig.readHealthByte(200), 200, 'health 200 → 200');
eq(sig.readHealthByte(0), 0, 'health 0 → 0');
eq(sig.readHealthByte(-1), null, 'health -1 → null（归一后 255 越界，宁可标不可用）');
eq(sig.readHealthByte(201), null, 'health 201 → null（超过龙上限）');
eq(sig.readHealthByte(-128), 128, 'health -128 → 128（符号翻转那一格）');
eq(sig.readHealthByte(undefined), null, 'health undefined → null');
eq(sig.readHealthByte('200'), null, 'health 字符串 → null');

// ---- 2. 相位 ordinal 表（mappings L28090-28102 声明顺序）----
const names = ['HOLDING_PATTERN', 'STRAFE_PLAYER', 'LANDING_APPROACH', 'LANDING', 'TAKEOFF',
    'SITTING_FLAMING', 'SITTING_SCANNING', 'SITTING_ATTACKING', 'CHARGING_PLAYER', 'DYING', 'HOVERING'];
for (let i = 0; i < names.length; i++) eq(sig.classifyPhase(i).name, names[i], `phase ${i} = ${names[i]}`);
eq(sig.classifyPhase(5).family, 'perch', 'phase 5 = perch');
eq(sig.classifyPhase(6).family, 'perch', 'phase 6 = perch');
eq(sig.classifyPhase(7).family, 'perch', 'phase 7 = perch');
eq(sig.classifyPhase(2).family, 'landing', 'phase 2 = landing');
eq(sig.classifyPhase(3).family, 'landing', 'phase 3 = landing');
eq(sig.classifyPhase(4).family, 'takeoff', 'phase 4 = takeoff');
eq(sig.classifyPhase(9).family, 'dying', 'phase 9 = dying');
eq(sig.classifyPhase(0).family, 'cruise', 'phase 0 = cruise');
eq(sig.classifyPhase(11).family, 'unknown', 'phase 11 = unknown（表外不猜）');
eq(sig.classifyPhase(undefined).family, 'unavailable', 'phase undefined = unavailable');

// ---- 3. 索引常量（推导见文件头 (A)(B)，写死防止后人手滑改错）----
eq(sig.META_PHASE_INDEX, 15, 'META_PHASE_INDEX = 15');
eq(sig.META_HEALTH_INDEX, 8, 'META_HEALTH_INDEX = 8');

// ---- 4. 假 bot：实体挑选 / 一帧读取 ----
const mkBot = (dragon) => ({
    entities: {
        1: { id: 1, name: 'end_crystal', position: { x: 0, y: 60, z: 0 } },
        ...(dragon ? { 2: { id: 2, name: 'ender_dragon', position: { x: 1, y: 12, z: 2 }, metadata: dragon } } : {}),
    },
    version: '1.16.1',
});
const md = (health, phase) => { const a = []; a[8] = health; a[15] = phase; return a; };

const r1 = sig.readDragon(mkBot(md(-56, 5)), { headOffsetY: 6 });
ok(r1.found, 'readDragon 找到龙');
eq(r1.health, 200, 'readDragon health 归一');
eq(r1.phaseName, 'SITTING_FLAMING', 'readDragon phase 名');
ok(r1.isPerch, 'readDragon isPerch');
eq(r1.headEst[1], 18, 'readDragon headEst 加了 headOffsetY=6');
eq(sig.readDragon(mkBot(null)).found, false, '没有龙时 found=false');
eq(sig.countEntities(mkBot(md(200, 5)), 'end_crystal'), 1, 'countEntities 末影水晶');

// 部位实体不该被当成龙（1.16.1 不发独立部位实体；认到说明协议理解错了）
const partOnly = { entities: { 3: { id: 3, name: 'ender_dragon_part', position: { x: 0, y: 0, z: 0 }, metadata: md(200, 5) } } };
eq(sig.readDragon(partOnly).found, false, 'ender_dragon_part 不被认成龙');

// ---- 5. 栖息判定器：延迟 / 漏判 / 段落 ----
let clock = 1000;
const det = sig.createPerchDetector({ now: () => clock, onEvent: null });
clock = 2000; det.onMetadata({ name: 'ender_dragon', metadata: md(200, 10) });   // HOVERING：不该算
eq(det.isPerch(), false, 'HOVERING 不算栖息');
clock = 2100; det.onMetadata({ name: 'ender_dragon', metadata: md(200, 5) });    // 进入栖息
eq(det.isPerch(), true, '进入 SITTING_FLAMING → inPerch');
clock = 2150; const a1 = det.tick(sig.readDragon(mkBot(md(200, 5))));
eq(a1.act, 'BEGIN_CYCLE', '第一拍就动作');
eq(a1.latencyMs, 50, '判定延迟 = 元数据包→动作拍 = 50ms');
clock = 2200; const a2 = det.tick(sig.readDragon(mkBot(md(200, 5))));
eq(a2.act, 'IN_CYCLE', '后续拍 IN_CYCLE');
clock = 2300; det.onMetadata({ name: 'ender_dragon', metadata: md(200, 4) });    // TAKEOFF
clock = 2400; const s1 = det.snapshot();
eq(s1.episodes.length, 1, '记录 1 次栖息段落');
eq(s1.episodes[0].durMs, 200, '段落时长 200ms');
eq(s1.episodes[0].latencyMs, 50, '段落里带回判定延迟');

// 漏判：物理通道（龙 y 低）出现但相位通道没报 → 记 miss。
// 用**独立的探测器**测这一段：低位状态在真实运行里跨栖息段是连续的（龙的巡航高度 y≈60+、
// 栖息在 y≈10~12），若复用上面那个探测器，它还留着上一段的 lowHandled=true，不会再计 miss。
let clock2 = 1000;
const det2 = sig.createPerchDetector({ now: () => clock2 });
clock2 = 2000; det2.tick({ found: true, pos: [0, 10, 0] });   // 低位起始
clock2 = 2100; det2.tick({ found: true, pos: [0, 10, 0] });   // 持续低位，但相位通道没报栖息
eq(det2.snapshot().missCount, 1, '物理低位但相位未报 → 记 1 次漏判');
// 相位通道随后报栖息，同一段低位不应再重复计
clock2 = 2200; det2.onMetadata({ name: 'ender_dragon', metadata: md(200, 5) });
clock2 = 2250; det2.tick(sig.readDragon(mkBot(md(200, 5))));
clock2 = 2300; det2.tick({ found: true, pos: [0, 10, 0] });
clock2 = 2400; det2.tick({ found: true, pos: [0, 10, 0] });
eq(det2.snapshot().missCount, 1, '相位已进 perch 时低位不重复计漏判');
// 高位（巡航）应复位低位状态
clock2 = 3000; det2.tick({ found: true, pos: [0, 70, 0] });
clock2 = 3100; det2.tick({ found: true, pos: [0, 70, 0] });
eq(det2.snapshot().missCount, 1, '巡航高位不产生漏判');

// 别的实体的元数据不能触发/结束栖息判定
clock = 5000; det.onMetadata({ name: 'ender_dragon', metadata: md(200, 5) });   // 先让 det 回到栖息态
eq(det.isPerch(), true, 'det 回到栖息态');
clock = 5050; det.onMetadata({ name: 'end_crystal', metadata: md(200, 5) });
eq(det.isPerch(), true, '末影水晶的 metadata[15]=5 不影响龙的栖息判定（不误触发也不误结束）');
clock = 5100; det.onMetadata({ name: 'end_crystal', metadata: md(200, 0) });
eq(det.isPerch(), true, '别的实体的相位变化不结束龙的栖息段');

// ===========================================================================
// 第二轮（MC-END-01 续单）：栖息窗口 + E2 的三个新原语
// ===========================================================================
const pw = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/perch_window.js')).href);

// ---- 每床伤害模型（1.16.1 字节码口径）----
eq(pw.BED_EXPLOSION_RADIUS, 5, '床爆半径 = 5.0（bvm.a 偏移 144 的 ldc 5.0f）');
eq(pw.DRAGON_EYE_OFFSET_Y, 6.8, '龙眼高 = height*0.85 = 6.8（getEyeHeight）');
const d0 = pw.predictedBedDamage(0, { extraParts: 0 });
eq(d0.head, 21, '爆心正中的龙头吃满：(0*7+0)/2*5+1 → 21');
eq(d0.other, 6, '非龙头部位 amount/4+min(amount,1) = 21/4+1 = 6');
const dHalf = pw.predictedBedDamage(2.5, { extraParts: 0 });
eq(dHalf.head, 10, '距离 2.5 格：f=0.5 → ((3.5+0.25)/2)*5+1 = 10');
eq(pw.predictedBedDamage(6, {}).head, 0, '距离 ≥ 半径 → 0 伤害（够不着）');
ok(pw.predictedBedDamage(0, { extraParts: 4 }).total === 45, '爆心正中 + 4 个部位 = 21+4*6 = 45（rmalde 报的 46 量级）',
    JSON.stringify(pw.predictedBedDamage(0, { extraParts: 4 })));
ok(pw.predictedBedDamage(1, {}).head > pw.predictedBedDamage(3, {}).head, '距离越近伤害越大（单调）');
eq(pw.predictedBedDamage(2.5, { seen: 0.5 }).head, 5, '遮挡减半：seenPercent 线性进 f');

// ---- 视线射线 ----
// 假 bot：air 的 blockAt 返回非实心，stone 返回实心
const mkWorld = (solid) => ({
    entity: { position: { x: 0, y: 64, z: 0 }, onGround: true },
    blockAt: (v) => ({ name: solid.has(`${v.x},${v.y},${v.z}`) ? 'stone' : 'air', boundingBox: solid.has(`${v.x},${v.y},${v.z}`) ? 'block' : 'empty' }),
    entities: {},
});
eq(JSON.stringify(pw.botEye(mkWorld(new Set()))), JSON.stringify([0, 65.62, 0]), 'bot 眼高 = y+1.62');
eq(JSON.stringify(pw.dragonEye([0, 66.9, 0])), JSON.stringify([0, 73.7, 0]), '龙眼 = 实体 y + 6.8');
ok(pw.losClear(mkWorld(new Set()), [0, 65, 0], [0, 75, 0]).clear, '空旷处视线通');
ok(!pw.losClear(mkWorld(new Set(['0,70,0'])), [0, 65, 0], [0, 75, 0]).clear, '中间有实心方块 → 视线断');
ok(!pw.losClear(mkWorld(new Set(['0,66,0'])), [0, 65, 0], [0, 75, 0]).clear, '头顶正上方一格实心 → 视线断（对照实验的「盖屋顶」布景）');
ok(pw.losClear(mkWorld(new Set(['0,66,0'])), [0, 65, 0], [0, 65.5, 0]).clear, '近距离（<ignoreFirst）不算遮挡');

// ---- STRAFE 闸门：距离门 64 格 + 视线门 ----
const near = pw.strafeGate(mkWorld(new Set()), { found: true, pos: [10, 70, 0] });
ok(near.inRange64 === true, '龙在 30 格外 → 距离门开');
ok(near.los === true, '无遮挡 → 视线门开');
const far = pw.strafeGate(mkWorld(new Set()), { found: true, pos: [200, 70, 0] });
ok(far.inRange64 === false, '龙在 64 格外 → 距离门关（baq.c 偏移 210-225）');
eq(far.dist > 190, true, '闸门读数带距离值');
const roofed = pw.strafeGate(mkWorld(new Set(['5,71,0'])), { found: true, pos: [10, 70, 0] });
ok(roofed.inRange64 === true && roofed.los === false, '同距离但中途被一格实心挡住 → 只有视线门关（baq.c 的 canSee 门）', JSON.stringify(roofed));

// ---- 火球观测：只有"新 id"才算一次开火 ----
const fbBot = { entities: { 7: { id: 7, name: 'dragon_fireball', position: { x: 1, y: 2, z: 3 } } } };
const w1 = pw.createFireballWatch(fbBot);
w1.sample(); const fbA = w1.state.spawned;
w1.sample(); const fbB = w1.state.spawned;
eq(fbA, 1, '首次看到火球 → spawned=1');
eq(fbB, 1, '同一个火球再采一次不重复计数');
fbBot.entities[8] = { id: 8, name: 'dragon_fireball', position: { x: 4, y: 5, z: 6 } };
w1.sample();
eq(w1.state.spawned, 2, '新 id → spawned=2（= 退出追击阶段开了一次火）');
fbBot.entities[9] = { id: 9, name: 'end_crystal', position: {} };
eq((w1.sample(), w1.state.spawned), 2, '末影水晶不计入火球');

// ---- 相位时间线：STRAFE 段能不能被切出来 ----
const tl = pw.createPhaseTimeline();
const fake = (ph, y) => ({ found: true, phase: ph, phaseName: pw.PHASE_NAMES?.[ph] ?? ['HOLDING_PATTERN', 'STRAFE_PLAYER', 'LANDING_APPROACH', 'LANDING', 'TAKEOFF', 'SITTING_FLAMING', 'SITTING_SCANNING', 'SITTING_ATTACKING', 'CHARGING_PLAYER', 'DYING', 'HOVERING'][ph], pos: [0, y, 0], health: 200 });
for (const [ph, n] of [[0, 3], [1, 5], [0, 2], [2, 1], [3, 1], [5, 4], [4, 1], [0, 1]]) {
    for (let i = 0; i < n; i++) tl.push(fake(ph, ph >= 5 && ph <= 7 ? 67 : 90));
}
const eps = tl.strafeEpisodes();
eq(eps.length, 1, '时间线切出 1 段 STRAFE_PLAYER');
eq(eps[0].endPhase, 'HOLDING_PATTERN', 'STRAFE 段结束相位 = HOLDING_PATTERN（baq.c 两个出口都回持机）');
ok(Object.keys(tl.dwell()).includes('STRAFE_PLAYER') && Object.keys(tl.dwell()).includes('SITTING_FLAMING'),
    '相位驻留统计覆盖到 STRAFE_PLAYER 与 SITTING_FLAMING', JSON.stringify(Object.keys(tl.dwell())));

// ---- 地面机位：按实测断面枚举（假世界复刻 1.16.1 出口结构断面）----
// 断面（z=0，x=-4..4）：y=62 bedrock(-2..2)；y=63 bedrock(±3)+end_stone(±4)+air(±1,±2)+中心柱；
// y=64..66 中心柱 bedrock(0)；y=65 壁炬(±1)
const solidSet = new Set();
for (let x = -2; x <= 2; x++) for (let z = -2; z <= 2; z++) solidSet.add(`${x},62,${z}`);
for (const x of [-3, 3]) for (let z = -2; z <= 2; z++) solidSet.add(`${x},63,${z}`);
for (let y = 63; y <= 66; y++) solidSet.add(`0,${y},0`);
const rigBot = { entity: { position: { x: 3.5, y: 64, z: 0.5 }, onGround: true }, blockAt: mkWorld(solidSet).blockAt, entities: {} };
const rig3 = pw.groundRig(rigBot, { radius: 3, angleDeg: 0 });
ok(rig3.stand && rig3.stand.x === 3 && rig3.stand.y === 64, '半径 3 → 机位 (3,64,0)（bedrock 顶面 y=63 → 脚底 64）', JSON.stringify(rig3.stand));
ok(rig3.bedCandidates.length > 0, '机位旁有可放床的格', JSON.stringify(rig3.bedCandidates));
ok(rig3.bedCandidates.every((c) => c.reach <= 4.2), '所有床位都在伸手范围（≤4.2）内');
const rig2 = pw.groundRig(rigBot, { radius: 2, angleDeg: 0 });
ok(rig2.stand && rig2.stand.y === 63, '半径 2 → 机位脚底 63（坑底 bedrock 顶面 y=62）', JSON.stringify(rig2.stand));
const rigVoid = pw.groundRig(rigBot, { radius: 9, angleDeg: 0 });
ok(rigVoid.stand === null, '虚空方向没有落脚面 → stand=null（不静默给错机位）');

console.log(`\n[selftest] ${pass} pass, ${fail} fail`);
if (fail) { for (const f of failures) console.log(`  X ${f}`); process.exit(1); }
console.log('[selftest] OK — 协议解析层（血量/相位/判定器）离线自测通过');
