// summarize.mjs — MC-END-01 试局汇总（逐局表 + 验收口径判定 + report.md）
// 口径：全部 trial 都进表（手册 §5：失败局按预算值计入，不只算成功局）。

import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../../..');
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; };
const stamp = arg('run', null);
if (!stamp) { console.error('用法：node summarize.mjs --run <STAMP>'); process.exit(1); }
const DIR = path.join(HERE, 'runs', stamp);
if (!fs.existsSync(DIR)) { console.error(`没有这个 run：${DIR}`); process.exit(1); }

const rows = fs.readFileSync(path.join(DIR, 'summary.jsonl'), 'utf8').split('\n').filter(Boolean)
    .map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
const meta = JSON.parse(fs.readFileSync(path.join(DIR, 'run_meta.json'), 'utf8'));

const med = (a) => { const s = a.filter((x) => Number.isFinite(x)).sort((x, y) => x - y); return s.length ? (s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2) : null; };
const p90 = (a) => { const s = a.filter((x) => Number.isFinite(x)).sort((x, y) => x - y); return s.length ? s[Math.min(s.length - 1, Math.floor(s.length * 0.9))] : null; };
const fmt = (x, d = 1) => (x == null ? '—' : (typeof x === 'number' ? (+x).toFixed(d) : String(x)));

const L = [];
L.push(`# END-01 试局汇总 — ${stamp}`);
L.push('');
L.push(`- 模式：**${meta.mode}** · 难度 ${meta.difficulty} · 泳道 C(25568) · 1.16.1 vanilla`);
L.push(`- 任务层：\`${meta.mindcraftRoot}\``);
L.push(`- 参数：headOffsetY=${meta.headOffsetY} headRange=${meta.headRange} settle=${meta.settleMs}ms maxPerch=${meta.maxPerch} crystalJanitor=${meta.crystalJanitorMs}ms`);
L.push(`- kit（控制台 give）：\`${meta.kit}\``);
L.push(`- 机器墙钟：${meta.wallMs ? (meta.wallMs / 60000).toFixed(1) + 'min' : '—'}`);
L.push('');
L.push('## 逐局');
L.push('');
L.push('| # | 终态 | 难度 | 龙首见 | 走到中央岛 | 栖息数 | 漏判 | 判定延迟(med/max) | 引爆 | 总伤害 | 床耗 | 死亡 | 龙血终值 | bot最低血 | 水晶(最少/最多) | 墙钟 |');
L.push('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|');
for (const r of rows) {
    const m = r.metrics ?? {};
    const lat = (m.latencies ?? []).filter((x) => Number.isFinite(x));
    L.push(`| ${r.trial} | ${r.outcome} | ${r.difficulty} | ${m.wallMs ? fmt(m.wallMs / 1000) + 's' : '—'} | ${m.walkMs ? (m.walkOk ? 'OK ' : '未到位 ') + fmt(m.walkMs / 1000) + 's' : '—'} | ${m.perches ?? '—'} | ${m.misses ?? '—'} | ${fmt(med(lat), 0)}/${fmt(Math.max(...(lat.length ? lat : [NaN])), 0)} | ${m.bombs ?? '—'} | ${m.bombDamageTotal ?? '—'} | ${m.bedsUsed ?? '—'} | ${m.deaths ?? '—'} | ${m.dragonHealthEnd ?? '—'} | ${m.healthMin ?? '—'} | ${m.crystalMin ?? '—'}/${m.crystalMax ?? '—'} | ${m.wallMs ? fmt(m.wallMs / 1000) + 's' : '—'} |`);
}
L.push('');

// ---- 逐次引爆明细 ----
const bombRows = rows.flatMap((r) => (r.metrics?.bombRecords ?? []).map((b) => ({ trial: r.trial, ...b })));
if (bombRows.length) {
    L.push('## 逐次引爆');
    L.push('');
    L.push('| 局 | t(s) | 第几次栖息 | 引爆时相位 | 床头距 | 龙血 前→后 | 伤害 | bot 血 | 床消失 |');
    L.push('|---|---|---|---|---|---|---|---|---|');
    for (const b of bombRows) {
        L.push(`| ${b.trial} | ${fmt(b.t / 1000)} | ${b.perch} | ${b.phase ?? '—'} | ${b.headDist ?? '—'} | ${b.healthBefore ?? '—'}→${b.healthAfter ?? '—'} | ${b.damage ?? '—'} | ${b.botHealth ?? '—'} | ${b.gone ? 'yes' : 'no'} |`);
    }
    L.push('');
}

// ---- 逐次栖息段落 ----
const perches = rows.flatMap((r) => (r.metrics?.perchDetail ?? []).map((p) => ({ trial: r.trial, ...p })));
if (perches.length) {
    L.push('## 逐次栖息段落（判定延迟 = 收到相位元数据包 → 主循环做出动作）');
    L.push('');
    L.push('| 局 | 起始相位 | 时长(ms) | 判定延迟(ms) | 本段引爆 | 本段伤害 |');
    L.push('|---|---|---|---|---|---|');
    for (const p of perches) L.push(`| ${p.trial} | ${p.startPhase ?? '—'} | ${p.durMs ?? '—'} | ${p.latencyMs ?? '—'} | ${p.bombs ?? 0} | ${p.damage ?? 0} |`);
    L.push('');
}

// ---- 相位直方图（证明 ordinal 表在真服上真的对得上）----
L.push('## 相位分布（跨局合并；验证「读到的是 EnderDragonPhase.ordinal」）');
L.push('');
const hist = {};
for (const r of rows) for (const [k, v] of Object.entries(r.metrics?.phaseHistogram ?? {})) hist[k] = (hist[k] ?? 0) + v;
L.push('| 相位名 | 采样次数 |');
L.push('|---|---|');
for (const [k, v] of Object.entries(hist).sort((a, b) => b[1] - a[1])) L.push(`| ${k} | ${v} |`);
L.push('');

// ---- 门柱几何（stage-06 §1 S3 的站位假设是否成立）----
const geoms = rows.map((r) => r.metrics?.geom).filter(Boolean);
if (geoms.length) {
    const g = geoms[0];
    L.push('## 出口门柱几何（实测，非假设）');
    L.push('');
    L.push('```json');
    L.push(JSON.stringify(g, null, 2));
    L.push('```');
    L.push('');
}

// ---- 验收口径 ----
const allLat = rows.flatMap((r) => (r.metrics?.latencies ?? []).filter((x) => Number.isFinite(x)));
const totalPerch = rows.reduce((a, r) => a + (r.metrics?.perches ?? 0), 0);
const totalMiss = rows.reduce((a, r) => a + (r.metrics?.misses ?? 0), 0);
const totalBombs = rows.reduce((a, r) => a + (r.metrics?.bombs ?? 0), 0);
const totalDamage = rows.reduce((a, r) => a + (r.metrics?.bombDamageTotal ?? 0), 0);
const totalDeaths = rows.reduce((a, r) => a + (r.metrics?.deaths ?? 0), 0);
const kills = rows.filter((r) => r.outcome === 'KILL').length;

L.push('## 验收对照（任务单 §4）');
L.push('');
L.push('| 项 | 要求 | 实测 | 判定 |');
L.push('|---|---|---|---|');
L.push(`| 栖息判定延迟 | ≤1s | med ${fmt(med(allLat), 0)}ms / max ${fmt(allLat.length ? Math.max(...allLat) : null, 0)}ms / n=${allLat.length} | ${allLat.length && (med(allLat) <= 1000) && Math.max(...allLat) <= 1000 ? '✅' : '❌'} |`);
L.push(`| 漏判 | 10 次栖息内 ≤1 | ${totalPerch} 次栖息、漏判 ${totalMiss} | ${totalPerch >= 10 && totalMiss <= 1 ? '✅' : '❌'} |`);
L.push(`| 一轮床爆 | 单次栖息窗口内引爆 ≥2 张床、打掉可观血量、bot 不死 | 共引爆 ${totalBombs}、总伤害 ${totalDamage}、死亡 ${totalDeaths} | ${totalBombs > 0 && totalDeaths === 0 ? '✅' : '❌'} |`);
L.push(`| 整条龙（peaceful, kit） | 5 次中 ≥3 次击杀 | ${kills}/${rows.length} 击杀 | ${kills >= 3 ? '✅' : '❌'} |`);
L.push('');

fs.writeFileSync(path.join(DIR, 'report.md'), L.join('\n'), 'utf8');
console.log(L.join('\n'));
