// review_checklist_v2.mjs — MC-ROUND4 §C-1 交付：**主种子 route 冻结审阅清单 v2**
//
// 【与 v1（review_checklist.mjs）的区别】v1 只读 `route/<seed>.json` + `<seed>.probe.json`，
//   覆盖的是 10-01 ROUTE-02 那一轮的八站。v2 把 **ROUND4 C 线新测的下界三站**并进同一张表，
//   并按派单 C-4 的口径逐站给：kind / station 区域 / scout 核验状态 / 证据路径。
//
// 【不写 frozenAt（本工具的硬约束）】
//   派单 C-4 原文：「**不写 frozenAt**；冻结等 B 线 S1 主种子 5/5 后由设计会话做」。
//   本文件**只读** route / probe / round4c 三处，**不写任何 route 文件**，也不生成 sha256。
//   这与 v1 的自我约束一致，但 v2 多一条：**v2 里的下界三站是"待并入 route 的草稿数据"**，
//   明确标 `routePending`，提醒设计会话冻结前要把它们 emit 进 <seed>.json。
//
// 用法：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\review_checklist_v2.mjs [--seed 4926685115947721762]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { argOf } from '../../stages/_lib/runner_core.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROUTE_DIR = path.join(HERE, '..');
const REPO = path.join(ROUTE_DIR, '..', '..');
const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const SEED = argOf(process.argv, 'seed', '4926685115947721762');

const readJson = (p, dflt = null) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return dflt; } };

const routePath = path.join(ROUTE_DIR, `${SEED}.json`);
const route = readJson(routePath);
if (!route) throw new Error(`找不到 route 草稿：${routePath}`);
const probe = readJson(path.join(PROBE_DIR, `${SEED}.probe.json`), {});
const offline = readJson(path.join(PROBE_DIR, 'nether_side_offline.json'), {});
const r4 = {
    nether_portal: readJson(path.join(PROBE_DIR, 'nether_portal.round4c.json'), null),
    bastion: readJson(path.join(PROBE_DIR, 'bastion.round4c.json'), null),
    fortress: readJson(path.join(PROBE_DIR, 'fortress.round4c.json'), null),
};

const out = [];
const P = (s = '') => out.push(s);
const ev = (rel) => `\`${rel.replace(/\\/g, '/')}\``;

P(`# route 冻结审阅清单 v2 —— ${SEED}`);
P();
P('> 由 `bench/route/tools/review_checklist_v2.mjs` 生成（**只读 route / probe / round4c，绝不写 route 文件**）。');
P('> v1 见 `bench/route/review/<seed>.review.md`（只覆盖 ROUTE-02 那一轮八站）；v2 = v1 + **ROUND4 C 线新测的下界三站**。');
P('> 派单 C-4 原文：「**不写 `frozenAt`**；冻结等 B 线 S1 主种子 5/5 后由设计会话做。」');
P();
P('| 项 | 值 |');
P('|---|---|');
P(`| 种子 | \`${route.seed}\`（10-02 设计会话定为主种子，手册 §7） |`);
P(`| 版本 | ${route.mcVersion} |`);
P(`| \`frozenAt\` | \`${JSON.stringify(route.frozenAt)}\` —— **草稿；本工具不写，冻结由设计会话做** |`);
P(`| \`sha256File\` | \`${JSON.stringify(route.sha256File)}\` —— 冻结时才生成 |`);
P(`| v1 站数 / REAL | ${route.stations.length} / ${route.stations.filter((s) => s.scout?.verify?.status === 'REAL').length} |`);
const r4ok = Object.values(r4).filter(Boolean).length;
P(`| v2 新增下界站 | ${r4ok}/3 已产出 round4c 取证（nether_portal / bastion / fortress） |`);
P(`| 要塞对应点（nether ÷8） | \`(${offline.netherAnchor?.x},${offline.netherAnchor?.z})\`（主世界要塞 ${route.stations.find((s) => s.id === 'S5_stronghold_room')?.station?.center ?? '?'}） |`);
P();

// ---------------------------------------------------------------- 一、v1 八站
P('## 一、既有八站（ROUTE-02 已核，v1 清单同口径）');
P();
P('| 站 | kind | dim | station 中心 | radius | scout 状态 | 证据路径 |');
P('|---|---|---|---|---|---|---|');
for (const st of route.stations) {
    const v = st.scout?.verify ?? {};
    P(`| \`${st.id}\` | \`${st.kind}\` | \`${st.dim}\` | \`[${st.station.center}]\` | ${st.station.radius} | ${v.status}`
        + `${st.scout?.flags ? ` ⚠${st.scout.flags.join(',')}` : ''} | ${ev(`bench/route/probe/${SEED}.probe.json#categories`)} |`);
}
P();
const risks = [];
for (const st of route.stations) {
    const v = st.scout?.verify ?? {};
    if (v.status !== 'REAL') risks.push(`\`${st.id}\` 是 ${v.status}（${v.reason ?? '无 reason'}）—— 冻结前需裁决`);
    if (st.station.center[0] === 0 && st.station.center[1] === 0) risks.push(`\`${st.id}\` 的 center 是占位 [0,0]（对 bot 无指向性）`);
    if (st.scout?.flags?.includes('insufficient_spawners')) risks.push(`\`${st.id}\` 带 insufficient_spawners 标记（刷怪笼 < 2，编排器应按"尽力而为"处理，勿重试到超时）`);
}
if (risks.length) { P('### 既有站的冻结前风险'); P(); risks.forEach((r) => P(`- ${r}`)); P(); }

// ---------------------------------------------------------------- 二、下界三站
P('## 二、下界一侧三站（**ROUND4 C 线新测**，派单 §C）');
P();
P('> 全部走服务器权威通道（每盒地形对照 + fill 回执严格 FIFO 配对 + 每站一个 fresh world），');
P('> 离线 cubiomes 只用于**给出起点**，框体/刷怪笼/站位一律服务端真值。');
P('> 口径提醒（手册 §5）：**区域总数 ≠ 框内计数** —— 门框用与生产 `frameCells` 相同的几何逐格判定。');
P();

/** 一站一段，字段完全按派单 C-4：kind / station 区域 / scout 核验状态 / 证据路径 */
function stageBlock(key, id, title) {
    const d = r4[key];
    P(`### \`${id}\` —— ${title}`);
    P();
    if (!d) { P('- **scout 核验**：本轮**未产出**取证（该站未跑或被预算/让路截断）→ 冻结前必须补测'); P(); return; }
    P(`- **kind**：\`${d.stage}\` · dim \`the_nether\` · 泳道 \`${d.lane}\` · seed \`${d.seed}\``);
    P(`- **离线起点**：\`(${d.offlineStart?.x},${d.offlineStart?.z})\` 距要塞对应点 \`${d.offlineStart?.distanceFromAnchor}\` 格 · 扫描 r=\`${d.r}\` · y带 \`${JSON.stringify(d.ySlices)}\``);
    P(`- **scout 核验状态**：\`${d.status}\` · method \`fill-replace + 八叉下钻（服务器权威）\` · 用时 \`${d.seconds}s\``);
    P(`- **地形对照**：${JSON.stringify(d.scan?.terrain ?? {})}（合计 ${d.terrainTotal ?? 0}；全零即工具不可信，本单不会产出该状态）`);
    P(`- **真值计数**：${JSON.stringify(d.scan?.counts ?? {})}`);
    P(`- **自检**：${JSON.stringify(d.scan?.selfCheck ?? {})} · 回执错位 \`${d.scan?.desync ?? 0}\` · fills \`${d.scan?.fills ?? 0}\``);
    if (d.error) P(`- **⚠ 错误**：\`${d.error.split('\n')[0]}\``);
    P(`- **证据路径**：${ev(`bench/route/probe/${key}.round4c.json`)}；服务器日志 ${ev(`bench/route/probe/_run_round4c/${key}/server.log`)}`);
    P(`- **route 状态**：\`routePending\` —— **尚未 emit 进** \`${SEED}.json\`（冻结前必须并入，否则编排器看不到这一站）`);
    P();
    return d;
}

const np = stageBlock('nether_portal', 'C1_nether_portal', '派单 C-1：要塞对应点旁 15 格的下界废弃传送门');
if (np) {
    P('#### C-1 结论：补门要多少黑曜石');
    P();
    if (np.status === 'OK' && np.frame) {
        const f = np.frame, s = np.summary;
        P(`- **框体几何**：origin \`(${f.origin.x},${f.origin.y},${f.origin.z})\` axis \`${f.axis}\`（与生产 \`nether.js\` 的 \`frameCells\` 同一套移植，${f.required} 个必需格 + 顶行两角可省）`);
        P(`- **框内黑曜石**：**${f.obsidian}/${f.required}**（可选角另有 ${f.optionalObsidian} 块）`);
        P(`- **缺格**：空缺 **${f.missing.length}** 格 · 错块 **${f.wrong.length}** 格 · 内部脏 **${f.dirty.length}** 格`);
        P(`- **缺格被什么占**：${(s.missingGot ?? []).map((x) => `\`${x}\``).join('、') || '（无）'}`);
        P(`- **错块是什么**：${(s.wrongGot ?? []).map((x) => `\`${x}\``).join('、') || '（无）'}`);
        P(`- **需新放黑曜石**：**${f.obsidianToPlace}** 块（= 空缺 ${f.missing.length} + 错块 ${f.wrong.length}；错块要先挖掉，不算"补 0 格"）`);
        P(`- **门是否已可用**：${f.usable ? '✅ 是' : '❌ 否'}`);
        P(`- **逐格真值**：\`cellTruth\`（${f.cellTruth?.length ?? 0} 格，fills ${f.classify?.fills}，复原失败 ${f.classify?.restoreFails}）`);
        P();
        P('> ⚠ **下界不能用水浇黑曜石**（水在下界蒸发）。所以"需补 N 块黑曜石"在下界是**纯物资成本**：');
        P('> N 块黑曜石必须来自**易物**或**箱子**，不能像主世界那样现浇。这条直接决定 S5 的物资预算。');
        P();
    } else {
        P(`- **结论**：本轮状态 \`${np.status}\` —— ${np.note ?? '（无 note）'}`);
        P('- **纪律**：按手册 §5「没找到目标必须判失败」，该状态**不等于**"不需要补门"。');
        P();
    }
    if (np.nearbyChests?.length) {
        P(`- **附近的箱子**（2D 距离按门原点算）：${np.nearbyChests.slice(0, 5).map((c) => `(${c.x},${c.y},${c.z}) ${c.dist2d != null ? `**${c.dist2d} 格**` : '距离未知'}`).join('、')}`);
        P();
    }
}

const ba = stageBlock('bastion', 'C2_bastion', '派单 C-2：堡垒类型 / 金块 / 宝箱（交给 F 线 B5）');
if (ba) {
    P('#### C-2 结论：堡垒类型与金块/宝箱');
    P();
    const t = ba.bastionType;
    if (t) {
        P(`- **类型判别**：treasure = ${t.criteria?.treasure ? '**有金块 → 是**' : '无金块 → 否'}；hoglin stables = ${t.criteria?.stables ? '**菌光体密集 → 是**' : `否（菌光体 ${(t.crimsonFungus ?? 0) + (t.warpedFungus ?? 0)}）`}`);
        P(`- **结构件计数**：金块 \`${t.goldBlock}\` · 鎏金黑石 \`${t.gildedBlackstone}\` · 箱 \`${t.chest}\` · 陷阱箱 \`${t.trappedChest}\` · 黑曜石 \`${t.obsidian}\` · 哭泣黑曜石 \`${t.cryingObsidian}\``);
        P(`- **区域中心**：${ba.region ? `\`[${ba.region.center}]\`（命中盒 ${JSON.stringify(ba.region.box)}）` : '（无命中盒）'}`);
        P(`- **判别方法与局限**：${t.note ?? ''}`);
    }
    P(`- **金块精确坐标**（F 线 B5 直接用）：${ba.goldBlockPoints?.length ? ba.goldBlockPoints.map((p) => `(${p.x},${p.y},${p.z})`).join('、') : `粗扫 ${ba.bastionType?.goldBlock ?? 0} 块，但未下钻到格级`}`);
    P(`- **宝箱精确坐标**：${ba.chestPoints?.length ? ba.chestPoints.map((p) => `(${p.x},${p.y},${p.z})`).join('、') : `粗扫 ${ba.bastionType?.chest ?? 0} 个，未下钻到格级`}`);
    P();
    P('> 给 F 线 B5 的口径：B5 要"用 route 的 scout 信息定位后，服务器真值数一次"。');
    P('> 上面的坐标属于**精确坐标**，按手册 §7 **只能留在 scout 区 / 测试脚本 / 报告里**，');
    P('> **不得进入 prompt、模型记忆或 MISSION**；任务层只能通过 `route_loader` 读站级数据。');
    P();
}

const fo = stageBlock('fortress', 'C3_fortress_spawner', '派单 C-3：下界要塞刷怪笼（数量 / 区域 / 站位条件）');
if (fo) {
    P('#### C-3 结论：刷怪笼数量与站位条件');
    P();
    P(`- **刷怪笼**：**${fo.spawnerCount} 个**（派单要求 ≥2 → ${fo.meetsMin ? '✅ 达标' : '❌ 不足'}）`);
    P(`- **锚点（证明扫的是要塞而非空地）**：nether_bricks \`${fo.anchorBricks?.netherBricks}\` · blackstone \`${fo.anchorBricks?.blackstone}\``);
    P(`- **各笼所在区域**：${(fo.spawners ?? []).map((s, i) => `#${i + 1} (\`${s.x},${s.y},${s.z}\`)`).join('、') || '（无）'}`);
    P();
    if (fo.standing?.length) {
        P('- **站位条件（能否挡烈焰人火球）**：');
        fo.standing.forEach((s, i) => {
            P(`  - 笼 #${i + 1} \`(${s.spawner.x},${s.spawner.y},${s.spawner.z})\`：**${s.coverStands} 个**可挡火球的站位`
                + `（判据：脚下实心 + 身体两格空气 + 四侧≥两面实心/墙）· 探测格 ${s.probedCells} · 未知 ${s.unknown} · 复原失败 ${s.restoreFails}`);
        });
        P();
    } else if (fo.spawnerCount) {
        P('- **站位条件**：本轮未产出（预算截断）→ 冻结前补测');
        P();
    }
}

// ---------------------------------------------------------------- 三、结论与冻结前待办
P('## 三、v2 相对 v1 的变化（设计会话审阅重点）');
P();
const chg = [];
if (np?.status === 'OK' && np.frame) {
    chg.push(`- **新增 C1 站**：主世界对应点旁 ${offline.items?.netherRuinedPortal?.nearestAny?.distanceFromAnchor ?? '?'} 格的下界废弃门，框内黑曜石 **${np.frame.obsidian}/${np.frame.required}**，需补 **${np.frame.obsidianToPlace}** 块。`
        + '这与 S1（主世界门，需补 ' + (route.stations.find((s) => s.id === 'S1_portal')?.scout?.verify?.counts?.obsidian ?? '?') + ' 格 obsidian 区域）是**两个独立的门**，路线需要二选一或都留。');
}
if (ba?.bastionType) {
    chg.push(`- **新增 C2 站**：堡垒真值计数（金块 ${ba.bastionType.goldBlock} / 鎏金黑石 ${ba.bastionType.gildedBlackstone} / 箱 ${ba.bastionType.chest}），`
        + `区域中心 \`${ba.region ? JSON.stringify(ba.region.center) : '无'}\`。**与既有 S3_bastion 是不同区域**（既有中心 [288,240]，距要塞对应点 153 格）→ 冻结前需裁决 route 里保留哪个堡垒站。`);
}
if (fo) {
    chg.push(`- **新增 C3 站**：距要塞对应点最近的下界要塞刷怪笼 **${fo.spawnerCount} 个**（既有 S4 站只有 1 个，且在 607 格外）。`
        + (fo.spawnerCount >= 2 ? '这一站可**替代**既有 S4。' : '仍不达标，需裁决。'));
}
if (chg.length) chg.forEach((c) => P(c)); else P('- （本轮无新结论）');
P();
P('## 四、冻结前待办（设计会话）');
P();
P('1. 把 C1/C2/C3 三站 **emit 进** `' + SEED + '.json`（当前标 `routePending`，编排器看不到）；');
P('2. 裁决「下界门 vs 主世界门」与「新堡垒站 vs 既有 S3」「新要塞站 vs 既有 S4」是否替换；');
P('3. 逐条裁决第一节的既有站风险（UNVERIFIED / 占位中心 / insufficient_spawners）；');
P('4. 以上落定后**再**写 `frozenAt` + 生成 `<seed>.sha256`（SCHEMA §2/§3）。');
P();
P('> 派单 C-4 明确：**冻结等 B 线 S1 主种子 5/5 后由设计会话做**，本单不写 `frozenAt`。');
P();

const outPath = path.join(ROUTE_DIR, 'review', `${SEED}.review.v2.md`);
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, out.join('\n'));
console.log(`✓ ${path.relative(REPO, outPath)}`);
console.log(`  v2 新增下界站取证：${r4ok}/3`);
console.log(`  route 文件未改动（frozenAt 仍为 ${JSON.stringify(route.frozenAt)}）`);
