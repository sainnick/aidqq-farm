﻿// smelt_task.js — MC-M1-TASK-06 Task: Smelt（熔炼任务）
//
// 职责：给定输出物品（iron_ingot）与目标数量，把背包里的输入（iron_ore）在熔炉里熔成
// 成品并验证入包。输入/燃料/熔炉物品的获取由上层 CraftingTask 的计划步骤自理——
// 本任务只负责「放置→使用→回收」的熔炉生命周期本体。
//
// 生命周期镜像 CraftingTask 的工作台语义（找现成的→导航→没有则放自己的→方块级验证→
// 用完挖回），文件独立实现——禁区约束「不改合成层」，本任务只新增不修改。
// 使用通道 = mineflayer 原生 bot.openFurnace（putInput/putFuel/takeOutput，协议级 1.16 支持）。
// 思想来源：AltoClef（MIT）SmeltInFurnaceTask 的「查燃料→投料→等产物→取出→增量验证」
// 流程思想（thought-level reference，非逐行复制）。
//
// 燃料（任务单口径）：煤 > 木板 > 原木，用量按原版燃烧值（煤 8 项/个、木板 1.5 项/个、
// 原木 1.5 项/个），只投需要的量。执行期从真实库存按优先级自选——计划期保底预留的木板
// 用不完就剩在包里（无害）。
//
// 验证口径（同 craft）：takeOutput 后按背包增量验证；「熔炉界面显示有产物」≠ 入包成功。

import { ExecTask, FailReason, sleep, countItems, posKey } from './task.js';
import { SMELT_RECIPES } from './recipe_resolver.js';
import { logFamilyFor } from './resources.js';
import { navTo, stopNav } from './nav.js';
import { placeItem } from './place.js';
import { takeFromSlotConfirmed, takeFurnaceOutputConfirmed, closeWindowConfirmed, countItemsWindowAware, quickMoveIntoFurnace, quickMoveOutOfFurnace, playerInvRange, windowSlotCount, slotCountSource } from './window_ops.js';
import pf from 'mineflayer-pathfinder';
import { Vec3 } from 'vec3';

const LIQUIDS = new Set(['lava', 'water']);
const REPLACEABLE = new Set(['air', 'cave_air', 'void_air', 'water', 'grass', 'tall_grass', 'fern', 'snow', 'dead_bush']);
const POLL_MS = 400;

function withTimeout(p, ms, tag) {
    return Promise.race([p, sleep(ms).then(() => { throw new Error(tag ?? 'timeout'); })]);
}

// 燃料优先级与燃烧值（每单位燃料可熔炼的物品数，1.16.1 原版真值）
const FURNACE_ITEM = 'furnace';

export class SmeltTask extends ExecTask {
    constructor(opts = {}) {
        super('SmeltTask', { timeoutMs: opts.timeoutMs ?? 240000 });
        this.item = opts.item;                    // 输出物品名，如 'iron_ingot'
        this.target = opts.target ?? 1;           // 背包内应达到的总量（与 craft step 同语义）
        this.smeltDef = opts.smeltDef ?? null;    // SMELT_RECIPES 条目（缺省自查表）
        this.reclaimFurnace = opts.reclaimFurnace ?? true;
        this.stationSearchRadius = opts.stationSearchRadius ?? 24;
        this._sub = '';
        this.phase = 'idle';
        this._furnace = null;       // 当前打开的熔炉窗口（签名用，会话结束置空）
        this._placedFurnacePos = null;
        this._ignoredFurnaces = new Set();
        this._reclaimDone = false;
        this.smelted = 0;
    }

    countMet(ctx) { return countItems(ctx.bot, [this.item]) >= this.target; }

    progressSignature(ctx) {
        // 熔炼等待期必须让签名持续推进（furnace 进度秒数），否则 ProgressChecker 25s 就判
        // soft stuck——smoke5 实证：onStuck 关窗把合法熔炼会话弄瞎，232s 冻结到 NO_PROGRESS
        let prog = '';
        try {
            if (this._furnace) {
                prog = `|p${Math.round((this._furnace.progressSeconds ?? 0) * 2)}|f${Math.round(this._furnace.fuelSeconds ?? 0)}|o${this._furnace.outputItem()?.count ?? 0}`;
            }
        } catch { /* 窗口已关时忽略 */ }
        return `${this.phase}|${this._sub}|i${countItems(ctx.bot, [this.item])}|t${this.target}${prog}`;
    }

    getProgress(ctx) {
        return { phase: this.phase, have: countItems(ctx.bot, [this.item]), target: this.target, smelted: this.smelted };
    }

    async onStuck(kind, ctx) {
        if (kind !== 'soft') return;
        // 只停导航，【不关熔炉窗口】——关窗会把在烧的会话弄瞎（smoke5 实证）；
        // 真死会话由 _smeltSession 自己的 deadline 收口
        stopNav(ctx.bot);
    }

    async cleanup(ctx) {
        stopNav(ctx.bot);
        try {
            if (ctx.bot.currentWindow && String(ctx.bot.currentWindow.type).includes('furnace')) {
                ctx.bot.closeWindow(ctx.bot.currentWindow);
            }
        } catch { /* 忽略 */ }
    }

    async tick(ctx) {
        const bot = ctx.bot;
        if (this.countMet(ctx)) { this.phase = 'reclaim'; }
        switch (this.phase) {
            case 'idle': {
                ctx.telemetry('smelt_start', { item: this.item, target: this.target });
                this.smeltDef ??= SMELT_RECIPES[this.item];
                if (!this.smeltDef) { this._fail(FailReason.INTERNAL, { error: `no smelt recipe for ${this.item}` }); return; }
                this.phase = 'verify';
                return;
            }
            case 'verify': {
                // 输入够不够（缺了让上层 replan——计划器会补 acquire 步骤）
                const opsNeeded = this.target - countItems(bot, [this.item]);
                const haveInput = countItems(bot, [this.smeltDef.input]);
                if (opsNeeded > 0 && haveInput < opsNeeded) {
                    ctx.telemetry('smelt_missing_input', { item: this.item, haveInput, opsNeeded });
                    this._fail(FailReason.DEPENDENCY_FAILED, { missing: this.smeltDef.input, haveInput, opsNeeded });
                    return;
                }
                // 燃料有没有（煤>木板>原木）
                if (!this._pickFuel(ctx, opsNeeded)) {
                    // r4：补 `at:'plan'`。旧代码同一个 event 名有两套不兼容的 schema
                    // （这里是 {item, inv}，炉边那处是 {at:'furnace'}）⇒ 按字段分不清
                    // "开工时没燃料"还是"炉边没燃料"。两个都带 `at` 才好统计。
                    ctx.telemetry('smelt_missing_fuel', { at: 'plan', item: this.item, inv: inventoryDump(bot) });
                    this._fail(FailReason.FUEL_MISSING, { item: this.item, opsNeeded });
                    return;
                }
                this.phase = 'station';
                return;
            }
            case 'station': {
                const furnace = await this._ensureFurnace(ctx);
                if (!furnace) { this._fail(FailReason.FURNACE_UNAVAILABLE, { item: this.item }); return; }
                this._sub = 'smelting';
                const ok = await this._runFurnace(ctx, furnace);
                this._sub = '';
                if (ok) { this.phase = 'reclaim'; return; }
                // 熔炼未达标：结构性失败交上层 replan（重开炉/换炉/补料）
                this._fail(FailReason.SMELT_FAILED, { item: this.item, have: countItems(bot, [this.item]), target: this.target });
                return;
            }
            case 'reclaim': return this._tickReclaim(ctx);
            default:
                this._fail(FailReason.INTERNAL, { error: `unknown phase ${this.phase}` });
        }
    }

    // ---------- 燃料 ----------
    // 返回 {itemType, count, per} 或 null。优先级：煤（8 项/个）> 任意木板（1.5）> 任意原木（1.5）。
    _pickFuel(ctx, opsNeeded) {
        const bot = ctx.bot;
        const invOf = (names) => bot.inventory.items().filter((i) => names.includes(i.name));
        const need = (per) => Math.max(1, Math.ceil(opsNeeded / per));
        const coal = invOf(['coal']);
        if (coal.length) {
            const count = Math.min(coal.reduce((s, i) => s + i.count, 0), need(8));
            return { name: 'coal', itemType: coal[0].type, count, per: 8 };
        }
        const planks = invOf(bot.registry.itemsByName['oak_planks']
            ? Object.keys(bot.registry.itemsByName).filter((n) => n.endsWith('_planks'))
            : ['oak_planks']);
        if (planks.length) {
            const count = Math.min(planks.reduce((s, i) => s + i.count, 0), need(1.5));
            return { name: planks[0].name, itemType: planks[0].type, count, per: 1.5 };
        }
        const logs = invOf(logFamilyFor(bot.registry));
        if (logs.length) {
            const count = Math.min(logs.reduce((s, i) => s + i.count, 0), need(1.5));
            return { name: logs[0].name, itemType: logs[0].type, count, per: 1.5 };
        }
        return null;
    }

    // ---------- 熔炉生命周期 ----------
    _findFurnace(ctx, radius) {
        const bot = ctx.bot;
        const id = bot.registry.blocksByName[FURNACE_ITEM]?.id;
        if (id == null) return null;
        const found = bot.findBlocks({ matching: [id], maxDistance: radius, count: 8 })
            .filter((p) => !this._ignoredFurnaces.has(posKey(p)))
            .sort((a, b) => bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b));
        return found.length ? bot.blockAt(found[0]) : null;
    }

    /** 返回可达的熔炉 Block；拿不到则自己放一个；都失败返回 null（不抛） */
    async _ensureFurnace(ctx) {
        const bot = ctx.bot;
        let f = this._findFurnace(ctx, 4.0);
        if (!f) {
            f = this._findFurnace(ctx, this.stationSearchRadius);
            if (f) {
                ctx.telemetry('furnace_nav', { pos: [f.position.x, f.position.y, f.position.z] });
                const ok = await navTo(ctx, new pf.goals.GoalNear(f.position.x, f.position.y, f.position.z, 2),
                    { timeoutMs: 25000, label: 'to_furnace' });
                const near = this._findFurnace(ctx, 4.0);
                if (!ok || !near) {
                    this._ignoredFurnaces.add(posKey(f.position));
                    return this._placeOwnFurnace(ctx);
                }
                return near;
            }
            return this._placeOwnFurnace(ctx);
        }
        return f;
    }

    async _ensureFurnaceInHand(ctx) {
        const bot = ctx.bot;
        for (let i = 0; i < 2; i++) {
            if (bot.heldItem?.name === FURNACE_ITEM) return true;
            const item = bot.inventory.items().find((it) => it.name === FURNACE_ITEM);
            if (!item) return false;
            try { await withTimeout(bot.equip(item, 'hand'), 5000, 'equip_timeout'); } catch { /* 重试一次 */ }
            await sleep(300);
        }
        return bot.heldItem?.name === FURNACE_ITEM;
    }

    // MC-M1-TASK-06c：换成共享放置原语 place.js（旧的三轮扫描 + 8s 等 blockUpdate 已删）。
    // 铁链的 place_fail 主要就出在这里：垂直下挖完站在井底时，扫描挑中的目标格是井壁实心格
    // 或被井壁挡住的参照面，服务端静默拒收 → 每次空等 5s → furnace_place_exhausted。
    // 失败语义不变：交还上层 replan，不判死任务。
    async _placeOwnFurnace(ctx) {
        const bot = ctx.bot;
        const r = await placeItem(bot, FURNACE_ITEM, {
            telemetry: ctx.telemetry, ctx, GoalNear: pf.goals.GoalNear, label: 'furnace',
            maxTries: 10, rounds: 3, confirmMs: 1000,
        });
        if (r.ok) {
            this._placedFurnacePos = new Vec3(r.dest.x, r.dest.y, r.dest.z);
            ctx.run.counters.furnacePlacements++;
            return r.block;
        }
        if (r.reason === 'hold_fail') {
            ctx.telemetry('furnace_hold_fail', { item: this.item, invFurnace: countItems(bot, [FURNACE_ITEM]) });
            return null;
        }
        ctx.run.counters.furnacePlacementFailures++;
        return null;
    }

    // ---------- 使用熔炉 ----------
    async _runFurnace(ctx, furnaceBlock) {
        const bot = ctx.bot;
        const opsNeeded = () => this.target - countItems(bot, [this.item]);
        for (let attempt = 1; attempt <= 3 && opsNeeded() > 0; attempt++) {
            const ok = await this._smeltSession(ctx, furnaceBlock, opsNeeded());
            if (ok) return true;
            await sleep(600); // 重开炉前歇一拍（窗口/协议抖动恢复）
        }
        return opsNeeded() <= 0;
    }

    /**
     * MC-M1-TASK-09-r4：熔炉装料 / 加燃料的**唯一**入口（shift 点击）。
     *
     * 本方法存在的理由是**让失败响亮**：r3 定位到旧的两处是裸 `await`（`putInput`/`putFuel`），
     * 异常冒泡成 INTERNAL 之后**异常文本一个字节都不落盘**（`bot.log` / `server.log` /
     * stdout / stderr / `result.json` 全无堆栈），现场只剩一条 `place_ok` 之后 0.5s 的空白，
     * 连"是 :266 还是 :270 抛的"都分不出来（r3 如实标 INCONCLUSIVE）。
     * 现在：① try/catch 兜住一切；② 每个失败都发一条带**结构化 reason** 的遥测；
     * ③ 顺带把窗口布局真值（服务端槽数 / 区间 / 区间来源）落盘 ——
     * 这三个字段是本单"区间不再靠猜"的自证材料，也是把 r3 那条 INCONCLUSIVE 钉死的判别手。
     *
     * 返回 {ok, reason, ...}：`already_loaded` 视为成功（目标格已经有同种且够量）。
     */
    async _loadIntoFurnace(ctx, furnace, { itemName, target, wantCount = 0 }) {
        const bot = ctx.bot;
        const win = furnace.window ?? furnace;
        const destSlot = target === 'fuel' ? 1 : 0;
        try {
            const destBefore = win?.slots?.[destSlot] ?? null;
            if (destBefore && destBefore.name === itemName && (wantCount <= 0 || destBefore.count >= wantCount)) {
                return { ok: true, reason: 'already_loaded', moved: 0, dest: destSlot };
            }
            const r = await withTimeout(
                quickMoveIntoFurnace(bot, furnace, { itemName, target, wantCount, timeoutMs: 2500 }),
                8000, 'quick_move_furnace_timeout',
            );
            ctx.telemetry(r.ok ? 'smelt_load_ok' : 'smelt_load_fail', {
                what: target, item: itemName, ok: !!r.ok, reason: r.reason ?? null,
                moved: r.moved ?? 0, src: r.src ?? null, dest: r.dest ?? null,
                got: r.got ?? null, want: r.want ?? null, hotbarSlot: r.hotbarSlot ?? null,
                otherSlot: r.otherSlot ?? null, via: r.via ?? null,
                // 窗口布局自证三字段
                slotCount: windowSlotCount(bot, win), slotCountVia: slotCountSource(bot, win),
                playerRange: (() => { const g = playerInvRange(bot, win); return g ? `${g.start}-${g.end}#${g.via}` : null; })(),
                winType: win?.type ?? null, winId: win?.id ?? null,
                libInvRange: win ? `${win.inventoryStart}-${win.inventoryEnd}` : null,
                verdict: r.verdict ? JSON.stringify(r.verdict).slice(0, 160) : null,
            });
            return r;
        } catch (e) {
            // 这一条就是 r3 缺的那条：异常文本以前彻底丢失
            ctx.telemetry('smelt_load_error', {
                what: target, item: itemName,
                error: String(e && e.message ? e.message : e).slice(0, 200),
                stack: String(e && e.stack ? e.stack : '').split('\n').slice(0, 4).join(' | ').slice(0, 300),
                slotCount: windowSlotCount(bot, win), slotCountVia: slotCountSource(bot, win),
                playerRange: (() => { const g = playerInvRange(bot, win); return g ? `${g.start}-${g.end}#${g.via}` : null; })(),
                winType: win?.type ?? null,
            });
            return { ok: false, reason: 'threw', error: String(e && e.message ? e.message : e).slice(0, 200) };
        }
    }

    async _smeltSession(ctx, furnaceBlock, opsNeeded) {
        const bot = ctx.bot;
        // 会话 deadline 按需：10s/锭 + 45s 余量，封顶 150s（死会话不拖垮整个任务）
        const deadline = Date.now() + Math.min(150000, opsNeeded * 15000 + 45000);
        let furnace;
        try {
            const w0 = bot.currentWindow;
            if (w0 && String(w0.type).includes('furnace')) { try { bot.closeWindow(w0); } catch { /* 忽略 */ } }
            furnace = await withTimeout(bot.openFurnace(furnaceBlock), 8000, 'open_furnace_timeout');
        } catch (e) {
            ctx.telemetry('furnace_open_fail', { error: String(e && e.message ? e.message : e).slice(0, 120) });
            return false;
        }
        this._furnace = furnace;
        try {
            // mineflayer Furnace API：inputItem()/fuelItem()/outputItem() 是槽位；fuel/fuelSeconds
            // 是「当前燃烧比例/剩余秒数」（craft_progress_bar 包驱动），不是物品
            let fuel = this._pickFuel(ctx, opsNeeded);
            if (!fuel) { ctx.telemetry('smelt_missing_fuel', { at: 'furnace' }); return false; }
            // 投料（只投还差的量）
            //
            // ═══ MC-M1-TASK-09-r4：装料 / 加燃料改走 shift 点击（window_ops.quickMoveIntoFurnace）═══
            // 不再调用 `furnace.putInput` / `furnace.putFuel`。它们的实现是
            // `furnace.js:93-105 putSomething` → `bot.transfer({sourceStart: furnace.inventoryStart,
            // sourceEnd: furnace.inventoryEnd})`，而 1.16.1 上这个区间是**坏的**
            // （`open_window` 不带 slotCount，类型号又对不上 prismarine-windows 自己那套
            // 编号 ⇒ 套默认 `{27,62}`，在 39 格的熔炉窗上只覆盖 27..38，主背包 3..26 这 24 格够不着）
            // ⇒ `bot.transfer` 在 `inventory.js:305` 必 `throw "Can't find <item> in slots [27 - 63]"`。
            // 旧代码这两处是**裸 await**（无 try/catch）⇒ 异常冒到 driveTask 的 catch 变成
            // INTERNAL，且耗时极短（不走 5s 超时）、**异常文本在任何落盘物里都不存在**
            // ——这就是 r3 定位到的"place_ok 之后 0.5s 空白"、以及"熔炉取产物 0–2/30"、
            // "smeltOk 恒 0"的整条历史病。
            // 1.16.1 服务端 `AbstractFurnaceMenu.quickMoveStack:109-124` 会自己分流：
            // 可熔炼 → 输入格(0)、可燃 → 燃料格(1)、两者都不是 → 静默搬到快捷栏(30..38)。
            // 判据在 window_ops 里按**服务端 window_items** 的 0/1 两格真值确认。
            const inputName = this.smeltDef.input;
            const inputItem = bot.inventory.items().find((i) => i.name === inputName);
            if (inputItem) {
                const put = Math.min(inputItem.count, opsNeeded - (furnace.outputItem()?.count ?? 0));
                if (put > 0 && !(furnace.inputItem()?.name === inputName && furnace.inputItem().count >= put)) {
                    const r = await this._loadIntoFurnace(ctx, furnace, { itemName: inputName, target: 'input' });
                    if (!r.ok && r.reason !== 'already_loaded') return false;
                }
            }
            const rf = await this._loadIntoFurnace(ctx, furnace, { itemName: fuel.name, target: 'fuel', wantCount: fuel.count });
            if (!rf.ok && rf.reason !== 'already_loaded') return false;
            ctx.telemetry('smelt_fuel_in', { fuel: fuel.name, count: fuel.count, per: fuel.per, opsNeeded });
            await sleep(POLL_MS);
            // 等产物 + 补燃料循环
            while (Date.now() < deadline) {
                if (this.countMet(ctx)) return true;
                const out = furnace.outputItem();
                if (out?.count > 0) {
                    // TASK-09：窗口感知计数 —— 熔炉开着时，服务端把产物放进的是**熔炉窗口的
                    // 镜像背包区**（inventory.js 按 windowId 派发 set_slot），`bot.inventory`
                    // 读不到。用 countItems 会恒读到 0，这正是 06c「背包同步慢 / smeltOk 恒 0」
                    // 里真正属于本单的那一半。
                    const before = countItemsWindowAware(bot, this.item, bot.currentWindow);
                    // ⚠⚠ MC-M1-TASK-06d P2-3 验收局诊断转储抓到的**真因**（06c/06d 两轮都只看到表象）：
                    //   光标上残留着「刚放下的熔炉方块」。`furnace.takeOutput()` 内部第一步是
                    //   `clickWindow(2,0,0)` —— 光标非空时这是一次**交换**，于是熔炉和产物对调，
                    //   后面的 putSelectedItemRange 搬的是熔炉，产物从此下落不明。
                    //   现场原文：held="furnacex1"、inv 里只有 iron_orex3、slots="0:iron_orex2 1:- 2:-"、
                    //   nearItems="(none)"、stillInFurnace=0 —— 东西确实离开了炉子，谁也没拿到。
                    //   判据：`smeltOk` 从 06c 起恒 0，而同一条任务的 craft_ok 一直正常。
                    if (bot.heldItem) {
                        const was = `${bot.heldItem.name}x${bot.heldItem.count}`;
                        try {
                            await withTimeout(bot.tossStack(bot.heldItem), 2000, 'pre_take_cursor_clear');
                            ctx.telemetry('smelt_pre_cursor_cleared', { was });
                        } catch (e) {
                            ctx.telemetry('smelt_pre_cursor_clear_error', { was, error: String(e && e.message ? e.message : e).slice(0, 100) });
                        }
                    }
                    // ═══ MC-M1-TASK-09：取产物换成「自己一步步点 + 每步等服务端确认」═══
                    // 换掉 `furnace.takeOutput()`。它 = `putAway(2)` = 点一下 + putSelectedItemRange
                    // + 等回包 的**复合动作**：光标非空时第一步就是"交换"（熔炉↔产物），
                    // 任一环节被服务端拒收，客户端模型已改而服务端没改 ⇒ 产物下落不明。
                    // 06c/06d 两轮共 3 次诊断（3s→8s→20s 轮询）全部没抓到它，因为
                    // **产物压根没进包**，等的不是"背包同步慢"。
                    // 新流程：点输出格 → 等服务端对那一次点击的判决 → 从**服务端 set_slot(-1)**
                    // 确认光标真拿到东西 → 点背包目标格 → 再等一次判决 → 按背包增量兜底。
                    const takeStarted = Date.now();
                    const take = await takeFurnaceOutputConfirmed(bot, furnace, {
                        timeoutMs: 2500, itemName: this.item, expectName: this.item,
                    });
                    const waitedMs = Date.now() - takeStarted;
                    const gained = take.ok ? (take.gained || take.took || 0) : 0;
                    ctx.telemetry('smelt_take_checked', {
                        item: this.item, took: out.count, before, after: countItems(bot, [this.item]),
                        gained, waitedMs, ok: !!take.ok, reason: take.reason ?? null,
                        dest: take.dest ?? null,
                        stillInFurnace: furnace.outputItem()?.count ?? 0,
                    });
                    this.smelted += Math.max(0, gained);
                    if (take.ok) {
                        // MC-M1-TASK-09：smelt_ok 的口径从"背包增量"改成"**服务端逐步确认过**
                        // 且背包增量到账"——两者都要满足才算数。旧口径只看背包增量，
                        // 在产物没到手时会记 0；新口径下每一条 smelt_ok 都对应一次真的熔炼。
                        ctx.run.counters.smeltOk += Math.max(1, gained);
                        ctx.telemetry('smelt_ok', {
                            item: this.item, gained, took: out.count,
                            total: countItems(bot, [this.item]), smelted: this.smelted,
                        });
                    } else {
                        // 服务端没确认 = 产物没到手。**不要**再在这里靠轮询等背包
                        // （06d 已证：等更久只会白烧预算，见报告 §5.3）。
                        // 但必须把"产物到底去哪了"一次性抓全（手册 §5：归因必须引用遥测）。
                        ctx.run.counters.smeltFailures++;
                        const nearItems = Object.values(bot.entities)
                            .filter((e) => e.name === 'item' && e.position.distanceTo(bot.entity.position) < 6)
                            .map((e) => {
                                let n = '?';
                                try { n = e.item ? `${e.item.name}x${e.item.count}` : String(e.metadata); } catch { /* ignore */ }
                                return `${n}@${Math.round(e.position.distanceTo(bot.entity.position))}`;
                            });
                        ctx.telemetry('smelt_take_unverified', {
                            item: this.item, took: out.count, waitedMs, reason: take.reason ?? null,
                            verdict: take.verdict ? JSON.stringify(take.verdict).slice(0, 200) : null,
                            stillInFurnace: furnace.outputItem()?.count ?? 0,
                            inv: bot.inventory.items().map((i) => `${i.slot}:${i.name}x${i.count}`).join(' '),
                            held: bot.heldItem ? `${bot.heldItem.name}x${bot.heldItem.count}` : 'none',
                            slots: [0, 1, 2].map((i) => (furnace.slots[i] ? `${i}:${furnace.slots[i].name}x${furnace.slots[i].count}` : `${i}:-`)).join(' '),
                            nearItems: nearItems.join(' ').slice(0, 200) || '(none)',
                            win: bot.currentWindow ? `${bot.currentWindow.type}#${bot.currentWindow.id} inv[${bot.currentWindow.inventoryStart},${bot.currentWindow.inventoryEnd})` : 'closed',
                        });
                    }
                    if (this.countMet(ctx)) return true;
                }
                // 燃料烧完且还有输入 → 补投（按剩余需求算）
                const burning = (furnace.fuelSeconds ?? 0) > 0;
                if (!burning && (furnace.inputItem()?.count ?? 0) > 0 && opsNeeded() > 0) {
                    fuel = this._pickFuel(ctx, opsNeeded());
                    if (fuel) {
                        // r4：同上。旧写法是 `.catch(() => {})` —— **失败被静默吞掉**，
                        // 然后照发一条 `smelt_refuel`，读数会显示"补过燃料"而实际没补。
                        const rr = await this._loadIntoFurnace(ctx, furnace, { itemName: fuel.name, target: 'fuel', wantCount: fuel.count });
                        ctx.telemetry('smelt_refuel', { fuel: fuel.name, count: fuel.count, ok: !!rr.ok, reason: rr.reason ?? null });
                    } else {
                        ctx.telemetry('smelt_fuel_out', { item: this.item });
                        return false;
                    }
                }
                // 输入烧完、无在烧产物、炉子熄了而目标未达 → 结束本次会话，外层重试
                if (!(furnace.inputItem()?.count > 0) && !(furnace.outputItem()?.count > 0) && !burning) {
                    return this.countMet(ctx);
                }
                await sleep(POLL_MS);
            }
            return this.countMet(ctx);
        } finally {
            this._furnace = null;
            // 清炉：拿回残留的输入/燃料（成品已在循环里取走），防挖炉时内容物散落。
            // r4：`furnace.takeInput()/takeFuel()` 内部是 `bot.putAway(slot)`，而 `putAway`
            // 用的也是 `window.inventoryStart/inventoryEnd`（`inventory.js:660-662`）
            // ⇒ 同一个坏区间 ⇒ 残余物留在炉里，挖炉时散落一地。改走 shift 点击。
            for (const [slot, tag] of [[0, 'input'], [1, 'fuel']]) {
                const s = furnace.slots?.[slot];
                if (!s || !(s.count > 0)) continue;
                try {
                    const r = await withTimeout(quickMoveOutOfFurnace(bot, furnace, { slot, timeoutMs: 2000 }), 6000, 'quick_move_out_timeout');
                    if (!r.ok) ctx.telemetry('smelt_unload_fail', { what: tag, reason: r.reason ?? null, got: `${s.name}x${s.count}` });
                } catch (e) {
                    ctx.telemetry('smelt_unload_error', { what: tag, error: String(e && e.message ? e.message : e).slice(0, 160) });
                }
            }
            // TASK-09：清炉取产物同样走逐步确认（原来的 takeOutput() 是同一个复合动作）
            try { if (furnace.outputItem()?.count > 0) await takeFurnaceOutputConfirmed(bot, furnace, { timeoutMs: 1500 }); } catch { /* 忽略 */ }
            try { await closeWindowConfirmed(bot, furnace); } catch { /* 忽略 */ }
        }
    }

    // ---------- 回收（自己放的熔炉挖回；best-effort） ----------
    async _tickReclaim(ctx) {
        const bot = ctx.bot;
        const pos = this._placedFurnacePos;
        if (!pos || !this.reclaimFurnace || this._reclaimDone) {
            this._succeed({ item: this.item, count: countItems(bot, [this.item]), smelted: this.smelted, furnacePlaced: !!this._placedFurnacePos });
            return;
        }
        this._reclaimDone = true;
        const block = bot.blockAt(pos);
        if (!block || block.name !== FURNACE_ITEM) { this._succeed({ item: this.item, count: countItems(bot, [this.item]), smelted: this.smelted }); return; }
        try {
            if (bot.entity.position.distanceTo(pos) > 3.5) {
                const ok = await navTo(ctx, new pf.goals.GoalNear(pos.x, pos.y, pos.z, 2), { timeoutMs: 15000, label: 'furnace_reclaim_nav' });
                if (!ok) { this._succeed({ item: this.item, count: countItems(bot, [this.item]), smelted: this.smelted, reclaim: 'nav_fail' }); return; }
            }
            const before = countItems(bot, [FURNACE_ITEM]);
            await withTimeout(bot.dig(bot.blockAt(pos)), 8000, 'dig_timeout');
            for (let w = 0; w < 5 && countItems(bot, [FURNACE_ITEM]) <= before; w++) {
                await sleep(300);
                if (w === 1) {
                    const drop = Object.values(bot.entities)
                        .find((e) => e.name === 'item' && e.position.distanceTo(bot.entity.position) < 3.5);
                    if (drop) {
                        const p = bot.pathfinder.goto(new pf.goals.GoalFollow(drop, 0.8));
                        p.catch(() => {});
                        await Promise.race([p, sleep(2500)]);
                        try { bot.pathfinder.stop(); } catch {}
                    }
                }
            }
            ctx.telemetry(countItems(bot, [FURNACE_ITEM]) > before ? 'furnace_reclaimed' : 'furnace_reclaim_fail', { pos: [pos.x, pos.y, pos.z] });
        } catch (e) {
            ctx.telemetry('furnace_reclaim_fail', { error: String(e && e.message ? e.message : e).slice(0, 100) });
        }
        this._succeed({ item: this.item, count: countItems(bot, [this.item]), smelted: this.smelted });
    }
}

function inventoryDump(bot) {
    return bot.inventory.items().map((i) => `${i.name}x${i.count}`).join(',').slice(0, 200);
}
