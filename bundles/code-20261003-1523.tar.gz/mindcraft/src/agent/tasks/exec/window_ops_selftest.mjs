﻿// window_ops_selftest.mjs — MC-M1-TASK-09-r4 的离线用例（不开服、不占端口、不连任何东西）
//
// 本单治的是两条病，两条都**静默**，所以用例必须能证伪"修好了"，而不是只能证明"没抛错"：
//
//   ① **取料区间是坏的**：mineflayer `furnace.js:99-100` 的 `putSomething` 把
//      `sourceStart: furnace.inventoryStart, sourceEnd: furnace.inventoryEnd` 当取料区间。
//      r3 离线量到熔炉窗是 `slots=39 / inventoryStart=27 / inventoryEnd=63`
//      ⇒ 实际只覆盖窗口槽 27–38（12 格），**玩家主背包 3–26 这 24 格结构上够不着**。
//      本单改成从**服务端 window_items 的数组长度**推区间（`playerInvRange`）。
//      ⇒ 用例 ①–⑤ 就是钉这件事的：真实 prismarine-windows + 真实 1.16.1 物品工厂，
//        故意造出 r3 那种混搭区间，再断言 `playerInvRange` 仍取到**全部 36 格**。
//      ⚠ 阴性对照：旧的 `win.inventoryStart/inventoryEnd` 在同一夹具上**必须错**（用例 ④）——
//        如果哪天"坏区间"也变对了，这条用例会红，那说明 r3 的机制描述需要再更正一次。
//
//   ② **`item`（光标）字段填错**：1.16.1 服务端 ack 判据是
//      `ItemStack.matches(包里的光标, 点击后服务端光标)`（`ServerGamePacketListenerImpl.java:1180`），
//      而 mineflayer `clickWindow` 填的是 `win.slots[slot]`（`inventory.js:571/626`）。
//      ⇒ 用例 ⑥–⑫ 断言 `clickCarryConfirmed` 在**四种点击语义**下 `item` 各填什么，
//        并用**变异测试**（把 carryAfter 换回 `win.slots[slot]`）证明这些断言真能抓住它。
//
//   ③ 2×2 网格合成的**几何闸门**：`_gridCells` 放不下必须返回 null（"需要工作台"），
//      绝不能少放几个格子凑合 —— 少放会被服务端判成配方不匹配、结果格恒空，
//      读数看起来像"合成失败"而真因是"这东西根本不该走 2×2"。用例 ⑬–⑮。
//
//   ④ 假 bot 只补**真库确实有**的字段（G 线第七轮那条纪律：假 bot 比真库宽 ⇒ 真 bug 被盖成绿灯）。
//      见 `makeFakeBot` 的字段清单与末尾的 `assertFakeBotMatchesRealLib`。
//
// 跑法：node window_ops_selftest.mjs      （退出码 0 = 全过）

import { EventEmitter } from 'events';
import { createRequire } from 'module';
import prismarineItem from 'prismarine-item';
import {
    playerInvRange, windowSlotCount, slotCountSource, countItemsInRange, findInPlayerRange,
    itemWithCount, toItem, waitServerWindowSlots, clickCarryConfirmed, quickMoveIntoFurnace,
    craftInGridConfirmed, clickFlavor, windowClickPacket, makeCursorTracker, predictClickedReturn,
} from './window_ops.js';

const require = createRequire(import.meta.url);

/**
 * 安全地取一段摘要。
 * ⚠ 关键点：**实参在调用点就被求值** —— `JSON.stringify(undefined)` 返回的是
 *   `undefined`（不是字符串），所以 `JSON.stringify(x?.y).slice(0,n)` 会在断言
 *   还没来得及跑之前就抛 TypeError，**把后面所有断言一起带走**。
 *   本单第一版就是这么写的，变异测试 M1 里明明已经红了 4 条，却整体崩掉、看不到后续结果。
 */
const brief = (v, n = 140) => {
    try {
        const s = JSON.stringify(v);
        return s === undefined ? String(v) : s.slice(0, n);
    } catch { return '(取不出来)'; }
};

let pass = 0, fail = 0;
/**
 * ⚠ `extra` 必须能扛住"被测对象是 undefined/null"——本单第一版写成
 *   `brief(sent?.params, 120)`，而 `JSON.stringify(undefined)`
 *   返回的是 **`undefined` 不是字符串** ⇒ 断言失败时 `.slice` 抛异常，
 *   **把后面所有断言一起带走**（变异测试 M1 实际踩到：明明已经红了 4 条，
 *   却在第 5 条崩掉，看不到后面的结果）。
 *   ⇒ 失败路径绝不允许抛异常。
 */
const ok = (cond, name, extra = '') => {
    if (cond) { pass++; console.log(`  ✅ ${name}`); }
    else {
        fail++;
        let e = '';
        try { e = extra === '' ? '' : `  → ${String(extra).slice(0, 160)}`; } catch { e = '  → (附加信息取不出来)'; }
        console.log(`  ❌ ${name}${e}`);
    }
};
const section = (t) => console.log(`\n── ${t} ──`);
/** 让出微任务队列：被测函数里发包发生在 await 之后，读"发了什么"之前必须先让一拍 */
const tick = () => new Promise((r) => setImmediate(r));

// ─────────────────────────────────────────────────────────────────────
// 夹具：真 1.16.1 registry + 真 prismarine-windows 造的窗口（不是手搓的对象）
// ─────────────────────────────────────────────────────────────────────
const registry = require('prismarine-registry')('1.16.1');
const Item = prismarineItem(registry);
const windowsFactory = require('prismarine-windows')(registry);

/**
 * 造一扇 **r3 实测那种混搭**的窗口：槽数是熔炉的 39，但背包区间被换成坏的 {27,62}。
 * 这正是 1.16.1 上 open_window 的类型号对不上 prismarine-windows 自己那套编号时
 * `createWindow` 兜底分支造出来的东西（`prismarine-windows/index.js:76-85`）。
 */
function makeFurnaceWindowBroken() {
    const w = windowsFactory.createWindow(7, 'minecraft:furnace', 'container.furnace', undefined);
    w.id = 7;
    // 强行复现 r3 的观测值
    w.inventoryStart = 27;
    w.inventoryEnd = 63;
    w.slots = new Array(39).fill(null);
    return w;
}
/** 阴性对照夹具：区间**没坏**的熔炉窗（prismarine 自己认对了类型） */
function makeFurnaceWindowGood() {
    const w = windowsFactory.createWindow(7, 'minecraft:furnace', 'container.furnace', undefined);
    w.id = 7;
    w.slots = new Array(w.slots.length).fill(null);
    return w;
}

/**
 * 假 bot：**只补真库确实有的东西**。
 * `bot._client`（EventEmitter：真 bot 上是 minecraft-protocol 的 Client）、
 * `bot.registry`、`bot.version`、`bot.supportFeature`（真 bot 上的方法）。
 * 刻意**不补** `bot.inventory.windowSlotsRange` 之类真库没有的字段。
 */
function makeFakeBot({ version = '1.16.1' } = {}) {
    const client = new EventEmitter();
    client.written = [];
    client.write = (name, params) => { client.written.push({ name, params }); };
    return {
        _client: client,
        registry,
        version,
        supportFeature: (f) => {
            // 1.16.x 真实取值（minecraft-data 的 features）
            if (f === 'actionIdUsed' || f === 'transactionPacketExists') return true;
            if (f === 'stateIdUsed') return false;
            return false;
        },
    };
}

// ⚠⚠ **本单踩到的一个真陷阱，必须钉住**（手册 §3 已有 D 线那条同族记录：
//   "prismarine-item 在 1.16 上 `.name` 可能是 `unknown`"，这里是它的**成因**）：
//   `new Item('iron_ore', 5)` 在 1.16.1 上给出 `{name:'unknown', type:'iron_ore'}` ——
//   **`type` 是字符串，不是数字 id**！于是 `Item.toNotch()` 产出的 `itemId` 是字符串
//   `"iron_ore"`，协议要的是 VarInt 数字 ⇒ **发出去的包在真实服务端上必然是坏的**。
//   而 if 两个 undefined/两个同名字符串互相比较，断言会**假绿**。
//   ⇒ 夹具一律**按数字 id 造物品**，并且下面 ⑯ 把这个陷阱本身断言住。
const item = (name, count) => {
    const id = registry.itemsByName[name]?.id;
    if (id == null) throw new Error(`fixture: 1.16.1 没有这个物品 ${name}`);
    return new Item(id, count ?? 1);
};

// ─────────────────────────────────────────────────────────────────────
section('① 区间：坏夹具上 playerInvRange 仍取到全部 36 格（r3 病根）');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();

    // r3 的原始观测（钉住，防止"病根形状"被人悄悄改掉而不自知）
    ok(win.slots.length === 39, '夹具复现 r3 观测：slots.length=39', `got ${win.slots.length}`);
    ok(win.inventoryStart === 27 && win.inventoryEnd === 63,
        '夹具复现 r3 观测：inventoryStart=27 / inventoryEnd=63（坏区间）',
        `got ${win.inventoryStart}/${win.inventoryEnd}`);

    // 关键：没有服务端 window_items 快照时，退回 slots.length 推
    const r = playerInvRange(bot, win);
    ok(r.start === 3 && r.end === 39, 'playerInvRange 给出 3–39（39−36），不是 27–63',
        `got ${r?.start}-${r?.end}`);
    ok(r.start === win.slots.length - 36, '区间 = 槽数 − 36 这条原版规则');
    ok(r.hotbarStart === 30, '快捷栏起点 = 30（主背包 3..29 之后）', `got ${r.hotbarStart}`);
}

// ─────────────────────────────────────────────────────────────────────
section('② 服务端 window_items 优先于本地 slots.length');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();
    ok(playerInvRange(bot, win).via === 'prismarine_slots', '无服务端快照时来源标 prismarine_slots');

    // 服务端下发整窗：真实槽数 39
    bot._client.emit('window_items', { windowId: win.id, items: new Array(39).fill(null) });
    ok(windowSlotCount(bot, win) === 39, '服务端 window_items 记下槽数 39');
    ok(slotCountSource(bot, win) === 'window_items', '来源标成 window_items（可区分）');
    ok(playerInvRange(bot, win).via === 'window_items', '有服务端快照后 via 变成 window_items');

    // 服务端说其实有 46 格（类型认错时的真实情形）⇒ 区间必须跟着服务端走
    bot._client.emit('window_items', { windowId: win.id, items: new Array(46).fill(null) });
    const r = playerInvRange(bot, win);
    ok(r.start === 10 && r.end === 46, '服务端改口说 46 格 ⇒ 区间跟着变成 10–46（不认本地 39）',
        `got ${r?.start}-${r?.end}`);

    // 不同窗口互不污染
    const w2 = windowsFactory.createWindow(9, 'minecraft:furnace', 'x', undefined);
    w2.slots = new Array(39).fill(null);
    ok(windowSlotCount(bot, w2) === 39, '按窗口 id 分别记，不会串号');
}

// ─────────────────────────────────────────────────────────────────────
section('③ 坏区间够不着的 24 格，新区间一个不漏');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();
    // 玩家主背包：3..35（33 格）里塞满矿石，主背包最前面那几格 r3 够不着
    for (let i = 3; i <= 35; i++) win.slots[i] = item('iron_ore', 1);
    // 快捷栏 36..38
    for (let i = 36; i <= 38; i++) win.slots[i] = item('oak_log', 1);

    // 守卫：夹具造出来的物品必须是**协议形状**（否则下面所有断言都在比字符串，假绿）
    ok(win.slots[3].name === 'iron_ore' && typeof win.slots[3].type === 'number',
        '夹具守卫：物品是数字 type + 正确 name', `${win.slots[3].name}/${typeof win.slots[3].type}`);

    const range = playerInvRange(bot, win);
    // r3 的坏区间只覆盖 27..38
    const oldReachable = [];
    for (let i = win.inventoryStart; i < Math.min(win.inventoryEnd, win.slots.length); i++) {
        if (win.slots[i]) oldReachable.push(i);
    }
    ok(oldReachable.length === 12, '阴性对照：r3 坏区间只能看到 12 格', `got ${oldReachable.length}`);
    ok(countItemsInRange(bot, win, range, 'iron_ore') === 33, '新区间读到全部 33 个 iron_ore',
        `got ${countItemsInRange(bot, win, range, 'iron_ore')}`);
    ok(findInPlayerRange(win, range, 'iron_ore') === 3, '第一个 iron_ore 在槽 3（坏区间的起点是 27）');
    ok(findInPlayerRange(win, range, 'oak_log') === 36, '快捷栏的 oak_log 在 36 也够得着');
    ok(countItemsInRange(bot, win, range, 'coal') === 0, '没有的东西仍然读 0（不凭空造）');
}

// ─────────────────────────────────────────────────────────────────────
section('④ 阴性对照：区间没坏时两种口径一致（防"坏区间也变对"）');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowGood();
    ok(win.inventoryStart === 3 && win.inventoryEnd === 39,
        '夹具：prismarine 自己认对类型时区间就是 3–39', `got ${win.inventoryStart}/${win.inventoryEnd}`);
    const r = playerInvRange(bot, win);
    ok(r.start === win.inventoryStart && r.end === win.inventoryEnd,
        '区间没坏时，新口径与库口径**逐字相同**（不制造行为变化）');
    // 反向：如果哪天 r3 那个混搭区间也变对了，用例 ① 的"阴性对照"就该红——
    // 这条断言把"病根形状"钉死，防止将来静默变化。
    ok(!(makeFurnaceWindowBroken().inventoryStart === 3),
        '反向守卫：坏夹具的区间仍不等于 3（若变了说明库行为变了，要重新评估 r3 结论）');
}

// ─────────────────────────────────────────────────────────────────────
section('⑤ window 0 的区间沿用本仓既有口径');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const inv = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    inv.slots = new Array(inv.slots.length).fill(null);
    ok(inv.slots.length === 46, 'window 0 有 46 槽', `got ${inv.slots.length}`);
    const r = playerInvRange(bot, inv);
    // 1.16.1 InventoryMenu 实测（子 agent 逐行核过源码）：0=产物 1-4=网格 5-8=护甲
    // 9-35=主背包 36-44=快捷栏 45=副手
    ok(r.start === 9 && r.end === 45 && r.hotbarStart === 36, 'window 0 区间 = 9–45 / 快捷栏 36',
        `got ${r?.start}-${r?.end} / ${r?.hotbarStart}`);
    ok(r.start === inv.inventoryStart && r.end === inv.inventoryEnd,
        'window 0 上新口径与库口径一致（countItems 走的就是这个区间）');
    // ⚠ 46−36=10 是错的：window 0 的护甲+副手占了 5-8 与 45 ⇒ 用例钉住这个特例
    ok(inv.slots.length - 36 !== 9, '守卫：window 0 不能套用"槽数−36"（会是 10，差 1 格）');
}

// ─────────────────────────────────────────────────────────────────────
section('⑥ item 字段：按 1.16.1 源码填「clicked() 的返回值」（2×2 病根）');
// ─────────────────────────────────────────────────────────────────────
// 判据（`ServerGamePacketListenerImpl.java:1179-1180`）：
//   `ItemStack.matches(包里的 item, menu.clicked(slot, button, mode, player))`
// 而 `AbstractContainerMenu.b(...)` 的返回值（逐行核过 `docs/research/data/src-1161/`）：
//   `:159` 初值 `ItemStack.EMPTY`；`:256` PICKUP 只在**被点那格非空**时赋成那格的拷贝；
//   `:233-245` QUICK_MOVE 返回**被移动那摞的拷贝**（各菜单 quickMoveStack 给的是
//   **搬动前的整份拷贝**，搬动量 0 时返回 EMPTY）。
// ⇒ 规则：**item = 被点那一格的点击前内容；那格为空（或没搬动）就报空。**
// ⚠ **不是"点击后的光标"** —— 光标是 `:254` 的 `☃x.m()`，它不参与返回值。
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('spruce_planks', 8);
    const lastPkt = () => bot._client.written.at(-1);

    // ① 整摞拿起（左键点非空格）⇒ item = 那一格的点击前内容
    let r = await clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 50 });
    ok(r.ok === false && r.unconfirmed === true, '没回执时如实判 unconfirmed（不假定成功）');
    let pkt = lastPkt();
    ok(pkt.name === 'window_click', '发的是 window_click');
    ok(pkt.params.windowId === 0 && pkt.params.slot === 10, 'windowId/slot 对得上');
    ok(pkt.params.item && pkt.params.item.itemId === win.slots[10].type, '拿起：item 填的是那一格的东西',
        brief(pkt.params.item));
    ok(typeof pkt.params.item.itemId === 'number', 'itemId 必须是**数字**（VarInt），不是物品名字符串',
        `typeof=${typeof pkt.params.item?.itemId}`);
    ok(pkt.params.item.itemCount === 8, '拿起：数量也是那一格的数量', `got ${pkt.params.item?.itemCount}`);
    ok(typeof pkt.params.action === 'number', '1.16.x 信封带 action 号');

    // ② ★★ 右键把 1 个放进**空的** 2×2 格 ⇒ item **必须是空**（`AbstractContainerMenu:159+256`
    //    那一格原本是空 ⇒ 返回值从初值 EMPTY 起、从没被赋值）
    //    ⚠ 这正是 r4 实跑 `place_rejected` 的成因：当时上报的是光标 `oak_log×5`。
    win.selectedItem = item('spruce_planks', 8);
    await clickCarryConfirmed(bot, win, { slot: 1, mouseButton: 1, mode: 0, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false,
        '★★ 放进空格：item 必须报空（不是光标、不是空格里的东西）', brief(pkt.params.item));
    ok(!('itemCount' in (pkt.params.item || {})) || pkt.params.item.itemCount === 0,
        '★★ 放进空格：不能带 itemCount（present=false 就是"什么都没有"）', brief(pkt.params.item));

    // ③ QUICK_MOVE（shift）点**非空**槽 ⇒ item = 被移动那摞的拷贝（**整摞**）
    win.selectedItem = null;
    await clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 1, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.mode === 1, 'QUICK_MOVE 的 mode=1');
    ok(pkt.params.item && pkt.params.item.present === true && pkt.params.item.itemCount === 8,
        'QUICK_MOVE：item 填**被移动那摞**（8 个整摞），不是空', brief(pkt.params.item));

    // ④ 放回（光标整摞放进空格）⇒ 被点格为空 ⇒ item 报空
    win.selectedItem = item('spruce_planks', 6);
    await clickCarryConfirmed(bot, win, { slot: 20, mouseButton: 0, mode: 0, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false, '放回：被点是空格 ⇒ item 填空', brief(pkt.params.item));

    // ⑤ ★ 交换语义：光标**非空**时点**非空**格 ⇒ item 仍是**那一格的**内容，**不是光标**
    //    （光标非空 + 格子非空 = 交换；服务端算出的返回值 = 格子那摞）
    win.slots[20] = item('oak_log', 3);
    win.selectedItem = item('spruce_planks', 6);
    await clickCarryConfirmed(bot, win, { slot: 20, mouseButton: 0, mode: 0, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item.itemId === win.slots[20].type && pkt.params.item.itemCount === 3,
        '★ 交换：item 填被点格的 3 个原木，**不是**手上的 6 个木板', brief(pkt.params.item));

    // ⑥ QUICK_MOVE 点**空**槽 ⇒ nothing to move ⇒ 返回空
    await clickCarryConfirmed(bot, win, { slot: 25, mouseButton: 0, mode: 1, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false, 'QUICK_MOVE 点空槽：item 填空（没东西可搬）', brief(pkt.params.item));

    // ⑦ 明知搬不动（expectMove:false）⇒ 空
    await clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 1, expectMove: false, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false, 'expectMove:false ⇒ item 填空', brief(pkt.params.item));

    // ⑧ 点窗口外（THROW，slot<0）⇒ 返回空
    await clickCarryConfirmed(bot, win, { slot: -999, mouseButton: 0, mode: 0, timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item && pkt.params.item.present === false, '点窗口外（THROW）：item 填空', brief(pkt.params.item));

    // ⑨ ★★ 回归锁：旧的 `carryAfter` 入参**必须被忽略**（它就是 r4 的病根写法）
    win.slots[30] = item('cobblestone', 5);
    win.selectedItem = item('oak_log', 9);
    await clickCarryConfirmed(bot, win, { slot: 30, mouseButton: 0, mode: 0, carryAfter: item('oak_log', 9), timeoutMs: 50 });
    pkt = lastPkt();
    ok(pkt.params.item.itemId === win.slots[30].type && pkt.params.item.itemCount === 5,
        '★★ carryAfter 传什么都不影响：item 一律按"被点格点击前内容"算', brief(pkt.params.item));
}

// ─────────────────────────────────────────────────────────────────────
section('⑦ 服务端拒收 / 接受 两种回执都要如实反映');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);

    // 抓 action 号：回执必须按我们发出去的那个 action 对齐，迟到的旧回执不认
    const p = clickCarryConfirmed(bot, win, { slot: 1, mouseButton: 1, mode: 0, timeoutMs: 400 });
    const sent = bot._client.written.at(-1).params;
    // 先来一条别的 action 的回执（模拟迟到/别人的）
    bot._client.emit('transaction', { windowId: 0, action: sent.action - 1, accepted: false });
    // 再来我们自己的
    bot._client.emit('transaction', { windowId: 0, action: sent.action, accepted: false });
    const rej = await p;
    ok(rej.rejected === true, 'accepted=false ⇒ rejected', JSON.stringify(rej));
    ok(rej.via === 'transaction', '判决来自 transaction 包');

    const p2 = clickCarryConfirmed(bot, win, { slot: 1, mouseButton: 1, mode: 0, timeoutMs: 400 });
    const sent2 = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sent2.action, accepted: true });
    const acc = await p2;
    ok(acc.ok === true, 'accepted=true ⇒ ok', JSON.stringify(acc));
}

// ─────────────────────────────────────────────────────────────────────
section('⑦b 被拒必须**立刻回 transaction 道歉**（否则窗口从此静默吞点击）');
// ─────────────────────────────────────────────────────────────────────
// 机制（`ServerGamePacketListenerImpl.java`）：
//   :1189 一次拒收 → `setSynched(player,false)`；
//   :1169 闸门 `bw.containerId==id && bw.isSynched(player)` ⇒ 此后本窗口的点击
//         **全部被忽略、连 ack 都不回**（客户端看到的就是"后面全没反应"）；
//   :1259-1267 `handleContainerAck` 认**同 windowId + 同 uid** 且当前 `!isSynched` ⇒ 恢复。
//   mineflayer 只对它自己队列里的 action 回 ack（`inventory.js:492-502`），
//   ⇒ **我们自己直发的包没人替我们道歉**。
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('oak_log', 6);

    // ── 阴性对照（先做）：accepted=true 时**绝不能**多发 transaction ──
    const before = bot._client.written.length;
    const pOk = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 400 });
    const sentOk = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sentOk.action, accepted: true });
    const accOk = await pOk;
    const sentTx = bot._client.written.slice(before + 1).filter((w) => w.name === 'transaction');
    ok(accOk.ok === true, '阴性对照：accepted=true ⇒ ok', brief(accOk));
    ok(sentTx.length === 0, '阴性对照：被接受时不发多余的 transaction（不刷服务端）', `发了 ${sentTx.length} 条`);

    // 上面那次被接受的"拿起"会调 acceptClick 推进模型（见 ⑧），这里把模型复位再测拒收
    win.selectedItem = null;
    win.slots[10] = item('oak_log', 6);

    // ── 正例：accepted=false ⇒ 立刻回 transaction（windowId + uid 都对齐）──
    const pRej = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 400, resyncTimeoutMs: 400 });
    const sentRej = bot._client.written.at(-1).params;
    // 服务端：先回 accepted=false，再（同一 handler 里）发整窗 window_items
    bot._client.emit('transaction', { windowId: 0, action: sentRej.action, accepted: false });
    const rej = await pRej;
    // window_items 可能在道歉之后才到（真实顺序取决于网络），这里模拟"迟到一点"
    bot._client.emit('window_items', { windowId: 0, items: new Array(46).fill(null) });
    await tick();

    const ap = bot._client.written.filter((w) => w.name === 'transaction');
    ok(ap.length === 1, '★★ 被拒后**恰好发出一条** transaction 道歉', `发了 ${ap.length} 条`);
    ok(ap[0]?.params?.windowId === win.id, '道歉的 windowId 与当前窗口一致', brief(ap[0]?.params));
    ok(ap[0]?.params?.action === sentRej.action,
        '★★ 道歉的 uid 必须等于那次拒收回执的 uid（服务端只认同 uid）',
        `道歉=${ap[0]?.params?.action} 拒收=${sentRej.action}`);
    ok(rej.rejected === true, '仍然是 rejected（道歉不改变判决，如实上报）', brief(rej));
    ok(rej.apologized === true, '返回值如实带出 apologized=true', brief(rej));
    ok(rej.sentItem != null && rej.sentItem.startsWith('oak_log'),
        '返回值带上"我上报的是什么"（排障时能直接看出是不是填错）', brief(rej.sentItem));

    // ── 窗口状态：道歉后服务端会恢复同步 ⇒ 我们下一次点击能被认 ──
    const p2 = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 400 });
    const sent2 = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sent2.action, accepted: true });
    const acc2 = await p2;
    ok(acc2.ok === true, '道歉之后下一次点击仍能被 accepted（窗口没被拖死）', brief(acc2));
}

// ─────────────────────────────────────────────────────────────────────
section('⑧ 窗口模型：accepted 才推进（客户端预测），rejected 一个字节都不动');
// ─────────────────────────────────────────────────────────────────────
// ⚠ **本条在 r5 之前是反的**，而且那个"反"是个真 bug：
//   r4 断言"1.16.x 路径一次都没调 acceptClick（模型只被服务端回包驱动）"。
//   但 `ServerGamePacketListenerImpl.java:1182-1185` 在 accepted 路径上把
//   `ignoreSlotUpdateHack` 置位，`broadcastChanges()` 的逐格广播**全被挡掉**
//   ⇒ 服务端**一条槽位更新都不发**。≤1.16 协议的前提就是客户端自己预测。
//   ⇒ 模型不推进，下一击的 `item` 就从陈旧数据出发。
//   实测代价（本单 T09R5B）：2×2 合成 30/30 全 `putback_rejected`。
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('iron_ore', 48);
    const before = win.slots.map((s) => (s ? `${s.name}x${s.count}` : '-')).join('|');

    let acceptCalls = 0;
    const realAccept = win.acceptClick.bind(win);
    win.acceptClick = (a) => { acceptCalls++; return realAccept(a); };

    // ① accepted ⇒ 必须推进模型一次
    const p = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 300 });
    const sent = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sent.action, accepted: true });
    await p;
    ok(acceptCalls === 1, '★★ accepted ⇒ 恰好调一次 acceptClick（客户端预测，协议要求）', `called ${acceptCalls}`);
    const after = win.slots.map((s) => (s ? `${s.name}x${s.count}` : '-')).join('|');
    ok(before !== after, '★★ accepted 之后模型真的动了（否则下一击必然用陈旧数据）');

    // ② rejected ⇒ 模型一个字节都不动（只道歉 + 等服务端重发整窗覆写）
    acceptCalls = 0;
    const snapshot = win.slots.map((s) => (s ? `${s.name}x${s.count}` : '-')).join('|');
    const p2 = clickCarryConfirmed(bot, win, { slot: 10, mouseButton: 0, mode: 0, timeoutMs: 300, resyncTimeoutMs: 200 });
    const sent2 = bot._client.written.at(-1).params;
    bot._client.emit('transaction', { windowId: 0, action: sent2.action, accepted: false });
    const rej = await p2;
    ok(rej.rejected === true, '对照：accepted=false ⇒ rejected', brief(rej));
    ok(acceptCalls === 0, '★★ rejected ⇒ 一次都不调 acceptClick（不许拿错的预测改模型）', `called ${acceptCalls}`);
    ok(win.slots.map((s) => (s ? `${s.name}x${s.count}` : '-')).join('|') === snapshot,
        '★★ rejected ⇒ 窗口模型逐字未变');
}

// ─────────────────────────────────────────────────────────────────────
section('⑨ 熔炉装料：正例 / 反例 / 光标非空 / 区间够不着');
// ─────────────────────────────────────────────────────────────────────
{
    // 正例：矿石在槽 3（坏区间的 27 够不着），shift 一次到位
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();
    win.slots[3] = item('iron_ore', 48);
    win.slots[30] = item('coal', 8);
    const p = quickMoveIntoFurnace(bot, { window: win, id: win.id }, { itemName: 'iron_ore', target: 'input', timeoutMs: 300 });
    // 发包发生在 await 之后的微任务里 ⇒ 必须让一拍再去读"发了什么"
    await tick();
    // 服务端：ack + 整窗广播（槽 0 拿到矿石，槽 3 空掉）
    const sent = bot._client.written.at(-1);
    ok(sent && sent.name === 'window_click', '正例：确实发了一次 window_click', brief(sent?.params, 120));
    // ⚠ 变异测试 M1 会让这一段走到"一个包都没发出去"（区间坏 ⇒ 源格找不到 ⇒ 提前返回）。
    //   所以这里**必须**写成守卫式：否则断言会在"已经红了 7 条"之后崩掉，
    //   把后面的结果一起带走（第一版就是这么写的，见 brief() 的注释）。
    ok(!!sent && sent.params.slot === 3 && sent.params.mode === 1, '点的是槽 3 的 QUICK_MOVE（源在坏区间够不着的那一格）', brief(sent?.params, 120));
    if (!sent) { console.log('     （源格不在任何区间 ⇒ 提前返回，后续正例断言跳过）'); }
    bot._client.emit('transaction', { windowId: win.id, action: sent?.params?.action ?? -1, accepted: true });
    await tick();
    const items = new Array(39).fill(null).map(() => ({ present: false }));
    items[0] = { present: true, itemId: item('iron_ore').type, itemCount: 48 };
    win.slots[3] = null; win.slots[0] = item('iron_ore', 48);
    bot._client.emit('window_items', { windowId: win.id, items });
    const res = await p;
    ok(res.ok === true, '正例：矿石 shift 进输入格判成功', brief(res, 200));
    ok(res.moved === 48, '一次搬 48 个（整摞）', `got ${res.moved}`);
    ok(res.via === 'window_items', '判据来自服务端整窗 window_items', `got ${res.via}`);
    ok(res.src === 3, '源槽是 3（坏区间够不着的那一格）');

    // 反例：物品只在**旧坏区间**覆盖得到的地方也不该失败，但更重要的是够不着时要响亮
    const bot2 = makeFakeBot();
    const w2 = makeFurnaceWindowBroken();
    const p2 = quickMoveIntoFurnace(bot2, { window: w2, id: w2.id }, { itemName: 'gold_ore', target: 'input', timeoutMs: 200 });
    const r2 = await p2;
    ok(r2.ok === false && r2.reason === 'item_not_in_player_range',
        '区间里没有 ⇒ 响亮报 item_not_in_player_range（不再是那句读不出所以然的 INTERNAL）', JSON.stringify(r2));
    ok(r2.range && r2.range[0] === 3, '失败里带区间（判别手：r3 缺的正是这个）', JSON.stringify(r2.range));

    // 光标非空 ⇒ 拒绝（QUICK_MOVE 在光标非空时语义完全不同）
    const bot3 = makeFakeBot();
    const w3 = makeFurnaceWindowBroken();
    w3.slots[3] = item('iron_ore', 48);
    w3.selectedItem = item('furnace', 1);   // 06d 抓到的真凶：光标上残留着刚放下的熔炉
    const r3 = await quickMoveIntoFurnace(bot3, { window: w3, id: w3.id }, { itemName: 'iron_ore', target: 'input', timeoutMs: 100 });
    ok(r3.ok === false && r3.reason === 'cursor_not_empty', '光标非空 ⇒ 拒绝并报出光标上是什么',
        brief(r3, 160));
    ok(String(r3.held).startsWith('furnace'), 'held 字段带出光标内容（r3 丢的正是这个字段）', String(r3.held));

    // 服务端把矿石放进**燃料格** ⇒ 判 landed_in_other_slot（响亮，而不是"装料成功"）
    const bot4 = makeFakeBot();
    const w4 = makeFurnaceWindowBroken();
    w4.slots[3] = item('iron_ore', 48);
    const p4 = quickMoveIntoFurnace(bot4, { window: w4, id: w4.id }, { itemName: 'iron_ore', target: 'input', timeoutMs: 300 });
    await tick();
    const s4 = bot4._client.written.at(-1);
    bot4._client.emit('transaction', { windowId: w4.id, action: s4?.params?.action ?? -1, accepted: true });
    const it4 = new Array(39).fill(null).map(() => ({ present: false }));
    it4[1] = { present: true, itemId: item('iron_ore').type, itemCount: 48 };
    bot4._client.emit('window_items', { windowId: w4.id, items: it4 });
    const r4 = await p4;
    ok(r4.ok === false && r4.reason === 'landed_in_other_slot', '落错格 ⇒ landed_in_other_slot', brief(r4, 160));

    // 目标格被别的物品占着 ⇒ 提前判掉（服务端会静默不动，没有任何错误信号）
    const bot5 = makeFakeBot();
    const w5 = makeFurnaceWindowBroken();
    w5.slots[3] = item('iron_ore', 48);
    w5.slots[0] = item('sand', 3);
    const r5 = await quickMoveIntoFurnace(bot5, { window: w5, id: w5.id }, { itemName: 'iron_ore', target: 'input', timeoutMs: 100 });
    ok(r5.ok === false && r5.reason === 'dest_occupied', '目标格被占 ⇒ dest_occupied（不点，点了也是静默失败）');

    // 不可熔炼物被服务端挪到快捷栏 ⇒ moved_to_hotbar_not_furnace
    // （1.16.1 AbstractFurnaceMenu.quickMoveStack:118-121 的第三条分支）
    const bot6 = makeFakeBot();
    const w6 = makeFurnaceWindowBroken();
    w6.slots[3] = item('dirt', 5);
    const p6 = quickMoveIntoFurnace(bot6, { window: w6, id: w6.id }, { itemName: 'dirt', target: 'input', timeoutMs: 300 });
    await tick();
    const s6 = bot6._client.written.at(-1);
    bot6._client.emit('transaction', { windowId: w6.id, action: s6?.params?.action ?? -1, accepted: true });
    const it6 = new Array(39).fill(null).map(() => ({ present: false }));
    it6[32] = { present: true, itemId: item('dirt').type, itemCount: 5 };
    w6.slots[32] = item('dirt', 5);   // 整窗广播后模型会变成这样
    bot6._client.emit('window_items', { windowId: w6.id, items: it6 });
    const r6 = await p6;
    ok(r6.ok === false && r6.reason === 'moved_to_hotbar_not_furnace',
        '不可熔炼物进熔炉 ⇒ 报"被挪到快捷栏"（1.16.1 就是这个行为，不是被拒）', brief(r6, 160));
    ok(r6.hotbarSlot === 32, '报出具体落在哪一格', `got ${r6.hotbarSlot}`);

    // 目标格已经是同种且够量 ⇒ already_loaded（上层当成功，不重复点）
    const bot7 = makeFakeBot();
    const w7 = makeFurnaceWindowBroken();
    w7.slots[0] = item('coal', 8);
    const r7 = await quickMoveIntoFurnace(bot7, { window: w7, id: w7.id }, { itemName: 'coal', target: 'fuel', wantCount: 5, timeoutMs: 100 });
    ok(r7.ok === false, 'wantCount 已满足时也不重复点（省一次点击）', brief(r7, 120));
}

// ─────────────────────────────────────────────────────────────────────
section('⑩ 服务端真值通道：两条都认，超时如实说超时');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = makeFurnaceWindowBroken();
    // 逐格 set_slot
    const COAL = registry.itemsByName.coal.id;
    let p = waitServerWindowSlots(bot, win, [0, 1], { timeoutMs: 300 });
    bot._client.emit('set_slot', { windowId: win.id, slot: 0, item: { present: true, itemId: COAL, itemCount: 12 } });
    let r = await p;
    ok(r.ok === true && r.via === 'set_slot', '认逐格 set_slot', brief(r, 120));
    ok(r.slots[0] && r.slots[0].name === 'coal' && r.slots[0].count === 12,
        'set_slot 内容过了物品工厂（有 name/count，不是裸 notch）', JSON.stringify(r.slots[0]?.name));
    ok(r.slots[1] === null, '只报请求的格；没收到的那格是 null（不是 undefined）',
        `typeof=${typeof r.slots[1]}`);

    // 整窗 window_items（1.16.1 实际走的就是这条）
    p = waitServerWindowSlots(bot, win, [2], { timeoutMs: 300 });
    const items = new Array(39).fill(null).map(() => ({ present: false }));
    items[2] = { present: true, itemId: 265, itemCount: 3 };
    bot._client.emit('window_items', { windowId: win.id, items });
    r = await p;
    ok(r.ok === true && r.via === 'window_items', '认整窗 window_items');
    ok(r.slotCount === 39, '整窗包顺带给出槽数（区间自证的材料）', `got ${r.slotCount}`);

    // 别的窗口的包不算
    p = waitServerWindowSlots(bot, win, [0], { timeoutMs: 120 });
    bot._client.emit('window_items', { windowId: win.id + 100, items });
    r = await p;
    ok(r.ok === false && r.timedOut === true, '别的窗口的包不被当成本窗口的真值');

    // 超时
    const t0 = Date.now();
    r = await waitServerWindowSlots(bot, win, [0], { timeoutMs: 120 });
    ok(r.ok === false && r.timedOut === true, '等不到就如实判超时（超时不是"服务端说没有"）');
    ok(Date.now() - t0 >= 100, '确实等满了才返回（有界，不是立刻放弃）');
}

/**
 * 确定性驱动器：等"下一条新发出去的 window_click"，把模型改成服务端该有的样子，
 * 再回一个 accepted 的 transaction。
 *
 * ⚠ 两个坑都是本单真踩的，写在这里免得下次重犯：
 *  ① **不能用"比长度"判新包**：`craftInGridConfirmed` 的第一次发包发生在它自己
 *     同步段里（`clickCarryConfirmed` 在第一个 await 之前就 write 了），
 *     所以调用驱动器时第一包**已经写出去了**。⇒ 游标挂在 bot 上，逐条消费。
 *  ② **服务端广播的时机不能靠猜**：`waitServerWindowSlots` 的监听器是在 await 之后
 *     才挂上的，测试侧"发完包就广播"可能早于监听器挂上 ⇒ 结果被丢掉，
 *     用例假红或假绿。⇒ 结果槽这类"必须持续存在"的服务端真值用**定时重复广播**，
 *     让时序无关。
 */
/**
 * 等"下一条新发出去的 window_click"，把模型改成服务端该有的样子，再回一个 accepted 的 transaction。
 * **等不到就返回 null，不抛异常** —— 抛异常会把"被测代码提前收手"（这在变异测试里恰恰是
 * 要观察的现象）变成"测试崩了"，既丢掉后续断言、也让报告里看不出到底哪一步坏的。
 * 调用方用 `ok(cN && …)` 断言，最后再对函数的结构化 reason 断言。
 */
async function nextClick(bot, apply, { accept = true } = {}) {
    if (bot.__consumed == null) bot.__consumed = 0;
    for (let i = 0; i < 120; i++) {
        // ⚠ 必须让**真实时间**过去：服务端真值是 setInterval 泵出来的，
        //   只用 setImmediate 空转（微秒级）的话泵一次都不会触发，
        //   用例会假红成 `no_server_window_truth`（本单真踩过）。
        await new Promise((r) => setTimeout(r, 2));
        if (bot._client.written.length > bot.__consumed) {
            const w = bot._client.written[bot.__consumed++];
            if (apply) apply(w);
            bot._client.emit('transaction', { windowId: w.params.windowId, action: w.params.action, accepted: accept });
            return w;
        }
    }
    return null;
}
/** 起一个"持续广播服务端真值"的泵，返回停止函数（让广播时序与监听器挂上时刻无关） */
function pump(bot, build, ms = 15) {
    const t = setInterval(() => bot._client.emit('window_items', { windowId: 0, items: build() }), ms);
    return () => clearInterval(t);
}
/**
 * 持续广播**某一格**的 `set_slot`。
 * ⚠ 为什么结果格要用这个而不是 `pump`：实跑抓包（`runs/T09R5_DBG4`）证明，window 0 上服务端
 *   在 accepted 路径**只发结果格这一格的 set_slot**（`set_slot(0, 成品)`），
 *   网格格与背包格一个字节都不发 ⇒ 结果格判据走环形缓冲读 set_slot，不等整窗包。
 */
function pumpSlot(bot, slot, build, ms = 15) {
    const t = setInterval(() => bot._client.emit('set_slot', { windowId: 0, slot, item: build() }), ms);
    return () => clearInterval(t);
}
const emptyItems46 = () => new Array(46).fill(null).map(() => ({ present: false }));
/**
 * 造一条**服务端光标包**（1.16.1：windowId=-1 / slot=-1）。
 * ⚠ 这是本单最关键的一条夹具：真服上 mineflayer **把这条包丢掉**
 *   （`inventory.js:738-753`：`window.id !== packet.windowId ⇒ return`），
 *   所以 `win.selectedItem` **恒为 null**，而服务端光标是真的有东西。
 *   第一版夹具让测试自己维护 `win.selectedItem` ⇒ 天然与真服不同构
 *   ⇒ 用例全绿、真服 2×2 全灭（T09R4_IRON trial_01：4 次 cursor_lost_after_pickup
 *   与 4 次 pickup_rejected 严格交替）。**假 bot 与真服同构，是这一条的全部意义。**
 */
const sayCursor = (bot, it) => bot._client.emit('set_slot', {
    windowId: -1, slot: -1,
    item: it ? { present: true, itemId: it.type, itemCount: it.count } : { present: false },
});

// ─────────────────────────────────────────────────────────────────────
section('⑪ 2×2 网格合成：只 shift 点结果格，网格格只 PICKUP');
// ─────────────────────────────────────────────────────────────────────
{
    // 场景：背包 8 个云杉木板（槽 10），做 2×2 的木棍（"#" / "#" ⇒ 4 根）
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('spruce_planks', 8);
    const PL = item('spruce_planks').type;
    const broadcast = (fill) => {
        const items = new Array(46).fill(null).map(() => ({ present: false }));
        for (const [i, it] of Object.entries(fill)) items[i] = { present: true, itemId: it.type, itemCount: it.count };
        bot._client.emit('window_items', { windowId: 0, items });
    };
    const p = craftInGridConfirmed(bot, win, {
        cells: [{ x: 0, y: 0, id: PL }, { x: 1, y: 0, id: PL }], gridW: 2, gridH: 2,
        resultSlot: 0, expectName: 'stick', timeoutMs: 500,
    });

    // ── 先消费 prime() 那一击：右键点一个**空**背包槽、上报"光标是空的" ──
    // 它不改变任何模型（光标仍为空），所以 apply 传 null。
    const probe = await nextClick(bot, null);
    ok(!!probe && probe.params.mouseButton === 1 && probe.params.mode === 0
       && probe.params.slot >= 9 && probe.params.slot < 45
       && probe.params.item && probe.params.item.present === false,
       'prime 探针：右键点空背包槽 + 上报空光标（用 ack 证明起点干净）', brief(probe?.params, 130));
    // 步骤 1：左键整摞拿起槽 10
    const c1 = await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('spruce_planks', 8)); });
    ok(c1 && c1.params && c1.params.slot === 10 && c1 && c1.params && c1.params.mouseButton === 0, '第 1 步：左键拿起源物品（槽 10）', brief((c1 && c1.params), 110));
    ok(c1 && c1.params && c1.params.item.itemCount === 8 && c1 && c1.params && c1.params.item.itemId === PL, '拿起：item = 那一格的东西（id 是数字 / count 8）');

    // 步骤 2：右键把 1 个放进网格格 (0,0) = 槽 1
    const c2 = await nextClick(bot, () => { win.slots[1] = item('spruce_planks', 1); sayCursor(bot, item('spruce_planks', 7)); });
    ok(c2 && c2.params && c2.params.slot === 1 && c2 && c2.params && c2.params.mouseButton === 1, '第 2 步：右键放 1 个进网格格 (0,0)=槽 1', brief((c2 && c2.params), 110));
    ok(c2 && c2.params && c2.params.item && c2.params.item.present === false,
        '★★ 放 1 个进空网格格：item 报**空**（被点格点击前是空的 ⇒ `AbstractContainerMenu:159+256` 返回初值 EMPTY）',
        `got ${brief(c2 && c2.params && c2.params.item)}`);

    // 步骤 3：第二格 (1,0) = 槽 2，同一摞不再拿起
    const c3 = await nextClick(bot, () => { win.slots[2] = item('spruce_planks', 1); sayCursor(bot, item('spruce_planks', 6)); });
    ok(c3 && c3.params && c3.params.slot === 2 && c3 && c3.params && c3.params.mouseButton === 1, '第 3 步：第二格 (1,0)=槽 2（手上已有，不再拿起）', brief((c3 && c3.params), 110));
    ok(c3 && c3.params && c3.params.item && c3.params.item.present === false,
        '★★ 放第二个：同样是空格 ⇒ item 报空', `got ${brief(c3 && c3.params && c3.params.item)}`);

    // 步骤 4：余料放回（放整摞 ⇒ 光标清空）
    const c4 = await nextClick(bot, () => { win.slots[30] = item('spruce_planks', 6); sayCursor(bot, null); });
    ok(c4 && c4.params && c4.params.mouseButton === 0 && c4 && c4.params && c4.params.mode === 0 && c4 && c4.params && c4.params.item.present === false,
        '步骤 4：余料放回背包（item 填空 = 放完整摞后光标清空）', brief((c4 && c4.params), 110));
    ok(c4 && c4.params && c4.params.slot >= 9 && c4 && c4.params && c4.params.slot < 45, '放回目标是背包区 9..45，不是网格格', `slot=${c4 && c4.params && c4.params.slot}`);

    // 服务端算出结果：槽 0 = 4 根木棍（**只发这一格的 set_slot**，与实跑抓包同构）
    win.slots[0] = item('stick', 4);
    const stopPump = pumpSlot(bot, 0, () => ({ present: true, itemId: item('stick').type, itemCount: 4 }));

    // 步骤 5：★ **左键**拿起产物（**不用 shift**）——
    //   QUICK_MOVE 在结果格上不可预测：取走产物会触发配方重算、把新物品放回同一格，
    //   服务端 `clicked()` 的 do-while 循环会再进一轮，返回值变成"最后一轮搬的那摞"。
    //   实跑证据 bench/.../runs/T09R5_DBG5：上报 stick×4、服务端算成别的 ⇒ accepted=false。
    // apply 只负责"服务端那一侧"：确保光标是空的，让 acceptClick 执行"拿起"而不是"交换"。
    // 模型怎么变交给被测代码自己的 acceptClick（夹具手工改会抢在它前面，见步骤 6 的坑）。
    const c5 = await nextClick(bot, () => { win.selectedItem = null; });
    ok(c5 && c5.params && c5.params.slot === 0 && c5 && c5.params && c5.params.mode === 0 && c5.params.mouseButton === 0,
        '取产物：**左键**点结果格（不走 QUICK_MOVE）', brief((c5 && c5.params), 110));
    ok(c5 && c5.params && c5.params.item && c5.params.item.present === true && c5.params.item.itemCount === 4,
        '★ 取产物：PICKUP 的 item = 结果格的点击前内容（4 根木棍）',
        `got ${brief(c5 && c5.params && c5.params.item)}`);

    // 步骤 6：左键把光标上的产物放进一个**空**的背包格 ⇒ item 报空
    // ⚠ apply 传 null：这一步的模型推进由被测代码自己的 `acceptClick` 做（ack accepted 之后），
    //   夹具再手工改模型反而会**抢在 acceptClick 之前**把它清掉（第一版就踩了，
    //   症状是 `result_not_landed {slot:10, got:null}`）。
    const c6 = await nextClick(bot, null);
    stopPump();
    ok(c6 && c6.params && c6.params.slot >= 9 && c6.params.slot < 45 && c6 && c6.params && c6.params.mode === 0 && c6.params.item && c6.params.item.present === false,
        '放下：目标是背包区的空格 ⇒ item 报空', brief((c6 && c6.params), 110));
    ok(!bot._client.written.some((w) => w.params.mode === 1 && w.params.slot >= 1 && w.params.slot <= 4),
        '⚠ 绝不 shift 点网格格 1..4（1.16.1 InventoryMenu.java:126-129 会把材料倒回背包、静默清空配方）');

    const r = await p;
    ok(r.ok === true, '整条 2×2 合成判成功', brief(r, 200));
    ok(r.gained === 4 && r.took === 4, '拿到 4 根木棍（服务端真值确认过结果格）', `gained=${r.gained} took=${r.took}`);
    ok(r.viaPickup === true, '取件走的是两次 PICKUP（不是 shift）', `viaPickup=${r.viaPickup}`);
}

// ─────────────────────────────────────────────────────────────────────
section('⑫ 2×2 的失败形态都要有结构化 reason（不许"差不多就行"）');
// ─────────────────────────────────────────────────────────────────────
{
    // ① 材料不在背包里
    {
        const bot = makeFakeBot();
        const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
        win.slots = new Array(46).fill(null);
        // ⚠ 顺序：`craftInGridConfirmed` 必须**先启动**，prime() 的探针才会发出去，
        //   驱动器才吃得到它。先 `nextClick` 再调用的话那一刻探针还没发（r4 遗留的 5 条红就是这个）。
        const p1 = craftInGridConfirmed(bot, win, { cells: [{ x: 0, y: 0, id: item('spruce_planks').type }], gridW: 2, gridH: 2, timeoutMs: 150 });
        await nextClick(bot, null);   // prime 探针（不改模型）
        const r = await p1;
        ok(r.ok === false && r.reason === 'missing_ingredient', '没材料 ⇒ missing_ingredient（带 id + 区间）', brief(r, 150));
    }
    // ② 网格摆好了但服务端不认（配方不匹配）⇒ 结果格空 ⇒ no_result，且把网格内容一起报出来
    {
        const bot = makeFakeBot();
        const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
        win.slots = new Array(46).fill(null);
        win.slots[10] = item('spruce_planks', 4);
        const p = craftInGridConfirmed(bot, win, {
            cells: [{ x: 0, y: 0, id: item('spruce_planks').type }], gridW: 2, gridH: 2, expectName: 'stick', timeoutMs: 300,
        });
        // ── 先消费 prime() 那一击：右键点一个**空**背包槽、上报"光标是空的" ──
        // 它不改变任何模型（光标仍为空），所以 apply 传 null。
        // ⚠ r4 遗留：这里曾被复制粘贴成**两段**、且第二段引用了块外的 `probe`（未定义），
        //   于是断言拿错变量、用例假红。**只保留一段**。
        const probe2 = await nextClick(bot, null);
        ok(!!probe2 && probe2.params.mouseButton === 1 && probe2.params.mode === 0
           && probe2.params.slot >= 9 && probe2.params.slot < 45
           && probe2.params.item && probe2.params.item.present === false,
           'prime 探针：右键点空背包槽 + 上报空（用 ack 证明起点干净）', brief(probe2?.params, 130));
        await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('spruce_planks', 4)); });
        await nextClick(bot, () => { win.slots[1] = item('spruce_planks', 1); sayCursor(bot, item('spruce_planks', 3)); });
        await nextClick(bot, () => { win.slots[9] = item('spruce_planks', 3); sayCursor(bot, null); });
        // 结果格**恒空**（配方不匹配）—— 用泵持续广播
        const stop = pump(bot, emptyItems46);
        const r = await p;
        stop();
        ok(r.ok === false, '服务端没给货 ⇒ 如实判失败', brief(r, 150));
        ok(r.reason === 'no_result' || r.reason === 'no_server_window_truth', '失败 reason 是结构化的', `got ${r.reason}`);
        ok(r.reason !== 'no_result' || typeof r.grid === 'string',
            'no_result 会把网格内容一起报出来（能看出料摆对没有）', brief(r, 150));
    }
    // ③ 取产物被服务端拒收 ⇒ take_rejected，不假装成功
    {
        const bot = makeFakeBot();
        const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
        win.slots = new Array(46).fill(null);
        win.slots[10] = item('spruce_planks', 4);
        const p = craftInGridConfirmed(bot, win, {
            cells: [{ x: 0, y: 0, id: item('spruce_planks').type }], gridW: 2, gridH: 2, expectName: 'spruce_planks', timeoutMs: 300,
        });
        // ⚠ 必须先吃掉 prime() 的探针，否则后面每一次 nextClick 都错位一格
        //   （r4 遗留：这里漏了探针，导致"取产物那一下"拿到的是放回那一下）
        await nextClick(bot, null);
        await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('spruce_planks', 4)); });
        await nextClick(bot, () => { win.slots[1] = item('spruce_planks', 1); sayCursor(bot, item('spruce_planks', 3)); });
        await nextClick(bot, () => { win.slots[9] = item('spruce_planks', 3); sayCursor(bot, null); });
        win.slots[0] = item('spruce_planks', 1);
        // 结果格只发 set_slot（与实跑抓包同构）
        const stop = pumpSlot(bot, 0, () => ({ present: true, itemId: item('spruce_planks').type, itemCount: 1 }));
        // 下一次点击（取产物）被服务端拒收
        const c = await nextClick(bot, null, { accept: false });
        stop();
        ok(!!c && c.params.slot === 0 && c.params.mode === 0, '取产物那一下确实是左键点结果格', brief(c?.params, 110));
        const r = await p;
        ok(r.ok === false && r.reason === 'take_rejected', '产物取件被拒 ⇒ take_rejected（不报"成功"）', brief(r, 170));
    }
}

// ─────────────────────────────────────────────────────────────────────
section('⑬ 网格几何闸门：放不下必须返 null（不能少放凑合）');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);

    // 2×2 放料
    // ⚠ 同 ⑫①：必须先启动 `craftInGridConfirmed`，prime() 的探针才会发出去、驱动器才吃得到
    const p2 = craftInGridConfirmed(bot, win, { cells: [{ x: 0, y: 0, id: 1 }], gridW: 2, gridH: 2, timeoutMs: 100 });
    await nextClick(bot, null);   // prime 探针（不改模型）
    const r2 = await p2;
    ok(r2.ok === false && r2.reason === 'missing_ingredient', '2×2 能放但没料 ⇒ missing_ingredient（不是 no_result）', brief(r2, 150));

    // 3×3 配方硬塞进 2×2：这里只验"几何闸门"这个纯函数（_gridCells 在 crafting_task 里）
    const { CraftingTask } = await import('./crafting_task.js');
    const t = new CraftingTask({ item: 'iron_pickaxe' });
    const big = { inShape: [[1, 1, 1], [null, 2, null], [null, 2, null]] };
    ok(t._gridCells(big, 2, 2) === null, '3×3 配方进 2×2 ⇒ null（要工作台）');
    ok(t._gridCells(big, 3, 3) !== null, '同一配方进 3×3 ⇒ 正常摊平');
    const shapeless3 = { ingredients: [1, 2, 3] };
    const c3s = t._gridCells(shapeless3, 2, 2);
    ok(c3s !== null && c3s.length === 3, '3 原料 shapeless 放得进 2×2（4 格）⇒ 摊平 3 格', JSON.stringify(c3s));
    ok(t._gridCells({ ingredients: [1, 2, 3, 4, 5] }, 2, 2) === null, '5 原料 shapeless 放不进 2×2 ⇒ null');
}
// ─────────────────────────────────────────────────────────────────────
section('⑭ _gridCells 的真实判定（订正上一条的措辞）');
// ─────────────────────────────────────────────────────────────────────
{
    const { CraftingTask } = await import('./crafting_task.js');
    const t = new CraftingTask({ item: 'x' });
    // 2×2 shapeless：木板→工作台（1.16.1 RecipeProvider.java:656 的 "##"/"##"）
    const table = { inShape: [[1, 1], [1, 1]] };
    const c = t._gridCells(table, 2, 2);
    ok(c && c.length === 4, '木板→工作台（2×2）4 格全摊平', JSON.stringify(c));
    // 木棍：1.16.1 是 "#"/"#" = 2×1，2×2 放得下
    const stick = { inShape: [[1], [1]] };
    ok(t._gridCells(stick, 2, 2).length === 2, '木板→木棍（2×1）2 格，2×2 装得下');
    // 原木→木板：shapeless 1 原料
    const planks = { ingredients: [1] };
    ok(t._gridCells(planks, 2, 2).length === 1, '原木→木板（1 原料）1 格');
    // 3×3：熔炉 "###"/"# #"/"###"
    const furnace = { inShape: [[1, 1, 1], [1, null, 1], [1, 1, 1]] };
    ok(t._gridCells(furnace, 2, 2) === null, '熔炉（3×3）⇒ 2×2 返 null');
    ok(t._gridCells(furnace, 3, 3).length === 8, '熔炉 8 格在 3×3 摊平');
    // 空洞不能被当成物品
    const withHole = { inShape: [[1, null, 1], [1, 1, 1], [1, 1, 1]] };
    ok(t._gridCells(withHole, 3, 3).every((c2) => c2.id != null && c2.id !== -1), 'null 格不进 cells');
    // id=0 是真物品 id，不能被当成"空"
    const zeroId = { inShape: [[0]] };
    ok(t._gridCells(zeroId, 2, 2).length === 1, 'id=0 是合法物品 id（不是空）');
    // 没有任何形状信息 ⇒ null（不能当成"空配方"）
    ok(t._gridCells({}, 2, 2) === null, '既无 inShape 又无 ingredients ⇒ null');
}

// ─────────────────────────────────────────────────────────────────────
section('⑮ 假 bot 与真库的字段对齐自检（G 线纪律）');
// ─────────────────────────────────────────────────────────────────────
{
    const bot = makeFakeBot();
    // 真 bot 上这几个是存在的
    for (const k of ['_client', 'registry', 'version', 'supportFeature']) {
        ok(k in bot, `假 bot 有真库确实有的字段 ${k}`);
    }
    // 刻意不补的（补了就是"假 bot 比真库宽"）
    ok(!('windowSlotsRange' in bot), '假 bot 没补真库没有的字段（避免盖掉真 bug）');
    ok(!('currentWindow' in bot), '假 bot 没偷塞 currentWindow');

    // 版本口径：1.16.x 与 1.17+ 走的是不同信封
    const b16 = makeFakeBot();
    const f16 = clickFlavor(b16);
    ok(f16.actionIdUsed === true && f16.transactionPacketExists === true && f16.stateIdUsed === false,
        '1.16.1 口径：actionId + transaction，无 stateId', JSON.stringify(f16));
    const b17 = makeFakeBot({ version: '1.17.1' });
    b17.supportFeature = (f) => (f === 'stateIdUsed');
    const f17 = clickFlavor(b17);
    ok(f17.stateIdUsed === true, '1.17+ 口径：stateId');
    const pkt17 = windowClickPacket(b17, f17, { windowId: 1, slot: 2, mouseButton: 0, mode: 0, changedSlots: [], item: null, cursorItem: null });
    ok(pkt17.params.stateId === 0 && pkt17.params.cursorItem && pkt17.params.cursorItem.present === false,
        '1.17+ 信封带 stateId + cursorItem', brief(pkt17.params, 140));
}

// ─────────────────────────────────────────────────────────────────────
section('⑯ 光标模型：服务端真值与预测不一致时必须被发现（不许悄悄采信预测）');
// ─────────────────────────────────────────────────────────────────────
// 为什么补这一组（r5 的变异测试发现的**真覆盖缺口**，不是锚点漂移）：
//   变异 9「光标不跟服务端包刷新」在 r4 记为"锚点找不到"，改好锚点后它仍然
//   **0 条断言变红** —— 因为夹具里服务端发的光标包**永远和预测一致**，
//   于是"读真值"和"不读真值"走同一条分支、行为完全等价。
//   ⇒ 只有补一条"**真值与预测不一致**"的用例，这条保护才真的存在。
{
    const bot = makeFakeBot();
    const win = windowsFactory.createWindow(0, 'minecraft:inventory', 'Inventory');
    win.slots = new Array(46).fill(null);
    win.slots[10] = item('oak_log', 6);

    const cur = await makeCursorTracker(bot, win, { timeoutMs: 300 });
    // prime：右键点空槽、上报空光标（先启动再消费，探针才发得出去）
    const pPrime = cur.prime();
    await nextClick(bot, null);
    const pr = await pPrime;
    ok(pr.ok === true, 'prime 通过（起点光标被 ack 确认为空）', brief(pr, 140));
    ok(cur.empty === true, 'prime 后模型认为光标是空的', `got ${brief(cur.item)}`);

    // 正例①：拿起 6 个原木，服务端光标**与预测一致** ⇒ 不算 mismatch
    const p1 = cur.click(10, 0, 0, item('oak_log', 6));
    await nextClick(bot, () => { win.slots[10] = null; sayCursor(bot, item('oak_log', 6)); });
    await p1;
    ok(cur.mismatches === 0, '一致时不计 mismatch（阳性对照）', `mismatches=${cur.mismatches}`);
    ok(cur.item && cur.item.count === 6, '光标模型 = 6 个原木', brief(cur.item));

    // ★ 反例：再点一次，预测"放 1 个后剩 5"，**服务端真值却是 3** ⇒ 必须被发现
    const p2 = cur.click(1, 1, 0, item('oak_log', 5));
    await nextClick(bot, () => { win.slots[1] = item('oak_log', 1); sayCursor(bot, item('oak_log', 3)); });
    await p2;
    ok(cur.mismatches === 1,
        '★★ 预测(5)与服务端真值(3)不一致时必须被抓住并如实累加', `mismatches=${cur.mismatches}`);
    ok(cur.item && cur.item.count === 3,
        '★★ 不一致时**以服务端真值为准**（3），不采信自己的预测（5）', brief(cur.item));

    // QUICK_MOVE 不碰光标 ⇒ 服务端光标仍是 3 ⇒ 预测 = 原值 ⇒ 不算 mismatch
    const before3 = cur.mismatches;
    const p3 = cur.click(30, 0, 1, null);
    await nextClick(bot, () => { win.slots[30] = null; sayCursor(bot, item('oak_log', 3)); });
    await p3;
    ok(cur.mismatches === before3, 'QUICK_MOVE 不改光标 ⇒ 不产生 mismatch', `mismatches=${cur.mismatches}`);
    cur.stop();
}

// ─────────────────────────────────────────────────────────────────────
section('⑰ predictClickedReturn 的纯函数口径（不依赖任何 bot）');
// ─────────────────────────────────────────────────────────────────────
{
    const w = { slots: new Array(46).fill(null) };
    w.slots[10] = item('oak_log', 6);
    ok(predictClickedReturn(w, { slot: 10, mode: 0 }) === w.slots[10], 'PICKUP 非空 ⇒ 返回那一格的对象');
    ok(predictClickedReturn(w, { slot: 20, mode: 0 }) === null, 'PICKUP 空 ⇒ 返回 null（= EMPTY）');
    ok(predictClickedReturn(w, { slot: -999, mode: 0 }) === null, 'THROW(slot<0) ⇒ null');
    ok(predictClickedReturn(w, { slot: 99, mode: 0 }) === null, '越界槽 ⇒ null（不抛）');
    ok(predictClickedReturn(w, { slot: 10, mode: 1 }) === w.slots[10], 'QUICK_MOVE ⇒ 返回被移动那摞');
    ok(predictClickedReturn(w, { slot: 10, mode: 1, expectMove: false }) === null, 'expectMove:false ⇒ null');
}

console.log(`\n${'='.repeat(60)}`);
console.log(`window_ops_selftest: ${pass} 通过 / ${fail} 失败（共 ${pass + fail}）`);
console.log('='.repeat(60));
process.exit(fail === 0 ? 0 : 1);
