// _mutation_r4.mjs — MC-M1-TASK-09-r4 的**变异测试**
//
// 离���自检 105/105 只说明"当前代码没把断言弄红"。它**不能**说明"这些断言抓得住 bug" ——
// 本项目反复吃过这个亏（B 线 r16 的夹具区分不出"≥1 格"和"≥2 格"，于是一条既有用例在
// 修复前也全绿；D 线的假 bot 补了真库没有的字段，把真 bug 盖成了绿灯）。
//
// 做法：逐个"把修复改回修复前的样子 / 改成一个等价但错的写法" → 必须有断言变红 → 还原。
// ⚠ **每一步都在 finally 里还原文件**，且还原失败要报错退出（半还原的仓库比没跑还糟）。
// ⚠ 故意**不**用"删掉闸门"做变异：window_ops 删掉闸门会直接放真服上的点击跑飞。
//
// 跑法：node _mutation_r4.mjs      （退出码 0 = 全部变异都被抓住）

import { readFileSync, writeFileSync } from 'fs';
import { createHash } from 'crypto';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { execFileSync } from 'child_process';

const HERE = dirname(fileURLToPath(import.meta.url));
const WINDOW_OPS = join(HERE, 'window_ops.js');
const CRAFTING = join(HERE, 'crafting_task.js');

const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');

let pass = 0, fail = 0;
const ok = (cond, name, extra = '') => {
    if (cond) { pass++; console.log(`  ✅ ${name}`); }
    else { fail++; console.log(`  ❌ ${name}${extra ? '  → ' + extra : ''}`); }
};

function runSelftest() {
    try {
        const out = execFileSync(process.execPath, [join(HERE, 'window_ops_selftest.mjs')], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
        return { code: 0, out };
    } catch (e) {
        return { code: e.status ?? -1, out: `${e.stdout ?? ''}${e.stderr ?? ''}` };
    }
}

function countPass(out) {
    const m = out.match(/(\d+) 通过 \/ (\d+) 失败/);
    return m ? { pass: +m[1], fail: +m[2] } : { pass: -1, fail: -1 };
}

/**
 * 变异：改文件 → 跑自检 → 还原，返回自检结果。
 *
 * ⚠⚠ **还原必须逐字节校验**（本单真踩过）：第一版这个函数只在 finally 里
 *   `writeFileSync(file, orig)`，看起来是"一定还原了"。结果某一轮之后
 *   `crafting_task.js` 的几何闸门**整条消失**、自检从 105 掉到 103，
 *   而脚本自己一路报"还原核验通过"——因为它**只检查了几个 marker 字符串**，
 *   没检查文件本身。
 *   ⇒ 还原后比对 sha256，不一致就**立刻退出码 2**，不许继续跑后面的变异
 *   （带着被污染的源码继续变异，测出来的东西全部无意义）。
 *   这是手册 §5「扫描或核验工具读出全零时先证伪工具」的离线版本：
 *   **校验器自己必须先证明自己没坏。**
 */
function mutate(label, file, from, to) {
    const orig = readFileSync(file, 'utf8');
    const shaBefore = sha(file);
    if (!orig.includes(from)) {
        return { label, error: `锚点找不到（源码已经变了？）：${from.slice(0, 60)}` };
    }
    try {
        writeFileSync(file, orig.replace(from, to), 'utf8');
        const r = runSelftest();
        return { label, ...r, ...countPass(r.out) };
    } finally {
        writeFileSync(file, orig, 'utf8');
        const shaAfter = sha(file);
        if (shaAfter !== shaBefore) {
            console.error(`\n🚨🚨 还原失败：${label}`);
            console.error(`   ${file}`);
            console.error(`   变异前 sha256 ${shaBefore}`);
            console.error(`   还原后 sha256 ${shaAfter}`);
            console.error('   已带着被污染的源码退出，后续变异一律无意义。请用 git 恢复该文件。\n');
            process.exit(2);
        }
    }
}

console.log('── 基线（未变异）必须全绿 ──');
const shaBeforeAll = { windowOps: sha(WINDOW_OPS), crafting: sha(CRAFTING) };
{
    const r = runSelftest();
    const c = countPass(r.out);
    ok(r.code === 0 && c.fail === 0, `变异前自检全绿（${c.pass} 通过 / ${c.fail} 失败）`, `exit=${r.code} ${c.fail} 失败`);
}

console.log('\n── 变异 1：playerInvRange 改回读 win.inventoryStart/End（= r3 的坏区间）──');
{
    // 原版规则"槽数−36" → 改回 mineflayer 的 inventoryStart/End
    const r = mutate('playerInvRange 退回坏区间', WINDOW_OPS,
        '    const start = n - 36;\n    return { start, end: n, hotbarStart: start + 27, via: slotCountSource(bot, win) };',
        '    const start = win.inventoryStart;\n    const end = win.inventoryEnd;\n    return { start, end, hotbarStart: end - 9, via: slotCountSource(bot, win) };');
    if (r.error) { ok(false, r.label, r.error); }
    else {
        // 崩溃退出**也算**抓住（变异让代码走进 null 解引用，本身就是缺陷）
        const caught = r.fail > 0 || r.code !== 0;
        ok(caught, `抓住：退回坏区间后 ${r.code !== 0 ? '自检崩溃退出' : `有 ${r.fail} 条断言变红`}`,
            caught ? '' : `仍然 ${r.pass} 全绿 —— 断言抓不住这条`);
        ok(r.fail >= 3, `并且是"多条断言变红"而不是偶然一条（实得 ${r.fail} 条）`, `实得 ${r.fail} 条`);
    }
}

console.log('\n── 变异 2：item 退回"光标"（= r3/r4 的错填，本单实跑炸的那一条）──');
{
    // r5：`item` 已由 `predictClickedReturn` 统一算（= 被点格点击前内容）。
    // 变异把它退回**光标** —— 正是 r3/r4 的写法，也正是 T09R4C_PROBE `place_rejected` 的成因。
    const r = mutate('item 退回光标', WINDOW_OPS,
        '    return win.slots[slot] ?? null;                          // 空格 ⇒ null（即 EMPTY）',
        '    return win.selectedItem ?? null;                         // ← 变异：退回光标（r3/r4 的错填）');
    if (r.error) { ok(false, r.label, r.error); }
    else {
        ok(r.fail > 0, `抓住：item 填成光标后有 ${r.fail} 条断言变红`, r.fail > 0 ? '' : `仍然 ${r.pass} 全绿 —— 断言抓不住这条`);
    }
}

console.log('\n── 变异 3：取产物从 QUICK_MOVE 改回 PICKUP（会经过光标）──');
{
    const r = mutate('取产物退回 pickup', WINDOW_OPS,
        '    const tv = await clickCarryConfirmed(bot, win, { slot: resultSlot, mouseButton: 0, mode: 1, expectMove: true, timeoutMs });',
        '    const tv = await clickCarryConfirmed(bot, win, { slot: resultSlot, mouseButton: 0, mode: 0, expectMove: true, timeoutMs });');
    if (r.error) { ok(false, r.label, r.error); }
    else {
        ok(r.fail > 0, `抓住：取件方式改回 pickup 后有 ${r.fail} 条断言变红`, r.fail > 0 ? '' : `仍然 ${r.pass} 全绿 —— 断言抓不住这条`);
    }
}

console.log('\n── 变异 4：网格尺寸闸门整条去掉（少放几个格子凑合）──');
{
    // ⚠ 第一版这个变异**只**关掉了 `inShape.length > gridH` 一条，而
    //   `inShape[y].length > gridW` 那条还在 ⇒ 自检仍然 105 全绿。
    //   也就是说"只坏一半的闸门"测不出来（两条闸门互为冗余）。
    //   ⇒ 变异必须把**整条几何闸门**拿掉，否则这条用例是假的安全感。
    const r = mutate('_gridCells 去掉尺寸闸门', CRAFTING,
        '            if (recipe.inShape.length > gridH) return null;\n            for (let y = 0; y < recipe.inShape.length; y++) {\n                if (recipe.inShape[y].length > gridW) return null;',
        '            for (let y = 0; y < recipe.inShape.length; y++) {');
    if (r.error) { ok(false, r.label, r.error); }
    else {
        ok(r.fail > 0, `抓住：整条几何闸门去掉后有 ${r.fail} 条断言变红`, r.fail > 0 ? '' : `仍然 ${r.pass} 全绿 —— 断言抓不住这条`);
    }
}

console.log('\n── 变异 5：itemWithCount 去掉 new（类当函数调用）──');
{
    const r = mutate('itemWithCount 去掉 new', WINDOW_OPS,
        '    return new Factory(it.type, count, it.metadata ?? 0, it.nbt);',
        '    return Factory(it.type, count, it.metadata ?? 0, it.nbt);');
    if (r.error) { ok(false, r.label, r.error); }
    else {
        // 这个变异会让自检直接抛异常退出（非 0）也算"抓住"
        const caught = r.fail > 0 || r.code !== 0;
        ok(caught, `抓住：去掉 new 后自检${r.code !== 0 ? '崩溃退出' : `有 ${r.fail} 条变红`}`, caught ? '' : `仍然 ${r.pass} 全绿`);
    }
}

console.log('\n── 变异 6：waitServerWindowSlots 预置回 undefined（把"未知"折算成"空"）──');
{
    const r = mutate('未知折算成空', WINDOW_OPS,
        '    const out = {};\n    for (const s of want) out[s] = null;',
        '    const out = {};');
    if (r.error) { ok(false, r.label, r.error); }
    else {
        ok(r.fail > 0, `抓住：未预置 null 后有 ${r.fail} 条断言变红`, r.fail > 0 ? '' : `仍然 ${r.pass} 全绿 —— 断言抓不住这条`);
    }
}

console.log('\n── 变异 7：熔炉装料不校验落点（不看服务端 0/1 两格就报成功）──');
{
    const r = mutate('装料不校验落点', WINDOW_OPS,
        '    if (!dest) {',
        '    if (false) {');
    if (r.error) { ok(false, r.label, r.error); }
    else {
        const caught = r.fail > 0 || r.code !== 0;
        ok(caught, `抓住：不校验落点后自检${r.code !== 0 ? '崩溃退出' : `有 ${r.fail} 条变红`}`, caught ? '' : `仍然 ${r.pass} 全绿`);
    }
}

console.log('\n── 变异 8：光标退回 win.selectedItem（本单实跑真炸的那一条）──');
{
    // 这一条是**唯一一条"离线全绿、真服全灭"**的变异：
    // 1.16.1 上 mineflayer 丢掉服务端光标包（inventory.js:738-753），
    // 而自研直发包不经过 confirmTransaction.onAccepted（inventory.js:492-502 直接 return）
    // ⇒ win.selectedItem 恒 null。第一次拿真实回归（T09R4_IRON trial_01）才暴露：
    // 4 次 cursor_lost_after_pickup 与 4 次 pickup_rejected 严格交替。
    // 第一版夹具让测试自己维护 selectedItem ⇒ 这条变异抓不住 ⇒ 用例是假绿。
    // 现在夹具发的是**服务端 set_slot(-1,-1) 光标包**，与真服同构。
    const r = mutate('光标退回 selectedItem', WINDOW_OPS,
        "            if (!cur.item || cur.item.type !== id) {\n                const src = findTypeInRange(win, range, id);",
        "            if (!win.selectedItem || win.selectedItem.type !== id) {\n                const src = findTypeInRange(win, range, id);");
    if (r.error) { ok(false, r.label, r.error); }
    else {
        const caught = r.fail > 0 || r.code !== 0;
        ok(caught, `抓住：退回 selectedItem 后自检${r.code !== 0 ? '崩溃退出' : `有 ${r.fail} 条断言变红`}`, caught ? '' : `仍然 ${r.pass} 全绿 —— 这条用例抓不住真炸的那条`);
        ok(r.fail >= 2, `并且是"多条断言变红"（实得 ${r.fail} 条）`, `实得 ${r.fail} 条`);
    }
}

console.log('\n── 变异 9：光标不跟服务端包刷新（每点一次不读真值）──');
{
    const r = mutate('光标不读服务端包', WINDOW_OPS,
        '            const t = await readTruth(140);',
        '            const t = { ok: false };');
    if (r.error) { ok(false, r.label, r.error); }
    else {
        const caught = r.fail > 0 || r.code !== 0;
        ok(caught, `抓住：不读服务端光标真值后自检${r.code !== 0 ? '崩溃退出' : `有 ${r.fail} 条变红`}`, caught ? '' : `仍然 ${r.pass} 全绿`);
    }
}

console.log('\n── 变异 10（r5 新增）：PICKUP 时把"空格"也当成有内容（`?? null` → `|| 预测`）──');
{
    // 钉住本单最贵的那条：右键把 1 个放进**空的** 2×2 格时，`item` 必须是空。
    // 去掉空格判断 ⇒ 空格子会拿别的值去填 ⇒ 必被服务端拒收（r4 实跑 place_rejected）。
    const r = mutate('空格不再报空', WINDOW_OPS,
        "    if (mode === 1 && !expectMove) return null;              // 明知搬不动 ⇒ EMPTY\n    return win.slots[slot] ?? null;                          // 空格 ⇒ null（即 EMPTY）",
        "    if (mode === 1 && !expectMove) return null;\n    return win.slots[slot] || win.selectedItem || null;     // ← 变异：空格不再报空");
    if (r.error) { ok(false, r.label, r.error); }
    else {
        ok(r.fail > 0, `抓住：空格不再报空后有 ${r.fail} 条断言变红`, r.fail > 0 ? '' : `仍然 ${r.pass} 全绿 —— 断言抓不住这条`);
        ok(r.fail >= 2, `并且是"多条断言变红"（实得 ${r.fail} 条）`, `实得 ${r.fail} 条`);
    }
}

console.log('\n── 变异 11（r5 新增）：被拒之后不道歉（窗口从此静默吞点击）──');
{
    // `ServerGamePacketListenerImpl:1189` 一次拒收就 setSynched(false)，
    // `:1169` 的闸门此后静默吞掉本窗口所有点击；只有客户端回 transaction 才能恢复。
    // 去掉道歉 ⇒ 后面每一次点击都收不到 ack（真服上表现为 no_server_window_truth 满天飞）。
    const r = mutate('被拒不道歉', WINDOW_OPS,
        "        bot._client.write('transaction', { windowId: win.id, action: uid, accepted: true });\n        apologized = true;",
        '        apologized = true;');
    if (r.error) { ok(false, r.label, r.error); }
    else {
        ok(r.fail > 0, `抓住：不道歉后有 ${r.fail} 条断言变红`, r.fail > 0 ? '' : `仍然 ${r.pass} 全绿 —— 断言抓不住这条`);
    }
}

console.log('\n── 还原核验：文件必须与变异前逐字相同 ──');
{
    // 每个 mutate() 内部已经做过 sha256 比对（不一致直接 exit 2）。
    // 这里再从"跑变异之前"记的哈希独立复核一次，并要求自检仍然全绿。
    ok(sha(WINDOW_OPS) === shaBeforeAll.windowOps, 'window_ops.js 逐字节等于跑变异前', `${sha(WINDOW_OPS).slice(0, 12)} vs ${shaBeforeAll.windowOps.slice(0, 12)}`);
    ok(sha(CRAFTING) === shaBeforeAll.crafting, 'crafting_task.js 逐字节等于跑变异前', `${sha(CRAFTING).slice(0, 12)} vs ${shaBeforeAll.crafting.slice(0, 12)}`);
    const r = runSelftest();
    const c = countPass(r.out);
    ok(r.code === 0 && c.fail === 0, `全部变异还原后自检仍全绿（${c.pass} 通过）`, `exit=${r.code} ${c.fail} 失败`);
    // 并且源码里不该残留任何变异痕迹
    const src = readFileSync(WINDOW_OPS, 'utf8') + readFileSync(CRAFTING, 'utf8');
    ok(!src.includes('← 变异：退回 mineflayer 的错填'), '源码里没有残留的变异标记');
    ok(!src.includes('if (false) return null;'), '源码里没有残留的 if (false) return null');
    ok(!src.includes('if (false) {'), '源码里没有残留的 if (false) {');
    // 最要紧的一条：几何闸门必须还在（它就是被本脚本的旧版本弄丢过的东西）
    ok(readFileSync(CRAFTING, 'utf8').includes('if (recipe.inShape.length > gridH) return null;'),
        '几何闸门 `inShape.length > gridH` 仍在（曾被本脚本的旧版还原逻辑弄丢）');
    ok(readFileSync(CRAFTING, 'utf8').includes('if (recipe.inShape[y].length > gridW) return null;'),
        '几何闸门 `inShape[y].length > gridW` 仍在');
}

console.log(`\n${'='.repeat(60)}`);
console.log(`_mutation_r4: ${pass} 通过 / ${fail} 失败（共 ${pass + fail}）`);
console.log('='.repeat(60));
process.exit(fail === 0 ? 0 : 1);
