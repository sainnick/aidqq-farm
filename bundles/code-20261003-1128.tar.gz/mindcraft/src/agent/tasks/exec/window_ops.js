// window_ops.js — MC-M1-TASK-09：窗口操作「每一步等服务端确认」
//
// 本文件要治的病（ROUND3-A 报告 §9.1，三个症状一个根因）：
//   ① 工作台 3×3 合成偶发拿不到成品、不抛错、材料没少（1.16.1 上 wooden_pickaxe 24/30）；
//   ② 熔炉取产物后产物「下落不明」，`smelt_ok` 恒为 0；
//   ③ 2×2 背包合成 `Server rejected transaction for clicking on slot 0`（M4B4 回归 24 次）。
//
// 根因不是配方、不是材料、也不是「背包同步慢」，而是**窗口模型被客户端单方面改写、
// 后续点击却按被改写后的模型发包**。三处都落在 mineflayer 4.38 的复合动作上：
//   - craft.js `grabResult()`：先 `window.updateSlot(0, new Item(result))` **凭空造出产物槽**，
//     再 `await bot.putAway(0)`。这一行 updateSlot 是**直接写模型**（不是服务端回包），
//     于是随后那次点击携带的 `item` 字段是伪造值；服务端自己的结果槽若是空的/不同的，
//     就会拒收或不按客户端预期生效，而客户端已经把模型改了 ⇒ 两边永久分叉。
//   - furnace.js `takeOutput()` = `putAway(2)`，同样是「点一下 + putSelectedItemRange + 等回包」
//     的复合动作，中途任何一环被服务端拒绝，客户端模型都已经改过了。
//   - 2×2 通道走 window 0，光标/产物槽状态更容易与实际不符，于是被服务端明确拒绝（这个是
//     **响亮**地失败：transaction accepted=false ⇒ clickWindow 抛异常）。
//
// 本文件的口径（**每一步等服务端确认**）：
//   - 绝不主动写窗口模型（不调 `window.updateSlot`），模型只允许被服务端回包驱动；
//   - 每次点击都拿到**服务端对这一次点击的判决**才继续：
//       · 1.16.x：有 `transaction{windowId,action,accepted}` —— 判决按 **action 号**对齐，
//         等我们**自己发出去的那个 action** 的回执，不接受任何"客户端自说自话的通过"；
//       · 任何版本 / `requiresConfirmation=false` 的窗口（1.16.1 的箱子就是这种，见下）：
//         退化为「等**服务端** `set_slot` 覆盖到被点的那一格」，等不到就判 unverified（不猜）。
//   - 光标（carried item）的真值从**原始 `set_slot` 包 slot=-1** 读，不读 `win.selectedItem`
//     （1.16.1 上 mineflayer 不会用服务端包的 slot=-1 去更新 selectedItem，见 `readCursorTruth`）。
//
// ── 两条 1.16.1 的实测事实（本单离线核实，证据见 docs/MC-M1-TASK-09.md §2）──
//  (A) **`slot` 类型的 `{present,…}` 容器不是 1.16 专属**：minecraft-data 的 `types.slot` 在
//      1.16 / 1.16.1 / 1.16.2 / 1.17 / 1.17.1 / 1.18.2 上**逐字相同**，而
//      `prismarine-item@1.18` 的 `toNotch()` 本来就返回 `{present:false}` /
//      `{present:true,itemId,itemCount}` —— 即**它对所有版本都是对的**。
//      ⇒ ROUND3-A §3.2.7「1.16.1 的 window_click 里 Slot 是 {present,…}，1.17+ 才是裸 NBT，
//        toNotch() 的形状对不上」这个归因**不成立**；`SizeOf error … reading 'present'` 那个
//        报错只是**症状落在最后一个被读的字段上**，不是形状问题（见下）。
//  (B) 真正随版本变的是**包封（envelope）**，不是 Slot：
//        1.16.1 `window_click` = {windowId:u8, slot:i16, mouseButton:i8, action:i16, mode:i8, item:slot}
//        1.17.1 `window_click` = {windowId:u8, stateId:varint, slot:i16, mouseButton:i8, mode:varint,
//                                  changedSlots:[{location,item}], cursorItem:slot}
//      自研的 `_tableCraft` 只写了 1.17+ 那一种信封，且**字段名对不上** ⇒ protodef 按字段名取值时
//      `action` 与 `item` 都是 undefined，读到 `item`（匿名 slot 容器）时去取 `undefined.present`
//      才炸。因为这个 slot 是**匿名容器**，`e.field` 也是 undefined，报错文本里连字段名都没有 ——
//      所以看起来像"Slot 形状问题"，实际是"少写了两个字段"。
//      ⇒ `_tableCraft` 在 1.16.1 上**可以启用**，只要按版本选信封（`windowClickPacket`）。

import { sleep, countItems } from './task.js';
import { createRequire } from 'module';
import prismarineItem from 'prismarine-item';

const require = createRequire(import.meta.url);

const ITEM_FACTORY_KEY = Symbol.for('aidqq.windowOps.itemFactory');
/** 服务端 set_slot 包里的 slot 是 `{present,itemId,itemCount}`，不是 prismarine 的 Item。
 *  必须过一次 `Item.fromNotch` 才有 name/count/type —— 否则 `expectName` 比对恒不成立、
 *  `findDestSlot` 恒找不到格子（自检 ⑦a 实测：took 读成 undefined 就是漏了这一步）。 */
export function toItem(bot, notch) {
    if (!notch) return null;
    if (notch.item === undefined && typeof notch.count === 'number' && typeof notch.type === 'number') return notch; // 已是 Item
    if (typeof notch.present === 'undefined' && notch.itemId === undefined) return null;
    if (!bot[ITEM_FACTORY_KEY]) bot[ITEM_FACTORY_KEY] = prismarineItem(bot.registry);
    try { return bot[ITEM_FACTORY_KEY].fromNotch(notch) ?? null; } catch { return null; }
}

// ── 版本判定（1.16.x 与 1.17+ 是唯一的分界：stateIdUsed / transactionPacketExists）──
export function clickFlavor(bot) {
    return {
        // ≤1.16.5：window_click 带 action 号，服务端用 transaction 包回执 accepted
        actionIdUsed: !!bot.supportFeature('actionIdUsed'),
        // ≤1.16.5：服务端会发 transaction；1.17+ 改为 stateId 校验
        transactionPacketExists: !!bot.supportFeature('transactionPacketExists'),
        // 1.17+：window_click 带 stateId + changedSlots + cursorItem
        stateIdUsed: !!bot.supportFeature('stateIdUsed'),
    };
}

// ── action 号（1.16.x）：必须**相对服务端已见到的最大 action 单调递增** ──
// 协议注释原话：Action number = "Assigned by the Client. This number must
// incrementally increase per click." 1.16.1 的服务端会拒收不递增的点击。
//
// 踩过的坑（实服 T09_SMOKE）：本模块原先用自己的计数器从 1 起步，于是同一台 bot 上
// mineflayer 自己（`bot.clickWindow`）已经推进过的 action 号被本模块"倒退"覆盖，
// **每一次点击都被服务端 accepted=false 拒收**（telemetry: table_craft_click_rejected
// {slot:37, rejected:true, via:'transaction'}，3/3 全灭）。
// 而 mineflayer 的计数器是 inventory.js 的模块私有变量，**读不到**。
// ⇒ 改成**从服务端回执里反推**：`transaction` 包会把 action 号原样送回来，
//    每次都拿它更新 max，下一个点击发 max+1。这样无论 mineflayer 自己点过多少次，
//    本模块发出的号都严格大于服务端见过的所有号。
const ACTION_KEY = Symbol.for('aidqq.windowOps.actionId');
function state(bot) {
    if (!bot[ACTION_KEY]) {
        bot[ACTION_KEY] = { maxAction: 0, onTx: null };
        const st = bot[ACTION_KEY];
        st.onTx = (p) => {
            if (p && typeof p.action === 'number' && p.action > st.maxAction) st.maxAction = p.action;
        };
        bot._client.on('transaction', st.onTx);
    }
    return bot[ACTION_KEY];
}
function nextActionId(bot) {
    const st = state(bot);
    st.maxAction = st.maxAction === 32767 ? 1 : st.maxAction + 1;
    return st.maxAction;
}

// 1.17+ 的 stateId：mineflayer 在 inventory.js 里自己维护（`stateId` 模块变量），
// 外部拿不到；这里自己跟一份，按**窗口 ID** 跟踪（这正是 _tableCraft 想要的语义：
// bot.craft 用全局单变量，会被玩家背包 offhand 的 set_slot 污染）。
const STATE_KEY = Symbol.for('aidqq.windowOps.stateId');
function stateIdFor(bot, windowId) {
    if (!bot[STATE_KEY]) {
        bot[STATE_KEY] = { map: new Map(), listen: false };
        const st = bot[STATE_KEY];
        const onSync = (p) => { if (p && typeof p.stateId === 'number') st.map.set(p.windowId, p.stateId); };
        bot._client.on('window_items', onSync);
        bot._client.on('set_slot', onSync);
    }
    const st = bot[STATE_KEY];
    return st.map.get(windowId) ?? 0;
}

/** 协议要的 slot 形状是 `{present,itemId,itemCount,nbtData}`。传 prismarine 的 Item 进去，
 *  protodef 读 `present` 得到 undefined ⇒ 编码成 **present=false（"光标是空的"）**，
 *  包照样编出来、不报任何错，但语义是错的：1.16.1 服务端按"你声称光标是空的"去校验，
 *  于是 accepted=false 拒收（实服证据 bench micro-craft/runs/T09_PDIFF：
 *  mineflayer 16 字节 accepted:true vs 本模块 9 字节 accepted:false，同一次点击）。
 *  已在离线自检里加断言（自检 ⑨），别再退化回去。 */
export function toNotchSlot(bot, item) {
    if (item == null) return { present: false };
    if (typeof item.present === 'boolean') return item;   // 已经是协议形状，原样透传
    if (item.itemId !== undefined) return item;           // 同上
    if (!bot[ITEM_FACTORY_KEY]) bot[ITEM_FACTORY_KEY] = prismarineItem(bot.registry);
    return bot[ITEM_FACTORY_KEY].toNotch(item);
}

/**
 * 按目标协议版本组装 window_click 包。
 * 这是 `_tableCraft` 在 1.16.1 上发不出包的真修法（**不是**改 Slot 形状，见文件头 (A)(B)）。
 * `item` / `cursorItem` / `changedSlots[].item` 一律在这里过 `toNotchSlot`，
 * 调用方不需要（也不该）自己记得转换。
 */
export function windowClickPacket(bot, flavor, { windowId, slot, mouseButton = 0, mode = 0, changedSlots, item, cursorItem }) {
    if (flavor.stateIdUsed) {
        return {
            name: 'window_click',
            params: {
                windowId, stateId: stateIdFor(bot, windowId), slot, mouseButton, mode,
                changedSlots: (changedSlots ?? []).map((c) => ({ location: c.location, item: toNotchSlot(bot, c.item) })),
                cursorItem: toNotchSlot(bot, cursorItem),
            },
        };
    }
    // ≤1.16.5：action 号 + 携带物品（不是 cursorItem）
    return {
        name: 'window_click',
        params: {
            windowId, slot, mouseButton, action: nextActionId(bot), mode,
            item: toNotchSlot(bot, item),
        },
    };
}

/** 序列化一个 window_click（离线自检与实服调试共用；失败信息带字段名便于定位） */
export function encodeWindowClick(bot, params) {
    const flavor = clickFlavor(bot);
    const pkt = windowClickPacket(bot, flavor, params);
    try {
        const { createSerializer } = require('minecraft-protocol');
        const s = createSerializer({ state: 'play', isServer: false, version: bot.version });
        return { ok: true, packet: pkt, bytes: s.createPacketBuffer(pkt).length };
    } catch (e) {
        return { ok: false, packet: pkt, error: String(e && e.message ? e.message : e).slice(0, 200) };
    }
}

/**
 * 等**服务端**对某一格的一次 set_slot。
 * 注意：这里只认原始包（`bot._client.on('set_slot')`）—— 本地 `window.updateSlot()`
 * 走的是 `window.emit`，不是这个事件，所以「客户端自己改模型」骗不过它。
 */
export function waitServerSlot(bot, windowId, slot, timeoutMs = 1200) {
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => { if (!done) { done = true; bot._client.removeListener('set_slot', h); clearTimeout(timer); resolve(v); } };
        const h = (p) => {
            if (p.windowId === windowId && p.slot === slot) finish({ ok: true, slot, item: toItem(bot, p.item) });
        };
        const timer = setTimeout(() => finish({ ok: false, slot, timedOut: true }), timeoutMs);
        bot._client.on('set_slot', h);
    });
}

/**
 * 等**服务端**的 transaction 回执，按我们发出的 action 号对齐。
 * 只有 1.16.x 有这个包（transactionPacketExists）。返回 {accepted} 或超时。
 */
export function waitServerTransaction(bot, windowId, actionId, timeoutMs = 1500) {
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => { if (!done) { done = true; bot._client.removeListener('transaction', h); clearTimeout(timer); resolve(v); } };
        const h = (p) => {
            if (p.windowId !== windowId) return;
            if (p.action !== actionId) return;   // 迟到/别人的回执一律不认
            finish({ ok: true, accepted: !!p.accepted, action: p.action });
        };
        const timer = setTimeout(() => finish({ ok: false, timedOut: true, action: actionId }), timeoutMs);
        bot._client.on('transaction', h);
    });
}

/**
 * 光标（carried item）的**服务端真值**判据。
 *
 * ── MC-M1-TASK-10 订正 TASK-09 §4.5 的否定结论 ──
 * TASK-09 写的是「1.16.x 的协议里根本没有光标这个字段 ⇒ 服务端永远不会告诉客户端
 * 光标里是什么 ⇒ 等服务端确认光标物理上不可能」。**这条不成立**，本单用协议表 +
 * 1.16.1 官方反编译源码双向核实：
 *
 *  ① 协议层（minecraft-data pc/1.16.1 protocol.json）：
 *       packet_set_slot = [{windowId: **i8**}, {slot: i16}, {item: slot}]
 *     `windowId` 是**有符号** i8，所以服务端的 -1 在线上一字节 0xFF 就是 -1，
 *     客户端 protodef 解出来仍然是 **-1**（不是 255）。
 *     TASK-09 犯的错是**判据**：它等 `set_slot(windowId === 当前窗口id, slot === -1)`，
 *     而服务端发光标用的 windowId 是 **-1**（不是窗口 id）⇒ 那个谓词**永远不可能命中**。
 *     「等不到包」是判据写错的观测结果，**不是包没来**（手册 §5：超时不是证据）。
 *
 *  ② 服务端确实会主动发（ServerPlayer.java:947 / :962）：
 *       broadcastCarriedItem() → new ClientboundContainerSetSlotPacket(-1, -1, this.bt.m())
 *       窗口全量同步后也会跟一条同形的包
 *     即 **windowId=-1 且 slot=-1 的那条 set_slot 就是光标真值**，1.16.1 与 1.17+ 一致。
 *
 *  ③ 为什么 mineflayer 读不到：`inventory.js:738-753` 的 set_slot 处理器按 windowId 派发，
 *     `packet.windowId === 0 ? bot.inventory : bot.currentWindow` 之后还有
 *     `window.id !== packet.windowId ⇒ return` —— windowId=-1 落进这个 return，
 *     **包被丢掉**。所以本地 `win.selectedItem` 永远拿不到服务端校正。
 *     ⇒ 要服务端的光标真值，只能自己听原始包（本文件的 tap / readCursorTruth）。
 *
 * 注意：服务端**只在光标内容变化时**才发这条包（broadcastCarriedItem 由回执路径和
 * broadcastChanges 触发）。所以「没等到光标包」≠「光标是空的」，也不该当成失败判据；
 * 它只在**我们期望光标变化**时才是有效证据。
 */
export const CURSOR_WINDOW_ID = -1;
export const CURSOR_SLOT = -1;
export function isCursorPacket(p) {
    return !!p && p.windowId === CURSOR_WINDOW_ID && p.slot === CURSOR_SLOT;
}

/** 槽位签名（type:count），用来判"服务端那一格有没有真的变" */
export function slotSig(it) {
    return it ? `${it.type}:${it.count}` : null;
}

/** 背包区（win.inventoryStart … win.inventoryEnd）逐格签名快照 */
export function inventorySignature(win) {
    const sig = {};
    if (!win || win.id == null) return sig;
    for (let i = win.inventoryStart; i < win.inventoryEnd; i++) sig[i] = slotSig(win.slots[i]);
    return sig;
}

export function readCursorTruth(bot, windowId, { timeoutMs = 0, from } = {}) {
    // from: 已经收到的包里回放（毫秒时间戳），用于「点击后已经收到过 -1 更新」的情况。
    // ⚠ windowId 参数**只保留签名兼容**，不再参与匹配：服务端光标包的 windowId 是 -1，
    //   与当前窗口 id 无关（见上）。老代码拿它做等值比较，导致 1.16.1 上永远等不到。
    if (from) {
        for (let i = from.length - 1; i >= 0; i--) {
            if (isCursorPacket(from[i])) return { ok: true, item: toItem(bot, from[i].item), fromPacket: true };
        }
        return { ok: false, item: null, fromPacket: false };
    }
    if (timeoutMs <= 0) return { ok: false, item: null, fromPacket: false };
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => { if (!done) { done = true; bot._client.removeListener('set_slot', h); clearTimeout(timer); resolve(v); } };
        const h = (p) => { if (isCursorPacket(p)) finish({ ok: true, item: toItem(bot, p.item), fromPacket: true }); };
        const timer = setTimeout(() => finish({ ok: false, item: null, fromPacket: false }), timeoutMs);
        bot._client.on('set_slot', h);
    });
}

/**
 * 抓 `set_slot` 原始包的环形缓冲（用于点击前后回放，确认光标真值与背包槽真值）。
 *
 * ⚠ TASK-10 订正：老版本这里第一行就是 `if (p.windowId !== windowId) return;` ——
 *   那会把 windowId=-1 的**光标包**全部过滤掉（服务端发光标用的 windowId 是 -1，
 *   不是窗口 id），于是"光标真值"这条通道永远是空的。现在**照单全收**，
 *   由 `cursorTruth()` / `slotTruth()` 各自按正确的谓词去挑。
 *   windowId 参数只用于 `slotTruth` 的默认过滤。
 */
export function makeSlotTap(bot, windowId = null, capacity = 64) {
    const buf = [];
    const push = (p) => {
        const rec = { at: Date.now(), windowId: p.windowId, slot: p.slot, item: p.item ?? null };
        buf.push(rec);
        if (buf.length > capacity) buf.shift();
        return rec;
    };
    const h = (p) => { push(p); };
    bot._client.on('set_slot', h);
    // 命中缓冲里**最近**一条；没有就真的**等**一条新的（不是立刻返回空——
    // 服务端的回包本来就是异步的，「刚点完就查」必然查不到）
    const find = (pred, ms) => {
        for (let i = buf.length - 1; i >= 0; i--) {
            if (pred(buf[i])) return { hit: buf[i] };
        }
        if (!(ms > 0)) return { hit: null };
        return new Promise((resolve) => {
            let done = false;
            const finish = (v) => { if (!done) { done = true; bot._client.removeListener('set_slot', w); clearTimeout(t); resolve(v); } };
            const w = (p) => {
                if (p.windowId !== windowId) return;
                const rec = push(p);
                if (pred(rec)) finish({ hit: rec });
            };
            const t = setTimeout(() => finish({ hit: null }), ms);
            bot._client.on('set_slot', w);
        });
    };
    return {
        packets: buf,
        since: (ms) => buf.filter((p) => p.at >= Date.now() - ms),
        /** 光标真值：只认服务端 set_slot 的 (-1,-1) 那一条（与窗口 id 无关） */
        async cursorTruth(ms = 2000) {
            const { hit } = await find(isCursorPacket, ms);
            return hit ? { ok: true, item: toItem(bot, hit.item), fromPacket: true } : { ok: false, item: null, fromPacket: false };
        },
        /** 某格的最新服务端真值（默认只看本窗口） */
        async slotTruth(slot, ms = 2000, winId = windowId) {
            const { hit } = await find((p) => p.slot === slot && (winId == null || p.windowId === winId), ms);
            return hit ? { ok: true, item: toItem(bot, hit.item) } : { ok: false, timedOut: true };
        },
        stop: () => bot._client.removeListener('set_slot', h),
    };
}

/**
 * 一步一确认的窗口点击。
 *
 * 语义（这是整个文件的核心）：
 *   发包 → **等服务端对这一次点击的判决** → 把判决带回来。
 *   - `requiresConfirmation` 的窗口（1.16.1 的 inventory/crafting_table/furnace）：
 *     走 `bot.clickWindow`，它内部已经按 action 号等真实 `transaction` 包，
 *     被拒会抛 —— 我们把那个异常**结构化**成 {accepted:false}，不当未知异常吞掉。
 *   - `requiresConfirmation=false` 的窗口（**1.16.1 的箱子**就是这样：
 *     `prismarine-windows` 对 `minecraft:container` 把 requireConfirmation 设成 false，
 *     于是 mineflayer **自己给自己发 accepted=true**、不等服务端）：不能信模型，
 *     改为「直发包 + 等服务端 set_slot 覆盖被点的那一格」。
 *   - 1.17+：没有 transaction 包，按 stateId 走，等服务端 set_slot 覆盖被点的那一格。
 *
 * 返回 {accepted, via, cursor, slot}；`accepted===false` 或 `unconfirmed===true` 都**不是**成功。
 */
export async function clickConfirmed(bot, win, { slot, mouseButton = 0, mode = 0, timeoutMs = 1500, expectSlotChange = true } = {}) {
    const flavor = clickFlavor(bot);
    const needsConfirmation = win.requiresConfirmation !== false;
    const tap = makeSlotTap(bot, win.id);

    try {
        if (flavor.transactionPacketExists && needsConfirmation) {
            // mineflayer 自己的 clickWindow：按 action 号等真实 transaction，被拒抛异常
            try {
                await bot.clickWindow(slot, mouseButton, mode);
            } catch (e) {
                const msg = String(e && e.message ? e.message : e);
                const rejected = /Server rejected transaction/.test(msg);
                return { accepted: false, rejected, via: 'transaction', error: msg.slice(0, 160), slot };
            }
            return { accepted: true, via: 'transaction', slot };
        }

        // 直发 + 等服务端覆盖该格（1.16.1 箱子 / 1.17+）
        const flavorNow = clickFlavor(bot);
        // ⚠ 必须在等回执**之前**把这一格的内容拍下来：服务端的 `set_slot` 一到，
        //   `win.slots[slot]` 就已经是新值了，到时候再拿它去 acceptClick 就等于
        //   "按结果算原因"，整步预测全错（自检 ⑧ 就是这么红的）。
        const beforeItem = win.slots[slot] ?? null;
        const pkt = windowClickPacket(bot, flavorNow, {
            windowId: win.id, slot, mouseButton, mode,
            changedSlots: [],
            item: beforeItem,
            cursorItem: win.selectedItem ?? null,
        });
        const action = pkt.params.action;
        // 只在「这个窗口本来就要 transaction 回执」时才等它。
        // requiresConfirmation=false 的窗口（1.16.1 的箱子）**按定义就收不到** transaction
        // ——mineflayer 对这类窗口是自说自话地 accepted=true。等一个永远不会来的包，
        // 只会把「等 set_slot」这一步整体推迟到包已经错过之后（自检 ⑧ 的真实教训）。
        const wantTx = flavorNow.transactionPacketExists && needsConfirmation;
        const ackP = wantTx ? waitServerTransaction(bot, win.id, action, timeoutMs) : Promise.resolve(null);
        bot._client.write(pkt.name, pkt.params);
        const ack = await ackP;
        if (ack && ack.ok && ack.accepted === false) {
            return { accepted: false, rejected: true, via: 'transaction', slot };
        }
        if (expectSlotChange) {
            const s = await waitServerSlot(bot, win.id, slot, timeoutMs);
            if (!s.ok) return { accepted: null, unconfirmed: true, via: 'set_slot', slot };
            // 服务端已确认这一格（`win.slots[slot]` 也已被 mineflayer 的 set_slot 处理器
            // 按服务端的值更新过，**不要**再拿它去 acceptClick 预测——那是"按结果算原因"）。
            // 1.16.x 唯一缺的是**光标**：线上没有 carriedItem 字段，服务端不会告诉���。
            // 光标为空 + 服务端把这一格清空 + 发包前这一格有东西 ⇒ 光标现在就是那样东西。
            // 这是**由服务端确认推导**出来的，不是凭空预测。
            if (!hasCarriedItemWire(bot) && beforeItem && !win.selectedItem && !s.item) {
                win.selectedItem = beforeItem;
            }
            return { accepted: true, via: 'set_slot', slot, item: s.item };
        }
        return { accepted: ack ? ack.accepted : null, via: 'set_slot', slot };
    } finally {
        tap.stop();
    }
}

/**
 * 直发一次 window_click，**等服务端判决之后**再决定要不要动本地模型。
 *
 * 这是 `_tableCraft` 的地基，也是「每一步等服务端确认」的字面实现：
 *   - 1.16.x：发出去时带 action 号 ⇒ 等 `transaction{action:我们那个, accepted}`。
 *     **accepted=true 才调 `win.acceptClick(...)`**（把服务端认可的预测写回本地模型，
 *     这正是 mineflayer `confirmTransaction.onAccepted` 干的事）；accepted=false 或超时
 *     ⇒ **一个字节都不改模型**，直接如实返回。
 *   - 1.17+：包里必须带 changedSlots（协议要求客户端上报预测），所以照样先 acceptClick 算差分，
 *     但随后**等服务端 set_slot 覆盖被点的那一格**再返回；没等到就是 unconfirmed。
 *
 * 关键区别（vs 旧 `_tableCraft`）：旧代码是「先 acceptClick 改模型 → 再发包 → 最多等 350ms 就走」，
 * 服务端还没说话本地就已经假定成功了；这里把顺序倒过来。
 */
export async function clickRawConfirmed(bot, win, { slot, mouseButton = 0, mode = 0, timeoutMs = 900 } = {}) {
    const flavor = clickFlavor(bot);
    const before = win.slots[slot] ?? null;
    const beforeCursor = win.selectedItem ?? null;
    const beforeSig = win.slots.map((s) => (s ? `${s.type}:${s.count}` : null));

    // 1.17+ 的 changedSlots 是协议要求（客户端预测上报），必须在写包前算出来
    let changedSlots = [];
    if (flavor.stateIdUsed) {
        win.acceptClick({ slot, mouseButton, mode, item: before });
        win.slots.forEach((s, i) => {
            const k = s ? `${s.type}:${s.count}` : null;
            if (k !== beforeSig[i]) changedSlots.push({ location: i, item: s });
        });
    }

    const pkt = windowClickPacket(bot, flavor, {
        windowId: win.id, slot, mouseButton, mode,
        changedSlots,
        item: before,
        cursorItem: beforeCursor,
    });
    const action = pkt.params.action;
    const ackP = flavor.transactionPacketExists
        ? waitServerTransaction(bot, win.id, action, timeoutMs)
        : waitServerSlot(bot, win.id, slot, timeoutMs).then((s) => (s.ok ? { ok: true, via: 'set_slot' } : { ok: false, timedOut: true }));

    bot._client.write(pkt.name, pkt.params);
    const ack = await ackP;

    if (flavor.transactionPacketExists) {
        if (!ack || !ack.ok) return { ok: false, unconfirmed: true, via: 'transaction', action, maxAction: state(bot).maxAction, timedOut: !!ack?.timedOut };
        if (ack.accepted === false) return { ok: false, rejected: true, via: 'transaction', action, maxAction: state(bot).maxAction };
        // 服务端认可 ⇒ 才把预测落到本地模型（与 mineflayer 的 onAccepted 同款）
        win.acceptClick({ slot, mouseButton, mode, id: action, windowId: win.id, item: before });
        return { ok: true, via: 'transaction', action };
    }
    if (!ack || !ack.ok) return { ok: false, unconfirmed: true, via: 'set_slot', slot, timedOut: !!ack?.timedOut };
    return { ok: true, via: 'set_slot', slot };
}

/**
 * 窗口开着的时候，**背包里的东西在 `win.slots[win.inventoryStart … win.inventoryEnd]`**，
 * 而不在 `bot.inventory` 里 —— mineflayer 的 `set_slot` 处理器按 windowId 派发
 * （inventory.js：`packet.windowId === 0 ? bot.inventory : bot.currentWindow`），
 * 所以工作台/熔炉/箱子开着时，服务端放进背包的物品只落在**那扇窗口**的镜像区。
 * ⇒ 用 `countItems(bot, …)` 判"到手没有"在窗口开着期间恒读到 0，
 *   这正是 06c 记的"背包同步慢、smeltOk 恒 0"里**真正属于本单的那一半**。
 * 本函数是窗口感知版计数，两种情形都读对。
 */
export function countItemsWindowAware(bot, name, win = null) {
    const w = win ?? bot.currentWindow;
    const inWin = (w && w.id !== 0)
        ? w.slots.slice(w.inventoryStart, w.inventoryEnd).filter((s) => s && s.name === name).reduce((s, i) => s + i.count, 0)
        : 0;
    return Math.max(countItems(bot, [name]), inWin);
}

/** 找一个能放下的背包槽（同型可堆叠优先，其次空槽）；找不到返回 -1 */
export function findDestSlot(win, item) {
    if (!item) return -1;
    for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
        const s = win.slots[i];
        if (s && s.type === item.type && s.count < s.stackSize) return i;
    }
    for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
        if (!win.slots[i]) return i;
    }
    return -1;
}

/**
 * 「自己一步步点」取产物/取输出格 —— 本文件的主原语。
 *
 * 替换掉 mineflayer 的 `putAway(2)` / `grabResult()` 这类**复合动作**：
 *   1) 点结果格 → **等服务端判决**（1.16.x：transaction 按 action 号；否则：等该格 set_slot）
 *   2) **从服务端包**确认光标上真的有东西（不是 `selectedItem` 的客户端预测）
 *   3) 点背包目标格 → 同样等服务端判决
 *   4) 最后按**背包增量**再确认一次（手册 §3 的老规矩，兜底）
 *
 * opts.expectName：期望拿到的物品名（服务端真值比对，不符即判失败，绝不"差不多就行"）
 * 返回 {ok, took, gained, reason, verdict}
 */
/**
 * 1.16.x 的协议里**根本没有光标（carried item）这个字段**。
 * 证据（本单 dump 的 minecraft-data 定义）：
 *   1.16.1 `window_items` = `{windowId:u8, items:array}`      ← **没有 carriedItem**
 *   1.17.1 `window_items` = `{windowId, stateId, items, carriedItem}`  ← 1.17 才加
 *   两个版本的 `set_slot` 都只有 `{windowId, slot, item}`，没有"光标"专用的槽位定义。
 * ⇒ 在 1.16.1 上，**光标的内容永远不会被服务端单独告知**，`set_slot(-1)` 不会来。
 *   实服证据 T09_FURN3：点击输出格被 accepted、输出格 `set_slot` 清零，
 *   但 `cursorTruth()` 永远等不到 slot=-1 ⇒ 取件 0/30。
 * ⇒ 所以 1.16.x 的"逐步确认"里，**光标这一步在物理上无法独立确认**，
 *   最强的可得确认是三件事的合取：
 *     ① 那一次点击被服务端 `transaction{accepted:true}` 认可；
 *     ② 目标格（背包格）拿到了**服务端 `set_slot`**；
 *     ③ 窗口感知的背包增量真的到账。
 *   光标读本地 `win.selectedItem` —— 在 1.16.x 且 `requiresConfirmation=true` 的窗口上，
 *   它是被 `confirmTransaction.onAccepted`（服务端 accepted 之后）赋值的，
 *   **不是纯客户端预测**，可以当作中间量用；但**不能**当作最终判据。
 * 1.17+ 有 carriedItem，才走严格的 `set_slot(-1)` 确认。
 */
export function hasCarriedItemWire(bot) {
    // stateIdUsed = 1.17+；1.16.x（actionIdUsed）为 false
    return !clickFlavor(bot).actionIdUsed;
}

export async function takeFromSlotConfirmed(bot, win, slot, opts = {}) {
    const { timeoutMs = 2000, expectName = null, invBefore = null, itemName = null } = opts;
    const flavor = clickFlavor(bot);
    const strictCursor = hasCarriedItemWire(bot);
    const tap = makeSlotTap(bot, win.id, 96);

    // 起点：光标必须为空，否则这一步是「交换」而不是「拿起」（ROUND3-A §5 的真凶）
    if (win.selectedItem) {
        return { ok: false, reason: 'cursor_not_empty', held: `${win.selectedItem.name}x${win.selectedItem.count}` };
    }
    const before = itemName ? countItemsWindowAware(bot, itemName, win) : (invBefore ?? null);

    try {
        // ── 步骤 1：点结果格，等服务端判决 ──
        const v1 = await clickConfirmed(bot, win, { slot, mouseButton: 0, mode: 0, timeoutMs });
        if (v1.accepted === false) return { ok: false, reason: 'server_rejected', verdict: v1 };
        if (v1.unconfirmed) return { ok: false, reason: 'no_server_ack', verdict: v1 };

        // ── 步骤 2：确认"产物到手了" ──
        let cursorItem = null;
        let cursorHow = null;
        if (strictCursor) {
            // 1.17+：光标有线上表示，只认服务端 set_slot(-1)
            const cur = await tap.cursorTruth(timeoutMs);
            if (!cur.ok) return { ok: false, reason: 'cursor_empty_from_server', verdict: v1 };
            cursorItem = cur.item;
            cursorHow = 'set_slot(-1)';
        } else {
            // 1.16.x：线上没有光标字段，只能用"被 accepted 之后才被赋值的"本地 selectedItem
            cursorItem = win.selectedItem ?? null;
            cursorHow = 'selectedItem(after accepted)';
            if (!cursorItem) return { ok: false, reason: 'no_cursor_after_accept', verdict: v1 };
        }
        if (expectName && cursorItem.name !== expectName) {
            return { ok: false, reason: 'cursor_wrong_item', got: cursorItem.name, want: expectName };
        }

        // ── 步骤 3：点背包目标格，再等一次服务端判决 ──
        const dest = findDestSlot(win, cursorItem);
        if (dest < 0) return { ok: false, reason: 'inventory_full', got: `${cursorItem.name}x${cursorItem.count}` };
        const v2 = await clickConfirmed(bot, win, { slot: dest, mouseButton: 0, mode: 0, timeoutMs });
        if (v2.accepted === false) return { ok: false, reason: 'server_rejected_dest', verdict: v2, took: cursorItem.count };
        if (v2.unconfirmed) return { ok: false, reason: 'no_server_ack_dest', verdict: v2, took: cursorItem.count };

        // ── 步骤 4：窗口感知的背包增量兜底（1.16.x 上这才是最终判据）──
        let gained = 0;
        if (itemName) {
            const dl = Date.now() + timeoutMs;
            gained = countItemsWindowAware(bot, itemName, win) - before;
            while (gained <= 0 && Date.now() < dl) { await sleep(120); gained = countItemsWindowAware(bot, itemName, win) - before; }
            if (gained <= 0) {
                return { ok: false, reason: 'no_inv_delta', took: cursorItem.count, dest, verdict: [v1, v2] };
            }
        }
        return { ok: true, took: cursorItem.count, gained: Math.max(0, gained), dest, cursorHow, verdict: [v1, v2], flavor };
    } finally {
        tap.stop();
    }
}

/**
 * 发一次 window_click，`item` 字段填**光标**（协议里这一位叫 carried item）。
 *
 * ── 为什么不能直接用 `bot.clickWindow` 发 QUICK_MOVE ──
 * 1.16.1 服务端回执的判据是 `ItemStack.matches(包的carried, 点击后服务端光标)`
 * （`ServerGamePacketListenerImpl.handleContainerClick` :1180）。
 * 对 QUICK_MOVE，`AbstractContainerMenu.b(...)` 那个分支**从头到尾没有给返回值赋过非空**，
 * 最后 `return itemstack`（:400）返回的是**初始值 EMPTY** ⇒ 服务端认定"点击后光标是空的"。
 * 而 mineflayer 的 `clickWindow` 把 `item` 填成**被点那一格里的东西**（`click.item = window.slots[slot]`，
 * inventory.js:571/626）——shift 点输出格时那就是**产物本身**。
 * 于是 `matches(产物, 空)` = false ⇒ **服务端回 accepted=false** 并整窗重发，
 * 一次 shift 点击都别想成功。（这就是"用 mineflayer 原生 API 做 shift 取件"在 1.16.1 上的死结。）
 *
 * 对 PICKUP 恰好相反：点输出格时"格里的东西"正好等于"点击后光标里的东西"，所以那个错填
 * 一直蒙对了——这正是 TASK-09 里两次点击都 accepted、产物却没进背包的嫌疑点之一。
 *
 * ⇒ 本函数把 `item` 填成**当前光标**（`win.selectedItem`），这才是协议要的东西。
 * 仍然按 action 号等服务端真回执，accepted 之后才 `acceptClick` 落本地模型。
 */
export async function clickCursorClaimConfirmed(bot, win, { slot, mouseButton = 0, mode = 0, timeoutMs = 1200, applyLocal = true } = {}) {
    const flavor = clickFlavor(bot);
    const cursor = win.selectedItem ?? null;
    const before = win.slots[slot] ?? null;

    let changedSlots = [];
    if (flavor.stateIdUsed) {
        // 1.17+：包里必须带 changedSlots（客户端预测上报）——先拍签名再算差分
        const sig0 = win.slots.map(slotSig);
        win.acceptClick({ slot, mouseButton, mode, item: before });
        win.slots.forEach((s, i) => { if (slotSig(s) !== sig0[i]) changedSlots.push({ location: i, item: s }); });
    }

    const pkt = windowClickPacket(bot, flavor, {
        windowId: win.id, slot, mouseButton, mode, changedSlots,
        item: cursor,                 // ← 光标，不是被点那一格
        cursorItem: cursor,
    });
    const action = pkt.params.action;
    const ackP = flavor.transactionPacketExists
        ? waitServerTransaction(bot, win.id, action, timeoutMs)
        : waitServerSlot(bot, win.id, slot, timeoutMs).then((s) => (s.ok ? { ok: true, via: 'set_slot' } : { ok: false, timedOut: true }));

    bot._client.write(pkt.name, pkt.params);
    const ack = await ackP;

    if (flavor.transactionPacketExists) {
        if (!ack || !ack.ok) return { ok: false, unconfirmed: true, via: 'transaction', action, timedOut: !!ack?.timedOut };
        if (ack.accepted === false) return { ok: false, rejected: true, via: 'transaction', action };
        if (applyLocal) win.acceptClick({ slot, mouseButton, mode, id: action, windowId: win.id, item: before });
        return { ok: true, via: 'transaction', action };
    }
    if (!ack || !ack.ok) return { ok: false, unconfirmed: true, via: 'set_slot', slot, timedOut: !!ack?.timedOut };
    return { ok: true, via: 'set_slot', slot };
}

/**
 * 等**服务端**确认「产物进了背包的哪一格」。
 *
 * ⚠ TASK-10：这里**必须同时认两条服务端通道**，只等 `set_slot` 永远等不到。
 * 1.16.1 一次被 accepted 的点击，服务端走的是
 *   `ServerPlayer.handleContainerClick` :1181-1185：
 *       send(Ack(true)); ignoreSlotUpdateHack = **true**; menu.broadcastChanges(); broadcastCarriedItem(); = false
 * 而 `broadcastChanges()` = `ServerPlayer.a(menu, menu.getItems())`（:941-948）发的是
 *   **整窗 `window_items`（ClientboundContainerSetContentPacket） + 一条 set_slot(-1,-1) 光标包**；
 * 逐格 `set_slot`（`ServerPlayer.a(menu,int,ItemStack)` :929-939）被 `ignoreSlotUpdateHack` **整个抑制**。
 * ⇒ 点击被 accepted 之后，客户端能拿到的服务端真值是**整窗数组**，不是逐格包。
 *   只等逐格 set_slot 的判据在这条路径上是**结构性等不到**（又一个"超时不是证据"的坑）。
 *
 * 返回 {ok, slot, item, via}：
 *   via='window_items' —— 从整窗数组里找出与点击前签名不同、且装着期望物品的那一格；
 *   via='set_slot'     —— 服务端确实逐格发了（别的路径/别的版本）。
 */
export function waitServerInventoryUpdate(bot, win, { timeoutMs = 2000, beforeSig = null, expectName = null } = {}) {
    const invSig = (items) => {
        const sig = {};
        for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
            const it = items?.[i] ? toItem(bot, items[i]) : (win.slots[i] ?? null);
            sig[i] = slotSig(it);
        }
        return sig;
    };
    return new Promise((resolve) => {
        let done = false;
        const finish = (v) => { if (!done) { done = true; bot._client.removeListener('set_slot', h1); bot._client.removeListener('window_items', h2); clearTimeout(timer); resolve(v); } };
        const accept = (it, slot, via) => {
            if (!it) return;
            if (expectName && it.name && it.name !== expectName) return;
            if (beforeSig && beforeSig[slot] === slotSig(it)) return;   // 与点击前一样 ⇒ 不是这次点击带来的
            finish({ ok: true, slot, item: it, via });
        };
        const h1 = (p) => {
            if (p.windowId !== win.id || isCursorPacket(p)) return;
            if (!(p.slot >= win.inventoryStart && p.slot < win.inventoryEnd)) return;
            accept(toItem(bot, p.item), p.slot, 'set_slot');
        };
        const h2 = (p) => {
            if (p.windowId !== win.id || !p.items) return;
            const sig = invSig(p.items);
            for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
                if (beforeSig && beforeSig[i] === sig[i]) continue;      // 没变
                const it = toItem(bot, p.items[i]);
                if (it) { accept(it, i, 'window_items'); return; }
            }
        };
        const timer = setTimeout(() => finish({ ok: false, timedOut: true }), timeoutMs);
        bot._client.on('set_slot', h1);
        bot._client.on('window_items', h2);
    });
}

/**
 * ── MC-M1-TASK-10：熔炉取产物改 **shift 点击（mode=1 / QUICK_MOVE）** ──
 *
 * 为什么换掉"点输出格 → 再点背包格"那两步：
 *   那条路**必然经过光标**。1.16.1 服务端 `AbstractFurnaceMenu.b(Player,int)`
 *   （quickMoveStack，:97-143）对 index==2 有**专门分支**：
 *       if (index == 2) { if (!this.moveItemStack(itemstack, 3, 39, true)) return EMPTY; slot.remove(itemstack); }
 *   ——**整摞直接进背包槽 3..39，光标全程不参与**。这条路径上"产物停在光标"这个失效模式
 *   结构上不存在，也就不需要去和"客户端/服务端光标是否分叉"搏斗。
 *
 * 判据（**每一步都要服务端真值**，不接受"点了就当成功"）：
 *   ① 那一次 shift 点击拿到服务端 `transaction{accepted:true}`（1.16.x 唯一真回执）；
 *   ② 背包区出现**服务端** set_slot（`waitServerInventoryUpdate`）——不是客户端模型自说自话；
 *   ③ 窗口感知的背包增量真的到账；
 *   ④ **产物不经光标**：从点击到增量到账这段时间内，服务端光标包（-1,-1）里没有出现产物。
 *      这条是本原语与旧原语的结构性区别，作为不变量一起断言。
 * 返回 {ok, took, gained, dest, cursorUntouched, verdict, reason}
 */
export async function takeFurnaceOutputQuickMove(bot, furnace, opts = {}) {
    const { timeoutMs = 2500, expectName = null, itemName = null } = opts;
    const win = furnace.window ?? furnace;
    if (!win || win.id == null) return { ok: false, reason: 'no_furnace_window' };

    // 服务端真值先问一遍：输出格到底有没有东西（不信客户端模型的 outputItem）
    const out = win.slots[2];
    if (!out || out.count <= 0) return { ok: false, reason: 'output_empty' };
    const outName = out.name ?? null;
    if (expectName && outName && outName !== expectName) {
        return { ok: false, reason: 'output_wrong_item', got: outName, want: expectName };
    }
    const item = itemName ?? outName;

    // 起点：光标必须为空。shift 点击在光标非空时语义完全不同（会把光标物丢出去/交换）。
    if (win.selectedItem) {
        return { ok: false, reason: 'cursor_not_empty', held: `${win.selectedItem.name}x${win.selectedItem.count}` };
    }

    // 背包放不下就别点。服务端 `AbstractFurnaceMenu.b(Player,int)` 对 index==2 是
    // 「先 moveItemStack(3,39)，失败就原样返回 EMPTY」⇒ 输出格**不会被清空**，
    // 也就是说点下去不会有任何副作用，但会留下一条读不出所以然的失败。
    // 这里提前判掉，理由写成人能看懂的 `inventory_full`（06c 的 `destination full` 同族）。
    if (item) {
        let room = false;
        for (let i = win.inventoryStart; i < win.inventoryEnd; i++) {
            const s = win.slots[i];
            if (!s) { room = true; break; }
            if (s.name === outName && s.count < s.stackSize) { room = true; break; }
        }
        if (!room) return { ok: false, reason: 'inventory_full', want: item };
    }

    const before = item ? countItemsWindowAware(bot, item, win) : null;
    const beforeSig = inventorySignature(win);
    const tap = makeSlotTap(bot, win.id, 128);

    try {
        const clickAt = Date.now();
        // ⚠⚠ 判据②的监听器必须在**点击之前**挂上。
        //   服务端在 accepted 路径里是「先发 Ack、再 broadcastChanges（整窗 window_items）」，
        //   两个包通常在同一个 TCP 段里到达 ⇒ 等 clickCursorClaimConfirmed 的回执 resolve
        //   **之后**再挂监听，整窗包早就被 mineflayer 派发掉了。
        //   实测证据：① 那轮 quickMove 的 dest 全是 null（而 gained>0 所以没判失败）
        //   ——判据② 整条是死代码，服了但没证据。
        const srvP = waitServerInventoryUpdate(bot, win, { timeoutMs, beforeSig, expectName: item });
        // ① shift 点击输出格；`item` 填光标（空）——见 clickCursorClaimConfirmed 的注释
        const v = await clickCursorClaimConfirmed(bot, win, { slot: 2, mouseButton: 0, mode: 1, timeoutMs });
        if (!v.ok) return { ok: false, reason: v.rejected ? 'server_rejected' : 'no_server_ack', verdict: v };

        // ② 服务端确认产物进了背包的哪一格（1.16.1 上是整窗 window_items，不是逐格 set_slot）
        const srv = await srvP;
        // ③ 窗口感知的背包增量
        let gained = 0;
        if (item) {
            const dl = Date.now() + timeoutMs;
            gained = countItemsWindowAware(bot, item, win) - before;
            while (gained <= 0 && Date.now() < dl) { await sleep(100); gained = countItemsWindowAware(bot, item, win) - before; }
        }
        // ④ 不变量：这段时间里光标**没有**拿到产物
        const cursorPackets = tap.since(Date.now() - clickAt).filter(isCursorPacket);
        const cursorGotProduct = cursorPackets.some((p) => {
            const it = toItem(bot, p.item);
            return it && (it.name === item || (item == null && it.name));
        });
        if (cursorGotProduct) {
            return { ok: false, reason: 'cursor_got_product', cursor: cursorPackets.map((p) => slotSig(toItem(bot, p.item))), srv, gained };
        }
        if (!srv.ok && gained <= 0) {
            return { ok: false, reason: 'no_server_inv_slot', gained, verdict: v, cursorPackets: cursorPackets.length };
        }
        if (item && gained <= 0) return { ok: false, reason: 'no_inv_delta', gained, srv, verdict: v };
        return {
            ok: true, took: srv.item?.count ?? out.count, gained: Math.max(0, gained),
            dest: srv.slot ?? null, destVia: srv.via ?? null,
            cursorUntouched: true, cursorPackets: cursorPackets.length,
            srv, verdict: v,
        };
    } finally {
        tap.stop();
    }
}

/**
 * 熔炉取产物的**生产入口**。MC-M1-TASK-10 起主用 shift 点击（不经光标），
 * 失败时才回退到"点输出格 → 点背包格"那两步（仍保留，用于对照与诊断）。
 *
 * 回退只在**服务端明确拒收**（rejected / no_server_ack）时发生——那说明这条炉子/
 * 这一局的窗口状态本身有问题，再点一次不会更好；而 `no_inv_delta` 这类
 * "点了但没到账"的情况**不回退**（重复点击只会让光标状态更乱，正是要治的病）。
 */
export async function takeFurnaceOutputConfirmed(bot, furnace, opts = {}) {
    const win = furnace.window ?? furnace;
    if (!win || win.id == null) return { ok: false, reason: 'no_furnace_window' };
    const out = win.slots[2];
    if (!out || out.count <= 0) return { ok: false, reason: 'output_empty' };

    const via = opts.via ?? 'auto';
    if (via === 'pickup' || via === 'two-step') {
        return takeFromSlotConfirmed(bot, win, 2, { ...opts, expectName: opts.expectName ?? null });
    }

    const quick = await takeFurnaceOutputQuickMove(bot, furnace, opts);
    if (quick.ok || via === 'quickmove') return quick;

    // 只有"服务端拒收"才值得换协议再试一次
    if (quick.reason !== 'server_rejected' && quick.reason !== 'no_server_ack') return quick;
    const two = await takeFromSlotConfirmed(bot, win, 2, { ...opts, expectName: opts.expectName ?? null });
    if (two.ok) return { ...two, fellBackFrom: 'quickmove', quickReason: quick.reason };
    return { ...two, quickAttempt: quick };
}

/**
 * 开箱取物（1.16.1 的箱子是 `requiresConfirmation=false` 的那一类，必须走服务端确认）。
 * items: [{name?, type?}]；只取匹配项，逐格取、逐格确认。
 * 返回 {ok, taken:[{name,count}], failed:[{slot,reason}]}
 */
export async function withdrawFromContainerConfirmed(bot, container, match, opts = {}) {
    const { timeoutMs = 2000, maxSlots = 27 } = opts;
    const win = container.window ?? container;
    if (!win || win.id == null) return { ok: false, taken: [], failed: [{ slot: -1, reason: 'no_window' }] };
    const taken = [], failed = [];
    // 逐格扫容器区（inventoryStart 之前都是容器自己的格子）
    for (let slot = 0; slot < win.inventoryStart && slot < maxSlots; slot++) {
        const s = win.slots[slot];
        if (!s) continue;
        if (!match(s)) continue;
        const name = s.name;
        const before = countItems(bot, [name]);
        const r = await takeFromSlotConfirmed(bot, win, slot, { timeoutMs, expectName: name, itemName: name });
        if (r.ok) taken.push({ name, count: r.took, slot });
        else failed.push({ slot, name, reason: r.reason, verdict: r.verdict ?? null });
    }
    return { ok: failed.length === 0, taken, failed };
}

/** 关窗并等服务端真的把窗口关掉（避免下一次开窗复用到分叉窗口） */
export async function closeWindowConfirmed(bot, win, timeoutMs = 1200) {
    if (!win) return true;
    if (bot.currentWindow && bot.currentWindow.id !== win.id) return true;
    const p = new Promise((resolve) => {
        const h = (w) => { if (!w || w.id === win.id) { bot.removeListener('windowClose', h); clearTimeout(t); resolve(true); } };
        const t = setTimeout(() => { bot.removeListener('windowClose', h); resolve(false); }, timeoutMs);
        bot.on('windowClose', h);
    });
    try { bot.closeWindow(win); } catch { /* 忽略 */ }
    return p;
}
