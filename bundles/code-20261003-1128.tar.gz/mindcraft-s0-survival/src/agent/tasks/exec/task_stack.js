// task_stack.js — MC-M1-TASK-02 父子任务机制（Task Stack）
//
// 任务书 §6：嵌套任务不允许每个 Task 手写回调地狱，需要最小 PUSH/WAIT/RESUME 语义：
//   parent tick → runChild(key, factory) → driveTask(child) → child 终态 → parent 拿结构化结果继续。
// 栈本身只做四件事（任务书 §7 守卫）：
//   1. dependency cycle guard：key 已在当前活跃链上 → DEPENDENCY_CYCLE（A→B→A 必须终止）
//   2. max depth：嵌套超限 → DEPENDENCY_TOO_DEEP
//   3. repeated failure budget：同一依赖 key 连续失败超预算 → 不再重试（死亡重置——
//      死亡清背包，装备链路失败的历史原因作废，预算必须重新计）
//   4. task trace：push/pop 记录成调用树，MISSION 结束渲染成文本（任务书 §15）
//
// trace 语义：只记真正的子任务（runChild 驱动的）；Find/Collect 等父任务内部阶段
// 不进树（那是遥测的事），树反映的是任务组合结构本身。
//
// 来源：AltoClef（MIT）TaskSystem 的父子 goal 链 + CompositionUtil 思想级 PORT，
// 非逐行复制；守卫三件套为本轮任务书要求。

import { FailReason } from './task.js';
import { driveTask } from './task_runner.js';

let _nodeSeq = 0;

export class TaskStack {
    constructor(opts = {}) {
        this.maxDepth = opts.maxDepth ?? 6;
        this.maxFailures = opts.maxFailures ?? 2;
        this.entries = [];            // 活跃链 [{key, nodeId}]
        this.roots = [];              // trace 根节点
        this.nodes = new Map();       // nodeId → node
        this.budgets = new Map();     // key → {epoch, fails}
        this.deathEpoch = 0;
    }

    get depth() { return this.entries.length; }

    noteDeath() { this.deathEpoch++; }

    _newNode(key, label, parentId) {
        const id = `n${++_nodeSeq}`;
        const node = {
            id, key, label, parentId,
            startedAt: Date.now(), endedAt: null,
            status: 'RUNNING', failReason: null,
            children: [],
        };
        this.nodes.set(id, node);
        if (parentId) this.nodes.get(parentId).children.push(id);
        return node;
    }

    /** 任务书 §15：根任务也进树（不走守卫、不计预算——根任务就是 MISSION 本身）。 */
    async runRoot(ctx, key, label, factory, opts = {}) {
        const node = this._newNode(key, label, null);
        this.roots.push(node.id);
        this.entries.push({ key, nodeId: node.id });
        ctx.run.counters.maxDepth = Math.max(ctx.run.counters.maxDepth, this.depth);
        let task;
        try {
            task = await driveTask(factory(), ctx, { tickMs: opts.tickMs ?? 250 });
        } finally {
            this.entries.pop();
            node.endedAt = Date.now();
            node.status = task?.status ?? 'INTERNAL';
            node.failReason = task?.failReason ?? null;
        }
        return task;
    }

    /**
     * 驱动一个子任务到终态（守卫失败时同样返回终态任务，parent 无需特判）。
     * @param ctx      makeCtx 产物（ctx.stack 由 makeCtx 注入）
     * @param key      依赖语义键（如 'craft:wooden_pickaxe' / 'acquire:log'），守卫与预算的计量单位
     * @param label    trace 展示名（如 'Craft(wooden_pickaxe ×1)'）
     * @param factory  () => ExecTask
     */
    async run(ctx, key, label, factory, opts = {}) {
        const parentId = this.entries.length ? this.entries[this.entries.length - 1].nodeId : null;

        // 1. cycle guard：key 已在活跃链上
        if (this.entries.some((e) => e.key === key)) {
            ctx.telemetry('child_guard', { key, guard: 'DEPENDENCY_CYCLE', depth: this.depth });
            const t = factory();
            t._fail(FailReason.DEPENDENCY_CYCLE, { key });
            return t;
        }
        // 2. depth guard（含根任务计 1）
        if (this.depth >= this.maxDepth) {
            ctx.telemetry('child_guard', { key, guard: 'DEPENDENCY_TOO_DEEP', depth: this.depth });
            const t = factory();
            t._fail(FailReason.DEPENDENCY_TOO_DEEP, { key, depth: this.depth });
            return t;
        }
        // 3. failure budget：同 key 连败超限（死亡换纪元后重新计）
        const b = this.budgets.get(key);
        if (b && b.epoch === this.deathEpoch && b.fails >= this.maxFailures) {
            ctx.telemetry('child_guard', { key, guard: 'DEPENDENCY_BUDGET', fails: b.fails });
            const t = factory();
            t._fail(FailReason.DEPENDENCY_BUDGET, { key, fails: b.fails });
            return t;
        }

        const node = this._newNode(key, label, parentId);
        this.entries.push({ key, nodeId: node.id });
        ctx.run.counters.childTasks++;
        ctx.run.counters.maxDepth = Math.max(ctx.run.counters.maxDepth, this.depth);
        ctx.telemetry('child_push', { key, label, depth: this.depth });
        let task;
        try {
            task = factory();
            task = await driveTask(task, ctx, { tickMs: opts.tickMs ?? 250, checker: opts.checker });
        } finally {
            this.entries.pop();
            node.endedAt = Date.now();
            node.status = task?.status ?? 'INTERNAL';
            node.failReason = task?.failReason ?? null;
            ctx.telemetry('child_pop', {
                key, label, status: node.status, failReason: node.failReason,
                durationMs: node.endedAt - node.startedAt,
            });
        }
        // 预算记账：成功清零，失败累计
        // MC-M1-TASK-07（G 线）：DEFENSE_ABORT **不计入失败预算**（设计 §3.3 契约③）——
        // 防御抢占不是"这个依赖拿不到"，把它算进预算会让 acquire 被 DEPENDENCY_BUDGET
        // 拒绝，而背包里的战利品明明还在（这正是该契约要防的误判）。
        if (task.status === 'SUCCESS') this.budgets.delete(key);
        else if (task.failReason === FailReason.DEFENSE_ABORT) {
            ctx.telemetry('child_budget_exempt', { key, label });
        }
        else {
            const cur = this.budgets.get(key);
            this.budgets.set(key, { epoch: this.deathEpoch, fails: (cur && cur.epoch === this.deathEpoch ? cur.fails : 0) + 1 });
        }
        return task;
    }

    /** 任务书 §15：渲染任务调用树文本（每局一份）。 */
    renderTrace() {
        const lines = [];
        const render = (nodeId, prefix, isLast) => {
            const n = this.nodes.get(nodeId);
            if (!n) return;
            const dur = n.endedAt ? ((n.endedAt - n.startedAt) / 1000).toFixed(1) + 's' : '...';
            const status = n.status + (n.failReason ? `(${n.failReason})` : '');
            lines.push(`${prefix}${isLast ? '└─ ' : '├─ '}${n.label} [${status}, ${dur}]`);
            n.children.forEach((cid, i) => render(cid, prefix + (isLast ? '   ' : '│  '), i === n.children.length - 1));
        };
        for (const rid of this.roots) {
            const n = this.nodes.get(rid);
            const dur = n.endedAt ? ((n.endedAt - n.startedAt) / 1000).toFixed(1) + 's' : '...';
            const status = n.status + (n.failReason ? `(${n.failReason})` : '');
            lines.push(`${n.label} [${status}, ${dur}]`);
            n.children.forEach((cid, i) => render(cid, '', i === n.children.length - 1));
        }
        return lines.join('\n');
    }
}

/** 子任务驱动统一入口。ctx.stack 不存在时（旧调用方/单测）退化为直接 driveTask。 */
export async function runChild(ctx, key, label, factory, opts = {}) {
    if (!ctx.stack) return driveTask(factory(), ctx, { tickMs: opts.tickMs ?? 250 });
    return ctx.stack.run(ctx, key, label, factory, opts);
}
