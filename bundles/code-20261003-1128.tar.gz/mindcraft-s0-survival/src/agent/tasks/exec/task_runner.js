// task_runner.js — MC-M1-TASK-01 任务执行器（Task Runtime）
//
// driveTask：统一的任务驱动循环（根任务由 TaskRuntime 用，子任务由父任务用）。
// 职责：生命周期推进 / 超时强制 / 死亡事件分发 / 双维度卡死检测（ProgressChecker）/
//       状态迁移遥测。保证任何任务必然进入终态（任务书 §9：禁止永远 RUNNING）。
//
// TaskRuntime：一次 MISSION 的执行容器。bot 级事件（死亡/踢出）→ ctx 分发；
// 终态汇总（结构化 failure reason + 全量计数器）交给 onDone 回调。
// 零 LLM：本文件与 dm_client/decider 无任何 import 关系。

import { ExecTask, TaskStatus, FailReason, sleep } from './task.js';
import { ProgressChecker, runChecker } from './progress_checker.js';
import { TaskStack } from './task_stack.js';
import { resourceDef } from './resources.js';
import { appendFileSync, mkdirSync } from 'fs';
import { dirname } from 'path';

export function makeRunState() {
    return {
        blacklist: new Set(),   // "x,y,z" 最近失败位置（全 run 共享，参照 AltoClef MineOrCollectTask blacklist 语义）
        counters: {
            searches: 0, maxSearchRadius: 0, blockCandidates: 0,
            navAttempts: 0, navFailures: 0,
            miningAttempts: 0, successfulMines: 0,
            relocates: 0, unsafeTargets: 0,
            recoveries: 0, softStuckEvents: 0, hardStuck: 0,
            deaths: 0, taskProgressSteps: 0, idleMs: 0,
            phaseMs: { search: 0, nav: 0, mine: 0, recover: 0 },
            // —— MC-M1-TASK-02 新增 ——
            childTasks: 0, maxDepth: 0,          // 任务栈规模
            recipeResolves: 0, replans: 0,       // 配方解析 / 失配重规划
            depResolutions: 0, depResolutionFailures: 0, // 依赖自主解决率（任务书 §13）
            toolRescues: 0,                      // TOOL_MISSING → Crafting 救援次数
            craftAttempts: 0, craftFailures: 0,  // 合成动作
            tablePlacements: 0, tablePlacementFailures: 0,
            // —— MC-M1-TASK-06 新增 ——
            furnacePlacements: 0, furnacePlacementFailures: 0,  // 熔炉放置
            smeltOk: 0, smeltFailures: 0,                        // 熔炼取出/验证
            flintPlaceRedigs: 0,                                 // 沙砾重埋重挖次数
            ironTargetsSelected: 0,                              // 选中的铁矿石目标数（公平口径遥测伴随计数）
            // —— MC-M1-TASK-07（G 线 S0 生存）新增 —— 见 design stage-00-survival §1.3/§3.3
            defenseScans: 0,            // DefenseLayer 扫描次数
            defenseInterrupts: 0,       // 中断次数（走独立通道，不计 failCounts）
            defenseActions: 0,          // 防御期间动作条数（攻击/后撤/垫塔/封存/脱离）
            defenseFrozenSamples: 0,    // ProgressChecker 因 defenseActive 丢弃的采样
            defenseStuckViolations: 0,  // 冻结期间 hard stuck 成立次数（硬线：必须 0）
            defenseDisengages: 0,       // 降级脱离次数（墙钟/失败预算/hp<8 触发）
        },
        // —— MC-M1-TASK-07：防御层冻结标记。ProgressChecker 唯一能看到的"防御在跑"信号 ——
        // 放 run（而不是 ctx 顶层）是为了让所有子任务共享同一个可见性。
        defenseActive: false,
    };
}

export function makeCtx(bot, { telemetry = () => {}, run = makeRunState(), stackMaxDepth } = {}) {
    return {
        bot,
        run,
        telemetry,
        stack: new TaskStack(stackMaxDepth != null ? { maxDepth: stackMaxDepth } : {}),   // MC-M1-TASK-02 父子任务机制（守卫/预算/trace）
        activeChain: [],          // 活跃任务链（driveTask 推入/弹出；祖先超时强制用）
        deathEvents: [],
        stuckEvents: [],   // [{taskId, at}] 软卡死信号（由 ProgressChecker 投递）
        takeDeath() { return this.deathEvents.shift() ?? null; },
        takeStuck(taskId) {
            const i = this.stuckEvents.findIndex((e) => e.taskId === taskId);
            if (i === -1) return null;
            return this.stuckEvents.splice(i, 1)[0];
        },
    };
}

/**
 * 驱动一个任务到终态并返回该任务。
 * @param task ExecTask 实例
 * @param ctx  makeCtx 产物
 * @param opts { tickMs, checker: ProgressChecker options, parent }
 */
export async function driveTask(task, ctx, opts = {}) {
    task._ctx = ctx;
    let canStart = true;
    try { canStart = await task.canStart(ctx); } catch { canStart = false; }
    if (!canStart) {
        task._fail(FailReason.PRECONDITION);
        await task.cleanup(ctx);
        return task;
    }
    task._transition(TaskStatus.RUNNING, 'start');
    task._startedAt = Date.now();
    try { await task.onStart(ctx); } catch (e) {
        task._fail(FailReason.INTERNAL, { error: String(e).slice(0, 200) });
        await task.cleanup(ctx);
        return task;
    }

    const checker = new ProgressChecker(task, ctx, opts.checker);
    const sampler = runChecker(checker, ctx);
    ctx.activeChain?.push(task);
    try {
        while (!task.isComplete()) {
            // 超时强制（含祖先链）：B2R2-t6/t13 教训——嵌套 tick 会无限推迟祖先的超时检查
            //（祖先的检查只在它自己的 tick 间隙跑，而 tick 内 await 子任务可以任意长）。
            // 任一链上任务到期：是自己则 TIMEOUT，是祖先则 ABORT 放行让链回卷，逐层收口。
            const expired = ctx.activeChain?.find((t) => t.timedOut());
            if (expired) {
                if (expired === task) task._timeout({ elapsedMs: task.elapsed() });
                else task._abort(`ancestor_timeout:${expired.id}`);
                ctx.telemetry('ancestor_timeout_unroll', { task: task.id, expired: expired.id });
                break;
            }
            if (ctx.takeDeath()) {
                ctx.run.counters.deaths++;
                ctx.telemetry('task_on_death', { task: task.id });
                try { await task.onDeath?.(ctx); } catch (e) { ctx.telemetry('on_death_error', { task: task.id, error: String(e).slice(0, 120) }); }
            }
            // —— MC-M1-TASK-07（G 线）：防御中断（设计 §3.2 ②）——
            // 挂在**最内层** driveTask：被抢占时正在跑的是子任务（root 正在 await 它），
            // 只在 root 层检查会漏掉抢占。DEFENSE_ABORT 与 ABORTED 分开命名就是为这里
            // ——两者的恢复动作不同（前者重入、后者上卷）。
            // §3.3 契约③：DEFENSE_ABORT 不计 failCounts / 不烧任务预算 / 不触发 onStuck。
            const intr = ctx.run?.interrupt;
            if (intr) {
                ctx.run.interrupt = null;
                task._fail(FailReason.DEFENSE_ABORT, {
                    threat: intr.threat ?? null, dist: intr.dist ?? null, level: intr.level ?? null,
                });
                ctx.telemetry('task_defense_abort', { task: task.id, threat: intr.threat, dist: intr.dist, level: intr.level });
                break;
            }
            try {
                await task.tick(ctx);
            } catch (e) {
                task._fail(FailReason.INTERNAL, { error: String(e).slice(0, 250) });
                break;
            }
            if (ctx.takeStuck(task.id)) {
                try { await task.onStuck?.('soft', ctx); } catch (e) { ctx.telemetry('stuck_recover_error', { task: task.id, error: String(e).slice(0, 120) }); }
            }
            if (checker.hardStuck()) {
                task._fail(FailReason.NO_PROGRESS, {
                    lastSignature: checker.lastSig,
                    recoveries: checker.recoveries,
                    frozenMs: Date.now() - checker.lastProgressAt,
                });
                break;
            }
            await sleep(opts.tickMs ?? 250);
        }
    } finally {
        const ci = ctx.activeChain ? ctx.activeChain.indexOf(task) : -1;
        if (ci >= 0) ctx.activeChain.splice(ci, 1);
        checker._stopped = true;
        try { await task.cleanup(ctx); } catch { /* 清理失败不影响终态 */ }
    }
    if (!task.isComplete()) task._abort('drive_exit');
    if (task.status === TaskStatus.SUCCESS) {
        try { await task.onSuccess(ctx); } catch (e) { ctx.telemetry('on_success_error', { task: task.id, error: String(e).slice(0, 120) }); }
    } else {
        try { await task.onFailure(ctx, task.failReason); } catch (e) { ctx.telemetry('on_failure_error', { task: task.id, error: String(e).slice(0, 120) }); }
    }
    return task;
}

/**
 * TaskRuntime：一次 MISSION 的执行容器（benchmark runner / DECIDER_MODE=tasked 共用）。
 */
export class TaskRuntime {
    /**
     * @param bot       mineflayer bot 实例（可后置 setBot）
     * @param opts      { mission, telemetryPath?, onDone(summary), tickMs, defense, defenseGazeGuard,
     *                    defenseWallMs, defenseScanMs, defenseTotalMs, maxInterrupts }
     */
    constructor(bot, opts = {}) {
        this.bot = bot;
        this.mission = opts.mission;   // parseMission 产物 {resource, count}
        this.onDone = opts.onDone ?? (() => {});
        this.tickMs = opts.tickMs ?? 250;
        this.telePath = opts.telemetryPath ?? null;
        this.stackMaxDepth = opts.stackMaxDepth ?? null;  // MC-M1-TASK-06：铁链嵌套深（默认仍 6 不变）
        this.summary = null;
        this._startedAt = 0;
        // —— MC-M1-TASK-07（G 线 S0 生存）——
        // 裁决（设计会话 10-02 夜）①：defense **默认关、显式开**（`=== true`）。
        // 理由：合并进主干后不能悄悄改变别的线的回归基线与 B 线的液体操作 ——
        // 尤其是凝视守卫，它拒绝 lookAt 时调用方会拿**旧朝向**继续干活（手册 §3：
        // 服务端按它看到的朝向打射线），那是行为变化，不该由默认值带来。
        // 语义边界：**不传 / 传 false / 传任何非 true 值 = 防御层与凝视守卫都不装**，
        // 于是 driveTask/ProgressChecker/TaskStack 的改动退化成纯 no-op。
        this.defense = opts.defense === true;
        this.defenseGazeGuard = opts.defenseGazeGuard === true;   // 凝视守卫同样默认关
        this.defenseWallMs = opts.defenseWallMs ?? 30000;   // 任务单硬要求①：单次防御墙钟上限
        this.defenseScanMs = opts.defenseScanMs ?? 500;     // 设计 §1.3：500ms 扫描
        // 裁决②：整局防御**总**墙钟上限。maxInterrupts(60) × defenseWallMs(30s) 的最坏情况
        // 是 30 分钟 —— 任务层会反复被抢占、主任务一步都走不了。默认 120s（2 分钟）。
        this.defenseTotalMs = opts.defenseTotalMs ?? 120000;
        this.maxInterrupts = opts.maxInterrupts ?? 60;      // 第二道闸（保证 mission 必然终止）
    }

    setBot(bot) { this.bot = bot; }

    telemetry(event, data = {}) {
        const rec = JSON.stringify({ t: Date.now(), event, ...data });
        try { console.log(`[task-layer] ${rec}`); } catch {}
        if (this.telePath) {
            try {
                if (!this._dirReady) {
                    mkdirSync(dirname(this.telePath), { recursive: true });
                    this._dirReady = true;
                }
                appendFileSync(this.telePath, rec + '\n');
            } catch { /* 遥测失败不影响主循环 */ }
        }
    }

    noteDeath(reason) {
        if (!this._ctx) return;
        this._ctx.deathEvents.push({ t: Date.now(), reason: reason ?? null });
        // 死亡清背包：依赖失败预算的历史归因作废，换纪元重新计（task_stack 语义）
        this._ctx.stack?.noteDeath();
    }

    /** 执行根任务直至终态，resolve 汇总 summary。 */
    async run(rootTask) {
        if (this.telePath) {
            try { mkdirSync(dirname(this.telePath), { recursive: true }); } catch {}
        }
        this._ctx = makeCtx(this.bot, { telemetry: (e, d) => this.telemetry(e, d), stackMaxDepth: this.stackMaxDepth });
        this._startedAt = Date.now();
        this.telemetry('mission_start', { mission: this.mission });
        // 根任务进任务树（trace 根节点；根不走守卫/预算——它就是 MISSION 本身）
        const rootKey = `acquire:${this.mission?.resource ?? 'unknown'}`;
        const rootLabel = `Acquire(${this.mission?.resource ?? '?'} ×${this.mission?.count ?? '?'})`;
        const onDeath = (reason) => this.noteDeath(reason);
        this.bot?.on?.('death', onDeath);
        let defense = null;
        let task = rootTask;
        // 声明在 try **之外**：summary 在 finally 之后构造，要读它。
        // （第一版把它声明在 try 块内，块外的 summary 引用它 ⇒ ReferenceError，
        //   8 条端到端用例全灭——正是 T9 名字级检查该抓的那一类。）
        let defenseSpentMs = 0;
        try {
            // —— MC-M1-TASK-07：挂 DefenseLayer（常驻、独立于任务栈，设计 §3.1）——
            if (this.defense) {
                const { DefenseLayer } = await import('./defense/defense_layer.js');
                const { DefenseTask } = await import('./defense/defense_task.js');
                defense = new DefenseLayer(this.bot, {
                    scanMs: this.defenseScanMs, wallMs: this.defenseWallMs,
                    gazeGuard: this.defenseGazeGuard,
                });
                defense.mount(this._ctx).start();
                this._defenseCtor = DefenseTask;
            }
            // 重入式恢复循环（设计 §3.2）：跑根 → 被抢占就处置 → 用**原 MISSION**重新 replan。
            // 没有威胁时这个循环只跑一轮 ⇒ 与防御上线前逐字等价（回归可比）。
            for (let round = 0; ; round++) {
                const runOpts = { tickMs: this.tickMs };
                task = await this._ctx.stack.runRoot(this._ctx, rootKey, rootLabel, () => task, runOpts);
                const intr = defense?.takeInterrupt?.() ?? null;
                if (!intr) break;                       // 正常终态：成功/失败/超时 → 收工
                if (task.failReason !== FailReason.DEFENSE_ABORT) {
                    // 防御层排到了中断，但根任务不是被它抢占的（例如它刚到、根任务自己先跑完）
                    this.telemetry('defense_interrupt_late', { rootFail: task.failReason, threat: intr.threat });
                    break;
                }
                if (round >= this.maxInterrupts) {
                    // 防 thrash 第二道闸：设计 §3.3 契约④要求"中断计数入 summary + §2.5-D 兜底"，
                    // 但 mission 级也必须有终止保证，否则被反复抢占会永不收敛。
                    this.telemetry('defense_throttle', { rounds: round, threat: intr.threat });
                    task._fail(FailReason.NO_PROGRESS, { error: 'defense_throttle', rounds: round });
                    break;
                }
                // —— 裁决②：整局防御总墙钟 ——
                // 到点后**不再抢占**（只记威胁），并把这一轮还回给主任务接着跑。
                // 不能像 maxInterrupts 那样 break —— 那里主任务已被 ABORT，必须给终态；
                // 这里要的是"主任务继续跑到自然终态"，否则等于因防御而提前判负。
                if (defenseSpentMs >= this.defenseTotalMs) {
                    this.telemetry('defense_budget_exhausted', {
                        spentMs: defenseSpentMs, totalMs: this.defenseTotalMs, round, threat: intr.threat,
                    });
                    if (defense) defense.exhausted = true;     // 扫描继续、只记不排
                    task.restart();
                    continue;
                }
                const d = await this._runDefense(defense, task, intr, round);
                defenseSpentMs += d.ms;
                // ④ 用原 MISSION 重新 replan 根任务（重入即恢复：先查背包，已采的不重采）
                task.restart();
            }
        } finally {
            defense?.stop();
            this.bot?.removeListener?.('death', onDeath);
        }
        const c = this._ctx.run.counters;
        if (defense) {
            const ds = defense.summary();
            c.defenseScans = ds.scans;
            c.defenseInterrupts = ds.interrupts;
        }
        this.summary = {
            mission: this.mission,
            status: task.status,
            failReason: task.failReason,
            detail: task.result,
            startedAt: this._startedAt,
            finishedAt: Date.now(),
            durationMs: Date.now() - this._startedAt,
            finalInventory: { [resourceKey(this.mission)]: countFinal(this.bot, this.mission) },
            transitions: task.transitions.length,
            metrics: c,
            blacklistSize: this._ctx.run.blacklist.size,
            taskTree: this._ctx.stack.renderTrace(),   // 任务书 §15：每局一棵任务调用树
            // —— MC-M1-TASK-07：设计 §5.2 指标 3/5/6 的数据源，独立于 metrics ———
            defense: defense ? defense.summary() : null,
            // 裁决②的可审计量：这一局花在防御上的总墙钟 / 是否撞到总预算
            defenseSpentMs,
            defenseBudgetExhausted: !!defense?.exhausted,
        };
        this.telemetry('mission_end', { ...this.summary, taskTree: undefined });
        try { await this.onDone(this.summary); } catch (e) { console.error('[task-layer] onDone error', e); }
        return this.summary;
    }

    /**
     * ③ DefenseTask 以 **runRoot 语义**驱动（设计 §3.2 ③）：不进 TaskStack 三守卫，
     * 防御失败不污染采集预算。同时置/清 defenseActive（冻结 ProgressChecker，§3.3 契约①）。
     */
    async _runDefense(defense, abortedRoot, intr, round) {
        const ctx = this._ctx;
        ctx.run.defenseActive = true;
        ctx.run.counters.defenseInterrupts++;
        this.telemetry('defense_begin', {
            round, threat: intr.threat, dist: intr.dist, level: intr.level, reason: intr.reason,
            rootTask: abortedRoot.id, rootPhase: abortedRoot.phase ?? null,
        });
        const dTask = new this._defenseCtor({
            wallMs: this.defenseWallMs,
            trigger: { name: intr.threat, id: intr.id, level: intr.level, dist: intr.dist, fusing: !!intr.fusing },
        });
        try {
            await ctx.stack.runRoot(ctx, `defense:${intr.threat}`, `Defense(${intr.threat} d${intr.dist})`, () => dTask, { tickMs: 100 });
        } finally {
            // ⑤ 无论成败都解冻（不允许无限冻结：wallMs 已在 DefenseTask 内部强制）
            ctx.run.defenseActive = false;
            if (dTask.status !== 'SUCCESS') ctx.run.counters.defenseDisengages++;
            defense.noteCleared(intr.threat);
            this.telemetry('defense_end', {
                round, threat: intr.threat, status: dTask.status, failReason: dTask.failReason,
                actions: dTask.state.actions.length, ms: Date.now() - dTask._startedAt,
            });
        }
        // 裁决②的记账口径用**任务实际占用的墙钟**（startedAt→终态），
        // 不用"从触发到收尾的墙上时间"——后者会把防御外的等待也算进去，虚高。
        return { task: dTask, ms: Math.max(0, dTask.elapsed()) };
    }
}

function resourceKey(mission) {
    // 资源无关（TASK-02）：成功物资 = 资源定义的 drops（stone→cobblestone；log→任意原木）
    try { return resourceDef(mission?.resource).drops.join('|'); }
    catch { return mission?.resource ?? 'unknown'; }
}
function countFinal(bot, mission) {
    try {
        const names = resourceDef(mission?.resource).drops;
        return bot.inventory.items().filter((i) => names.includes(i.name)).reduce((s, i) => s + i.count, 0);
    } catch { return 0; }
}
