// responses.js — MC-M1-TASK-07（G 线）：苦力怕/骷髅/回避类处置决策（设计 §2.2/§2.3）
//
// 本文件 = **纯决策**：输入处境快照，输出处置路线 + 理由 + 目标点。
// 走位执行由 DefenseTask 驱动（navTo/place.js 复用），所以这里不碰 pathfinder。
// 好处：决策可以在离线单测里穷举（selftest T6 组），不必起服。
//
// 复用：地面安全判据（岩浆/悬空/无支撑）与 nav.js 的岩浆护栏同源口径，
// 但**独立实现**——nav.js 那个是"导航途中的 5Hz 急停采样"，这里是"规划下一步去哪"，
// 两者的输入时点不同，合并会让离线可测性消失。

import { Vec3 } from 'vec3';
import { CREEPER, RETREAT_HP, DISENGAGE_RANGE, ENDERMAN } from './threat_table.js';
import { losMargin, eyeAt, entityEye, isSolid, eyeOf, eyeDistance } from './los.js';
import { hasWeapon } from './melee_tick.js';

const DIRS8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

/** 该格能不能站（脚下有支撑、身体 1 格空、头顶 1 格空）。 */
export function standable(bot, x, y, z) {
    if (isSolid(bot, new Vec3(x, y, z))) return false;
    if (isSolid(bot, new Vec3(x, y + 1, z))) return false;
    if (!isSolid(bot, new Vec3(x, y - 1, z))) return false;
    return true;
}

/** 地面安全：不是液体、脚下 3 格内不是岩浆。手册 §3：1.16 液体状态用 getProperties()。 */
export function groundSafe(bot, x, y, z) {
    for (let dy = 0; dy >= -3; dy--) {
        let b = null;
        try { b = bot.blockAt(new Vec3(x, y + dy, z)); } catch { return false; }
        if (!b) return false;
        if (b.name === 'lava' || b.name === 'magma_block') return false;
    }
    return true;
}

/** 该格头顶是否露天（用于"不后退进坑"）。 */
export function openSky(bot, x, y, z) {
    for (let dy = 1; dy <= 6; dy++) {
        try {
            const b = bot.blockAt(new Vec3(x, y + dy, z));
            if (b && b.boundingBox === 'block') return false;
        } catch { return false; }
    }
    return true;
}

// ---------------------------------------------------------------- 苦力怕（§2.2）

/**
 * 苦力怕处置决策。
 * @param {object} p { bot, creeper, dist, fusing, hp, hasWeapon }
 * @returns {{route:'disengage'|'kill', target?:Vec3, reason:string,
 *            minRange?:number, targetRange?:number, safeRange?:number}}
 */
export function decideCreeper({ bot, creeper, dist, fusing = false, hp = 20, armed = null }) {
    const weapon = armed ?? hasWeapon(bot);
    // 撤退几何（裁决 2：先改再测，不测"现状"）：
    //   minRange   = 7  wiki 的取消引爆距离（**判据**，不是落点）
    //   targetRange= 9  落点要去的距离（留余量）
    //   safeRange  = 7.5 "到位"的实际判据（**以实际水平距离为准，不以 navTo 返回为准**）
    // 三者分开的原因是 navTo 用 GoalNear(...,1)、允许差 1 格停 ⇒ 按 7 选点实际只能到 ~6.6，
    // 而 creep 进 3 格就开始 fuse（MIC_CREEPER_SMOKE 三局各掉 10 点血）。
    const geom = { minRange: CREEPER.defuseRange, targetRange: CREEPER.retreatTargetRange, safeRange: CREEPER.safeRangeCheck };
    // 已膨胀（fuse 中）：血量与武器都不重要了，**立即后撤**
    //   ⚠ fusing 由调用方给。膨胀的**元数据**判据见 threat_table.creeperFusingMeta；
    //     包围盒判据在 1.16.1 实测不可用（width 恒 0.6），不要再拿它当真值。
    if (fusing) {
        return { route: 'disengage', ...geom, reason: 'fusing_retreat' };
    }
    // 贴脸击杀路线：hp≥12 且有武器（苦力怕近战弱，击退可打断 fuse）
    if (Number(hp) >= 12 && weapon) {
        return { route: 'kill', reason: 'strong_armed_kill', standoff: 2, ...geom };
    }
    // 否则后撤
    return { route: 'disengage', ...geom, reason: weapon ? 'low_hp_retreat' : 'unarmed_retreat' };
}

/**
 * 选后撤落点：远离向量 + 不后退进坑/岩浆 + 优先有退路余量的方向。
 * 评分越高越好；无合法候选返回 null（调用方降级为"就地挖洞/原地防御"）。
 */
export function pickFleeSpot(bot, threatPos, { minRange = CREEPER.defuseRange, maxRange = 20, steps = 3 } = {}) {
    const p = bot.entity?.position;
    if (!p || !threatPos) return null;
    const vx = p.x - threatPos.x, vz = p.z - threatPos.z;
    const len = Math.hypot(vx, vz) || 1;
    const awayX = vx / len, awayZ = vz / len;
    let best = null;
    for (let r = steps; r <= maxRange; r++) {
        for (const side of [0, 0.5, -0.5]) {
            const ang = side;
            const dx = awayX * Math.cos(ang) - awayZ * Math.sin(ang);
            const dz = awayX * Math.sin(ang) + awayZ * Math.cos(ang);
            const x = Math.floor(p.x + dx * r);
            const y = Math.floor(p.y);
            const z = Math.floor(p.z + dz * r);
            if (!groundSafe(bot, x, y, z)) continue;
            if (!standable(bot, x, y, z)) continue;
            const d = Math.hypot(x - threatPos.x, z - threatPos.z);
            if (d < minRange) continue;
            let score = d;                                  // 主项：离苦力怕越远越好
            if (openSky(bot, x, y, z)) score += 3;           // 别退进坑/洞穴（会被堵）
            if (isSolid(bot, new Vec3(x, y + 1, z))) score += 1; // 退到有顶的地方更安全（骷髅打不到）
            if (!best || score > best.score) best = { pos: new Vec3(x + 0.5, y, z + 0.5), score, dist: Number(d.toFixed(1)) };
        }
        if (best) break;   // 最近的合法距离优先（不无谓多跑）
    }
    return best;
}

/** AltoClef fuse 加权：膨胀中的苦力怕在威胁排序里跳到最高（安全度 = 距离×0.2）。 */
export function creeperSafety(creeper, dist, fusing) {
    if (!creeper) return 0;
    return fusing ? dist * 0.2 : dist;
}

// ---------------------------------------------------------------- 骷髅（§2.3）

/**
 * 骷髅处置决策（设计 §2.3 三步法）。
 * @returns {{phase:'cover'|'approach'|'melee'|'withdraw', target?:Vec3, reason:string}}
 */
export function decideSkeleton({ bot, skeleton, dist, hp = 20, shield = false, hostiles = 0 }) {
    // 失败恢复线：多只覆盖射击 + hp<8 → 全速脱离 24 格转 MONITORED
    if (Number(hp) < RETREAT_HP && hostiles >= 2) {
        return { phase: 'withdraw', minRange: DISENGAGE_RANGE, reason: 'hp_low_multi_archers' };
    }
    if (dist < 3.2) return { phase: 'melee', reason: 'in_melee_range' };
    const cover = pickCover(bot, skeleton);
    if (cover) return { phase: 'cover', target: cover.pos, reason: cover.reason, margin: cover.margin };
    if (shield) return { phase: 'approach', reason: 'shield_push' };
    // 无盾无掩体 ⇒ **不接战**（设计 §2.3 硬规则）
    return { phase: 'cover', reason: 'no_cover_no_shield_hold', target: null };
}

/**
 * S1 掩体：就近找一个能断视线的实心角（用体素射线验证 LOS 断开——设计指定）。
 *
 * ⚠⚠ **第七轮改动（生产代码，报告 §2 已列）**：原来这里**只测一条射线**
 *   （`hasLineOfSight(bot, skeletonEye, candidate)`），零余量。真服实测（MIC_SKELETON_N3
 *   trial 2）：决策那一刻确实断了 LOS，但 bot 移过去 38ms + 结算 300ms 后骷髅走位，
 *   射线在 z=10 处 x≈9.2 **擦着掩体外侧**过去 ⇒ 又看得见了。
 *   两处改动：
 *   ① **从落点的眼位发射线**（原来用的是落点**脚底** y，射线比真实视线低 1.62 格
 *      ⇒ 一格高的台阶就可能"挡住"它，而真实眼位其实看得见）。
 *   ② **多射线余量**：在骷髅眼位周围 ±margin 的 3×3×3（默认 ±0.5，共 27 条）上逐条测，
 *      要求**全部**被挡（`losMargin.all`）。对移动目标，单点采样在原理上就没有鲁棒性。
 * @returns {{pos:Vec3, reason:string, margin?:string}|null}
 */
export function pickCover(bot, skeleton, { maxRadius = 6, margin = 0.5, requireAll = true } = {}) {
    const p = bot.entity?.position;
    const eye = entityEye(skeleton);
    if (!p || !eye) return null;
    const px = Math.floor(p.x), py = Math.floor(p.y), pz = Math.floor(p.z);
    let best = null;
    for (let r = 1; r <= maxRadius; r++) {
        for (const [dx, dz] of DIRS8) {
            const x = px + dx * r, z = pz + dz * r;
            for (const y of [py, py + 1]) {
                if (!standable(bot, x, y, z)) continue;
                const candidate = new Vec3(x + 0.5, y, z + 0.5);
                // 视线验证：站这里之后**看不见**骷髅 = 掩体有效（多条射线全断才算）
                const m = losMargin(bot, eyeAt(candidate), eye, { margin, requireAll });
                if (!m.all) continue;
                const d = Math.hypot(x - px, z - pz);
                if (!best || d < best.d) best = { pos: candidate, d, reason: `los_broken(${m.broken}/${m.n})`, margin: `${m.broken}/${m.n}` };
            }
        }
        if (best) break;
    }
    return best ? { pos: best.pos, reason: best.reason, margin: best.margin } : null;
}

// ---------------------------------------------------------------- 末影人 / 通用回避

/** 被激怒的末影人：钻 2 格高掩体（碰撞箱 2.9 格 ⇒ 2 格高才躲得掉）或入水。 */
export function decideEnderman({ bot, enderman, dist, inWater = false }) {
    if (inWater) return { action: 'stay_in_water', reason: 'enderman_teleports_in_water' };
    if (dist < ENDERMAN.teleRange) {
        // 贴脸反而会触发传送 ⇒ 后撤到 4 格外
        return { action: 'back_off', minRange: ENDERMAN.teleRange + 1, reason: 'too_close_teleport' };
    }
    const p = bot.entity?.position;
    if (!p) return { action: 'hold', reason: 'no_pos' };
    const x = Math.floor(p.x), y = Math.floor(p.y), z = Math.floor(p.z);
    // 头顶连续 2 格实心 = 够高的掩体
    if (isSolid(bot, new Vec3(x, y + 1, z)) && isSolid(bot, new Vec3(x, y + 2, z))) {
        return { action: 'crouch_cover', reason: 'two_block_cover' };
    }
    // 找水：附近水格
    for (let r = 1; r <= 6; r++) {
        for (const [dx, dz] of DIRS8) {
            const b = safeName(bot, x + dx * r, y, z + dz * r);
            if (b === 'water') return { action: 'enter_water', target: new Vec3(x + dx * r + 0.5, y, z + dz * r + 0.5), reason: 'water_teleport_bait' };
        }
    }
    return { action: 'move_away', minRange: ENDERMAN.aggroRange, reason: 'keep_distance' };
}

function safeName(bot, x, y, z) {
    try { return bot.blockAt(new Vec3(x, y, z))?.name ?? null; } catch { return null; }
}

/** 通用脱离：走到离所有敌对实体都 ≥ DISENGAGE_RANGE。 */
export function isDisengaged(bot, hostiles, range = DISENGAGE_RANGE) {
    const p = bot.entity?.position;
    if (!p) return false;
    return hostiles.every((h) => Math.hypot(h.position.x - p.x, h.position.z - p.z) >= range);
}

export { eyeOf, eyeDistance };
