// night_decision.js — MC-M1-TASK-07（G 线）：过夜决策树（设计 §2.5）
//
//   A. 在地下作业（挖矿/要塞探索）→ 夜晚无关，继续干活（默认路径——铁镐目标本来就在地下）
//   B. 地表 + 有床 → 睡觉跳夜
//      （前置：16 格无敌对 + 怪物在旁不能睡〔映射：sleepInBed 签名引用 Monster 判定〕）
//   C. 地表 + 无床 → 挖 1×2×3 壁龛封门等到天亮；封存期间防守扫描不停
//   D. 升级触发：同区域一晚内被打断 ≥3 次 → 强制切 C（防 thrash，设计 §7-3）
//   推荐：**基准局不主动做床**（增加变量），默认 A/C；床作为后续优化项留档。
//
// 纯函数：输入是"当前处境快照"，输出是决策 + 理由。可完全离线单测（selftest T5 组），
// 不需要 bot。执行侧（C 的挖龛、B 的睡觉）由 DefenseLayer/Bench harness 落地。

export const NIGHT = {
    // 1.16.1：13000–23000 是夜，12500 起天开始暗。设计 §5.1 用 /time set 12500 起步。
    dusk: 12500, nightStart: 13000, sunrise: 23000, dayStart: 24000,
    // 防 thrash 升级阈值（设计 §2.5-D）：同区域一晚打断 ≥3 → 强制 C
    interruptEscalation: 3,
    // B 的前置：16 格内不能有怪物
    bedSafeRange: 16,
};

/** 是不是夜晚（含黄昏尾巴）。bot.time.time 是 ms tick。 */
export function isNight(bot, { dusk = NIGHT.dusk, sunrise = NIGHT.sunrise } = {}) {
    const t = gameTimeOf(bot);
    if (t == null) return false;
    return t >= dusk && t < sunrise;
}

export function gameTimeOf(bot) {
    // 优先协议真值：1.16.1 客户端收 time_update（1.16 的 bot.time.time 是毫秒）
    const t = Number(bot.time?.time ?? NaN);
    if (Number.isFinite(t) && t > 0) return Math.floor(t / 1000) % 24000;
    return null;
}

/** 有床吗（背包里有 bed 物品即算"能做"，本单不做"造床"计划）。 */
export function hasBed(bot) {
    return (bot.inventory?.items?.() ?? []).some((i) => i.name === 'red_bed' || i.name === 'white_bed' || i.name === 'bed');
}

/** 地下？判据同手册/P2-1 的口径：头顶以上实心块 ≥10（设计 A 分支用它）。 */
export function isUnderground(bot, lookUp = 12) {
    const p = bot.entity?.position;
    if (!p) return false;
    let solid = 0;
    for (let dy = 2; dy <= lookUp; dy++) {
        try {
            const b = bot.blockAt({ x: Math.floor(p.x), y: Math.floor(p.y + dy), z: Math.floor(p.z) });
            if (b && b.boundingBox === 'block') solid++;
        } catch { return false; }
    }
    return solid >= 10;
}

/**
 * 过夜决策。
 * @param {object} p
 * @param {object} p.bot
 * @param {number} p.interruptsTonight  本区域今夜被打断次数
 * @param {number} p.hostilesWithin16     16 格内敌对实体数（B 的前置）
 * @returns {{action:'continue'|'sleep'|'shelter', reason:string, escalate:boolean}}
 */
export function decideNight({ bot, interruptsTonight = 0, hostilesWithin16 = 0 }) {
    if (!isNight(bot)) return { action: 'continue', reason: 'not_night', escalate: false };
    // D 优先于一切：已经 thrash 了就别再"看看情况"
    if (interruptsTonight >= NIGHT.interruptEscalation) {
        return { action: 'shelter', reason: 'escalate_thrash', escalate: true };
    }
    if (isUnderground(bot)) {
        return { action: 'continue', reason: 'underground_work', escalate: false };
    }
    if (hasBed(bot)) {
        // B 的前置没过就不睡：16 格内有怪物时 sleepInBed 直接失败（映射：Monster 判定）
        if (hostilesWithin16 > 0) {
            return { action: 'shelter', reason: 'bed_blocked_by_monsters', escalate: false };
        }
        return { action: 'sleep', reason: 'surface_with_bed', escalate: false };
    }
    return { action: 'shelter', reason: 'surface_no_bed', escalate: false };
}

/** 夜间每 tick 累加打断计数（跨区域不清零；换区域由 resetInterrupts 显式调）。 */
export function bumpInterrupts(state) {
    state.interruptsTonight = (state.interruptsTonight ?? 0) + 1;
    return state.interruptsTonight;
}

export function resetInterrupts(state) {
    state.interruptsTonight = 0;
    return state;
}

/**
 * 深夜"还能再干多久"的判据（返回 0 表示必须收工）：给 §7-3 的 thrash 兜底用。
 * 现在是夜且离天亮不足 2 分钟游戏时间（即 2400 tick = 2 分钟）→ 建议进壁龛。
 */
export function shouldWrapUp(bot, { marginTicks = 2400 } = {}) {
    const t = gameTimeOf(bot);
    if (t == null || !isNight(bot)) return false;
    return (NIGHT.sunrise - t) < marginTicks;
}
