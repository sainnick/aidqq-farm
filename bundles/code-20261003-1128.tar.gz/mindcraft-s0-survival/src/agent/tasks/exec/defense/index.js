// index.js — MC-M1-TASK-07（G 线 / S0 BASIC-survival）汇总导出
//
// 全部实现都落在新目录 `defense/` 下（本文件是唯一入口），与 A 线正在改的
// 窗口操作（crafting_task.js / smelt_task.js）零文件重叠。共享文件只碰
// task_runner.js / progress_checker.js / task.js 三处（改动逐条见报告 §2）。

export * from './threat_table.js';
export * from './los.js';
export * from './gaze_guard.js';
export * from './melee_tick.js';
export * from './shield.js';
export * from './food.js';
export * from './night_decision.js';
export * from './responses.js';
export * from './defense_task.js';
export * from './defense_layer.js';
