// shield.js — MC-M1-TASK-07（G 线）：盾牌薄壳（off-hand 槽 45 自写 equip）
//
// 设计 §2.4：1.16.1 能做、值得做。
//   配方：6 木板 + 1 铁锭（15w37a 起，1.16.1 同款）。任务单硬范围：**只做"有就用"**，
//         本单不把盾加进铁链计划（那会改 TASK-09/CraftingTask 的依赖链，撞 A 线）。
//   收益：挡箭/近战/三叉戟/恶魂火球直击〔wiki·Shield〕——本单只用前两项。
//   边界：激活延迟 5 tick（0.25s, MC-100949）⇒ 起盾要**提前**；被斧击中失效 5s；
//         穿透弩箭/药水/摔落不挡。1.16.1 能否挡爆炸【未核验】⇒ 主策略不依赖挡爆炸。
//   操作：off-hand 槽 45（rmalde 同款判据），bot.activateItem(true) 举盾；
//         armor-manager 不管 off-hand，需自写 equip。
//
// 任务单 §1 末句之外的设计边界：盾牌只当"有就举"的**加成**，任何判定分支都不得
// 以"没盾"为唯一理由接战（否则回归局全裸装会被这条依赖卡死）。

export const OFFHAND_SLOT = 45;

/** 1.16.1 激活延迟（tick）〔MC-100949〕。 */
export const SHIELD_ACTIVATE_TICKS = 5;
export const SHIELD_ACTIVATE_MS = 250;

export function shieldInInventory(bot) {
    return (bot.inventory?.items?.() ?? []).find((i) => i.name === 'shield') ?? null;
}

export function hasShield(bot) { return !!shieldInInventory(bot); }

/** 自写 off-hand 装备（armor-manager 覆盖不到副手槽）。返回是否成功。 */
export function equipShield(bot) {
    const it = shieldInInventory(bot);
    if (!it) return false;
    try {
        // 1.16.1 window_click 的 Slot 是 {present,…} 容器（A 线 TASK-09 正在协议级修复），
        // 这里走 mineflayer 自己的 equip（它自己处理版本形状），不自己拼 window_click。
        bot.equip(it, 'off-hand');
        return true;
    } catch { return false; }
}

/**
 * 举盾。带 5 tick 激活延迟的提前量：调用方应在"预计接战"时提前 activate，
 * 不要等箭已经在飞。返回 true = 已举。
 * @param {object} opts { preActivate:boolean（默认 true）, telemetry }
 */
export function raiseShield(bot, opts = {}) {
    const it = shieldInInventory(bot);
    if (!it) return false;
    try {
        if (bot.heldItem?.name !== 'shield') {
            const cur = bot.inventory.slots[bot.quickBarSlot];
            if (cur && cur.name !== 'shield') bot.equip(it, 'hand');
        }
        bot.activateItem(true);   // true = 持续使用（举着）
        opts.telemetry?.('shield_raise', { activateMs: SHIELD_ACTIVATE_MS });
        return true;
    } catch { return false; }
}

export function lowerShield(bot) {
    try { bot.activateItem(false); } catch { /* 忽略 */ }
}

/** 当前是否在举盾（1.16.1：bot.activeItem 为盾时算举着）。 */
export function isRaising(bot) {
    return !!bot.activeItem && bot.activeItem.name === 'shield';
}
