// los.js — MC-M1-TASK-07（G 线）：体素视线射线（LOS）+ 眼位/安全步进
//
// 设计 §1.3：「LOS：体素射线 ~30 行自写；遮挡判据 = boundingBox==='block'
//   （不用 minecraft-data 的 transparent —— RESEARCH-01 §5.4：≤1.16.2 该属性不可靠
//    mcdata#937）」。
//
// 本文件**只用 bot.blockAt()**，因此可以喂假 bot 完全离线单测（selftest T3 组）：
// 假 bot 只需实现 blockAt(Vec3) → {boundingBox}，不需要真服务器。
//
// 算法：Amanatides & Woo 3D DDA 体素遍历（精确、不漏格、不重复访问），
// 起点格（bot 自己所在的格）不判遮挡（否则贴墙站时永远"看不见东西"），
// 终点格判遮挡（目标在墙里就是看不见——这正是要的语义）。

import { Vec3 } from 'vec3';

/** 方块是否遮挡视线。唯一判据是 boundingBox==='block'（设计 §1.3 指定）。 */
export function blocksSight(block) {
    if (!block) return false;
    // 未加载区块 blockAt 返回 null → 保守当作"不遮挡"？
    // 不：手册 §3「读方块一律用 bot.blockAt」且 prismarine 对未加载格返回 null，
    // 把 null 当不遮挡会让"墙后"被读成"可见"。但把 null 当遮挡会让跨区块边缘全部
    // 误判遮挡。折中：未加载 = 不可见（los=false），由调用方的 monitor 档兜底。
    return block.boundingBox === 'block';
}

function isLoaded(block) { return !!block; }

/**
 * 体素 DDA 射线，**带逐格读数**（遥测用）。`raycastBlock` 是它的薄封装。
 *
 * ⚠⚠ **逐轴的"到下一格边界"必须用每根轴自己的方向**（第七轮修的真 bug）：
 *   旧实现把它写成一个共用闭包
 *       `const bound = (c, cell) => (stepX > 0 ? (cell + 1 - c) : (c - cell));`
 *   三根轴一起用 ⇒ **y/z 用了 x 的方向**。只要 `dy`（或 `dz`）与 `dx` **异号**
 *   （最常见的就是"目标在下方、且在 +x 侧"——近战、骷髅这两组都是这个几何），
 *   对应轴的 tMax 就被算大 ⇒ 遍历留在**错误的高度层**里走、**永远踩不到终点格**
 *   ⇒ 一路走到 maxSteps（256 格），中途撞上地板/未加载区块
 *   ⇒ **空旷场地上把"看得见"读成"看不见"**。
 *   离线证据：96 例（4 个眼距 × 24 个方位角）里 **46 例**结论与正确实现相反，
 *   全部满足 `dx>0 && dy<0`：`bench/stages/basic-survival/analysis/dda_offline_check.mjs`。
 *   真服证据：1.4 格外、25×25 空旷竞技场上的 4 只僵尸 `canSeeEntity` 恒 false
 *   （上一轮 MIC_MELEE_N3），逐格读数见 `micro/raydiag` 场景。
 *   另：旧实现**没有"射线走完就停"**这一条，收尾全靠"踩到终点格"或 maxSteps。
 *   现在按参数 t∈[0,1] 收尾（`past_end`）。
 *
 * ⚠ 零位移轴的 tMax 必须**显式保持 Infinity**：`Infinity * 0 === NaN`，
 *   NaN 会让后面所有 `<=`/`>` 比较为 false ⇒ 遍历永远挑中同一根轴。
 *
 * @returns {{hit:{x,y,z,index,unloaded?}|null, hitKind:string, steps:number, cells:Array}}
 *   `hitKind`：`solid` / `endpoint_solid` / `unloaded` / `past_end` / `exhausted` / `degenerate`。
 *   `hitKind==='unloaded'` 是**读通道失败**（区块没加载），与"读到实心方块"必须分开看
 *   ——手册 §5：把"我们没读到"折算进"看见了墙"是最常见的静默误判。
 *   `cells` 只在 `opts.trace===true` 时收集（默认关：canSeeEntity 在热路径上逐实体调用）。
 */
export function raycastBlockTrace(bot, from, to, opts = {}) {
    const maxSteps = opts.maxSteps ?? 256;
    const trace = !!opts.trace;
    const cells = [];
    let x = Math.floor(from.x), y = Math.floor(from.y), z = Math.floor(from.z);
    const ex = Math.floor(to.x), ey = Math.floor(to.y), ez = Math.floor(to.z);
    const dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
    const done = (hitKind, hit) => ({ hit, hitKind, steps: cells.length, cells });
    if (dx === 0 && dy === 0 && dz === 0) return done('degenerate', null);

    const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
    const tDeltaX = dx === 0 ? Infinity : Math.abs(1 / dx);
    const tDeltaY = dy === 0 ? Infinity : Math.abs(1 / dy);
    const tDeltaZ = dz === 0 ? Infinity : Math.abs(1 / dz);
    // ★ 逐轴：方向取该轴自己的 step
    let tMaxX = Infinity, tMaxY = Infinity, tMaxZ = Infinity;
    if (dx !== 0) tMaxX = tDeltaX * (stepX > 0 ? (x + 1 - from.x) : (from.x - x));
    if (dy !== 0) tMaxY = tDeltaY * (stepY > 0 ? (y + 1 - from.y) : (from.y - y));
    if (dz !== 0) tMaxZ = tDeltaZ * (stepZ > 0 ? (z + 1 - from.z) : (from.z - z));

    // 起点格不判遮挡（否则贴墙站时永远"看不见东西"）；终点格判（目标在墙里就是看不见）。
    for (let steps = 1; steps <= maxSteps; steps++) {
        // 推进到下一格（取 t 最小的轴；并列时固定先 x 再 y 再 z，保证可复现）
        let tNext, axis;
        if (tMaxX <= tMaxY && tMaxX <= tMaxZ) { tNext = tMaxX; axis = 'x'; }
        else if (tMaxY <= tMaxZ) { tNext = tMaxY; axis = 'y'; }
        else { tNext = tMaxZ; axis = 'z'; }
        // 射线参数 t∈[0,1]：越界 ⇒ 已经走过终点 ⇒ 通视（不再靠 maxSteps 兜底）
        if (!(tNext <= 1 + 1e-9)) return done('past_end', null);
        if (axis === 'x') { x += stepX; tMaxX += tDeltaX; }
        else if (axis === 'y') { y += stepY; tMaxY += tDeltaY; }
        else { z += stepZ; tMaxZ += tDeltaZ; }

        const b = safeBlockAt(bot, x, y, z);
        const isEnd = (x === ex && y === ey && z === ez);
        if (trace) {
            cells.push({
                x, y, z, axis, t: Number(tNext.toFixed(6)), end: isEnd,
                name: b?.name ?? null, boundingBox: b?.boundingBox ?? null, loaded: isLoaded(b),
            });
        }
        if (b === null) return done('unloaded', { x, y, z, index: steps, unloaded: true });
        if (blocksSight(b)) return done(isEnd ? 'endpoint_solid' : 'solid', { x, y, z, index: steps });
        if (isEnd) return done('endpoint', null);
    }
    return done('exhausted', null);
}

/**
 * 体素 DDA 射线。返回被遮挡的那一格，或 null（通视）。
 * @returns {{x:number,y:number,z:number,index:number,unloaded?:boolean}|null}
 */
export function raycastBlock(bot, from, to, opts = {}) {
    return raycastBlockTrace(bot, from, to, opts).hit;
}

function safeBlockAt(bot, x, y, z) {
    try { return bot.blockAt(new Vec3(x, y, z)); } catch { return null; }
}

/** bot 眼高（MC 1.16.1 玩家眼高 1.62）。`eyeOf` 与掩体采样共用这一个真源。 */
export const EYE_HEIGHT = 1.62;

/** bot 眼位（MC 1.16.1 玩家眼高 1.62）。 */
export function eyeOf(bot) {
    const p = bot.entity?.position;
    if (!p) return null;
    return new Vec3(p.x, p.y + (bot.entity?.height ?? 1.8) * 0.9, p.z);
}

/** 站位点 → 该点上的**眼位**（掩体/射线采样必须用眼位，不能用脚底）。 */
export function eyeAt(v) {
    return v ? new Vec3(v.x, v.y + EYE_HEIGHT, v.z) : null;
}

/**
 * 掩体余量采样：不是只测"目标眼位这一个点"，而是在它周围 ±margin 的 3×3×3
 * 网格上逐条测（27 条），返回**是否全部被挡**。
 *
 * ⚠ 为什么必须多条（第七轮，生产结论）：`pickCover` 原来只测**一条**射线
 *   （眼位正中心）。真服实测：决策那一刻断了 LOS，bot 移过去 38ms + 结算 300ms 后
 *   骷髅走位 0.3 格，射线**擦着掩体外侧**过去 ⇒ 又看得见了 ⇒ 掩体零余量。
 *   单点采样对移动目标天然没有鲁棒性；余量必须进**判据**，不能只靠"再等 300ms"。
 *
 * @returns {{all:boolean, broken:number, n:number, rays:Array}}
 */
export function losMargin(bot, fromEye, targetEye, { margin = 0.5, requireAll = true } = {}) {
    if (!fromEye || !targetEye) return { all: false, broken: 0, n: 0, rays: [] };
    const rays = [];
    for (const ox of [-margin, 0, margin]) {
        for (const oy of [-margin, 0, margin]) {
            for (const oz of [-margin, 0, margin]) {
                const t = new Vec3(targetEye.x + ox, targetEye.y + oy, targetEye.z + oz);
                const tr = raycastBlockTrace(bot, fromEye, t);
                rays.push({ offset: [ox, oy, oz], los: tr.hit === null, hitKind: tr.hitKind, hit: tr.hit });
            }
        }
    }
    const broken = rays.filter((r) => !r.los).length;
    const all = broken === rays.length;
    return { all: requireAll ? all : broken > 0, broken, n: rays.length, rays };
}

/** 实体眼位（怪物眼高取 height*0.9，末影人按 2.9 高）。 */
export function entityEye(entity) {
    if (!entity?.position) return null;
    const h = Number(entity.height ?? 1.8);
    return new Vec3(entity.position.x, entity.position.y + h * 0.9, entity.position.z);
}

/**
 * bot 眼位 → 目标眼位是否通视。false = 被墙挡或区块未加载。
 */
export function hasLineOfSight(bot, targetPoint, from = null) {
    const a = from ?? eyeOf(bot);
    if (!a || !targetPoint) return false;
    return raycastBlock(bot, a, targetPoint) === null;
}

/** bot → 实体 是否通视（便捷版，距离用眼位差）。 */
export function canSeeEntity(bot, entity) {
    const e = entityEye(entity);
    if (!e) return false;
    return hasLineOfSight(bot, e);
}

/** 眼位距离（格）。 */
export function eyeDistance(bot, entity) {
    const a = eyeOf(bot), b = entityEye(entity);
    if (!a || !b) return Infinity;
    return a.distanceTo(b);
}

/** 水平距离（格）——脱离/绕行判据用水平分量（垂直差不该算"没脱身"）。 */
export function horizontalDistance(bot, entity) {
    const p = bot.entity?.position, q = entity?.position;
    if (!p || !q) return Infinity;
    return Math.hypot(p.x - q.x, p.z - q.z);
}

/** 某点是否被方块占据（实心）。用于掩体/塔的落点校验。 */
export function isSolid(bot, v) {
    const b = safeBlockAt(bot, Math.floor(v.x), Math.floor(v.y), Math.floor(v.z));
    return blocksSight(b);
}
