// melee_tick.js — MC-M1-TASK-07（G 线）：MeleeTick 近战原语（自写，不加载 mineflayer-pvp）
//
// 设计 §2.1 + §4：
//   目标选择：LOS 且 <3.2 格中最近者；粘滞（已锁目标优先，stage-03 同款）
//   节奏：满冷却才出手——实现 proxy = AltoClef 同款「冷却归一化 ≥0.99 才攻击」
//         〔AbstractKillEntityTask.java〕
//   武器优先级（换武器）：iron_sword > stone_sword > wooden_sword > iron_axe > 赤手
//   站位：背对墙面/坑沿防击退；一次只锁一只；多只围攻 → 退到 1 格宽通道口"卡口逐只打"
//   撤退线：hp<8 → 停手撤退
//   成功判定：目标 entityGone/死亡事件；失败：连击 5 次未死且自身 hp<8 → 转 MONITORED 撤退
//
// 为什么不用 mineflayer-pvp 1.3.2（设计 §4 已裁）：#52 可隔墙攻击（不公平 + 自伤）、
// #53 无法停止/无法设攻击范围（与中断语义 + 苦力怕距离管理直接冲突）。
// 本文件只用 mineflayer 核心的 bot.attack()，全部策略自己控制 ⇒ 天然可停、可限距、可离线测。
//
// ⚠ 攻击冷却口径（离线定版，实跑校准）：
//   1.9+ 伤害 = f(attackStrength)，attackStrength = clamp((now - lastAttack) / cooldownMs, 0, 1)，
//   **由服务端时钟算**，客户端读不到自己的 attackStrengthT。1.16.1 cooldownMs = 1/attackSpeedModifier：
//   剑 1.6 → 0.625s〔wiki·Sword〕、斧 1.0 → 1.0s、赤手 1.0s。
//   所以本文件用**客户端墙钟**做等价 proxy（bot.time 优先，回落 Date.now()）。
//   偏差来源：命令往返延迟（LAN <5ms，量级远小于 0.625s，可接受）。校准项记在报告里。

import { Vec3 } from 'vec3';
import { sleep } from '../task.js';
import { MELEE_RANGE, ATTACK_COOLDOWN_GATE, WEAPON_PRIORITY, RETREAT_HP, isHostile } from './threat_table.js';
import { canSeeEntity, eyeDistance, hasLineOfSight, entityEye, isSolid } from './los.js';

export const ATTACK_COOLDOWN = {
    // cooldownMs = 1 / attackSpeedModifier（1.16.1 ToolMaterial/AxeItem）
    sword: 625,   // 1/1.6〔wiki·Sword〕
    axe: 1000,    // 1/1.0
    fist: 1000,   // 1/1.0（赤手）
    unverified: ['axe-vs-sword DPS 序（设计 §2.1 标未核验）'],
};

export function weaponCooldownMs(itemName) {
    if (!itemName) return ATTACK_COOLDOWN.fist;
    if (itemName.endsWith('_sword')) return ATTACK_COOLDOWN.sword;
    if (itemName.endsWith('_axe')) return ATTACK_COOLDOWN.axe;
    return ATTACK_COOLDOWN.fist;
}

/** bot 侧单调时钟：优先 bot.time（游戏 tick ms），回落墙钟。 */
function nowMs(bot) { return Number(bot?.time?.time ?? 0) || Date.now(); }

/** 攻击冷却归一化强度（0..1），proxy 见文件头口径说明。 */
export function attackStrength(bot, lastAttackAt, itemName) {
    if (!lastAttackAt) return 1;
    const cd = weaponCooldownMs(itemName);
    return Math.max(0, Math.min(1, (nowMs(bot) - lastAttackAt) / cd));
}

/** 包里最优武器（设计 §2.1 优先级表）。返回 {item, slot} 或 null。 */
export function bestWeapon(bot) {
    let best = null;
    for (const it of bot.inventory?.items?.() ?? []) {
        const rank = WEAPON_PRIORITY.indexOf(it.name);
        if (rank < 0) continue;
        if (!best || rank < best.rank) best = { rank, item: it };
    }
    return best ? { item: best.item, slot: best.item.slot, name: best.item.name } : null;
}

export function hasWeapon(bot) { return !!bestWeapon(bot); }

/** 实体是否已消失（死亡/卸载）。Odyssey waitForMobRemoved 同款轮询思想。 */
export function isEntityGone(bot, entity) {
    if (!entity) return true;
    if (entity.isValid === false) return true;
    if (entity.id != null && !entity.isValid) return true;
    // 1.16 mineflayer：实体离视野/死亡后从 bot.entities 移除
    const still = Object.values(bot.entities ?? {}).some((e) => e.id === entity.id);
    if (!still) return true;
    if (typeof entity.health === 'number' && entity.health <= 0) return true;
    return false;
}

const DIRS8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

/**
 * 选站位（防击退 / 多只围攻时收窄）。
 * 纯 blockAt 计算，可离线断言：
 *   - backWall：bot→目标 连线方向上，bot 身后 1 格是实心 → 抗击退（设计 §2.1「背靠墙防击退」）
 *   - narrow  ：周围 8 邻里实心 ≥5 → 近似 1 格宽通道口（多只围攻时优先，卡口逐只打）
 * @returns {{pos:Vec3, score:number, why:string}|null}
 */
export function pickStance(bot, target, hostiles = []) {
    const t = target.position;
    if (!t) return null;
    const px = Math.floor(t.x), py = Math.floor(t.y), pz = Math.floor(t.z);
    // 以目标为中心 1..2 格的环上取候选（不能站进目标格，也不能离太远）
    const cand = [];
    for (let r = 1; r <= 2; r++) {
        for (const [dx, dz] of DIRS8) {
            const x = px + dx * r, y = py, z = pz + dz * r;
            if (isSolid(bot, new Vec3(x, y, z))) continue;         // 站位本身要空
            if (!isSolid(bot, new Vec3(x, y - 1, z))) continue;    // 脚下要有支撑（实心）
            if (isSolid(bot, new Vec3(x, y + 1, z)) || isSolid(bot, new Vec3(x, y + 2, z))) continue; // 站位要能容纳
            cand.push(new Vec3(x + 0.5, y, z + 0.5));
        }
    }
    if (!cand.length) return null;
    const multi = hostiles.filter((h) => h !== target && h.position
        && Math.hypot(h.position.x - t.x, h.position.z - t.z) < 4).length;
    let best = null;
    for (const pos of cand) {
        // 背后墙：防击退要求「墙在 bot 身后」——即沿 (pos − target) 方向再往外 1 格。
        // ⚠ 离线自检第一次跑就抓到这里的符号写反了（写成朝 target 的方向），
        //   后果是"面前有墙"也会被判成 back_wall —— 那恰恰是会挨打的位置。
        const vx = pos.x - t.x, vz = pos.z - t.z;
        const len = Math.hypot(vx, vz) || 1;
        const backX = Math.floor(pos.x + (vx / len) * 1), backZ = Math.floor(pos.z + (vz / len) * 1);
        const hasBackWall = isSolid(bot, new Vec3(backX, Math.floor(pos.y), backZ));
        // 窄道评分：站位 8 邻实心数
        let walls = 0;
        for (const [dx, dz] of DIRS8) if (isSolid(bot, new Vec3(Math.floor(pos.x) + dx, Math.floor(pos.y), Math.floor(pos.z) + dz))) walls++;
        const dist = Math.hypot(pos.x - t.x, pos.z - t.z);
        let score = 0;
        let why = [];
        if (hasBackWall) { score += 3; why.push('back_wall'); }
        if (multi >= 2) { score += walls * 0.5; why.push(`narrow(${walls})`); } // 卡口逐只打
        score += (2.0 - Math.abs(dist - 2)) * 0.5;                           // 贴到 2 格左右最佳
        if (!best || score > best.score) best = { pos, score, why: why.join('+') || 'open' };
    }
    return best;
}

/**
 * 目标选择：粘滞优先 —— 已锁目标仍满足「可见 + <range」就继续锁它。
 * @returns {object|null}
 */
export function pickTarget(bot, hostiles, { locked = null, range = MELEE_RANGE } = {}) {
    if (locked && !isEntityGone(bot, locked)
        && eyeDistance(bot, locked) < range + 1.5
        && canSeeEntity(bot, locked)) return locked;
    let best = null;
    for (const e of hostiles) {
        const d = eyeDistance(bot, e);
        if (d >= range) continue;
        if (!canSeeEntity(bot, e)) continue;
        if (!best || d < best.d) best = { entity: e, d };
    }
    return best ? best.entity : null;
}

/**
 * 场上我们该管且看得见的敌对实体（供 DefenseTask/DefenseLayer 复用）。
 *
 * ⚠⚠ **不能按 `entity.type` 预过滤 `'hostile'`/`'animal'`** ——
 *   mineflayer 4.38 的 `entity.type` 来自 minecraft-data 的注册表项
 *   （`entities.js:163` `entity.type = entityData.type || 'object'`），
 *   而 **1.16.1 的 107 个实体 `type` 全是 `"mob"`**（101 mob + 6 UNKNOWN，
 *   实测 `minecraft-data('1.16.1').entitiesArray` 的 type 分布 = {mob:101, UNKNOWN:6}），
 *   **没有任何一个实体是 `'hostile'` 或 `'animal'`**。
 *   ⇒ 原来那句 `if (e.type && e.type !== 'hostile' && e.type !== 'animal') continue;`
 *   会把**每一个**真实实体都跳过 ⇒ 本函数在 1.16.1 上**恒返回空数组** ⇒
 *   `meleeBeat` 永远 `no_target`、DefenseTask 的近战分支（`defense_task.js:298/392`）
 *   统计到的 `hostiles` 永远是 0 ⇒ **近战在真服上从未生效过**。
 *   （离线自检抓不到：`fake_world.mjs` 的 `makeEntity` 默认 `type:'hostile'`，
 *     又是"假 bot 比真库宽"，与本单的 `entity.look` 同一族错误。见 T13。）
 * 正确口径：**只按 `name` 走威胁表**（`isHostile` 已是按名字 + 维度的权威判据），
 * 玩家/掉落物/箭矢的名字都不在表里，自然被排除，不需要额外的 type 预过滤。
 */
export function visibleHostiles(bot, dimensionId = 0) {
    const out = [];
    for (const e of Object.values(bot.entities ?? {})) {
        if (!isHostile(e.name, dimensionId)) continue;   // 名字判据即权威（含维度）
        if (e.type === 'player') continue;                // 玩家本人永远不是目标
        if (!canSeeEntity(bot, e)) continue;
        out.push(e);
    }
    return out;
}

/**
 * 一次攻击拍：冷却满 → 换最优武器 → lookAt（force=false！手册 §3）→ attack。
 * 抽成单拍是为了让 DefenseTask 的状态机能逐步驱动、逐步记遥测（任务单硬要求 2）。
 *
 * @returns {{fired:boolean, reason:string, targetId:number|null, strength:number}}
 */
export async function meleeBeat(ctx, state, opts = {}) {
    const bot = ctx.bot;
    const range = opts.range ?? MELEE_RANGE;
    const hostiles = opts.hostiles ?? visibleHostiles(bot, opts.dimensionId ?? 0);
    const target = pickTarget(bot, hostiles, { locked: state.locked, range });
    if (!target) { state.locked = null; return { fired: false, reason: 'no_target', targetId: null, strength: 0 }; }
    state.locked = target;
    const dist = eyeDistance(bot, target);
    if (dist >= range) return { fired: false, reason: 'out_of_range', targetId: target.id, strength: attackStrength(bot, state.lastAttackAt, state.weaponName) };

    // 武器（设计 §2.1：包里有更高档就换手）
    const w = bestWeapon(bot);
    if (w) {
        if (state.weaponName !== w.name || state.weaponSlot !== w.slot) {
            try { bot.equip(w.item, 'hand'); } catch { /* 无手可换则继续用当前 */ }
            state.weaponName = w.name;
            state.weaponSlot = w.slot;
        }
    }
    // 冷却门（proxy 归一化 ≥0.99）
    const strength = attackStrength(bot, state.lastAttackAt, state.weaponName);
    if (strength < ATTACK_COOLDOWN_GATE) {
        return { fired: false, reason: 'cooldown', targetId: target.id, strength };
    }
    // 朝向：force=false 才真的发旋转包（手册 §3 / TASK-08 实测）
    const eye = entityEye(target);
    if (eye) {
        try {
            await bot.lookAt(eye, false);   // 凝视守卫在 DefenseLayer 挂载时包了这层
            await sleep(30);
        } catch { /* 旋转失败不放弃攻击 */ }
    }
    try { bot.attack(target); } catch (e) { return { fired: false, reason: 'attack_threw', targetId: target.id, strength, error: String(e).slice(0, 80) }; }
    state.lastAttackAt = nowMs(bot);
    state.swings = (state.swings ?? 0) + 1;
    state.lastTargetId = target.id;
    return { fired: true, reason: 'fired', targetId: target.id, strength, dist: Number(dist.toFixed(2)), weapon: state.weaponName ?? 'fist' };
}

/** 新建 MeleeTick 的可变状态（DefenseTask 持有）。 */
export function makeMeleeState(locked = null) {
    return { locked, lastAttackAt: 0, weaponName: null, weaponSlot: null, swings: 0, lastTargetId: null };
}

/** 撤退线判据（设计 §2.1：hp<8 停手撤退）。 */
export function shouldRetreat(bot, hp = bot.health) { return Number(hp) < RETREAT_HP; }

/**
 * 击杀确认轮询（有界）。Odyssey waitForMobRemoved 思想。
 * @returns {boolean} true = 目标已消失
 */
export async function waitEntityGone(bot, entity, { timeoutMs = 5000, tickMs = 250 } = {}) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
        if (isEntityGone(bot, entity)) return true;
        await sleep(tickMs);
    }
    return isEntityGone(bot, entity);
}

/** LOS 便捷导出（DefenseTask 用）。 */
export { canSeeEntity, hasLineOfSight, eyeDistance };
