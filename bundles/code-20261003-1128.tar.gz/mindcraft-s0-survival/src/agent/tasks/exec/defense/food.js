// food.js — MC-M1-TASK-07（G 线）：进食薄壳（auto-eat 保留 + 撤退先吃 + EMERGENCY 让位）
//
// 设计 §2.6：
//   阈值：auto-eat 现有插件（startAt=14）保留——sprint 需饥饿 >6、回血需 18+、
//         easy 下饥饿耗尽只掉到 10HP〔wiki·Difficulty〕；14 吃可保持回血余量。
//   白名单：只吃熟食/bread/golden_carrot；生鸡肉/腐肉不吃（食物中毒 debuff 干扰战斗）。
//   战斗中：hp<8 撤退**先吃后战**；EMERGENCY 期间进食**让位**
//         （AltoClef 同思想：needsToEatCritical 才打断防御〔MobDefenseChain.prioritizeEating〕）。
//
// 与 agent.js 既有 auto-eat 配置（startAt 14 / bannedFood 含 rotten_flesh、spider_eye、
// poisonous_potato、pufferfish、chicken）保持一致：这里不重新配置插件，只做**战斗语义**：
// 何时该主动吃（撤退线）、何时必须让位（EMERGENCY）。

import { sleep } from '../task.js';

export const EAT_START_AT = 14;          // 与 agent.js auto-eat 配置同口径
export const CRITICAL_HP = 8;            // 撤退线血量（同 threat_table.RETREAT_HP）
export const EAT_TARGET_HP = 12;         // 「先吃后战」吃到多少再上
export const EAT_TARGET_FOOD = 16;

/** 白名单（设计 §2.6：熟食/bread/golden_carrot）。 */
export const FOOD_WHITELIST = [
    'cooked_beef', 'cooked_porkchop', 'cooked_chicken', 'cooked_mutton', 'cooked_rabbit', 'cooked_salmon', 'cooked_cod',
    'bread', 'golden_carrot', 'golden_apple', 'baked_potato', 'cookie', 'apple',
];

/** 明确禁吃（与 agent.js bannedFood 对齐，防食物中毒 debuff 干扰战斗）。 */
export const FOOD_BANNED = new Set(['rotten_flesh', 'spider_eye', 'poisonous_potato', 'pufferfish', 'chicken', 'raw_chicken', 'porkchop', 'beef', 'cod', 'salmon', 'rabbit', 'mutton']);

export function isEdibleForCombat(name) {
    return FOOD_WHITELIST.includes(name) && !FOOD_BANNED.has(name);
}

/** 饥饿度（0..20）。 */
export function foodLevel(bot) { return Number(bot.food ?? 0); }

/** 该不该主动吃（非插件层语义：撤退线 + 战斗前补给）。 */
export function shouldEatNow(bot, { hp = bot.health, emergency = false } = {}) {
    if (emergency) return false;                       // EMERGENCY 让位（设计 §2.6）
    if (foodLevel(bot) < EAT_START_AT) return true;
    if (Number(hp) <= CRITICAL_HP) return true;         // hp<8 撤退先吃
    return false;
}

/** 有可吃的合规食物吗（插件 bannedFood 之外的第二道闸）。 */
export function hasCombatFood(bot) {
    return (bot.inventory?.items?.() ?? []).some((i) => isEdibleForCombat(i.name));
}

/**
 * 「先吃后战」：直接吃 1~2 个合规食物（不依赖 auto-eat 插件时序），
 * 直到 hp ≥ targetHp 或 food ≥ targetFood 或食物用尽。带界。
 * @returns {Promise<{ate:number, reason:string, hp:number, food:number}>}
 */
export async function eatBeforeFight(bot, opts = {}) {
    const targetHp = opts.targetHp ?? EAT_TARGET_HP;
    const targetFood = opts.targetFood ?? EAT_TARGET_FOOD;
    const maxItems = opts.maxItems ?? 4;
    let ate = 0;
    for (let i = 0; i < maxItems; i++) {
        if (Number(bot.health) >= targetHp && foodLevel(bot) >= targetFood) break;
        const food = (bot.inventory.items() ?? []).find((it) => isEdibleForCombat(it.name) && it.count > 0);
        if (!food) break;
        const before = food.count;
        try {
            bot.consume();                       // 吃手上那摞
        } catch { break; }
        ate++;
        // 等服务端把这一口结算完（背包增量确认：手上那摞 −1）
        const t0 = Date.now();
        while (Date.now() - t0 < 1500) {
            const cur = bot.inventory.items().find((it) => it === food);
            if (!cur || cur.count < before) break;
            await sleep(100);
        }
    }
    const r = { ate, reason: ate ? 'ate' : 'nothing_edible', hp: Number(bot.health ?? 0), food: foodLevel(bot) };
    opts.telemetry?.('eat_before_fight', r);
    return r;
}

/** auto-eat 插件是否已加载（没加载要告警：否则 startAt 14 语义不成立）。 */
export function autoEatLoaded(bot) { return !!bot.autoEat; }
