// defense_task.js — MC-M1-TASK-07（G 线）：DefenseTask 状态机 + 执行体
//
// ��计 §3.4：IDLE →(trigger)→ ASSESS → ENGAGE → CLEAR → IDLE
//                              → DISENGAGE（同威胁连续失败 3 次 或 hp<8）→ 脱离至 24 格 → IDLE
// 任务单硬要求 ①：**单次防御必须有墙钟上限**（参数，默认 30s）。到点强制降级为
//                 "脱离到 24 格 + 标记回避"，然后解冻 ProgressChecker；冻结期间独立计时，不允许无限冻结。
// 任务单硬要求 ②：防御期间每一次动作（攻击/后撤/垫塔/封存）都记遥测，带**威胁类型和距离**。
// 任务单硬要求 ③：只对看得见的实体做反应（见 los.js / threat_table.classify 的 losStrict）。
//
// —— 为什么要拆成「纯 reducer + 执行体」——
// 任务单 §2.1 要求「用**构造的事件流**离线单测状态机」。所以 `reduce()` 不碰 bot、不读时钟
// （`now` 由入参注入），可以穷举；`DefenseTask.tick()` 只做"把世界翻译成 input"。
// 这样离线能验的是真状态机，不是"跑通一遍就算"。

import { ExecTask, sleep } from '../task.js';
import { navTo } from '../nav.js';
import {
    THREAT_RANGE, DISENGAGE_RANGE, RETREAT_HP,
    threatDef, creeperFusingNow,
} from './threat_table.js';
import { canSeeEntity, eyeDistance, entityEye, isSolid } from './los.js';
import { makeMeleeState, meleeBeat, visibleHostiles, shouldRetreat } from './melee_tick.js';
import { decideCreeper, pickFleeSpot, decideSkeleton, decideEnderman, isDisengaged } from './responses.js';
import { hasShield, raiseShield, lowerShield, equipShield } from './shield.js';
import { shouldEatNow, eatBeforeFight, hasCombatFood } from './food.js';
import pf from 'mineflayer-pathfinder';

/** DefenseTask 内部状态机的五个状态（设计 §3.4）。 */
export const DefenseState = {
    IDLE: 'IDLE',
    ASSESS: 'ASSESS',
    ENGAGE: 'ENGAGE',
    CLEAR: 'CLEAR',
    DISENGAGE: 'DISENGAGE',
};

/** 单次防御的墙钟上限默认值（任务单硬要求 ①，参数化）。 */
export const DEFAULT_DEFENSE_WALL_MS = 30000;

/** 同威胁连续失败预算（设计 §3.2 ③）。 */
export const DEFAULT_FAIL_BUDGET = 3;

// ================================================================= 纯状态机（离线可测）

export function makeDefenseState(overrides = {}) {
    return {
        state: DefenseState.IDLE,
        threat: null,            // {name, id, action, level, dist}
        plan: null,              // ASSESS 产出的处置路线
        startedAt: 0,            // 本次防御的墙钟起点
        deadlineAt: 0,           // 墙钟上限（startedAt + wallMs）——冻结期间的独立计时
        wallMs: DEFAULT_DEFENSE_WALL_MS,
        failures: new Map(),     // 威胁名 → 连续失败次数（**按威胁分桶**，换威胁不串味）
        melee: makeMeleeState(),
        actions: [],             // 本次防御的动作日志（任务单硬要求 ②）
        avoid: new Set(),        // 标记回避（脱离后写这里）
        lastReason: null,
        ...overrides,
    };
}

/** 记一条动作遥测（攻击/后撤/垫塔/封存/脱离…都走这里，保证字段一致可审计）。 */
export function noteAction(state, action, detail = {}) {
    const rec = {
        at: Date.now(), action,
        threat: state.threat?.name ?? null,
        threatId: state.threat?.id ?? null,
        dist: state.threat?.dist ?? null,      // 任务单硬要求 ②：必须带距离
        state: state.state,
        ...detail,
    };
    state.actions.push(rec);
    return rec;
}

function budgetOf(state, name) { return state.failures.get(name) ?? 0; }

/**
 * 纯状态机转移。**不碰 bot、不读时钟**（now 入参）。
 * @param {object} state
 * @param {object} input 事件流的一格
 * @param {number} now   注入的墙钟（ms）
 * @returns {{changed:boolean, from:string, to:string, reason:string, forced?:boolean}}
 */
export function reduce(state, input, now = Date.now()) {
    const from = state.state;
    const to = (s, reason, extra = {}) => { state.state = s; state.lastReason = reason; return { changed: s !== from, from, to: s, reason, ...extra }; };

    // ① 墙钟上限：任何非 IDLE 状态到点**强制**降级为脱离（任务单硬要求 ①）
    //    这是"冻结期间独立计时、不允许无限冻结"的结构保证。
    if (state.state !== DefenseState.IDLE && now >= state.deadlineAt) {
        noteAction(state, 'deadline_force_disengage', { wallMs: state.wallMs, elapsedMs: now - state.startedAt });
        state.plan = { route: 'disengage', minRange: DISENGAGE_RANGE, reason: 'wall_deadline' };
        return to(DefenseState.DISENGAGE, 'wall_deadline', { forced: true });
    }

    switch (input?.type) {
        case 'trigger': {
            if (state.state !== DefenseState.IDLE) {
                // 已在防御中：新威胁只升级（EMERGENCY 抢占），不重置墙钟
                // ——重置墙钟会让"一直被骚扰"变成无限防御。
                const higher = (input.level ?? 0) > (state.threat?.level ?? 0);
                if (higher) {
                    state.threat = { ...state.threat, ...input };
                    return to(DefenseState.ASSESS, 'threat_escalated');
                }
                return { changed: false, from, to: from, reason: 'already_defending' };
            }
            state.threat = { ...input };
            state.startedAt = now;
            state.deadlineAt = now + state.wallMs;
            state.actions.length = 0;
            state.melee = makeMeleeState();
            noteAction(state, 'trigger', { level: input.level, fusing: !!input.fusing });
            return to(DefenseState.ASSESS, 'triggered');
        }
        case 'assess_done': {
            if (state.state !== DefenseState.ASSESS) return { changed: false, from, to: from, reason: 'not_assessing' };
            state.plan = input.plan;
            noteAction(state, 'plan', { plan: input.plan });
            // 决策直接给出"只能脱离"（无武器/低血）时，**不浪费一次 ENGAGE 预算**
            if (input.plan?.route === 'disengage' || input.plan?.phase === 'withdraw') {
                return to(DefenseState.DISENGAGE, 'plan_is_disengage');
            }
            return to(DefenseState.ENGAGE, 'plan_committed');
        }
        case 'beat_result': {
            // ENGAGE 中的一次攻击拍/一步走位
            if (state.state === DefenseState.ENGAGE) {
                if (input.cleared) return to(DefenseState.CLEAR, 'threat_cleared');
                if (input.lowHp) {
                    noteAction(state, 'low_hp_withdraw', { hp: input.hp });
                    state.plan = { route: 'disengage', minRange: DISENGAGE_RANGE, reason: 'low_hp' };
                    return to(DefenseState.DISENGAGE, 'low_hp');
                }
                return { changed: false, from, to: from, reason: 'engaging' };
            }
            return { changed: false, from, to: from, reason: 'not_engaging' };
        }
        case 'engagement_failed': {
            if (state.state !== DefenseState.ENGAGE) return { changed: false, from, to: from, reason: 'not_engaging' };
            const name = state.threat?.name ?? 'unknown';
            const f = budgetOf(state, name) + 1;
            state.failures.set(name, f);
            noteAction(state, 'engagement_failed', { failures: f, reason: input.reason ?? null });
            if (f >= (input.budget ?? DEFAULT_FAIL_BUDGET)) {
                state.plan = { route: 'disengage', minRange: DISENGAGE_RANGE, reason: `fail_budget(${f})` };
                return to(DefenseState.DISENGAGE, 'fail_budget', { failures: f });
            }
            return { changed: false, from, to: from, reason: 'retry_same_threat', failures: f };
        }
        case 'disengaged': {
            if (state.state !== DefenseState.DISENGAGE) return { changed: false, from, to: from, reason: 'not_disengaging' };
            const name = state.threat?.name;
            if (name) state.failures.set(name, 0);   // 成功脱离 = 该威胁预算清零
            if (state.plan?.avoidMark !== false) state.avoid.add(name);
            noteAction(state, 'disengaged', { marked: name });
            state.threat = null; state.plan = null; state.startedAt = 0; state.deadlineAt = 0;
            return to(DefenseState.IDLE, 'disengaged');
        }
        case 'cleared': {
            if (state.state !== DefenseState.CLEAR) return { changed: false, from, to: from, reason: 'not_clearing' };
            noteAction(state, 'cleared');
            const name = state.threat?.name;
            if (name) state.failures.set(name, 0);
            state.threat = null; state.plan = null; state.startedAt = 0; state.deadlineAt = 0;
            return to(DefenseState.IDLE, 'cleared');
        }
        case 'death': {
            // 防御期间死亡：走既有死亡路径；DefenseLayer 重生后重新武装
            noteAction(state, 'death_during_defense');
            state.threat = null; state.plan = null; state.startedAt = 0; state.deadlineAt = 0;
            return to(DefenseState.IDLE, 'death');
        }
        case 'abandon': {
            noteAction(state, 'abandon', { reason: input.reason ?? null });
            state.threat = null; state.plan = null; state.startedAt = 0; state.deadlineAt = 0;
            return to(DefenseState.IDLE, 'abandon');
        }
        default:
            return { changed: false, from, to: from, reason: `unknown_input:${input?.type}` };
    }
}

// ================================================================= 执行体

/**
 * DefenseTask：以 **runRoot 语义**驱动（设计 §3.2 ③），不进 TaskStack 三守卫——
 * 防御失败不污染采集预算、不烧任务预算、不触发 onStuck。
 */
export class DefenseTask extends ExecTask {
    constructor(opts = {}) {
        super('DefenseTask', { timeoutMs: opts.wallMs ? opts.wallMs + 5000 : DEFAULT_DEFENSE_WALL_MS + 5000 });
        this.wallMs = opts.wallMs ?? DEFAULT_DEFENSE_WALL_MS;
        this.failBudget = opts.failBudget ?? DEFAULT_FAIL_BUDGET;
        this.dimensionId = opts.dimensionId ?? 0;
        this.state = makeDefenseState({ wallMs: this.wallMs });
        this.trigger = opts.trigger ?? null;    // {name, id, level, dist, fusing}
        this._ticks = 0;
        this._noSpot = 0;                       // 连续找不到脱离落点的次数（见 _doDisengage）
    }

    /** 硬性独立计时：墙钟到点后 tick() 不再执行任何战斗动作，只走脱离。 */
    get deadlineAt() { return this.state.deadlineAt; }
    get overDeadline() { return this.state.state !== DefenseState.IDLE && Date.now() >= this.state.deadlineAt; }

    progressSignature(ctx) {
        const s = this.state;
        // 绑定任务语义：目标距离分档 + 动作计数 + 状态。**不能**用纯位移（战斗走位位移很大，
        // 但那不是进展；用位移会让 checker 永远以为有进展——手册 §5 归因纪律的同一理由）。
        const bucket = s.threat ? Math.round(Math.min(s.threat.dist ?? 99, 40) / 4) : -1;
        return `${s.state}|${s.threat?.name ?? '-'}|d${bucket}|a${s.actions.length}|f${budgetOf(s, s.threat?.name)}`;
    }

    getProgress(ctx) {
        return {
            state: this.state.state, threat: this.state.threat?.name ?? null,
            dist: this.state.threat?.dist ?? null, actions: this.state.actions.length,
            remainingMs: Math.max(0, this.state.deadlineAt - Date.now()),
        };
    }

    async onStart(ctx) {
        this._noSpot = 0;
        if (this.trigger) this._apply(ctx, { type: 'trigger', ...this.trigger });
    }

    /** 每一步都把动作遥测推给 ctx（任务单硬要求 ②：复核时能还原"它看见了什么、做了什么"）。 */
    _apply(ctx, input) {
        const before = this.state.actions.length;
        const r = reduce(this.state, input, Date.now());
        for (let i = before; i < this.state.actions.length; i++) {
            const a = this.state.actions[i];
            ctx.telemetry('defense_action', a);
            ctx.run.counters.defenseActions = (ctx.run.counters.defenseActions ?? 0) + 1;
        }
        if (r.changed) {
            ctx.telemetry('defense_state', { from: r.from, to: r.to, reason: r.reason, threat: this.state.threat?.name ?? null, forced: !!r.forced });
        }
        return r;
    }

    async tick(ctx) {
        const bot = ctx.bot;
        this._ticks++;
        const s = this.state;

        // 1) 墙钟闸门优先于一切（任务单硬要求 ①）
        if (s.state !== DefenseState.IDLE && Date.now() >= s.deadlineAt) {
            this._apply(ctx, { type: 'beat_result', cleared: false });   // reduce 内部强制转 DISENGAGE
            return this._doDisengage(ctx);
        }

        switch (s.state) {
            case DefenseState.IDLE:
                // 走到 IDLE = 本次防御已收尾（cleared / disengaged / death / abandon 都归这里）
                if (this._startedAt > 0) this._succeed({ outcome: 'idle', actions: s.actions.length });
                return;
            case DefenseState.ASSESS: return this._doAssess(ctx);
            case DefenseState.ENGAGE: return this._doEngage(ctx);
            case DefenseState.CLEAR: {
                // CLEAR 的确认：威胁消失 + hp/food 达标（设计 §3.4）
                if (s.threat && !this._threatStillPresent(ctx, s.threat)) {
                    const name = s.threat.name;
                    if (Number(bot.health) < RETREAT_HP + 4 && hasCombatFood(bot) && !shouldEatNow(bot, { hp: bot.health, emergency: true })) {
                        await eatBeforeFight(bot, { telemetry: (e, d) => ctx.telemetry(e, d) });
                    }
                    this._apply(ctx, { type: 'cleared' });
                    this._succeed({ outcome: 'cleared', actions: s.actions.length, threat: name });
                    return;
                }
                // 还没清干净 → 继续打
                this._apply(ctx, { type: 'beat_result', cleared: false });
                return this._doEngage(ctx);
            }
            case DefenseState.DISENGAGE: return this._doDisengage(ctx);
            default: return;
        }
    }

    /** ASSESS：按威胁表选处置路线。 */
    async _doAssess(ctx) {
        const bot = ctx.bot;
        const s = this.state;
        const th = s.threat ?? {};
        const entity = th.id != null ? (bot.entities ?? {})[th.id] : null;
        const dist = th.dist ?? (entity ? eyeDistance(bot, entity) : Infinity);
        const def = threatDef(th.name, this.dimensionId);
        let plan;
        switch (def?.action) {
            case 'creeper': {
                // fuse 判据走**元数据 [15]**（MIC_FUSEPROBE 实测：2.92 格时 -1→1；width 恒 0.6 不可用）
                const fusing = th.fusing || creeperFusingNow(entity);
                plan = decideCreeper({ bot, creeper: entity, dist, fusing, hp: bot.health });
                break;
            }
            case 'skeleton': {
                const hostiles = visibleHostiles(bot, this.dimensionId).length;
                plan = decideSkeleton({ bot, skeleton: entity, dist, hp: bot.health, shield: hasShield(bot), hostiles });
                break;
            }
            case 'gaze': {
                plan = decideEnderman({ bot, enderman: entity, dist, inWater: this._inWater(bot) });
                break;
            }
            default:
                plan = { route: 'engage', action: 'melee', reason: 'default_melee' };
        }
        plan.avoidMark = true;
        this._apply(ctx, { type: 'assess_done', plan });
    }

    /** ENGAGE：MeleeTick / 后撤 / 拉近，每拍都记遥测。 */
    async _doEngage(ctx) {
        const bot = ctx.bot;
        const s = this.state;
        const th = s.threat ?? {};
        const entity = th.id != null ? (bot.entities ?? {})[th.id] : null;
        if (!entity || this._threatGone(ctx, th)) {
            this._apply(ctx, { type: 'beat_result', cleared: true });
            return;
        }
        const dist = eyeDistance(bot, entity);
        th.dist = Number(dist.toFixed(2));

        if (shouldRetreat(bot)) {
            this._apply(ctx, { type: 'beat_result', cleared: false, lowHp: true, hp: bot.health });
            return;
        }

        const plan = s.plan ?? {};
        // —— 路线分流 ——
        if (plan.route === 'disengage' || plan.phase === 'withdraw') {
            noteAction(s, 'withdraw_planned', { plan });
            ctx.telemetry('defense_action', s.actions[s.actions.length - 1]);
            this._apply(ctx, { type: 'beat_result', cleared: false });
            return this._doDisengage(ctx);
        }
        if (plan.action === 'stay_in_water' || plan.action === 'crouch_cover') {
            // 末影人被动处置：不接战，只确认自己已脱身
            const ok = plan.action === 'stay_in_water' ? this._inWater(bot) : this._hasTwoBlockCover(bot);
            noteAction(s, 'enderman_hold', { ok, action: plan.action });
            ctx.telemetry('defense_action', s.actions[s.actions.length - 1]);
            if (ok) this._apply(ctx, { type: 'beat_result', cleared: true });
            else this._apply(ctx, { type: 'engagement_failed', reason: 'cover_unavailable' });
            return;
        }
        if (plan.phase === 'cover' && plan.target) {
            noteAction(s, 'move_to_cover', { to: [plan.target.x, plan.target.y, plan.target.z], dist: th.dist });
            ctx.telemetry('defense_action', s.actions[s.actions.length - 1]);
            await navTo(ctx, new pf.goals.GoalNear(plan.target.x, plan.target.y, plan.target.z, 1), { timeoutMs: 12000, label: 'defense_cover' });
            const stillVisible = entity && canSeeEntity(bot, entity);
            if (!stillVisible) this._apply(ctx, { type: 'beat_result', cleared: true });
            else this._apply(ctx, { type: 'engagement_failed', reason: 'cover_not_broken_los' });
            return;
        }
        if (plan.phase === 'approach') {
            // 举盾直线推进（保持面向骷髅）。盾有 5 tick 激活延迟 ⇒ 提前举。
            equipShield(bot);
            const raised = raiseShield(bot, { telemetry: (e, d) => ctx.telemetry(e, d) });
            noteAction(s, raised ? 'shield_approach' : 'approach_unshielded', { dist: th.dist });
            ctx.telemetry('defense_action', s.actions[s.actions.length - 1]);
            const to = entityEye(entity);
            if (to) { try { await bot.lookAt(to, false); } catch { /* 忽略 */ } }
            const ok = await navTo(ctx, new pf.goals.GoalNear(entity.position.x, entity.position.y, entity.position.z, 2), { timeoutMs: 15000, label: 'defense_approach' });
            this._apply(ctx, ok ? { type: 'beat_result', cleared: false } : { type: 'engagement_failed', reason: 'approach_nav_fail' });
            return;
        }
        // 默认：近战一拍
        const beat = await meleeBeat(ctx, s.melee, { dimensionId: this.dimensionId });
        if (beat.fired) {
            noteAction(s, 'attack', { targetId: beat.targetId, dist: beat.dist ?? th.dist, weapon: beat.weapon, strength: Number(beat.strength?.toFixed(3)) });
            ctx.telemetry('defense_action', s.actions[s.actions.length - 1]);
        } else {
            noteAction(s, `beat_${beat.reason}`, { targetId: beat.targetId, dist: th.dist });
            ctx.telemetry('defense_action', s.actions[s.actions.length - 1]);
        }
        if (beat.reason === 'no_target' || beat.reason === 'out_of_range') {
            // 够不着：算一次失败（预算耗尽会转脱离，不会无限磨）
            this._apply(ctx, { type: 'engagement_failed', reason: beat.reason });
            return;
        }
        this._apply(ctx, { type: 'beat_result', cleared: this._threatGone(ctx, th) });
        await sleep(50);
    }

    /** DISENGAGE：走到全部敌对实体 ≥24 格外，标回避，回 IDLE。 */
    async _doDisengage(ctx) {
        const bot = ctx.bot;
        const s = this.state;
        const minRange = s.plan?.minRange ?? DISENGAGE_RANGE;
        const hostiles = visibleHostiles(bot, this.dimensionId);
        if (hostiles.length === 0 || isDisengaged(bot, hostiles, minRange)) {
            noteAction(s, 'disengaged', { minRange, hostiles: hostiles.length });
            ctx.telemetry('defense_action', s.actions[s.actions.length - 1]);
            this._apply(ctx, { type: 'disengaged' });
            this._succeed({ outcome: 'disengaged', threat: s.threat?.name ?? null, minRange, actions: s.actions.length });
            return;
        }
        const spot = pickFleeSpot(bot, hostiles[0].position, { minRange: Math.min(minRange, 16) });
        if (spot) {
            this._noSpot = 0;
            noteAction(s, 'retreat', { to: [spot.pos.x, spot.pos.y, spot.pos.z], dist: spot.dist, minRange });
            ctx.telemetry('defense_action', s.actions[s.actions.length - 1]);
            await navTo(ctx, new pf.goals.GoalNear(spot.pos.x, spot.pos.y, spot.pos.z, 1), { timeoutMs: 15000, label: 'defense_retreat' });
        } else {
            // 几何上脱离不了（四周无合法落点：坑/岩浆/窄道）。**不能就这么转到任务超时**：
            // 那样每次脱离都会白烧满整段墙钟（实跑墙钟上限 30s），而主任务在这段时间里
            // 一步都走不了 —— 表现为"夜里零进展"。两次落空就收工：标记回避、回 IDLE，
            // 并把"脱离不可达"单独记一条遥测，让报告能统计它（而不是静默吞掉）。
            // 离线自检的计时就是靠这条逮到的：throttle 场景原本 79s（3 轮 × 各自转到超时）。
            this._noSpot++;
            noteAction(s, 'retreat_no_spot', { minRange, attempts: this._noSpot });
            ctx.telemetry('defense_action', s.actions[s.actions.length - 1]);
            if (this._noSpot >= 2) {
                const name = s.threat?.name ?? null;
                ctx.telemetry('defense_disengage_unreachable', { threat: name, minRange, attempts: this._noSpot });
                this._apply(ctx, { type: 'disengaged' });
                this._succeed({ outcome: 'disengage_unreachable', threat: name, minRange, attempts: this._noSpot });
                return;
            }
        }
        await sleep(100);
    }

    async cleanup(ctx) {
        try { lowerShield(ctx.bot); } catch { /* 忽略 */ }
    }

    // —— 探针（可被离线单测替换/断言）——
    _inWater(bot) {
        const p = bot.entity?.position;
        if (!p) return false;
        try { return bot.blockAt({ x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z) })?.name === 'water'; } catch { return false; }
    }
    _hasTwoBlockCover(bot) {
        const p = bot.entity?.position;
        if (!p) return false;
        return isSolid(bot, { x: Math.floor(p.x), y: Math.floor(p.y) + 1, z: Math.floor(p.z) })
            && isSolid(bot, { x: Math.floor(p.x), y: Math.floor(p.y) + 2, z: Math.floor(p.z) });
    }
    _threatGone(ctx, th) {
        const bot = ctx.bot;
        const e = th?.id != null ? (bot.entities ?? {})[th.id] : null;
        if (!e) return true;
        if (typeof e.health === 'number' && e.health <= 0) return true;
        if (eyeDistance(bot, e) >= THREAT_RANGE.monitored + 4) return true;
        return false;
    }
    _threatStillPresent(ctx, th) { return !this._threatGone(ctx, th); }
}
