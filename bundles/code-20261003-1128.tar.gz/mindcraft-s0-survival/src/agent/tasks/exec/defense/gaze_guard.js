// gaze_guard.js — MC-M1-TASK-07（G 线）：末影人凝视守卫（"不看它"的工程化）
//
// 设计 §1.4：
//   - 全局规则：任何 bot.lookAt 调用前过一道检查——视线向量与「bot→末影人眼位」向量的
//     夹角 < θ（初值 10°，实测校准）且末影人 <64 格 → **拒绝该 lookAt**（换站位或换目标）。
//   - 行进默认俯仰：pitch ≤ −15°（看地面），天然避开眼位注视；挖矿时向下看，天然安全。
//   - 禁止用南瓜头盔方案（占用头盔格、合成链里不存在）。
//
// 为什么做成"猴补丁 bot.lookAt"而不是在每个调用点加检查：
//   设计要求的是**全局**规则，而 lookAt 的调用点散落在 place.js / nav.js / collect 任务等
//   共享文件里（还正在被 A 线改）。逐点改 = 大量共享文件冲突面。
//   在 DefenseLayer 挂载时对 bot.lookAt 做一次可逆包装，是**唯一**能在不改任何共享文件
//   的前提下满足"任何 lookAt 都过闸"的做法。uninstall() 还原；被拒调用写遥测。
//
// 离线可测：install/uninstall/wouldStare 只依赖 bot.entity 与 bot.entities，
// 假 bot（selftest T4 组）能直接断言。

import { Vec3 } from 'vec3';
import { ENDERMAN } from './threat_table.js';
import { eyeOf, entityEye } from './los.js';

/** 行进默认俯仰（度，设计 §1.4：pitch ≤ −15° 看地面）。 */
export const TRAVEL_PITCH_DEG = -15;

function angleDeg(a, b) {
    const dot = a.x * b.x + a.y * b.y + a.z * b.z;
    const na = Math.hypot(a.x, a.y, a.z), nb = Math.hypot(b.x, b.y, b.z);
    if (na === 0 || nb === 0) return 180;
    return (Math.acos(Math.max(-1, Math.min(1, dot / (na * nb)))) * 180) / Math.PI;
}

/**
 * bot 当前朝向的单位向量（yaw/pitch → 向量）。
 *
 * ⚠⚠ **必须读 `entity.yaw` / `entity.pitch`，不能读 `entity.look`**
 *   mineflayer 4.38 的实体是 prismarine-entity 的 `Entity`，它**只有 `yaw`/`pitch`
 *   两个数字字段，根本没有 `look` 属性**（实测 `'look' in new Entity(1) === false`；
 *   `entities.js:927 fetchEntity` 就是 `new Entity(id)`，没补任何属性）。
 *   原来这里写的是 `e.look ?? {x:0,y:0}` ⇒ 线上**永远**取到 {0,0}，
 *   于是 `lookVector` 恒等于「朝 +z」，`wouldStare` 的夹角判据整条是死的：
 *   无论 bot 实际朝哪，都只判断「+z 方向有没有末影人」。
 *   （离线自检一直绿，是因为 `fake_world.mjs` 的假 bot 自己造了一个 `entity.look`
 *     —— 假 bot 补了真库没有的字段，把真 bug 盖住了。见 T13。）
 *
 * ⚠⚠⚠ **第七轮再修一处：y 与 z 两个分量的符号原来都是反的**（离线推导 + 对着
 *   mineflayer 自己的数学核过，`selftest_defense.mjs` T14 有钉子）：
 *   mineflayer 4.38 的**内部**约定与线上（notch）约定差一个变换：
 *     · `conversions.js:31` `fromNotchianYaw = euclideanMod(PI - ψ, 2π)`
 *       ⇒ 内部 yaw = π − 线上 yaw，**面向 +z（南）时内部 yaw = π**；
 *     · `conversions.js:35` `fromNotchianPitch = euclideanMod(-θ + π, 2π) - π`
 *       ⇒ 内部 pitch = −线上 pitch，**内部 pitch 正 = 抬头**（可交叉验证：
 *         `physics.js:361 bot.lookAt` 用 `pitch = atan2(delta.y, 地面距离)`，
 *         目标在头顶上方时 delta.y>0 ⇒ pitch>0）。
 *   把线上约定 `(ψ,θ)` 的朝向向量 `(-sinψ·cosθ, -sinθ, cosψ·cosθ)` 代进去：
 *     ψ = π − yaw, θ = −pitch ⇒ **`(-sin(yaw)·cos(pitch), +sin(pitch), -cos(yaw)·cos(pitch))`**
 *   原来写的是 `(-sin(yaw)·cos p, -sin p, +cos(yaw)·cos p)`：
 *     ① z 反号 ⇒ 守卫评估的是**背对方向**（bot 真在盯末影人时它说"没盯" ⇒ 放行）；
 *     ② y 反号 ⇒ 抬头被当成低头（低头行进时反而会误判"在盯"）。
 *   上一轮 gaze 组 3/3 PASS 之所以没暴露：那一局的 bot 是 `bot.look(0,0,false)`，
 *   而 yaw=0 在真约定下**恰好是背对 +z 的末影人**（z 反号把两者抵消了），
 *   算出的 9.37° 数值本身对（几何 = atan(0.99/6)），但"bot 正对着末影人"这个前提
 *   在那一局**不成立**。⇒ 那一局的 PASS 是**巧合成立**，不是守卫在正确工作。
 *
 * @returns {Vec3|null} null = 朝向读不到（实体缺失 / 数值非有限）
 */
export function lookVector(bot) {
    const e = bot.entity;
    if (!e) return null;
    const yaw = Number(e.yaw ?? 0);
    const pitch = Number(e.pitch ?? 0);
    if (!Number.isFinite(yaw) || !Number.isFinite(pitch)) return null;
    // 内部约定（见上）：yaw = π − 线上 yaw ⇒ 面向 +z 是 yaw=π；pitch 正 = 抬头。
    const cp = Math.cos(pitch);
    return new Vec3(-Math.sin(yaw) * cp, Math.sin(pitch), -Math.cos(yaw) * cp);
}

/**
 * 会不会「盯上」某只末影人。
 * @returns {{stare:boolean, deg:number|null, dist:number|null}}
 */
export function wouldStare(bot, enderman, opts = {}) {
    const theta = opts.thetaDeg ?? ENDERMAN.gazeGuardDeg;
    const maxRange = opts.maxRange ?? ENDERMAN.aggroRange;
    const e = entityEye(enderman);
    const from = eyeOf(bot);
    if (!e || !from) return { stare: false, deg: null, dist: null };
    const dist = from.distanceTo(e);
    if (dist > maxRange) return { stare: false, deg: null, dist };   // 64 格外不触发
    const look = lookVector(bot);
    // 朝向读不到（实体缺失 / yaw·pitch 非有限）⇒ **按"会盯上"处理**。
    // 这是个安全守卫：读不到就不许看，漏判（stare:false）会让 bot 在未知朝向下
    // 照直盯上末影人把它激怒——那正是这个守卫要防的事。
    if (!look) return { stare: true, deg: null, dist, reason: 'facing_unreadable' };
    const toEnderman = new Vec3(e.x - from.x, e.y - from.y, e.z - from.z).normalize();
    const deg = angleDeg(look, toEnderman);
    return { stare: deg < theta, deg, dist };
}

/** 场上所有会触发凝视的末影人（按最近排序）。 */
export function staringEndermen(bot, opts = {}) {
    const out = [];
    const seen = new Set();
    // ⚠ bot.entities 是**以 id 为键的对象**（mineflayer 4.x），不是 Map/数组 ——
    //   对它 for...of 会抛 "object is not iterable"。必须 Object.values。
    for (const e of Object.values(bot.entities ?? {})) {
        if (e?.name !== 'enderman') continue;
        if (seen.has(e.id)) continue;
        seen.add(e.id);
        const r = wouldStare(bot, e, opts);
        if (r.stare) out.push({ entity: e, deg: r.deg, dist: r.dist });
    }
    return out.sort((a, b) => a.dist - b.dist);
}

/**
 * 安全 lookAt：会盯上末影人就拒绝（返回 false，不动朝向）。
 * 拒绝时把俯仰压到 TRAVEL_PITCH_DEG（看地面）作为安全退路。
 * @returns {boolean} true = 已执行；false = 被守卫拒绝
 */
export function safeLookAt(bot, point, opts = {}) {
    if (!point) return false;
    const risky = staringEndermen(bot, opts);
    if (!risky.length) return false; // 调用方照常 lookAt
    const trace = opts.telemetry;
    try {
        // 退路：把视线压到地面俯仰（设计 §1.4「行进默认俯仰」）
        // ⚠⚠ **签名**：`bot.look(yaw, pitch, force)` 收的是**两个弧度数字**
        //   （physics.js:329；`bot.lookAt` 自己也是先算 yaw/pitch 再调它，:357-362）。
        //   原来这里传的是 `bot.look(new Vec3(...), true)` —— 第一个参数是 Vec3、
        //   第二个是 `true`，于是 `yawChange = Math.round((Vec3 - yaw) / sens)` = **NaN**
        //   ⇒ `bot.entity.yaw += NaN` 把朝向永久污染成 NaN（NaN !== 0 所以那个提前
        //   return 也拦不住），而 pitch 被写成 `true - pitch` ≈ +1.05 rad（俯视 60°），
        //   **压根没压到 −15°**。实测证据见报告 §4.14。
        // ⚠ **force 必须传 false**：force=true 在 4.38 里只改 lastSentYaw/lastSentPitch
        //   就 return，物理 tick 认为朝向没变、**一个包都不发**（手册 §3）⇒ 服务端
        //   仍按旧朝向算，末影人照样被激怒。这个守卫的目的正是让服务端改朝向。
        // ⚠ `bot.look` 是 async：调用方不 await 时必须自己 .catch()，
        //   否则一次 rejection 就是 unhandledRejection ⇒ Node 20 直接终止整局
        //   （与 MIC_CREEPER_S9 三局全 NO_RESULT 同一族，见报告 bug #8）。
        const e = bot.entity;
        if (e) {
            const yaw = Number(e.yaw ?? 0);
            bot.look(Number.isFinite(yaw) ? yaw : 0, TRAVEL_PITCH_DEG * Math.PI / 180, false)?.catch?.(() => {});
        }
    } catch { /* 保守失败 */ }
    trace?.('gaze_guard_reject', {
        deg: Number(risky[0].deg?.toFixed(2)),
        dist: Number(risky[0].dist?.toFixed(2)),
        wanted: [point.x, point.y, point.z],
    });
    return true;
}

/**
 * 在 bot.lookAt 上装守卫（可逆）。
 * @returns {{installed:boolean, restore:()=>void, rejected:()=>number}}
 */
export function installGazeGuard(bot, opts = {}) {
    if (!bot || typeof bot.lookAt !== 'function') return { installed: false, restore() {}, rejected: () => 0 };
    const original = bot.lookAt.bind(bot);
    let rejected = 0;
    bot.lookAt = function guardedLookAt(point, force) {
        // 注意：force=true 在 mineflayer 4.38 里**不真的发旋转包**（手册 §3），
        // 所以这里不改变 force 语义，只在"会造成凝视"时整体拒绝。
        if (safeLookAt(bot, point, opts)) { rejected++; return true; }
        return original(point, force);
    };
    return {
        installed: true,
        rejected: () => rejected,
        restore() { bot.lookAt = original; },
    };
}
