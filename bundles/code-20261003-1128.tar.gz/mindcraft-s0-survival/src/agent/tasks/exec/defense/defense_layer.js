// defense_layer.js — MC-M1-TASK-07（G 线）：DefenseLayer 常驻中断层
//
// 设计 §1.3 + §3.1/§3.2：
//   扫描：500ms 周期——bot.entities 遍历（视野内协议同步实体），分级打标
//     EMERGENCY <6 且 LOS   → 立即中断（不等下个周期）
//     ENGAGED   <12 且 LOS  → 中断任务树，派发处置任务
//     MONITORED <24         → 只标记（telemetry + 导航回避代价），不打断
//   即时触发（绕过周期）：bot.health 下降事件 → 立即进入 EMERGENCY 判定
//   迟滞：ENGAGED 进入 12 / 退出 16；同威胁 3s 冷却防重派
//
// 分工（关键）：**本层只"发现 + 排队"，不"执行防御"**。
// 派发权在 TaskRuntime（设计 §3.2 ②③④：ABORT 根任务树 → DefenseTask 以 runRoot 语义驱动 →
// 完成后用原 MISSION 重新 replan）。这样本层可以在离线单测里用假 bot 穷举扫描逻辑，
// 而不需要把 TaskRuntime 一起拉起来。
//
// 末影人凝视守卫也在本层挂载（唯一入口，installGazeGuard 可逆包装 bot.lookAt）——
// 这样"任何 lookAt 都过闸"成立，又不用去改 place.js/nav.js 等共享文件。

import {
    THREAT_LEVEL, THREAT_RANGE, THREAT_COOLDOWN_MS,
    isHostile, threatDef, classify, actionable, creeperFusingNow,
} from './threat_table.js';
import { canSeeEntity, eyeDistance, horizontalDistance } from './los.js';
import { installGazeGuard } from './gaze_guard.js';
import { bumpInterrupts, isNight } from './night_decision.js';

// ================================================================= 纯扫描（离线可测）

/**
 * 扫一遍场上实体，返回最高威胁 + 分档统计。**不产生副作用**。
 * @param {object} bot
 * @param {object} opts { now, dimensionId, losStrict, engagedSet:Set（迟滞用）, monitorOnly }
 * @returns {{threat:object|null, byLevel:number[], byType:object, maxDist:object}}
 */
export function scanOnce(bot, opts = {}) {
    const now = opts.now ?? Date.now();
    const dimensionId = opts.dimensionId ?? 0;
    const losStrict = opts.losStrict !== false;
    const engagedSet = opts.engagedSet ?? new Set();
    const byLevel = [0, 0, 0];
    const byType = {};
    const maxDist = {};
    let threat = null;
    for (const e of Object.values(bot.entities ?? {})) {
        if (!e?.name) continue;
        const def = threatDef(e.name, dimensionId);
        if (!def) continue;
        const los = canSeeEntity(bot, e);
        const dist = eyeDistance(bot, e);
        // fuse 判据 = **元数据 [15]（SWELL_DIR：-1 不膨胀 / 1 膨胀）**。
        // 阳性对照实测（MIC_FUSEPROBE，1.16.1 客户端）：creep 走到 2.92 格那一刻 15 号
        // 由 -1 翻成 1，而 `width` 全程恒 0.6（widthEverChanged=false）⇒ 宽判据不可用。
        // 这条比 <6 格的静态距离门**早得多**（2.92 格就报），是 fuse 的唯一可用信号。
        // 读不到元数据（索引够不到/实体刚进视野）时返回 false ⇒ 退回 <6 格兜底，不会误判。
        const fusing = e.name === 'creeper' && creeperFusingNow(e);
        // 迟滞：已在 ENGAGED 的实体，退出门限放宽到 16
        const cls = classify({ distance: dist, los, fusing, dimensionId }, {
            losStrict,
            engagedExitApplied: engagedSet.has(e.name),
        });
        if (!cls) continue;
        const key = `${e.name}#${e.id}`;
        maxDist[key] = Number(dist.toFixed(2));
        // 可处置性：implemented===false 的下界条目本单不派发（只统计）
        const can = actionable(e.name, dimensionId);
        byType[e.name] = (byType[e.name] ?? 0) + 1;
        byLevel[cls.level - 1]++;
        if (!can) continue;
        if (cls.level === THREAT_LEVEL.MONITORED) {
            // MONITORED 不打断；但要留档供"导航回避代价"与报告用
            continue;
        }
        const cand = {
            name: e.name, id: e.id, level: cls.level, reason: cls.reason,
            dist: Number(dist.toFixed(2)), hDist: Number(horizontalDistance(bot, e).toFixed(2)),
            los, fusing, action: def.action, entity: e, at: now,
        };
        // 排序键：先档位，再距离（fusing 直接最高）
        if (!threat || cls.level > threat.level || (cls.level === threat.level && cand.dist < threat.dist)) {
            threat = cand;
        }
    }
    return { threat, byLevel, byType, maxDist, now };
}

// ================================================================= 常驻层

export class DefenseLayer {
    /**
     * @param {object} bot
     * @param {object} opts { dimensionId, scanMs, wallMs, losStrict, gazeGuard, autoStart }
     */
    constructor(bot, opts = {}) {
        this.bot = bot;
        this.dimensionId = opts.dimensionId ?? 0;
        this.scanMs = opts.scanMs ?? 500;                       // 设计 §1.3
        this.wallMs = opts.wallMs ?? 30000;                     // 任务单硬要求 ①
        this.losStrict = opts.losStrict !== false;              // 任务单硬要求 ③
        // 裁决①：凝视守卫同样**默认关、显式开**。它的拒绝会让调用方拿旧朝向继续干活
        //（手册 §3），属于行为变化，不该由默认值带进别的线。
        this.gazeGuardOn = opts.gazeGuard === true;
        // 裁决②：整局防御总墙钟耗尽后置 true —— 扫描照跑、统计照记，但**不再排中断**。
        this.exhausted = false;
        this._lastExhaustedLogAt = 0;
        this._gazeInstalled = false;   // sticky：stop() 之后仍要能回答"到底装没装"
        this._gazeRejects = 0;
        this.ctx = null;
        this._timer = null;
        this._health = null;
        this._onHealth = null;
        this.gaze = null;
        this.engagedSet = new Set();
        this.lastDispatchAt = new Map();     // 威胁名 → 上次派发时刻（3s 冷却）
        this.interrupts = [];               // 遥测通道（设计 §3.3：独立于 failCounts）
        this.pending = null;                // 待处理的中断（TaskRuntime 消费）
        this.nightState = { interruptsTonight: 0 };
        this.stats = {
            scans: 0, threatsSeen: 0, interrupts: 0, emergencyTriggers: 0,
            healthTriggers: 0, byType: {}, byReason: {}, emaDist: null,
        };
    }

    /** 挂到 ctx（telemetry/counters 通道）。可在拿到 ctx 后再调。 */
    mount(ctx) {
        this.ctx = ctx;
        this._armHealth();
        if (this.gazeGuardOn && !this.gaze) {
            this.gaze = installGazeGuard(this.bot, { telemetry: (e, d) => this._tele(e, d) });
            this._gazeInstalled = !!this.gaze?.installed;
        }
        return this;
    }

    start() {
        if (this._timer) return this;
        this._timer = setInterval(() => this._tickOnce(), this.scanMs);
        this._timer.unref?.();
        this._tickOnce();
        return this;
    }

    stop() {
        if (this._timer) { clearInterval(this._timer); this._timer = null; }
        this._disarmHealth();
        // ⚠ 守卫统计必须**在 restore 之前**定格：runtime 收尾是先 stop() 再取 summary()，
        //   而 stop() 会把 this.gaze 置 null —— 第一版就这么写的，于是
        //   "gazeGuardInstalled / gazeRejects" 永远是 false/0，看着像"守卫没触发"，
        //   实际是"守卫装了但统计被自己擦掉"。这是记账型静默失败，必须先存后拆。
        if (this.gaze) {
            this._gazeRejects = this.gaze.rejected?.() ?? 0;
            this.gaze.restore?.();
        }
        this.gaze = null;
        return this;
    }

    /** bot.health 下降事件 → 立即 EMERGENCY 判定（设计 §1.3 即时触发，绕过 500ms 周期）。 */
    _armHealth() {
        if (!this.bot?.on || this._onHealth) return;
        this._health = Number(this.bot.health ?? 20);
        this._onHealth = (hp) => {
            const prev = this._health;
            this._health = Number(hp);
            if (!Number.isFinite(prev) || !Number.isFinite(this._health) || this._health >= prev) return;
            this.stats.healthTriggers++;
            this._tele('defense_health_drop', { from: prev, to: this._health, lost: prev - this._health });
            // 掉血即刻重扫一次（不等下个周期）——被打的来源就在旁边，不重扫会慢半拍
            this._tickOnce({ immediate: true });
        };
        this.bot.on('health', this._onHealth);
    }

    _disarmHealth() {
        if (this.bot?.removeListener && this._onHealth) this.bot.removeListener('health', this._onHealth);
        this._onHealth = null;
    }

    _tele(event, data) { this.ctx?.telemetry?.(event, data); }

    /** 一次扫描 + 分级 + 迟滞 + 冷却 → 决定是否产生中断。 */
    _tickOnce({ immediate = false } = {}) {
        this.stats.scans++;
        const now = Date.now();
        const res = scanOnce(this.bot, { now, dimensionId: this.dimensionId, losStrict: this.losStrict, engagedSet: this.engagedSet });
        // 迟滞集合维护：ENGAGED/EMERGENCY 的名字进集合，退到 engagedExit 之外再移除
        for (const name of Object.keys(res.byType)) {
            const stillIn = (res.maxDist ?? {}) && Object.entries(res.maxDist).some(([k, d]) => k.startsWith(`${name}#`) && d < THREAT_RANGE.engagedExit);
            if (stillIn) this.engagedSet.add(name); else this.engagedSet.delete(name);
        }
        for (const [k, v] of Object.entries(res.byType)) this.stats.byType[k] = (this.stats.byType[k] ?? 0) + v;
        if (!res.threat) return null;
        this.stats.threatsSeen++;
        if (res.threat.level === THREAT_LEVEL.EMERGENCY) this.stats.emergencyTriggers++;
        this.stats.byReason[res.threat.reason] = (this.stats.byReason[res.threat.reason] ?? 0) + 1;
        this.stats.emaDist = this.stats.emaDist == null ? res.threat.dist
            : this.stats.emaDist * 0.8 + res.threat.dist * 0.2;

        // 已在防御中：不重派（派发权在 TaskRuntime；这里只保证不排队第二个）
        if (this.pending) return res.threat;
        // —— 裁决②：整局防御总预算耗尽 ⇒ 只记威胁、不再抢占 ——
        // 扫描与统计照旧（这是复盘"夜里到底有多少威胁"的关键数据，停了就没了），
        // 只是不再打断主任务。遥测做节流：威胁名变化时立即记，否则每 5s 一条，
        // 避免 500ms 一次把遥测文件刷爆。
        if (this.exhausted) {
            const changed = this._lastExhaustedName !== res.threat.name;
            if (changed || now - this._lastExhaustedLogAt > 5000) {
                this._lastExhaustedName = res.threat.name;
                this._lastExhaustedLogAt = now;
                this._tele('defense_threat_after_budget', {
                    threat: res.threat.name, dist: res.threat.dist, level: res.threat.level,
                    reason: res.threat.reason, observed: this.stats.threatsSeen,
                });
            }
            return res.threat;
        }
        // 同威胁 3s 冷却（设计 §1.3，防 dispatch 风暴）
        const last = this.lastDispatchAt.get(res.threat.name) ?? 0;
        if (now - last < THREAT_COOLDOWN_MS && !immediate) return res.threat;
        this.lastDispatchAt.set(res.threat.name, now);
        this._queueInterrupt(res.threat, now);
        return res.threat;
    }

    _queueInterrupt(threat, now) {
        const rec = {
            t: now, threat: threat.name, threatId: threat.id, level: threat.level,
            reason: threat.reason, dist: threat.dist, fusing: !!threat.fusing,
        };
        this.interrupts.push(rec);
        if (this.interrupts.length > 5000) this.interrupts.splice(0, 1000);  // 有界，别把内存吃光
        this.stats.interrupts++;
        // §2.5-D：夜间打断计数（同区域一夜 ≥3 次 → 强制壁龛）
        if (isNight(this.bot)) bumpInterrupts(this.nightState);
        this._tele('defense_interrupt', rec);
        // pending 的形状必须与 run.interrupt **一致**（{threat, id, dist, level}），
        // 否则消费方读 `intr.threat` 会拿到 undefined。真的踩过：
        //   runtime 里 `defense.noteCleared(intr.threat)` 传的是 undefined
        //   ⇒ lastDispatchAt 里 'zombie' 那一项永远删不掉 ⇒ 3s 冷却清不掉
        //   ⇒ 防御结束后仍有威胁时，最多 3s 内**不再派发**（苦力怕 fuse 只有 1.5s，
        //      够它从起爆走到炸完）。同时任务树标签会印成 `Defense(undefined d3)`。
        // 显式带上 threat 字段，两个通道的契约就统一了。
        this.pending = { ...threat, threat: threat.name, id: threat.id, level: threat.level, dist: threat.dist, at: now, interrupt: rec };
        // ★ 真正把根任务打断的信号：driveTask 每拍检查 ctx.run.interrupt。
        //   漏了这一行 = 层只"发现"不"通知"，根任务会一直跑到自然终态（离线自检第一次跑
        //   就是这么发现的：中断数 0、根任务只跑 1 轮）。两个通道分工：
        //   pending = runtime 事后取（做 post-mortem / 清 pending）；run.interrupt = 实时打断。
        if (this.ctx?.run && !this.ctx.run.interrupt) {
            this.ctx.run.interrupt = {
                threat: threat.name, id: threat.id, dist: threat.dist, level: threat.level,
            };
        }
    }

    /** TaskRuntime 消费：取走待处理中断（并关掉这一次的"已排队"标记）。 */
    takeInterrupt() {
        const p = this.pending;
        this.pending = null;
        // 必须清 run.interrupt：若根任务已经自己跑完了，这个信号会**打到下一轮**根任务头上
        // （延迟一拍的中断看起来像"刚重入就被抢"，最难查的一类假阳性）。
        if (this.ctx?.run) this.ctx.run.interrupt = null;
        return p;
    }

    /** 防御结束回调：让迟滞与冷却复位，避免恢复后立刻被同一威胁再打断。 */
    noteCleared(threatName) {
        this.engagedSet.delete(threatName);
        this.lastDispatchAt.delete(threatName);
    }

    /** 给 summary 用的统计（设计 §5.2 指标 3/5/6 的数据源）。 */
    summary() {
        const byType = {};
        for (const i of this.interrupts) byType[i.threat] = (byType[i.threat] ?? 0) + 1;
        return {
            scans: this.stats.scans, threatsSeen: this.stats.threatsSeen,
            interrupts: this.interrupts.length, byType,
            emergencyTriggers: this.stats.emergencyTriggers,
            healthTriggers: this.stats.healthTriggers,
            interruptsTonight: this.nightState.interruptsTonight ?? 0,
            // 裁决①：默认关时守卫根本没装 ⇒ 恒 0。**"0"必须能区分「没触发」与「没装」**，
            // 所以把"是否装载"也落盘（复盘时"守卫拒绝 0 次"可能只是没开它）。
            gazeGuardInstalled: this._gazeInstalled || !!this.gaze,
            gazeRejects: this._gazeRejects || this.gaze?.rejected?.() || 0,
            budgetExhausted: !!this.exhausted,
        };
    }
}
