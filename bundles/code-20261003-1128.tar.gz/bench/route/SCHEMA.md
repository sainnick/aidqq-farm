# route/<seed>.json 规范 v1（设计会话定稿，2026-10-01）

> 依据：`docs/MC-DECISION-01-路线与口径裁决报告.md` §2（SSG 路线型 + L2 站级粒度）、手册 §7。
> 改本规范只能由设计会话做。

## 1. 核心原则：L2 靠"结构"保证，不靠自觉

route 文件里同时存两类数据：
- **`scout`（预勘区，精确数据）**：结构内部坐标、核验计数、证据路径。**只给人审阅和审计用。**
- **`station`（运行区，站级数据）**：任务层**只能**看到这一部分。

任务层**不允许直接读 JSON 文件**，只能通过 `route_loader`（运行时加载器）读取。加载器的职责：
1. 校验文件的 sha256 与冻结值一致，不一致就拒绝加载（并在遥测里记 `route_hash_mismatch`）；
2. **只返回 `station` 字段**，`scout` 整块丢弃；
3. 返回之前再做一次粗化兜底：中心坐标对齐到 **8 格网格**，`radius` 不小于 **16**（满足不了就拒绝加载这一站）。

这样，就算有人在 station 里误写了精确坐标，任务层拿到的也只会是"这一片"，L0（精确到方块）在结构上不可能发生。

## 2. 文件格式

```jsonc
{
  "schema": "aidqq-route/1",
  "seed": "-8839485814800629942",
  "mcVersion": "1.16.1",
  "frozenAt": null,              // 冻结时间；为 null 表示草稿，run 时拒绝加载草稿
  "sha256File": "<seed>.sha256", // 冻结时生成，内容 = 整个文件（含 frozenAt、sha256File）的规范化 sha256，口径见 §4
  "stations": [
    {
      "id": "S1_portal",               // 唯一，run 时 MISSION 写成 "goto station S1_portal" / "do station S1_portal"
      "seq": 3,                         // 站序
      "kind": "ruined_portal",          // ruined_portal | lava_pool | iron_source | gravel | sheep | bastion | fortress_spawner | stronghold_portal_room | ...
      "dim": "overworld",               // overworld | the_nether | the_end
      "station": {                      // ← 运行区：加载器只返回这一块
        "center": [176, 352],           // XZ，加载器会对齐到 8 格网格
        "yHint": "surface",             // surface | underground | nether_mid | any —— 只是一个提示，不给精确 y
        "radius": 24,                   // 到达后自己搜索的半径（≥16）
        "lookFor": ["crying_obsidian", "obsidian"]  // 到达确认用的方块或实体类型，要自己用 findBlocks/实体可见性找到
      },
      "scout": {                        // ← 预勘区：加载器丢弃
        "points": [{ "what": "frame_corner", "xyz": [180, 64, 349] }],
        "verify": { "status": "REAL", "method": "fill-replace", "counts": { "crying_obsidian": 1, "obsidian": 9 }, "terrain": { "stone": 214187 }, "at": "2026-09-30T…", "evidence": "experiments/seed-scout/s3_results/..." },
        "notes": "门框缺 3 格；箱子在框西侧"
      },
      "fallback": ["S1b_lava_pool"]     // 这一站失败时可以改去的备选站 id（可空）
    }
  ]
}
```

### 2.1 站序与 fallback（v1.1，设计会话 2026-10-02 夜补）

- `stations[].seq` 仍要求从 1 起连续、不重复（`route_guard.mjs` 校验）。
- `stations[].routeRole`：可选；`"fallback-only"` 表示这一站**正常流程不去**，只在别的站失败、经其 `fallback` 指向时才去。fallback-only 站排在数组末尾。
- 顶层 `normalFlowStations`：正常流程的站 id 列表（按 seq 升序）。**编排器只按这个列表走，不遍历整个 `stations`。**
- 顶层 `fallbackOnlyStations`：`[{ id, seq, fallbackOf: [主站 id…] }]`，与各站 `routeRole`、主站的 `fallback` 三处必须一致（route_guard 应校验）。
- 顶层 `orchestratorContract`：给编排器的人读规则（例：刷怪笼不足时"尽力而为，掉落少不重试，只有到达确认失败才切 fallback"）。只是说明，不作为机器判据。
- `yHint` 必须和 scout 实测高度一致：结构在地下（例如洞穴里的废墟门）就写 `underground`，不能因为"从地表走过去"写 `surface`。

## 3. 运行时规则

- MISSION 层只下站 id（例如 `do station S1_portal`），**不下坐标**；坐标不得进入 prompt、模型记忆。
- 任务层流程：`navToRegion(station)` → **到达确认闸门**：在 `radius` 内用正常可见信息（findBlocks / 实体）找到 `lookFor`。找不到时，像真人一样换个方向在附近再找（有次数上限）；还找不到就以 `STATION_NOT_CONFIRMED` 失败，上报编排器走 `fallback`。**不瞬移、不穿墙、不用 scout 坐标兜底。**
- 每局开跑时把 route 的 sha256 写进遥测；run 中 route 文件被修改 = 该局作废。
- 草稿（`frozenAt=null`）只能用于开发局；正式矩阵和拍摄局必须用冻结版。

## 4. 生成与冻结

- 生成工具在 `bench/route/tools/`，**换种子能一键重新生成**。核验沿用 SEED-03 的服务器权威通道（stdin 控制台 + forceload + fill-replace，每个盒子都带地形对照）。
- 冻结：人工审阅 → 写 `frozenAt` → 生成 `.sha256` 文件 → 在 handover 记一行（种子、sha256、审阅人）。
- **sha256 口径（v1.1，2026-10-02 夜定）**：`sha256( JSON.stringify(JSON.parse(文件原文), null, 2) + "\n" )`，对**整个文件**算，包括 `frozenAt` 和 `sha256File`。哈希存在旁挂文件里、不在 route 文件里，所以没有循环依赖。用规范化而不是原始字节，是为了不受换行符影响（Windows 本地是 CRLF，云端 X / 农场 Y 是 LF，原始字节哈希会对不上）。冻结工具、`route_guard` 的冻结校验和开跑/段间复验必须调用**同一个**哈希函数。冻结后再改要升版本号，例如 `<seed>.v2.json`。
