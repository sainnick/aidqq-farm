// review_checklist_v2.mjs — MC-ROUND5 §C 线：**主种子 route 冻结审阅清单 v2**
//
// 【v1 → v2 的差别】
//   v1（ROUND4 C 线，10-02 傍晚）：只覆盖 ROUTE-02 那一轮的八站 + 下界三站的**待并入**数据。
//   v2（本单）：① 下界三站按派单裁决**已并入 route**（C-2 进 S3 的 scout、C-3 新增站、C-1 判不并入）；
//     ② C-3 的「可挡火球站位」由 ROUND5 补测给出**可判定的数**（ROUND4 那份 124 格探测里 52 格未解析，
//        "0 个站位"是"没读到"）；③ 逐条列出设计会话冻结前仍需裁决的点。
//
// 【硬约束】本文件**只读** route / probe / emit 台账，**绝不写 route 文件、不写 frozenAt、不生成 sha256**
//   （派单 C-4：冻结等 B 线 S1 主种子 5/5 后由设计会话做）。
//
// 用法：
//   & .\.runtime\node-v20.20.2-win-x64\node.exe bench\route\tools\review_checklist_v2.mjs [--seed 4926685115947721762]

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { argOf } from '../../stages/_lib/runner_core.mjs';
import { ROUTE_DIR } from './console.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROBE_DIR = path.join(ROUTE_DIR, 'probe');
const REVIEW_DIR = path.join(ROUTE_DIR, 'review');
const SEED = argOf(process.argv, 'seed', '4926685115947721762');
const readJson = (p, dflt = null) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return dflt; } };

const route = readJson(path.join(ROUTE_DIR, `${SEED}.json`));
if (!route) throw new Error(`找不到 route 草稿：bench/route/${SEED}.json`);
const probe = readJson(path.join(PROBE_DIR, `${SEED}.probe.json`), {});
const offline = readJson(path.join(PROBE_DIR, 'nether_side_offline.json'), {});
const r4 = {
    nether_portal: readJson(path.join(PROBE_DIR, 'nether_portal.round4c.json')),
    bastion: readJson(path.join(PROBE_DIR, 'bastion.round4c.json')),
    fortress: readJson(path.join(PROBE_DIR, 'fortress.round4c.json')),
};
const standing = readJson(path.join(PROBE_DIR, 'fortress_standing.round5c.json'));
const sheepRes = readJson(path.join(PROBE_DIR, 'sheep.round5c.json'));
const emitLedger = readJson(path.join(PROBE_DIR, 'route_emit.round5c.json'));

const out = [];
const P = (s = '') => out.push(s);
const ev = (rel) => `\`${rel.replace(/\\/g, '/')}\``;

P(`# route 冻结审阅清单 v2 —— ${SEED}`);
P();
P('> 由 `bench/route/tools/review_checklist_v2.mjs` 生成（**只读 route / probe / round4c / round5c，绝不写 route 文件**）。');
P('> v1 见 `bench/route/review/<seed>.review.md`（只覆盖 ROUTE-02 那一轮八站）。');
P('> **本版对应 MC-ROUND5 §C 的三条裁决**：C-1 判不并入（底行基岩）、C-2 并入 S3 站的 scout、C-3 新增站 + 站位补测。');
P('> `frozenAt` 仍为 `null`：**冻结由设计会话做**（派单 C-4：等 B 线 S1 主种子 5/5 之后）。');
P();
P('| 项 | 值 |');
P('|---|---|');
P(`| 种子 | \`${route.seed}\`（10-02 设计会话定为主种子，手册 §7） |`);
P(`| 版本 | ${route.mcVersion} |`);
P(`| \`frozenAt\` | \`${JSON.stringify(route.frozenAt)}\` —— **草稿；本工具不写，冻结由设计会话做** |`);
P(`| \`sha256File\` | \`${JSON.stringify(route.sha256File)}\` —— 冻结时才生成 |`);
P(`| 站数 / scout REAL | ${route.stations.length} / ${route.stations.filter((s) => s.scout?.verify?.status === 'REAL').length} |`);
P(`| 下界三站裁决 | C-1 **不并入**（见 §2.1） · C-2 **并入 \`S3_bastion\`.scout**（见 §2.2） · C-3 **新增站 \`C3_fortress_spawner\`**（见 §2.3） |`);
P(`| 要塞对应点（nether ÷8） | \`(${offline.netherAnchor?.x},${offline.netherAnchor?.z})\`（主世界要塞 ${JSON.stringify(route.stations.find((s) => s.id === 'S5_stronghold_room')?.station?.center)}） |`);
P(`| 本单 emit 台账 | ${emitLedger ? ev('bench/route/probe/route_emit.round5c.json') + `（${emitLedger.changes?.length ?? 0} 条变更）` : '（尚未 emit）'} |`);
P();

// ---------------------------------------------------------------- 一、路线上的站
P('## 一、路线上的站（读 `bench/route/' + SEED + '.json`）');
P();
P('| seq | 站 id | kind | dim | station 中心 | radius | yHint | scout 状态 | 备注 |');
P('|---|---|---|---|---|---|---|---|---|');
for (const st of route.stations) {
    const v = st.scout?.verify ?? {};
    const flags = [];
    if (st.scout?.flags) flags.push(`⚠${st.scout.flags.join(',')}`);
    if (st.routeRole === 'fallback-only') flags.push('**fallback-only**');
    if (st.id === 'C3_fortress_spawner') flags.push('本轮新增');
    if (st.id === 'S3_bastion' && st.scout?.corroboration) flags.push('已并入 C-2 复核 + F 线猪灵');
    P(`| ${st.seq} | \`${st.id}\` | \`${st.kind}\` | \`${st.dim}\` | \`[${st.station.center}]\` | ${st.station.radius} | \`${st.station.yHint}\` | ${v.status} | ${flags.join(' ') || ''} |`);
}
P();
const risks = [];
for (const st of route.stations) {
    const v = st.scout?.verify ?? {};
    if (v.status !== 'REAL') risks.push(`\`${st.id}\` 是 ${v.status}（${v.reason ?? '无 reason'}）—— 冻结前需裁决`);
    if (st.station.center[0] === 0 && st.station.center[1] === 0) risks.push(`\`${st.id}\` 的 center 是占位 [0,0]（对 bot 无指向性）`);
    if (st.scout?.flags?.includes('insufficient_spawners')) risks.push(`\`${st.id}\` 带 insufficient_spawners 标记（刷怪笼 < 2，编排器应按"尽力而为"处理，勿重试到超时）`);
}
if (risks.length) { P('### 冻结前风险（既有站）'); P(); risks.forEach((r) => P(`- ${r}`)); P(); }

// ---------------------------------------------------------------- 一之二、yHint 逐站核对
if (route.yHintAudit) {
    const ya = route.yHintAudit;
    P('### 1.1 `yHint` 逐站对照 scout 实测高度（SCHEMA v1.1）');
    P();
    P(`> 规则：\`${ya.rule}\``);
    P(`> 审计时间：${ya.at}（${ya.changedCount} 站与基线不同）`);
    P();
    P('| 站 id | dim | yHint（基线 → 现值） | 实测 y | 高度数据来源 |');
    P('|---|---|---|---|---|');
    for (const r of ya.rows) {
        P(`| \`${r.id}\` | ${r.dim} | ${r.yHintBaseline} → **${r.yHint}**${r.changed ? ' ← 改了' : ''} | ${r.measuredY ?? '—'} | ${r.ySource} |`);
    }
    P();
    ya.caveats.forEach((c) => P(`> ⚠ ${c}`));
    P();
}

// ---------------------------------------------------------------- 二、下界一侧三站
P('## 二、下界一侧三站：按派单 C 节的裁决');
P();
P('> 三站的原始取证都在服务器权威通道上（每盒地形对照 + fill 回执严格 FIFO 配对 + 每站 fresh world）。');
P('> 口径提醒（手册 §5）：**区域总数 ≠ 框内计数** —— 门框用与生产 `frameCells` 相同的几何逐格判定。');
P();

// ---- 2.1 C-1
P('### 2.1 `C1_nether_portal` —— **不 emit**（派单 C-1 裁决）');
P();
const np = r4.nether_portal;
if (np) {
    const f = np.frame;
    P(`- **离线起点**：\`(${np.offlineStart?.x},${np.offlineStart?.z})\` 距要塞对应点 \`${np.offlineStart?.distanceFromAnchor ?? np.offlineStart?.d}\` 格 · r=\`${np.r}\` · 取证 \`${np.status}\`（${np.seconds}s）`);
    P(`- **框体**：origin \`(${f.origin.x},${f.origin.y},${f.origin.z})\` axis \`${f.axis}\` · 框内黑曜石 **${f.obsidian}/${f.required}** · 需新放 **${f.obsidianToPlace}** 块 · 门可用：${f.usable ? '✅' : '❌'}`);
    P(`- **证据**：${ev('bench/route/probe/nether_portal.round4c.json')} · 服务器日志 ${ev('bench/route/probe/_run_round4c/nether_portal/server.log')}`);
    P();
    // 理由**直接读 route 的 notEmitted**（单一真源；更正在那里改，这里只呈现）
    const ne = (route.notEmitted ?? []).find((x) => x.id === 'C1_nether_portal');
    if (ne) {
        P(`**不并入的理由**（route \`notEmitted[].reason\`，${ne.decidedBy}）：`);
        P();
        ne.reason.forEach((r, i) => P(`${i + 1}. ${r}`));
        P();
        if (ne.correctedAway?.length) {
            P('> ⚠ **已作废的初版理由**（设计会话 2026-10-02 夜更正）：');
            ne.correctedAway.forEach((r) => P(`> - ${r}`));
            P();
        }
        P(`- **框体几何**：origin \`(${f.origin.x},${f.origin.y},${f.origin.z})\` axis \`${f.axis}\` · 框内黑曜石 **${f.obsidian}/${f.required}\` · 需新放 **${f.obsidianToPlace}** 块 · 门可用：${f.usable ? '✅' : '❌'}`);
        P(`- **错块构成**：${(ne.measured?.wrongBlocks ?? '（未记）')}`);
        P(`- **保留作参照**：${ne.keepAsReference}`);
    } else {
        P('- **⚠ route 里没有 `notEmitted` 条目** ⇒ 尚未执行 C-1 的"不并入"裁决，冻结前必须处理。');
    }
    P();
    P('> 派单 §0 第 1 条据此判定：v1 去要塞维持"回主世界、走陆路"；**研究线已撤回钻石镐路线评估**，'
        + '所以"缺格含哭泣黑曜石"不再是理由（铁镐可挖，只是不掉落），不并入只剩上面两条。');
    P();
    P('- **本单的动作**：route 里 `notEmitted` 条目（原因 + 计数 + 证据路径），**不新增站**。');
    P();
} else {
    P('- **取证缺失**：本轮未产出 `nether_portal.round4c.json` ⇒ 无法执行派单 C-1 的裁决，冻结前必须补测。');
    P();
}

// ---- 2.2 C-2
P('### 2.2 `C2_bastion` —— **已并入 `S3_bastion` 站的 scout**（派单 C-2 裁决）');
P();
const ba = r4.bastion;
const s3 = route.stations.find((s) => s.id === 'S3_bastion');
if (ba && s3) {
    const t = ba.bastionType;
    const cor = s3.scout.corroboration;
    P(`- **类型判别**：treasure = **有金块 → 是**（gold_block ${t?.goldBlock}）；hoglin stables 标志（crimson ${t?.crimsonFungus} + warped ${t?.warpedFungus}）`);
    P(`- **结构件**：金块 \`${t?.goldBlock}\` · 鎏金黑石 \`${t?.gildedBlackstone}\` · 箱 \`${t?.chest}\` · 陷阱箱 \`${t?.trappedChest}\` · 黑曜石 \`${t?.obsidian}\` · 哭泣黑曜石 \`${t?.cryingObsidian}\``);
    P(`- **区域中心**：\`${JSON.stringify(ba.region?.center)}\`（命中盒 ${JSON.stringify(ba.region?.box)}） · 取证 \`${ba.status}\`（${ba.seconds}s）`);
    P(`- **自检**（点状目标下钻点数 == 粗扫计数）：${JSON.stringify(ba.scan?.selfCheck?.['minecraft:gold_block'])} · 回执错位 \`${ba.scan?.desync ?? 0}\` · 地形对照 ${JSON.stringify(ba.scan?.terrain)}`);
    P(`- **证据**：${ev('bench/route/probe/bastion.round4c.json')} · 服务器日志 ${ev('bench/route/probe/_run_round4c/bastion/server.log')}`);
    P();
    P('**并入口径 + 站级中心迁移**（设计会话 2026-10-02 夜复核指令 2）：');
    P();
    const mig = s3.scout.centerMigration;
    if (cor) {
        P(`- route 里 \`S3_bastion.scout.corroboration\` = { 区域中心 ${JSON.stringify(cor.region?.center)}, 计数 ${JSON.stringify(cor.counts)}, 精确坐标（金块 ${cor.goldBlockPoints?.length ?? 0} 个 / 箱 ${cor.chestPoints?.length ?? 0} 个） }；`);
    } else {
        P('- ⚠ route 里**还没有** `S3_bastion.scout.corroboration` —— 尚未运行 `emit_round5c.mjs`（或 emit 被硬闸门拒绝）。');
    }
    if (mig) {
        P(`- **站级中心已迁移**：\`${JSON.stringify(mig.from.center)}\`（服务器 /locate）→ **\`${JSON.stringify(mig.to.center)}\`**（C-2 实测片，8 格对齐），radius 保持 ${s3.station.radius}；`);
        P(`  - 8 格对齐校验：${mig.to.center[0]} % 8 = ${mig.to.center[0] % 8}、${mig.to.center[1]} % 8 = ${mig.to.center[1] % 8} ⇒ 满足 \`route_guard.mjs:49\` 的硬闸门；`);
        P(`- **前置已核**（${mig.sameStructureEvidence.method}）：${mig.sameStructureEvidence.result}`);
        P(`  - 证据工具 \`${mig.sameStructureEvidence.tool}\`（零开服，可复跑）· 距离 ${mig.sameStructureEvidence.distanceToFrom} / ${mig.sameStructureEvidence.distanceToTo} 格 · 足迹阈值 ${mig.sameStructureEvidence.footprintThreshold} 格`);
        P(`  - ⚠ 口径提醒：${mig.sameStructureEvidence.caveat}`);
        P(`  - ⚠ 未做：${mig.sameStructureEvidence.notVerified}`);
        P(`- \`/locate\` 的旧中心保留在 scout 作参照：${mig.locateKeptAsReference}`);
    } else {
        P(`- ⚠ 站级中心**仍是** ${JSON.stringify(s3.station.center)}（迁移未执行）。`);
    }
    P(`- ⚠ **给 F 线 B5 的坑已写进该站 notes**：${cor?.hoglinAggression ?? '（尚未 emit）'}`);
    P();
    // ---- F 线实测的猪群（设计会话指令 4）
    const pp = s3.scout.piglinPopulation;
    if (pp) {
        P('**已并入 F 线实测的猪群数据**（设计会话指令 4）：');
        P();
        P(`| 难度 | 服务端权威数 | 客户端可见 | 证据 |`);
        P(`|---|---|---|---|`);
        P(`| **peaceful** | **${pp.peaceful}** 头（\`kill @e[type=piglin]\` 回执 \`Killed ${pp.peaceful} entities\`） | 一致 | ${ev(pp.source)} |`);
        P(`| easy | ${pp.easy} | 一致 | 同上 |`);
        P();
        P(`- 测法：${pp.method}`);
        P(`- 分布：${pp.spread}`);
        P('- 对 S3 的含义：');
        pp.implication.forEach((i) => P(`  - ${i}`));
        P();
    }
} else {
    P('- **取证或 route 缺失**：`bastion.round4c.json` 或 `S3_bastion` 站缺失 ⇒ 并入口径无法核对。');
    P();
}

// ---- 2.3 C-3
P('### 2.3 `C3_fortress_spawner` —— **新增站** + 站位补测（派单 C-3 裁决）');
P();
const fo = r4.fortress;
const c3 = route.stations.find((s) => s.id === 'C3_fortress_spawner');
if (fo && c3) {
    P(`- **kind** \`${c3.kind}\` · dim \`${c3.dim}\` · seq ${c3.seq} · 站级中心 \`${JSON.stringify(c3.station.center)}\`（8 格对齐，SCHEMA §1）· radius ${c3.station.radius} · lookFor ${JSON.stringify(c3.station.lookFor)} · fallback ${JSON.stringify(c3.fallback)}`);
    P(`- **刷怪笼**：**${fo.spawnerCount} 个**（派单下限 2 → 不足，但**派单 C-3 判为"接受"**：一个笼刷 8 根烈焰棒是常规打法，冗余记为风险）`);
    P(`- **锚点**（证明扫的是要塞不是空地）：nether_bricks \`${fo.anchorBricks?.netherBricks}\` · blackstone \`${fo.anchorBricks?.blackstone}\` · 地形对照 ${JSON.stringify(fo.scan?.terrain)}`);
    P(`- **各笼坐标**（scout 区）：${(fo.spawners ?? []).map((s, i) => `#${i + 1} (\`${s.x},${s.y},${s.z}\`)`).join('、')}`);
    P(`- **证据**：${ev('bench/route/probe/fortress.round4c.json')}（数量/区域） + ${ev('bench/route/probe/fortress_standing.round5c.json')}（站位）`);
    P();
    if (standing && standing.status === 'OK') {
        const st = standing.stands;
        P('**站位（本轮补测，ROUND4 那份 52/124 未解析已作废）**');
        P();
        P(`| 项 | 值 |`);
        P(`|---|---|`);
        P(`| 判据 | ${standing.criterion} |`);
        P(`| 判据半径 / 取名半径 | ±${st.criterionRadius} / ±${st.truthRadius}（**取名比判据大 1**：墙判定要读候选格四侧邻格，盒边缘的邻格在盒外） |`);
        P(`| 逐格 | ${standing.cellTruth.cells} 格，**未解析 ${standing.cellTruth.unknown}**（ROUND4 是 52） · 复原失败 ${standing.cellTruth.restoreFails} |`);
        P(`| **可挡火球站位** | **${st.coverStands}** 个（主口径：身体/头正好是 \`air\`，与 ROUND4 判据逐字一致） |`);
        P(`| 空气口径 B | ${st.coverStandsAirLike} 个（把这台 1.16.1 也认的 ${JSON.stringify(st.airNamesSeen)} 算空气）｜差异 ${JSON.stringify(st['air口径差'])} |`);
        P(`| 同判据 + ROUND4 白名单（口径对照） | ${st.coverStandsRound4Set} 个${st.coverStandsRound4Set === st.coverStands ? '（本片脚下与墙都是 `nether_bricks`，两套白名单都认）' : ''} |`);
        P(`| 有地可站（无墙约束，诊断） | ${st.openFloors} 个 |`);
        P(`| 逐格真值 | ${standing.cellTruth.cells} 格全部落盘（\`scout.cover\` 与 probe 的 \`cellTruth.table\`）· 同时命中多个名字的格子 ${standing.cellTruth.multiHitCells ?? '—'} |`);
        P(`| 穷举自证 | Σ 各方块计数 ${standing.gates.exhaustive.identified}/${standing.gates.exhaustive.totalCells}，未识别 ${standing.gates.exhaustive.unidentified}，复原不等 ${standing.gates.exhaustive.restoreMismatch} |`);
        P(`| 端到端自证 | 笼格读到 \`spawner\`（= ROUND4 独立测得的地面真值）：${standing.gates.centerTruth.ok ? '✅' : '❌'} |`);
        P(`| 世界未被改动 | ${(standing.worldRecheck?.drift?.length ?? 0) === 0 ? '✅ 重数无漂移' : `❌ 漂移 ${JSON.stringify(standing.worldRecheck.drift)}`} |`);
        P();
        if (st.coverStands !== st.coverStandsRound4Set) {
            P(`> **口径差已量化**：同一片地方、同一判据，只因 SOLID 白名单不同，结论从 ${st.coverStandsRound4Set} 变成 ${st.coverStands}。`);
            P('> 差异来源：ROUND4 的白名单**没有** `nether_brick_stairs` / `nether_brick_wall` / `chiseled_polished_blackstone` ——');
            P('> 而这正是下界要塞最常见的结构件（同型问题还造成它 52 格读不到）。白名单的逐条依据见 route 的 `scout.cover.solidRation`。');
            P();
        }
        if ((st.coverStandsAirLike ?? st.coverStands) !== st.coverStands) {
            P(`> ⚠ **空气口径会改变结论**：把 ${JSON.stringify(st.airNamesSeen)} 也算空气，站位数从 ${st.coverStands} 变成 ${st.coverStandsAirLike}。`);
            P('> 本单主口径仍取"身体/头 == `air`"（与 ROUND4 逐字一致、可比），差异明细见 `scout.cover.airLike.diff`；');
            P('> 这台服务器为什么认 1.17 才有的 `cave_air` 属待查项（见报告 §4 风险 3）。');
            P();
        } else {
            P(`> 空气口径 A（只认 \`air\`）与 B（把 ${JSON.stringify(st.airNamesSeen)} 也算空气）都是 **${st.coverStands}** 个，差 ${JSON.stringify(st['air口径差'])} —— 本片站位的身体都是真 \`air\`，口径之争不影响本结论。`);
            P();
        }
        P('> **口径更正（设计会话 2026-10-02 夜）**：`cave_air` / `void_air` 是 **1.13 起就有的方块**，1.16.1 本来就有；');
        P('> `smooth_basalt` 才是 **1.17** 才有的。minecraft-data 3.114 的 `pc/1.16.1` 清单**是正确的**，');
        P('> 本机把 754 个名字**全部**接受（`block_palette_1161.validated.json`）与此一致。');
        P('> 我上一版报告把版本读反、并据此怀疑"这台 jar 不是 1.16.1"——**该怀疑作废**。');
        P();
        if (st.stands?.length) {
            P(`**站位精确坐标**（只留在 scout 区，不得进 prompt / 模型记忆 / MISSION）：`);
            P();
            st.stands.forEach((s, i) => P(`${i + 1}. \`(${s.pos.join(',')})\` 脚下 \`${s.feet}\`，墙 ${s.walls} 面（四侧：${s.wallNames.map((n) => `\`${n}\``).join(' / ')}）`));
            P();
        }
    } else {
        P(`**⚠ 站位补测未通过（status=${standing?.status ?? '文件缺失'}）** ⇒ 站位数据不可用，冻结前必须重跑补测。`);
        P();
    }
    P(`- **notes 已写明**：1 笼 = 8 根烈焰棒够打龙、冗余记为风险、勿重试到超时、站位判据只覆盖笼位 ±2 格（更大半径未测）。`);
    P();
} else {
    P('- **取证或 route 缺失**：`fortress.round4c.json` 或 `C3_fortress_spawner` 站缺失 ⇒ 并入口径无法核对。');
    P();
}

// ---------------------------------------------------------------- 三、本轮动作台账
P('## 三、本轮（MC-ROUND5 §C）对 route 做了什么');
P();
if (emitLedger?.changes?.length) {
    emitLedger.changes.forEach((c) => P(`- **${c.kind}**：${c.what}${c.detail ? ` — ${JSON.stringify(c.detail).slice(0, 220)}` : ''}`));
} else {
    P('- （尚未运行 `emit_round5c.mjs`）');
}
P();
P('- **没有做的事**（逐条对齐纪律）：未写 `frozenAt`、未生成 `sha256File`、未改 `S5_stronghold_room` 的站级数据、');
P('  未动 C-1 的原始取证、未碰其它种子与其它开发线的文件。');
P();

// ---------------------------------------------------------------- 四、设计会话 2026-10-02 夜复核的裁决台账
P('## 四、设计会话 2026-10-02 夜复核：六条裁决的落点');
P();
P('| # | 裁决 | 落点 | 状态 |');
P('|---|---|---|---|');
{
    const c3s = route.stations.find((s) => s.id === 'C3_fortress_spawner');
    const s3s = route.stations.find((s) => s.id === 'S3_bastion');
    const fb = route.fallbackOnlyStations ?? [];
    const nf = route.normalFlowStations ?? [];
    P(`| 1 | C3 为主站；S4 不进正常站序，只作 C3 的 fallback；fallback 站处理要与 S1b_lava_pool 一致 | route 顶层 \`normalFlowStations\` = ${JSON.stringify(nf)}；\`fallbackOnlyStations\` = ${JSON.stringify(fb.map((x) => x.id))}（两站都标了 \`routeRole:"fallback-only"\` 并排到数组末尾） | ✅ 已落 |`);
    P(`| 2 | S3 站级中心迁到 C-2 实测片（对齐后约 [336,256]），radius 32，/locate 的旧值留 scout；**前提：先证是同一个堡垒** | \`S3_bastion.station.center\` = ${JSON.stringify(s3s?.station?.center)}、radius ${s3s?.station?.radius}；旧值与 cubiomes 证据在 \`scout.centerMigration\` | ${s3s?.scout?.centerMigration ? '✅ 前置已核（cubiomes 唯一起点）' : '⚠ 未执行'} |`);
    P(`| 3 | S0_sheep：两次 fresh world 数羊；一致⇒填真实中心标 REAL，不一致⇒用 cubiomes 找草原/平原片作中心并保持 UNVERIFIED | 见 **§五 S0_sheep 专项** | ${sheepRes?.status === 'SHEEP_FOUND' ? '✅ 已按派单填入' : (sheepRes?.status && sheepRes.status !== 'FAILED' ? '🛑 停下报告（见 §五）' : '⚠ 实测未完成（见 §五）')} |`);
    P(`| 4 | 刷怪笼只有 1 个：按尽力而为；只有"找不到要塞"才切 fallback，掉落少不重试 | route 顶层 \`orchestratorContract.insufficientSpawners\` + C3 的 \`scout.notes\` | ✅ 已写 |`);
    P(`| 5 | 站位只测 ±2，够用不扩大 | C3 的 \`scout.cover.criterionRadius=${c3s?.scout?.cover?.criterionRadius}\`（已标"已裁决不扩大"） | ✅ 已落 |`);
    P('| 6 | 冻结仍等 B 线开发面板通过 | `frozenAt` 保持 `null` | ✅ 未冻结 |');
    P('| 更正 | `cave_air`/`void_air` 是 1.13 起就有的方块（不是 1.17）；minecraft-data 的 1.16.1 清单是对的，我上一版读反了 | 报告更正节 + C3 `scout.notes` + 本清单 §2.3 | ✅ 已更正 |');
    P('| 更正 | C1 notEmitted 理由删掉"crying_obsidian 要钻石镐"（铁镐 41.7s 可挖、只是不掉落），删掉 keepAsReference 里的钻石镐路线 | route `notEmitted[].reason` 只剩两条 + `correctedAway` 留痕 | ✅ 已更正 |');
}
P();
P('### 编排器契约（新增字段，建议写进 SCHEMA）');
P();
P('> ⚠ `bench/route/SCHEMA.md` 规定"只有设计会话能改"，所以本单**只往 route 数据里加了字段、没有改规范**。');
P('> `route_guard.mjs:57-58` 要求 **seq 必须 1 起不重复的连续整数** ⇒ 无法用 seq 空隙表达"不在正常流程"，');
P('> 因此用显式字段：`routeRole` / `normalFlowStations` / `fallbackOnlyStations` / `orchestratorContract`。');
P();
if (route.orchestratorContract) {
    const oc = route.orchestratorContract;
    P(`- **正常流程**：${oc.normalFlow}`);
    P(`- **fallback**：${oc.fallback}`);
    P(`- **刷怪笼不足**：${oc.insufficientSpawners}`);
    P(`- **新增字段**：${oc.newFields}`);
}
P();

// ---------------------------------------------------------------- 五、S0_sheep 专节
P('## 五、`S0_sheep` 专项（复核指令 3）');
P();
{
    const s0 = route.stations.find((s) => s.id === 'S0_sheep');
    P(`- **当前状态**：scout \`${s0?.scout?.verify?.status}\` · 站级 center ${JSON.stringify(s0?.station?.center)}（0 % 8 = 0，过得了 route_guard，但**会把 bot 导到 340 格外**）`);
    P(`- **出生点真值**：(${sheepRes?.spawn?.x ?? '?'},${sheepRes?.spawn?.z ?? '?'}) 群系 \`${sheepRes?.spawn?.biome ?? '?'}\`（SEED-01 \`top_ranked.csv\`）· 距 S1 门 ${sheepRes?.spawnDistance ?? '?'} 格`);
    P();
    P('**两个必须先说清的事实**（都不是本单推测，是查证的）：');
    P();
    P('1. **羊是实体，不是方块** ⇒ `fill <box> barrier replace minecraft:sheep` 永远数不到羊。'
        + 'ROUTE-02 当初把本站标 UNVERIFIED 的理由（"羊是实体随机生成，赛前无法用 fill-replace 核验"）**是对的**；'
        + '实体计数只能走 1.16.1 的 `as @e[type=…] run <每实体一次回执>` 通道。');
    P('2. **实跑口径是 `peaceful`**（`bench/stages/fullrun/run_bench.mjs:115`「本单口径是 peaceful」；各 lane 模板的 `server.properties` 也都是 `difficulty=peaceful`）。'
        + '而 1.16.1 被动生物的初始生成在 peaceful 下是否发生，决定这个站是"中心填错"还是"从根上不成立"。');
    P();
    if (sheepRes) {
        P(`**实测**：${sheepRes.worlds?.length ?? 0} 个 fresh world，${sheepRes.seconds ?? '?'}s，status \`${sheepRes.status}\``);
        P();
        if (sheepRes.readout?.length) {
            P('| world | 难度 | 羊 | 牛 | 猪 | 鸡 | 地形对照（grass_block / stone / water / chest） |');
            P('|---|---|---|---|---|---|---|');
            for (const r of sheepRes.readout) {
                P(`| ${r.label} | ${r.difficultyAfter ?? '（未改）'} | **${r.sheep}** | ${r.cow} | ${r.pig} | ${r.chicken} | ${r.controls.grass_block ?? 0} / ${r.controls.stone ?? 0} / ${r.controls.water ?? 0} / ${r.controls.chest ?? 0} |`);
            }
            P();
        }
        P(`**判读**：${sheepRes.conclusion ?? '（无）'}`);
        P();
        P(`- 闸门：地形对照 ${sheepRes.gates?.terrainControl ? '✅ 正常' : '❌ 异常'} · 实体通道 ${sheepRes.gates?.channelWorks ? '✅ 回执已探明' : '❌ 不可用'} · 两次同条件一致 ${sheepRes.gates?.twoWorldsConsistent ?? '（未跑第二个同条件 world）'}`);
        P(`- 证据：${ev('bench/route/probe/sheep.round5c.json')}`);
        P();
        if (sheepRes.status === 'SHEEP_FOUND') {
            P(`⇒ 按派单：填真实中心并标 REAL。**本单已填**：center ${JSON.stringify(s0?.station?.center)}，状态 \`${s0?.scout?.verify?.status}\`。`);
            P();
        } else {
            P('> 🛑 **按手册 §4.8「遇到颠覆性结论先停下报告」：本单不擅自改这个站的存废与状态**，');
            P('> 等设计会话裁决。可选项：① 改实跑难度（非 peaceful）让羊刷出；② 删站，食物改走废弃房屋箱子/别的来源；');
            P('> ③ 保留 UNVERIFIED 但把 center 指向出生点平原（(216,224)，89 格到 S1 顺路）—— 注意**这不等于 REAL**。');
            P();
        }
    } else {
        P('> 尚未产出 `sheep.round5c.json`（本单未完成该项实测）。');
        P();
    }
}

// ---------------------------------------------------------------- 六、冻结前待裁决
P('## 六、冻结前待裁决（设计会话）');
P();
{
    const todo = [
        '**`S0_sheep` 的存废与状态**（见 §五）：本单已把事实摆齐，**不擅自改站**，等你裁决。',
        '**把新增的编排器字段写进 `bench/route/SCHEMA.md`**：`routeRole` / `normalFlowStations` / `fallbackOnlyStations` / `orchestratorContract`（只有设计会话能改规范）。',
        '**S4_fortress_spawner 的数据处置**：现在它是 `C3` 的 fallback（1 个笼，607 格外）。若两个站都跑，掉落少也不重试（裁决 4）；是否要让 fallback 换站时降级为"不满足即放弃"，也由你定。',
        '**两片堡垒的服务器侧连续性确认**（可选加固）：cubiomes 已给出"唯一起点"这条设计会话认可的判据；若想在 route 里再钉死，可另开一单数两片之间的连续堡垒方块。',
        '以上落定后再**写 `frozenAt` + 生成 `<seed>.sha256`**（SCHEMA §2/§3），并按 §5 记一行（种子、sha256、审阅人）。',
    ];
    todo.forEach((t, i) => P(`${i + 1}. ${t}`));
}
P();
P('> 派单 C-4 + 复核指令 6：**冻结等 B 线开发面板通过后由设计会话做**，本单不写 `frozenAt`。');
P();

const outPath = path.join(REVIEW_DIR, `${SEED}.review.v2.md`);
fs.mkdirSync(REVIEW_DIR, { recursive: true });
fs.writeFileSync(outPath, out.join('\n'));
console.log(`✓ ${path.relative(path.join(ROUTE_DIR, '..', '..'), outPath)}`);
console.log(`  站数 ${route.stations.length}（REAL ${route.stations.filter((s) => s.scout?.verify?.status === 'REAL').length}）`);
console.log(`  站位补测 status=${standing?.status ?? '缺失'}，可挡火球站位 ${standing?.stands?.coverStands ?? '—'} 个`);
console.log(`  route 文件未改动（frozenAt 仍为 ${JSON.stringify(route.frozenAt)}）`);
