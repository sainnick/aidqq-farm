// truth.mjs — MC-S2-01（F 线 · S2 易物原型）的服务端真值通道
//
// 为什么自己写一份而不 import C 线的 bench/route/tools/scan.mjs：
//   跨 stage 依赖会让别线一改就把本线带崩；手册 §9.2 也要求各线只在自己的目录下工作。
//   下面的配对纪律是 C 线 MC-FRAME-BATCH-01 踩坑换来的，**照抄，不要"优化"掉**：
//     ① 发命令前必须先消费掉**还在路上的**上一条回执（"发前排空缓冲"对在途回执无效——
//        C 线实测：同一片 obsidian 实为 7，紧挨着发命令读成 0，下一条读成 9）；
//     ② 只认本条命令**之后**到达的回执，不跨命令配对；
//     ③ 超时 = 流不可信 → **硬失败**，不重试（重试只会把错位放大成"看起来正常但坐标是错的"）。
//
// 1.16.1 上唯一可靠的"条件真值"通道是 `/fill` 的回执（已由 C 线 cmd_channel_smoke.mjs 钉死）：
//   ① **没有 /say**（1.17 才有）；② tellraw 零玩家时不落控制台。
//   所以"某格是不是 X"一律走 `fill <单格> barrier replace <X>` → 回执 1 = 是（并复原）。
//
// ⚠ **多类回执必须共用一个队列**（本文件 v1 的真 bug，写在这里防止有人再犯）：
//   回执有三类（fill / data / gametime），时钟轮询（4Hz）和实体查询会**同时在途**。
//   v1 让每类各自 `drain()` 整个缓冲、不匹配的行直接丢掉 ⇒ 时钟的回执被 `data` 查询吞掉，
//   时钟类永远等不到自己的回执 → 5s 后**把整条通道判死**，后面所有真值查询全废。
//   现在改成：`drain()` 进来的行一律进共享 `queue`，每类只从队列里取**自己正则匹配的第一条**
//   （到达顺序 = FIFO），不匹配的行留在队列里给别的类。
//
// 维度：C 线已实测 1.16.1 支持 `execute in minecraft:the_nether run …`（E 线也用它跨维度 tp）。
//   控制台命令源没有实体（**没有 @s**），坐标一律写绝对值。

import fs from 'fs';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const RE_FILLED = /Successfully filled (\d+) blocks/;
const RE_NONE = /No blocks were filled/;
/** fill 的**两种**回执都算"这条命令有回执了"——只等一种会把通道等死（S2_CHAN 实测） */
const RE_FILL_ANY = new RegExp(`${RE_FILLED.source}|${RE_NONE.source}`);
const RE_NOTLOADED = /not loaded|couldn't be loaded/i;
// ⚠ 1.16.1 的 `time query gametime` 回执是 **"The time is 1"**（不是 1.17+ 的 "The game time is 1"）。
//   S2_P1_PROBE 首跑就栽在这：正则没命中 → 时钟类永远等不到回执 → 5s 后把整条通道判死。
const RE_GAMETIME = /The (?:game )?time is (\d+)/i;
const RE_DATA = /has the following (?:entity|block) data/;

export const MARKER = 'minecraft:barrier';
const PROBE = 'minecraft:command_block';   // 回执用的独立目标格（与 MARKER 不同块，可分辨）
const QUEUE_CAP = 5000;                   // 共享队列上限（见 pump 的注释）

export function dimPre(dim) {
    if (dim === 'the_nether') return 'execute in minecraft:the_nether run ';
    if (dim === 'the_end') return 'execute in minecraft:the_end run ';
    return '';
}

/**
 * `execute in <dim> at <实体> ` 前缀（**不带 run**，后面的子命令自己带）。
 *
 * ⚠⚠ **这里曾经是我自己写出来的 bug，而且它伪装成"1.16.1 不支持这个形态"**：
 *   早先 `dataEntity`/`countEntities` 用的是 `dimPre(dim) + 'at … run …'`
 *   ⇒ 实际发出的是 `execute in minecraft:the_nether **run at** BarterBotC run data get …`
 *   ⇒ run 后面接 at **不是合法子命令** ⇒ 服务端 100% 回 "Incorrect argument for command"。
 *   于是我先后把结论误判成「选择器形态不行」「`as`+`@s` 不行」「`sort=nearest` 不行」，
 *   绕了三大圈。**教训：先把"我发出去的命令原文"和"服务端回显的命令原文"逐字对一遍**——
 *   server.log 里 `… run at BarterBotC run … <--[HERE]` 的那个 `run at` 就是全部答案。
 *   （设计会话 10-02 夜复核时抓到的，设计会话对。）
 */
export function dimAt(dim, atEntity) {
    if (dim === 'the_nether') return `execute in minecraft:the_nether at ${atEntity} `;
    if (dim === 'the_end') return `execute in minecraft:the_end at ${atEntity} `;
    return `at ${atEntity} `;
}

/** 每一类回执单独记账：配对只在同类内进行（跨类不互相等） */
class Chan {
    constructor() { this.sent = 0; this.got = 0; this.late = 0; }
}

export class Truth {
    constructor({ child, logPath, log = () => {} }) {
        this.child = child;
        this.logPath = logPath;
        this.log = log;
        this.offset = 0;
        this.queue = [];
        this.dropped = 0;
        this.poisoned = null;
        this.chans = new Map();
        this.notes = [];
        this._locks = new Map();          // 回执类互斥（见 withLock 注释）
    }

    chan(name) {
        let c = this.chans.get(name);
        if (!c) { c = new Chan(); this.chans.set(name, c); }
        return c;
    }

    /** 裸发一条控制台命令（不等回执；用于 tp/give/difficulty 这类无回执命令） */
    raw(cmd) {
        try { this.child.stdin.write(`${cmd}\n`); return true; }
        catch (e) { this.log(`raw 发送失败 ${cmd}: ${e}`); return false; }
    }

    /** 读 server.log 增量。⚠ 按**字节**切行：日志里有中文，按字符串长度回退偏移会在
     *  多字节字符处算错字节数 → 偏移漂移 → 回执重复或丢失（回执是 FIFO 的，重复即错位）。 */
    drain() {
        let size = 0;
        try { size = fs.statSync(this.logPath).size; } catch { return []; }
        if (size <= this.offset) return [];
        let buf;
        try { buf = fs.readFileSync(this.logPath); } catch { return []; }
        const slice = buf.subarray(this.offset, size);
        const nl = slice.lastIndexOf(0x0a);
        if (nl < 0) return [];
        const complete = slice.subarray(0, nl + 1);
        this.offset += complete.length;
        return complete.toString('utf8').split(/\r?\n/).filter((l) => l && l.trim());
    }

    /** 把新行灌进共享队列。
     *  ⚠ 队列里允许留**不匹配**的行（join 行、chunk 加载行…），但必须封顶：
     *    不封顶会随运行时长线性增长；一旦有无关行**碰巧**命中某个类的正则就会错配。
     *    超限时丢最旧的（丢多少记在 stats 里，出事能查）。 */
    pump() {
        if (this.child.exitCode !== null) this.poison(`server rc=${this.child.exitCode}`);
        for (const l of this.drain()) this.queue.push(l);
        if (this.queue.length > QUEUE_CAP) {
            this.dropped += this.queue.length - QUEUE_CAP;
            this.queue.splice(0, this.queue.length - QUEUE_CAP);
        }
        return this.queue.length;
    }

    /** 从队列里取**第一条**匹配的行（到达顺序 = FIFO）；不匹配的留给别的类 */
    take(re) {
        for (let i = 0; i < this.queue.length; i++) {
            if (re.test(this.queue[i])) return this.queue.splice(i, 1)[0];
        }
        return null;
    }

    /** 队列里还没被任何类取走的、匹配 pattern 的行（自检/诊断用，不记账） */
    peek(re) {
        return this.queue.find((l) => re.test(l)) ?? null;
    }

    poison(msg) {
        this.poisoned = this.poisoned ?? msg;
        throw new Error(`TRUTH_POISONED: ${this.poisoned}`);
    }

    /**
     * 发一条命令并等它的回执（同类内严格 FIFO）。
     * @param {string} name 回执类
     * @param {string} cmd  命令
     * @param {RegExp} match 回执判据
     * @param {object} o    { timeoutMs, soft } soft=true 时超时返回 null 而不判死通道
     */
    async ask(name, cmd, match, { timeoutMs = 15000, soft = false } = {}) {
        if (this.poisoned) this.poison(this.poisoned);
        const c = this.chan(name);
        // ① 先把本类在途的回执消费掉
        if (c.sent > c.got) {
            const tw = Date.now();
            while (Date.now() - tw < Math.min(timeoutMs, 5000) && c.sent > c.got) {
                this.pump();
                if (this.take(match)) { c.got++; c.late++; }
                await sleep(20);
            }
            if (c.sent > c.got) {
                if (soft) { c.got = c.sent; return null; }   // ⚠ 软失败必须把账做平，
                //   否则这一类永远 sent>got ⇒ 之后每条命令都要白等 5s 消费"不存在的回执"
                //   ⇒ 表现是「所有 data get 查询都超时、hand 系列全是 no_receipt」
                this.poison(`类 ${name} 在途回执 ${c.sent - c.got} 条 5s 未到（拒绝继续以免产出错数据）`);
            }
        }
        c.sent++;
        this.raw(cmd);
        const t0 = Date.now();
        while (Date.now() - t0 < timeoutMs) {
            this.pump();
            const hit = this.take(match);
            if (hit) { c.got++; return hit; }
            await sleep(20);
        }
        if (soft) { c.sent--; return null; }   // ⚠ 软失败**必须把 sent 退回去**：
        //   否则这条类永远 sent>got ⇒ 之后每条命令都要先等 5s 消费"不存在的回执" ⇒ 5s 后整条通道判死
        this.poison(`类 ${name} 的回执 ${timeoutMs}ms 未到：${cmd.slice(0, 140)}`);
        return null;
    }

    /**
     * `fill <盒> <marker> replace <block>` 的回执计数。
     * ⚠ **回执有两种**（S2_CHAN 实测踩到）：`Successfully filled N blocks`（命中）与
     *   `No blocks were filled`（该盒没有目标方块）。只等前一种 ⇒ 未命中时等满超时
     *   ⇒ 把整条通道判死。`probeCell` 靠"返回 0"才能往下试下一个候选。
     * 未加载区块会重发同一条（1.16.1 的 fill 对未加载区块是静默失败）。
     */
    async fillCount(dim, box, block, { marker = MARKER, asReplace = false, timeoutMs = 25000, soft = false } = {}) {
        const pre = dimPre(dim);
        const cmd = asReplace
            ? `${pre}fill ${box.x1} ${box.y1} ${box.z1} ${box.x2} ${box.y2} ${box.z2} ${block} replace ${marker}`
            : `${pre}fill ${box.x1} ${box.y1} ${box.z1} ${box.x2} ${box.y2} ${box.z2} ${marker} replace ${block}`;
        // 同类回执两种文本都算"本条到了"（FIFO 配对只认"第一条到达的 fill 回执"）
        // ⚠ **S2-04 新增 `soft`**：大盒（232,960 格）一次 fill 服务端 40s 回不出回执
        //   ⇒ 硬失败会把**整条 fill 通道判死**，后面所有读数全丢（`runs/S2_S4B5/error.json`）。
        //   ⇒ 切片统计时传 `soft:true`：该片读不到就退账（`sent--`）并返回 `null`，
        //   **不 poison**，调用方把 `null` 记成"该片未知"而不是"该片为 0"。
        const line = await this.ask('fill', cmd, RE_FILL_ANY, { timeoutMs, soft });
        if (line == null) return null;              // soft 失败 = 没读到，**不是 0**
        const m = line.match(RE_FILLED);
        return m ? parseInt(m[1], 10) : 0;
    }

    /** 单格非破坏性判据：`fill <单格> barrier replace <候选>` → 1 = 是；再换回来，回执也必须是 1 */
    async probeCell(dim, p, candidates) {
        const box = { x1: p.x, y1: p.y, z1: p.z, x2: p.x, y2: p.y, z2: p.z };
        for (const c of candidates) {
            const hit = await this.fillCount(dim, box, c, { marker: MARKER });
            if (hit === 0) continue;
            const back = await this.fillCount(dim, box, c, { marker: MARKER, asReplace: true });
            return { hit: c, restoreOk: back === 1 };
        }
        return { hit: null, restoreOk: false };
    }

    /**
     * 服务端时钟：`time query gametime`（1.13 加，1.16.1 有）。
     * gameTime 是**每个世界层各存一份**，控制台命令源在主世界 ⇒ 绝对值跨层无意义，
     * 但只做差值用没问题（两层同刻创建、偏移恒定）。
     */
    async gametime(dim = 'overworld', { soft = true } = {}) {
        return this.withLock('timeq', async () => {
            const line = await this.ask('timeq', `${dimPre(dim)}time query gametime`, RE_GAMETIME, { timeoutMs: 8000, soft });
            const m = line?.match(RE_GAMETIME);
            return m ? parseInt(m[1], 10) : null;
        });
    }

    /**
     * 通用互斥：**同一回执类同一时刻只允许一条命令在途**。
     * 为什么必须有：1.16.1 里 `time query gametime/day/daytime` 的回执文本**完全一样**
     * （"The time is N"），`data get` 各种 path 也共用一条正则 ⇒ 两个消费者同时在途
     * 就会**互抢回执**，被抢的一方永远等不到 → 5s 后把整条通道判死。
     */
    withLock(name, fn) {
        const prev = this._locks.get(name) ?? Promise.resolve();
        const next = prev.then(fn, fn);
        this._locks.set(name, next.then(() => {}, () => {}));
        return next;
    }

    /**
     * 单个实体的 NBT。**1.16.1 可用形态（probe_channel_variants 定向对照实测）**：
     *   ✓ `execute in <dim> at <实体> run data get entity <选择器,limit=1> <路径>`  ← **就用这个**
     *       （`Pos` / `Health` / `HandItems[0].id` 全部拿到：Health=16.0f 正好佐证猪灵满血 16）
     *   ✗ `… as <选择器> run data get entity @s <路径>`   ← 解析期失败（我一度误以为这个才对）
     *   ✗ `… run data get entity <选择器,limit≥2> <路径>` ← "Only one entity is allowed"
     *   ✓ `… run data get entity <玩家名> <路径>`
     *   ⚠ 1.16 的 `data get` **要求选择器只命中一个实体** ⇒ 计数不能靠它（用 kill 回执的数字）。
     */
    async dataEntity(dim, atEntity, sel, path, { timeoutMs = 12000, soft = false } = {}) {
        const cmd = `${dimAt(dim, atEntity)}run data get entity ${sel} ${path}`;
        return this.withLock('data', () => this.ask('data', cmd, RE_DATA, { timeoutMs, soft }));
    }
    async dataBlock(dim, p, path, { timeoutMs = 12000, soft = false } = {}) {
        const cmd = `${dimPre(dim)}data get block ${p.x} ${p.y} ${p.z} ${path}`;
        return this.ask('data', cmd, RE_DATA, { timeoutMs, soft });
    }

    /**
     * 数实体（服务端真值）。`execute as <多目标选择器> run <cmd>` 会按匹配实体**逐个执行**
     * ⇒ 回执行数 = 个数。两条可选形态，回执文本不同：
     *   · mode='data'（默认，**优先**）：`as <sel> run data get entity @s Pos`
     *     —— 顺带把每头的坐标拿回来；回执正则与时钟的 time query 不同，**不会互抢**。
     *   · mode='timeq'：`as <sel> run time query day`（1.16.1 下 0 匹配是零输出 ⇒ 用静默窗收尾）。
     *
     * ⚠ **零行早退窗口必须给够**（S2_P1_PROBE 实测踩到）：56 头时服务端要跑一会儿才吐完，
     *   早退窗口 1.2s ⇒ 数到 0 头，而迟到的 56 条被时钟类当自己的样本吃掉
     *   （日志表现：一串快速递增的 "The time is N"）。现在 minWaitMs 默认 6s。
     */
    async countEntities(dim, atEntity, sel, { quietMs = 500, minWaitMs = 6000, timeoutMs = 25000, mode = 'timeq' } = {}) {
        const useData = mode === 'data';
        const re = useData ? RE_DATA : RE_GAMETIME;
        const cls = useData ? 'data' : 'timeq';
        const inner = useData ? 'data get entity @s Pos' : 'time query day';
        const cmd = `${dimAt(dim, atEntity)}as ${sel} run ${inner}`;
        return this.withLock(cls, async () => {
            // 先消费本类在途回执（与 ask 的纪律一致）
            const c = this.chan(cls);
            if (c.sent > c.got) {
                const sw = Date.now();
                let last = Date.now();
                while (Date.now() - sw < 4000) {
                    this.pump();
                    if (this.take(re)) last = Date.now();
                    if (Date.now() - last >= Math.min(quietMs, 400)) break;
                    await sleep(20);
                }
                c.got = c.sent;
            }
            c.sent++;
            this.raw(cmd);
            const lines = [];
            const t0 = Date.now();
            let last = Date.now();
            while (Date.now() - t0 < timeoutMs) {
                this.pump();
                const hit = this.take(re);
                if (hit) { lines.push(hit); last = Date.now(); continue; }
                const idle = Date.now() - last;
                // 见到第一行后：静默 quietMs 收尾；还没见到任何行：至少等 minWaitMs
                if (lines.length && idle >= quietMs) break;
                if (!lines.length && idle >= minWaitMs) break;
                await sleep(20);
            }
            // 收尾再扫一遍：把"刚好卡在窗口边界"的迟到行也收进来（否则它们会污染别的类）
            this.pump();
            for (let i = 0; i < 3; i++) { const h = this.take(re); if (!h) break; lines.push(h); await sleep(60); this.pump(); }
            c.got++;
            return { n: lines.length, lines, trusted: lines.length > 0 ? true : (Date.now() - t0 >= minWaitMs) };
        });
    }

    // ---- 服务端时钟同步（把客户端 wall clock 对齐到服务端 gametime）----
    /**
     * 背景轮询 `time query gametime`，记 (clientMs, ticks)。duration 一律换算成**服务端 tick**
     * 再除以实测 TPS —— 手册 §9.3：TPS = world age 增量 ÷ 墙钟秒数（**不要再除以 20**）。
     * 服务器跑不到 20 TPS 时"tick 数 × 50ms"是错的。
     */
    startClock({ hz = 3, dim = 'the_nether' } = {}) {
        const samples = [];
        let running = true;
        let errors = 0;
        const loop = async () => {
            while (running) {
                try {
                    const t = await this.gametime(dim);
                    if (t != null) {
                        // ⚠ 只收**单调递增**的样本：别的命令的回执文本与本类相同（1.16.1 的
                        //   time query gametime/day/daytime 全是 "The time is N"）时，
                        //   混进来的样本会让最小二乘斜率变负（TPS 读成 -0.09）。
                        const last = samples[samples.length - 1];
                        if (!last || t > last.ticks) samples.push({ ms: Date.now(), ticks: t });
                    }
                    while (samples.length > 240) samples.shift();
                } catch (e) {
                    // 单次失败不致命（回执错位/服务端正忙），退避后重试；只有连续失败才停
                    if (++errors > 20) { running = false; break; }
                    if (this.poisoned) { running = false; break; }
                    await sleep(500);
                    continue;
                }
                errors = 0;
                await sleep(Math.max(40, Math.round(1000 / hz)));
            }
        };
        loop();
        this.clock = {
            samples, n: () => samples.length,
            stop: () => { running = false; },
            now: () => {
                if (samples.length < 2) return null;
                const a = samples[samples.length - 2], b = samples[samples.length - 1];
                const dt = b.ms - a.ms;
                return dt <= 0 ? b.ticks : b.ticks + ((Date.now() - b.ms) / dt) * (b.ticks - a.ticks);
            },
            /** 实测 TPS：最近 20 个样本做最小二乘（ticks/ms × 1000）；样本不足时用能有的那些 */
            tps: () => {
                if (samples.length < 2) return null;
                const s = samples.slice(-20);
                const n = s.length;
                let sx = 0, sy = 0, sxx = 0, sxy = 0;
                for (const p of s) { sx += p.ms; sy += p.ticks; sxx += p.ms * p.ms; sxy += p.ms * p.ticks; }
                const den = n * sxx - sx * sx;
                if (!den) return null;
                const v = ((n * sxy - sx * sy) / den) * 1000;
                return v > 0 && v < 100 ? +v.toFixed(2) : null;   // 明显离谱就不给读数（null = 未知）
            },
            tickAt: (clientMs) => {
                if (samples.length < 2) return null;
                const a = samples[0], b = samples[samples.length - 1];
                const dt = b.ms - a.ms;
                return dt ? a.ticks + ((clientMs - a.ms) / dt) * (b.ticks - a.ticks) : b.ticks;
            },
            secs: (ticks) => ticks / (this.clock?.tps?.() ?? 20),
        };
        return this.clock;
    }

    /** 通道自检：任何真值数据之前必须先跑它（手册 §5：先证伪测量通道） */
    async selfCheck({ dim = 'the_nether', at = { x: 0, y: 40, z: 0 }, atEntity = null } = {}) {
        // at 允许传数组（park.park）也允许传 {x,y,z}，统一成点
        const raw = Array.isArray(at) ? { x: at[0], y: at[1], z: at[2] } : at;
        // ★ S2-03：`fill` / `data get block` **只接受整数方块坐标**。传 `botPos()`（带小数，如 336.5）
        //   会让服务端**不给 fill 回执** ⇒ 6s 后整条 `fill` 类被判死（TRUTH_POISONED）
        //   ⇒ 后面所有真值查询全废（B5 首次跑就是这样 0.9 分钟结束的）。
        //   ⇒ 这里一律 floor；`P.raw` 保留原值只作留证。
        const P = { x: Math.floor(raw.x), y: Math.floor(raw.y), z: Math.floor(raw.z) };
        const out = { at: new Date().toISOString(), atCell: P, atRaw: [raw.x, raw.y, raw.z] };
        // ① time query gametime（两个维度各一次，顺便看层级偏移）
        try {
            const a = await this.gametime('overworld');
            const b = await this.gametime('the_nether');
            out.gametime = { overworld: a, the_nether: b, delta: (a != null && b != null) ? b - a : null };
        } catch (e) { out.gametime = { error: String(e).slice(0, 200) }; }
        // ② forceload（1.16.1 **有**这个命令，单次上限 256 区块；这里只是确认它在、回执长什么样）
        this.raw('forceload add 0 0 1 1');
        await sleep(700);
        this.pump();
        out.forceload = this.queue.find((l) => /force loaded|Too many chunks|Incorrect|Unknown/i.test(l))?.slice(0, 160) ?? '(no receipt)';
        // ③ 实体计数（`as <sel> run time query day` 逐实体一行）
        try {
            if (!atEntity) throw new Error('NEED_AT_ENTITY（countEntities 的 `execute at` 只能给实体名）');
            const r = await this.countEntities(dim, atEntity, '@e[type=piglin]', { quietMs: 350, timeoutMs: 8000 });
            out.countEntities = { n: r.n, trusted: r.trusted, sample: r.lines[0]?.slice(0, 120) ?? null };
        } catch (e) { out.countEntities = { error: String(e).slice(0, 200) }; }
        // ④ 单个实体 NBT（`at <实体>` 位置上下文 + 直接写选择器；1.16.1 的 at **不支持坐标**）
        try {
            if (!atEntity) throw new Error('NEED_AT_ENTITY（1.16.1 的 execute at 不接受坐标，只能给实体名）');
            const l = await this.dataEntity(dim, atEntity, '@e[type=piglin,limit=1]', 'Pos', { timeoutMs: 5000, soft: true });
            out.dataGetEntity = l ? l.slice(0, 160) : '(no receipt)';
        } catch (e) { out.dataGetEntity = { error: String(e).slice(0, 200) }; }
        // ⑤ data get block：**软失败**（普通方块没有 block entity，会报 "not a block entity"，
        //    那本身就是有效信息，但不能因此把通道判死）
        try {
            const l = await this.dataBlock(dim, P, 'Items', { timeoutMs: 4000, soft: true });
            out.dataGetBlock = l ? l.slice(0, 160) : '(no block-entity receipt —— 普通方块，符合预期)';
        } catch (e) { out.dataGetBlock = { error: String(e).slice(0, 200) }; }
        // ⑥ fill 回执（单格，两层都要 1）
        try {
            const cell = { x1: P.x, y1: P.y, z1: P.z, x2: P.x, y2: P.y, z2: P.z };
            const n1 = await this.fillCount(dim, cell, 'minecraft:air', { marker: PROBE, timeoutMs: 6000 });
            const n2 = await this.fillCount(dim, cell, 'minecraft:air', { marker: PROBE, asReplace: true, timeoutMs: 6000 });
            out.fillReceipt = { probe: n1, restore: n2, note: '两层都应为 1（该格是 air 时）' };
        } catch (e) { out.fillReceipt = { error: String(e).slice(0, 200) }; }
        this.notes.push(out);
        return out;
    }

    stats() {
        return {
            queue: this.queue.length, dropped: this.dropped, poisoned: this.poisoned,
            chans: Object.fromEntries([...this.chans].map(([k, v]) => [k, { sent: v.sent, got: v.got, late: v.late }])),
        };
    }
}

/** 解析 `… entity data: Pos: [1.0d, 2.0d, 3.0d]` 里的三元组 */
export function parsePos(line) {
    const m = /Pos:\s*\[(-?[\d.]+)d?,\s*(-?[\d.]+)d?,\s*(-?[\d.]+)d?\]/.exec(line ?? '');
    return m ? { x: +m[1], y: +m[2], z: +m[3] } : null;
}
/** 解析 `Age: 12s`（1.16.1 的 Age 是带 s 的 short） */
export function parseAge(line) {
    const m = /Age:\s*(-?\d+)s/.exec(line ?? '');
    return m ? parseInt(m[1], 10) : null;
}
export function parseCount(line) {
    const m = /Count:\s*(\d+)[bsl]?/.exec(line ?? '');
    return m ? parseInt(m[1], 10) : null;
}

/**
 * ★ S2-04：解析 `data get entity <bot> Inventory` 的**服务端装备槽真值**。
 *
 * 🚨🚨 **槽位编号是 100–103，不是 5–8**（源码 `Inventory.java:343-348`：
 *   `tag.putByte("Slot", (byte)(i + 100))`）。含义：
 *   **100=feet(靴) / 101=legs(护腿) / 102=torso(胸甲) / 103=head(头盔)**。
 *
 * 5–8 是 **mineflayer 客户端** `bot.inventory.slots[5..8]` 的显示编号，两套编号不同。
 * 按 5–8 解析服务端 NBT ⇒ 永远数出 0 件金甲 ⇒ **在"确实穿了 4 件"的局里
 * 报"没穿金"**，而局照跑、指标照好看 —— 纯静默假阴性。
 * （S2-04 第一版就踩了这个坑，已修；回归锁见 `mode3_selftest.mjs` ⑪。）
 *
 * 判据源码（`PiglinAi.java:592-601` `isWearingGold`）：遍历 `getArmorSlots()`，
 * **任意一件**金质护甲即 true —— 背包里的不算，**必须穿在装备槽上**。
 *
 * @param {string|null} line 服务端回执原文；null/空 ⇒ `readFailed`（**不是"没穿"**）
 * @returns {{readFailed:boolean, worn:Array, armor:Array, goldCount:number, leatherCount:number,
 *            full:boolean, anyGold:boolean, verdict:string}}
 */
export const ARMOR_SLOT_IDS = { 100: 'feet', 101: 'legs', 102: 'torso', 103: 'head' };
export function parseArmorNbt(line) {
    const out = {
        readFailed: true, worn: [], armor: [],
        goldCount: 0, leatherCount: 0, full: false, anyGold: false, verdict: 'read_failed',
    };
    if (!line) return out;
    // ⚠⚠⚠ **回执里没有 `Inventory:` 这个标签**（S2-04 实服踩到）：
    //   1.16.1 对 `data get entity <玩家> Inventory` 的回执是
    //   `BarterBotC has the following entity data: [{Slot: 0b, id: "minecraft:gold_ingot", Count: 64b}, …]`
    //   —— **数组是根值，没有 `Inventory:` 前缀**。
    //   写成 `/Inventory:\s*(\[[\s\S]*\])/` ⇒ 永远不匹配 ⇒ `readFailed` 恒 true
    //   ⇒ 装备真值通道静默判死，而局照跑、其它指标照好看。
    //   ⇒ **两种形态都收**：带标签的（部分版本/其它命令）与裸数组的（1.16.1 实发）。
    //   反过来也要认：回执里**压根没有数组**（如 `has no data available.`）才算 readFailed。
    const tagged = /Inventory:\s*(\[[\s\S]*\])/.exec(line);
    const bare = /(?:entity data:\s*)(\[\{[\s\S]*\}\])/.exec(line);
    const m = tagged ?? bare;
    if (!m) return out;                       // 回执在但不是物品数组 ⇒ 仍算读不到
    // 1.16.1 实发是 `}, {Slot:`（**逗号+空格**分隔），`\},\s*\{` 两种都覆盖
    for (const grp of m[1].split(/\},\s*\{/)) {
        // ⚠⚠ **`id:` 后面有空格**：1.16.1 的 NBT toString 形态是 `{Slot: 0b, id: "minecraft:xxx", Count: 1b}`。
        //   写成 `/id:"minecraft:…"/`（少个 `\s*`）⇒ **一件都解析不出来**，而回执明明在手上
        //   ⇒ 装备真值恒为 `no_gold`，看起来像"bot 没穿金甲"。
        //   （S2-04 的自检阳性对照当场逮住：两种写法只差一个空格。）
        //   `Slot` 同样容空白。两种格式（`id: "` / `id:"`）都收。
        const slot = /Slot:\s*(-?\d+)b/.exec(grp)?.[1];
        const id = /id:\s*"minecraft:([a-z_0-9]+)"/.exec(grp)?.[1];
        if (slot == null || id == null) continue;
        out.worn.push({ slot: +slot, id, where: ARMOR_SLOT_IDS[+slot] ?? 'inventory_or_unknown' });
    }
    out.readFailed = false;
    out.armor = out.worn.filter((w) => ARMOR_SLOT_IDS[w.slot]);
    out.goldCount = out.armor.filter((w) => w.id.startsWith('golden_')).length;
    out.leatherCount = out.armor.filter((w) => w.id.startsWith('leather_')).length;
    out.full = out.goldCount === 4;
    out.anyGold = out.goldCount >= 1;
    out.verdict = out.goldCount >= 4 ? 'full_gold' : out.goldCount >= 1 ? 'partial_gold' : 'no_gold';
    return out;
}

/**
 * ★ S2-04：珍珠用时统计（E 与 P90）。**纯函数，离线可测**。
 *
 * 口径（手册 §5「时间指标按全部 trial 计算（失败局记为预算值）」）：
 *   · 达标局用 `sec`（背包真值首次达标那一瞬的墙钟）
 *   · 未达标局用 `secAsBudget` 进 **E / P90_allTrials**（headline 口径）
 *   · `E_reachedOnly` / `median_reached` / `P90_reached` 只用达标局，作旁边对照
 * 百分位用**最近秩法**（nearest-rank）：P90 = 排序后第 `ceil(0.9n)` 个（n=3 时 = 最大值）。
 */
export function pearlTimeStats(rows, { goalSec = 180 } = {}) {
    // ⚠ **`reached` 的口径**：`sec == null` 就不算达标局 —— 「背包到目标了但没记到达标那一瞬」
    //   （例如 harvest 之后才结算）算"跑满窗口"，**不许**给它编一个达标用时。
    //   （自检 ⑪ 的反例就是钉这一条：sec=null 时 `reached` 必须是 0。）
    const isReached = (r) => r.reached === true && r.sec != null;
    const reached = rows.filter(isReached);
    const all = rows.map((r) => (isReached(r) ? r.sec : r.secAsBudget)).filter((v) => v != null);
    const mean = (a) => (a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(1) : null);
    const pct = (a, p) => {
        if (!a.length) return null;
        const s = a.slice().sort((x, y) => x - y);
        return +s[Math.max(0, Math.ceil((p / 100) * s.length) - 1)].toFixed(1);
    };
    const E = mean(all);
    return {
        target: rows[0]?.target ?? null, goalSec,
        runs: rows.length, reached: reached.length,
        E, E_reachedOnly: mean(reached.map((r) => r.sec)),
        median_reached: pct(reached.map((r) => r.sec), 50),
        P90_reached: pct(reached.map((r) => r.sec), 90),
        P90_allTrials: pct(all, 90),
        gate: reached.length >= 3 && E != null && E <= goalSec,
    };
}
export { RE_DATA, RE_FILLED, RE_NONE, RE_NOTLOADED, RE_GAMETIME, sleep };
