// test_route_loader.mjs — route_loader / station_nav 的离线单测（不开服、不占泳道）
//
// 补充单 §2 的验收项：
//   `route_loader` 单测 | 改 1 字节 → 拒绝加载；scout 字段不可见；精确中心被对齐到 8 格网格
//   禁区（补充单 §3）  | 任务层代码里禁止出现读取 route 文件 scout 字段的路径，也禁止硬编码坐标；
//                      单测要覆盖这一点
//
// 跑法：node bench/stages/portal/test_route_loader.mjs   （退出码 0 = 全过）

import { createRequire } from 'module';
import { pathToFileURL, fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import os from 'os';

const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(BENCH_DIR, '../../..');
const MINDCRAFT = process.env.MC_MINDCRAFT_ROOT || path.join(ROOT, 'mindcraft-wt', 's1-portal');
const require = createRequire(path.join(MINDCRAFT, 'main.js'));
const ROUTE_DIR = path.join(ROOT, 'bench', 'route');
// ⚠ 这里原本指向 `-8839485814800629942.draft.json`，**该文件已被 bench 提交 89c0305 删除**
//   （`git log --diff-filter=D -- route/-8839485814800629942.draft.json`），本单开工前
//   这个测试在第 55 行就 ENOENT 崩掉、一条用例也跑不到。同种子的 `<seed>.json` 仍在
//   仓库里且 `frozenAt=null`（按 SCHEMA 判定就是草稿），站级数据与下面各条断言完全吻合，
//   所以改指它；不新建文件（授权范围只有本测试与 route_loader.js）。
const DRAFT = path.join(ROUTE_DIR, '-8839485814800629942.json');

const L = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/route_loader.js')).href);
const N = await import(pathToFileURL(path.join(MINDCRAFT, 'src/agent/tasks/exec/station_nav.js')).href);
// 权威哈希口径（编排器侧，bench commit ce56269 统一过）：**动态 import**，不复制粘贴实现，
// 这样下面的用例是真的在跨仓库比对，而不是把同一份算法抄了两遍自己跟自己比。
const G = await import(pathToFileURL(path.join(BENCH_DIR, '..', 'fullrun', 'route_guard.mjs')).href);

let pass = 0, fail = 0;
const fails = [];
function t(name, fn) {
    try {
        fn();
        pass++;
        console.log(`  ✅ ${name}`);
    } catch (e) {
        fail++;
        fails.push({ name, err: String(e && e.message ? e.message : e) });
        console.log(`  ❌ ${name} —— ${e && e.message ? e.message : e}`);
    }
}
function eq(a, b, msg = '') {
    const sa = JSON.stringify(a), sb = JSON.stringify(b);
    if (sa !== sb) throw new Error(`${msg} 期望 ${sb}，实际 ${sa}`);
}
function ok(v, msg = '') { if (!v) throw new Error(msg || '断言失败'); }
function throwsCode(fn, code) {
    try {
        fn();
    } catch (e) {
        if (e?.code === code) return e;
        throw new Error(`期望 code=${code}，实际 code=${e?.code} msg=${e?.message}`);
    }
    throw new Error(`期望抛错 code=${code}，但没抛`);
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'p8-route-'));
const draftRaw = JSON.parse(fs.readFileSync(DRAFT, 'utf8'));

console.log('# route_loader / station_nav 离线单测\n');

// ---------- 1. 规范化与哈希 ----------
console.log('## 1. 规范化与哈希（SCHEMA §4 v1.1：对整文件算，含 frozenAt）');
t('改 frozenAt 一定改哈希（草稿态与冻结态是两份不同的文件）', () => {
    const a = { schema: 'aidqq-route/1', frozenAt: null, seed: '1', stations: [] };
    const b = { schema: 'aidqq-route/1', frozenAt: '2026-10-01T00:00:00Z', seed: '1', stations: [] };
    ok(L.computeCanonicalSha256(a) !== L.computeCanonicalSha256(b),
        'SCHEMA §4 v1.1 对整个文件算、含 frozenAt ⇒ 冻结动作改这一个字段就会改哈希');
});
t('改 sha256File 一定改哈希（它也在整文件里）', () => {
    const a = { schema: 'aidqq-route/1', frozenAt: null, sha256File: null, seed: '1', stations: [] };
    const b = { schema: 'aidqq-route/1', frozenAt: null, sha256File: '1.sha256', seed: '1', stations: [] };
    ok(L.computeCanonicalSha256(a) !== L.computeCanonicalSha256(b),
        'sha256File 是整文件的一部分 ⇒ 改它就该改哈希（不构成循环依赖：值只是旁挂文件名）');
});
t('键序会改变哈希（规范化只管缩进与末尾换行，不排序键）', () => {
    const a = { schema: 'aidqq-route/1', seed: '1', stations: [{ id: 'x', seq: 1 }] };
    const b = { stations: [{ seq: 1, id: 'x' }], seed: '1', schema: 'aidqq-route/1' };
    // 结论（按事实记录，不是 bug）：JSON.parse 保序、route_guard 的口径不排序键 ⇒ 键序会改哈希。
    // 因此**生成工具必须写出稳定键序**（同一条生成路径必然同序），换工具链就要重算冻结值。
    ok(L.computeCanonicalSha256(a) !== L.computeCanonicalSha256(b),
        '键序不同的两份文档，哈希应不同');
});
t('对象与等价原文喂进去结果相同（口径是"规范化 JSON 文本的哈希"）', () => {
    const doc = { schema: 'aidqq-route/1', seed: '1', stations: [{ id: 'x', seq: 1 }] };
    const text = JSON.stringify(doc, null, 2) + '\n';
    eq(L.computeCanonicalSha256(text), L.computeCanonicalSha256(doc), '对象 vs 2 空格缩进原文：');
    eq(L.computeCanonicalSha256(text), G.routeSha256(text), 'loader vs route_guard：');
});
t('内容变一个字节哈希就变', () => {
    const a = { schema: 'aidqq-route/1', seed: '1', stations: [{ id: 'x', radius: 24 }] };
    const b = { schema: 'aidqq-route/1', seed: '1', stations: [{ id: 'x', radius: 25 }] };
    ok(L.computeCanonicalSha256(a) !== L.computeCanonicalSha256(b), 'radius 24/25 的哈希不应相同');
});

// ---------- 1.4 跨仓库一致性（本单核心验收） ----------
console.log('\n## 1.4 跨仓库一致性：同一份 route 文件，loader 哈希必须 == route_guard 哈希');
// 真实主种子（只读；不往 bench/route 写任何东西）
const REAL = path.join(ROUTE_DIR, '4926685115947721762.json');
const realRaw = fs.readFileSync(REAL, 'utf8');
const lfText = realRaw.replace(/\r\n/g, '\n');
const crlfText = lfText.replace(/\n/g, '\r\n');
const lfFile = path.join(tmp, 'seed-lf.json');
const crlfFile = path.join(tmp, 'seed-crlf.json');
fs.writeFileSync(lfFile, lfText, 'utf8');
fs.writeFileSync(crlfFile, crlfText, 'utf8');

const guardSeed = G.readRouteFile(REAL).sha256;
const loaderSeed = L.computeCanonicalSha256(realRaw);
console.log(`     主种子 ${path.basename(REAL)}`);
console.log(`       route_guard.routeSha256 = ${guardSeed}`);
console.log(`       loader.computeCanonical = ${loaderSeed}`);

t('真实主种子本身 0 violations、且仍是草稿（我只读没动它）', () => {
    const r = G.readRouteFile(REAL);
    eq(r.violations, [], '主种子不该有 SCHEMA 违规：');
    eq(r.doc.frozenAt, null, '主种子应仍是草稿：');
});
t('LF 与 CRLF 两版：loader 哈希相同（换行风格无关 = 规范化口径的全部理由）', () => {
    ok(lfText !== crlfText && crlfText.includes('\r\n'), '两版内容必须真的不同，否则这条是空转');
    eq(L.computeCanonicalSha256(lfText), L.computeCanonicalSha256(crlfText), 'LF/CRLF 两版 loader 哈希应相同：');
});
t('LF 与 CRLF 两版：route_guard 哈希相同，且与 loader 逐字相同', () => {
    eq(G.routeSha256(crlfText), G.routeSha256(lfText), 'LF/CRLF 两版 route_guard 哈希应相同：');
    eq(L.computeCanonicalSha256(lfText), G.routeSha256(lfText), 'loader vs route_guard（LF）：');
    eq(L.computeCanonicalSha256(crlfText), G.routeSha256(crlfText), 'loader vs route_guard（CRLF）：');
});
t('loader 哈希 == route_guard 对该真实文件的 sha256（三份输入同一答案）', () => {
    eq(loaderSeed, guardSeed, 'loader(原文) vs route_guard(真实文件)：');
    eq(L.computeCanonicalSha256(lfText), guardSeed, 'loader(LF 临时文件) vs route_guard(真实文件)：');
    eq(L.computeCanonicalSha256(crlfText), guardSeed, 'loader(CRLF 临时文件) vs route_guard(真实文件)：');
});
t('运行期真路径 loadRoute().sha256 也等于 route_guard（LF/CRLF 都放行）', () => {
    const ev = [];
    const rLf = L.loadRoute(lfFile, { allowDraft: true, telemetry: (e) => ev.push(e) });
    const rCrlf = L.loadRoute(crlfFile, { allowDraft: true, telemetry: (e) => ev.push(e) });
    eq(rLf.sha256, guardSeed, 'loadRoute(LF 临时文件)：');
    eq(rCrlf.sha256, guardSeed, 'loadRoute(CRLF 临时文件)：');
    eq(rLf.stations.length, 10, '主种子 10 站应全部通过投影：');
    eq(ev.filter((e) => e === 'route_loaded').length, 2, '两次加载都该记 route_loaded');
});
t('改一个字段 ⇒ 两边哈希同时变化（两边不会一起静默漂移）', () => {
    const before = { loader: L.computeCanonicalSha256(lfText), guard: G.routeSha256(lfText) };
    eq(before.loader, before.guard, '基准态两边就应相同：');
    const doc = JSON.parse(lfText);
    doc.stations[0].station.radius += 1;                 // 32 → 33，只动一个字段
    const afterText = JSON.stringify(doc, null, 2) + '\n';
    const after = { loader: L.computeCanonicalSha256(afterText), guard: G.routeSha256(afterText) };
    ok(after.loader !== before.loader, 'loader 哈希必须变：');
    ok(after.guard !== before.guard, 'route_guard 哈希必须变：');
    eq(after.loader, after.guard, '改动后两边仍必须相同：');
    console.log(`     改 radius 32→33：loader ${after.loader.slice(0, 16)}… / route_guard ${after.guard.slice(0, 16)}…`);
});

// ---------- 2. 草稿加载 ----------
console.log('\n## 2. 草稿 route 加载与投影');
t('草稿 + allowDraft:true 能加载', () => {
    const r = L.loadRoute(DRAFT, { allowDraft: true });
    ok(r.draft === true, 'draft 标志');
    // 原断言写死 `站数应为 2` —— 那是已被 bench 提交 89c0305 删除的两站草稿的形状。
    // 改成与文件里实际站数**严格相等**：比写死数字更强（多一站/少一站/有站被拒都会红）。
    ok(r.stations.length > 0, '不该加载出 0 站');
    eq(r.stations.length, draftRaw.stations.length, `站数应与 ${path.basename(DRAFT)} 的站数一致（无站被拒）：`);
});
t('草稿在正式局（allowDraft 默认 false）被拒绝', () => {
    const events = [];
    throwsCode(() => L.loadRoute(DRAFT, { telemetry: (e) => events.push(e) }), 'route_is_draft');
    ok(events.includes('route_is_draft'), '应记 route_is_draft 遥测');
});
t('scout 字段在返回值里任何层级都不可见', () => {
    const r = L.loadRoute(DRAFT, { allowDraft: true });
    const seen = [];
    (function walk(o, p = '$') {
        if (!o || typeof o !== 'object') return;
        for (const k of Object.keys(o)) {
            if (k === 'scout') seen.push(`${p}.${k}`);
            walk(o[k], `${p}.${k}`);
        }
    })(r);
    eq(seen, [], '返回值里出现 scout：');
    eq(Object.keys(r.station('S1_portal')).sort(),
        ['center', 'dim', 'fallback', 'id', 'kind', 'lookFor', 'radius', 'seq', 'yHint'].sort(),
        '站级字段集合：');
});
t('assertNoScout 能抓住泄漏（防以后有人手滑 ...raw）', () => {
    throwsCode(() => L.assertNoScout({ stations: [{ id: 'a', scout: { points: [1, 2, 3] } }] }), 'scout_leaked');
});
t('主种子站 S1_portal 的站级数据正确且已对齐 8 格网格', () => {
    const s = L.loadRoute(DRAFT, { allowDraft: true }).station('S1_portal');
    eq(s.center, { x: 176, z: 352 });
    ok(s.center.x % 8 === 0 && s.center.z % 8 === 0, '中心必须落在 8 格网格上');
    eq(s.radius, 24);
    eq(s.lookFor.slice(), ['crying_obsidian', 'obsidian']);
    eq(s.fallback.slice(), ['S1b_lava_pool']);
    eq(s.dim, 'overworld');
    eq(s.yHint, 'surface');
});
t('精确中心被对齐到 8 格网格（181,357 → 184,360）', () => {
    const f = path.join(tmp, 'align.json');
    const raw = {
        schema: 'aidqq-route/1', seed: 'x', mcVersion: '1.16.1', frozenAt: null,
        stations: [{ id: 'A', seq: 1, kind: 'lava_pool', dim: 'overworld', station: { center: [181, 357], yHint: 'surface', radius: 24, lookFor: ['lava'] }, fallback: [] }],
    };
    fs.writeFileSync(f, JSON.stringify(raw, null, 2));
    const s = L.loadRoute(f, { allowDraft: true }).station('A');
    eq(s.center, { x: 184, z: 360 });
});
t('radius < 16 → 拒绝这一站（不 clamp、不掩盖写错）', () => {
    const f = path.join(tmp, 'small.json');
    fs.writeFileSync(f, JSON.stringify({
        schema: 'aidqq-route/1', seed: 'x', frozenAt: null,
        stations: [
            { id: 'small', seq: 1, kind: 'lava_pool', dim: 'overworld', station: { center: [0, 0], radius: 8, lookFor: ['lava'] } },
            { id: 'ok', seq: 2, kind: 'lava_pool', dim: 'overworld', station: { center: [8, 8], radius: 16, lookFor: ['lava'] } },
        ],
    }, null, 2));
    const ev = [];
    const r = L.loadRoute(f, { allowDraft: true, telemetry: (e, d) => ev.push([e, d]) });
    eq(r.stations.map((s) => s.id), ['ok'], 'radius=8 的站必须被拒，radius=16 的留下：');
    eq(r.rejected.map((x) => x.code), ['station_radius_too_small']);
    ok(ev.some(([e]) => e === 'route_station_rejected'), '应记 route_station_rejected');
    throwsCode(() => r.station('small'), 'station_radius_too_small');
});
t('scout 里写精确坐标也救不回来（投影只看 station）', () => {
    const f = path.join(tmp, 'leak.json');
    fs.writeFileSync(f, JSON.stringify({
        schema: 'aidqq-route/1', seed: 'x', frozenAt: null,
        stations: [{
            id: 'A', seq: 1, kind: 'ruined_portal', dim: 'overworld',
            station: { center: [176, 352], radius: 24, lookFor: ['obsidian'] },
            scout: { points: [{ what: 'frame_corner', xyz: [180, 64, 349] }] },
        }],
    }, null, 2));
    const r = L.loadRoute(f, { allowDraft: true });
    const s = r.station('A');
    eq(JSON.stringify(s).includes('frame_corner'), false, '精确坐标不该出现在站级数据里：');
    eq(JSON.stringify(s).includes('349'), false);
});

// ---------- 3. 冻结版与哈希闸门 ----------
console.log('\n## 3. 冻结版与哈希闸门');
function writeFrozen(dir, mutate) {
    const raw = JSON.parse(fs.readFileSync(DRAFT, 'utf8'));
    raw.frozenAt = '2026-10-01T00:00:00Z';
    if (mutate) mutate(raw);
    const file = path.join(dir, `${raw.seed}.json`);
    fs.writeFileSync(file, JSON.stringify(raw, null, 2));
    const hex = L.computeCanonicalSha256(raw);
    fs.writeFileSync(path.join(dir, `${raw.seed}.sha256`), `${hex}\n`);
    return { file, hex };
}
t('冻结版哈希对得上就能加载，并记 route_loaded 遥测（含 sha256）', () => {
    const d = path.join(tmp, 'frozen1'); fs.mkdirSync(d, { recursive: true });
    const { file, hex } = writeFrozen(d);
    const ev = [];
    const r = L.loadRoute(file, { telemetry: (e, data) => ev.push([e, data]) });
    ok(r.frozen === true, 'frozen 标志');
    eq(r.sha256, hex);
    const loaded = ev.find(([e]) => e === 'route_loaded');
    ok(loaded && loaded[1].sha256 === hex, '遥测里必须带 route 的 sha256（SCHEMA §3）');
});
t('改 1 字节 → 拒绝加载（route_hash_mismatch）', () => {
    const d = path.join(tmp, 'frozen2'); fs.mkdirSync(d, { recursive: true });
    const { file } = writeFrozen(d);
    // 只改一个字节：radius 24 → 25（文件里其它内容与 sha 文件都不动）
    const txt = fs.readFileSync(file, 'utf8').replace('"radius": 24', '"radius": 25');
    fs.writeFileSync(file, txt);
    const ev = [];
    throwsCode(() => L.loadRoute(file, { telemetry: (e) => ev.push(e) }), 'route_hash_mismatch');
    ok(ev.includes('route_hash_mismatch'), '必须记 route_hash_mismatch');
});
t('冻结版缺 .sha256 文件 → 拒绝加载（route_hash_missing）', () => {
    const d = path.join(tmp, 'frozen3'); fs.mkdirSync(d, { recursive: true });
    const { file } = writeFrozen(d);
    fs.rmSync(path.join(d, '-8839485814800629942.sha256'));
    throwsCode(() => L.loadRoute(file), 'route_hash_missing');
});
t('草稿不需要 .sha256（开发局不冻结）', () => {
    const r = L.loadRoute(DRAFT, { allowDraft: true });
    ok(r.draft && !fs.existsSync(path.join(ROUTE_DIR, '-8839485814800629942.sha256')),
        '草稿没有冻结哈希文件也能加载');
});

// ---------- 4. 到达确认闸门的纯逻辑 ----------
console.log('\n## 4. 到达确认闸门（纯逻辑部分）');
t('planTurns：方向不重复、步长小（真人换方向的样子）', () => {
    const turns = N.planTurns(6);
    eq(turns.length, 6);
    eq(new Set(turns.map((x) => x.yawDeg)).size, 6, '6 次转身的朝向不该重复');
    for (const x of turns) {
        ok(Math.hypot(x.step[0], x.step[1]) <= 6, `步长过大 ${JSON.stringify(x.step)}`);
        ok(Math.abs(x.pitchDeg) <= 18, '俯仰不该太夸张');
    }
});
t('STATION_NOT_CONFIRMED 是导出常量（编排器按它判失败）', () => {
    eq(N.STATION_NOT_CONFIRMED, 'STATION_NOT_CONFIRMED');
});

// ---------- 5. 禁区守卫（补充单 §3） ----------
console.log('\n## 5. 禁区守卫：任务层不许读 scout、不许硬编码坐标');
const EXEC_DIR = path.join(MINDCRAFT, 'src', 'agent', 'tasks', 'exec');
const TASK_FILES = fs.readdirSync(EXEC_DIR).filter((f) => f.endsWith('.js'));

t('只有 route_loader.js 允许出现 scout 这个键名', () => {
    const bad = [];
    for (const f of TASK_FILES) {
        if (f === 'route_loader.js') continue;
        const src = fs.readFileSync(path.join(EXEC_DIR, f), 'utf8');
        // 只看代码形态的引用（.scout / ['scout'] / "scout":），注释里的中文说明不算
        const hits = src.match(/\.scout\b|\[\s*['"]scout['"]\s*\]|['"]scout['"]\s*:/g);
        if (hits) bad.push(`${f}: ${hits.join(',')}`);
    }
    eq(bad, [], '这些文件在代码里引用了 scout：');
});
t('只有 route_loader.js 允许读 route 文件（fs 读 + 路径字面量）', () => {
    const bad = [];
    for (const f of TASK_FILES) {
        if (f === 'route_loader.js') continue;
        const src = fs.readFileSync(path.join(EXEC_DIR, f), 'utf8');
        if (/readFileSync|readFile\s*\(|JSON\.parse\s*\(\s*fs/.test(src) && /route/i.test(src)) bad.push(f);
        if (/['"`][^'"`]*route\/[^'"`]*\.json['"`]/.test(src)) bad.push(`${f}(路径字面量)`);
    }
    eq(bad, [], '这些文件疑似自己读 route：');
});
t('站级模块里没有硬编码世界坐标', () => {
    const bad = [];
    for (const f of TASK_FILES) {
        if (f !== 'route_loader.js' && f !== 'station_nav.js') continue;
        const src = fs.readFileSync(path.join(EXEC_DIR, f), 'utf8')
            .replace(/\/\*[\s\S]*?\*\//g, '')      // 去块注释
            .replace(/^\s*\/\/.*$/gm, '');        // 去行注释
        for (const m of src.matchAll(/\[\s*(-?\d+)\s*,\s*(-?\d+)\s*(?:,\s*(-?\d+)\s*)?\]/g)) {
            const nums = [m[1], m[2], m[3]].filter((x) => x !== undefined).map(Number);
            if (nums.some((v) => Math.abs(v) >= 64)) bad.push(`${f}: ${m[0]}`);
        }
    }
    eq(bad, [], '站级模块里出现疑似世界坐标的字面量：');
});
t('真实的草稿 route 站级数据不含精确 y（yHint 只是提示）', () => {
    const r = L.loadRoute(DRAFT, { allowDraft: true });
    for (const s of r.stations) {
        eq(Object.keys(s).includes('y'), false, `${s.id} 不该有精确 y`);
        ok(['surface', 'underground', 'nether_mid', 'any'].includes(s.yHint), `yHint 越界：${s.yHint}`);
    }
});

// ---------- 汇总 ----------
try { fs.rmSync(tmp, { recursive: true, force: true }); } catch { /* 忽略 */ }
console.log(`\n## 结果：${pass} 通过 / ${fail} 失败`);
if (fail) {
    console.log('失败项：');
    for (const f of fails) console.log(`  - ${f.name}: ${f.err}`);
}
process.exit(fail ? 1 : 0);
