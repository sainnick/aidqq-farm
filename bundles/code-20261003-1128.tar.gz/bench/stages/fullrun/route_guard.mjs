// route_guard.mjs — MC-ROUTE-02：编排器侧的 route 守卫
//
// 本单**不实现**任务层的 `route_loader`（那是开发线 B 的活，SCHEMA §1 的三条校验都在那边：
// sha 校验、丢弃 scout、8 格粗化 + radius≥16 兜底）。本文件只做编排器该做的四件事，
// 全部是"编排器自己的账"，不碰任务层：
//
//   1. **文件选择 + 结构校验**：读 route 文件，校验 schema / 站序 / 站区字段。
//   2. **sha256 记录与复验**：开跑记一次；**每个段开始前**与整局结束时各复验一次。
//      任何一次对不上 → 整局判 `VOID`（SCHEMA §3：run 中 route 文件被修改 = 该局作废）。
//   3. **草稿闸门**：`frozenAt === null` 是草稿，SCHEMA 规定只能用于开发局；
//      正式矩阵/拍摄局必须显式 `--allow-draft` 才放行，默认拒。
//   4. **黑名单跨段台账**（任务单 §3 定的语义：预算按段重置、黑名单跨段保留）：
//      预算按段重置是任务层**现有**行为（FULLRUN-01 已实证：每次 TaskRuntime.run() 新建
//      TaskStack，budgets/blacklist/deathEpoch 都不跨段）。
//      「黑名单跨段保留」当前**没有注入通道**——黑名单是 ctx.run.blacklist，任务层未开放外部
//      runState 注入。所以本单把每段实测到的失败目标收集成**跨段台账**（从遥测
//      `nav_blacklist_expand{target,why,radius,expanded}` 解析），随 splits.json 落盘，
//      供设计会话排期任务层钩子时直接用。台账只读不改，不影响本局行为。

import fs from 'fs';
import crypto from 'crypto';
import path from 'path';

const STATION_ID_RE = /^[A-Za-z0-9_]{1,64}$/;
/** MISSION 形态白名单：只允许 `do station <id>`，从形态上杜绝坐标混进 MISSION */
const MISSION_RE = /^do station ([A-Za-z0-9_]{1,64})$/;

export class RouteError extends Error {
    constructor(code, msg) { super(`${code}: ${msg}`); this.code = code; }
}

export function sha256Of(text) {
    return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
}

// ---------------------------------------------------------------------------
// 【SCHEMA §4 v1.1 的**唯一**哈希口径】设计会话 2026-10-02 夜定案（bench 74b1b5d / 73f7456）
//
//   sha256( JSON.stringify(JSON.parse(文件原文), null, 2) + "\n" )
//
// 对**整个文件**算，**包括 frozenAt 和 sha256File**。哈希值存在**旁挂** `.sha256` 文件里、
// 不在 route 文件内部 ⇒ 没有循环依赖（`sha256File` 字段名在文件里是常量，它的**值**只是文件名，
// 不参与自身哈希的求解）。
//
// **为什么用规范化而不是原始字节**：原始字节哈希对换行符敏感 —— 本地 Windows 的 git 会把
// LF 转成 CRLF，而云端泳道 X / 农场 Y 是 LF ⇒ 同一个冻结文件在本地算出的哈希到了云端就对不上，
// 而且**本地自检全绿也不会报错**。规范化把换行/缩进/字段序差异全部消掉，跨机器可复现。
//
// ⚠ **三处必须共用这一个函数**（SCHEMA §4 明写）：冻结工具、checkRouteIntegrity 的冻结校验、
//   RouteGuard 开跑/段间复验。以前这三处各算各的（freeze_route.mjs 还有 --schema-literal
//   双口径），是"按 SCHEMA 文字冻结、guard 必然报 ROUTE_HASH_MISMATCH"那个🚨冲突的根因。
//   离线用例见 bench/route/tools/route_hash_selftest.mjs。
// ---------------------------------------------------------------------------

/** 规范化文本：2 空格缩进 + 末尾换行。接受**对象**或**文件原文字符串**。 */
export function canonicalRouteText(input) {
    const doc = typeof input === 'string' ? JSON.parse(input) : input;
    return JSON.stringify(doc, null, 2) + '\n';
}

/** route 文件的规范哈希（SCHEMA §4 v1.1）。`input` 可以是原文，也可以是已 parse 的对象。 */
export function routeSha256(input) {
    return sha256Of(canonicalRouteText(input));
}

/** 读 + 结构校验（不校验 hash：那是冻结态的事） */
export function readRouteFile(file) {
    if (!fs.existsSync(file)) throw new RouteError('ROUTE_FILE_MISSING', file);
    const raw = fs.readFileSync(file, 'utf8');
    let doc;
    try { doc = JSON.parse(raw); } catch (e) { throw new RouteError('ROUTE_BAD_JSON', `${file}: ${String(e).slice(0, 120)}`); }
    const v = [];
    if (doc.schema !== 'aidqq-route/1') v.push(`schema=${doc.schema}（期望 aidqq-route/1）`);
    if (!Array.isArray(doc.stations) || !doc.stations.length) v.push('stations 为空');
    for (const s of doc.stations ?? []) {
        if (!STATION_ID_RE.test(s.id ?? '')) v.push(`站 id 非法：${s.id}`);
        if (!Number.isInteger(s.seq)) v.push(`${s.id} seq 非整数`);
        if (!s.station || !Array.isArray(s.station.center) || s.station.center.length !== 2) v.push(`${s.id} station.center 非法`);
        else if (!s.station.center.every(Number.isInteger) || s.station.center.some((c) => c % 8 !== 0)) {
            // SCHEMA §1 说加载器会把 center 对齐到 8 格作兜底；这里**再加一道**：文件本身就必须
            // 已经是粗粒度的。否则有人把精确坐标写进 station，加载器虽会兜底，但"误写"已经发生。
            v.push(`${s.id} center=${JSON.stringify(s.station.center)} 未对齐 8 格网格（站级数据必须是粗粒度）`);
        }
        if (!Number.isInteger(s.station?.radius) || s.station.radius < 16) v.push(`${s.id} radius=${s.station?.radius} < 16（SCHEMA 硬下限）`);
        if (!Array.isArray(s.station?.lookFor) || !s.station.lookFor.length) v.push(`${s.id} lookFor 为空（运行时无法做到达确认）`);
    }
    const seqs = (doc.stations ?? []).map((s) => s.seq);
    if (seqs.length && (Math.min(...seqs) !== 1 || seqs.length !== new Set(seqs).size)) v.push('seq 必须是从 1 起的不重复整数');

    // ---- v1.1（SCHEMA §2.1，2026-10-02 夜设计会话要求补）：fallback 三处一致性 ----
    // `routeRole=fallback-only`、各主站 `fallback`、顶层 `fallbackOnlyStations` 三处必须一致。
    // ⚠ **条件触发**：另两个旧种子（-8839485814800629942 / -6850455172235562789）没有这些字段，
    //   对它们报 violation 会让旧 route 一律不可用 ⇒ 只有"文件里出现过任一新字段"才校验。
    {
        const stations = doc.stations ?? [];
        const hasRole = stations.some((s) => s.routeRole);
        const hasLists = Array.isArray(doc.normalFlowStations) || Array.isArray(doc.fallbackOnlyStations);
        if (hasRole || hasLists) {
            const byId = new Map(stations.map((s) => [s.id, s]));
            const roleFallback = stations.filter((s) => s.routeRole === 'fallback-only').map((s) => s.id);
            const badRole = stations.filter((s) => s.routeRole !== undefined && s.routeRole !== 'fallback-only').map((s) => `${s.id}=${s.routeRole}`);
            if (badRole.length) v.push(`routeRole 只允许 "fallback-only"，否则视为普通站：${badRole.join(', ')}`);

            // (a) 每个 fallback-only 站必须被 ≥1 个站引用，且引用者自己不是 fallback-only（否则会链式套娃）
            for (const id of roleFallback) {
                const refs = stations.filter((s) => Array.isArray(s.fallback) && s.fallback.includes(id)).map((s) => s.id);
                if (!refs.length) v.push(`${id} 标了 fallback-only 却没有任何站的 fallback 指向它`);
                const chain = refs.filter((r) => roleFallback.includes(r));
                if (chain.length) v.push(`${id} 被 fallback-only 站 ${chain.join(',')} 引用（会形成 fallback 链，SCHEMA §2.1 不允许）`);
            }
            // (b) 任何 fallback 指向的目标必须存在、且必须标了 fallback-only
            for (const s of stations) {
                for (const f of s.fallback ?? []) {
                    if (!byId.has(f)) v.push(`${s.id}.fallback 指向不存在的站 ${f}`);
                    else if (byId.get(f).routeRole !== 'fallback-only') v.push(`${s.id}.fallback 指向 ${f}，但它没有标 routeRole="fallback-only"（正常流程会顺路去它，与语义矛盾）`);
                }
            }
            // (c) 顶层两表 vs routeRole 三处一致
            if (Array.isArray(doc.fallbackOnlyStations)) {
                const listed = doc.fallbackOnlyStations.map((x) => x.id);
                const dup = listed.filter((x, i) => listed.indexOf(x) !== i);
                if (dup.length) v.push(`fallbackOnlyStations 有重复 id：${[...new Set(dup)].join(',')}`);
                for (const id of listed) if (!roleFallback.includes(id)) v.push(`fallbackOnlyStations 里的 ${id} 没有 routeRole="fallback-only"`);
                for (const id of roleFallback) if (!listed.includes(id)) v.push(`${id} 有 routeRole="fallback-only" 但没登记进 fallbackOnlyStations`);
                for (const rec of doc.fallbackOnlyStations) {
                    const st = byId.get(rec.id);
                    const actual = stations.filter((s) => Array.isArray(s.fallback) && s.fallback.includes(rec.id)).map((s) => s.id).sort();
                    const claimed = [...(rec.fallbackOf ?? [])].sort();
                    if (JSON.stringify(actual) !== JSON.stringify(claimed)) {
                        v.push(`${rec.id} 的 fallbackOf 记录与实际引用不一致：记录 ${JSON.stringify(rec.fallbackOf)} 实际 ${JSON.stringify(actual)}`);
                    }
                    if (st && Number.isInteger(st.seq) && rec.seq !== st.seq) v.push(`${rec.id} 的 fallbackOnlyStations.seq=${rec.seq} 与 stations.seq=${st.seq} 不一致`);
                }
            } else {
                v.push('有站标了 routeRole="fallback-only"，但顶层缺 fallbackOnlyStations');
            }
            if (Array.isArray(doc.normalFlowStations)) {
                for (const id of doc.normalFlowStations) {
                    if (!byId.has(id)) v.push(`normalFlowStations 里的 ${id} 不存在`);
                    else if (byId.get(id).routeRole === 'fallback-only') v.push(`normalFlowStations 里出现了 fallback-only 站 ${id}（正常流程不应去它）`);
                }
                const overlap = doc.normalFlowStations.filter((id) => roleFallback.includes(id));
                if (overlap.length) v.push(`normalFlowStations 与 fallback-only 站重叠：${[...new Set(overlap)].join(',')}`);
            } else {
                v.push('顶层缺 normalFlowStations');
            }
            // (d) 两表并集 = 全部站，且不重不漏
            const nf = doc.normalFlowStations ?? [];
            const fo = (doc.fallbackOnlyStations ?? []).map((x) => x.id);
            if (nf.length + fo.length !== stations.length) {
                v.push(`normalFlowStations(${nf.length}) + fallbackOnlyStations(${fo.length}) != stations.length(${stations.length})`);
            }
            const union = new Set([...nf, ...fo]);
            const missing = stations.filter((s) => !union.has(s.id)).map((s) => s.id);
            if (missing.length) v.push(`这些站既不在 normalFlowStations 也不在 fallbackOnlyStations：${missing.join(',')}`);
            const normalSet = new Set(nf);
            for (const id of fo) if (normalSet.has(id)) v.push(`${id} 同时出现在 normalFlowStations 和 fallbackOnlyStations`);
            // 正常流程的 seq 应当就是 1..N 连续（编排器按 seq 走）
            const normalSeqs = nf.map((id) => byId.get(id)?.seq).filter(Number.isInteger).sort((a, b) => a - b);
            for (let i = 0; i < normalSeqs.length; i++) {
                if (normalSeqs[i] !== i + 1) { v.push(`正常流程站的 seq 应为 1..${normalSeqs.length} 连续，实得 ${JSON.stringify(normalSeqs)}`); break; }
            }
        }
    }
    // `sha256` 走 SCHEMA §4 v1.1 的**规范化**口径（见 routeSha256）。
    // ⚠ 这里同时保留 `rawSha256`（原始字节哈希）**只作诊断**：它和 sha256 不相等只说明
    //   文件被换行风格改写过（CRLF/LF），不代表内容变了 —— 别拿它判"route 被改"。
    return { file, raw, sha256: routeSha256(doc), rawSha256: sha256Of(raw), doc, violations: v };
}

/** 开局闸门：草稿 / 冻结态 / sha 一致性 */
export function checkRouteIntegrity(file, { allowDraft = false, requireFrozen = false } = {}) {
    const r = readRouteFile(file);
    const out = { file, sha256: r.sha256, rawSha256: r.rawSha256, frozenAt: r.doc.frozenAt ?? null, frozen: !!r.doc.frozenAt, sha256File: r.doc.sha256File ?? null, violations: [...r.violations], ok: true, reason: null };

    if (out.violations.length) { out.ok = false; out.reason = `SCHEMA_VIOLATIONS: ${out.violations.join(' | ')}`; return out; }

    if (!out.frozen) {
        if (requireFrozen || !allowDraft) {
            out.ok = false;
            out.reason = `ROUTE_IS_DRAFT: frozenAt=null（草稿只能用于开发局；正式矩阵/拍摄局必须用冻结版）。`
                + `开发局请显式 --allow-draft`;
            return out;
        }
    } else {
        // 冻结态：与 <seed>.sha256 旁挂文件比对
        const side = r.doc.sha256File ? path.join(path.dirname(file), r.doc.sha256File) : null;
        if (side && fs.existsSync(side)) {
            const frozen = fs.readFileSync(side, 'utf8').trim().split(/\s+/)[0];
            if (frozen !== r.sha256) {
                out.ok = false;
                out.reason = `ROUTE_HASH_MISMATCH: 文件 sha=${r.sha256.slice(0, 16)}… 冻结值 sha=${String(frozen).slice(0, 16)}…`;
                return out;
            }
        } else if (requireFrozen) {
            out.ok = false;
            out.reason = `ROUTE_SIDECAR_MISSING: 冻结态必须有 ${r.doc.sha256File ?? '<seed>.sha256'}`;
            return out;
        }
    }
    return out;
}

export class RouteGuard {
    /**
     * @param {string} file route 文件路径
     * @param {{allowDraft?:boolean, requireFrozen?:boolean, onViolation?:(r:object)=>void}} opt
     */
    constructor(file, opt = {}) {
        this.file = file;
        this.opt = opt;
        this.started = checkRouteIntegrity(file, opt);
        this.voided = !this.started.ok;
        this.voidReason = this.started.reason;
        this.ledger = [];          // 跨段黑名单台账（只读观测，不注入任务层）
        this.checks = [{ at: 'start', ...this.started }];
    }
    get sha256() { return this.started.sha256; }
    get stations() { return (this.started.violations.length ? [] : this.started.doc.stations) ?? []; }

    /** 段开始前复验：文件被改过 → 整局作废 */
    verify(where) {
        let now;
        try { now = checkRouteIntegrity(this.file, this.opt); }
        catch (e) { now = { ok: false, reason: `ROUTE_READ_FAIL: ${e.message}`, sha256: null, violations: [] }; }
        const changed = !this.voided && now.sha256 !== this.started.sha256;
        const rec = {
            at: where, sha256: now.sha256, same: now.sha256 === this.started.sha256,
            ok: now.ok && !changed, changed,
            reason: changed ? `ROUTE_CHANGED_MID_RUN: 开局 sha=${String(this.started.sha256).slice(0, 16)}… 现在 sha=${String(now.sha256).slice(0, 16)}… → 该局作废` : now.reason,
        };
        this.checks.push(rec);
        if (!rec.ok) { this.voided = true; this.voidReason = rec.reason; }
        return rec;
    }

    /**
     * 吸收一段的遥测，提取实测失败目标 → 跨段黑名单台账。
     * 事件形如 nav_blacklist_expand{why,target:"x y z",radius,expanded}
     */
    absorbSegmentTelemetry(telemetryPath, { dim = 'overworld' } = {}) {
        if (!fs.existsSync(telemetryPath)) return { added: 0, ledger: this.ledger };
        let added = 0;
        for (const line of fs.readFileSync(telemetryPath, 'utf8').split('\n')) {
            if (!line.trim()) continue;
            let e; try { e = JSON.parse(line); } catch { continue; }
            if (e.event !== 'nav_blacklist_expand' || !e.target) continue;
            const [x, y, z] = String(e.target).split(/\s+/).map(Number);
            if (![x, y, z].every(Number.isFinite)) continue;
            const key = `${x},${y},${z}`;
            if (this.ledger.some((r) => r.key === key)) continue;
            this.ledger.push({ key, x, y, z, dim, why: e.why ?? null, radius: e.radius ?? null, expanded: e.expanded ?? null, at: e.t ?? null });
            added++;
        }
        return { added, ledger: this.ledger };
    }

    /**
     * 测试专用：模拟「外部在 run 中改了 route 文件」。
     * 改一个字节（把某站的 radius 从 32 改成 33，仍是合法 JSON），用来在真实 bot 路径上
     * 触发 verify() 的作废判定——干跑时每段耗时 ~0ms，人手改文件根本抢不到窗口，
     * 所以把"被改"这一步自动化；判定逻辑与外部修改完全同一条路径（重新读文件 + 比 sha）。
     * 离线等价验证见 route_selftest.mjs 第 3 组（那里是真·外部改文件）。
     */
    simulateExternalEdit() {
        try {
            const doc = JSON.parse(fs.readFileSync(this.file, 'utf8'));
            const st = doc.stations?.[0];
            if (!st) return null;
            const before = st.station.radius;
            st.station.radius = before + 1; // 只动一个字符
            fs.writeFileSync(this.file, JSON.stringify(doc, null, 2) + '\n');
            return { field: 'stations[0].station.radius', before, after: st.station.radius };
        } catch (e) {
            return { error: String(e).slice(0, 120) };
        }
    }

    report() {
        return {
            file: this.file,
            sha256AtStart: this.started.sha256,
            frozen: this.started.frozen,
            frozenAt: this.started.frozenAt,
            voided: this.voided,
            voidReason: this.voidReason,
            checks: this.checks,
            blacklistLedgerSize: this.ledger.length,
            blacklistLedger: this.ledger,
            blacklistPolicy: '预算按段重置（任务层现有行为，已实证）；黑名单跨段保留 = 台账已建，注入通道待任务层钩子（本单不改任务层）',
        };
    }
}

/** MISSION 形态自检：站 id 序列里**不允许出现任何坐标**（手册 §7 / SCHEMA §3） */
export function assertStationOnlyMissions(missions) {
    for (const m of missions) {
        const hit = MISSION_RE.exec(m.raw);
        if (!hit) throw new RouteError('MISSION_NOT_STATION_FORM', `序列项不是 "do station <id>"：${m.raw}`);
        if (/\d/.test(hit[1]) && !/^S\d/.test(hit[1])) throw new RouteError('STATION_ID_HAS_DIGITS', `站 id 含数字且不像 S 编号：${hit[1]}`);
    }
    return true;
}
