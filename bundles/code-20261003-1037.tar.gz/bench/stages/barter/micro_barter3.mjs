// micro_barter3.mjs — MC-S2-03（开发线 F）：三模式同口径对比 + 猪灵密度时间分布 + 0→12 珍珠验收
//
// 派单（S2-03）四条：
//   1. **每轮给失效投锭位补人**；**bot 死亡即中止本局**（以 server.log 死亡消息为准）；
//      实测开放场新中心 [336,256] **站位 3 格内同时有几头猪灵的时间分布**。
//   2. **三种模式开放场同口径对比**（N=4，每种 ≥10 分钟）：
//      `wait` = 等猪灵过来 ／ `ground` = 地面投锭（`bot.toss`）／`approach` = 主动走近。
//   3. **围栏组**：fill 回执**全非 0** 才开测；围栏数字**只算引擎上限**。
//   4. B5 用新中心 [336,256] 跑一次（在 probe_b5_chest_gold.mjs 里，本文件不重复）。
//
// 口径纪律（每条都是上一轮的教训）：
//   · **同口径**：三格跑在**同一站位格**、同一 N、同一 kit、同一窗口长度、同一 TP 顺序；
//     唯一的变量是 `mode`。跑完一格先 `clear` + 杀掉落物 + `replenish()`，不许继承上一格的状态。
//   · **死亡即中止**：`makeDeathGuard()` 有两条互相独立的通道（server.log 死亡消息 / 客户端维度
//     不在下界），任一命中立刻停，且 `report.reason` 如实带 `death:*`。
//   · **没原料单独记账**（`ingotStarvedMs`）：猪灵把玩完**不还锭**，所以"投得少"有两种原因
//     （打不动 / 没原料），混在一起就没法归因。
//   · **围栏硬闸**：`buildPen()` 的 `ok=false` ⇒ 不开测（上一轮的 `glassCells=[0,0,1,1]` 是
//     FIFO 错位 + 破坏性复核造出来的假数，本轮已修）。
//
// 用法：
//   node micro_barter3.mjs --stamp S2_M3 --density-min 10 --window-min 10 --pearl-runs 3
//   node micro_barter3.mjs --stamp S2_M3P --only pearls            # 只补珍珠验收
//   node micro_barter3.mjs --stamp S2_M3D --only density          # 只测密度

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
    openRun, bootWorld, closeRun, cmd, truth, bot, botPos, posStr, dim,
    invCount, record, writeSummary, sleep, recallTo, buildPen, watchDeaths, makeDeathGuard,
    parkSafe, standNatural, makeStandGuard, footingOk,
    diskFreeGB, STATION, LANE, SEED, argv, moduleUrl,
} from './harness.mjs';

const STAMP = argv('stamp', 'S2_M3');
const ONLY = String(argv('only', 'density,modes,pen,pearls')).split(',').map((s) => s.trim()).filter(Boolean);
const WANT = (k) => ONLY.includes(k);
const DENSITY_MS = Math.round(parseFloat(argv('density-min', '10')) * 60000);
const WINDOW_MS = Math.round(parseFloat(argv('window-min', '10')) * 60000);
const PEARL_TARGET = parseInt(argv('pearls', '12'), 10);
const PEARL_RUNS = parseInt(argv('pearl-runs', '3'), 10);
const PEARL_MS = Math.round(parseFloat(argv('pearl-min', '15')) * 60000);
const MODES = String(argv('modes', 'wait,ground,approach')).split(',').map((s) => s.trim()).filter(Boolean);
const N = parseInt(argv('n', '4'), 10);
const INGOTS = parseInt(argv('ingots', '128'), 10);
/**
 * 难度（**默认 peaceful**，S2-03 的选型理由，必须写进报告）：
 *   · easy 下 **bot 在 29 秒内被猪灵连杀 5 次**（server.log `was slain by Piglin` ×5，stamp S2_M3X）
 *     —— 1.16.1 猪灵的攻击目标链里有 `NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD`，
 *     所以脱战相没做、bot 又只有 2 件金装时，站在猪群里就是活靶。
 *     那样测到的是**战斗**，不是易物，三种模式的对比会被"谁先被打死"这个无关变量污染。
 *   · peaceful 下 `EntitySelector.ATTACK_ALLOWED` 恒 false（源码）⇒ **不可能被杀**，
 *     而 S2-01 已实测 **peaceful 下堡垒站仍有 28 头猪灵**（生成不受 peaceful 抑制）。
 *   · ⚠ **诚实标注**：peaceful 下测到的是"**易物机制本身**的上限"，
 *     真实 S2 链路上易物段必须在**脱战相之后**做（stage-02 §R2.2 早就这么写了）。
 *     本单另外单独报了 easy 下的死亡事实（5 次/29s），那是 S2 的设计约束，不是本单能修的。
 */
const DIFFICULTY = argv('difficulty', 'peaceful');
const S = STATION.bastion;
const BENCH_DIR = path.dirname(fileURLToPath(import.meta.url));
/** ★ 钉住作业位（`--work 320,68,241`）：两次 `standNatural` 可能因为猪灵游走而落在**不同格**，
 *  那样"密度段"和"三模式段"就不是同一站位、对比无效。分两次跑时必须钉。 */
const WORK_PIN = (() => {
    const s = argv('work', null);
    if (!s) return null;
    const p = String(s).split(',').map((x) => parseFloat(x));
    return p.length === 3 && p.every(Number.isFinite) ? { x: p[0], y: p[1], z: p[2] } : null;
})();

let pig = null;
const readJson = (...parts) => { try { return JSON.parse(fs.readFileSync(path.join(BENCH_DIR, ...parts), 'utf8')); } catch { return null; } };

// ───────────────────────────────────────────────────── 猪灵密度（3 格内同时几头）
/**
 * 站位格周围的猪灵数时间分布。**这正是 techniques-1161 §2.1 那条"喂 4 头"打法的未验证前提**。
 * 同时记三档半径：2.0 / 3.0 / 3.4（3.4 = 喂锭交互的服务端实际上限，2.8–3.4 是唯一可观测掉落的窗口）。
 * 每 `everyMs` 采一次；每 30s 用**服务端真值**数一次全图猪灵（客户端实体表会保留已离开追踪范围的实体）。
 *
 * 🚨 **每行都带 `ok` 标记**（S2-03 踩到：首轮 10 分钟里有 ~80% 的样本猪灵数是 0，
 *   根因是 bot 从那条窄台**掉下去了**——掉落/死亡会让下界区块卸载 ⇒ 猪灵数与服务端计数**双双归零**，
 *   而"归零"会被读成"这一带没有猪灵"。**不区分有效样本与失效样本，就会得出"3 格内 0 头"的假结论。**）
 * ⇒ `ok = 维度在下界 && 水平漂移 ≤ r && 下坠 ≤ dy`；死亡则整段中止并如实记 reason。
 */
async function sampleDensity({ ms, everyMs = 1000, at = null, radii = [2.0, 3.0, 3.4], serverEveryMs = 30000, work = null } = {}) {
    const rows = [];
    const srv = [];
    const t0 = Date.now();
    let lastSrv = 0;
    const me = at ?? botPos();
    const w = work ? watchDeaths() : null;
    const sg = work ? makeStandGuard(work, { r: 2.5, dy: 3.0 }) : null;
    const dg = w ? makeDeathGuard(w) : null;
    let reason = 'window';
    while (Date.now() - t0 < ms) {
        const now = Date.now();
        const live = botPos();
        const d = String(dim());
        const stop = (dg?.() ?? null) ?? (sg?.guard() ?? null);
        if (stop) { reason = stop; break; }
        const list = Object.values(bot()?.entities ?? {}).filter((e) => e && e.name === 'piglin' && e.position);
        const r = { at: now - t0, wall: now };
        for (const rad of radii) r[`n${String(rad).replace('.', '_')}`] = list.filter((e) => e.position.distanceTo(me) <= rad).length;
        r.total24 = list.length;
        const ds = list.map((e) => e.position.distanceTo(me)).sort((a, b) => a - b);
        r.nearest = ds.length ? +ds[0].toFixed(2) : null;
        r.within6 = ds.filter((dd) => dd <= 6).length;
        r.within12 = ds.filter((dd) => dd <= 12).length;
        r.holding = list.filter((e) => pig.isHolding(e) === true).length;
        r.hpBelow = list.filter((e) => { const h = pig.piglinHealth(e); return h != null && h < pig.PIGLIN_MAX_HP * 0.999; }).length;
        r.botPos = live ? posStr(live) : null;
        r.dim = d;
        r.drift = live ? +Math.hypot(live.x - me.x, live.z - me.z).toFixed(2) : null;
        r.drop = live ? +(me.y - live.y).toFixed(2) : null;
        r.ok = !!live && /nether/i.test(d) && r.drift <= 2.5 && r.drop <= 3.0;
        rows.push(r);
        if (now - lastSrv >= serverEveryMs) {
            lastSrv = now;
            try {
                const c = await truth().countEntities('the_nether', LANE.username, '@e[type=piglin]', { quietMs: 800, minWaitMs: 6000, timeoutMs: 25000 });
                srv.push({ at: now - t0, serverPiglins: c.n, trusted: c.trusted, clientTotal: list.length, botOk: r.ok });
            } catch (e) { srv.push({ at: now - t0, error: String(e?.message ?? e).slice(0, 100) }); }
        }
        await sleep(Math.max(50, everyMs - (Date.now() - now)));
    }
    sg?.stop();
    w?.stop();
    return {
        rows, server: srv, sampleMs: Date.now() - t0, at: [me.x, me.y, me.z], radii, reason,
        valid: rows.filter((x) => x.ok).length, invalid: rows.filter((x) => !x.ok).length,
        deaths: w ? w.deaths : [], stand: sg ? sg.stats() : null,
    };
}

function densityStats(rows, key) {
    const v = rows.map((r) => r[key]).filter((x) => typeof x === 'number');
    if (!v.length) return null;
    const hist = {};
    for (const x of v) hist[x] = (hist[x] ?? 0) + 1;
    const s = v.slice().sort((a, b) => a - b);
    return {
        key, n: v.length, mean: +(v.reduce((a, b) => a + b, 0) / v.length).toFixed(3),
        p05: s[Math.floor(0.05 * (s.length - 1))], p50: s[Math.floor(0.5 * (s.length - 1))],
        p90: s[Math.floor(0.9 * (s.length - 1))], max: s[s.length - 1], min: s[0],
        hist, pctGe2: +(v.filter((x) => x >= 2).length / v.length).toFixed(3),
        pctGe3: +(v.filter((x) => x >= 3).length / v.length).toFixed(3),
        pctGe4: +(v.filter((x) => x >= 4).length / v.length).toFixed(3),
    };
}

// ───────────────────────────────────────────────────── 标定（按口径重算，见报告 §4）
/**
 * 🚨 **两处口径/SQL 断点（S2-03 修；证据 `analysis/baseline_recompute.md` + `baseline_recompute.json`）**：
 *  ① `summary.json#cycle` 是**混口径**（drop_entity 与 inv_delta 两种判据混算）：落盘 headline =
 *     **124 tick / 6.20s（n=14）**；**119 tick / 5.96s 只在 drop_entity 子集（n=7）成立**。
 *     两者差 0.17%，不改变机制结论，但**对外报哪个数必须同时写清 n 和口径**（派单点名要写清这件事）。
 *  ② 上一轮 `micro_barter.mjs:44` 读的是 `b1_p2_distance.json` —— 那是**五档全部 no_los 的失败轮**
 *     （当时 `hasLos` 还是 `world.raycast` 版，见 piglin.js 注释）⇒ `bestDist` 恒 null，
 *     引擎一直用默认 1.4–3.2 窗，**而不是实测最佳档**。有成交的是 `b1_p3_distance.json`，本单读它。
 */
function loadCalibration() {
    const p4 = readJson('runs', 'S2_B1', 'b1_p4_trials.json');
    const p3 = readJson('runs', 'S2_B1', 'b1_p3_distance.json');
    const cal = readJson('runs', 'S2_P1_PROBE', 'p2b_throw_calib.json');
    const rows = p4?.trials ?? [];
    const pick = (f) => rows.filter((r) => r.ok && f(r) && typeof r.cycleSec === 'number').map((r) => r.cycleSec);
    const stat = (v) => (v.length ? {
        n: v.length, mean: +(v.reduce((a, b) => a + b, 0) / v.length).toFixed(3),
        p50: v.slice().sort((a, b) => a - b)[Math.floor(v.length / 2)],
        min: Math.min(...v), max: Math.max(...v),
    } : null);
    const dropEntity = pick((r) => r.dealBy === 'drop_entity');
    const invDelta = pick((r) => r.dealBy === 'inv_delta');
    const mixed = pick(() => true);
    const distRows = (p3?.distRows ?? []).filter((r) => r.ok && r.cycleSec != null).sort((a, b) => a.cycleSec - b.cycleSec);
    const best = distRows[0] ?? null;
    const cycleSec = dropEntity.length ? dropEntity.reduce((a, b) => a + b, 0) / dropEntity.length : 6.0;
    return {
        cycleMs: Math.round(cycleSec * 1000),
        holdingIdx: cal?.holdingIdx ?? null,
        // 投掷窗：实测有成交的档是 2.12 / 2.83 / 3.10 / 3.22 ⇒ 窗取 2.0–3.4
        minDist: 2.0, maxDist: 3.4,
        provenance: {
            cycle_dropEntity: stat(dropEntity), cycle_invDelta: stat(invDelta), cycle_mixed: stat(mixed),
            bestDistRow: best ? { dist0: best.dist0, cycleSec: best.cycleSec } : null,
            distRows: distRows.map((r) => ({ d: r.dist0, cyc: r.cycleSec, by: r.dealBy })),
            note: '对外周期口径 = drop_entity 子集（出手→猪灵脚边出现掉落物实体）；inv_delta 子集系统性晚约 0.5s（掉落物 pickupDelay 10 tick）',
        },
    };
}

// ───────────────────────────────────────────────────── 一格（同口径）跑法
function makeEngine(n, mode, { groundCount = 1, cycleMs = 6000, collect = true, calib = null } = {}) {
    return new pig.BarterEngine(bot(), {
        slots: n,
        mode,
        minDist: calib?.minDist ?? 2.0, maxDist: calib?.maxDist ?? 3.4,
        groundCount, groundRadius: 9,
        approachRadius: 12, approachStandoff: 2.8, approachMoveMs: 2500, approachLeash: 6.5,
        cycleTimeoutMs: Math.max(14000, Math.round(cycleMs * 2.5)),
        rebindEveryMs: 1200, whyEveryMs: 5000,
        collect, harvestEveryRounds: 8, harvestMaxMs: 20000,
        safeRadius: 4.5, leashRadius: 7,
    });
}

async function resetTrial(ingots = INGOTS) {
    cmd(`clear ${LANE.username}`);
    cmd('execute in minecraft:the_nether run kill @e[type=item]');
    cmd('execute in minecraft:the_nether run kill @e[type=experience_orb]');
    await sleep(900);
    cmd(`give ${LANE.username} minecraft:gold_ingot ${ingots}`);
    // ★ **整套**金甲（4 件）+ 盾牌 + 剑 + 食物：1.16.1 猪灵会打"没穿金装的玩家"
    //   （`NEAREST_TARGETABLE_PLAYER_NOT_WEARING_GOLD`）。S2-01 只给 2 件 ⇒ easy 下 29 秒被连杀 5 次。
    for (const it of ['golden_helmet:1', 'golden_chestplate:1', 'golden_leggings:1', 'golden_boots:1', 'iron_sword:1', 'shield:1', 'cooked_porkchop:16']) {
        cmd(`give ${LANE.username} minecraft:${it}`);
        await sleep(120);
    }
    cmd(`effect give ${LANE.username} minecraft:slow_falling 20 0 true`);
    await sleep(1400);
    const armor = await pig.ensureGoldArmor(bot(), { full: true });
    return { inv0: invCount(), ingots0: pig.countIngots(bot()), free: diskFreeGB(), armor };
}

/** 补足 N 头 fixture 猪灵（如实记数）：不够才 summon，等它真的进客户端实体表 */
async function ensureN(n, { minDist, maxDist }) {
    const me = botPos();
    const list = Object.values(bot()?.entities ?? {}).filter((e) => e && e.name === 'piglin' && e.position);
    const usable = list.filter((e) => {
        const d = e.position.distanceTo(me);
        return d >= minDist - 0.5 && d <= maxDist + 0.5 && pig.hasLos(bot(), e) && pig.isHolding(e) !== true;
    });
    let fixture = 0;
    const angles = [0, 45, 90, 135, 180, 225, 270, 315, 22, 68, 112, 158, 202, 248, 294, 336];
    for (let i = usable.length; i < n; i++) {
        const a = (angles[i % angles.length] * Math.PI) / 180;
        const d = minDist + ((i % 3) * 0.4);
        const x = me.x + Math.cos(a) * d, z = me.z + Math.sin(a) * d;
        const before = new Set(Object.values(bot()?.entities ?? {}).map((e) => e.id));
        cmd(`execute in minecraft:the_nether run summon minecraft:piglin ${x.toFixed(2)} ${me.y.toFixed(2)} ${z.toFixed(2)}`);
        let ok = false;
        for (let k = 0; k < 50; k++) {
            await sleep(120);
            const fresh = Object.values(bot()?.entities ?? {}).find((e) => e.name === 'piglin' && !before.has(String(e.id))
                && Math.abs(e.position.x - x) < 2.5 && Math.abs(e.position.z - z) < 2.5);
            if (fresh) { ok = true; break; }
        }
        if (!ok) console.log(`[ensureN] 第 ${fixture + 1} 只 fixture 6s 内没进实体表`);
        fixture++;
    }
    await sleep(1000);
    return { natural: Math.min(usable.length, n), fixture };
}

async function oneMode({ mode, windowMs, work, cycleMs, calib = null, groundCount = 1, label = null, shouldStop = null }) {
    const w = watchDeaths();
    await recallTo(work, { label: label ?? mode });
    const rs = await resetTrial(INGOTS);
    const me = botPos();
    // ★ 同口径的关键：三种模式**共用同一个可选池**（都补到 N 头、半径都取 approach 的 11 格），
    //   唯一的变量是**策略**（等它进 3.4 格 / 丢地上让它来 / 主动走过去）。
    //   ⚠ 上一轮三种模式用**不同半径**各补各的 ⇒ 猪群组成都不同，对比无效。
    const prov = await ensureN(N, { minDist: 1.2, maxDist: 11 });
    const engine = makeEngine(N, mode, { groundCount, cycleMs, calib });
    // ★ 中止闸 = 死亡（server.log + 维度两条独立通道） **AND** 站位守护（漂/下坠就拉回）
    const sg = makeStandGuard(work, { r: mode === 'approach' ? 7 : 2.5, dy: 3.0 });
    engine.opts.guard = () => makeDeathGuard(w)() ?? sg.guard();
    const bound = engine.bind();
    const t0 = Date.now();
    const rep = await engine.run({ windowMs, shouldStop });
    const h = await engine.harvest();
    sg.stop();
    w.stop();
    const after = Date.now();
    return {
        mode, N, bound, work: [me.x, me.y, me.z], windowMs, rep,
        natural: prov.natural, fixture: prov.fixture,
        harvest: { gained: h.gained, ms: h.ms, skippedOutside: h.skippedOutside, abortedByLeash: h.abortedByLeash, freed: h.freed },
        ingots0: rs.ingots0, ingotsEnd: pig.countIngots(bot()), invEnd: invCount(),
        wallMs: after - t0, hp: bot()?.health, alive: !!bot()?.entity, dim: dim(),
        deaths: w.deaths, stand: sg.stats(), diskFreeGB: diskFreeGB(),
        whySamples: engine.stats.whySamples.slice(0, 12),
    };
}

async function main() {
    await openRun(STAMP);
    try {
        pig = await import(moduleUrl('src/agent/tasks/exec/piglin.js'));
        const C = loadCalibration();
        if (C.holdingIdx != null) pig.applyCalibration({ holdingIdx: C.holdingIdx, healthIdx: 9, babyIdx: 12, evidence: 'S2_P1_PROBE/p2b_throw_calib.json' });
        console.log(`[cfg] 标定holdingIdx=${JSON.stringify(C.holdingIdx)} 周期(drop_entity口径)=${C.cycleMs}ms 投掷窗=${C.minDist}~${C.maxDist} 模式=${MODES} N=${N} 窗口=${WINDOW_MS / 60000}min`);
        console.log(`[cfg] 周期三口径 ${JSON.stringify(C.provenance)}`);

        await bootWorld({ difficulty: DIFFICULTY });
        const t = truth();
        const park = await parkAndStand();
        const work = park.stand;
        // ★ 站位**四点支撑**校验：bot 碰撞箱 0.6 宽，只查站位格正下方一格会漏掉"半个身子悬空"
        //   （S2-03 实测：钉住 (320,68,241) 后 bot 立刻掉一格并漂 1.2 格 ⇒ 四角必须有实心）。
        const footing = footingOk(botPos());
        const sc = await t.selfCheck?.({ dim: 'the_nether', at: park.park, atEntity: LANE.username });
        record('m3_p0_setup', { park, work, footing, standRec: park.standRec, selfCheck: sc ?? null, calibration: C, modes: MODES, N, ingots: INGOTS, diskFreeGB: diskFreeGB(), seed: SEED, center: S });
        console.log(`[setup] 作业位=${work} 四点支撑=${JSON.stringify(footing)} 猪灵(服务端)=${JSON.stringify(await serverCount())} TPS=${t.clock.tps()}`);
        if (!footing.ok) console.log(`[setup] ⚠ 四点支撑不全（${footing.why} / ${JSON.stringify(footing.names)}）⇒ 站位守护会把 bot 反复拉回`);

        // ── ① 密度时间分布（开放场，站定不动，不投锭）────────────────
        if (WANT('density')) {
            await recallTo(work, { label: 'density' });
            const d = await sampleDensity({ ms: DENSITY_MS, at: botPos(), work });
            const stats = {};
            // ★ **只用有效样本**算分布：失效样本（掉下台/离开下界/区块卸载）会把"没读到"读成"没有猪灵"
            const vrows = d.rows.filter((r) => r.ok);
            for (const rad of d.radii) {
                const k = `n${String(rad).replace('.', '_')}`;
                stats[k] = densityStats(vrows, k);
            }
            stats.total24 = densityStats(vrows, 'total24');
            stats.nearest = densityStats(vrows, 'nearest');
            stats.within6 = densityStats(vrows, 'within6');
            stats.within12 = densityStats(vrows, 'within12');
            stats.samples = { total: d.rows.length, valid: d.valid, invalid: d.invalid, reason: d.reason, deaths: d.deaths, stand: d.stand };
            record('m3_p1_density', { ...d, stats, note: '3 格内同时几头猪灵的时间分布 = techniques-1161 §2.1「喂 4 头」那条打法的未验证前提' });
            console.log('[密度]', JSON.stringify(stats, null, 1).slice(0, 2200));
        }

        // ── ② 三模式同口径（开放场）──────────────────────────────────
        const sweep = [];
        if (WANT('modes')) {
            for (const mode of MODES) {
                const r = await oneMode({ mode, windowMs: WINDOW_MS, work, cycleMs: C.cycleMs, calib: C, groundCount: 1 });
                sweep.push(r);
                record(`m3_p2_mode_${mode}`, r);
                console.log(`[N=${N} ${mode}] 绑=${r.bound}(自然${r.natural}/fixture${r.fixture}) 投锭=${r.rep.throwsOk}/${r.rep.throws} = ${r.rep.throwsPerMin}/分`
                    + ` 周期p50=${r.rep.cycleP50Ms}ms 珍珠=${r.rep.pearls} 补人=${r.rep.rebind.ok}/${r.rep.rebind.attempt} 空转=${Math.round((r.rep.ingotStarvedMs ?? 0) / 1000)}s`
                    + ` reason=${r.rep.reason} 死亡=${JSON.stringify(r.deaths)}`);
            }
            const curve = sweep.map((r) => ({
                mode: r.mode, N: r.N, bound: r.bound, natural: r.natural, fixture: r.fixture,
                windowMin: +(r.rep.windowMs / 60000).toFixed(2),
                throwsOk: r.rep.throwsOk, throwsPerMin: r.rep.throwsPerMin,
                cyclesN: r.rep.cyclesN, cycleP50Ms: r.rep.cycleP50Ms, cycleP10Ms: r.rep.cycleP10Ms, cycleP90Ms: r.rep.cycleP90Ms,
                pearls: r.rep.pearls, pearlsPerMin: r.rep.windowMs ? +(r.rep.pearls / (r.rep.windowMs / 60000)).toFixed(2) : 0,
                ingotsUsed: r.ingots0 - r.ingotsEnd, ingotStarvedSec: Math.round((r.rep.ingotStarvedMs ?? 0) / 1000),
                rebind: r.rep.rebind, slotKilled: r.rep.slotKilled, moves: r.rep.moves, moveSec: +(r.rep.moveMs / 1000).toFixed(1),
                ownDropsSeen: r.rep.ownDropsSeen, tooClose: r.rep.tooClose,
                reason: r.rep.reason, deaths: r.deaths, phases: r.rep.phases, tps: t.clock.tps(),
            }));
            const rank = curve.slice().sort((a, b) => b.throwsPerMin - a.throwsPerMin);
            record('m3_p2_curve', { curve, best: rank[0] ?? null, gate27: rank.filter((c) => c.throwsPerMin >= 27).map((c) => c.mode) });
            console.log('[三模式]', JSON.stringify(curve.map((c) => ({ m: c.mode, tpm: c.throwsPerMin, bound: c.bound, cyc: c.cycleP50Ms, pearls: c.pearls }))));
        }

        // ── ③ 围栏组（**只算引擎上限**；fill 回执全非 0 才开测）────────
        let pen = null;
        if (WANT('pen')) {
            await recallTo(work, { label: 'pen' });
            pen = await buildPen({ r: 4, wallH: 2, at: work });
            record('m3_p3_pen', pen);
            if (!pen.ok) {
                console.log(`[pen] ★ 硬闸未通过（回执 ${JSON.stringify(pen.fillReceipts)}／客户端玻璃 ${pen.clientCheck.glass}/${pen.clientCheck.total}）⇒ **不开测**`);
                record('m3_p3_pen_skipped', { why: 'pen_hard_gate', pen });
            } else {
                const r = await oneMode({ mode: 'wait', windowMs: Math.min(WINDOW_MS, 6 * 60000), work, cycleMs: C.cycleMs, calib: C, label: 'pen/wait' });
                record('m3_p3_pen_run', { ...r, note: '围栏组只读引擎上限（可行性按开放场判）', pen: { ok: pen.ok, fillReceipts: pen.fillReceipts, glassRatio: pen.clientCheck.glassRatio } });
                console.log(`[pen 组] 引擎上限 ${r.rep.throwsPerMin}/分（绑${r.bound} 周期${r.rep.cycleP50Ms}ms）——**不代表可行**`);
            }
        }

        // ── ④ 验收 0→12 珍珠（n≥3，用开放场最好的模式）────────────────
        const pearlRuns = [];
        if (WANT('pearls')) {
            let best = { mode: 'wait', throwsPerMin: -1 };
            if (WANT('modes') && sweep.length) {
                best = sweep.slice().sort((a, b) => b.rep.throwsPerMin - a.rep.throwsPerMin)[0];
            }
            for (let i = 1; i <= PEARL_RUNS; i++) {
                const r = await oneMode({
                    mode: best.mode, windowMs: PEARL_MS, work, cycleMs: C.cycleMs, calib: C, label: `pearl${i}`,
                    // 达到 12 颗就收（省墙钟；达不到就跑满 --pearl-min 分钟，如实记 reason）
                    shouldStop: (e) => (e.stats.pearls >= PEARL_TARGET ? `target_${PEARL_TARGET}` : null),
                });
                // 珍珠目标：跑到 12 颗就收（shouldStop 走引擎的 guard 之外那一条）
                const row = { run: i, mode: best.mode, ...r };
                pearlRuns.push(row);
                record(`m3_p4_pearls_run${i}`, row);
                console.log(`[珍珠局 ${i}] 模式=${best.mode} 珍珠=${r.rep.pearls}/${PEARL_TARGET} 投锭=${r.rep.throwsOk}(${r.rep.throwsPerMin}/分)`
                    + ` 锭耗=${r.ingots0 - r.ingotsEnd} 用时=${(r.rep.windowMs / 1000).toFixed(0)}s reason=${r.rep.reason} 死亡=${JSON.stringify(r.deaths)}`);
                // ⚠ **达标不 break**：验收线是 n≥3（派单 §F），第一局达标就收工只拿得到 n=1
                //   （本轮真的这么丢过一次：run1 200s 就打到 14 颗，循环却直接 break 了）。
                //   只有**死亡**才提前收（那一局的数据已无意义）。
                if (r.rep.reason?.startsWith('death')) break;
            }
        }

        const okRuns = pearlRuns.filter((r) => r.rep.pearls >= PEARL_TARGET);
        const curve = sweep.map((r) => ({ mode: r.mode, throwsPerMin: r.rep.throwsPerMin, bound: r.bound, cycleP50Ms: r.rep.cycleP50Ms, pearls: r.rep.pearls }));
        const n4 = curve.find((c) => c.N === N) ?? curve[0];
        const verdict = {
            seed: SEED, center: S, N, modes: MODES, windowMin: WINDOW_MS / 60000,
            curve, pen: pen ? { ok: pen.ok, fillReceipts: pen.fillReceipts, glassRatio: pen.clientCheck.glassRatio } : null,
            pearls: {
                target: PEARL_TARGET, runs: pearlRuns.length, achieved: okRuns.length,
                rows: pearlRuns.map((r) => ({ run: r.run, mode: r.mode, pearls: r.rep.pearls, throwsOk: r.rep.throwsOk, throwsPerMin: r.rep.throwsPerMin, ingotsUsed: r.ingots0 - r.ingotsEnd, sec: +(r.rep.windowMs / 1000).toFixed(0), reason: r.rep.reason, deaths: r.deaths })),
            },
            gate: {
                n_throwsPerMin: n4?.throwsPerMin ?? null,
                gate27: (n4?.throwsPerMin ?? 0) >= 27,
                target37: (n4?.throwsPerMin ?? 0) >= 37,
                pearls_n_ge_3: okRuns.length >= PEARL_RUNS,
            },
            tps: t.clock.tps(), diskFreeGB: diskFreeGB(),
        };
        record('m3_p5_verdict', verdict);
        writeSummary(verdict);
        console.log('[验收]', JSON.stringify(verdict.gate));
    } catch (e) {
        console.error('[m3] 失败：', e);
        try { record('error', { message: String(e?.message ?? e), stack: String(e?.stack ?? '').slice(0, 900) }); } catch { /* 忽略 */ }
        try { writeSummary({ failed: String(e?.message ?? e) }); } catch { /* 忽略 */ }
        process.exitCode = 1;
    } finally {
        await closeRun();
    }
}

async function serverCount(sel = '@e[type=piglin]') {
    try {
        const r = await truth().countEntities('the_nether', LANE.username, sel, { quietMs: 800, minWaitMs: 6000, timeoutMs: 25000 });
        return { n: r.n, trusted: r.trusted };
    } catch (e) { return { n: null, error: String(e?.message ?? e).slice(0, 80) }; }
}

/** 安全进场：先 parkSafe（高空缓降 + 真值竖扫），再 standNatural 落到**地面**格（猪灵只在地面） */
async function parkAndStand() {
    const park = await parkSafe({ cx: S.x, cz: S.z, yLo: S.yLo, yHi: 100, r: 4 });
    await sleep(4000);
    if (WORK_PIN) {
        // 钉住作业位：仍然走真值复核（feet=air + 脚下实心非液体），不许盲信 --work
        await recallTo([WORK_PIN.x, WORK_PIN.y, WORK_PIN.z], { label: 'work-pin' });
        const t = truth();
        const feet = await t.probeCell('the_nether', { x: WORK_PIN.x, y: WORK_PIN.y, z: WORK_PIN.z }, ['minecraft:air']);
        const floor = await t.probeCell('the_nether', { x: WORK_PIN.x, y: WORK_PIN.y - 1, z: WORK_PIN.z },
            ['minecraft:netherrack', 'minecraft:blackstone', 'minecraft:basalt', 'minecraft:crimson_nylium', 'minecraft:warped_nylium', 'minecraft:soul_soil']);
        if (feet.hit !== 'minecraft:air' || !floor.hit) throw new Error(`WORK_PIN_INVALID：${JSON.stringify(WORK_PIN)} feet=${feet.hit} floor=${floor.hit}`);
        return { park, stand: [WORK_PIN.x, WORK_PIN.y, WORK_PIN.z], standRec: { pinned: true, cell: [WORK_PIN.x, WORK_PIN.y, WORK_PIN.z], verified: { feet: feet.hit, floor: floor.hit } } };
    }
    const stand = await standNatural({ cx: S.x, cz: S.z, r: 22, yLo: S.yLo, yHi: S.yHi + 30 });
    if (!stand) throw new Error('STAND_NATURAL_FAILED：新中心 [336,256] 找不到可站自然地面（作业位必须是地面格）');
    return { park, stand: stand.stand, standRec: stand };
}

// `--dry`：**不起服**的解析自检（import 图 + 语法），收工前先跑一遍，省得白等一次排队。
if (process.argv.includes('--dry')) {
    console.log(`[dry] 解析通过：模式=${MODES} N=${N} 窗口=${WINDOW_MS / 60000}min 密度=${DENSITY_MS / 60000}min `
        + `珍珠局=${PEARL_RUNS}×${PEARL_TARGET} 只跑=${ONLY.join(',')} 盘=${STATION.bastion.x},${STATION.bastion.z} 种子=${SEED}`);
} else {
    main();
}

