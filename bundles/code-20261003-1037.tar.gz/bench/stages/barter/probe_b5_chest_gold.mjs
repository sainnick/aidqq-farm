// probe_b5_chest_gold.mjs — MC-S2-01 · B5：主种子堡垒的金锭来源（服务端真值，不让 bot 透视）
//
// 问题（RESEARCH-03 B5 / stage-02 §0）：「堡垒 treasure 箱 12.85 锭/箱，需 ~4 箱达 46 锭」是
// **loot table 期望**，含方差。route 只记了区域内 `chest:5` 这个**计数**，没有位置、没有内容。
//
// 口径（派单 §F「不要让 bot 透视」）：
//   **全程不读 bot 的方块/容器视图**。定位与读数都走 fill 回执 + data get，两局分工：
//   · 世界①（可弃）：`fill <盒> <marker> replace chest` 是**破坏性**的，只能用它二分定位；
//   · 世界②（同种子 fresh world，地形确定）：在①记下的坐标上 `data get block … Items`
//     **非破坏性**读战利品 + `LootTable` 读箱型（treasure / bridge / hoglin_stable…）。
//   ⚠ 1.16.1 无 /forceload ⇒ 两局都必须先把 bot tp 过去让区块自然加载。
//   ⚠ 顺带数清 gold_block / gilded_blackstone：route 的 22 块金块 = 198 锭，
//     比"4 箱开 46 锭"大一个量级 —— 但挖金块会激怒猪灵（stage-02 §0 风险表），要一起报。
//
// 泳道只有 C。用法：node probe_b5_chest_gold.mjs [--stamp S2_B5]

import {
    openRun, bootWorld, stopWorld, closeRun, cmd, truth, bot, botPos, posStr,
    tpNether, record, writeSummary, sleep, STATION, SEED, argv, LANE,
} from './harness.mjs';

const STAMP = argv('stamp', 'S2_B5');
const S = STATION.bastion;
const BOX = { x1: S.x, y1: S.yLo, z1: S.z, x2: S.x + S.radius, y2: S.yHi, z2: S.z + S.radius };
const TP = { x: S.x, y: S.yHi + 6, z: S.z };
const vol = (b) => (b.x2 - b.x1 + 1) * (b.y2 - b.y1 + 1) * (b.z2 - b.z1 + 1);

function splitBox(b) {
    const mx = Math.floor((b.x1 + b.x2) / 2), my = Math.floor((b.y1 + b.y2) / 2), mz = Math.floor((b.z1 + b.z2) / 2);
    const out = [];
    for (const [x1, x2] of [[b.x1, mx], [mx + 1, b.x2]]) {
        for (const [y1, y2] of [[b.y1, my], [my + 1, b.y2]]) {
            for (const [z1, z2] of [[b.z1, mz], [mz + 1, b.z2]]) {
                if (x1 > x2 || y1 > y2 || z1 > z2) continue;
                out.push({ x1, y1, z1, x2, y2, z2 });
            }
        }
    }
    return out;
}

/** 破坏性二分定位：把目标方块换成 marker，按回执计数递归细分到 1×1×1。返回坐标列表。 */
async function locateBlocks(dim, box, blockName, { budget = 900, marker = 'minecraft:barrier' } = {}) {
    const t = truth();
    const found = [];
    let fills = 0, boxes = 0;
    const stack = [box];
    while (stack.length) {
        if (fills >= budget) { console.log(`[locate] 预算耗尽，剩 ${stack.length} 个待查盒`); break; }
        const b = stack.pop();
        boxes++;
        const n = await t.fillCount(dim, b, blockName, { marker, timeoutMs: 30000 });
        fills++;
        if (n === 0) continue;
        if (vol(b) === 1) { found.push({ x: b.x1, y: b.y1, z: b.z1 }); continue; }
        for (const s of splitBox(b)) stack.push(s);
    }
    return { found, fills, boxes, budgetHit: fills >= budget };
}

/** 解析 `Items: [{Count:6b, Slot:0b, id:"minecraft:gold_ingot"}, …]` */
function parseItems(line) {
    const out = [];
    if (!line) return out;
    const body = /Items:\s*(\[[\s\S]*?\])(?:,|\s*$)/.exec(line);
    const src = body ? body[1] : null;
    if (!src) return out;
    for (const grp of src.split(/\},\s*\{/)) {
        const id = /id:"minecraft:([a-z_0-9]+)"/.exec(grp)?.[1];
        const count = /Count:(\d+)[bsl]?/.exec(grp)?.[1];
        if (id) out.push({ name: id, count: count ? parseInt(count, 10) : 1 });
    }
    return out;
}

async function bootAndPark(difficulty) {
    await bootWorld({ difficulty });
    // ★ S2-03：**必须先给缓降/抗性再 tp**。B5 首次跑就是**没给** ⇒ bot 从 y=53 自由落体，
    //   等 `selfCheck` 发 fill 时人已经不在那根列柱上 ⇒ 服务端回 `That position is not loaded`
    //   ⇒ **`fill` 类 6s 等不到回执 → 整条真值通道判死（TRUTH_POISONED）** ⇒ 0.9 分钟整局结束。
    //   （parkSafe 一直有这两条，B5 这条路径漏了。）
    cmd(`effect give ${LANE.username} minecraft:slow_falling 120 0 true`);
    cmd(`effect give ${LANE.username} minecraft:resistance 120 4 true`);
    await sleep(700);
    await tpNether(TP.x, TP.y, TP.z);
    await sleep(6000);
    // 落位复核：还在那根列柱上吗？不在就再 tp 一次（区块没加载 = 后面所有 fill 都白跑）
    let p = botPos();
    if (!p || Math.abs(p.x - TP.x) > 2 || Math.abs(p.z - TP.z) > 2) {
        console.log(`[boot ${difficulty}] 落位偏了（${posStr(p)}）⇒ 重 tp`);
        cmd(`effect give ${LANE.username} minecraft:slow_falling 120 0 true`);
        await tpNether(TP.x, TP.y, TP.z);
        await sleep(4000);
        p = botPos();
    }
    console.log(`[boot ${difficulty}] dim=${bot()?.game?.dimension} pos=${posStr(p)}（落位列柱 ${TP.x},${TP.z} 已加载）`);
    return p;
}

async function main() {
    await openRun(STAMP);
    let summary = {};
    try {
        // ── 世界①：破坏性定位 ─────────────────────────────────────────────
        await bootAndPark('easy');
        const t = truth();

        // 通道自检（先证伪工具，再采数）
        // ★ 传 `atEntity`（B5 首次跑没传 ⇒ `countEntities` 报 NEED_AT_ENTITY，白丢一个通道自检）
    const sc = await t.selfCheck({ dim: 'the_nether', at: botPos(), atEntity: LANE.username });
        record('b5_p0_selfcheck', { selfCheck: sc });
        console.log('[selfcheck]', JSON.stringify(sc));

        // 区域粗计（route 记的是 chest:5 / gold_block:22 / gilded_blackstone:227）
        const coarse = {};
        for (const b of ['minecraft:chest', 'minecraft:trapped_chest', 'minecraft:gold_block', 'minecraft:gilded_blackstone', 'minecraft:basalt', 'minecraft:blackstone']) {
            coarse[b] = await t.fillCount('the_nether', BOX, b, { marker: 'minecraft:barrier', timeoutMs: 40000 });
            console.log(`[coarse] ${b} = ${coarse[b]}`);
            await sleep(200);
        }
        record('b5_p1_coarse', { box: BOX, coarse, note: '破坏性计数（世界①可弃）；marker 留在原地不影响世界②' });

        const loc = {};
        for (const b of ['minecraft:chest', 'minecraft:gold_block']) {
            const r = await locateBlocks('the_nether', BOX, b);
            loc[b] = r;
            console.log(`[locate] ${b}: ${r.found.length} 处, ${r.fills} 次 fill`);
            record(`b5_p2_locate_${b.replace('minecraft:', '')}`, r);
        }

        // ── 世界②：同种子 fresh world，非破坏读战利品 ─────────────────────
        await stopWorld();
        await bootAndPark('easy');
        const t2 = truth();

        const chests = [];
        for (const c of (loc['minecraft:chest']?.found ?? [])) {
            const rec = { pos: c };
            try {
                const lItems = await t2.dataBlock('the_nether', c, 'Items', { timeoutMs: 10000 });
                rec.items = parseItems(lItems);
                rec.goldIngots = rec.items.filter((i) => i.name === 'gold_ingot').reduce((a, b) => a + b.count, 0);
                rec.goldNuggets = rec.items.filter((i) => i.name === 'gold_nugget').reduce((a, b) => a + b.count, 0);
                rec.goldBlocks = rec.items.filter((i) => i.name === 'gold_block').reduce((a, b) => a + b.count, 0);
                rec.itemCount = rec.items.reduce((a, b) => a + b.count, 0);
                rec.raw = (lItems ?? '').slice(0, 400);
            } catch (e) { rec.error = String(e).slice(0, 160); }
            try {
                const lTbl = await t2.dataBlock('the_nether', c, 'LootTable', { timeoutMs: 8000 });
                rec.lootTable = lTbl ? (/chests\/([a-z_]+)\.json/.exec(lTbl)?.[1] ?? lTbl.slice(-80)) : null;
            } catch (e) { rec.lootTableErr = String(e).slice(0, 120); }
            chests.push(rec);
            console.log(`[chest] ${c.x},${c.y},${c.z} loot=${rec.lootTable} 金锭=${rec.goldIngots} 物品${rec.itemCount}件`);
        }
        const totalIngots = chests.reduce((a, c) => a + (c.goldIngots ?? 0), 0);
        const goldBlockCount = (loc['minecraft:gold_block']?.found ?? []).length;
        const b5 = {
            box: BOX, chests, totalIngots,
            goldBlockPositions: loc['minecraft:gold_block']?.found ?? [],
            goldBlockIngotValue: goldBlockCount * 9,
            verdict: {
                chestsFound: chests.length,
                treasureChests: chests.filter((c) => c.lootTable === 'treasure').length,
                ingotsFromChests: totalIngots,
                ingotsNeededFor12Pearls: 46,                 // stage-02 R2.5：E[投锭次数]=13/0.2837≈46
                enoughFromChests: totalIngots >= 46,
                ingotsFromGoldBlocks: goldBlockCount * 9,
            },
        };
        record('b5_p3_chest_truth', b5);
        writeSummary(b5);
        summary = b5;
    } catch (e) {
        console.error('[b5] 失败：', e);
        try { record('error', { message: String(e?.message ?? e), stack: String(e?.stack ?? '').slice(0, 900) }); } catch { /* 忽略 */ }
        try { writeSummary({ failed: String(e?.message ?? e) }); } catch { /* 忽略 */ }
        process.exitCode = 1;
    } finally {
        await closeRun();
    }
    return summary;
}

main();
