// run_smoke.mjs — G 线：借泳道跑微基准冒烟的驱动（等泳道 → 跑 → 被占就重试）
//
// 为什么要它：泳道是共享资源（手册 §9.2 泳道归属看 .lane-owners 心跳）。
// 各开发线在自己两局之间进出泳道，所以"看一次就起跑"必然有概率撞上 —— run_bench
// 遇到活锁会**正确地停下让路**（"✗ 线锁被占 … 不要接管"），于是这一轮直接白等。
// 这里把「等一个真正释放的窗口 + 抢跑 + 失败重试」包起来，一次调用跑完一组。
//
// 用法：node run_smoke.mjs --scenario creeper --trials 3 --stamp MIC_X --attempts 4
// 判据：判空闲 = **端口空闲 且 该泳道线锁不活**（"两局之间"那种空窗不算——
//       持有者下一局就会抢回去，撞上去是两败俱伤）。

import { execFileSync, spawnSync } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BENCH = path.join(HERE, '..');
const NODE = process.execPath;
function arg(n, d) { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : d; }

const SCENARIO = arg('scenario', 'melee');
const TRIALS = arg('trials', '3');
const STAMP = arg('stamp', `MIC_${SCENARIO.toUpperCase()}`);
const TIMEOUT_MS = arg('timeout-ms', '240000');
const ATTEMPTS = parseInt(arg('attempts', '4'), 10);
const WAIT_S = parseInt(arg('wait-s', '300'), 10);
const PREFER = arg('prefer', 'A,C,B').split(',');

function freeLane() {
    // ⚠⚠ `wait_lane.mjs` 在**上一层**（`basic-survival/`），不在 `micro/` 里。
    //   原来这里写的是 `path.join(HERE, 'wait_lane.mjs')` = `micro/wait_lane.mjs`，
    //   而那个文件**不存在** ⇒ spawnSync 抛 ENOENT、r.stdout 为空 ⇒ 正则匹配不上
    //   ⇒ freeLane() 恒返回 null ⇒ 一路打印"没有空闲泳道"，**看起来像"泳道被别人占着"**，
    //   实际是本脚本自己的路径错了。与 micro_defense.mjs 的 TASK_LAYER 默认路径
    //   少退一级是同一族（报告 bug #11）。
    //   路径写错时必须**报出来**，不能伪装成"没有空闲泳道"——后者会把人引去
    //   错误地怀疑别的线占着泳道。
    const p = path.join(BENCH, 'wait_lane.mjs');
    if (!fs.existsSync(p)) {
        console.log(`  ✗ 找不到 ${p} —— 这是脚本自身的路径错误，不是泳道被占`);
        return null;
    }
    const r = spawnSync(NODE, [p, '--max-s', '1', '--prefer', PREFER.join(',')], { encoding: 'utf8' });
    if (r.error) { console.log(`  ✗ wait_lane 起不来：${r.error.message}`); return null; }
    const m = /FREE_LANE=(\w)/.exec(r.stdout || '');
    if (!m && (r.stderr || '').trim()) console.log(`  ✗ wait_lane 报错：${String(r.stderr).trim().slice(0, 200)}`);
    return m ? m[1] : null;
}

for (let attempt = 1; attempt <= ATTEMPTS; attempt++) {
    console.log(`\n######## attempt ${attempt}/${ATTEMPTS} scenario=${SCENARIO} ########`);
    const lane = freeLane();
    if (!lane) { console.log('  没有空闲泳道，等一轮…'); await new Promise((r) => setTimeout(r, 20000)); continue; }
    console.log(`  借到泳道 ${lane}，起跑（trials=${TRIALS}）`);
    const r = spawnSync(NODE, [
        path.join(BENCH, 'run_bench.mjs'),
        '--scenario', SCENARIO, '--lane', lane, '--trials', TRIALS,
        '--timeout-ms', TIMEOUT_MS, '--no-progress-s', '240', '--probe-ms', '3000',
        '--stamp', STAMP,
    ], { encoding: 'utf8', env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
    const out = `${r.stdout || ''}\n${r.stderr || ''}`;
    // 只挑关键行，避免刷屏
    for (const line of out.split(/\r?\n/)) {
        if (/verdict=|DONE|线锁被占|toolFailed|scenario gates|common gates|cleanup .*(CLEAN|DIRTY)|done \d+\//.test(line)) console.log(`  | ${line.trim()}`);
    }
    const summary = path.join(BENCH, 'runs', STAMP, 'summary.jsonl');
    const ran = fs.existsSync(summary) && fs.readFileSync(summary, 'utf8').trim().length > 0;
    if (ran) {
        console.log(`  ✅ 跑完并落盘：${summary}`);
        process.exit(0);
    }
    console.log('  ⚠ 这一轮没跑成（多半是线锁被占），下一轮重试');
    await new Promise((r2) => setTimeout(r2, 15000));
}
console.log(`\n❌ ${ATTEMPTS} 轮都没抢到泳道，停下让路（不接管别人的活锁）`);
process.exit(2);
