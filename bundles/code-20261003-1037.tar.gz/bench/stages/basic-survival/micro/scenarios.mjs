// scenarios.mjs — MC-M1-TASK-07（G 线）防御微基准：**4 组场景的唯一真源**
//
// 手册 §5：场景坐标**只能有一个真源**（编排器和 bot 共用同一份定义）。
// 本文件就是那份真源；run_bench.mjs 由它拼出控制台命令串，micro_defense.mjs 只负责执行与判据。
//
// —— 为什么场景命令走「控制台 + 全部绝对坐标」——
// 三条实测把可选方案一个个否掉了（MIC_CREEPER_S1 / MIC_GAZE_PROBE2 / MIC_CREEPER_S2）：
//   ① **bot 用 chat 发命令，带参数的一律失败**：回包是 `commands.failed` + `<--[HERE]`，
//      而 1.16.1 的 `commands.failed` **本身就是空串** ⇒ 服务端只给玩家看输入和标记，
//      **真实原因只进服务端日志**，客户端侧查不出来。判决实验：`/list`（无参）**成功**
//      并返回在线列表 ⇒ 通道通、已登录、也是 op；失败的只有带参数命令。
//   ② 所以场景交给控制台（手册 §2/§5 的要求）。控制台**有 `@p`、没有 `@s`**。
//   ③ 但 **`execute at @p run … ~ …` 的位置上下文不可信**：MIC_CREEPER_S2 里控制台回
//      `Successfully filled 289 blocks` + `Summoned new Creeper`（都没报错），
//      可 bot 实测 creep 在 **79.6 格外**、脚下 stone 也分不清是原生的还是填的
//      ⇒ `~` 没按 bot 解析。**只有 `execute` 的位置上下文不可信，`@p` 作目标选择器可靠**
//      （`/tp @p <绝对坐标>` 能定位）。所以：**一条 `~` 都不用，全绝对坐标。**
//
// —— 因此需要一个 forceload（绝对坐标在 y=200 的空中，先得让区块加载）——
// 手册 §3：未加载区块上的 fill 是**静默丢弃**；forceload 是**异步**的，四参数。
// injectKit 每条命令间隔 300ms，所以这里把 fill **连发三次**：第一次可能正好撞在
// forceload 还没生效的窗口里，后两次兜住。真正的权威判据是 bot 侧的唯一真值标记
// （手册 §5「真值标记要唯一」）：标记没出现在该出现的位置 ⇒ 一律 toolFailed。
//
// 裁决 1 的口径（设计会话 10-02 夜）：**开发期允许 kit + summon + 固定站位 + 布景硬闸门**。
//   - 物品 + 场景命令都走 --kit 通道（控制台），kit.json 留痕
//   - 每组都有硬闸门：不通过就 toolFailed 判负，**绝不**把"场景没建起来"读成"原语坏了"
//     （TASK-08 r6 的教训：4 轮微基准每轮都在测假的东西）

import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
// bench/ 自己没有 node_modules；`vec3` 只存在于任务层那一份（worktree 的 node_modules 是
// 指向主目录的 junction）⇒ 用 createRequire 锚到任务层解析。与 fake_world.mjs 同一个坑。
// ⚠ 本文件在 basic-survival/**micro**/ 下，比 fake_world.mjs（basic-survival/）**深一级**，
//   默认路径要多退一层（`../../../../`）。写少一层的症状很隐蔽：平时都设了
//   TASK_LAYER_DIR 走 env 分支，只有不设 env 直接跑才会炸 —— 而 `--remap-only` 就是这条路。
const TASK_LAYER = process.env.TASK_LAYER_DIR || path.resolve(HERE, '../../../../mindcraft-wt/s0-survival');
const require = createRequire(path.join(TASK_LAYER, 'package.json'));
const { Vec3 } = require('vec3');
export { Vec3 };

// —— 竞技场（唯一真源，绝对坐标；y=200 空中平台，与任何出生点都不可能重叠）——
export const ARENA = {
    // ⚠ 25×25 而不是 17×17：creep 要从 **12 格外**刷（4 格外它会在闸门等待期就引爆、
    //   把 bot 炸飞，见下方 marker 注释），而 bot 站在中心 ⇒ 12 格必须仍在平台上。
    //   17×17 的半宽只有 8，放不下 12 格外 —— 于是 creep 掉出平台掉进虚空（MIC_CREEPER_S7 实测）。
    minX: 0, maxX: 24, minZ: 0, maxZ: 24,
    floorY: 200,                                   // 地板方块所在 y（顶面 = 201）
    standY: 201,                                   // bot 站位所在 y
    cx: 8.5, cz: 8.5,                             // bot 站位中心
    // ★ 唯一真值标记放在**正中心脚下**（不是角落！MIC_CREEPER_S5 教训）：
    //   放在角落时，闸门等待期里 creep 走到 3 格内引爆、把 bot 炸飞 4.67 格，
    //   于是"bot 在不在中心"这种**位置**判据会被战斗本身推翻 —— 而场景其实建对了。
    //   标记在脚下则与 bot 的位置无关：它只证明"地板建对了 + 坐标链对了 + tp 生效了"。
    marker: [8, 200, 8],
    clearTopY: 204,                                // 清空到这个高度，保证头顶净空
    settleMs: 1500,
    gateTimeoutMs: 12000,
};
const F = (y) => `${ARENA.minX} ${y} ${ARENA.minZ} ${ARENA.maxX} ${y} ${ARENA.maxZ}`;

/** 场景公共命令（4 组共用）：forceload → 铺地板×3（防 forceload 异步竞态）→ 清净空 → 真值标记 → 定位 bot。 */
function arenaConsole() {
    return [
        `forceload add ${ARENA.minX} ${ARENA.minZ} ${ARENA.maxX} ${ARENA.maxZ}`,   // ⚠ 四参数
        `fill ${F(ARENA.floorY)} stone`,
        `fill ${F(ARENA.floorY)} stone`,            // 兜底 1
        `fill ${F(ARENA.floorY)} stone`,            // 兜底 2
        `fill ${ARENA.minX} ${ARENA.standY} ${ARENA.minZ} ${ARENA.maxX} ${ARENA.clearTopY} ${ARENA.maxZ} air`,
        `setblock ${ARENA.marker.join(' ')} gold_block`,
        `tp @p ${ARENA.cx} ${ARENA.standY} ${ARENA.cz}`,
    ];
}
const COMMON = ['gamerule doMobSpawning false', 'gamerule doDaylightCycle false'];

/** 通用闸门：真值标记（中心脚下）/ 站在平台上 / 脚与头是空气。 */
export function commonGates(bot) {
    const p = bot.entity?.position;
    if (!p) return [{ name: 'bot_position_known', ok: false, got: null }];
    const at = (x, y, z) => { try { return bot.blockAt(new Vec3(x, y, z)); } catch { return null; } };
    const marker = at(...ARENA.marker);
    // ⚠ 「脚下」是 feet-1 那一格（y = floor(p.y) - 1）。写成 feet 那一格会恒为 air ——
    //   第一版就这么写错的，闸门判 FAIL 而场景其实完全正确。
    const under = at(Math.floor(p.x), Math.floor(p.y) - 1, Math.floor(p.z));
    const head = at(Math.floor(p.x), Math.floor(p.y) + 1, Math.floor(p.z));
    // 「在平台上」用宽松判据：只要站在 17×17 平台范围内、脚下是实心即可。
    // 刻意**不**判"正好在中心"——战斗本身会把 bot 推走（见 marker 处的注释）。
    const onArena = p.x >= ARENA.minX - 1 && p.x <= ARENA.maxX + 1
        && p.z >= ARENA.minZ - 1 && p.z <= ARENA.maxZ + 1
        && p.y >= ARENA.floorY && p.y <= ARENA.standY + 2;
    return [
        // ★ 端到端坐标链判据：标记不在 ⇒ 场景没建对（或建到了别处），后面全部不许测
        { name: 'truth_marker_under_center', ok: marker?.name === 'gold_block', got: marker?.name },
        { name: 'bot_on_arena', ok: onArena, got: `${p.x.toFixed(1)},${p.y.toFixed(1)},${p.z.toFixed(1)}` },
        { name: 'under_foot_is_solid', ok: under?.name === 'stone' || under?.name === 'gold_block', got: under?.name },
        { name: 'head_is_air', ok: head?.name === 'air' || head?.name === 'cave_air', got: head?.name },
    ];
}

/**
 * 环境有没有**竞技场上**多出来的怪。
 * ⚠ 只看 bot 周围 ~10 格：`bot.entities` 里还包括**原出生点那一片**的实体
 *   （bot 被 tp 到 y=200 的空中平台后，视距仍覆盖原来的地面出生点），
 *   那些鸡/兔子与测量无关，却会把闸门判 FAIL（MIC_CREEPER_S7 实测 5 只鸡）。
 *   `doMobSpawning false` 到底生不生效，判据是"平台上有没有多出来的怪"，不是全局。
 */
export function strayMobs(bot, allowed, radius = 10) {
    const p = bot.entity?.position;
    if (!p) return [];
    return Object.values(bot.entities ?? {}).filter((e) => {
        if (!e?.name || e.type === 'player' || allowed.includes(e.name)) return false;
        const q = e.position;
        if (!q) return false;
        return q.distanceTo(p) <= radius;
    }).map((e) => `${e.name}#${e.id}`);
}

// ==================================================================== 四组场景
//
// 每组的形状：{ label, kit, console: [...服务器命令], gates(ctx), measure(ctx) }
//   console 由 run_bench 拼进 --kit（`exec:` 前缀）。

export const SCENARIOS = {

    // ---------------------------------------------------------- 1. 苦力怕（fuse 窗口）
    /** 测：包围盒膨胀判据在真机上能不能测到 fuse 起点，以及「撤到 7 格外」能不能在 1.5s 内做完。 */
    creeper: {
        label: '苦力怕 · fuse 窗口内脱离',
        kit: '',                                  // 故意空手：逼出 decideCreeper 的 unarmed_retreat 路线
        // ⚠ 从 **12 格外**（z=20.5）刷，让它自己走进来：从 4 格外刷的话，它在闸门等待期
        //   就能走到 3 格内、1.5s 后引爆，把 bot 炸飞（MIC_CREEPER_S5 实测炸飞 4.67 格）。
        //   12 格外 ⇒ creep 走到 3 格内约需 4~6s，闸门（约 1~2s）必然先过。
        console: [...COMMON, ...arenaConsole(), 'time set night',
            'summon minecraft:creeper 8.5 201 20.5'],
        gates: async (ctx) => {
            const { bot, prod, sleep } = ctx;
            for (let i = 0; i < 40; i++) {
                if (Object.values(bot.entities ?? {}).some((e) => e.name === 'creeper')) break;
                await sleep(250);
            }
            const c = Object.values(bot.entities ?? {}).find((e) => e.name === 'creeper');
            const stray = strayMobs(bot, ['creeper']);
            return [
                ...commonGates(bot),
                { name: 'creeper_present', ok: !!c, got: c ? `#${c.id}` : 'MISSING' },
                { name: 'creeper_far_enough', ok: c ? ctx.dist3d(c) > 3 : false, got: c ? Number(ctx.dist3d(c).toFixed(2)) : null },
                { name: 'creeper_within_platform', ok: c ? ctx.dist3d(c) < 16 : false, got: c ? Number(ctx.dist3d(c).toFixed(2)) : null },
                { name: 'bot_unarmed', ok: !prod.bestWeapon(bot), got: prod.bestWeapon(bot)?.name ?? 'fist' },
                { name: 'no_stray_mobs', ok: stray.length === 0, got: stray.slice(0, 5).join(',') || '(none)' },
            ];
        },
        measure: async (ctx) => {
            const { bot, prod, log, sleep } = ctx;
            let creep = Object.values(bot.entities ?? {}).find((e) => e.name === 'creeper');
            if (!creep) return { verdict: 'FAIL', samples: [], detail: { why: 'creeper_missing' } };
            for (let i = 0; i < 60 && (!creep || prod.isEntityGone(bot, creep)); i++) {
                await sleep(250);
                creep = Object.values(bot.entities ?? {}).find((e) => e.name === 'creeper');
            }
            if (!creep) return { verdict: 'FAIL', samples: [], detail: { why: 'creeper_exploded_before_measure' } };

            // ① 触发条件用**生产判据**：距离 <6 且有视线 ⇒ classify 给 EMERGENCY。
            //    ⚠ 原来这里等的是 `creeperLooksFused`（包围盒宽度 ≥0.95）——
            //      MIC_CREEPER_S8 实测 98s 都没等到（creep 明明在 5 格外、早该 fuse 并炸），
            //      **结论：1.16.1 客户端上 creep 的 width 不随膨胀变化，包围盒判据不可用**。
            //      这正好把设计 §1.3 标「未核验」的那条结案（结论=否定）。
            //      改成生产真正的触发条件后，本组不再依赖 fuse 检测；
            //      「到底有没有 fuse 信号」降级成**记录项**，不参与判据。
            const tWait0 = Date.now();
            for (let i = 0; i < 300; i++) {          // 最多 30s 等它进 EMERGENCY 距离
                if (ctx.dist3d(creep) < 6 || prod.isEntityGone(bot, creep)) break;
                await sleep(100);
            }
            if (prod.isEntityGone(bot, creep)) return { verdict: 'FAIL', samples: [], detail: { why: 'creeper_exploded_before_emergency' } };
            const tTrigger = Date.now();
            const dAtTrigger = ctx.dist3d(creep);
            const hpBefore = bot.health;
            const fusedAtTrigger = prod.creeperFusingNow(creep);
            const widthAtTrigger = creep.width;
            log(`creeper: 进入 EMERGENCY 距离 t+${tTrigger - tWait0}ms，距离 ${dAtTrigger.toFixed(2)}，fused(元数据)=${fusedAtTrigger}，width=${widthAtTrigger}`);

            // ② 走生产决策（fusing 已是真值 ⇒ 读到 1 的那一拍就进"立即后撤"分支）
            //    几何按裁决 2：落点去 targetRange(9)，到位判据是**实际水平距离 ≥ safeRange(7.5)**，
            //    **不以 navTo 的返回为准**，没到就继续换点撤。
            const plan = prod.decideCreeper({ bot, creeper: creep, dist: dAtTrigger, fusing: fusedAtTrigger, hp: hpBefore });
            const target = plan.targetRange ?? 9;
            const safe = plan.safeRange ?? 7.5;
            let maxWidth = widthAtTrigger, fuseEverSeen = fusedAtTrigger;
            let tSafe = null, noSpot = false, rePlans = 0;
            const trace = [];                      // ★ 距离轨迹：主判据（裁决 3）
            const t0 = Date.now();
            // 最多撤 3 轮：每轮按 target 选点、走过去，再看实际距离到没到 safe
            for (let round = 0; round < 3 && tSafe == null; round++) {
                const spot = prod.pickFleeSpot(bot, creep.position, { minRange: target });
                if (!spot) { noSpot = true; break; }
                rePlans++;
                const navP = ctx.navToSpot(spot.pos);
                for (let i = 0; i < 40; i++) {      // 每轮最多 2s
                    const hd = ctx.hdist(creep);
                    maxWidth = Math.max(maxWidth, creep.width ?? 0);
                    if (prod.creeperFusingNow(creep)) fuseEverSeen = true;
                    if (trace.length < 60) trace.push({ ms: Date.now() - t0, hdist: Number(hd.toFixed(2)) });
                    if (hd >= safe) { tSafe = Date.now(); break; }        // ← 实际距离判据
                    if (prod.isEntityGone(bot, creep)) break;
                    await sleep(50);
                }
                await navP;                        // ⚠ 必定 await（悬空 promise 会崩进程）
                if (prod.isEntityGone(bot, creep)) break;
            }
            await sleep(200);
            const hpAfter = bot.health;
            const escapeMs = tSafe == null ? null : tSafe - tTrigger;
            const damageTaken = hpBefore - hpAfter;
            const maxHdist = trace.length ? Math.max(...trace.map((t2) => t2.hdist)) : null;
            // 判据（设计会话 10-02 夜裁决 1）：**不掉血、没死**。
            //   依据：苦力怕爆炸伤害半径 = 2 × 威力 = 6 格〔wiki·Creeper〕⇒ 6 格外不掉血。
            //   maxHdist / 到达 7.5 的耗时 / 换点次数**降为诊断字段，不参与判据** ——
            //   "≥7.5 才停"仍是**行为目标**（多拉开一点没坏处），但不再是成败定义：
            //   上一版把它当判据，会把"没被炸到但只拉到 7.3 格"误判成失败（n=6 里 3 局）。
            const reachedSafe = escapeMs != null;
            const verdict = (damageTaken === 0 && hpAfter > 0) ? 'PASS' : 'FAIL';
            log(`creeper: 逃生 ${escapeMs ?? '未达 7.5'}ms（换点 ${rePlans} 次），maxHdist=${maxHdist}，掉血 ${damageTaken} ⇒ ${verdict}（判据=不掉血没死）`);
            return {
                verdict, samples: [escapeMs, maxHdist].filter((x) => x != null),
                detail: {
                    triggerWaitMs: tTrigger - tWait0, distAtTrigger: Number(dAtTrigger.toFixed(2)),
                    plan, targetRange: target, safeRange: safe, rePlans,
                    // —— 判据 ——
                    damageTaken, hpBefore, hpAfter, survived: hpAfter > 0,
                    // —— 诊断字段（不参与判据）——
                    escapeMs, maxHdist, reachedSafeRange: reachedSafe, navMs: tSafe == null ? null : tSafe - tTrigger,
                    creepGone: prod.isEntityGone(bot, creep),
                    hdistTrace: trace,
                    fuseBudgetMs: 1500,
                    fuseDetector: {
                        everSeen: fuseEverSeen, widthAtTrigger, maxWidthSeen: maxWidth,
                        baseWidth: 0.6, verdict: fuseEverSeen || maxWidth > 0.7
                            ? '包围盒判据在 1.16.1 客户端可用'
                            : '包围盒判据在 1.16.1 客户端【不可用】：width 始终不变（creep 照常 fuse 并炸）',
                        note: '元数据判据见 fuseprobe 组（阳性对照）',
                    },
                },
            };
        },
    },

    // ---------------------------------------------------------- 1b. 苦力怕 fuse 阳性对照
    /**
     * 阳性对照（设计会话 10-02 夜）：**膨胀状态在实体元数据里客户端可读**，
     * 按 E 线龙相位的计数链（Entity 0–6 / LivingEntity 7–13 / Mob 14）推算 creep 的首索引是 **15**
     * （`DATA_ID_SWELL_DIR`：-1/0 不膨胀、1 膨胀）。
     *
     * 本组**只记录、不判定**：让 creep 自己走近，10Hz 采样整份元数据，
     * 由 `analyzeFuseTrace()` 反推**到底是哪个索引在膨胀时变化**及其时刻/距离。
     * - 对上了（hypothesis15=true）→ 才把它接成 EMERGENCY 触发（读到 1 立刻撤），<6 格那条留作兜底
     * - 对不上 → 停下报告，附原始元数据转储（trace 全量落在 result.json）
     *
     * bot 站着不动 ⇒ **被炸掉血是预期结果**，本组不按掉血判负。
     */
    fuseprobe: {
        label: '苦力怕 · fuse 阳性对照（元数据索引反推）',
        kit: '',
        console: [...COMMON, ...arenaConsole(), 'time set night',
            'summon minecraft:creeper 8.5 201 20.5'],
        gates: async (ctx) => {
            const { bot, sleep } = ctx;
            for (let i = 0; i < 40; i++) {
                if (Object.values(bot.entities ?? {}).some((e) => e.name === 'creeper')) break;
                await sleep(250);
            }
            const c = Object.values(bot.entities ?? {}).find((e) => e.name === 'creeper');
            const stray = strayMobs(bot, ['creeper']);
            return [
                ...commonGates(bot),
                { name: 'creeper_present', ok: !!c, got: c ? `#${c.id}` : 'MISSING' },
                { name: 'bot_unarmed', ok: true, got: 'fist（阳性对照不交战，掉血是预期）' },
                { name: 'no_stray_mobs', ok: stray.length === 0, got: stray.slice(0, 5).join(',') || '(none)' },
            ];
        },
        measure: async (ctx) => {
            const { bot, prod, log, sleep } = ctx;
            let creep = Object.values(bot.entities ?? {}).find((e) => e.name === 'creeper');
            if (!creep) return { verdict: 'FAIL', samples: [], detail: { why: 'creeper_missing' } };
            const hpBefore = bot.health;
            const t0 = Date.now();
            const trace = [];
            const META_LEN = 20;
            // 采样到 creep 消失（炸掉）或 40s 上限
            for (let i = 0; i < 400; i++) {
                if (i % 2 === 0 || i < 4) {                       // 前 8 次全采，之后 5Hz
                    const md = Array.isArray(creep.metadata)
                        ? Array.from({ length: META_LEN }, (_, k) => (creep.metadata[k] ?? null))
                        : null;
                    trace.push({
                        ms: Date.now() - t0,
                        dist: Number(ctx.hdist(creep).toFixed(2)),
                        width: creep.width ?? null,
                        meta: md,
                    });
                }
                if (prod.isEntityGone(bot, creep)) break;
                await sleep(100);
            }
            const gone = prod.isEntityGone(bot, creep);
            const hpAfter = bot.health;
            const analysis = prod.analyzeFuseTrace(trace);
            log(`fuseprobe: ${trace.length} 个样本，creep 消失=${gone}，掉血=${hpBefore - hpAfter}`);
            log(`fuseprobe: hypothesis15=${analysis.hypothesis15} best=${JSON.stringify(analysis.best)}`);
            // 本组判据只看"有没有找到候选索引"——**不按掉血判负**（站着不动被炸是预期）
            const verdict = (analysis.hypothesis15 || (analysis.changed || []).length > 0) ? 'PASS' : 'FAIL';
            return {
                verdict, samples: [Number(trace.length)],
                detail: {
                    samples: trace.length, creepGone: gone, hpBefore, hpAfter,
                    damageTaken: hpBefore - hpAfter,   // 预期 >0：本组不闪避
                    widthEverChanged: new Set(trace.map((s) => s.width)).size > 1,
                    hypothesis15: analysis.hypothesis15,
                    hypothesis15Detail: analysis.hypothesis15Detail,
                    changedIndices: analysis.changed,
                    best: analysis.best,
                    note: '阳性对照：只记录不判定是否"该撤"。width 判据已实测不可用；'
                        + '索引以本轨迹反推为准，对上了才接成 EMERGENCY 触发。',
                    trace,                                          // ← 原始元数据转储（对不上就靠它）
                },
            };
        },
    },

    // ---------------------------------------------------------- 2. 僵尸近战（MeleeTick）
    /** 测：冷却门（0.625s 满蓄的真实间隔）、武器优先级、粘滞选目标、击杀确认。 */
    melee: {
        label: '僵尸近战 · MeleeTick 冷却门与击杀',
        kit: 'stone_sword',                        // 真实前置：TASK-06 链里第一把武器
        console: [...COMMON, ...arenaConsole(), 'time set day',
            'summon minecraft:zombie 10.5 201 10.5', 'summon minecraft:zombie 6.5 201 10.5',
            'summon minecraft:zombie 10.5 201 6.5', 'summon minecraft:zombie 8.5 201 4.5'],
        gates: async (ctx) => {
            const { bot, prod, sleep } = ctx;
            for (let i = 0; i < 40; i++) {
                if (Object.values(bot.entities ?? {}).filter((e) => e.name === 'zombie').length >= 4) break;
                await sleep(250);
            }
            const zs = Object.values(bot.entities ?? {}).filter((e) => e.name === 'zombie');
            const inRange = zs.filter((z) => prod.eyeDistance(bot, z) < 3.2).length;
            const stray = strayMobs(bot, ['zombie']);
            return [
                ...commonGates(bot),
                { name: 'zombies_present', ok: zs.length >= 4, got: zs.length },
                { name: 'zombies_in_melee_range', ok: inRange >= 3, got: inRange },
                { name: 'weapon_is_stone_sword', ok: prod.bestWeapon(bot)?.name === 'stone_sword', got: prod.bestWeapon(bot)?.name ?? 'none' },
                { name: 'no_stray_mobs', ok: stray.length === 0, got: stray.slice(0, 5).join(',') || '(none)' },
            ];
        },
        measure: async (ctx) => {
            const { bot, prod, log, sleep, tele } = ctx;
            const state = prod.makeMeleeState();
            const swings = [];
            const t0 = Date.now();
            let cleared = false;
            let diag = null;
            while (Date.now() - t0 < 90000) {
                const hostiles = prod.visibleHostiles(bot, 0);
                if (!hostiles.length) {
                    // ⚠ 遥测落盘：把"为什么收不到目标"逐个过滤器的读数记下来。
                    //   手册 §5：遥测没落盘 = 没有证据。上一轮这里只记 swings=0，
                    //   结果只能靠读码猜（先后猜了 type、isHostile、chunk 加载，全不是）。
                if (!diag) {
                    const all = Object.values(bot.entities ?? {});
                    diag = {
                        entitiesTotal: all.length,
                        perEntity: all.map((e) => ({
                            id: e.id, name: e.name, type: e.type,
                            eyeDist: Number(prod.eyeDistance(bot, e).toFixed(2)),
                            isHostile: (() => { try { return prod.isHostile ? prod.isHostile(e.name, 0) : 'n/a'; } catch { return 'n/a'; } })(),
                            canSee: (() => { try { return prod.canSeeEntity(bot, e); } catch (err) { return `threw:${String(err.message).slice(0, 60)}`; } })(),
                        })),
                        botEye: (() => { try { return [Number(bot.entity.position.x.toFixed(2)), Number((bot.entity.position.y + 1.62).toFixed(2)), Number(bot.entity.position.z.toFixed(2))]; } catch { return null; } })(),
                        blockUnderBot: (() => { try { return bot.blockAt(bot.entity.position.offset(0, -1, 0))?.name ?? null; } catch { return null; } })(),
                        visibleHostiles: hostiles.length,
                    };
                    tele('melee_no_target_diag', diag);
                    log(`melee: 无目标诊断 ${JSON.stringify(diag)}`);
                }
                    cleared = true; break;
                }
                const r = await prod.meleeBeat(ctx, state, { dimensionId: 0 });
                if (r.fired) { swings.push(Date.now()); log(`melee: swing#${swings.length} target=${r.targetId} str=${r.strength.toFixed(3)}`); }
                await sleep(60);
            }
            const gaps = swings.slice(1).map((t, i) => t - swings[i]);
            const sorted = gaps.slice().sort((a, b) => a - b);
            const med = sorted.length ? sorted[sorted.length >> 1] : null;
            const minGap = gaps.length ? Math.min(...gaps) : null;
            const cooldownMs = prod.weaponCooldownMs('stone_sword');
            // ⚠⚠ **必须要求真的挥过手**，否则这一组会判出**空 PASS**。
            //   实测（MIC_PROBE_LANE trial 1，2026-10-03）：`visibleHostiles` 在 1.16.1
            //   上恒返回空（按 entity.type 预过滤了一个真库里不存在的取值，见 melee_tick.js
            //   头注）⇒ measure 循环**第一拍**就 `hostiles.length === 0` ⇒ `cleared = true`、
            //   `swings = 0`、`minGap = null` ⇒ 而 `gapOk = (minGap == null || …)` 对 null
            //   判 true ⇒ **verdict=PASS，墙钟 1ms，冷却门一次都没被测到**。
            //   一个"什么都没做"的 PASS 比 FAIL 更危险：它会让 3/3 全绿看起来像达标。
            //   判据：① 至少挥 MIN_SWINGS 次（这样才有 gap 可测）② 清场 ③ 最短间隔不越门
            const MIN_SWINGS = 2;
            const swung = swings.length >= MIN_SWINGS;
            const gapOk = minGap == null || minGap >= 560;
            const verdict = (swung && cleared && gapOk) ? 'PASS' : 'FAIL';
            return {
                verdict,
                samples: gaps,
                detail: {
                    swings: swings.length, minSwings: MIN_SWINGS, enoughSwings: swung, cleared,
                    gapsMs: gaps, medianGapMs: med, minGapMs: minGap,
                    weaponCooldownMs: cooldownMs, gapFloorMs: 560, gapOk, hp: bot.health,
                    why: !swung ? 'no_swings' : (!cleared ? 'not_cleared' : (!gapOk ? 'gap_too_short' : null)),
                    noTargetDiag: diag,
                    note: '冷却口径：0.99×625≈619ms 才出手；本组下限取 560ms 抗抖动。'
                        + '⚠ 必须 swings≥2，否则第一拍就空 PASS（MIC_PROBE_LANE 实证）',
                },
            };
        },
    },

    // ---------------------------------------------------------- 3. 骷髅（掩体 + 举盾推进）
    /** 测：断视线掩体能不能被找到并**走到位真的断掉视线**、盾能不能装上并举起。 */
    skeleton: {
        label: '骷髅 · 掩体断视线与举盾推进',
        kit: 'stone_sword,shield',
        console: [...COMMON, ...arenaConsole(), 'time set day',
            'fill 8 201 10 8 202 10 stone',        // 中间 2 格高的柱子（bot 眼位 ~202.6，柱体 201..203 足以遮挡）
            'summon minecraft:skeleton 8.5 201 13.5'],
        gates: async (ctx) => {
            const { bot, prod, sleep } = ctx;
            for (let i = 0; i < 40; i++) {
                if (Object.values(bot.entities ?? {}).some((e) => e.name === 'skeleton')) break;
                await sleep(250);
            }
            const sk = Object.values(bot.entities ?? {}).find((e) => e.name === 'skeleton');
            const pillar = bot.blockAt(new Vec3(8, 202, 10));
            const stray = strayMobs(bot, ['skeleton']);
            return [
                ...commonGates(bot),
                { name: 'skeleton_present', ok: !!sk, got: sk ? `#${sk.id}` : 'MISSING' },
                { name: 'cover_pillar_built', ok: pillar?.name === 'stone', got: pillar?.name },   // fill 静默失败的兜底
                { name: 'pillar_blocks_initial_los', ok: sk ? !prod.canSeeEntity(bot, sk) : false, got: sk ? prod.canSeeEntity(bot, sk) : null },
                { name: 'shield_in_inventory', ok: prod.hasShield(bot), got: prod.hasShield(bot) },
                { name: 'skeleton_in_range', ok: sk ? prod.eyeDistance(bot, sk) < 12 : false, got: sk ? Number(prod.eyeDistance(bot, sk).toFixed(2)) : null },
                { name: 'no_stray_mobs', ok: stray.length === 0, got: stray.slice(0, 5).join(',') || '(none)' },
            ];
        },
        measure: async (ctx) => {
            const { bot, prod, log, sleep, tele } = ctx;
            const sk = Object.values(bot.entities ?? {}).find((e) => e.name === 'skeleton');
            if (!sk) return { verdict: 'FAIL', samples: [], detail: { why: 'skeleton_missing' } };
            const hpBefore = bot.health;
            const equipped = prod.equipShield(bot);
            const raised = equipped ? prod.raiseShield(bot, { telemetry: (e, d) => tele(e, d) }) : false;
            log(`skeleton: equipShield=${equipped} raiseShield=${raised}`);

            const plan = prod.decideSkeleton({ bot, skeleton: sk, dist: prod.eyeDistance(bot, sk), hp: bot.health, shield: prod.hasShield(bot), hostiles: 1 });
            let coverLosBroken = null, timeToCover = null, coverPos = null;
            if (plan.phase === 'cover' && plan.target) {
                coverPos = [Number(plan.target.x.toFixed(2)), Number(plan.target.y.toFixed(2)), Number(plan.target.z.toFixed(2))];
                const t0 = Date.now();
                await ctx.navToSpot(plan.target);
                timeToCover = Date.now() - t0;
                // **判据是 LOS 真断**，不是"走到了附近"（设计 §2.3 要求体素射线验证）
                await sleep(300);
                coverLosBroken = !prod.canSeeEntity(bot, sk);
                log(`skeleton: coverLosBroken=${coverLosBroken} timeToCover=${timeToCover}ms plan=${plan.phase}/${plan.reason}`);
            }
            const hpAfter = bot.health;
            const verdict = (plan.phase === 'cover' && coverLosBroken === true && hpAfter >= hpBefore) ? 'PASS' : 'FAIL';
            return {
                verdict, samples: [timeToCover].filter((x) => x != null),
                detail: { plan, equipped, raised, coverPos, coverLosBroken, timeToCoverMs: timeToCover, hpBefore, hpAfter, damageTaken: hpBefore - hpAfter },
            };
        },
    },

    // ---------------------------------------------------------- 4. 末影人（凝视守卫）
    /** 测：正对末影人时守卫**确实拦下** lookAt、并把俯仰压到 ≤−15°、且末影人没有被激怒冲过来。 */
    gaze: {
        label: '末影人 · 凝视守卫拦截',
        kit: '',
        console: [...COMMON, ...arenaConsole(), 'time set night',
            'summon minecraft:enderman 8.5 201 14.5'],   // +z 6 格
        gates: async (ctx) => {
            const { bot, prod, sleep } = ctx;
            for (let i = 0; i < 40; i++) {
                if (Object.values(bot.entities ?? {}).some((e) => e.name === 'enderman')) break;
                await sleep(250);
            }
            const em = Object.values(bot.entities ?? {}).find((e) => e.name === 'enderman');
            const stray = strayMobs(bot, ['enderman']);
            return [
                ...commonGates(bot),
                { name: 'enderman_present', ok: !!em, got: em ? `#${em.id}` : 'MISSING' },
                { name: 'enderman_within_64', ok: em ? prod.eyeDistance(bot, em) < 64 : false, got: em ? Number(prod.eyeDistance(bot, em).toFixed(2)) : null },
                { name: 'enderman_near_spawn_point', ok: em ? ctx.dist3d(em) < 9 : false, got: em ? Number(ctx.dist3d(em).toFixed(2)) : null },
                { name: 'no_stray_mobs', ok: stray.length === 0, got: stray.slice(0, 5).join(',') || '(none)' },
            ];
        },
        measure: async (ctx) => {
            const { bot, prod, log, sleep, tele } = ctx;
            const em = Object.values(bot.entities ?? {}).find((e) => e.name === 'enderman');
            if (!em) return { verdict: 'FAIL', samples: [], detail: { why: 'enderman_missing' } };
            // ① 先让 bot 正对它（用 bot.look 设 yaw/pitch，**不是** lookAt —— 那正是被守卫拦的东西）
            try { bot.look(0, 0, false); } catch {}
            await sleep(400);
            const baseline = prod.wouldStare(bot, em);
            log(`gaze: 基准（正对）wouldStare=${baseline.stare} deg=${baseline.deg?.toFixed(2)}`);

            // ② 装生产守卫（DefenseLayer 用的就是这个函数）
            const g = prod.installGazeGuard(bot, { telemetry: (e, d) => tele(e, d) });
            const posBefore = em.position.clone();
            // ③ 试着盯它 —— 应被拒绝
            bot.lookAt(prod.entityEye(em), false);
            await sleep(300);
            const rejected = g.rejected();
            // ⚠ 必须读 `bot.entity.pitch`（**数字**），不能读 `bot.entity.look.y`：
            //   mineflayer 4.38 的实体没有 `look` 属性（prismarine-entity 只有
            //   yaw/pitch 两个数字，实测 `'look' in entity === false`）。
            //   原来这里 `bot.entity?.look?.y ?? 0` 恒为 0 ⇒ `pitchDeg <= -10`
            //   恒 false ⇒ **gaze 组无论守卫对不对都判 FAIL**（确定性假失败）。
            const pitchDeg = (Number(bot.entity?.pitch ?? 0)) * 180 / Math.PI;
            log(`gaze: rejected=${rejected} pitch=${pitchDeg.toFixed(1)}°`);

            // ④ 观察 3s：末影人没被激怒 ⇒ 不该直线冲过来
            await sleep(3000);
            const moved = em.position.distanceTo(posBefore);
            const stillThere = !prod.isEntityGone(bot, em);
            const notAngry = moved < 2.0;
            g.restore();
            const verdict = (baseline.stare && rejected >= 1 && pitchDeg <= -10 && notAngry) ? 'PASS' : 'FAIL';
            return {
                verdict, samples: [rejected, pitchDeg, moved].filter((x) => x != null),
                detail: {
                    baselineStare: baseline.stare, baselineDeg: baseline.deg,
                    guardInstalled: g.installed, rejected, pitchDeg: Number(pitchDeg.toFixed(1)),
                    endermanMoved: Number(moved.toFixed(2)), endermanStillPresent: stillThere, notAngry,
                    note: '俯仰判据 ≤−10°（设计初值 −15°，留 5° 抖动余量）；notAngry 判据 3s 内位移 <2 格',
                },
            };
        },
    },
};

export const SCENARIO_NAMES = Object.keys(SCENARIOS);
