// los.js — MC-M1-TASK-07（G 线）：体素视线射线（LOS）+ 眼位/安全步进
//
// 设计 §1.3：「LOS：体素射线 ~30 行自写；遮挡判据 = boundingBox==='block'
//   （不用 minecraft-data 的 transparent —— RESEARCH-01 §5.4：≤1.16.2 该属性不可靠
//    mcdata#937）」。
//
// 本文件**只用 bot.blockAt()**，因此可以喂假 bot 完全离线单测（selftest T3 组）：
// 假 bot 只需实现 blockAt(Vec3) → {boundingBox}，不需要真服务器。
//
// 算法：Amanatides & Woo 3D DDA 体素遍历（精确、不漏格、不重复访问），
// 起点格（bot 自己所在的格）不判遮挡（否则贴墙站时永远"看不见东西"），
// 终点格判遮挡（目标在墙里就是看不见——这正是要的语义）。

import { Vec3 } from 'vec3';

/** 方块是否遮挡视线。唯一判据是 boundingBox==='block'（设计 §1.3 指定）。 */
export function blocksSight(block) {
    if (!block) return false;
    // 未加载区块 blockAt 返回 null → 保守当作"不遮挡"？
    // 不：手册 §3「读方块一律用 bot.blockAt」且 prismarine 对未加载格返回 null，
    // 把 null 当不遮挡会让"墙后"被读成"可见"。但把 null 当遮挡会让跨区块边缘全部
    // 误判遮挡。折中：未加载 = 不可见（los=false），由调用方的 monitor 档兜底。
    return block.boundingBox === 'block';
}

function isLoaded(block) { return !!block; }

/**
 * 体素 DDA 射线。返回被遮挡的那一格，或 null（通视）。
 * @returns {{x:number,y:number,z:number,index:number}|null}
 */
export function raycastBlock(bot, from, to, opts = {}) {
    const maxSteps = opts.maxSteps ?? 256;
    // 起点格与终点格
    let x = Math.floor(from.x), y = Math.floor(from.y), z = Math.floor(from.z);
    const ex = Math.floor(to.x), ey = Math.floor(to.y), ez = Math.floor(to.z);
    const dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
    if (dx === 0 && dy === 0 && dz === 0) return null;

    const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
    // 每轴到下一格边界的参数 t
    const tDeltaX = dx === 0 ? Infinity : Math.abs(1 / dx);
    const tDeltaY = dy === 0 ? Infinity : Math.abs(1 / dy);
    const tDeltaZ = dz === 0 ? Infinity : Math.abs(1 / dz);
    // 起点在格内的相对位置 → 到该格边界的 t
    const bound = (c, cell) => (stepX > 0 ? (cell + 1 - c) : (c - cell));
    let tMaxX = dx === 0 ? Infinity : tDeltaX * bound(from.x, x);
    let tMaxY = dy === 0 ? Infinity : tDeltaY * bound(from.y, y);
    let tMaxZ = dz === 0 ? Infinity : tDeltaZ * bound(from.z, z);

    let steps = 0;
    // 跳过起点格
    if (Math.abs(tMaxX - tMaxY) < 1e-9 && Math.abs(tMaxX - tMaxZ) < 1e-9) { /* 对角起步 */ }
    for (; steps <= maxSteps; steps++) {
        // 推进到下一格（取 t 最小的轴）
        if (tMaxX < tMaxY && tMaxX < tMaxZ) { x += stepX; tMaxX += tDeltaX; }
        else if (tMaxY < tMaxZ) { y += stepY; tMaxY += tDeltaY; }
        else { z += stepZ; tMaxZ += tDeltaZ; }

        if (steps > maxSteps) return null;
        if (x === ex && y === ey && z === ez) {
            // 终点格：检查是否落在实心方块里（目标被埋 = 看不见）
            const endBlock = safeBlockAt(bot, x, y, z);
            return blocksSight(endBlock) && isLoaded(endBlock) ? { x, y, z, index: steps } : null;
        }
        const b = safeBlockAt(bot, x, y, z);
        if (b === null) return { x, y, z, index: steps, unloaded: true }; // 未加载 → 不可见
        if (blocksSight(b)) return { x, y, z, index: steps };
    }
    return null;
}

function safeBlockAt(bot, x, y, z) {
    try { return bot.blockAt(new Vec3(x, y, z)); } catch { return null; }
}

/** bot 眼位（MC 1.16.1 玩家眼高 1.62）。 */
export function eyeOf(bot) {
    const p = bot.entity?.position;
    if (!p) return null;
    return new Vec3(p.x, p.y + (bot.entity?.height ?? 1.8) * 0.9, p.z);
}

/** 实体眼位（怪物眼高取 height*0.9，末影人按 2.9 高）。 */
export function entityEye(entity) {
    if (!entity?.position) return null;
    const h = Number(entity.height ?? 1.8);
    return new Vec3(entity.position.x, entity.position.y + h * 0.9, entity.position.z);
}

/**
 * bot 眼位 → 目标眼位是否通视。false = 被墙挡或区块未加载。
 */
export function hasLineOfSight(bot, targetPoint, from = null) {
    const a = from ?? eyeOf(bot);
    if (!a || !targetPoint) return false;
    return raycastBlock(bot, a, targetPoint) === null;
}

/** bot → 实体 是否通视（便捷版，距离用眼位差）。 */
export function canSeeEntity(bot, entity) {
    const e = entityEye(entity);
    if (!e) return false;
    return hasLineOfSight(bot, e);
}

/** 眼位距离（格）。 */
export function eyeDistance(bot, entity) {
    const a = eyeOf(bot), b = entityEye(entity);
    if (!a || !b) return Infinity;
    return a.distanceTo(b);
}

/** 水平距离（格）——脱离/绕行判据用水平分量（垂直差不该算"没脱身"）。 */
export function horizontalDistance(bot, entity) {
    const p = bot.entity?.position, q = entity?.position;
    if (!p || !q) return Infinity;
    return Math.hypot(p.x - q.x, p.z - q.z);
}

/** 某点是否被方块占据（实心）。用于掩体/塔的落点校验。 */
export function isSolid(bot, v) {
    const b = safeBlockAt(bot, Math.floor(v.x), Math.floor(v.y), Math.floor(v.z));
    return blocksSight(b);
}
